import pathlib,json,collections
r=pathlib.Path('artifacts/zemax-standard-samples/20261015/full-matrix-v1')
for slug in ['zoom-lens','wide-angle-lens-100-degree-field','wide-angle-lens-200-degree-field','wide-angle-lens-210-degree-field']:
 for c in range(1,4) if slug=='zoom-lens' else [1]:
  snap=json.loads((r/f'models/{slug}-c{c}.json').read_text())
  model=json.loads((r/f'native-models/{slug}-c{c}/model.json').read_text())
  core=json.loads((r/f'rays/{slug}-c{c}-w1/core.json').read_text())
  nat=json.loads((r/f'rays/{slug}-c{c}-w1/native/ray-audit.json').read_text())
  print(slug,c,'snapkeys',list(snap)[:20] if c==1 else '')
  print('aperture',snap.get('aperture'),'aim',snap.get('rayAimingEnabled'),'native',model['aperture'],model['rayAiming'])
  print('pupil',nat['entrancePupilDiameter'],nat['entrancePupilPosition'],'fields',model['fields'])
  for field in core:
   fi=field['fieldIndex']; i=fi*len(field['rays']); ray=field['rays'][0]
   print('field',fi,'input',nat['inputs'][i], 'launchNative',nat['launches'][i],'coreObject',ray['samples'][0],'coreLast',ray['samples'][-1])
  print('surface keys',list(snap['surfaces'][0]))
  print('coreSurface',[(s.get('number'),s.get('thickness'),s.get('semiDiameter'),s.get('semiDiameterFixed'),s.get('physicalAperture'),s.get('isStop')) for s in snap['surfaces']])
  print('nativeSurface',[(s.get('SurfaceNumber'),s.get('Thickness'),s.get('SemiDiameter'),s.get('IsStop'),s.get('Radius')) for s in model['surfaces']])
