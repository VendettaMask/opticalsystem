using System.Globalization;
using System.Text;
using OpticalSystemDesign.Core.Apertures;
using OpticalSystemDesign.Core.Apodization;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Coordinates;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Geometries;
using OpticalSystemDesign.Core.Interactions;
using OpticalSystemDesign.Core.Materials;
using OpticalSystemDesign.Core.Optimization;
using OpticalSystemDesign.Core.Serialization;

namespace OpticalSystemDesign.Core.FileIO;

internal static class ZemaxZmxReader
{
    public static Optic Import(string text)
    {
        return ImportConfigurationSet(text).ActiveOptic;
    }

    public static ZemaxZmxImportResult ImportConfigurationSet(string text)
    {
        var document = Parse(text);
        Validate(document);

        var configurations = Enumerable.Range(0, Math.Max(1, document.ConfigurationCount))
            .Select(configurationIndex => BuildOptic(document, configurationIndex))
            .ToArray();
        var activeConfigurationIndex = DetectActiveConfiguration(document);
        return new ZemaxZmxImportResult(
            configurations[activeConfigurationIndex],
            configurations,
            activeConfigurationIndex);
    }

    private static Optic BuildOptic(ZemaxDocument document, int configurationIndex)
    {
        var optic = new Optic(document.Name);
        optic.Materials.SetPreferredGlassCatalogs(document.GlassCatalogs);
        var configuredSurfaces = ConfigureSurfaces(document, configurationIndex);
        var converted = ConvertSurfaces(optic, configuredSurfaces, document.GlassCatalogs);
        InstallConvertedSurfaces(optic, converted);
        var sourceSurfaceNumbers = configuredSurfaces
            .Where(surface => !surface.Type.Equals("COORDBRK", StringComparison.OrdinalIgnoreCase))
            .Select(surface => surface.Number).ToArray();
        optic.GlobalReferenceSurfaceNumber = Array.IndexOf(sourceSurfaceNumbers, document.GlobalReferenceSurfaceNumber);
        if (optic.GlobalReferenceSurfaceNumber < 0)
            throw new NotSupportedException($"全局参考面 {document.GlobalReferenceSurfaceNumber} 不存在或为坐标断点；不能转换到物理表面。");
        InstallSemiDiameterPickups(optic, configuredSurfaces);

        ConfigureAperture(optic, document, configurationIndex);
        optic.Apodization = document.Apodization?.Clone();
        optic.RayAimingEnabled = document.RayAimingEnabled;
        optic.ImageSpaceAfocal = document.AfocalImageSpace;
        ConfigureFields(optic, document, configurationIndex);
        ConfigureWavelengths(optic, document, configurationIndex);
        // Keep the file's stored thicknesses when dispersion is unavailable.
        // A ray-based solve must not prevent the rest of the document from importing.
        if (!optic.SurfaceGroup.Items.Any(surface => surface.MaterialAfter is UnresolvedMaterial))
            ApplyThicknessSolves(optic, configuredSurfaces, document.GlassCatalogs);
        ConfigureMeritFunction(optic, document);
        return optic;
    }

    private static void InstallConvertedSurfaces(
        Optic optic,
        IReadOnlyList<ConvertedSurface> converted)
    {
        optic.SurfaceGroup.Replace(converted.Select(item => item.Surface));
        foreach (var item in converted)
        {
            var surface = optic.SurfaceGroup.Items[item.Index];
            surface.Geometry = item.Geometry;
            surface.MaterialBefore = item.MaterialBefore;
            surface.MaterialAfter = item.MaterialAfter;
            surface.InteractionModel = new RefractiveReflectiveInteractionModel(item.IsReflective);
            surface.CoordinateSystem = item.CoordinateSystem;
        }
    }

    private static void InstallSemiDiameterPickups(
        Optic optic,
        IReadOnlyList<ZemaxSurface> sourceSurfaces)
    {
        var sourceToImported = sourceSurfaces
            .Where(surface => !surface.Type.Equals("COORDBRK", StringComparison.OrdinalIgnoreCase))
            .Select((surface, index) => (surface.Number, index))
            .ToDictionary(item => item.Number, item => item.index);
        foreach (var surface in sourceSurfaces.Where(surface => surface.SemiDiameterSolveCode == 2))
        {
            if (!sourceToImported.TryGetValue(surface.Number, out var target)
                || !sourceToImported.TryGetValue(surface.SemiDiameterPickupSource, out var source)
                || source >= target)
                continue;
            optic.Pickups.SetSemiDiameterPickup(source, target, surface.SemiDiameterPickupScale);
        }
        optic.Pickups.ApplyAll();
    }

    public static string Decode(ReadOnlySpan<byte> bytes)
    {
        if (bytes.StartsWith(new byte[] { 0xFF, 0xFE }))
        {
            return Encoding.Unicode.GetString(bytes[2..]);
        }

        if (bytes.StartsWith(new byte[] { 0xFE, 0xFF }))
        {
            return Encoding.BigEndianUnicode.GetString(bytes[2..]);
        }

        if (bytes.StartsWith(new byte[] { 0xEF, 0xBB, 0xBF }))
        {
            return Encoding.UTF8.GetString(bytes[3..]);
        }

        var sampleLength = Math.Min(bytes.Length, 512);
        var evenZeros = 0;
        var oddZeros = 0;
        for (var index = 0; index < sampleLength; index++)
        {
            if (bytes[index] != 0)
            {
                continue;
            }

            if ((index & 1) == 0)
            {
                evenZeros++;
            }
            else
            {
                oddZeros++;
            }
        }

        if (oddZeros > sampleLength / 8 && oddZeros > evenZeros * 2)
        {
            return Encoding.Unicode.GetString(bytes);
        }

        if (evenZeros > sampleLength / 8 && evenZeros > oddZeros * 2)
        {
            return Encoding.BigEndianUnicode.GetString(bytes);
        }

        try
        {
            return new UTF8Encoding(false, true).GetString(bytes);
        }
        catch (DecoderFallbackException)
        {
            return Encoding.Latin1.GetString(bytes);
        }
    }

    private static ZemaxDocument Parse(string text)
    {
        var document = new ZemaxDocument();
        ZemaxSurface? current = null;

        foreach (var rawLine in text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
        {
            var line = rawLine.Trim();
            if (line.Length == 0 || line.StartsWith('!'))
            {
                continue;
            }

            var tokens = line.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
            if (tokens.Length == 0)
            {
                continue;
            }

            var command = tokens[0].ToUpperInvariant();
            switch (command)
            {
                case "UNIT":
                    ReadUnit(document, tokens);
                    break;
                case "NAME":
                    document.Name = tokens.Length > 1
                        ? string.Join(" ", tokens.Skip(1)).Trim('"')
                        : document.Name;
                    break;
                case "MODE":
                    if (tokens.Length < 2 || !tokens[1].Equals("SEQ", StringComparison.OrdinalIgnoreCase))
                    {
                        throw new NotSupportedException("Only sequential Zemax ZMX files (MODE SEQ) are supported.");
                    }

                    document.SequentialModeSeen = true;
                    break;
                case "FNUM":
                    ReadFNumber(document, tokens);
                    break;
                case "ENPD":
                    document.UpsertAperture(
                        "EPD",
                        ApertureKind.EntrancePupilDiameter,
                        ScaleLength(document, RequiredDouble(tokens, 1, command)));
                    break;
                case "OBNA":
                    ReadObjectNumericalAperture(document, tokens);
                    break;
                case "FLOA":
                    document.FloatingStop = true;
                    break;
                case "GFAC":
                    var factor = RequiredDouble(tokens, 1, command);
                    var apodizationType = RequiredInt(tokens, 2, command);
                    if (apodizationType is < 0 or > 2)
                    {
                        throw new NotSupportedException($"Zemax GFAC apodization type {apodizationType} is not supported.");
                    }

                    document.Apodization = new ZemaxApodization((ZemaxApodizationType)apodizationType, factor);
                    break;
                case "RAIM":
                    document.RayAimingEnabled = tokens.Length > 2
                        && RequiredInt(tokens, 2, command) != 0;
                    break;
                case "GLRS":
                    document.GlobalReferenceSurfaceNumber = RequiredInt(tokens, 1, command);
                    break;
                case "FTYP":
                    ReadConfiguration(document, tokens);
                    break;
                case "XFLN":
                    document.FieldX = ReadValues(tokens, 1, document.FieldCount);
                    break;
                case "YFLN":
                    document.FieldY = ReadValues(tokens, 1, document.FieldCount);
                    break;
                case "FWGN":
                    document.FieldWeights = ReadValues(tokens, 1, document.FieldCount);
                    break;
                case "FCOM":
                    ReadFieldComment(document, line, tokens);
                    break;
                case "VCXN":
                    document.VignetteX = ReadValues(tokens, 1, document.FieldCount);
                    break;
                case "VCYN":
                    document.VignetteY = ReadValues(tokens, 1, document.FieldCount);
                    break;
                case "APMN" when tokens.Length <= 2 && current is not null:
                    RequireSurface(current, command).MinimumAperture =
                        Math.Abs(ScaleLength(document, RequiredDouble(tokens, 1, command)));
                    break;
                case "APMX" when tokens.Length <= 2 && current is not null:
                    RequireSurface(current, command).SemiDiameter =
                        Math.Abs(ScaleLength(document, RequiredDouble(tokens, 1, command)));
                    break;
                case "VDXN":
                    document.VignetteDecenterX = ReadValues(tokens, 1, document.FieldCount);
                    break;
                case "VDYN":
                    document.VignetteDecenterY = ReadValues(tokens, 1, document.FieldCount);
                    break;
                case "VANN":
                    document.VignetteAngle = ReadValues(tokens, 1, document.FieldCount);
                    break;
                case "WAVM":
                    ReadWavelength(document, tokens);
                    break;
                case "PWAV":
                    document.PrimaryWavelengthIndex = RequiredInt(tokens, 1, command) - 1;
                    break;
                case "DMFS":
                    document.MeritOperands.Add(new MeritOperandDefinition
                    {
                        Enabled = false,
                        Type = "DMFS"
                    });
                    break;
                case "BLNK":
                    document.MeritOperands.Add(new MeritOperandDefinition
                    {
                        Enabled = false,
                        Type = "BLNK",
                        Comment = line.Length > command.Length
                            ? line[command.Length..].Trim().Trim('"')
                            : string.Empty
                    });
                    break;
                case "OPDX":
                case "OPDM":
                case "OPDC":
                case "TRAC":
                case "TRAR":
                case "TRCX":
                case "TRCY":
                case "TRAX":
                case "TRAY":
                case "ANAC":
                case "ANAR":
                case "ANCX":
                case "ANCY":
                case "ANAX":
                case "ANAY":
                case "REAX":
                case "REAY":
                case "REAR":
                case "RANG":
                    ReadPupilRayMeritOperand(document, tokens, command);
                    break;
                case "RSCE":
                case "RSCH":
                case "RSRE":
                case "RSRH":
                    ReadRmsSpotMeritOperand(document, tokens, command);
                    break;
                case "CENX":
                case "CENY":
                case "MECS":
                case "MECT":
                case "EFFL":
                case "EFLX":
                case "EFLY":
                case "ENPP":
                case "EPDI":
                case "EXPP":
                case "EXPD":
                case "ISNA":
                case "ISFN":
                    ReadStandardMeritOperand(document, tokens, command);
                    break;
                // These native parameter layouts still require captured-file validation.
                case "RRET":
                case "CMGT":
                case "CMLT":
                case "CMVA":
                case "CIGT":
                case "CILT":
                case "CIVA":
                case "CEGT":
                case "CELT":
                case "CEVA":
                case "CODA":
                case "HYLD":
                case "DLTN":
                case "GRMN":
                case "GRMX":
                case "I1GT":
                case "I1LT":
                case "I1VA":
                case "I2GT":
                case "I2LT":
                case "I2VA":
                case "I3GT":
                case "I3LT":
                case "I3VA":
                case "I4GT":
                case "I4LT":
                case "I4VA":
                case "I5GT":
                case "I5LT":
                case "I5VA":
                case "I6GT":
                case "I6LT":
                case "I6VA":
                case "BFSD":
                case "TSAG":
                case "RELI":
                case "EFNO":
                case "DIST":
                case "DISA":
                case "MECA":
                case "ZERN":
                case "FDMO":
                case "FDRE":
                case "PRIM":
                case "SVIG":
                case "IMSF":
                case "SPHS":
                case "PSLP":
                case "DPHS":
                case "QSLP":
                case "DENC":
                case "DENF":
                case "SSAG":
                case "SSLP":
                case "SCRV":
                case "GENC":
                case "GENF":
                case "ERFP":
                case "VOLU":
                case "TMAS":
                case "DSAG":
                case "DSLP":
                case "DCRV":
                // The native surface TCE record has not been validated against a capture.
                case "TCVA":
                case "TCGT":
                case "TCLT":
                    ReadPreservedMeritOperand(document, tokens, command);
                    break;
                case "MTHA":
                case "MTHS":
                case "MTHT":
                case "MTHN":
                case "MTHX":
                case "MNRE":
                case "MNRI":
                case "MXRE":
                case "MXRI":
                    // Native extended MFE text layout has not been validated against a capture.
                    // Keep the exact record instead of silently losing the seventh parameter.
                    ReadPreservedMeritOperand(document, tokens, command);
                    break;
                case "TFNO":
                case "SFNO":
                case "WFNO":
                case "WLEN":
                case "INDX":
                case "POWR":
                case "PMAG":
                case "PETZ":
                    ReadStandardMeritOperand(document, tokens, command);
                    break;
                case "TOTR":
                    ReadSystemMeritOperand(document, tokens, command);
                    break;
                case "TTHI":
                case "TGTH":
                    ReadRangeThicknessMeritOperand(document, tokens, command);
                    break;
                case "ETGT":
                case "ETLT":
                case "ETVA":
                case "FTGT":
                case "FTLT":
                case "STHI":
                case "TTGT":
                case "TTLT":
                case "TTVA":
                    ReadSurfaceBoundaryMeritOperand(document, tokens, command);
                    break;
                case "CTGT":
                case "CTLT":
                case "CTVA":
                case "CVGT":
                case "CVLT":
                case "CVVA":
                case "COGT":
                case "COLT":
                case "COVA":
                    ReadSurfaceBoundaryMeritOperand(document, tokens, command);
                    break;
                case "MNCA":
                case "MXCA":
                case "MNEA":
                case "MXEA":
                case "MNCG":
                case "MXCG":
                case "MNEG":
                case "MXEG":
                case "MNCT":
                case "MXCT":
                case "MNET":
                case "MXET":
                case "MNCV":
                case "MXCV":
                case "MNSD":
                case "MXSD":
                case "MNIN":
                case "MXIN":
                case "MNAB":
                case "MXAB":
                case "XNEA":
                case "XXEA":
                case "XNEG":
                case "XXEG":
                case "XNET":
                case "XXET":
                    ReadRangeThicknessMeritOperand(document, tokens, command);
                    break;
                case "CONS":
                case "SINE":
                case "COSI":
                case "TANG":
                case "ASIN":
                case "ACOS":
                case "ATAN":
                case "ABSO":
                case "SQRT":
                case "RECI":
                case "LOGE":
                case "LOGT":
                case "SUMM":
                case "PROB":
                case "PROD":
                case "DIVB":
                case "DIVI":
                case "DIFF":
                case "EQUA":
                case "MAXX":
                case "MINN":
                case "OSUM":
                case "QSUM":
                case "OPGT":
                case "OPLT":
                case "ABGT":
                case "ABLT":
                case "OPVA":
                    ReadMathMeritOperand(document, tokens, command);
                    break;
                case "MCOV":
                case "MCOG":
                case "MCOL":
                case "CONF":
                case "ZTHI":
                    ReadPreservedMeritOperand(document, tokens, command);
                    break;
                case "MNUM":
                    document.ConfigurationCount = CheckedConfigurationCount(
                        RequiredInt(tokens, 1, command),
                        command);
                    break;
                case "THIC":
                case "CRVT":
                case "APER":
                case "APMN":
                case "APMX":
                case "XFIE":
                case "YFIE":
                case "WAVE":
                case "WLWT":
                case "GLSS":
                case "STPS":
                case "PRAM":
                    ReadConfigurationOperand(document, tokens, command);
                    break;
                case "GCAT":
                    document.GlassCatalogs.AddRange(tokens.Skip(1));
                    break;
                case "SURF":
                    current = new ZemaxSurface(RequiredInt(tokens, 1, command));
                    document.Surfaces.Add(current);
                    break;
                case "TYPE":
                    RequireSurface(current, command).Type = RequiredToken(tokens, 1, command).ToUpperInvariant();
                    break;
                case "PARM":
                    var parameterIndex = RequiredInt(tokens, 1, command) - 1;
                    if (parameterIndex < 0)
                    {
                        throw new InvalidDataException("Zemax PARM indices are one-based positive integers.");
                    }

                    var parameterSurface = RequireSurface(current, command);
                    parameterSurface.Parameters[parameterIndex] = ScaleSurfaceParameter(
                        document,
                        parameterSurface.Type,
                        parameterIndex,
                        RequiredDouble(tokens, 2, command));
                    break;
                case "CURV":
                    var curvature = RequiredDouble(tokens, 1, command);
                    RequireSurface(current, command).Radius = RadiusFromCurvature(
                        curvature,
                        document.LengthScaleToMillimeters);
                    break;
                case "DISZ":
                    RequireSurface(current, command).Thickness = RequiredDistance(document, tokens, 1, command);
                    break;
                case "MAZH":
                    RequireSurface(current, command).MarginalRayHeightSolve = new ZemaxMarginalRayHeightSolve(
                        RequiredDouble(tokens, 1, command),
                        tokens.Length > 2 ? RequiredDouble(tokens, 2, command) : 0);
                    break;
                case "CONI":
                    RequireSurface(current, command).Conic = RequiredDouble(tokens, 1, command);
                    break;
                case "GLAS":
                    ReadGlass(RequireSurface(current, command), tokens);
                    break;
                case "STOP":
                    RequireSurface(current, command).IsStop = true;
                    break;
                case "MIRR":
                    if (tokens.Length == 1)
                    {
                        RequireSurface(current, command).IsMirror = true;
                    }
                    break;
                case "DIAM":
                    ReadSemiDiameter(document, RequireSurface(current, command), tokens);
                    break;
                case "MEMA":
                    ReadMechanicalSemiDiameter(document, RequireSurface(current, command), tokens);
                    break;
                case "COMM":
                    RequireSurface(current, command).Comment = tokens.Length > 1
                        ? string.Join(" ", tokens.Skip(1)).Trim('"')
                        : string.Empty;
                    break;
                default:
                    if (ZemaxOperandRegistry.TryGet(command, out var operandDescriptor))
                    {
                        if (operandDescriptor.SupportLevel == ZemaxOperandSupportLevel.Executable)
                            ReadSystemMeritOperand(document, tokens, command);
                        else
                            ReadPreservedMeritOperand(document, tokens, command);
                    }
                    break;
            }
        }

        return document;
    }

    private static void Validate(ZemaxDocument document)
    {
        if (!document.SequentialModeSeen)
        {
            throw new InvalidDataException("The Zemax document does not declare MODE SEQ.");
        }

        if (document.Apertures.Count == 0 && !document.FloatingStop)
        {
            throw new InvalidDataException("The Zemax document does not define a supported system aperture.");
        }

        if (document.Surfaces.Count(surface => surface.Type != "COORDBRK") < 2)
        {
            throw new InvalidDataException("A Zemax document must contain at least object and image surfaces.");
        }

        var stopCount = document.Surfaces.Count(surface => surface.IsStop);
        if (stopCount > 1)
        {
            throw new InvalidDataException("A Zemax document may contain only one aperture stop.");
        }
    }

    private static IReadOnlyList<ZemaxSurface> ConfigureSurfaces(
        ZemaxDocument document,
        int configurationIndex)
    {
        var configuredStop = document.ConfigurationDouble("STPS", 0, configurationIndex);
        return document.Surfaces.Select(source =>
        {
            var material = document.ConfigurationText("GLSS", source.Number, configurationIndex)
                ?? source.Material;
            var configured = new ZemaxSurface(source.Number)
            {
                Type = source.Type,
                Comment = source.Comment,
                Radius = RadiusFromConfiguredCurvature(
                    document,
                    document.ConfigurationDouble("CRVT", source.Number, configurationIndex),
                    source.Radius),
                Thickness = ScaleConfiguredDistance(
                    document,
                    document.ConfigurationDouble(
                    "THIC",
                    source.Number,
                    configurationIndex),
                    source.Thickness),
                Conic = source.Conic,
                Material = string.IsNullOrWhiteSpace(material) ? "Air" : material,
                RefractiveIndex = source.RefractiveIndex,
                AbbeNumber = source.AbbeNumber,
                SemiDiameter = ScaleConfiguredLength(
                    document,
                    document.ConfigurationDouble(
                    "APMX",
                    source.Number,
                    configurationIndex),
                    source.SemiDiameter),
                MinimumAperture = ScaleConfiguredOptionalLength(
                    document,
                    document.ConfigurationDouble(
                    "APMN",
                    source.Number,
                    configurationIndex),
                    source.MinimumAperture),
                SemiDiameterFixed = source.SemiDiameterFixed,
                SemiDiameterSolveCode = source.SemiDiameterSolveCode,
                SemiDiameterPickupSource = source.SemiDiameterPickupSource,
                SemiDiameterPickupScale = source.SemiDiameterPickupScale,
                MechanicalSemiDiameter = source.MechanicalSemiDiameter,
                MechanicalSemiDiameterSolveCode = source.MechanicalSemiDiameterSolveCode,
                IsStop = configuredStop.HasValue
                    ? source.Number == (int)Math.Round(configuredStop.Value)
                    : source.IsStop,
                IsMirror = source.IsMirror || material.Equals("MIRROR", StringComparison.OrdinalIgnoreCase)
            };
            configured.MarginalRayHeightSolve = source.MarginalRayHeightSolve;
            foreach (var parameter in source.Parameters)
            {
                configured.Parameters[parameter.Key] = parameter.Value;
            }

            foreach (var operand in document.ConfigurationValues(
                         "PRAM",
                         source.Number,
                         configurationIndex))
            {
                if (operand.AuxiliaryIndex >= 0 && TryParseDouble(operand.Value, out var value))
                {
                    configured.Parameters[operand.AuxiliaryIndex] = ScaleSurfaceParameter(
                        document,
                        configured.Type,
                        operand.AuxiliaryIndex,
                        value);
                }
            }

            return configured;
        }).ToArray();
    }

    private static int DetectActiveConfiguration(ZemaxDocument document)
    {
        // Plain sequential ZMX exports do not provide a reliable persisted UI-active
        // multi-configuration selection. Keep imports deterministic and explainable
        // by selecting configuration 1 instead of guessing from operand values.
        return 0;
    }

    private static IReadOnlyList<ConvertedSurface> ConvertSurfaces(
        Optic optic,
        IReadOnlyList<ZemaxSurface> sourceSurfaces,
        IReadOnlyList<string> glassCatalogs)
    {
        var result = new List<ConvertedSurface>();
        var origin = Vector3D.Zero;
        var rotation = Matrix3x3.Identity;
        IMaterial previousMaterial = optic.Materials.Resolve("Air");

        foreach (var source in sourceSurfaces)
        {
            if (source.Type == "COORDBRK")
            {
                ApplyCoordinateBreak(source, ref origin, ref rotation);
                continue;
            }

            var index = result.Count;
            var surfaceOrigin = index == 0
                ? ObjectSurfaceOrigin(source.Thickness)
                : origin;
            var coordinate = CoordinateFrom(surfaceOrigin, rotation);
            var geometry = CreateGeometry(source);
            var isReflective = source.IsMirror || source.Material.Equals("MIRROR", StringComparison.OrdinalIgnoreCase);
            IMaterial materialAfter;
            if (isReflective)
            {
                materialAfter = previousMaterial.Clone();
            }
            else
            {
                materialAfter = ResolveGlass(optic, source, glassCatalogs);
            }

            var legacyRadius = double.IsInfinity(source.Radius) ? 0 : source.Radius;
            var thickness = source.Thickness;
            var semiDiameter = source.SemiDiameter is { } configuredSemiDiameter
                && double.IsFinite(configuredSemiDiameter)
                    ? Math.Max(0.1, Math.Abs(configuredSemiDiameter))
                    : 10;
            var physicalAperture = CreatePhysicalAperture(source, semiDiameter);
            var surface = new OpticalSurface
            {
                Number = index,
                ThermalExpansionPpmPerC = null,
                Label = SurfaceLabel(source, index, sourceSurfaces),
                Radius = legacyRadius,
                Thickness = thickness,
                Material = isReflective ? "MIRROR" : materialAfter.Name,
                SemiDiameter = semiDiameter,
                MechanicalSemiDiameterSolveCode = source.MechanicalSemiDiameterSolveCode,
                SemiDiameterFixed = source.SemiDiameterFixed,
                Conic = source.Conic,
                IsStop = source.IsStop,
                IsReflective = isReflective,
                Geometry = geometry,
                MaterialBefore = previousMaterial.Clone(),
                MaterialAfter = materialAfter.Clone(),
                InteractionModel = new RefractiveReflectiveInteractionModel(isReflective),
                PhysicalAperture = physicalAperture,
                SemiDiameterDefinesPhysicalAperture = physicalAperture is CircularAperture
                    && !source.IsStop
                    && (source.MinimumAperture is null
                        || !double.IsFinite(source.MinimumAperture.Value)
                        || Math.Abs(source.MinimumAperture.Value) <= 1e-12)
                    && source.SemiDiameterFixed
                    && HasSurfacePower(source),
                CoordinateSystem = coordinate
            };
            if (source.MechanicalSemiDiameter is { } mechanicalSemiDiameter)
                surface.MechanicalSemiDiameter = mechanicalSemiDiameter;
            result.Add(new ConvertedSurface(
                index,
                surface,
                geometry,
                previousMaterial.Clone(),
                materialAfter.Clone(),
                isReflective,
                coordinate));

            previousMaterial = materialAfter.Clone();
            if (index == 0)
            {
                origin = Vector3D.Zero;
                rotation = Matrix3x3.Identity;
            }
            else if (!double.IsInfinity(source.Thickness))
            {
                origin += rotation.Transform(new Vector3D(0, 0, source.Thickness));
            }
        }

        return result;
    }

    private static IPhysicalAperture? CreatePhysicalAperture(ZemaxSurface source, double semiDiameter)
    {
        if (source.MinimumAperture is { } minimumAperture
            && double.IsFinite(minimumAperture)
            && Math.Abs(minimumAperture) > 1e-12)
        {
            return new AnnularAperture(semiDiameter, Math.Abs(minimumAperture));
        }

        // Automatic DIAM is a ray-footprint estimate, including at the stop;
        // it must not become a physical clipping boundary. A user-defined stop
        // or powered-surface DIAM defines a circular aperture. MEMA only describes
        // the part edge and is deliberately excluded.
        if (source.SemiDiameterFixed && (source.IsStop || HasSurfacePower(source)))
        {
            return new CircularAperture(semiDiameter);
        }

        return null;
    }

    private static bool HasSurfacePower(ZemaxSurface surface) =>
        (double.IsFinite(surface.Radius) && Math.Abs(surface.Radius) > 1e-12)
        || (surface.Type.Equals("TOROIDAL", StringComparison.OrdinalIgnoreCase)
            && double.IsFinite(surface.Parameter(1))
            && Math.Abs(surface.Parameter(1)) > 1e-12);

    private static void ApplyCoordinateBreak(
        ZemaxSurface source,
        ref Vector3D origin,
        ref Matrix3x3 rotation)
    {
        if (Math.Abs(source.Parameter(5)) > 1e-12)
        {
            throw new NotSupportedException(
                $"Zemax coordinate-break order flags are not supported (SURF {source.Number}, PARM 6).");
        }

        var decenter = new Vector3D(source.Parameter(0), source.Parameter(1), 0);
        origin += rotation.Transform(decenter);
        rotation *= RotationMatrix(source.Parameter(2), source.Parameter(3), source.Parameter(4));
        if (!double.IsInfinity(source.Thickness))
        {
            origin += rotation.Transform(new Vector3D(0, 0, source.Thickness));
        }
    }

    private static IGeometry CreateGeometry(ZemaxSurface surface)
    {
        var radius = double.IsInfinity(surface.Radius) ? 0 : surface.Radius;
        return surface.Type switch
        {
            "STANDARD" => Math.Abs(radius) < 1e-15
                ? new PlaneGeometry()
                : new StandardGeometry(radius, surface.Conic),
            "EVENASPH" => new EvenAsphereGeometry(
                radius,
                surface.Conic,
                Enumerable.Range(0, 8).Select(surface.Parameter).ToArray()),
            "ODDASPHE" => new OddAsphereGeometry(
                radius,
                surface.Conic,
                Enumerable.Range(0, 8).Select(surface.Parameter).ToArray()),
            "TOROIDAL" => CreateToroidalGeometry(surface),
            _ => CreateOpaqueZemaxGeometry(surface)
        };
    }

    private static IGeometry CreateOpaqueZemaxGeometry(ZemaxSurface surface)
    {
        var numbers = new Dictionary<string, double>(StringComparer.Ordinal)
        {
            ["radius"] = surface.Radius,
            ["conic"] = surface.Conic
        };
        foreach (var parameter in surface.Parameters.OrderBy(item => item.Key))
        {
            numbers[$"parm{parameter.Key + 1}"] = parameter.Value;
        }

        var text = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["zemax.type"] = surface.Type,
            ["opticalsystemdesign.blockingReason"] =
                $"Zemax 面型 TYPE {surface.Type} 尚未映射到可计算几何；原始曲率、圆锥常数和 PARM 参数已保留为只读数据。"
        };
        return new OpaqueGeometryPayload(new ComponentSnapshot($"Zemax TYPE {surface.Type}", numbers, text));
    }

    private static IGeometry CreateToroidalGeometry(ZemaxSurface surface)
    {
        if (Math.Abs(surface.Conic) > 1e-14
            || Enumerable.Range(2, 6).Any(index => Math.Abs(surface.Parameter(index)) > 1e-14))
        {
            throw new NotSupportedException(
                $"Zemax toroidal conic or polynomial terms are not supported (SURF {surface.Number}).");
        }

        var radiusY = double.IsInfinity(surface.Radius) ? 0 : surface.Radius;
        var radiusX = Math.Abs(surface.Parameter(1)) < 1e-15
            ? double.PositiveInfinity
            : surface.Parameter(1);
        return new ToroidalGeometry(radiusY, radiusX);
    }

    private static void ConfigureAperture(
        Optic optic,
        ZemaxDocument document,
        int configurationIndex)
    {
        if (document.FloatingStop)
        {
            var stop = optic.SurfaceGroup.Items.FirstOrDefault(surface => surface.IsStop)
                ?? throw new InvalidDataException("FLOA requires a Zemax STOP surface.");
            optic.Aperture.Kind = ApertureKind.FloatByStopSize;
            optic.Aperture.Value = stop.SemiDiameter;
            return;
        }

        var aperture = document.Apertures[0];
        optic.Aperture.Kind = aperture.Kind;
        var configuredValue = document.ConfigurationDouble("APER", 0, configurationIndex);
        optic.Aperture.Value = configuredValue.HasValue
            ? ScaleApertureValue(document, aperture.Kind, configuredValue.Value)
            : aperture.Value;
    }

    private static void ConfigureFields(
        Optic optic,
        ZemaxDocument document,
        int configurationIndex)
    {
        optic.FieldDefinition = document.FieldType switch
        {
            0 => FieldDefinitionKind.Angle,
            1 => FieldDefinitionKind.ObjectHeight,
            2 => FieldDefinitionKind.ParaxialImageHeight,
            3 => FieldDefinitionKind.RealImageHeight,
            4 => throw new NotSupportedException("Zemax theodolite-angle fields are not supported."),
            _ => FieldDefinitionKind.Angle
        };
        optic.ObjectSpaceTelecentric = document.ObjectSpaceTelecentric;

        var count = Math.Max(document.FieldCount, Math.Max(document.FieldX.Count, document.FieldY.Count));
        if (count == 0)
        {
            optic.Fields.Add(new FieldPoint { Label = "On axis", Weight = 1 });
            return;
        }

        var fields = Enumerable.Range(0, count)
            .Select(index => new ParsedField(
                ScaleFieldValue(
                    document,
                    document.ConfigurationDouble("XFIE", index + 1, configurationIndex)
                        ?? ValueAt(document.FieldX, index)),
                ScaleFieldValue(
                    document,
                    document.ConfigurationDouble("YFIE", index + 1, configurationIndex)
                        ?? ValueAt(document.FieldY, index)),
                ValueAt(document.FieldWeights, index, 1),
                ValueAt(document.VignetteX, index),
                ValueAt(document.VignetteY, index),
                ValueAt(document.VignetteDecenterX, index),
                ValueAt(document.VignetteDecenterY, index),
                ValueAt(document.VignetteAngle, index),
                document.FieldComments.GetValueOrDefault(index + 1, string.Empty)))
            .ToArray();

        for (var index = 0; index < fields.Length; index++)
        {
            var field = fields[index];
            optic.Fields.Add(new FieldPoint
            {
                Label = !string.IsNullOrWhiteSpace(field.Label)
                    ? field.Label
                    : Math.Abs(field.X) < 1e-14 && Math.Abs(field.Y) < 1e-14
                        ? "On axis"
                        : $"Field {index + 1}",
                X = field.X,
                Y = field.Y,
                Weight = field.Weight,
                VignetteFactorX = field.VignetteX,
                VignetteFactorY = field.VignetteY,
                VignetteDecenterX = field.VignetteDecenterX,
                VignetteDecenterY = field.VignetteDecenterY,
                VignetteAngleDegrees = field.VignetteAngle
            });
        }
    }

    private static void ConfigureWavelengths(
        Optic optic,
        ZemaxDocument document,
        int configurationIndex)
    {
        var wavelengths = document.Wavelengths
            .OrderBy(wavelength => wavelength.Index)
            .Take(document.WavelengthCount > 0 ? document.WavelengthCount : int.MaxValue)
            .ToArray();
        if (wavelengths.Length == 0)
        {
            optic.Wavelengths.Add(new Wavelength
            {
                Label = "d",
                Nanometers = 587.5618,
                Weight = 1,
                IsPrimary = true
            });
            return;
        }

        var primary = document.PrimaryWavelengthIndex;
        if (primary < 0 || primary >= wavelengths.Length)
        {
            primary = 0;
        }

        for (var index = 0; index < wavelengths.Length; index++)
        {
            var wavelengthNumber = wavelengths[index].Index + 1;
            optic.Wavelengths.Add(new Wavelength
            {
                Label = $"W{index + 1}",
                Nanometers = (document.ConfigurationDouble(
                    "WAVE",
                    wavelengthNumber,
                    configurationIndex) ?? wavelengths[index].Micrometers) * 1000.0,
                Weight = document.ConfigurationDouble(
                    "WLWT",
                    wavelengthNumber,
                    configurationIndex) ?? wavelengths[index].Weight,
                IsPrimary = index == primary
            });
        }
    }

    private static void ApplyThicknessSolves(
        Optic optic,
        IReadOnlyList<ZemaxSurface> configuredSurfaces,
        IReadOnlyList<string> glassCatalogs)
    {
        var physicalSurfaces = configuredSurfaces
            .Where(surface => surface.Type != "COORDBRK")
            .ToArray();
        var wavelength = (optic.Wavelengths.FirstOrDefault(item => item.IsPrimary)
            ?? optic.Wavelengths.FirstOrDefault())?.Micrometers ?? 0.5875618;

        for (var surfaceIndex = 0; surfaceIndex < physicalSurfaces.Length - 1; surfaceIndex++)
        {
            var source = physicalSurfaces[surfaceIndex];
            var solve = source.MarginalRayHeightSolve;
            if (solve is null)
            {
                continue;
            }

            double height;
            double slope;
            if (Math.Abs(solve.PupilZone) <= 1e-15)
            {
                var marginal = optic.Paraxial.MarginalRay(wavelength);
                height = marginal.Heights[surfaceIndex][0];
                slope = marginal.Slopes[surfaceIndex][0];
            }
            else
            {
                var bundle = optic.SequentialRayTracer.RayGenerator.GenerateGeneric(
                    0,
                    0,
                    0,
                    solve.PupilZone,
                    wavelength,
                    aimAtStop: true);
                var history = optic.SequentialRayTracer.Trace(bundle).RayHistories.Single();
                if (surfaceIndex >= history.Count)
                {
                    throw new InvalidDataException(
                        $"Zemax MAZH solve on surface {source.Number} could not trace its pupil-zone ray.");
                }

                var sample = history[surfaceIndex];
                var localPosition = optic.SurfaceGroup.Items[surfaceIndex]
                    .CoordinateSystem.ToLocalPoint(sample.Position);
                var localDirection = optic.SurfaceGroup.Items[surfaceIndex]
                    .CoordinateSystem.ToLocalDirection(sample.Direction);
                height = localPosition.Y;
                slope = localDirection.Y / Math.Max(1e-30, localDirection.Z);
            }

            if (!double.IsFinite(slope) || Math.Abs(slope) <= 1e-15)
            {
                throw new InvalidDataException(
                    $"Zemax MAZH solve on surface {source.Number} has zero marginal-ray slope.");
            }

            var solvedThickness = (solve.Height - height) / slope;
            if (!double.IsFinite(solvedThickness))
            {
                throw new InvalidDataException(
                    $"Zemax MAZH solve on surface {source.Number} produced a non-finite thickness.");
            }

            source.Thickness = solvedThickness;
            var converted = ConvertSurfaces(optic, configuredSurfaces, glassCatalogs);
            InstallConvertedSurfaces(optic, converted);
        }
    }

    private static void ConfigureMeritFunction(Optic optic, ZemaxDocument document)
    {
        optic.MeritFunctionOperands.Clear();
        foreach (var operand in document.MeritOperands)
        {
            var imported = operand.Clone();
            var centroidSurface = imported.Type is "CENX" or "CENY" or "CNPX" or "CNPY" or "CNAX" or "CNAY";
            if ((centroidSurface && imported.Surface != 0)
                || imported.Type is "GLCX" or "GLCY" or "GLCZ" or "GLCA" or "GLCB" or "GLCC" or "GLCR"
                or "RAGX" or "RAGY" or "RAGZ" or "RAGA" or "RAGB" or "RAGC")
            {
                // Coordinate breaks are folded into physical frames by the importer.
                // Remap active surface references together with GLRS, never use shifted source numbering.
                var numbers = document.Surfaces.Where(s => !s.Type.Equals("COORDBRK", StringComparison.OrdinalIgnoreCase))
                    .Select(s => s.Number).ToArray();
                imported.Surface = Array.IndexOf(numbers, imported.Surface);
                if (imported.Surface < 0)
                    throw new NotSupportedException($"{imported.Type} 指向不存在或已折叠的坐标断点面，当前尚未支持该参考。");
                if (imported.ZemaxIntegerParameters.Length > 0) imported.ZemaxIntegerParameters[0] = imported.Surface;
            }
            optic.MeritFunctionOperands.Add(imported);
        }
    }

    private static void ReadPupilRayMeritOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        document.MeritOperands.Add(new MeritOperandDefinition
        {
            Type = command,
            Surface = RequiredInt(tokens, 1, command),
            Wavelength = RequiredInt(tokens, 2, command),
            Hx = RequiredDouble(tokens, 3, command),
            Hy = RequiredDouble(tokens, 4, command),
            Px = RequiredDouble(tokens, 5, command),
            Py = RequiredDouble(tokens, 6, command),
            Target = RequiredDouble(tokens, 7, command),
            Weight = RequiredDouble(tokens, 8, command),
            ZemaxIntegerParameters = ReadZemaxIntegerParameters(tokens, command),
            ZemaxDataParameters = ReadZemaxDataParameters(tokens, command)
        });
    }

    private static void ReadStandardMeritOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        var operand = new MeritOperandDefinition
        {
            Type = command,
            Surface = RequiredInt(tokens, 1, command),
            Wavelength = RequiredInt(tokens, 2, command),
            Field = RequiredInt(tokens, 3, command),
            Target = RequiredDouble(tokens, 7, command),
            Weight = RequiredDouble(tokens, 8, command),
            ZemaxIntegerParameters = ReadZemaxIntegerParameters(tokens, command),
            ZemaxDataParameters = ReadZemaxDataParameters(tokens, command)
        };
        if (command is "SFNO" or "TFNO") operand.Field = RequiredInt(tokens, 1, command);
        if (command is "MECS" or "MECT")
        {
            operand.SpatialFrequency = RequiredDouble(tokens, 4, command);
            operand.Px = RequiredDouble(tokens, 5, command);
            operand.Py = RequiredDouble(tokens, 6, command);
        }

        document.MeritOperands.Add(operand);
    }

    private static void ReadRmsSpotMeritOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        document.MeritOperands.Add(new MeritOperandDefinition
        {
            Type = command,
            PupilRings = Math.Max(1, RequiredInt(tokens, 1, command)),
            Wavelength = RequiredInt(tokens, 2, command),
            Hx = RequiredDouble(tokens, 3, command),
            Hy = RequiredDouble(tokens, 4, command),
            Target = RequiredDouble(tokens, 7, command),
            Weight = RequiredDouble(tokens, 8, command),
            ZemaxIntegerParameters = ReadZemaxIntegerParameters(tokens, command),
            ZemaxDataParameters = ReadZemaxDataParameters(tokens, command)
        });
    }

    private static void ReadRangeThicknessMeritOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        document.MeritOperands.Add(new MeritOperandDefinition
        {
            Type = command,
            Surface = RequiredInt(tokens, 1, command),
            Wavelength = RequiredInt(tokens, 2, command),
            Hx = RequiredDouble(tokens, 3, command),
            Hy = RequiredDouble(tokens, 4, command),
            Px = RequiredDouble(tokens, 5, command),
            Py = RequiredDouble(tokens, 6, command),
            Target = RequiredDouble(tokens, 7, command),
            Weight = RequiredDouble(tokens, 8, command),
            ZemaxIntegerParameters = ReadZemaxIntegerParameters(tokens, command),
            ZemaxDataParameters = ReadZemaxDataParameters(tokens, command)
        });
    }

    private static void ReadSystemMeritOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        document.MeritOperands.Add(new MeritOperandDefinition
        {
            Type = command,
            Surface = RequiredInt(tokens, 1, command),
            Wavelength = RequiredInt(tokens, 2, command),
            Hx = RequiredDouble(tokens, 3, command),
            Hy = RequiredDouble(tokens, 4, command),
            Px = RequiredDouble(tokens, 5, command),
            Py = RequiredDouble(tokens, 6, command),
            Target = RequiredDouble(tokens, 7, command),
            Weight = RequiredDouble(tokens, 8, command),
            ZemaxIntegerParameters = ReadZemaxIntegerParameters(tokens, command),
            ZemaxDataParameters = ReadZemaxDataParameters(tokens, command)
        });
    }

    private static void ReadMathMeritOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        document.MeritOperands.Add(new MeritOperandDefinition
        {
            Type = command,
            Surface = RequiredInt(tokens, 1, command),
            Wavelength = RequiredInt(tokens, 2, command),
            Hx = RequiredDouble(tokens, 3, command),
            Hy = RequiredDouble(tokens, 4, command),
            Px = RequiredDouble(tokens, 5, command),
            Py = RequiredDouble(tokens, 6, command),
            Target = RequiredDouble(tokens, 7, command),
            Weight = RequiredDouble(tokens, 8, command),
            ZemaxIntegerParameters = ReadZemaxIntegerParameters(tokens, command),
            ZemaxDataParameters = ReadZemaxDataParameters(tokens, command)
        });
    }

    private static void ReadSurfaceBoundaryMeritOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        document.MeritOperands.Add(new MeritOperandDefinition
        {
            Type = command,
            Surface = RequiredInt(tokens, 1, command),
            Wavelength = RequiredInt(tokens, 2, command),
            Hx = RequiredDouble(tokens, 3, command),
            Hy = RequiredDouble(tokens, 4, command),
            Px = RequiredDouble(tokens, 5, command),
            Py = RequiredDouble(tokens, 6, command),
            Target = RequiredDouble(tokens, 7, command),
            Weight = RequiredDouble(tokens, 8, command),
            ZemaxIntegerParameters = ReadZemaxIntegerParameters(tokens, command),
            ZemaxDataParameters = ReadZemaxDataParameters(tokens, command)
        });
    }

    private static void ReadPreservedMeritOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        document.MeritOperands.Add(new MeritOperandDefinition
        {
            Enabled = false,
            CompatibilityOnly = true,
            Type = command,
            Surface = RequiredInt(tokens, 1, command),
            Wavelength = RequiredInt(tokens, 2, command),
            Hx = RequiredDouble(tokens, 3, command),
            Hy = RequiredDouble(tokens, 4, command),
            Px = RequiredDouble(tokens, 5, command),
            Py = RequiredDouble(tokens, 6, command),
            Target = RequiredDouble(tokens, 7, command),
            Weight = RequiredDouble(tokens, 8, command),
            Comment = $"Zemax 只读记录：{string.Join(" ", tokens.Skip(1))}",
            ZemaxIntegerParameters = ReadZemaxIntegerParameters(tokens, command),
            ZemaxDataParameters = ReadZemaxDataParameters(tokens, command)
        });
    }

    private static int[] ReadZemaxIntegerParameters(
        IReadOnlyList<string> tokens,
        string command) =>
    [
        RequiredInt(tokens, 1, command),
        RequiredInt(tokens, 2, command)
    ];

    private static double[] ReadZemaxDataParameters(
        IReadOnlyList<string> tokens,
        string command) =>
    [
        RequiredDouble(tokens, 3, command),
        RequiredDouble(tokens, 4, command),
        RequiredDouble(tokens, 5, command),
        RequiredDouble(tokens, 6, command)
    ];

    private static void ReadFieldComment(
        ZemaxDocument document,
        string line,
        IReadOnlyList<string> tokens)
    {
        var index = RequiredInt(tokens, 1, "FCOM");
        if (index <= 0)
        {
            throw new InvalidDataException("Zemax FCOM indices are one-based positive integers.");
        }

        var commentStart = line.IndexOf(tokens[1], StringComparison.Ordinal) + tokens[1].Length;
        var comment = commentStart < line.Length
            ? line[commentStart..].Trim().Trim('"')
            : string.Empty;
        document.FieldComments[index] = comment;
    }

    private static double RadiusFromConfiguredCurvature(
        ZemaxDocument document,
        double? curvature,
        double fallbackRadius)
    {
        if (!curvature.HasValue)
        {
            return fallbackRadius;
        }

        return RadiusFromCurvature(curvature.Value, document.LengthScaleToMillimeters);
    }

    private static void ReadConfigurationOperand(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        string command)
    {
        var target = RequiredInt(tokens, 1, command);
        var configurationIndex = RequiredInt(tokens, 2, command) - 1;
        if (configurationIndex < 0)
        {
            throw new InvalidDataException($"Zemax {command} configuration indices are one-based positive integers.");
        }

        var value = RequiredToken(tokens, 3, command).Trim('"');
        var auxiliaryIndex = command.Equals("PRAM", StringComparison.OrdinalIgnoreCase)
            && tokens.Count > 5
            ? RequiredInt(tokens, 5, command) - 1
            : -1;
        var requiredConfigurationCount = CheckedConfigurationCount(
            configurationIndex + 1,
            command);
        document.ConfigurationOperands.Add(new ZemaxConfigurationOperand(
            command,
            target,
            configurationIndex,
            value,
            auxiliaryIndex));
        document.ConfigurationCount = Math.Max(document.ConfigurationCount, requiredConfigurationCount);
    }

    private static int CheckedConfigurationCount(int count, string command)
    {
        if (count < 1)
        {
            return 1;
        }

        if (count > StarOptProjectStore.MaximumConfigurationCount)
        {
            throw new InvalidDataException(
                $"Zemax {command} declares {count} configurations, which exceeds the supported limit "
                + $"of {StarOptProjectStore.MaximumConfigurationCount}.");
        }

        return count;
    }

    private static void ReadUnit(ZemaxDocument document, IReadOnlyList<string> tokens)
    {
        var unit = RequiredToken(tokens, 1, "UNIT").Trim().Trim('"').ToUpperInvariant();
        document.UnitName = unit;
        document.LengthScaleToMillimeters = unit switch
        {
            "MM" or "MILLIMETER" or "MILLIMETERS" => 1.0,
            "CM" or "CENTIMETER" or "CENTIMETERS" => 10.0,
            "M" or "METER" or "METERS" => 1000.0,
            "IN" or "INCH" or "INCHES" => 25.4,
            "UM" or "MICRON" or "MICRONS" or "MICROMETER" or "MICROMETERS" => 0.001,
            "NM" or "NANOMETER" or "NANOMETERS" => 0.000001,
            _ => throw new InvalidDataException($"Zemax UNIT '{unit}' is not supported.")
        };
    }

    private static void ReadFNumber(ZemaxDocument document, IReadOnlyList<string> tokens)
    {
        var subtype = RequiredInt(tokens, 2, "FNUM");
        if (subtype != 0)
        {
            throw new NotSupportedException("Zemax paraxial-image F-number (FNUM subtype 1) is not supported.");
        }

        document.UpsertAperture("imageFNO", ApertureKind.FNumber, RequiredDouble(tokens, 1, "FNUM"));
    }

    private static void ReadObjectNumericalAperture(ZemaxDocument document, IReadOnlyList<string> tokens)
    {
        var subtype = RequiredInt(tokens, 2, "OBNA");
        if (subtype != 0)
        {
            throw new NotSupportedException("Zemax object-cone-angle apertures (OBNA subtype 1) are not supported.");
        }

        document.UpsertAperture("objectNA", ApertureKind.NumericalAperture, RequiredDouble(tokens, 1, "OBNA"));
    }

    private static void ReadConfiguration(ZemaxDocument document, IReadOnlyList<string> tokens)
    {
        document.FieldType = RequiredInt(tokens, 1, "FTYP");
        document.ObjectSpaceTelecentric = RequiredInt(tokens, 2, "FTYP") == 1;
        document.FieldCount = RequiredInt(tokens, 3, "FTYP");
        document.WavelengthCount = RequiredInt(tokens, 4, "FTYP");
        document.AfocalImageSpace = tokens.Count > 7 && RequiredInt(tokens, 7, "FTYP") == 1;
    }

    private static void ReadWavelength(ZemaxDocument document, IReadOnlyList<string> tokens)
    {
        var index = RequiredInt(tokens, 1, "WAVM") - 1;
        if (index < 0)
        {
            throw new InvalidDataException("Zemax WAVM indices are one-based positive integers.");
        }

        var wavelength = new ZemaxWavelength(
            index,
            RequiredDouble(tokens, 2, "WAVM"),
            tokens.Count > 3 ? RequiredDouble(tokens, 3, "WAVM") : 1);
        var existing = document.Wavelengths.FindIndex(item => item.Index == index);
        if (existing >= 0)
        {
            document.Wavelengths[existing] = wavelength;
        }
        else
        {
            document.Wavelengths.Add(wavelength);
        }
    }

    private static void ReadGlass(ZemaxSurface surface, IReadOnlyList<string> tokens)
    {
        surface.Material = RequiredToken(tokens, 1, "GLAS");
        surface.IsMirror = surface.Material.Equals("MIRROR", StringComparison.OrdinalIgnoreCase);
        if (tokens.Count > 5
            && TryParseDouble(tokens[4], out var index)
            && TryParseDouble(tokens[5], out var abbe))
        {
            surface.RefractiveIndex = index;
            surface.AbbeNumber = abbe;
        }
    }

    private static void ReadSemiDiameter(
        ZemaxDocument document,
        ZemaxSurface surface,
        IReadOnlyList<string> tokens)
    {
        surface.SemiDiameter = Math.Abs(ScaleLength(document, RequiredDouble(tokens, 1, "DIAM")));
        var solveCode = tokens.Count > 2
            ? RequiredInt(tokens, 2, "DIAM")
            : 0;

        // OpticStudio solve codes: 0 = automatic, 1 = user defined, 2 = pickup.
        surface.SemiDiameterSolveCode = solveCode;
        surface.SemiDiameterFixed = solveCode != 0;
        if (solveCode == 2)
        {
            surface.SemiDiameterPickupSource = tokens.Count > 3 ? RequiredInt(tokens, 3, "DIAM") : 0;
            surface.SemiDiameterPickupScale = tokens.Count > 5 ? RequiredDouble(tokens, 5, "DIAM") : 1;
        }
    }

    private static void ReadMechanicalSemiDiameter(
        ZemaxDocument document,
        ZemaxSurface surface,
        IReadOnlyList<string> tokens)
    {
        surface.MechanicalSemiDiameter = Math.Abs(
            ScaleLength(document, RequiredDouble(tokens, 1, "MEMA")));
        surface.MechanicalSemiDiameterSolveCode = tokens.Count > 2
            ? RequiredInt(tokens, 2, "MEMA")
            : 0;
    }

    private static IMaterial ResolveGlass(
        Optic optic,
        ZemaxSurface surface,
        IReadOnlyList<string> glassCatalogs)
    {
        var material = NormalizeMaterial(surface.Material);
        if (optic.Materials.TryResolveExternalGlass(material, glassCatalogs, out var externalGlass))
        {
            return externalGlass;
        }

        if (optic.Materials.TryResolve(material, glassCatalogs, out var resolved))
        {
            return resolved;
        }

        // CORNING3 uses the compact C7980 name; the bundled catalog stores
        // Corning 7980 as C79-80. This is an explicit catalog alias, not an nd/Vd approximation.
        if (material.Equals("C7980", StringComparison.OrdinalIgnoreCase)
            && glassCatalogs.Any(catalog => Path.GetFileNameWithoutExtension(catalog)
                .Equals("CORNING3", StringComparison.OrdinalIgnoreCase))
            && optic.Materials.TryResolve("C79-80", glassCatalogs, out var corning7980))
        {
            return corning7980;
        }

        var unresolved = new UnresolvedMaterial(material, string.Join(", ", glassCatalogs));
        optic.Materials.Register(unresolved);
        return unresolved;
    }

    private static ZemaxSurface RequireSurface(ZemaxSurface? surface, string command)
    {
        return surface ?? throw new InvalidDataException($"Zemax {command} appears before the first SURF record.");
    }

    private static string RequiredToken(IReadOnlyList<string> tokens, int index, string command)
    {
        return index < tokens.Count
            ? tokens[index]
            : throw new InvalidDataException($"Zemax {command} is missing operand {index}.");
    }

    private static int RequiredInt(IReadOnlyList<string> tokens, int index, string command)
    {
        var token = RequiredToken(tokens, index, command);
        return int.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value)
            ? value
            : throw new InvalidDataException($"Zemax {command} value '{token}' is not an integer.");
    }

    private static double RequiredDouble(IReadOnlyList<string> tokens, int index, string command)
    {
        var token = RequiredToken(tokens, index, command);
        return TryParseDouble(token, out var value)
            ? value
            : throw new InvalidDataException($"Zemax {command} value '{token}' is not numeric.");
    }

    private static double RequiredDistance(
        ZemaxDocument document,
        IReadOnlyList<string> tokens,
        int index,
        string command)
    {
        var token = RequiredToken(tokens, index, command);
        return token.Equals("INFINITY", StringComparison.OrdinalIgnoreCase)
            ? double.PositiveInfinity
            : ScaleLength(document, RequiredDouble(tokens, index, command));
    }

    private static double ScaleConfiguredDistance(
        ZemaxDocument document,
        double? configuredValue,
        double fallback) =>
        configuredValue.HasValue ? ScaleDistance(document, configuredValue.Value) : fallback;

    private static double? ScaleConfiguredOptionalLength(
        ZemaxDocument document,
        double? configuredValue,
        double? fallback) =>
        configuredValue.HasValue ? ScaleLength(document, configuredValue.Value) : fallback;

    private static double? ScaleConfiguredLength(
        ZemaxDocument document,
        double? configuredValue,
        double? fallback) =>
        configuredValue.HasValue ? ScaleLength(document, configuredValue.Value) : fallback;

    private static double ScaleDistance(ZemaxDocument document, double value) =>
        double.IsInfinity(value) ? value : ScaleLength(document, value);

    private static double ScaleLength(ZemaxDocument document, double value) =>
        value * document.LengthScaleToMillimeters;

    private static double ScaleFieldValue(ZemaxDocument document, double value) =>
        document.FieldType is 1 or 2 or 3 ? ScaleLength(document, value) : value;

    private static double ScaleApertureValue(
        ZemaxDocument document,
        ApertureKind kind,
        double value) =>
        kind == ApertureKind.EntrancePupilDiameter ? ScaleLength(document, value) : value;

    private static double ScaleSurfaceParameter(
        ZemaxDocument document,
        string type,
        int zeroBasedIndex,
        double value)
    {
        var scale = document.LengthScaleToMillimeters;
        if (Math.Abs(scale - 1.0) <= 1e-15)
        {
            return value;
        }

        return type switch
        {
            "EVENASPH" => ScalePowerCoefficient(value, scale, 2 * (zeroBasedIndex + 1)),
            "ODDASPHE" => ScalePowerCoefficient(value, scale, zeroBasedIndex + 1),
            "TOROIDAL" when zeroBasedIndex == 1 => value * scale,
            "COORDBRK" when zeroBasedIndex is 0 or 1 => value * scale,
            _ => value
        };
    }

    private static double ScalePowerCoefficient(double coefficient, double lengthScale, int power) =>
        coefficient * Math.Pow(lengthScale, 1 - power);

    private static double RadiusFromCurvature(double curvature, double lengthScaleToMillimeters) =>
        Math.Abs(curvature) < 1e-15
            ? double.PositiveInfinity
            : lengthScaleToMillimeters / curvature;

    private static bool TryParseDouble(string token, out double value)
    {
        return double.TryParse(
            token.Replace(',', '.'),
            NumberStyles.Float,
            CultureInfo.InvariantCulture,
            out value);
    }

    private static List<double> ReadValues(IReadOnlyList<string> tokens, int start, int expectedCount)
    {
        var count = expectedCount > 0 ? Math.Min(expectedCount, tokens.Count - start) : tokens.Count - start;
        return Enumerable.Range(start, Math.Max(0, count))
            .Select(index => RequiredDouble(tokens, index, tokens[0]))
            .ToList();
    }

    private static double ValueAt(IReadOnlyList<double> values, int index, double fallback = 0)
    {
        return index < values.Count ? values[index] : fallback;
    }

    private static Vector3D ObjectSurfaceOrigin(double thickness)
    {
        return double.IsInfinity(thickness)
            ? Vector3D.Zero
            : new Vector3D(0, 0, -thickness);
    }

    private static string SurfaceLabel(ZemaxSurface surface, int index, IReadOnlyList<ZemaxSurface> source)
    {
        if (!string.IsNullOrWhiteSpace(surface.Comment))
        {
            return surface.Comment;
        }

        if (index == 0)
        {
            return "Object";
        }

        if (index == source.Count(item => item.Type != "COORDBRK") - 1)
        {
            return "Image";
        }

        return surface.IsStop ? "Aperture stop" : $"Surface {index}";
    }

    private static string NormalizeMaterial(string material)
    {
        return string.IsNullOrWhiteSpace(material)
            || material.Equals("AIR", StringComparison.OrdinalIgnoreCase)
            ? "Air"
            : material.Trim();
    }

    private static CoordinateSystem CoordinateFrom(Vector3D origin, Matrix3x3 rotation)
    {
        var (rx, ry, rz) = EulerDegrees(rotation);
        return new CoordinateSystem(origin, rx, ry, rz);
    }

    private static Matrix3x3 RotationMatrix(double rxDegrees, double ryDegrees, double rzDegrees)
    {
        var rx = rxDegrees * Math.PI / 180.0;
        var ry = ryDegrees * Math.PI / 180.0;
        var rz = rzDegrees * Math.PI / 180.0;
        var cx = Math.Cos(rx);
        var sx = Math.Sin(rx);
        var cy = Math.Cos(ry);
        var sy = Math.Sin(ry);
        var cz = Math.Cos(rz);
        var sz = Math.Sin(rz);
        var x = new Matrix3x3(1, 0, 0, 0, cx, -sx, 0, sx, cx);
        var y = new Matrix3x3(cy, 0, sy, 0, 1, 0, -sy, 0, cy);
        var z = new Matrix3x3(cz, -sz, 0, sz, cz, 0, 0, 0, 1);
        return z * y * x;
    }

    private static (double X, double Y, double Z) EulerDegrees(Matrix3x3 matrix)
    {
        var y = Math.Asin(Math.Clamp(-matrix.M31, -1, 1));
        double x;
        double z;
        if (Math.Abs(Math.Cos(y)) > 1e-10)
        {
            x = Math.Atan2(matrix.M32, matrix.M33);
            z = Math.Atan2(matrix.M21, matrix.M11);
        }
        else
        {
            x = 0;
            z = Math.Atan2(-matrix.M12, matrix.M22);
        }

        const double toDegrees = 180.0 / Math.PI;
        return (x * toDegrees, y * toDegrees, z * toDegrees);
    }

    private sealed class ZemaxDocument
    {
        public string Name { get; set; } = "Imported Zemax ZMX";
        public bool SequentialModeSeen { get; set; }
        public bool FloatingStop { get; set; }
        public ZemaxApodization? Apodization { get; set; }
        public string UnitName { get; set; } = "MM";
        public double LengthScaleToMillimeters { get; set; } = 1.0;
        public List<ZemaxAperture> Apertures { get; } = new();
        public int FieldType { get; set; }
        public int FieldCount { get; set; }
        public int WavelengthCount { get; set; }
        public bool ObjectSpaceTelecentric { get; set; }

        public bool RayAimingEnabled { get; set; }

        public int GlobalReferenceSurfaceNumber { get; set; } = 1;
        public bool AfocalImageSpace { get; set; }
        public List<double> FieldX { get; set; } = new();
        public List<double> FieldY { get; set; } = new();
        public List<double> FieldWeights { get; set; } = new();
        public List<double> VignetteX { get; set; } = new();
        public List<double> VignetteY { get; set; } = new();
        public List<double> VignetteDecenterX { get; set; } = new();
        public List<double> VignetteDecenterY { get; set; } = new();
        public List<double> VignetteAngle { get; set; } = new();
        public Dictionary<int, string> FieldComments { get; } = new();
        public int PrimaryWavelengthIndex { get; set; }
        public List<ZemaxWavelength> Wavelengths { get; } = new();
        public List<string> GlassCatalogs { get; } = new();
        public List<ZemaxSurface> Surfaces { get; } = new();
        public int ConfigurationCount { get; set; } = 1;
        public List<ZemaxConfigurationOperand> ConfigurationOperands { get; } = new();
        public List<MeritOperandDefinition> MeritOperands { get; } = new();

        public void UpsertAperture(string key, ApertureKind kind, double value)
        {
            var existing = Apertures.FindIndex(item => item.Key.Equals(key, StringComparison.OrdinalIgnoreCase));
            var aperture = new ZemaxAperture(key, kind, value);
            if (existing >= 0)
            {
                Apertures[existing] = aperture;
            }
            else
            {
                Apertures.Add(aperture);
            }
        }

        public double? ConfigurationDouble(string command, int target, int configurationIndex)
        {
            var operand = ConfigurationOperands.FindLast(item =>
                item.Command.Equals(command, StringComparison.OrdinalIgnoreCase)
                && item.Target == target
                && item.ConfigurationIndex == configurationIndex);
            return operand is not null && TryParseDouble(operand.Value, out var value)
                ? value
                : null;
        }

        public string? ConfigurationText(string command, int target, int configurationIndex)
        {
            return ConfigurationOperands.FindLast(item =>
                item.Command.Equals(command, StringComparison.OrdinalIgnoreCase)
                && item.Target == target
                && item.ConfigurationIndex == configurationIndex)?.Value;
        }

        public IEnumerable<ZemaxConfigurationOperand> ConfigurationValues(
            string command,
            int target,
            int configurationIndex)
        {
            return ConfigurationOperands.Where(item =>
                item.Command.Equals(command, StringComparison.OrdinalIgnoreCase)
                && item.Target == target
                && item.ConfigurationIndex == configurationIndex);
        }
    }

    private sealed class ZemaxSurface(int number)
    {
        public int Number { get; } = number;
        public string Type { get; set; } = "STANDARD";
        public string Comment { get; set; } = string.Empty;
        public double Radius { get; set; } = double.PositiveInfinity;
        public double Thickness { get; set; }
        public double Conic { get; set; }
        public string Material { get; set; } = "Air";
        public double? RefractiveIndex { get; set; }
        public double? AbbeNumber { get; set; }
        public double? SemiDiameter { get; set; }
        public double? MechanicalSemiDiameter { get; set; }
        public int MechanicalSemiDiameterSolveCode { get; set; }
        public double? MinimumAperture { get; set; }
        public bool SemiDiameterFixed { get; set; }
        public int SemiDiameterSolveCode { get; set; }
        public int SemiDiameterPickupSource { get; set; }
        public double SemiDiameterPickupScale { get; set; } = 1;
        public bool IsStop { get; set; }
        public bool IsMirror { get; set; }
        public ZemaxMarginalRayHeightSolve? MarginalRayHeightSolve { get; set; }
        public Dictionary<int, double> Parameters { get; } = new();

        public double Parameter(int index) => Parameters.GetValueOrDefault(index);
    }

    private sealed record ZemaxAperture(string Key, ApertureKind Kind, double Value);
    private sealed record ZemaxMarginalRayHeightSolve(double Height, double PupilZone);
    private sealed record ZemaxWavelength(int Index, double Micrometers, double Weight);
    private sealed record ZemaxConfigurationOperand(
        string Command,
        int Target,
        int ConfigurationIndex,
        string Value,
        int AuxiliaryIndex);
    private sealed record ParsedField(
        double X,
        double Y,
        double Weight,
        double VignetteX,
        double VignetteY,
        double VignetteDecenterX,
        double VignetteDecenterY,
        double VignetteAngle,
        string Label);
    private sealed record ConvertedSurface(
        int Index,
        OpticalSurface Surface,
        IGeometry Geometry,
        IMaterial MaterialBefore,
        IMaterial MaterialAfter,
        bool IsReflective,
        CoordinateSystem CoordinateSystem);
}
