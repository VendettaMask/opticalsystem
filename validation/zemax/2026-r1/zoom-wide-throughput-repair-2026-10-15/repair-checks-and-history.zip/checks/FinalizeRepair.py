import collections, datetime, hashlib, json, pathlib, re, subprocess, xml.etree.ElementTree as ET, zipfile

repo = pathlib.Path(__file__).resolve().parents[3]
checks = pathlib.Path(__file__).resolve().parent
run = repo/'artifacts/zemax-standard-samples/20261015/zoom-wide-accepted-v4'
before = repo/'artifacts/zemax-standard-samples/20261015/full-matrix-v1'
middle = repo/'artifacts/zemax-standard-samples/20261015/zoom-wide-repair-v2'
dest = repo/'validation/zemax/2026-r1/zoom-wide-throughput-repair-2026-10-15'
dest.mkdir(parents=True, exist_ok=True)
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rel(p): return p.relative_to(repo).as_posix()
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def trx(name):
    path=checks/'tests'/name
    root=ET.parse(path).getroot();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counts={k:int(v) for k,v in root.find('t:ResultSummary/t:Counters',ns).attrib.items()}
    assert counts['failed']==0 and counts['total']==counts['passed'] and counts.get('notExecuted',0)==0
    return dict(path=rel(path),sha256=sha(path),counts=counts)

a=read(run/'analysis-summary.json');rs=read(run/'ray-summary.json');items=read(run/'analysis-results.json');rays=read(run/'ray-results.json')
old=read(before/'analysis-results.json');oldr=read(before/'ray-results.json')
assert len(items)==868 and len(rays)==91 and len(a['lenses'])==26 and len(read(run/'models.json'))==28
assert all(s['originalUnchanged'] for s in read(run/'source-integrity.json'))
def key(x): return (x['lens'],x['configuration'],x['scope'],pathlib.Path(x['path']).name)
old_by={key(x):x for x in old};trans=collections.Counter();regress=[]
for x in items:
    prior=old_by[key(x)]['run']['conclusion'];current=x['run']['conclusion'];trans[prior+' -> '+current]+=1
    if prior=='Pass' and current!='Pass':regress.append(dict(id=pathlib.Path(x['path']).name,prior=prior,current=current))
assert not regress and trans['Pass -> Pass']==381
ray_by={x['id']:x for x in oldr};rtrans=collections.Counter((ray_by[x['id']]['conclusion']+' -> '+x['conclusion']) for x in rays)
assert rtrans['Pass -> Pass']==55
target=[x for x in rays if x['id'].startswith(('zoom-lens-','wide-angle-lens-'))]
assert len(target)==18 and all(x['conclusion']=='Pass' for x in target)
assert sum(x['inputs'] for x in target)==4536
assert all(x[k]==0 for x in target for k in ['acceptanceDifferences','firstClipDifferences','coordinateFailures','directionFailures'])
target_summary=dict(groups=18,inputs=4536,physicalSurfaceComparisons=sum(x['physicalSurfaceComparisons'] for x in target),
    maximumCoordinateMillimeters=max(x['maximumCoordinateMillimeters'] for x in target),maximumDirection=max(x['maximumDirection'] for x in target),
    acceptanceDifferences=0,firstClipDifferences=0,coordinateFailures=0,directionFailures=0)

native_jobs=read(run/'native-jobs.json');assert len(native_jobs)==758
native_codes=collections.Counter()
for job in native_jobs:
    out=pathlib.Path(job['output']);result=read(out/'batch-result.json');env=read(out/'environment.json')
    assert env['validLicense'] and env['major']==26 and env['minor']==1 and env['opticStudioVersion']==260127
    native_codes[str(result['exitCode'])]+=1
assert native_codes=={'0':757,'2':1}
assert len(read(run/'workbench-results.json'))==648
isolated=read(run/'isolated-controls.json');assert len(isolated)==4 and all(x['exactMatch'] and x['exitCode']==0 for x in isolated)
configs=[]
for x in items:
    if x['lens']!='Zoom systems/Zoom lens.zmx' or x['scope']!='primary' or x['run']['key']!='Spot Diagram':continue
    p=pathlib.Path(x['path'])/'native';settings=read(p/'captured-settings.json')['properties']
    assert settings['Configuration']==x['configuration']+1
    text=(p/'data.txt').read_text(encoding='utf-16');actual=re.search(r'结构\s+(\d+)\s+的\s+(\d+)',text)
    assert actual and int(actual[1])==x['configuration'] and int(actual[2])==3
    configs.append(dict(configuration=x['configuration'],analysisSelector=settings['Configuration'],textConfigurationLine=actual[0],
        nativeSpot=read(p/'data.json')['spot'],conclusion=x['run']['conclusion']))
assert len(configs)==3

curvature=read(checks/'curvature-illumination-accepted.json');cs=[dict(name=c['Name'],summary=c['Summary']) for c in curvature['Cases']]
fc=[g for c in cs for g in c['summary'] if g['Code'] in ['FCGS','FCGT']]
assert sum(g['Total'] for g in fc)==2160 and all(g['Status']=='Pass' for g in fc)
tests=dict(mainRelease=trx('full-accepted-release.trx'),relatedDebug=trx('related-accepted-debug.trx'),comparisonRelease=trx('comparison-accepted-release.trx'),
    initialStructureRelease=trx('initial-accepted-release.trx'),coatingDesignRelease=trx('coating-accepted-release.trx'))
angles=read(checks/'angle-mapping-audit.json');assert angles['propagationIsolation']['pass']
assert angles['allSameActualLaunchComparisonsPass'] is False
oldarchive=repo/'validation/zemax/2026-r1/standard-matrix-2026-10-15/native-and-core-evidence.zip'
assert sha(oldarchive)=='f9dec857670564c9a8319a801a2c928834fe51fa9eee7fb0dc6486804d66b771'
policy=repo/'validation/zemax/2026-r1/standard-matrix-2026-10-15/original-comparison-settings.json'
assert read(run/'comparison-settings.json')==read(policy)

changed=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()
code=[repo/p for p in changed if p.endswith(('.cs','.csproj'))]
code += [repo/p for p in ['tests/OpticalSystemDesign.Tests/ZoomWideAngleNativeParityTests.cs','tests/OpticalSystemDesign.ZemaxComparison.Tests/NativeConfigurationTests.cs','tools/OpticalSystemDesign.ZemaxComparison/ZemaxHost/NativeConfigurationSelector.cs']]
save(checks/'final-source-identities.json',[dict(path=rel(p),sha256=sha(p)) for p in sorted(set(code))])
diff=subprocess.check_output(['git','diff','--','src','tests','tools/OpticalSystemDesign.ZemaxComparison'],cwd=repo)
(checks/'product-and-tool-changes.diff').write_bytes(diff)
identity=read(run/'identity.json')
for asm in identity['assemblies']:
    assert sha(pathlib.Path(asm['path']))==asm['sha256']
save(dest/'before-after-summary.json',dict(analysisTransitions=dict(trans),rayTransitions=dict(rtrans),analysisPassRegressions=regress,target=target_summary))
for name in ['analysis-summary.json','analysis-matrix.csv','ray-summary.json','ray-results.json','source-integrity.json','isolated-controls.json','identity.json']:
    (dest/name).write_bytes((run/name).read_bytes())
save(dest/'curvature-illumination-summary.json',cs)
(dest/'angle-mapping-audit.json').write_bytes((checks/'angle-mapping-audit.json').read_bytes())

archive=dest/'native-and-core-evidence.zip';entries=[]
allowed={'.json','.txt','.log','.cfg','.zmx','.cs','.py','.ps1','.trx','.diff','.csv','.csproj'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    candidates=[]
    for prefix,folder in [('run',run),('checks',checks)]:
        for p in folder.rglob('*'):
            if p.is_file() and p.suffix.lower() in allowed and not any(part in {'bin','obj','testbin','__pycache__'} for part in p.relative_to(folder).parts):
                candidates.append((prefix+'/'+p.relative_to(folder).as_posix(),p))
    # Preserve the intermediate wrong-configuration controls, without duplicating
    # all unrelated intermediate captures in the final evidence bundle.
    for p in middle.glob('*.json'):candidates.append(('intermediate-v2/'+p.name,p))
    for folder in (middle/'analyses').glob('*zoom-lens*'):
        for p in folder.rglob('*'):
            if p.is_file() and p.suffix.lower() in allowed:candidates.append(('intermediate-v2/'+p.relative_to(middle).as_posix(),p))
    for arc,p in sorted(candidates):
        z.write(p,arc);entries.append(dict(path=arc,sha256=sha(p),bytes=p.stat().st_size))
    z.writestr('exact-byte-ledger.json',json.dumps(entries,ensure_ascii=True,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in entries:assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256']
assert archive.stat().st_size<100_000_000
ledger=dict(date='2026-10-15',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),productSourceChanged=True,
    scope='Original 27-source plan; independent Cooke/Tessar excluded. 25 official lenses plus unchanged 123456 baseline, 28 configurations. This closes scoped throughput/configuration defects, not every numerical analysis residual.',
    includedLenses=26,configurations=28,nativeJobs=758,nativeJobCounts=dict(native_codes),workbenchAttempts=648,
    nativeVersion=dict(major=26,minor=1,build=260127,license='EnterpriseEdition',validAPI=True),
    analysis=a,explicitRays=rs,targetThroughput=target_summary,analysisTransitions=dict(trans),rayTransitions=dict(rtrans),
    retainedPriorAnalysisPasses=381,retainedPriorRayPasses=55,priorPassRegressions=regress,nativeConfigurationControls=configs,
    curvatureAndIllumination=cs,supplementalAngleControls=angles,verification=tests,
    defaultSolutionBuilds=dict(configurations=['Debug','Release'],projects=19,warnings=0,errors=0,logs=['checks/build-accepted-debug.log','checks/build-accepted-release.log']),
    sourceIdentities=read(checks/'final-source-identities.json'),matrixIdentity=identity,
    policy=dict(tolerancesRelaxed=False,originalPolicy=rel(policy),originalPolicySha256=sha(policy),currentPolicySha256=sha(run/'comparison-settings.json'),semanticIdentity=True),
    frozenBeforeMatrix=dict(path=rel(oldarchive),sha256=sha(oldarchive),unchanged=True,oldPathGateStillHasFourUpstreamRelocations=True),
    archive=dict(path=rel(archive),sha256=sha(archive),bytes=archive.stat().st_size,files=len(entries),everyArchivedFileSHA256Verified=True,containsProprietaryBinaries=False),
    limitations=['64 base pupil/image sampling; GQ6 explicit rays do not certify full 32/128/256 convergence.',
      'Non-MM/afocal analysis adapters, MIL glass resolution, PARAXIAL surfaces, reflective direction convention and coordinate-break correspondence remain explicit gaps.',
      'Remaining OPD/diffraction/illumination differences stay open; EFNO is not closed.',
      'Native normalized +/-90 inputs are physically changed; matched-angle native aiming retains its own residual. Raw differences are preserved, not converted into passes.',
      'One native prism FFT cross-section capture still fails inside the capture adapter.',
      'No new independent Cooke/Tessar certification, installer rebuild or full desktop acceptance. Commit/push is authorized and recorded separately after verification.'])
save(repo/'docs/validation/ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.json',ledger)
table=['| 文件（Zoom 合计三配置） | Pass | Close | Difference | Incomparable | Error |','| --- | ---: | ---: | ---: | ---: | ---: |']
for lens in a['lenses']:
    table.append('| '+pathlib.PurePosixPath(lens['lens']).name+' | '+' | '.join(str(lens['counts'].get(k,0)) for k in ['Pass','Close','Difference','Incomparable','Error'])+' |')
cnt=a['counts'];rc=rs['counts']
report=f'''# Zoom 多配置与超广角通光修复：2026-10-15

原定义视场下的 Zoom 三配置及 100°/200°/210° 三款广角镜头，全部三个活动波长的物理通光与逐面光线差异已关闭。原清单中仍在范围内的 25 份官方镜头和主基准 `123456.ZMX` 已重新执行，共 26 文件、28 配置；独立 Cooke/Tessar 继续排除。整批分析仍有未解决残差，不能称为全部镜头、全部功能精度认证。

## 修复及依据

- Zoom 的无限物距近轴像高原先按实际离焦像面反求物方方向，三个配置的方向随离焦改变。现按主波长光焦度映射到近轴焦面；真实像高和有限物距的既有定义保留。与 [Ansys 视场定义](https://ansyshelp.ansys.com/public/Views/Secured/Zemax/v261/en/OpticStudio_User_Guide/OpticStudio_Help/topics/Field_Angles_and_Heights.html) 对齐。
- 200°/210° 原文件首面为有曲率的同介质虚拟面，固定 `DIAM 0` 被误作实体小孔。现结合几何和材料变化/反射判断光焦度；光阑及显式 `APMN`/`APMX` 仍截光，自动尺寸和机械半径的原契约保留。依据 [Ansys 半口径说明](https://ansyshelp.ansys.com/public/Views/Secured/Zemax/v261/en/OpticStudio_User_Guide/OpticStudio_Help/topics/Semi_Diameters.html) 并由原文件原生光线验证。
- 大视场保留真实方向的 Z 符号，采用稳定横截面的光阑求解和自适应连续求解。每步由共享 Core 实际追迹验证；不能求解仍报错。中间主光线解仅在一次视场/波长求值中复用，不跨处方修订缓存。
- 顺序有序平面、无限物距首参考面及无损同介质虚拟面之后允许必要的有符号交点，修复参考面与真实曲面矢高交叠造成的假丢光；保留物理孔径及界面作用，不修改非序列前向相交。
- 另发现原生比较器将 MCE 配置编号直接写入 Spot/Huygens 分析选择器，配置 2/3 实际分析了前一配置。修正两种编号的映射，并在归一化前拒绝错误/缺失的多配置选择器读回。该编号关系由本机 2026 R1 控制和文本回读验证，不能泛称全部 API 属性的通用规则。

本批在本机有效 Enterprise API、OpticStudio 2026 R1 / build 260127 上全新执行 758 项原生任务，757 项完成、1 项棱镜 FFT 截线采集器空引用保留。最终普通视场浮点顺序修正后，逐项核对数值请求及源 SHA-256 相同，复用这批原生参考并从头重算当前 Core；原执行请求、等价当前请求和每个复制文件的哈希均记录在参考复用账本中。正式 Workbench 独立进程执行 648 次，另外 220 项缺少非 MM/无焦分析适配而单列不可比。四项倒序独立进程控制与批次原生结果精确一致。

## 原通光缺陷验收

18 组配置/波长、4536 条输入光线、{target_summary['physicalSurfaceComparisons']} 个共同有效逐面样本，原通光接受状态、首截光面、位置和方向均按原点对点门槛通过，失败数全部为零。最大位置差 **{target_summary['maximumCoordinateMillimeters']:.16g} mm**，最大方向分量差 **{target_summary['maximumDirection']:.16g}**。GQ6 覆盖原文件全部定义视场，并非任意视场/任意瞳密度的收敛证明。

新增正式回归同时检查标量和批量追迹；另检验三个 Zoom 配置的像面离焦不变量、虚拟曲面与显式孔径区别，以及精确 ±90° 物理瞄准。联合初始结构验收曾暴露普通视场重复归一化引起的浮点路径回归；修复前 Core 和只恢复普通视场计算顺序的隔离控制均通过原冻结优化目标，因此正式修正仅在横向/后向场显式设置方向，不改变固定优化预算或目标。参考冻结来源不变，未增加拟合增益或放宽误差门槛。

## 原清单重验

868 项分析：**{cnt.get('Pass',0)} Pass、{cnt.get('Close',0)} Close、{cnt.get('Difference',0)} Difference、{cnt.get('Incomparable',0)} Incomparable、{cnt.get('Error',0)} Error**。修复前 381 项 Pass 全部保留，新增通过项目由错误/不可比/差异恢复而来；下游残差仍如实保留。由于旧比较器配置错配，旧 Zoom 配置 2/3 的 Spot/Huygens 差异不能当作同配置数值误差。

91 组逐面光线：**{rc.get('Pass',0)} Pass、{rc.get('Difference',0)} Difference、{rc.get('Incomparable',0)} Incomparable、{rc.get('Error',0)} Error**；原 55 组 Pass 全部保留。详见[分析矩阵](../validation/zemax/2026-r1/zoom-wide-throughput-repair-2026-10-15/analysis-matrix.csv)、[逐面结果](../validation/zemax/2026-r1/zoom-wide-throughput-repair-2026-10-15/ray-results.json)和[机器账本](validation/ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.json)。

{chr(10).join(table)}

## 补充边界与剩余问题

±105° 和正负斜视场控制按原门槛通过。原生归一化接口把本次 89.8°～90° 请求实际发射为 89.8°，90° 以上的邻近请求实际发射为 90.2°；负向控制镜像相同。产品保留实际角度，精确 ±90° 回归通过。原生改变输入后的记录不能直接作为相同光线的参考。

在实际角度相同的近 90° 控制中，原生归一化瞄准仍有最大约 8.42e-5 mm 的光阑残差，Core 约 1.54e-9 mm；原始逐面比较仍保留 Difference，未合并为通过。用原生实测第一面落点和方向隔离后，864 条光线、23328 个逐面样本按原门槛全部通过，最大位置差 2.4641622076160274e-10 mm，最大方向差 7.771561172376096e-15。该控制定位到发射/瞄准环节，不是原定义视场的新增认证。见[实际角度与残差账目](../validation/zemax/2026-r1/zoom-wide-throughput-repair-2026-10-15/angle-mapping-audit.json)。

四文件 FCGS/FCGT 以最终 Core 重算 **2160/2160** 通过原 1e-5 mm 门槛，最大绝对差 **{max(g['MaxAbsoluteError'] for g in fc):.16g} mm**。EFNO/RELI 仍为 Difference，EFNO 最大相对差约 12.537%，没有关闭。其他分析的 OPD、衍射/照度残差、MIL 玻璃、PARAXIAL、多单位/无焦适配、反射方向约定和坐标断点逐面对应也仍开放。

## 构建、回归与证据

最终默认 Debug/Release 根解决方案各 19 项目，零警告、零错误；正式完整 Release **{tests['mainRelease']['counts']['passed']}/{tests['mainRelease']['counts']['total']}**、相关 Debug **{tests['relatedDebug']['counts']['passed']}/{tests['relatedDebug']['counts']['total']}**、比较工具完整 Release **{tests['comparisonRelease']['counts']['passed']}/{tests['comparisonRelease']['counts']['total']}**，零失败、零跳过，集合不相加。首轮全量暴露的未知扩展名旧测试与当前明确拒绝契约冲突，已改为验证拒绝且文档不变，并验证改回 `.staropt` 后正常打开；旧失败和中断记录保留。比较工具新夹具大小写失败及构建失败也独立保留，不冒充最终通过记录。

所有原始官方文件 SHA-256 保持原登记值，旧证据包及容差原字节保持。旧冻结清单四条上游更名路径仍按[此前迁移审计](ZEMAX_STANDARD_MATRIX_2026-10-15.md)记录，不能宣称旧路径门禁通过。新[原生与 Core 证据包](../validation/zemax/2026-r1/zoom-wide-throughput-repair-2026-10-15/native-and-core-evidence.zip)共 {len(entries)} 文件，每项 SHA-256 与 ZIP 读回核验通过；包 SHA-256 `{sha(archive)}`。保留原始失败、配置错配中间控制、最终参考、正式工作进程输出、原设置、源文件和宿主源码，不含专有 API 二进制。

本批未重新打包安装器或执行完整人工桌面验收；默认应用二进制已更新。用户随后授权提交/推送，最终同步身份单列记录，不改写本报告的测试阶段。
'''
(repo/'docs/ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.md').write_text(report,encoding='utf-8')
status=repo/'docs/CURRENT_STATUS.md';s=status.read_text(encoding='utf-8')
heading='### 2026-10-15 Zoom 多配置与超广角通光修复'
entry=f'''{heading}

已关闭原定义视场下 Zoom 三配置及 100°/200°/210° 镜头的通光缺陷，并修正原生比较器 Spot/Huygens 配置选择偏移。目标 18 组配置/波长、4536 条光线、{target_summary['physicalSurfaceComparisons']} 个有效逐面样本全部通过原位置/方向、通光及首截光门槛，最大坐标差 {target_summary['maximumCoordinateMillimeters']:.16g} mm。按原清单重验 25 官方文件加主基准，共 26 文件、28 配置；独立 Cooke/Tessar 排除。

868 项分析：**{cnt.get('Pass',0)} Pass、{cnt.get('Close',0)} Close、{cnt.get('Difference',0)} Difference、{cnt.get('Incomparable',0)} Incomparable、{cnt.get('Error',0)} Error**；91 组逐面：**{rc.get('Pass',0)} Pass、{rc.get('Difference',0)} Difference、{rc.get('Incomparable',0)} Incomparable、{rc.get('Error',0)} Error**。原 381 项分析及 55 组逐面 Pass 全部保留；不是所有分析认证通过。新原生采集与正式 Workbench 重算、补充近 90° 输入差异及传播隔离分开记录。四文件 FCGS/FCGT **2160/2160** 保持原门槛通过，EFNO/RELI 仍开放。

默认两配置根解决方案各 19 项目构建零警告、零错误；正式完整 Release **{tests['mainRelease']['counts']['passed']}/{tests['mainRelease']['counts']['total']}**、相关 Debug **{tests['relatedDebug']['counts']['passed']}/{tests['relatedDebug']['counts']['total']}**、比较工具完整 Release **{tests['comparisonRelease']['counts']['passed']}/{tests['comparisonRelease']['counts']['total']}**，零失败、零跳过。旧扩展名测试契约冲突、新夹具大小写失败及中间中断记录保留。详见[修复报告](ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.md)及[机器账本](validation/ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.json)。本批源码和默认二进制已更新，尚待提交、推送；安装包未重打。

'''
assert heading not in s
s=s.replace('## 最新验证账目\n\n','## 最新验证账目\n\n'+entry,1)
s=s.replace('### 2026-10-15 原计划标准镜头的完整覆盖复验','### 2026-10-15 原计划标准镜头的修复前覆盖复验',1)
status.write_text(s,encoding='utf-8')
print(json.dumps(dict(analysis=a['counts'],rays=rs['counts'],target=target_summary,tests=tests,archive=ledger['archive']),ensure_ascii=True))
