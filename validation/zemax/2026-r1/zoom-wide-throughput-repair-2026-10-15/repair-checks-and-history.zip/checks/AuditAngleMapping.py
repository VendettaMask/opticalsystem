"""Offline comparison only: original inputs and measured native launch angles stay distinct."""
import json, math, pathlib
r = pathlib.Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
near = r/'near90-rays-210'
core = read(near/('core-accepted.json' if (near/'core-accepted.json').exists() else 'core.json'))
native = read(near/'native/ray-audit.json')
original = read(r/'extra-rays-210/native/ray-audit.json')
count = len(core[0]['physical'])
angles = [c['hy']*105 for c in core]
def compare(cfield, ndata, nfield):
    result = dict(acceptanceDifferences=0,firstClipDifferences=0,coordinateFailures=0,directionFailures=0,
                  physicalSurfaceComparisons=0,maximumCoordinateMillimeters=0.,maximumDirection=0.)
    image = ndata['surfaces'][-1]['surface']
    for pi, ray in enumerate(core[cfield]['physical']):
        ni = nfield*count+pi
        nr = ndata['surfaces'][-1]['rays'][ni];last = ray['samples'][-1]
        result['acceptanceDifferences'] += (nr['error']==0 and nr['vignette']==0) != (last['surfaceNumber']==image and not last['vignetted'] and last['intensity']>0)
        if nr['error']==0 and nr['vignette'] and last['vignetted']:
            result['firstClipDifferences'] += nr['vignette'] != last['surfaceNumber']
        for surface in ndata['surfaces']:
            n = surface['rays'][ni];c = next((s for s in ray['samples'] if s['surfaceNumber']==surface['surface']),None)
            if n['error'] or n['vignette'] or c is None or c['vignetted']: continue
            result['physicalSurfaceComparisons'] += 1
            for ck,nk in [('x','x'),('y','y'),('z','z')]:
                d=abs(c['localPosition'][ck]-n[nk]);result['maximumCoordinateMillimeters']=max(result['maximumCoordinateMillimeters'],d)
                result['coordinateFailures']+=d>1e-6+1e-6*abs(n[nk])
            for ck,nk in [('x','l'),('y','m'),('z','n')]:
                d=abs(c['localDirection'][ck]-n[nk]);result['maximumDirection']=max(result['maximumDirection'],d)
                result['directionFailures']+=d>1e-8+1e-6*abs(n[nk])
    result['pass']=not any(result[k] for k in ['acceptanceDifferences','firstClipDifferences','coordinateFailures','directionFailures'])
    return result
rows=[]
for fi, requested in enumerate(angles):
    n=native['surfaces'][0]['rays'][fi*count]
    measured=math.degrees(math.atan2(n['m'],n['n']))
    cf=min(range(len(angles)),key=lambda i:abs(angles[i]-measured))
    assert abs(angles[cf]-measured)<1e-10
    rows.append(dict(requestedAngle=requested,measuredNativeAngle=measured,comparedCoreAngle=angles[cf],
        originalInputComparable=abs(requested-measured)<1e-10,sameActualLaunchComparison=compare(cf,native,fi)))
cross=[dict(requestedAngle=sign*90,measuredNativeAngle=sign*89.8,coreAngle=sign*89.8,
            comparison=compare(1 if sign>0 else 9,original,1 if sign>0 else 2)) for sign in [1,-1]]
out=dict(scope='Supplemental primary-wavelength GQ6 controls only, original 210-degree source; native actual launch readback, no product angle clamp or tolerance change',
         near90=rows,original90ComparedAtMeasuredNativeAngle=cross,
         exact90Certification='Core exact +/-90 physical aiming is checked independently by regression tests. Native normalized +/-90 is not a same-input numerical reference because native launches +/-89.8.',
         allSameActualLaunchComparisonsPass=all(x['sameActualLaunchComparison']['pass'] for x in rows) and all(x['comparison']['pass'] for x in cross))
model=read(near/'native/model.json')
stop=next(s for s in model['surfaces'] if s['IsStop'])
residuals=[]
for fi in [0,1,7,9,11]:
    nr=[];cr=[]
    for pi,ray in enumerate(core[fi]['physical']):
        i=fi*count+pi;p=native['inputs'][i];n=native['surfaces'][stop['SurfaceNumber']-1]['rays'][i]
        c=next(s for s in ray['samples'] if s['surfaceNumber']==stop['SurfaceNumber'])
        tx=p['px']*stop['SemiDiameter'];ty=p['py']*stop['SemiDiameter']
        nr.append(math.hypot(n['x']-tx,n['y']-ty));cr.append(math.hypot(c['localPosition']['x']-tx,c['localPosition']['y']-ty))
    residuals.append(dict(requestedAngle=angles[fi],nativeMaximumStopResidualMillimeters=max(nr),coreMaximumStopResidualMillimeters=max(cr)))
out['stopTargetResiduals']=residuals
out['propagationIsolation']=read(r/'angle-propagation-isolation.json')
out['conclusion']='Original +/-90 normalized inputs differ physically from the native launch. Even at matching measured launch angle, native normalized aiming retains residuals; those comparisons remain Difference. Measured-native-launch propagation passes the unchanged pointwise gate; no product gain, angle cap or fitted correction was introduced.'
(r/'angle-mapping-audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
