"""Package completed evidence for the user's requested push; do not start more verification."""
import collections,datetime,hashlib,json,pathlib,subprocess,xml.etree.ElementTree as ET,zipfile
repo=pathlib.Path(__file__).resolve().parents[3]
checks=pathlib.Path(__file__).resolve().parent
run=repo/'artifacts/zemax-standard-samples/20261015/zoom-wide-accepted-v4'
intermediate=repo/'artifacts/zemax-standard-samples/20261015/zoom-wide-final-v3'
dest=repo/'validation/zemax/2026-r1/zoom-wide-throughput-repair-2026-10-15'
dest.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rel(p):return p.relative_to(repo).as_posix()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def test(name):
    p=checks/'tests'/name
    if not p.exists():return dict(status='UserStopped',counts=None)
    root=ET.parse(p).getroot();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    counts={k:int(v) for k,v in root.find('t:ResultSummary/t:Counters',ns).attrib.items()}
    return dict(status='Completed',counts=counts,path=rel(p),sha256=sha(p))
rows=read(checks/'probe-accepted-v4.json')
target=dict(groups=len(rows),inputs=sum(x['count'] for x in rows),physicalSurfaceComparisons=sum(x['compared'] for x in rows),
    acceptanceDifferences=sum(x['acceptedDiff'] for x in rows),firstClipDifferences=sum(x['firstClipDiff'] for x in rows),
    coordinateFailures=sum(x['coordBad'] for x in rows),directionFailures=sum(x['dirBad'] for x in rows),
    maximumCoordinateMillimeters=max(x['maxP'] for x in rows),maximumDirection=max(x['maxD'] for x in rows),
    reference='Original frozen native per-surface controls; final ordinary-angle floating-order correction included')
workers=read(run/'workbench-results.json')
curvature=read(checks/'curvature-illumination-accepted.json')
cs=[dict(name=c['Name'],summary=c['Summary']) for c in curvature['Cases']]
fc=[g for c in cs for g in c['summary'] if g['Code'] in ['FCGS','FCGT']]
tests=dict(relatedDebug=test('related-accepted-debug.trx'),comparisonRelease=test('comparison-accepted-release.trx'),
    coatingRelease=test('coating-accepted-release.trx'),mainRelease=test('full-accepted-release.trx'),initialStructureRelease=test('initial-accepted-release.trx'),
    isolatedHeadCoreOptimizationControl=test('head-core-initial-control.trx'),isolatedOrdinaryDirectionOptimizationControl=test('normal-direction-initial-control.trx'))
stopped=read(checks/'user-requested-verification-stop.json')
inter_a=read(intermediate/'analysis-summary.json');inter_r=read(intermediate/'ray-summary.json')
for name in ['analysis-summary.json','analysis-matrix.csv','ray-summary.json','ray-results.json']:
    p=intermediate/name
    if p.exists():(dest/('intermediate-v3-'+name)).write_bytes(p.read_bytes())
for name in ['probe-accepted-v4.json','angle-mapping-audit.json','angle-accepted-core-identity.json','user-requested-verification-stop.json']:
    (dest/name).write_bytes((checks/name).read_bytes())
save(dest/'curvature-illumination-summary.json',cs)
for name in ['identity.json','workbench-results.json','native-reference-reuse.json','sources.json','models.json']:
    (dest/name).write_bytes((run/name).read_bytes())
changed=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
code=[repo/p for p in set(changed+untracked) if p.endswith(('.cs','.csproj','.ps1','.py')) and (p.startswith('src/') or p.startswith('tests/') or p.startswith('tools/'))]
save(dest/'source-identities.json',[dict(path=rel(p),sha256=sha(p)) for p in sorted(code)])
archives=[]
allowed={'.json','.txt','.log','.cfg','.zmx','.cs','.py','.ps1','.trx','.diff','.csv','.csproj'}
def pack(name,folders,extras=()):
    p=dest/name;entries=[]
    with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        candidates=[]
        for prefix,folder in folders:
            for f in folder.rglob('*'):
                if f.is_file() and f.suffix.lower() in allowed and not any(s in {'bin','obj','testbin','__pycache__'} for s in f.relative_to(folder).parts):
                    candidates.append((prefix+'/'+f.relative_to(folder).as_posix(),f))
        candidates+=extras
        for arc,f in sorted(candidates):z.write(f,arc);entries.append(dict(path=arc,sha256=sha(f),bytes=f.stat().st_size))
        z.writestr('exact-byte-ledger.json',json.dumps(entries,ensure_ascii=True,indent=2))
    size=p.stat().st_size
    if size>=100_000_000:raise RuntimeError('Split required before GitHub push: '+str(p))
    archives.append(dict(path=rel(p),sha256=sha(p),bytes=size,files=len(entries),postPackagingFullReadbackRun=False,containsProprietaryBinaries=False))
pack('native-and-core-evidence.zip',[('run',run)])
extras=[]
for p in intermediate.glob('*.json'):extras.append(('intermediate-v3/'+p.name,p))
for folder in (intermediate/'analyses').glob('*zoom-lens*'):
    for p in folder.rglob('*'):
        if p.is_file() and p.suffix.lower() in allowed:extras.append(('intermediate-v3/'+p.relative_to(intermediate).as_posix(),p))
pack('repair-checks-and-history.zip',[('checks',checks)],extras)
ledger=dict(date='2026-10-15',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),scope='25 official lenses plus unchanged 123456 baseline; independent Cooke/Tessar excluded',
    includedLenses=26,configurations=28,targetThroughput=target,verification=tests,userRequestedVerificationStop=stopped,
    defaultSolutionBuilds=dict(configurations=['Debug','Release'],projects=19,warnings=0,errors=0,logs=['checks/build-accepted-debug.log','checks/build-accepted-release.log']),
    nativeCapture=dict(jobs=758,completed=757,captureErrors=1,version='OpticStudio 2026 R1 build 260127, valid Enterprise API',referenceReuse=rel(dest/'native-reference-reuse.json')),
    finalWorkbenchExecution=dict(attempts=len(workers),counts=dict(collections.Counter(('TimedOut' if w['timedOut'] else str(w['exitCode'])) for w in workers)),normalizedFullComparisonFinalized=False),
    intermediateBeforeOrdinaryAngleCorrection=dict(analysis=inter_a,explicitRays=inter_r,notFinalCoreCertification=True,
        note='One 180-second illumination timeout subsequently completed unchanged at 900 seconds; the intermediate full classification was not regenerated.'),
    curvatureAndIllumination=cs,supplementalAngleControls=read(checks/'angle-mapping-audit.json'),
    policy=dict(tolerancesRelaxed=False,opticalSettingsChangedForPass=False,fullVerificationWaivedByUser=True),archives=archives,
    limitations=['Main and initial-structure full suites were stopped at user request; unavailable totals are not zero or passes.',
      'Final Core Workbench calculations completed, but final full normalization/classification was not added after the user requested immediate push.',
      'Intermediate matrix counts remain tied to that earlier Core; final scoped 18-group throughput and 2160 curvature controls are separately identified.',
      'EFNO/RELI, other OPD/diffraction residuals, MIL glass resolution, PARAXIAL and analysis adapters remain open.',
      'No installer rebuild or full manual desktop acceptance.'])
save(repo/'docs/validation/ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.json',ledger)
report=f'''# Zoom 多配置与超广角通光修复：2026-10-15

Zoom 三配置及 100°/200°/210° 三款广角镜头的原定义视场通光问题已修复。用户随后要求“全推送，能不验就就不验了”，本批停止等待可选全量测试，不追加最终整批归一化比较；已完成结果、未完成状态与原始失败一并交付。

## 代码修改

- 无限物距近轴像高按主波长光焦度映射到近轴焦面，避免 Zoom 的物方方向随实际像面离焦改变；实际像高与有限物距映射保留。依据 [Ansys 视场定义](https://ansyshelp.ansys.com/public/Views/Secured/Zemax/v261/en/OpticStudio_User_Guide/OpticStudio_Help/topics/Field_Angles_and_Heights.html)。
- 同介质虚拟曲面不再因固定 `DIAM 0` 产生错误实体孔径，光阑及显式 `APMN`/`APMX` 仍截光；光焦度同时结合几何和材料变化/反射判断。依据 [Ansys 半口径说明](https://ansyshelp.ansys.com/public/Views/Secured/Zemax/v261/en/OpticStudio_User_Guide/OpticStudio_Help/topics/Semi_Diameters.html)并由原生控制验证。
- 横向及后向视场保留正确方向，在稳定横截面连续求解光阑落点；有序参考平面等必要交点使用有符号路径，实际孔径及界面作用仍生效。普通视场保留原浮点顺序。一次联合回归暴露重复归一化造成固定预算优化路径变化，隔离原 Core 与最小恢复控制均通过原目标，正式代码已采用该最小修正。
- 原生比较工具分别处理 MCE 配置编号与 Spot/Huygens 的分析选择器，修复配置 2/3 错选前一配置，并拒绝缺少或错误的多配置读回。

## 已完成的验证

最终 Core 对原冻结逐面控制：**18 组配置/波长、4536 条光线、{target['physicalSurfaceComparisons']} 个共同有效逐面样本**，通光接受、首截光面、位置及方向失败数全部为零。最大坐标差 **{target['maximumCoordinateMillimeters']:.16g} mm**，最大方向分量差 **{target['maximumDirection']:.16g}**。正式回归包含标量/批量两条路径、Zoom 离焦不变量及精确 ±90° 光阑瞄准。

最终默认 Debug/Release 根解决方案各 19 项目构建，零警告、零错误。相关 Debug **61/61**、比较工具完整 Release **209/209**、镀膜完整 Release **54/54**，零失败、零跳过；这些集合不相加。主程序及初始结构完整集合按用户要求停止，**没有完整通过结论**。修正普通视场前的初始结构失败、修正前后隔离控制和中断日志均保留。

最终四文件 FCGS/FCGT **{sum(g['Total'] for g in fc)}/2160** 通过原 1e-5 mm 门槛，最大绝对差 **{max(g['MaxAbsoluteError'] for g in fc):.16g} mm**。有效 F 数/照度仍为 Difference，EFNO 最大相对差约 12.537%，没有关闭。

## 原镜头清单及阶段边界

原 27 文件清单排除独立 Cooke/Tessar，包含 25 官方文件加主基准，共 26 文件、28 配置。本轮新原生采集 758 项任务，757 项完成，1 项棱镜 FFT 截线采集器空引用保留；四项倒序独立进程控制一致。最终普通视场修正后逐项核对数值请求及源 SHA-256 相同，复用这批原生参考并从头执行当前 Core，**648 次正式 Workbench 计算已完成执行**，其余 220 项缺少非 MM/无焦分析适配。

最终全批归一化分类未追加。此前中间版本的完整分类为 **467 Pass、19 Close、22 Difference、267 Incomparable、93 Error**；其中一项 180 秒照度超时随后在相同 Core/输入/光学设置下独立完成，但中间汇总没有再生成。中间逐面分类为 **73 Pass、7 Difference、2 Incomparable、9 Error**。这些数不能当作最终 Core 全批认证；原修复前报告与原字节仍保留。最终通光 18 组与场曲门槛的结论来自单列的最终 Core 控制。

补充 90° 邻域中，原生接口改变实际发射角且存在自身瞄准收敛残差，原始 Difference 保留。采用原生实测落点和方向隔离传播后，864 条光线、23328 个逐面样本通过原门槛，最大位置差 2.4641622076160274e-10 mm；没有对产品增加角度钳位、拟合增益或放宽外部比较门槛。MIL 玻璃、PARAXIAL、多单位/无焦适配、反射方向、坐标断点对应及其他 OPD/衍射残差仍开放。210° 照度的计算耗时也未作为性能问题关闭。

## 证据交付

[机器账本](validation/ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.json)分别记录最终控制、中间全矩阵与用户停止的集合。[最终原生参考及 Core 原始输出](../validation/zemax/2026-r1/zoom-wide-throughput-repair-2026-10-15/native-and-core-evidence.zip)和[检查、失败及阶段记录](../validation/zemax/2026-r1/zoom-wide-throughput-repair-2026-10-15/repair-checks-and-history.zip)包含原设置、来源、宿主源码、原始失败和已有测试结果，不含专有 API 二进制。打包时记录每个条目的 SHA-256；按用户指令未追加打包后全量读回验证。

源码、文档及全部本批交付证据按用户要求提交、推送；安装包没有重打，完整人工桌面验收没有新增。同步提交身份以 Git 及同步记录为准。
'''
(repo/'docs/ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.md').write_text(report,encoding='utf-8')
p=repo/'docs/CURRENT_STATUS.md';s=p.read_text(encoding='utf-8')
entry='''### 2026-10-15 Zoom/超广角修复与用户要求全推送

已修复 Zoom 近轴像高的离焦依赖、原生 Spot/Huygens 配置选择偏移、同介质虚拟曲面的隐含孔径及超广角连续瞄准/有符号参考交点。最终 Core 的目标 18 组、4536 条光线、91343 个有效逐面样本全部通过原门槛，通光、首截光、坐标及方向差异数为零；最大坐标差 2.130628971031001e-7 mm。普通视场保留原浮点顺序，避免改变固定预算优化路径。

默认两配置根解决方案各 19 项目构建零警告、零错误；最终相关 Debug **61/61**、比较工具完整 Release **209/209**、镀膜完整 Release **54/54**，零失败、零跳过。四文件 FCGS/FCGT **2160/2160** 通过原门槛，有效 F 数/照度仍开放。原清单 25 官方文件加主基准的新原生采集及最终 Core 648 次 Workbench 执行完成；最终全批分类未追加。

用户随后明确要求“全推送，能不验就就不验了”，故停止等待主程序及初始结构可选完整集合，不宣称全量通过，不再追加验证。修复前、中间全矩阵、最终控制及用户停止状态分开记录，见[修复交付报告](ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.md)及[机器账本](validation/ZEMAX_ZOOM_WIDE_THROUGHPUT_REPAIR_2026-10-15.json)。本批源码、文档和证据按用户要求同步；安装包没有重打。

'''
if '### 2026-10-15 Zoom/超广角修复与用户要求全推送' not in s:s=s.replace('## 最新验证账目\n\n','## 最新验证账目\n\n'+entry,1)
s=s.replace('### 2026-10-15 原计划标准镜头的完整覆盖复验','### 2026-10-15 原计划标准镜头的修复前覆盖复验',1)
p.write_text(s,encoding='utf-8')
print(json.dumps(dict(archives=archives,workers=len(workers),target=target),ensure_ascii=True))
