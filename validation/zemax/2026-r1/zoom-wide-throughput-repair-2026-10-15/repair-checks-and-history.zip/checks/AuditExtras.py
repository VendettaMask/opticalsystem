import json,pathlib,math
r=pathlib.Path(__file__).resolve().parent
d=r/'extra-rays-210'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
corePath=d/('core-accepted.json' if (d/'core-accepted.json').exists() else 'core.json')
core=read(corePath);native=read(d/'native/ray-audit.json');model=read(d/'native/model.json')
assert len(native['inputs'])==504
per=len(core[0]['physical']);image=model['surfaceCount']-1
fields=[]
for fi,field in enumerate(core):
 acc=clip=posbad=dirbad=paired=0;maxp=maxd=0
 for pi,ray in enumerate(field['physical']):
  ni=fi*per+pi;last=ray['samples'][-1];nr=native['surfaces'][-1]['rays'][ni]
  acc+=(nr['error']==0 and nr['vignette']==0)!=(last['surfaceNumber']==image and not last['vignetted'] and last['intensity']>0)
  if nr['error']==0 and nr['vignette']>0 and last['vignetted']:clip+=nr['vignette']!=last['surfaceNumber']
  for s in native['surfaces']:
   n=s['rays'][ni];c=next((x for x in ray['samples'] if x['surfaceNumber']==s['surface']),None)
   if n['error'] or n['vignette'] or c is None or c['vignetted']:continue
   paired+=1
   for ck,nk in [('x','x'),('y','y'),('z','z')]:
    delta=abs(c['localPosition'][ck]-n[nk]);maxp=max(maxp,delta);posbad+=delta>1e-6+1e-6*abs(n[nk])
   for ck,nk in [('x','l'),('y','m'),('z','n')]:
    delta=abs(c['localDirection'][ck]-n[nk]);maxd=max(maxd,delta);dirbad+=delta>1e-8+1e-6*abs(n[nk])
 fields.append(dict(hx=field['hx'],hy=field['hy'],inputs=per,acceptanceDifferences=acc,firstClipDifferences=clip,coordinateFailures=posbad,directionFailures=dirbad,maximumCoordinateMillimeters=maxp,maximumDirection=maxd,physicalSurfaceComparisons=paired))
out=dict(scope='Fresh native GQ6/primary-wavelength controls at axis, +/-90 degrees, +/-105 degrees and signed oblique fields; original pointwise matrix tolerances',fields=fields,passAll=all(not any(f[k] for k in ['acceptanceDifferences','firstClipDifferences','coordinateFailures','directionFailures']) for f in fields))
(r/'extra-rays-210-comparison.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
