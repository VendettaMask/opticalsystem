"""Reuse only exact numerical native requests; preserve original executed captures byte for byte."""
import hashlib,json,pathlib,shutil
r=pathlib.Path(__file__).resolve().parents[3]
source=r/'artifacts/zemax-standard-samples/20261015/zoom-wide-final-v3'
target=r/'artifacts/zemax-standard-samples/20261015/zoom-wide-accepted-v4'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old={j['id']:j for j in read(source/'native-jobs.json')}
new=read(target/'native-jobs.json');assert len(old)==len(new)==758
records=[]
for job in new:
    previous=old[job['id']];op=pathlib.Path(previous['request']);np=pathlib.Path(job['request'])
    a=read(op);b=read(np);os=a.pop('input');ns=b.pop('input')
    assert a==b,(job['id'],'native numerical request changed')
    assert sha(pathlib.Path(os))==sha(pathlib.Path(ns)),job['id']
    out=pathlib.Path(job['output']);origin=pathlib.Path(previous['output'])
    preserved=np.read_bytes();(out/'equivalent-recalculation-request.json').write_bytes(preserved)
    request_hash=sha(np)
    files=[]
    for p in origin.iterdir():
        assert p.is_file()
        d=out/p.name;shutil.copyfile(p,d);assert sha(p)==sha(d)
        files.append(dict(name=p.name,sha256=sha(p)))
    records.append(dict(id=job['id'],nativeExecutedRequest=op.as_posix(),nativeExecutedRequestSha256=sha(op),
        equivalentCurrentRequestSha256=request_hash,sourceSha256=sha(pathlib.Path(ns)),
        equality='All request JSON values identical except the copied input path; source bytes SHA-256 identical',files=files))
for folder in ['host','isolated-controls']:
    shutil.copytree(source/folder,target/folder,dirs_exist_ok=True)
shutil.copyfile(source/'isolated-controls.json',target/'isolated-controls.json')
shutil.copyfile(source/'native.log',target/'native-reference.log')
(target/'native-reference-reuse.json').write_text(json.dumps(dict(scope='Fresh native 2026 R1 captures from final-v3, reused after ordinary-angle floating-order correction; no numerical native input or settings changed',
    source=source.as_posix(),target=target.as_posix(),count=len(records),records=records),indent=2),encoding='utf-8')
print('Verified and reused',len(records),'native requests; all copied evidence hashes match')
