$ErrorActionPreference='Stop'
$repo=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$run=(Resolve-Path (Join-Path $repo 'artifacts/zemax-standard-samples/20261015/zoom-wide-final-v3')).Path
$items=Get-Content -LiteralPath (Join-Path $run 'items.json') -Raw | ConvertFrom-Json
$resultsPath=Join-Path $run 'workbench-results.json'
$results=@(Get-Content -LiteralPath $resultsPath -Raw | ConvertFrom-Json)
$initial=Join-Path $run 'workbench-results-initial.json'
if (Test-Path -LiteralPath $initial) { throw 'Retry audit already exists' }
Copy-Item -LiteralPath $resultsPath -Destination $initial
$records=@()
foreach ($item in $items) {
    if (!$item.workbenchJob) { continue }
    $folder=Split-Path -Parent $item.workbenchJob
    $old=Get-Content -LiteralPath (Join-Path $folder 'worker-result.json') -Raw | ConvertFrom-Json
    if (!$old.timedOut) { continue }
    $resolved=[IO.Path]::GetFullPath($folder)
    if (!$resolved.StartsWith($run+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Retry outside run' }
    $original=Join-Path (Split-Path -Parent $folder) 'workbench-initial-timeout'
    New-Item -ItemType Directory -Path $original -ErrorAction Stop | Out-Null
    Get-ChildItem -LiteralPath $folder -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $original }
    $jobHash=(Get-FileHash -LiteralPath $item.workbenchJob).Hash
    $tool=Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/bin/Release/net10.0/OpticalSystemDesign.ZemaxComparison.dll'
    $core=Join-Path $repo 'src/OpticalSystemDesign.Core/bin/Release/net10.0/OpticalSystemDesign.Core.dll'
    $coreHash=(Get-FileHash -LiteralPath $core).Hash
    $started=[DateTime]::UtcNow
    $p=Start-Process -FilePath 'dotnet' -ArgumentList @($tool,'--workbench-worker',$item.workbenchJob) -WindowStyle Hidden -PassThru -WorkingDirectory $repo -RedirectStandardOutput (Join-Path $folder 'retry-stdout.log') -RedirectStandardError (Join-Path $folder 'retry-stderr.log')
    $finished=$p.WaitForExit(900000)
    if (!$finished) { $p.Kill($true);$p.WaitForExit() }
    $exitCode=if ($finished) { $p.ExitCode } else { 4 }
    if ((Get-FileHash -LiteralPath $item.workbenchJob).Hash -ne $jobHash -or (Get-FileHash -LiteralPath $core).Hash -ne $coreHash) { throw 'Input/Core changed during retry' }
    $stdout=[IO.File]::ReadAllText((Join-Path $folder 'retry-stdout.log'))
    $stderr=[IO.File]::ReadAllText((Join-Path $folder 'retry-stderr.log'))
    [IO.File]::WriteAllText((Join-Path $folder 'process.log'),$stdout+$stderr)
    @{exitCode=$exitCode;timedOut=(!$finished);cancelled=$false;standardOutput=$stdout;standardError=$stderr} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $folder 'worker-result.json') -Encoding utf8NoBOM
    $record=@{directory=$item.run.directory;startedUtc=$started.ToString('o');completedUtc=[DateTime]::UtcNow.ToString('o');timeoutSeconds=900;priorTimeoutSeconds=180;canonicalJobSha256=$jobHash;coreSha256=$coreHash;exitCode=$exitCode;timedOut=(!$finished);originalAttempt=$original;opticalSettingsUnchanged=$true}
    $records+=$record
    $row=$results | Where-Object directory -eq $item.run.directory
    $row.exitCode=$exitCode;$row.timedOut=(!$finished)
    $record | ConvertTo-Json -Depth 8
}
ConvertTo-Json -InputObject @($records) -Depth 12 | Set-Content -LiteralPath (Join-Path $run 'workbench-retries.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($results) -Depth 12 | Set-Content -LiteralPath $resultsPath -Encoding utf8NoBOM
if (@($records | Where-Object { $_.exitCode -ne 0 }).Count) { exit 1 }
