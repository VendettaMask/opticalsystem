import csv, datetime, hashlib, json, pathlib, subprocess, zipfile
from collections import Counter

repo = pathlib.Path(__file__).resolve().parents[3]
run = repo / 'artifacts/zemax-standard-samples/20261015/full-matrix-v1'
checks = pathlib.Path(__file__).resolve().parent
dest = repo / 'validation/zemax/2026-r1/standard-matrix-2026-10-15'
dest.mkdir(parents=True, exist_ok=True)
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, v): p.write_text(json.dumps(v, ensure_ascii=False, indent=2), encoding='utf-8')
def rel(p): return p.relative_to(repo).as_posix()

a = read(run/'analysis-summary.json')
items = read(run/'analysis-results.json')
rays = read(run/'ray-results.json')
rs = read(run/'ray-summary.json')
sources = read(run/'sources.json')
models = read(run/'models.json')
jobs = read(run/'native-jobs.json')
assert len(a['lenses']) == 26 and a['total'] == 868 and sum(a['counts'].values()) == 868
assert len(models) == 28 and len(sources) == 28 and len(rays) == 91
assert all(x['originalUnchanged'] for x in read(run/'source-integrity.json'))
assert len(jobs) == 758
native_results = []
for job in jobs:
    out = pathlib.Path(job['output'])
    result = read(out/'batch-result.json')
    env = read(out/'environment.json')
    assert env['validLicense'] and env['major'] == 26 and env['minor'] == 1 and env['opticStudioVersion'] == 260127
    request = read(pathlib.Path(job['request']))
    source = pathlib.Path(request['input'])
    assert sha(source) in [s['source']['sha256'] for s in sources if not s['excluded']]
    native_results.append({'id': job['id'], 'exitCode': result['exitCode']})
assert sum(x['exitCode'] != 0 for x in native_results) == 1
assert len(read(run/'workbench-results.json')) == 648
isolated = read(run/'isolated-controls.json')
assert len(isolated) == 4 and all(x['exactMatch'] and x['exitCode'] == 0 for x in isolated)

old_policy = subprocess.check_output(['git','show','0179e2fb8fff814826176043271fac6e241c2c24:tools/OptilandWorkbench.ZemaxComparison/comparison-settings.json'], cwd=repo)
(dest/'original-comparison-settings.json').write_bytes(old_policy)
current_policy = run/'comparison-settings.json'
assert json.loads(old_policy) == read(current_policy)
frozen = read(checks/'frozen-head-working.json')
moves = []
for row in frozen['mismatches']:
    new = row['path'].replace('OptilandWorkbench.Tests','OpticalSystemDesign.Tests').replace('OptilandWorkbench.ZemaxComparison','OpticalSystemDesign.ZemaxComparison')
    path = repo/new
    moves.append({'originalPath':row['path'],'currentPath':new,'originalSha256':row['expectedSha256'],'currentSha256':sha(path),'exactByteMatch':sha(path)==row['expectedSha256']})
assert len(moves) == 4 and sum(x['exactByteMatch'] for x in moves) == 3
assert hashlib.sha256(old_policy).hexdigest() == moves[-1]['originalSha256']
save(run/'frozen-relocation-audit.json', {'originalPathCheck':frozen,'relocations':moves,'comparisonPolicySemanticallyEqual':True,
    'originalPolicyExactArchive':rel(dest/'original-comparison-settings.json'), 'explanation':'The upstream identity rename moved four entries. Three fixture byte identities remain exact. The maintained tool policy was reformatted, without changing JSON values. The original policy is preserved exactly in this new validation archive. The old-path HEAD gate is not reported as passing.'})
curvature = read(checks/'curvature-illumination-current.json')
curvature_summary = [{'name':c['Name'],'summary':c['Summary']} for c in curvature['Cases']]
assert sum(g['Total'] for c in curvature_summary for g in c['summary'] if g['Code'] in ('FCGS','FCGT')) == 2160
assert all(g['Status']=='Pass' for c in curvature_summary for g in c['summary'] if g['Code'] in ('FCGS','FCGT'))

for name in ['analysis-summary.json','ray-summary.json','source-integrity.json','isolated-controls.json','frozen-relocation-audit.json','identity.json']:
    (dest/name).write_bytes((run/name).read_bytes())
(dest/'analysis-matrix.csv').write_bytes((run/'analysis-matrix.csv').read_bytes())
save(dest/'curvature-illumination-summary.json', curvature_summary)

archive = dest/'native-and-core-evidence.zip'
entries=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    candidates = [p for p in run.rglob('*') if p.is_file() and p.suffix.lower() in ('.json','.txt','.log','.cfg','.zmx','.cs')]
    candidates += [p for p in checks.rglob('*') if p.is_file() and p.suffix.lower() in ('.json','.log','.trx','.py')]
    for path in sorted(set(candidates)):
        if path.name.startswith('.'): continue
        arc = ('run/' + path.relative_to(run).as_posix()) if path.is_relative_to(run) else ('checks/'+path.relative_to(checks).as_posix())
        z.write(path,arc)
        entries.append({'path':arc,'sha256':sha(path),'bytes':path.stat().st_size})
    z.writestr('exact-byte-ledger.json',json.dumps(entries,ensure_ascii=True,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in entries:
        assert hashlib.sha256(z.read(entry['path'])).hexdigest() == entry['sha256']

ledger = {
 'date':'2026-10-15','recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 'productSourceChanged':False, 'scope':'25 official standard lenses from the original 27-file plan, excluding independent Cooke/Tessar; plus unchanged 123456 baseline. This is a scoped audit, not full software or all-sampling certification.',
 'sourceCountIncludingExcluded':28,'includedLenses':26,'configurations':28,'nativeJobs':len(jobs),'nativeJobCounts':dict(Counter(str(x['exitCode']) for x in native_results)),
 'nativeVersion':{'major':26,'minor':1,'build':260127,'license':'EnterpriseEdition','validAPI':True},
 'analysis':a,'explicitRays':rs,'curvatureAndIllumination':curvature_summary,
 'isolatedNativeControls':isolated,
 'policy':{'preparedPolicySha256':sha(current_policy),'originalFrozenPolicySha256':hashlib.sha256(old_policy).hexdigest(),'semanticIdentity':True,'tolerancesRelaxed':False},
 'frozenEvidence':{'originalPathGateMatched':frozen['matched'],'originalPathGateTotal':frozen['count'],'originalPathGatePassed':False,'relocations':moves,'originalPolicyArchivedExactly':True,'audit':rel(dest/'frozen-relocation-audit.json')},
 'verification':{'comparisonToolRelease':{'passed':201,'failed':0,'skipped':0,'trx':'checks/test-results/comparison-tool-release.trx'},'diagnosticReleaseBuildWarnings':0,'diagnosticReleaseBuildErrors':0,'fullMainSuiteRun':False,'samplingConvergenceCertified':False},
 'archive':{'path':rel(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(entries),'everyArchivedFileSHA256Verified':True,'containsProprietaryBinaries':False},
 'limitations':['18 primary analysis requests and 4 edge controls per positive-weight wavelength/configuration; overlapping physical conditions remain separately identified requests.','64 pupil/image base sampling where applicable; no 32/128/256 convergence matrix or full field-by-wavelength diffraction certification.','220 requests lack MM/focal analysis adapters, 14 have native diagnostic warnings, and other Incomparables retain their detailed reasons.','MIL catalog glasses 517642/648338 and native PARAXIAL surfaces are blocked, not modeled by fallbacks.','Raw reflective local directions require a convention audit; coordinate-break row folding needs explicit surface correspondence.','One native FFT cross-section capture failed in Host.Capture with a null series; this is a capture-adapter error, not proof of a product optical residual.','No independent Cooke/Tessar recapture, installer rebuild, full desktop acceptance or external commit/push.'],
 'toolSources':[{'path':rel(p),'sha256':sha(p)} for p in sorted((repo/'tools/diagnostics/StandardMatrix20261015').glob('*')) if p.is_file()]
}
save(repo/'docs/validation/ZEMAX_STANDARD_MATRIX_2026-10-15.json',ledger)
rows=[]
for lens in a['lenses']:
    c=lens['counts']
    rows.append('| '+pathlib.PurePosixPath(lens['lens']).name+' | '+' | '.join(str(c.get(k,0)) for k in ['Pass','Close','Difference','Incomparable','Error'])+' |')
report='''# Zemax 官方标准镜头精度复验：2026-10-15

本轮已覆盖原 27 文件计划中仍在范围内的 25 份官方镜头，并另验主基准 `123456.ZMX`；独立 Cooke/Tessar 按用户决定排除。26 份文件全部完成导入、原生模型读回与适用项目执行尝试，Zoom 三配置分别登记，共 28 个配置。**没有全部通过，不能据此宣称商业软件级完整数值认证。** 本轮未修改产品计算代码或放宽容差。

## 本轮数值结果

868 项分析请求：**381 Pass、19 Close、32 Difference、300 Incomparable、136 Error**。请求数不是镜头通过数；同一文件的主波长/边场控制可能包含重叠条件，Close 不算 Pass，失败或不可比项目均保留在分母。明细见[误差矩阵](../validation/zemax/2026-r1/standard-matrix-2026-10-15/analysis-matrix.csv)及[机器账本](validation/ZEMAX_STANDARD_MATRIX_2026-10-15.json)。

| 文件（Zoom 合计三配置） | Pass | Close | Difference | Incomparable | Error |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

91 组配置/波长逐面光线检查：**55 Pass、25 Difference、2 Incomparable、9 Error**。取得 15768 条归一化输入、192672 条原生逐面记录，112265 个共同有效物理表面样本的 673590 个坐标/方向值进入比较。部分坐标断点样本因面号折叠缺少明确对应，单列不可比；不存在有效共同交点时，不以零误差宣称追迹正确。反射的原始局部方向约定尚待对齐，不能把方向符号残差直接解释成物理追迹错误。

## 实际暴露的问题

- **Zoom 多配置与超广角通光。** Zoom 三配置仅 6 项 Pass，16 项 Difference、30 项 Error、36 项 Incomparable、2 项 Close；9 组逐面光线控制都有通光/方向差异。100°/200°/210° 控制也存在通光差异；210° 的部分衍射计算没有有效入瞳。应先核对源处方的配置、解、光阑和大角度发射，不能仅调 MTF/PSF 的显示或采样。
- **材料与面型支持缺口。** MIL 玻璃 `517642`、`648338` 未匹配；Tilted mirror 与有限共轭 Double Gauss arrangement 的 `PARAXIAL` 未映射为可计算面，按能力检查阻断。文件能导入不代表可计算。
- **照度与衍射残差。** Double Gauss、Inverse telephoto 的相对照度仍 Difference；Petzval 在当前密度下孔径边界未解决。Even Asphere MTF NRMSE 约 0.0317763，Relay DEE 约 0.0117417，Annular Pupils DEE 约 0.0124978，均指本批设置。19 项 Close 及原生警告仍需处理。
- **比较契约缺口。** 5 份非 MM 文件及 1 份无焦文件的分析共 220 项因现有适配器边界不可比；另有退化单点曲线、原生诊断警告、场坐标映射、面号对应和反射方向约定问题。棱镜 FFT 截线有一次原生 `Host.Capture` 空引用，是采集适配器错误，不能当成产品光学误差。

## 之前精度问题的进度

以当前 Core 重算四文件旧原生 MFE 控制：FCGS/FCGT **2160/2160** 通过原 `1e-5 mm` 门槛，全组最大绝对差 **3.054520025802532e-8 mm**；没有回退。EFNO/RELI 的 256 个控制仍记录 Difference，EFNO 全档位最大相对差约 **12.537%**，未关闭。此前单分析设置的约 0.309% 不能代表扩展矩阵。此复验使用既有明确设置的原生控制；本轮全文件矩阵则另有新捕获，不混淆二者的捕获时间。

## 设置、独立性与证据

实际原生环境为 OpticStudio **2026 R1 / 26.1 / build 260127 / EnterpriseEdition，有效 API 许可证**。27 份选样原文件和 `123456` 的 SHA-256 均与登记身份相同。每配置运行原 18 项主波长请求、每活动波长 4 项最后定义场控制；采样为保存策略中的 64×64（适用分析），连续场分析保留自身契约。逐面控制为共享 Core 产生的 GQ6 节点、原始渐晕和径向归一化定义场。不覆盖所有场×波长的全部分析，也未完成 32/64/128/256 收敛矩阵。

Zemax 串行、逐请求重新加载只读副本，Workbench 两个隔离进程调用正式 Application/Core。倒序选取 Zoom 配置 3/1、Double Gauss、Apochromat，分别以全新 Zemax 进程补采，4 项 Spot 规范化结果与持续进程结果逐字节一致；这排除了这四个控制上的应用/配置污染，不扩展成全部状态认证。

比较工具完整 Release **201/201**，零失败、零跳过；诊断工具及其依赖构建零警告、零错误。本轮未重跑完整主测试或模块全量，不沿用历史全量计数冒充当前验收。工具说明见[批处理入口](../tools/diagnostics/StandardMatrix20261015/README.md)。

旧 2668 份冻结清单按原路径核验为 **2664/2668**：上游产品更名迁移了四个路径，三份夹具在新路径字节完全一致；维护中的工具配置只改变 JSON 格式，值和容差完全相同，但字节哈希不同。原配置已[按原字节另存](../validation/zemax/2026-r1/standard-matrix-2026-10-15/original-comparison-settings.json)。[路径迁移审计](../validation/zemax/2026-r1/standard-matrix-2026-10-15/frozen-relocation-audit.json)保留失败的旧路径门禁，不把它写成通过，也不恢复退役的产品目录。

原始两侧数组、掩码、CFG、环境/请求、模型、源副本、失败日志、独立控制及 TRX 已保存于[完整压缩证据](../validation/zemax/2026-r1/standard-matrix-2026-10-15/native-and-core-evidence.zip)，附逐文件 SHA-256 且解压内容全部复核。没有专有 API 二进制、第二套光学引擎、拟合增益或修改原生数值。
'''
(repo/'docs/ZEMAX_STANDARD_MATRIX_2026-10-15.md').write_text(report,encoding='utf-8')
print(json.dumps({'archiveBytes':archive.stat().st_size,'archiveFiles':len(entries),'archiveSha256':sha(archive),'analysis':a['counts'],'rays':rs['counts']},ensure_ascii=True))
