using OpticalSystemDesign.Core.Apertures;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Rays;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Raytrace;

public sealed partial class RayGenerator
{
    // Solve the actual two-dimensional stop map. Unit-gain shifts and independent
    // axis secants cannot represent inverted pupils or transverse coupling.
    private bool TryAimStopTarget(Vector3D baseOrigin, Vector3D fixedDirection,
        double wavelengthNanometers, int stopIndex, double targetX, double targetY,
        double x, double y, bool infinite, out Vector3D aimedOrigin,
        out Vector3D aimedDirection, out double residual, Vector3D? infiniteOriginGuess = null)
    {
        var stop = _optic.SurfaceGroup.Items[stopIndex];
        // A chief target is zero but its optical stop is not: scale the solver
        // to the same stop boundary used for physical clipping, including at
        // the axis. Keep the residual strictly inside that boundary budget.
        var tolerance = CircularAperture.BoundaryTolerance(
            Math.Max(stop.SemiDiameter, double.Hypot(targetX, targetY))) / 4;
        aimedOrigin = default;
        aimedDirection = default;
        residual = double.PositiveInfinity;
        // Near a transverse field, shifts parallel to the incident ray cannot
        // control the stop intercept. Solve on a plane with a finite transverse
        // Jacobian instead of forcing the world-Z plane through 90 degrees.
        var fixedAxis = !infinite || Math.Abs(fixedDirection.Z) >= .5 ? 2
            : Math.Abs(fixedDirection.Y) >= Math.Abs(fixedDirection.X) ? 1 : 0;
        var plane = baseOrigin;
        if (infinite)
        {
            var guess = infiniteOriginGuess ?? new Vector3D(x, y, baseOrigin.Z);
            if (fixedAxis != 2)
            {
                var first = _optic.SurfaceGroup.Items[1].CoordinateSystem.Origin;
                var extent = InfiniteLaunchExtent(EntrancePupilRadius());
                plane = fixedAxis == 1 ? new Vector3D(first.X, first.Y - Math.CopySign(extent, fixedDirection.Y), first.Z)
                    : new Vector3D(first.X - Math.CopySign(extent, fixedDirection.X), first.Y, first.Z);
            }
            var coordinate = fixedAxis == 2 ? plane.Z : fixedAxis == 1 ? plane.Y : plane.X;
            var delta = coordinate - (fixedAxis == 2 ? guess.Z : fixedAxis == 1 ? guess.Y : guess.X);
            guess += fixedDirection * (delta / (fixedAxis == 2 ? fixedDirection.Z : fixedAxis == 1 ? fixedDirection.Y : fixedDirection.X));
            (x, y) = fixedAxis == 2 ? (guess.X, guess.Y) : fixedAxis == 1 ? (guess.X, guess.Z) : (guess.Y, guess.Z);
        }
        var map = new DelegateStopMap(Sample);
        if (!StopAimingSolver.Solve(ref map,targetX,targetY,tolerance,ref x,ref y,out residual))
        {
            if (!infinite || fixedAxis == 2 || !double.IsFinite(residual)) return false;
            // A transverse launch plane is a free longitudinal datum. Rounded
            // intersections can leave no representable solution on that exact
            // plane even after the in-plane stencil. Inspect four other planes,
            // projecting the same stalled ray onto each before solving again.
            // The incident direction, pupil target and strict traced residual
            // stay unchanged; no angular clamp or native reference enters here.
            var stalled = Geometry(x, y).Origin;
            var coordinate = fixedAxis == 1 ? plane.Y : plane.X;
            var firstOrigin=_optic.SurfaceGroup.Items[1].CoordinateSystem.Origin;
            var datum=fixedAxis==1?firstOrigin.Y:firstOrigin.X;
            var solved = false;
            foreach (var factor in new[]{.5,.75,1.25,1.5})
            {
                var adjacent = datum+(coordinate-datum)*factor;
                plane = fixedAxis == 1 ? plane with { Y = adjacent } : plane with { X = adjacent };
                var projected = stalled + fixedDirection * ((adjacent - coordinate)
                    / (fixedAxis == 1 ? fixedDirection.Y : fixedDirection.X));
                (x, y) = fixedAxis == 1 ? (projected.X, projected.Z) : (projected.Y, projected.Z);
                solved = StopAimingSolver.Solve(ref map, targetX, targetY, tolerance, ref x, ref y, out residual);
                if(solved)break;
            }
            if (!solved) return false;
        }
        (aimedOrigin,aimedDirection)=Geometry(x,y);
        return true;

        (Vector3D Origin, Vector3D Direction) Geometry(double u, double v) => infinite
            ? (fixedAxis == 2 ? new Vector3D(u, v, plane.Z)
                : fixedAxis == 1 ? new Vector3D(u, plane.Y, v) : new Vector3D(plane.X, u, v), fixedDirection)
            : (baseOrigin, Normalize(new Vector3D(u, v, 1)));

        bool Sample(double u, double v, out Vector3D point)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            point = default;
            if (!double.IsFinite(u) || !double.IsFinite(v)) return false;
            var (origin, direction) = Geometry(u, v);
            var sample = _optic.SequentialRayTracer.TraceToSurface(
                new RealRay(origin, direction, wavelengthNanometers), stopIndex);
            if (sample is null || sample.Vignetted) return false;
            point = stop.CoordinateSystem.ToLocalPoint(sample.Position);
            return double.IsFinite(point.X) && double.IsFinite(point.Y);
        }
    }
    private delegate bool StopSample(double x,double y,out Vector3D point);
    private readonly record struct DelegateStopMap(StopSample Sampler) : IStopMap
    {
        public bool Sample(double x,double y,out Vector3D point) => Sampler(x,y,out point);
    }

}
