$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$target=Join-Path $root 'reference-aligned'
if(Test-Path -LiteralPath $target){throw 'Fresh output required'}
New-Item -ItemType Directory -Path $target | Out-Null
$jobs=@();$manifest=@()
foreach($item in @(Get-Content (Join-Path $root 'request-manifest.json') -Raw|ConvertFrom-Json)) {
    if($item.kind -eq 'fft-energy'){continue}
    $request=Get-Content -LiteralPath $item.request -Raw|ConvertFrom-Json
    $id=Split-Path $item.output -Leaf
    if($item.kind -eq 'fan') {
        $request|Add-Member -NotePropertyName referencePrimaryWavelength -NotePropertyValue $request.wavelength
        $id+='-selected-primary'
    } else {
        $angles=@(0,10,45,80,89,89.8,89.99,90,90.01,90.2,90.3,90.4,91,95,100)
        if($id.Contains('210-degree')){$angles+=105;$max=105.0}else{$max=100.0}
        $points=@()
        foreach($angle in $angles) {
            foreach($p in @(@(0,0),@(.001,0),@(0,.001))) {
                $points+=@{hx=0;hy=$angle/$max;px=$p[0];py=$p[1];requestedAngle=$angle}
            }
        }
        $request.pointInputs=$points
        $id+='-horizon'
    }
    $folder=Join-Path $target $id
    New-Item -ItemType Directory -Path $folder | Out-Null
    $path=Join-Path $folder 'request.json'
    $request|ConvertTo-Json -Depth 40|Set-Content -LiteralPath $path -Encoding utf8
    $jobs+=@{id=$id;request=$path;output=$folder}
    $manifest+=@{originalKeys=$item.originalKeys;kind=$item.kind;request=$path;output=$folder;sourceSha256=$item.sourceSha256}
}
ConvertTo-Json -InputObject $jobs -Depth 10|Set-Content (Join-Path $target 'native-jobs.json') -Encoding utf8
ConvertTo-Json -InputObject $manifest -Depth 10|Set-Content (Join-Path $target 'request-manifest.json') -Encoding utf8
