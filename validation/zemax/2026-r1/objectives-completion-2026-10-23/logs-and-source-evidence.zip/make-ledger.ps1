$ErrorActionPreference='Stop'
$run=$PSScriptRoot
$repo=(Resolve-Path (Join-Path $run '../../..')).Path
$destination=Join-Path $repo 'validation/zemax/2026-r1/objectives-completion-2026-10-23'
$previous=Join-Path $repo 'validation/zemax/2026-r1/objectives-repair-2026-10-23'
$oldRun=Join-Path $repo 'artifacts/validation/objectives-repair-20261023'
$original=@(Get-Content (Join-Path $oldRun 'final-frozen/summary.json') -Raw|ConvertFrom-Json|Where-Object conclusion -eq Incomparable)
$points=@(Get-Content (Join-Path $run 'final-points/summary.json') -Raw|ConvertFrom-Json)
$controls=@(Get-Content (Join-Path $run 'final-controls/summary.json') -Raw|ConvertFrom-Json)
$pointManifest=@(Get-Content (Join-Path $run 'native-final-fans-v2/request-manifest.json') -Raw|ConvertFrom-Json)
$controlManifest=@(Get-Content (Join-Path $run 'final-controls-manifest/request-manifest.json') -Raw|ConvertFrom-Json)
if($original.Count-ne52-or$points.Count-ne30-or$controls.Count-ne22){throw 'Unexpected evidence shape'}
$ledger=@()
foreach($row in $original){
    $match=@($points|Where-Object key -eq $row.key)
    $isPoint=$match.Count-eq1
    if($isPoint){$result=$match[0];$manifest=@($pointManifest|Where-Object {$row.key -in $_.originalKeys})[0]}
    else{$match=@($controls|Where-Object originalKey -eq $row.key);if($match.Count-ne1){throw "Missing/duplicate result: $($row.key)"};$result=$match[0];$manifest=@($controlManifest|Where-Object originalKey -eq $row.key)[0]}
    if($result.conclusion-ne'Pass'){throw "Unpassed supplemental result: $($row.key)"}
    $request=Get-Content -LiteralPath $manifest.request -Raw|ConvertFrom-Json
    $ftheta=$request.workbenchSettings.DistortionType-eq'F-Theta'
    $route=if($isPoint){'NativeExplicitFan'}elseif($ftheta){'FThetaFullFieldPlot'}else{'HigherSampling'}
    $reference=Join-Path $manifest.output $(if($isPoint){'point-reference.json'}else{'data.json'})
    $ledger+=@{originalKey=$row.key;originalConclusion='Incomparable';supplementalConclusion='Pass';route=$route;
        originalReferenceSha256=$row.referenceSha256;requestPath=$manifest.request;requestSha256=(Get-FileHash $manifest.request).Hash.ToLowerInvariant();
        referencePath=$reference;referenceSha256=(Get-FileHash $reference).Hash.ToLowerInvariant();sourceSha256=(Get-FileHash $request.input).Hash.ToLowerInvariant();
        pupilSampling=$request.pupilSampling;imageSampling=$request.imageSampling;primaryWavelengthMicrometers=$request.primaryWavelengthMicrometers;
        settingsDelta=$(if($isPoint){'Independent explicit batch; selected wavelength made primary on both sides; native thickness solves frozen without rewriting values.'}elseif($ftheta){'F-Tan(Theta) changed to F-Theta on both sides; 101 native samples through 100/105 degrees.'}else{'Higher pupil/image sampling; see exact request and native output grid readbacks.'});
        physicalRayGate=$(if($isPoint){'Pass: identical acceptance and strict original every-surface coordinate/direction limits'}elseif($ftheta){'Not certified near 90 degrees; native normalized launches clamp near the horizon'}else{'Analysis-only control'});
        metrics=$result.metrics}
}
if(@($ledger.originalKey|Sort-Object -Unique).Count-ne52){throw 'Original-key identity differs'}
$ledger|ConvertTo-Json -Depth 30|Set-Content (Join-Path $destination 'comparison-ledger.json') -Encoding utf8
$ledger|Select-Object originalKey,originalConclusion,supplementalConclusion,route,pupilSampling,imageSampling,primaryWavelengthMicrometers,physicalRayGate,settingsDelta|Export-Csv (Join-Path $destination 'comparison-ledger.csv') -NoTypeInformation -Encoding utf8
$groups=@(Get-ChildItem (Join-Path $run 'final-points') -Directory|ForEach-Object {Get-Content (Join-Path $_.FullName 'ray-comparison.json') -Raw|ConvertFrom-Json})
$sources=@();$sourceRoot=Join-Path $run 'sources/Objectives';New-Item -ItemType Directory -Path $sourceRoot -Force|Out-Null
foreach($source in Get-ChildItem (Join-Path $oldRun 'native-original/sources/Objectives') -File){
    $target=Join-Path $sourceRoot $source.Name;Copy-Item -LiteralPath $source.FullName -Destination $target
    $hash=(Get-FileHash $source.FullName).Hash.ToLowerInvariant();$product=Join-Path $repo ('src/OpticalSystemDesign.App/Assets/SequentialExamples/Objectives/'+$source.Name)
    if($hash-ne(Get-FileHash $product).Hash.ToLowerInvariant()){throw 'Original source changed'}
    $sources+=@{lens=$source.Name;sha256=$hash}
}
$sources|ConvertTo-Json -Depth 5|Set-Content (Join-Path $destination 'source-integrity.json') -Encoding utf8
$summary=@{date='2026-10-23';scope='Objectives: 19 original lenses';sources=$sources.Count;
    originalFrozenMatrix=@{Pass=586;Incomparable=52;Close=0;Difference=0;Error=0;replaced=$false;current638Replay=$false};
    supplemental=@{Pass=52;HigherSampling=20;NativeExplicitFan=30;FThetaFullFieldPlot=2;fullPhysicalHorizonCertification=$false};
    rays=@{groups=$groups.Count;inputs=($groups|Measure-Object inputs -Sum).Sum;compared=($groups|Measure-Object compared -Sum).Sum;maskMismatches=($groups|Measure-Object maskMismatches -Sum).Sum;coordinateFailures=($groups|Measure-Object coordinateFailures -Sum).Sum;directionFailures=($groups|Measure-Object directionFailures -Sum).Sum;maximumCoordinateMillimeters=($groups|Measure-Object maximumCoordinate -Maximum).Maximum;maximumDirection=($groups|Measure-Object maximumDirection -Maximum).Maximum};
    identity=(Get-Content (Join-Path $run 'final-points/identity.json') -Raw|ConvertFrom-Json);
    limitations=@('Original settings/references and tolerances are immutable; supplemental Pass is not an original-request Pass.','F-Theta plots cover 101 native samples through 100/105 degrees, but normalized native launches near 90 degrees alter the angle.','Rejected launch-plane experiments: 2/6 passed, 4/6 failed or timed out; candidate withdrawn. Additional 89.99/90.01 degree strict pupil aiming is not certified.','No full test suite, independent Cooke/Tessar certification, remote push or installer release.');
    dependencies=@(Get-ChildItem $previous -Filter '*.zip'|ForEach-Object { @{path=$_.Name;sha256=(Get-FileHash $_.FullName).Hash.ToLowerInvariant()} })}
if($summary.identity.policySha256-ne'30c27e7976710867d0edc6dd4099edac54ca9e070245dea679b3afdd88fd28f5'){throw 'Policy changed'}
$summary|ConvertTo-Json -Depth 20|Set-Content (Join-Path $destination 'summary.json') -Encoding utf8
