using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Capabilities;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Coatings;
using OpticalSystemDesign.Core.Interactions;
using OpticalSystemDesign.Core.Geometries;
using OpticalSystemDesign.Core.Materials;
using OpticalSystemDesign.Core.Propagation;
using OpticalSystemDesign.Core.Rays;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Raytrace;

public sealed record SequentialTrace(
    IReadOnlyList<IReadOnlyList<RayTraceSample>> RayHistories,
    SurfaceTraceData SurfaceTraceData);

public sealed partial class SequentialRayTracer
{
    private readonly Optic _optic;
    private RayTraceCache? _traceCache;
    private long _cacheOpticRevision;

    public SequentialRayTracer(Optic optic)
    {
        _optic = optic;
        RayGenerator = new RayGenerator(optic);
    }

    public RayGenerator RayGenerator { get; }

    internal void ConfigureCache(RayTraceCache? cache, long opticRevision)
    {
        _traceCache = cache;
        _cacheOpticRevision = opticRevision;
    }

    public SequentialTrace Trace()
    {
        var bundle = RayGenerator.Generate();
        return Trace(bundle);
    }

    public SequentialTrace TraceNormalized(
        double normalizedFieldX,
        double normalizedFieldY,
        double wavelengthMicrometers,
        int sampleCount = 100,
        string distribution = "hexapolar")
    {
        var bundle = RayGenerator.GenerateNormalized(
            normalizedFieldX,
            normalizedFieldY,
            wavelengthMicrometers,
            sampleCount,
            distribution);
        return Trace(bundle);
    }

    public SequentialTrace TraceGeneric(
        double normalizedFieldX,
        double normalizedFieldY,
        double normalizedPupilX,
        double normalizedPupilY,
        double wavelengthMicrometers)
    {
        var bundle = RayGenerator.GenerateGeneric(
            normalizedFieldX,
            normalizedFieldY,
            normalizedPupilX,
            normalizedPupilY,
            wavelengthMicrometers);
        return Trace(bundle);
    }
    public RayTraceSample? TraceGenericFinalSample(
        double normalizedFieldX,
        double normalizedFieldY,
        double normalizedPupilX,
        double normalizedPupilY,
        double wavelengthMicrometers,
        bool aimAtStop = false)
    {
        var bundle = RayGenerator.GenerateGeneric(
            normalizedFieldX,
            normalizedFieldY,
            normalizedPupilX,
            normalizedPupilY,
            wavelengthMicrometers,
            aimAtStop: aimAtStop);
        if (_optic.SurfaceGroup.Items.Count == 0)
        {
            return null;
        }

        var surfaceIndex = _optic.SurfaceGroup.Items.Count - 1;
        using var trace = Trace(bundle, TraceRequest.FinalOnly(false));
        return trace.TryGetSample(0, surfaceIndex, out var sample) ? sample.ToRayTraceSample() : null;
    }

    public RayTraceSample? TraceGenericSurfaceSample(
        double normalizedFieldX,
        double normalizedFieldY,
        double normalizedPupilX,
        double normalizedPupilY,
        double wavelengthMicrometers,
        int surfaceIndex,
        bool aimAtStop = false)
    {
        if (surfaceIndex < 0 || surfaceIndex >= _optic.SurfaceGroup.Items.Count)
        {
            return null;
        }

        var bundle = RayGenerator.GenerateGeneric(
            normalizedFieldX,
            normalizedFieldY,
            normalizedPupilX,
            normalizedPupilY,
            wavelengthMicrometers,
            aimAtStop);
        using var trace = Trace(bundle, TraceRequest.Selected(new[] { surfaceIndex }));
        return trace.TryGetSample(0, surfaceIndex, out var sample)
            ? sample.ToRayTraceSample()
            : null;
    }


    public IReadOnlyList<RayTraceSample?> TraceFinalSamples(RealRayBundle bundle)
    {
        if (_optic.SurfaceGroup.Items.Count == 0)
        {
            return new RayTraceSample?[bundle.Rays.Count];
        }

        var finalSurfaceIndex = _optic.SurfaceGroup.Items.Count - 1;
        using var trace = Trace(bundle, TraceRequest.FinalOnly(false));
        var values = trace.GetSurfaceSamples(finalSurfaceIndex);
        var samples = new RayTraceSample?[trace.RayCount];
        for (var index = 0; index < samples.Length; index++)
        {
            if (values[index] is { } value)
            {
                samples[index] = value.ToRayTraceSample();
            }
        }

        return samples;
    }
    internal RayTraceSample? TraceToSurface(RealRay sourceRay, int surfaceIndex)
    {
        OpticCapabilityPreflight.EnsureSupported(_optic, OpticCapabilityOperation.RayTrace);
        if (surfaceIndex < 0 || surfaceIndex >= _optic.SurfaceGroup.Items.Count)
        {
            return null;
        }

        SequentialTraceMeasurement.Record(1);
        var ray = sourceRay.Normalize();
        var currentMaterial = ResolveMaterial("Air");
        var cumulativePathLength = 0.0;
        var cumulativeOpticalPathLength = 0.0;

        for (var index = 0; index <= surfaceIndex; index++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var surface = _optic.SurfaceGroup.Items[index];
            var result = TraceSequentialSurface(
                surface,
                index,
                RayState.FromRealRay(ray),
                currentMaterial,
                cumulativePathLength,
                cumulativeOpticalPathLength,
                ignorePhysicalAperture: true,
                allowVirtualIntersection: AllowsReferenceBacktrack(_optic.SurfaceGroup.Items, index));
            if (index == surfaceIndex)
            {
                return result.Sample.ToRayTraceSample();
            }

            if (result.StopTracing)
            {
                return null;
            }

            ray = result.Ray.ToRealRay();
            currentMaterial = result.OutgoingMaterial;
            cumulativePathLength = result.CumulativePathLength;
            cumulativeOpticalPathLength = result.CumulativeOpticalPathLength;
        }

        return null;
    }

    private bool AllowsReferenceBacktrack(IList<OpticalSurface> surfaces, int index)
    {
        // An ordered plane has a unique signed intercept. This includes virtual
        // image/reference planes and a plane face slightly overlapped by the
        // preceding sag. Its actual aperture and interaction remain in force.
        if (index > 0 && surfaces[index].Geometry is PlaneGeometry) return true;
        if (index == 1 && ObjectConjugate.IsInfinite(surfaces[0])) return true;
        if (index <= 1) return false;
        var previous = surfaces[index - 1];
        if (previous.IsReflective
            || previous.InteractionModel is not RefractiveReflectiveInteractionModel { IsReflective: false }
            || previous.CoatingModel is not NoneCoatingModel || previous.ScatteringModel is not null
            || previous.MaterialBefore.PropagationModel is not HomogeneousPropagationModel
            || previous.MaterialAfter.PropagationModel is not HomogeneousPropagationModel) return false;
        return _optic.Wavelengths.All(w =>
            previous.MaterialBefore.RefractiveIndex(w.Micrometers * 1000) == previous.MaterialAfter.RefractiveIndex(w.Micrometers * 1000)
            && previous.MaterialBefore.ExtinctionCoefficient(w.Micrometers * 1000) == 0
            && previous.MaterialAfter.ExtinctionCoefficient(w.Micrometers * 1000) == 0);
    }

    private static SurfaceRayTraceStateResult TraceSequentialSurface(
        OpticalSurface surface,
        int surfaceIndex,
        RayState ray,
        IMaterial materialBefore,
        double cumulativePathLength,
        double cumulativeOpticalPathLength,
        bool ignorePhysicalAperture = false,
        bool stopBeforeInteraction = false,
        bool bypassCoating = false,
        bool allowVirtualIntersection = false,
        bool ignoreMaterialAbsorption = false)
    {
        if (surfaceIndex == 0 && ObjectConjugate.IsInfinite(surface))
        {
            if (surface.MaterialAfter is GradientIndexMaterial)
                throw new NotSupportedException("无限远物方的 GRIN 体坐标和传播边界尚未定义。");
            // An infinite object has no finite intercept plane. Keep the launch
            // point; advancing to its placeholder Z can jump past a concave face.
            return new SurfaceRayTraceStateResult(
                ray,
                new RayTraceSampleValue(surface.Number, surface.Label, ray.Origin,
                    ray.Direction, ray.Intensity, false,
                    CumulativePathLength: cumulativePathLength,
                    CumulativeOpticalPathLength: cumulativeOpticalPathLength,
                    IncidentDirection: ray.Direction,
                    PhaseInclusiveOpticalPathLength: ray.OpticalPathDifference),
                surface.MaterialAfter.RefractiveIndex(ray.WavelengthNanometers),
                surface.MaterialAfter,
                null,
                cumulativePathLength,
                cumulativeOpticalPathLength,
                !ray.CanTrace);
        }

        return surface.TraceRayState(ray, materialBefore, surface.MaterialAfter,
            cumulativePathLength, cumulativeOpticalPathLength, ignorePhysicalAperture, stopBeforeInteraction, bypassCoating,
            allowVirtualIntersection: allowVirtualIntersection, ignoreMaterialAbsorption: ignoreMaterialAbsorption);
    }

    public SequentialTrace Trace(RealRayBundle bundle)
    {
        using var requested = Trace(bundle, TraceRequest.FullHistory(recordSurfaceData: false));
        var histories = MaterializeHistories(requested);
        var surfaceTraceData = BuildSurfaceTraceData(_optic.SurfaceGroup.Items, histories);
        _optic.SurfaceGroup.RecordTrace(surfaceTraceData);
        return new SequentialTrace(histories, surfaceTraceData);
    }

    public RequestedTrace Trace(RealRayBundle bundle, TraceRequest request)
    {
        ArgumentNullException.ThrowIfNull(bundle);
        ArgumentNullException.ThrowIfNull(request);
        OpticCapabilityPreflight.EnsureSupported(_optic, OpticCapabilityOperation.RayTrace);

        if (request.MaxDegreeOfParallelism is 0 or < -1)
        {
            throw new ArgumentOutOfRangeException(
                nameof(request),
                "MaxDegreeOfParallelism must be -1 or a positive value.");
        }
        request = request with
        {
            MaxDegreeOfParallelism = ComputationParallelism.ResolveMaxDegreeOfParallelism(request.MaxDegreeOfParallelism)
        };
        var surfaces = _optic.SurfaceGroup.Items
            .Select(surface => surface.Clone())
            .ToArray();
        var retainedSurfaceIndices = request.ResolveSurfaceIndices(surfaces.Length);
        if (request.StopAtIncidentSurfaceIndex is { } incident)
        {
            incident = incident < 0 ? surfaces.Length + incident : incident;
            if (incident < 0 || incident >= surfaces.Length
                || retainedSurfaceIndices.Any(index => index > incident)
                || request.NormalizeOpticalPathDifference || request.RecordSurfaceData)
                throw new ArgumentException("Incident-surface traces require a valid terminal surface, no later retention, no final-image OPD normalization and no surface-data recording.", nameof(request));
            request = request with { StopAtIncidentSurfaceIndex = incident };
        }
        if (request.RecordSurfaceData && request.Retention != TraceRetention.FullHistory)
        {
            throw new ArgumentException(
                "Surface trace recording requires FullHistory retention.",
                nameof(request));
        }

        var rayCount = bundle.Rays.Count;
        var retainedCount = retainedSurfaceIndices.Length;
        if (rayCount > SequentialTraceLimits.MaximumRayCount)
        {
            throw new ArgumentOutOfRangeException(
                nameof(bundle),
                $"A sequential trace cannot contain more than {SequentialTraceLimits.MaximumRayCount:N0} rays.");
        }

        var requestedSampleCount = checked((long)rayCount * retainedCount);
        if (requestedSampleCount > SequentialTraceLimits.MaximumRetainedSamples)
        {
            throw new ArgumentOutOfRangeException(
                nameof(request),
                $"A sequential trace cannot retain more than {SequentialTraceLimits.MaximumRetainedSamples:N0} ray/surface samples.");
        }

        var sampleCount = checked((int)requestedSampleCount);
        var samples = System.Buffers.ArrayPool<RayTraceSampleValue>.Shared.Rent(Math.Max(1, sampleCount));
        var hasSamples = System.Buffers.ArrayPool<bool>.Shared.Rent(Math.Max(1, sampleCount));
        Array.Clear(hasSamples, 0, Math.Max(1, sampleCount));
        var requestedTrace = new RequestedTrace(rayCount, retainedSurfaceIndices, samples, hasSamples);

        if (rayCount == 0 || surfaces.Length == 0 || retainedCount == 0)
        {
            return requestedTrace;
        }

        RayTraceCacheKey? cacheKey = null;
        if (!request.RecordSurfaceData
            && _traceCache is not null
            && _traceCache.CanCache(sampleCount))
        {
            cacheKey = RayTraceCacheKey.Create(
                _cacheOpticRevision,
                _optic.Backend.Current.Name,
                request,
                retainedSurfaceIndices,
                bundle.Rays);
            if (_traceCache.TryCopyTo(cacheKey, samples, hasSamples))
            {
                return requestedTrace;
            }
        }

        SequentialTraceMeasurement.Record(rayCount);
        var surfaceSlots = new int[surfaces.Length];
        Array.Fill(surfaceSlots, -1);
        for (var slot = 0; slot < retainedCount; slot++)
        {
            surfaceSlots[retainedSurfaceIndices[slot]] = slot;
        }

        var finalOpticalPaths = request.NormalizeOpticalPathDifference
            ? System.Buffers.ArrayPool<double>.Shared.Rent(rayCount)
            : null;
        var hasFinalOpticalPath = request.NormalizeOpticalPathDifference
            ? System.Buffers.ArrayPool<bool>.Shared.Rent(rayCount)
            : null;
        if (hasFinalOpticalPath is not null)
        {
            Array.Clear(hasFinalOpticalPath, 0, rayCount);
        }

        var ambientMaterial = ResolveMaterial("Air");
        var maximumRequiredSurface = request.StopAtIncidentSurfaceIndex
            ?? (request.NormalizeOpticalPathDifference ? surfaces.Length - 1 : retainedSurfaceIndices[^1]);

        using var initialDirections = PooledDirectionBatch.Create(
            bundle,
            _optic.Backend.CurrentBatched,
            request.UseBatchedBackend);


        try
        {
            TraceSurfaceMajor(
                bundle,
                request,
                surfaces,
                surfaceSlots,
                maximumRequiredSurface,
                samples,
                hasSamples,
                finalOpticalPaths,
                hasFinalOpticalPath,
                initialDirections,
                ambientMaterial);

            if (request.NormalizeOpticalPathDifference)
            {
                NormalizeOpticalPathDifference(
                    samples,
                    hasSamples,
                    sampleCount,
                    finalOpticalPaths!,
                    hasFinalOpticalPath!,
                    rayCount);
            }

            if (request.RecordSurfaceData)
            {
                var histories = MaterializeHistories(requestedTrace);
                _optic.SurfaceGroup.RecordTrace(BuildSurfaceTraceData(surfaces, histories));
            }

            if (cacheKey is not null)
            {
                _traceCache?.Store(cacheKey, samples, hasSamples, sampleCount);
            }

            return requestedTrace;
        }
        catch
        {
            requestedTrace.Dispose();
            throw;
        }
        finally
        {
            if (finalOpticalPaths is not null)
            {
                System.Buffers.ArrayPool<double>.Shared.Return(finalOpticalPaths, clearArray: true);
            }

            if (hasFinalOpticalPath is not null)
            {
                System.Buffers.ArrayPool<bool>.Shared.Return(hasFinalOpticalPath, clearArray: true);
            }
        }
    }

    private static IReadOnlyList<IReadOnlyList<RayTraceSample>> MaterializeHistories(RequestedTrace trace)
    {
        var histories = new IReadOnlyList<RayTraceSample>[trace.RayCount];
        for (var rayIndex = 0; rayIndex < trace.RayCount; rayIndex++)
        {
            var history = new List<RayTraceSample>(trace.RetainedSurfaceIndices.Count);
            foreach (var surfaceIndex in trace.RetainedSurfaceIndices)
            {
                if (trace.TryGetSample(rayIndex, surfaceIndex, out var sample))
                {
                    history.Add(sample.ToRayTraceSample());
                }
            }

            histories[rayIndex] = history.ToArray();
        }

        return histories;
    }

    private static void NormalizeOpticalPathDifference(
        RayTraceSampleValue[] samples,
        bool[] hasSamples,
        int sampleCount,
        double[] finalOpticalPaths,
        bool[] hasFinalOpticalPath,
        int rayCount)
    {
        var sum = 0.0;
        var count = 0;
        for (var rayIndex = 0; rayIndex < rayCount; rayIndex++)
        {
            if (hasFinalOpticalPath[rayIndex])
            {
                sum += finalOpticalPaths[rayIndex];
                count++;
            }
        }

        if (count == 0)
        {
            return;
        }

        var reference = sum / count;
        for (var index = 0; index < sampleCount; index++)
        {
            if (hasSamples[index])
            {
                samples[index] = samples[index] with
                {
                    OpticalPathDifference = samples[index].CumulativeOpticalPathLength - reference
                };
            }
        }
    }

    private IMaterial ResolveMaterial(string material)
    {
        return _optic.Materials.Resolve(material);
    }

    private static SurfaceTraceData BuildSurfaceTraceData(
        IReadOnlyList<OpticalSurface> surfaces,
        IReadOnlyList<IReadOnlyList<RayTraceSample>> histories)
    {
        if (surfaces.Count == 0)
        {
            return SurfaceTraceData.Empty;
        }

        var records = surfaces
            .Select(surface =>
            {
                var samples = histories
                    .Select(history => history.FirstOrDefault(sample => sample.SurfaceNumber == surface.Number))
                    .ToArray();

                return new SurfaceTraceRecord(
                    surface.Number,
                    surface.Label,
                    samples.Select(sample => sample?.Position.X ?? double.NaN).ToArray(),
                    samples.Select(sample => sample?.Position.Y ?? double.NaN).ToArray(),
                    samples.Select(sample => sample?.Position.Z ?? double.NaN).ToArray(),
                    samples.Select(sample => sample?.Direction.X ?? double.NaN).ToArray(),
                    samples.Select(sample => sample?.Direction.Y ?? double.NaN).ToArray(),
                    samples.Select(sample => sample?.Direction.Z ?? double.NaN).ToArray(),
                    samples.Select(sample => sample?.Intensity ?? 0.0).ToArray(),
                    samples.Select(sample => sample?.OpticalPathDifference ?? double.NaN).ToArray(),
                    samples.Select(sample => sample?.CumulativeOpticalPathLength ?? double.NaN).ToArray());
            })
            .ToArray();

        return new SurfaceTraceData(records);
    }
}
