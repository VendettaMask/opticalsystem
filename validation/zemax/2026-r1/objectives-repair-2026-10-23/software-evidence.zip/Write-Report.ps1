$ErrorActionPreference='Stop'
$repo='D:\Projects\opticalsystem'
$run=Join-Path $repo 'artifacts/validation/objectives-repair-20261023'
$out=Join-Path $repo 'validation/zemax/2026-r1/objectives-repair-2026-10-23'
$baseline=Join-Path $repo 'artifacts/zemax-sequential-corpus/20261021/full-v1'
function Read([string]$p){Get-Content -Raw -LiteralPath $p|ConvertFrom-Json}
function Hash([string]$p){(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}
function Counts($items){$r=[ordered]@{};foreach($g in @($items|Group-Object)){$r[$g.Name]=$g.Count};$r}
$rows=@(Read (Join-Path $run 'final-contract/summary.json'))
$computed=@(Read (Join-Path $run 'final-frozen/summary.json'))
$rays=@(Read (Join-Path $run 'final-rays/summary.json'))
$controls=@(Read (Join-Path $run 'final-controls/summary.json'))
$repeat=@(Read (Join-Path $run 'final-native/summary.json'))
if($rows.Count -ne 638 -or $computed.Count -ne 638 -or $rays.Count -ne 74 -or $controls.Count -ne 26 -or $repeat.Count -ne 89){throw 'Final evidence is incomplete'}
$identity=Read (Join-Path $run 'final-frozen/identity.json')
foreach($p in 'final-rays/identity.json','final-controls/identity.json','final-native/identity.json','final-contract/identity.json'){
    if((Read (Join-Path $run $p)).coreSha256 -cne $identity.coreSha256){throw 'Core identity mismatch'}
}
if($identity.coreSha256 -cne (Hash (Join-Path $repo 'src/OpticalSystemDesign.Core/bin/Debug/net10.0/OpticalSystemDesign.Core.dll'))){throw 'Current Core differs'}
if($identity.policySha256 -cne (Hash (Join-Path $baseline 'comparison-settings.json'))){throw 'Policy changed'}
$original=@(Read (Join-Path $baseline 'analysis-results.json')|Where-Object {$_.lens.StartsWith('Objectives/')})
$lookup=@{};foreach($item in $original){$q=$item.run.request;$key="$($item.lens)|$($item.configuration)|$($item.scope)|$($q.canonicalAnalysisKey)|$($q.field)|$($q.wavelength)|$($q.pupilSampling)";$lookup[$key]=$item}
$flat=@();$manifest=@();$byKey=@{}
foreach($r in $rows){
    $item=$lookup[$r.key];if(-not $item){throw 'Unrecognized original request'}
    $data=Join-Path $run ('final-frozen/'+$item.run.directory+'/data.json')
    if((Hash $data) -cne $r.dataSha256){throw 'Current data changed'}
    if(@($computed|Where-Object key -eq $r.key)[0].dataSha256 -cne $r.dataSha256){throw 'Offline comparison changed computation bytes'}
    if($r.referenceSha256 -and (Hash $r.referencePath) -cne $r.referenceSha256){throw 'Reference changed'}
    $q=$item.run.request
    $flat+=[pscustomobject]@{Key=$r.key;Lens=$item.lens;Analysis=$q.canonicalAnalysisKey;Configuration=$q.configuration;Scope=$item.scope;
        Field=$q.field;Wavelength=$q.wavelength;PupilSampling=$q.pupilSampling;Conclusion=$r.conclusion;Reason=$r.reason}
    $manifest+=@{key=$r.key;request=$q;softwareSha256=$r.dataSha256;referencePath=$r.referencePath;referenceSha256=$r.referenceSha256}
    $byKey[$r.key]=$r
}
$sources=@();foreach($lens in @($flat.Lens|Sort-Object -Unique)){
    $current=Hash (Join-Path $repo ('src/OpticalSystemDesign.App/Assets/SequentialExamples/'+$lens))
    $frozen=Hash (Join-Path $baseline ('sources/'+$lens))
    if($current -cne $frozen){throw 'Original lens changed'}
    $sources+=@{lens=$lens;sha256=$current;unchanged=$true}
}
$oldPass=@(Import-Csv (Join-Path $repo 'artifacts/validation/objectives-20261020/report-final-v7/analysis-matrix.csv')|Where-Object Conclusion -eq 'Pass')
$regressions=@();foreach($p in $oldPass){$k="$($p.Lens)|$($p.Configuration)|$($p.Scope)|$($p.Analysis)|$($p.Field)|$($p.Wavelength)|$($p.PupilSampling)";if($byKey[$k].conclusion -ne 'Pass'){$regressions+=$k}}
$before=@(Import-Csv (Join-Path $repo 'validation/zemax/2026-r1/objectives-recheck-2026-10-23/analysis-matrix.csv')|Where-Object Conclusion -eq 'Pass')
$beforeRegressions=@($before|Where-Object {$byKey[$_.Key].conclusion -ne 'Pass'}|ForEach-Object Key)
$nativeInvariants=@(Read (Join-Path $run 'native-original-integrity.json'))
if(@($nativeInvariants|Where-Object {-not $_.requestEqualIgnoringInput}).Count -ne 0){throw 'Repeat request changed'}
$repeatDifferences=@($repeat|Where-Object {$byKey[$_.key].conclusion -ne $_.conclusion}|ForEach-Object key)
$firstOrderDelta=0.0
foreach($r in $repeat|Where-Object key -like '*|First Order|*'){
    $old=Read $byKey[$r.key].referencePath;$fresh=Read $r.referencePath
    foreach($p in $old.scalars.psobject.Properties){$firstOrderDelta=[Math]::Max($firstOrderDelta,[Math]::Abs([double]$p.Value-[double]$fresh.scalars.($p.Name)))}
}
$perLens=@($flat|Group-Object Lens|ForEach-Object {$lens=$_.Name;@{lens=$lens;requests=$_.Count;analysis=(Counts $_.Group.Conclusion);rays=(Counts @($rays|Where-Object lens -eq $lens).conclusion)}})
$summary=[ordered]@{date='2026-10-23';scope='All 19 Objectives lenses; original 638 requests and 74 GQ6 groups';baseCommit=(git -C $repo rev-parse HEAD);
    productionCodeChanged=$true;softwareComputationRoot='final-frozen';finalContractRecompareRoot='final-contract';lensCount=$sources.Count;originalAnalysisCounts=(Counts $flat.Conclusion);originalRequests=$rows.Count;
    softwareDataFiles=$manifest.Count;rayCounts=(Counts $rays.conclusion);rayGroups=$rays.Count;rayInputs=($rays|Measure-Object inputs -Sum).Sum;
    physicalSurfaceComparisons=($rays|Measure-Object comparisons -Sum).Sum;maximumCoordinateDifferenceMillimeters=($rays|Measure-Object maximumPosition -Maximum).Maximum;
    maximumDirectionDifference=($rays|Measure-Object maximumDirection -Maximum).Maximum;acceptanceDifferences=($rays|Measure-Object acceptance -Sum).Sum;
    firstClipDifferences=($rays|Measure-Object firstClip -Sum).Sum;preserved20261020Pass=($oldPass.Count-$regressions.Count);previous20261020Pass=$oldPass.Count;
    preservedPreRepairPass=($before.Count-$beforeRegressions.Count);preRepairPass=$before.Count;regressions=$regressions;preRepairRegressions=$beforeRegressions;
    nativeOriginalRepeatRequests=$repeat.Count;nativeRepeatCounts=(Counts $repeat.conclusion);repeatConclusionChanges=$repeatDifferences;
    nativeOriginalRequestsEqualIgnoringInput=$true;nativeFirstOrderControls=19;nativeFirstOrderMaximumScalarChange=$firstOrderDelta;
    supplementalRequests=$controls.Count;supplementalCounts=(Counts $controls.conclusion);supplementalSamplingChanged=$true;
    coreSha256=$identity.coreSha256;policySha256=$identity.policySha256;nativeReference='OpticStudio 2026 R1; frozen 2026-10-21 and independent 2026-10-23 repeats';
    tests=@{corePassed=82;nativeAndComparisonPassed=29;distinctPassed=111;skipped=0;failed=0;fullSuiteRun=$false};
    incomparableReasons=@($flat|Where-Object Conclusion -eq 'Incomparable'|Group-Object Reason|ForEach-Object {@{count=$_.Count;reason=$_.Name}});
    lenses=$perLens;release=(Read (Join-Path $run 'application-launch.json'))}
ConvertTo-Json -InputObject $summary -Depth 16|Set-Content (Join-Path $out 'summary.json') -Encoding utf8
ConvertTo-Json -InputObject $manifest -Depth 60|Set-Content (Join-Path $out 'request-reference-manifest.json') -Encoding utf8
ConvertTo-Json -InputObject $sources -Depth 8|Set-Content (Join-Path $out 'source-integrity.json') -Encoding utf8
$flat|Export-Csv (Join-Path $out 'analysis-matrix.csv') -NoTypeInformation -Encoding utf8
Copy-Item (Join-Path $run 'final-rays/summary.json') (Join-Path $out 'ray-results.json')
Copy-Item (Join-Path $run 'final-controls/summary.json') (Join-Path $out 'supplemental-results.json')
Copy-Item (Join-Path $run 'final-native/summary.json') (Join-Path $out 'native-repeat-results.json')
$text=[Collections.Generic.List[string]]::new();$text.Add('# Objectives 全部 19 支镜头精度修复与对比');$text.Add('')
$text.Add('日期：2026-10-23。正式 C# Core/Application 重新导入并计算全部原请求；原始输入、冻结 Zemax 数组和容差未修改。');$text.Add('')
$text.Add('原 638 项：**'+$summary.originalAnalysisCounts.Pass+' Pass / '+$summary.originalAnalysisCounts.Incomparable+' 不可比较 / 0 Close / 0 Difference / 0 Error**。全部 638 项产生新数据。74/74 组逐面光线通过，13320 条输入光线，145841 次有效表面比较；接受/首次裁光差异均为零。');$text.Add('')
$text.Add('保留原 2026-10-20 的 564/564 Pass，以及修复前本次审计的 568/568 Pass。89 个原设置独立重采集，与软件得到 37 Pass / 52 不可比较，结论与冻结参考完全一致；19 个一阶控制的原生标量最大变化为 '+$firstOrderDelta+'。26 个另列高采样控制得到 22 Pass / 4 不可比较，没有 Close 或 Difference；不替换原请求。');$text.Add('')
$text.Add('| 镜头 | 原请求 P/C/D/I/E | 光线组通过 |');$text.Add('|---|---:|---:|')
foreach($lens in $perLens){$a=@('Pass','Close','Difference','Incomparable','Error')|ForEach-Object {if($lens.analysis.Contains($_)){$lens.analysis[$_]}else{0}};$text.Add('| '+($lens.lens -replace '^Objectives/','')+' | '+($a -join '/')+' | '+$lens.rays.Pass+' |')}
$text.Add('');$text.Add('## 保留限制');$text.Add('')
$text.Add('- 原请求的 30 项光扇/OPD 有效性掩码差异、20 项无效/低采样/空原生输出、2 项超广角场曲覆盖不足继续记为不可比较。原生场曲只到 89°，不能证明完整 100°/105° 半视场。');
$text.Add('- 零视场通过仅认证轴上单点。光扇缺点不会被补零、跨缺点插值或伪造为实际裁光。即使批量光线通过，原生曲线没有相应有效数据时也不升级为精度通过。');
$text.Add('- Even Asphere 的能量在 512 采样下原生仍警告取样太低。其余低采样原请求也保持原状态，高采样结果另列。');
$text.Add('- 仅覆盖这 19 支镜头与明确请求，未跑全测试、全部 95 支目录、所有采样/视场组合，未发布安装包。');$text.Add('')
$text.Add('## 证据');$text.Add('')
$text.Add('- [修复说明](../../../../docs/OBJECTIVES_PRECISION_REPAIR_2026-10-23.md)、[机器汇总](summary.json)、[原请求矩阵](analysis-matrix.csv)、[请求及数据哈希](request-reference-manifest.json)、[输入完整性](source-integrity.json)。');
$text.Add('- [原生重采集结果](native-repeat-results.json)、[补充采样结果](supplemental-results.json)、[逐面光线结果](ray-results.json)。');
$text.Add('- [原生完整证据](native-evidence.zip)及[逐文件哈希](native-evidence.zip.manifest.json)保留 132 次原生请求尝试，包括无效与拒绝控制。软件、光线和失败阶段分开归档；派生图和 API/可执行二进制不进入归档。');
$text.Add('- 完成的定向测试为 Core 82/82、比较与原生回归 29/29，共 111 项，包含实际 CUDA；默认 Release 构建成功并启动。');
$text.Add('- 当前 Debug Core SHA-256：`'+$identity.coreSha256+'`；原容差策略 SHA-256：`'+$identity.policySha256+'`。');
$text|Set-Content (Join-Path $out 'README.md') -Encoding utf8
$summary|Select-Object originalAnalysisCounts,rayCounts,supplementalCounts,nativeRepeatCounts,regressions,repeatConclusionChanges|ConvertTo-Json -Depth 5
