$ErrorActionPreference='Stop'
$repo='D:\Projects\opticalsystem'
$run=Join-Path $repo 'artifacts/validation/objectives-repair-20261023/native-original'
if(Test-Path -LiteralPath $run){throw 'Fresh native directory required.'}
New-Item -ItemType Directory -Path $run | Out-Null
$problemRows=@(Import-Csv -LiteralPath (Join-Path $repo 'validation/zemax/2026-r1/objectives-recheck-2026-10-23/analysis-matrix.csv') | Where-Object Conclusion -ne 'Pass')
$selected=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $problemRows){[void]$selected.Add($row.Key)}
$items=@(Get-Content -Raw -LiteralPath (Join-Path $repo 'artifacts/zemax-sequential-corpus/20261021/full-v1/analysis-results.json') | ConvertFrom-Json)
$jobs=@();$manifest=@()
foreach($item in $items){
    if(-not $item.lens.StartsWith('Objectives/')){continue}
    $q=$item.run.request
    $key="$($item.lens)|$($item.configuration)|$($item.scope)|$($q.canonicalAnalysisKey)|$($q.field)|$($q.wavelength)|$($q.pupilSampling)"
    if(-not $selected.Contains($key) -and $q.canonicalAnalysisKey -ne 'First Order'){continue}
    $originalRequest=Join-Path $item.path 'native/request.json'
    $request=Get-Content -Raw -LiteralPath $originalRequest | ConvertFrom-Json -AsHashtable
    $source=Join-Path $run ('sources/'+$item.lens)
    if(-not(Test-Path -LiteralPath $source)){
        New-Item -ItemType Directory -Path (Split-Path -Parent $source) -Force | Out-Null
        Copy-Item -LiteralPath $request.input -Destination $source
    }
    if((Get-FileHash -LiteralPath $source).Hash -ne (Get-FileHash -LiteralPath $request.input).Hash){throw 'Source mismatch.'}
    $request.input=$source
    $output=Join-Path $run ('captures/'+$item.run.directory)
    New-Item -ItemType Directory -Path $output -Force | Out-Null
    $requestPath=Join-Path $output 'request.json'
    ConvertTo-Json -InputObject $request -Depth 80 | Set-Content -LiteralPath $requestPath -Encoding utf8
    $jobs+=@{id=$item.run.directory;request=$requestPath;output=$output}
    $manifest+=@{key=$key;inputSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant();originalRequest=$originalRequest;originalRequestSha256=(Get-FileHash -LiteralPath $originalRequest).Hash.ToLowerInvariant();request=$requestPath;output=$output;physicalSettingsChanged=$false}
}
if($jobs.Count -ne 89){throw "Expected 70 problem requests plus 19 first-order controls; got $($jobs.Count)."}
ConvertTo-Json -InputObject $jobs -Depth 8 | Set-Content -LiteralPath (Join-Path $run 'native-jobs.json') -Encoding utf8
ConvertTo-Json -InputObject $manifest -Depth 8 | Set-Content -LiteralPath (Join-Path $run 'request-manifest.json') -Encoding utf8
Write-Output "Prepared $($jobs.Count) unchanged native requests."
