using System.Diagnostics;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Serialization;
using OpticalSystemDesign.InitialStructure.Contracts;

namespace OpticalSystemDesign.InitialStructure.Engine;

/// <summary>Family proposals, accounting and provenance only; optical evaluation belongs to formal Core.</summary>
public sealed class FlatStartSearchService
{
    public static FlatStartPreflight Preflight(InitialStructureSpecification specification, FlatStartSearchOptions options)
    {
        FlatStartSearchPlanning.Validate(specification, options);
        var materials = FlatStartSearchPlanning.Materials(specification, options);
        return new(materials.Names, materials.Diagnostics);
    }

    public static IReadOnlyList<CandidateSnapshot> SelectCandidates(FlatStartSearchCheckpoint checkpoint) =>
        FlatStartCandidateArchive.Select(checkpoint.Specification, checkpoint.Options, ComparableTrials(checkpoint));

    private static IEnumerable<FamilyTrial> ComparableTrials(FlatStartSearchCheckpoint checkpoint)
    {
        if (checkpoint.Origin is not { } origin) return checkpoint.Trials;
        // The first continuation reevaluates and retains the source on the current
        // full dense objective. Until then it is a preview, never a mixed score.
        return origin.Source.Candidate!.Evaluation.FlatStartObjective is null
            && checkpoint.Trials.Any(trial => trial.Candidate is not null)
                ? checkpoint.Trials : checkpoint.Trials.Prepend(origin.AsParent());
    }

    public static FlatStartSearchCheckpoint CreateRefinementCheckpoint(FlatStartSearchCheckpoint source,
        string candidateId, int additionalEvaluations, TimeSpan additionalTime)
    {
        var materials = FlatStartSearchPlanning.Materials(source.Specification, source.Options);
        var roots = source.Origin is null ? Roots(source.Specification, source.Options, materials.Names, source.Algorithm.Version) : [];
        ValidateResume(source, source.Specification, source.Options, materials, roots, RootQuota(source.Specification, source.Options, roots.Count, source.Algorithm.Version));
        if (source.Trials.Any(trial => trial.State == FamilyTrialState.Reserved))
            throw new InvalidOperationException("Finish or restore the active batch before creating a refinement run.");
        var selected = source.Trials.FirstOrDefault(trial => trial.Candidate?.CandidateId == candidateId)
            ?? (source.Origin?.Source.Candidate?.CandidateId == candidateId ? source.Origin.Source : null)
            ?? throw new ArgumentException("The selected candidate does not belong to this run.", nameof(candidateId));
        var ancestor = selected;
        // A selected origin may itself come from a previous run; its supplied proof is already complete.
        if (ReferenceEquals(selected, source.Origin?.Source)) ancestor = source.Origin!.AsParent();
        else while (ancestor.ParentTrialId is { } parentId) ancestor = Parent(source, parentId);
        var specification = source.Specification with
        {
            Budget = source.Specification.Budget with
            { MaximumEvaluations = additionalEvaluations, TimeLimit = additionalTime }
        };
        FlatStartSearchPlanning.Validate(specification, source.Options);
        return new()
        {
            Algorithm = new(FlatStartAlgorithm.Name("strict-flat-selected-refinement", specification), FlatStartAlgorithm.Version, "Managed CPU", true),
            RunId = "flat-refine-" + Guid.NewGuid().ToString("N"),
            Specification = specification,
            Options = source.Options,
            SpecificationFingerprint = ContentFingerprint.Compute(specification),
            OptionsFingerprint = source.OptionsFingerprint,
            MaterialFingerprint = materials.Fingerprint,
            UsableGlassNames = materials.Names,
            Origin = new(source.RunId, source.Specification, materials.Fingerprint, source.ChargedEvaluations, selected, ancestor.BootstrapProof!),
            Schedule = new(FlatStartAlgorithm.SchedulingPolicy(FlatStartAlgorithm.Version, specification), 0, FlatStartScheduler.Seed(specification.Budget.RandomSeed, 0), "Selected candidate refinement."),
            Diagnostics = [new("refinement.origin", "A separate budget refines the selected candidate; source targets and history are preserved.")]
        };
    }

    private static IReadOnlyList<FlatStartFamily> Roots(InitialStructureSpecification specification, FlatStartSearchOptions options,
        IReadOnlyList<string> glasses, string version) => version is "8" or "9" or "10" or "11" or "12" or "13" or "14" or "15" or "16" or "17" or "18" or "19" or FlatStartAlgorithm.Version
            ? DesignFormSearch.Roots(specification, options, glasses, version) : FlatStartSearchPlanning.Roots(specification, glasses);

    private static int RootQuota(InitialStructureSpecification specification, FlatStartSearchOptions options, int rootCount, string version = FlatStartAlgorithm.Version) =>
        version is "8" or "9" or "10" or "11" or "12" or "13" or "14" or "15" or "16" or "17" or "18" or "19" or FlatStartAlgorithm.Version ? DesignFormSearch.RootQuota(specification, options, rootCount, version)
        : rootCount == 0 ? 0 : Math.Min(options.MaximumEvaluationsPerTrial,
            Math.Min(specification.Budget.MaximumEvaluations / rootCount,
                version is "6" or "7"
                    ? FlatStartScheduler.Allocation(specification, options, "flat-root", specification.MaximumElementCount)
                    : Math.Max(2, (int)(.55 * specification.Budget.MaximumEvaluations / rootCount))));

    public async Task<FlatStartSearchResult> RunAsync(InitialStructureSpecification specification,
        FlatStartSearchOptions? options = null, CancellationToken cancellationToken = default,
        FlatStartSearchCheckpoint? checkpoint = null,
        Func<FlatStartSearchCheckpoint, CancellationToken, ValueTask>? checkpointSink = null)
    {
        options ??= new();
        FlatStartSearchPlanning.Validate(specification, options);
        var materials = FlatStartSearchPlanning.Materials(specification, options);
        var roots = checkpoint?.Origin is null ? Roots(specification, options, materials.Names, checkpoint?.Algorithm.Version ?? FlatStartAlgorithm.Version) : [];
        var quota = RootQuota(specification, options, roots.Count, checkpoint?.Algorithm.Version ?? FlatStartAlgorithm.Version);
        var current = checkpoint ?? new FlatStartSearchCheckpoint
        {
            Algorithm = new(FlatStartAlgorithm.Name("strict-flat-family-search", specification), FlatStartAlgorithm.Version, "Managed CPU", true),
            RunId = "flat-search-" + Guid.NewGuid().ToString("N"),
            Specification = specification,
            Options = options,
            SpecificationFingerprint = ContentFingerprint.Compute(specification),
            OptionsFingerprint = ContentFingerprint.Compute(options),
            MaterialFingerprint = materials.Fingerprint,
            UsableGlassNames = materials.Names,
            RootPlan = roots,
            RootEvaluationQuota = quota,
            Diagnostics = materials.Diagnostics,
            Schedule = new(FlatStartAlgorithm.SchedulingPolicy(FlatStartAlgorithm.Version, specification), 0, FlatStartScheduler.Seed(specification.Budget.RandomSeed, 0), "Initial family screening.")
        };
        if (checkpoint is not null)
        {
            ValidateResume(current, specification, options, materials, roots, quota);
            if (checkpoint.Algorithm.Version != FlatStartAlgorithm.Version)
                throw new InvalidDataException($"This checkpoint uses a historical search version. View/export it or create a separate refinement run; continuing it with version {FlatStartAlgorithm.Version} would change its algorithm.");
            if (current.Trials.Any(trial => trial.State == FamilyTrialState.Reserved))
                current = current with
                {
                    Trials = current.Trials.Select(trial => trial.State == FamilyTrialState.Reserved
                        ? trial with
                        {
                            State = FamilyTrialState.Interrupted,
                            Diagnostics = [new("search.interrupted-quota", "Completion is unknown; the entire reserved evaluation quota remains charged.")]
                        }
                        : trial).ToArray(),
                    ElapsedComputeTicks = checked(current.ElapsedComputeTicks + current.ReservedComputeTicks),
                    ReservedComputeTicks = 0,
                    Diagnostics = current.Diagnostics.Append(new("search.interrupted-time", "The interrupted batch's reserved wall time remains charged.")).ToArray()
                };
        }
        var previousTicks = current.ElapsedComputeTicks;
        var clock = Stopwatch.StartNew();
        current = current with { State = FlatStartSearchState.Running };
        while (materials.Names.Count > 0 && RemainingEvaluations() > 0
            && RemainingTime() > TimeSpan.Zero && current.Trials.Count < FlatStartSearchPlanning.MaximumTrials
            && !FlatStartScheduler.IsStagnant(current)
            && !cancellationToken.IsCancellationRequested)
        {
            var isRootBatch = current.NextRootIndex < roots.Count;
            var count = isRootBatch ? Math.Min(Math.Min(specification.Budget.MaximumParallelism, 4), roots.Count - current.NextRootIndex) : 1;
            count = Math.Min(count, FlatStartSearchPlanning.MaximumTrials - current.Trials.Count);
            var work = new List<TrialWork>();
            var remaining = RemainingEvaluations();
            for (var offset = 0; offset < count && remaining > 0; offset++)
            {
                var index = current.Trials.Count + offset;
                var family = isRootBatch ? roots[current.NextRootIndex + offset] : null;
                var proposal = family is not null ? new TrialWork(family, "flat-root", null, null, null) { ScreenOnly = (options.DesignSearch ?? new()).Mode == DesignSearchMode.Quick }
                    : Propose(specification, materials.Names, current);
                var allocation = Math.Min(remaining, isRootBatch ? quota
                    : FlatStartAlgorithm.SchedulingPolicy(current.Algorithm.Version, specification) == 2 && proposal.Parent is not null && current.Origin is null
                        ? NeighborhoodBudget.Allocate(current, FlatStartScheduler.Operation(proposal.Operation), proposal.Family.ElementCount, remaining)
                        : FlatStartScheduler.Allocation(specification, options, proposal.Operation, proposal.Family.ElementCount));
                work.Add(proposal with
                {
                    Trial = new()
                    {
                        Index = index,
                        TrialId = $"trial-{index:D4}",
                        Family = proposal.Family,
                        Operation = proposal.Operation,
                        ParentTrialId = proposal.Parent?.TrialId,
                        State = FamilyTrialState.Reserved,
                        AllocatedEvaluations = allocation,
                        ChargedEvaluations = allocation,
                        Diagnostics = [new("search.schedule", proposal.Reason)]
                    }
                });
                remaining -= allocation;
            }
            var timeLimit = RemainingTime();
            // A cancel completes this bounded batch. A process loss charges its reserved upper bound.
            timeLimit = TimeSpan.FromTicks(Math.Min(timeLimit.Ticks, Math.Max(TimeSpan.TicksPerSecond,
                (long)(specification.Budget.TimeLimit.Ticks * (2.0 * work.Max(item => item.Trial.AllocatedEvaluations)
                    / specification.Budget.MaximumEvaluations)))));
            current = current with
            {
                Trials = current.Trials.Concat(work.Select(item => item.Trial)).ToArray(),
                NextRootIndex = current.NextRootIndex + (isRootBatch ? work.Count : 0),
                NextRefinementIndex = current.NextRefinementIndex + (isRootBatch ? 0 : work.Count),
                ElapsedComputeTicks = previousTicks + clock.Elapsed.Ticks,
                ReservedComputeTicks = timeLimit.Ticks,
                Schedule = new(FlatStartAlgorithm.SchedulingPolicy(FlatStartAlgorithm.Version, specification), current.NextRefinementIndex + (isRootBatch ? 0 : work.Count),
                    FlatStartScheduler.Seed(specification.Budget.RandomSeed, current.NextRefinementIndex + (isRootBatch ? 0 : work.Count)),
                    work[^1].Reason)
            };
            await Save(); // Persist reservations before dispatching any evaluations.
            var completed = await Task.WhenAll(work.Select(item => Task.Run(() => Execute(specification, item, timeLimit, materials.Names))));
            // Task.WhenAll preserves proposal order, independent of worker completion order.
            var updated = current.Trials.ToArray();
            foreach (var trial in completed) updated[trial.Index] = trial;
            current = current with { Trials = updated, ReservedComputeTicks = 0, ElapsedComputeTicks = previousTicks + clock.Elapsed.Ticks };
            await Save();
        }
        current = current with
        {
            ElapsedComputeTicks = previousTicks + clock.Elapsed.Ticks,
            State = materials.Names.Count == 0 ? FlatStartSearchState.NoUsableGlass
                : cancellationToken.IsCancellationRequested ? FlatStartSearchState.Cancelled
                : RemainingTime() <= TimeSpan.Zero ? FlatStartSearchState.TimeLimit
                : RemainingEvaluations() == 0 ? FlatStartSearchState.BudgetExhausted : FlatStartSearchState.Completed
        };
        if (current.Origin is null && (current.NextRootIndex < roots.Count || roots.Select(root => root.ElementCount).Distinct().Count()
            < specification.MaximumElementCount - specification.MinimumElementCount + 1))
            current = current with
            {
                Diagnostics = current.Diagnostics.Append(new("search.incomplete-coverage",
                "The available seed, evaluation or time budget did not cover every requested initial family/element count.")).ToArray()
            };
        if (current.Origin is null && DesignFormSearch.Preview(specification, options) is { } coverage
            && DesignFormSearch.CompletedSignForms(current) < coverage.DistinctSignForms)
            current = current with
            {
                Diagnostics = current.Diagnostics.Append(new("search.binary-coverage",
                "The completed roots do not cover every requested binary sign form; do not interpret this as exhaustive form search.")).ToArray()
            };
        if (current.Trials.Count == FlatStartSearchPlanning.MaximumTrials)
            current = current with { Diagnostics = current.Diagnostics.Append(new("search.trial-limit", "The bounded trial archive is full; remaining evaluation budget is unused.")).ToArray() };
        if (current.Origin is null && materials.Names.Count > 0
            && FlatStartAlgorithm.SchedulingPolicy(current.Algorithm.Version, specification) == 2)
        {
            var attempted = current.Trials.Where(trial => trial.ParentTrialId is not null && trial.State == FamilyTrialState.Completed)
                .Select(trial => FlatStartScheduler.Operation(trial.Operation)).ToHashSet();
            var missing = NeighborhoodBudget.Operations(specification, options, materials.Names.Count).Where(op => !attempted.Contains(op)).ToArray();
            if (missing.Length > 0)
                current = current with
                {
                    Diagnostics = current.Diagnostics.Append(new("search.neighborhood-coverage",
                    $"No completed trial for operator(s) {string.Join(", ", missing)}; the available budget, time or parents did not complete a mixed neighborhood round.")).ToArray()
                };
        }
        if (FlatStartScheduler.IsStagnant(current))
            current = current with { Diagnostics = current.Diagnostics.Append(new("search.stagnation", "No dense-validated improvement in 48 trials including two fresh strict-flat roots; remaining budget is unused.")).ToArray() };
        await Save();
        return new(current, SelectCandidates(current));

        int RemainingEvaluations() => specification.Budget.MaximumEvaluations - current.ChargedEvaluations;
        TimeSpan RemainingTime() => specification.Budget.TimeLimit - TimeSpan.FromTicks(previousTicks + clock.Elapsed.Ticks);
        async ValueTask Save()
        {
            if (checkpointSink is not null) await checkpointSink(current, CancellationToken.None);
        }
    }

    private static FamilyTrial Execute(InitialStructureSpecification specification, TrialWork work, TimeSpan timeLimit, IReadOnlyList<string> allowedGlassNames)
    {
        var trial = work.Trial;
        try
        {
            var request = specification with
            {
                Budget = specification.Budget with
                { MaximumEvaluations = trial.AllocatedEvaluations, MaximumParallelism = 1, TimeLimit = timeLimit }
            };
            var service = new FlatStartDesignService();
            var result = work.Start is null ? service.Solve(request, work.Family.ElementCount, family: work.Family, screenOnly: work.ScreenOnly, allowedGlassNames: allowedGlassNames)
                : service.Continue(request, work.Family, work.RootProof!, work.Start, work.Parent!.Candidate!.CandidateId,
                    improveBeyondTargets: work.Operation == "refine-selected",
                    screenOnly: specification.FlatStart!.SamplingPolicy != FlatStartSamplingPolicy.UniformAreaGaussianV1
                        && work.Operation is not ("refine" or "refine-selected"), allowedGlassNames: allowedGlassNames);
            var candidate = result.Candidate is { } value ? value with
            {
                CandidateId = (work.Operation == "refine-selected" ? "selected-" + ContentFingerprint.Compute(work.Parent!.Candidate!.CandidateId)[..8] + "-" : "")
                    + trial.TrialId + "-" + value.OpticFingerprint[..16],
                Lineage = value.Lineage with
                {
                    Operation = trial.Operation,
                    Generation = work.Parent is null ? 0 : work.Parent.Candidate!.Lineage.Generation + 1
                }
            } : null;
            return trial with
            {
                State = FamilyTrialState.Completed,
                CompletedEvaluations = result.EvaluationCount,
                ChargedEvaluations = result.EvaluationCount,
                TracedRealRayCount = result.TracedRayCount,
                DesignState = result.State,
                BootstrapProof = work.Parent is null ? result.Bootstrap : null,
                FlatRoot = result.Bootstrap.Steps[0].Optic,
                RefinementStartOptic = work.Start,
                FirstCurvatureUpdate = work.Parent is null ? result.Bootstrap.Steps.FirstOrDefault(step => step.Optic.Surfaces.Any(surface => surface.Radius != 0)) : null,
                FirstRefinementStep = Compact(result.Steps.FirstOrDefault(step => step.Operation == "curvature-thickness-step")),
                Stages = result.Steps.Where(step => step.Operation != "curvature-thickness-step").Select(step => Compact(step)!).ToArray(),
                Candidate = candidate,
                FinalValidation = result.FinalValidation is { } validation ? validation with { Residuals = [] } : null,
                AutoLensState = result.AutoLensState,
                Diagnostics = trial.Diagnostics.Concat(result.Diagnostics).ToArray()
            };
        }
        catch (Exception exception) when (exception is InvalidOperationException or ArgumentException or ArithmeticException or KeyNotFoundException or InvalidDataException)
        {
            return trial with
            {
                State = FamilyTrialState.Failed,
                Diagnostics = [new("search.trial-failed", $"{exception.GetType().Name}: {exception.Message} The reserved quota remains charged because completion is unknown.")]
            };
        }
    }

    private static DesignStep? Compact(DesignStep? step) => step is null ? null : step with { Evaluation = step.Evaluation with { Residuals = [] } };

    private static TrialWork Propose(InitialStructureSpecification specification, IReadOnlyList<string> glasses, FlatStartSearchCheckpoint checkpoint)
    {
        var ordinal = checkpoint.NextRefinementIndex;
        if (checkpoint.Origin is { } origin)
        {
            var chosen = ComparableTrials(checkpoint).Where(trial => trial.Candidate is not null)
                .OrderBy(trial => FlatStartCandidateArchive.Rank(trial.Candidate!.Status))
                .ThenBy(trial => FlatStartCandidateArchive.Score(specification, trial.Candidate!)).First();
            return new(chosen.Family, "refine-selected", chosen, origin.RootProof, chosen.Candidate!.Optic);
        }
        var decision = DesignFormScheduler.Decide(checkpoint);
        if (decision.Parent is not { } parent)
            return new(checkpoint.RootPlan[ordinal % checkpoint.RootPlan.Count], "flat-root-retry", null, null, null)
            { Reason = decision.Reason };
        var ancestor = parent;
        while (ancestor.ParentTrialId is { } parentId) ancestor = Parent(checkpoint, parentId);
        var optic = Optic.FromSnapshot(parent.Candidate!.Optic);
        var n = parent.Family.ElementCount;
        var selectedGlass = parent.Family.GlassNames.ToArray();
        if (specification.FlatStart?.OptimizationMethod == FlatStartOptimizationMethod.AutoLensManagedV1)
            for (var element = 0; element < n; element++)
            {
                var actual = optic.SurfaceGroup.Items[2 * element + 1].MaterialAfter.Name;
                selectedGlass[element] = glasses.First(name => optic.Materials.Resolve(name).Name.Equals(actual, StringComparison.OrdinalIgnoreCase));
            }
        var random = new DeterministicRandom(FlatStartScheduler.Seed(specification.Budget.RandomSeed, ordinal));
        var operation = decision.Operation;
        if (glasses.Count == 1 && operation is 1 or 2) operation = 4;
        if (operation is 1 or 2)
        {
            var start = random.NextInt32(n);
            for (var offset = 0; offset < (operation == 1 ? 1 : Math.Min(2, n)); offset++)
            {
                var element = (start + offset) % n;
                var surface = optic.SurfaceGroup.Items[2 * element + 1];
                var choices = glasses.Where(name => !name.Equals(selectedGlass[element], StringComparison.OrdinalIgnoreCase)).ToArray();
                selectedGlass[element] = choices[random.NextInt32(choices.Length)];
                surface.MaterialAfter = optic.Materials.Resolve(selectedGlass[element]);
            }
        }
        if (operation == 3)
        {
            var stop = 1 + parent.Family.StopSurfaceIndex % (2 * n);
            for (var index = 1; index <= 2 * n; index++) optic.SurfaceGroup.Items[index].IsStop = index == stop;
        }
        AutoLensManagedTopology.Apply(optic, specification, n);
        optic.SurfaceGroup.Renumber();
        var family = parent.Family with
        {
            GlassNames = selectedGlass,
            StopSurfaceIndex = optic.SurfaceGroup.Items.ToList().FindIndex(surface => surface.IsStop),
            SeedIndex = checkpoint.RootPlan.Count + ordinal
        };
        var snapshot = optic.ToSnapshot();
        if (operation == 4)
        {
            var problem = new FlatStartDesignProblem(specification, n, snapshot, family);
            var vector = problem.Vector(snapshot);
            for (var index = 0; index < vector.Length; index++) vector[index] += (random.NextUnitDouble() - .5) * (index < 2 * n ? .1 : .04);
            snapshot = problem.CreateOptic(problem.Project(vector), FlatStartDesignProblem.FullStage).ToSnapshot();
        }
        string[] names = ["refine", "glass-swap", "glass-pair-swap", "stop-surface-change", "parameter-perturbation"];
        return new(family, names[operation], parent, ancestor.BootstrapProof!, snapshot) { Reason = decision.Reason };
    }

    private static void ValidateResume(FlatStartSearchCheckpoint checkpoint, InitialStructureSpecification specification,
        FlatStartSearchOptions options, SearchMaterialSet materials, IReadOnlyList<FlatStartFamily> roots, int quota)
    {
        FlatStartCheckpointValidation.Validate(checkpoint);
        if (checkpoint.Origin is { } origin)
        {
            var source = origin.Source.Candidate!;
            var rootHash = ContentFingerprint.Compute(origin.RootProof.Steps[0].Optic);
            if (ContentFingerprint.Compute(specification with { Budget = origin.Specification.Budget }) != ContentFingerprint.Compute(origin.Specification)
                || origin.MaterialFingerprint != materials.Fingerprint || source.OpticFingerprint != ContentFingerprint.Compute(source.Optic)
                || source.Lineage.RootFingerprint != rootHash || ContentFingerprint.Compute(source.FlatRootOptic) != rootHash)
                throw new InvalidDataException("Refinement must retain source targets, catalog materials and original flat-root provenance.");
            FlatStartFamilySupport.Validate(specification, origin.Source.Family);
        }
        if (checkpoint.SpecificationFingerprint != ContentFingerprint.Compute(specification)
            || checkpoint.SpecificationFingerprint != ContentFingerprint.Compute(checkpoint.Specification)
            || checkpoint.OptionsFingerprint != ContentFingerprint.Compute(options)
            || checkpoint.OptionsFingerprint != ContentFingerprint.Compute(checkpoint.Options)
            || checkpoint.MaterialFingerprint != materials.Fingerprint
            || ContentFingerprint.Compute(checkpoint.UsableGlassNames) != ContentFingerprint.Compute(materials.Names)
            || ContentFingerprint.Compute(checkpoint.RootPlan) != ContentFingerprint.Compute(roots)
            || checkpoint.RootEvaluationQuota != quota)
            throw new InvalidDataException("The saved specification, search options, root plan or catalog materials differ from this run.");
        for (var index = 0; index < checkpoint.Trials.Count; index++)
        {
            var trial = checkpoint.Trials[index];
            FlatStartFamilySupport.Validate(specification, trial.Family);
            if (index < checkpoint.NextRootIndex && (trial.ParentTrialId is not null || trial.Operation != "flat-root"
                || ContentFingerprint.Compute(trial.Family) != ContentFingerprint.Compute(roots[index])))
                throw new InvalidDataException("An initial trial differs from the saved flat-root plan.");
            if (trial.Candidate is { } candidate)
            {
                var rootHash = ContentFingerprint.Compute(trial.FlatRoot!);
                if (candidate.OpticFingerprint != ContentFingerprint.Compute(candidate.Optic)
                    || candidate.Lineage.RootFingerprint != rootHash || ContentFingerprint.Compute(candidate.FlatRootOptic) != rootHash
                    || candidate.Lineage.ElementCount != trial.Family.ElementCount || candidate.Lineage.StopVariant != trial.Family.StopSurfaceIndex)
                    throw new InvalidDataException("Candidate optical content or flat-root provenance was changed.");
                if (trial.ParentTrialId is { } parentId && Parent(checkpoint, parentId).Candidate!.Lineage.RootFingerprint != rootHash)
                    throw new InvalidDataException("A refinement lost its original flat-root provenance.");
            }
            if (trial.BootstrapProof is { } proof && ContentFingerprint.Compute(proof.Steps[0].Optic) != ContentFingerprint.Compute(trial.FlatRoot!))
                throw new InvalidDataException("The bootstrap and recorded root disagree.");
        }
    }

    private static FamilyTrial Parent(FlatStartSearchCheckpoint checkpoint, string id) =>
        id == FlatStartRefinementOrigin.ParentReference && checkpoint.Origin is { } origin ? origin.AsParent()
            : checkpoint.Trials.First(trial => trial.TrialId == id);

    private sealed record TrialWork(FlatStartFamily Family, string Operation, FamilyTrial? Parent,
        FlatStartBootstrapResult? RootProof, OpticSnapshot? Start)
    {
        public FamilyTrial Trial { get; init; } = new();
        public string Reason { get; init; } = "Explore a binary initial form; every displayed result receives independent dense validation.";
        public bool ScreenOnly { get; init; }
    }
}
