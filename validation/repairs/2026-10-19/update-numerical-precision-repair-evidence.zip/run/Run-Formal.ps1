$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$runner=Join-Path $PSScriptRoot 'formal-runner/bin/Release/net10.0/Runner.dll'
$specs=@(@('formal-final',''),@('extra-final','extra'),@('apochromat-final','new'),@('high-sampling-final','current'),@('fnum-final','latest'),@('polychromatic-final','poly'),@('polychromatic128-final','poly128'),@('boundary128-final','boundary128'),@('offner-final','offner'),@('decenter-final','decenter'),@('controls-final','relay64w3'),@('aiming-final','aiming'),@('matrix-circular','matrix'),@('extended-controls-circular','controls'))
foreach($spec in $specs){
 $arguments=@($runner,$repo,(Join-Path $PSScriptRoot $spec[0]));if($spec[1]){$arguments+=@($spec[1])}
 dotnet @arguments *> (Join-Path $PSScriptRoot ($spec[0]+'.log'))
 if($LASTEXITCODE -ne 0){throw ('Formal comparison failed: '+$spec[0])}
}
