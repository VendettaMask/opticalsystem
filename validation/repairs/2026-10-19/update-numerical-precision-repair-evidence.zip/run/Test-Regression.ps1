param([string]$Configuration='Release',[switch]$Module)
$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$name=if($Module){'module-'+$Configuration}else{$Configuration}
$project=if($Module){'labs/InitialStructure/tests/OpticalSystemDesign.InitialStructure.Tests/OpticalSystemDesign.InitialStructure.Tests.csproj'}else{'tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj'}
if($Module){
 $env:OPTICALSYSTEMDESIGN_AUTOLENS_MANAGED_EVIDENCE=Join-Path $PSScriptRoot ('managed-results-'+$Configuration)
 New-Item -ItemType Directory -Path $env:OPTICALSYSTEMDESIGN_AUTOLENS_MANAGED_EVIDENCE -Force|Out-Null
}
$filter=[IO.File]::ReadAllText((Join-Path $PSScriptRoot ($name+'-filter.txt'))).Trim()
dotnet test (Join-Path $repo $project) -c $Configuration --no-build --no-restore --filter $filter --logger ('trx;LogFileName='+$name+'.trx') --results-directory (Join-Path $PSScriptRoot 'tests') *> (Join-Path $PSScriptRoot ('tests-'+$name+'.log'))
if($LASTEXITCODE -ne 0){Get-Content (Join-Path $PSScriptRoot ('tests-'+$name+'.log')) -Tail 16;throw 'Regression failed'}
Get-Content (Join-Path $PSScriptRoot ('tests-'+$name+'.log')) -Tail 3
if(!$Module){
 $filter=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'comparison-filter.txt')).Trim()
 dotnet test (Join-Path $repo 'tests/OpticalSystemDesign.ZemaxComparison.Tests/OpticalSystemDesign.ZemaxComparison.Tests.csproj') -c $Configuration --no-build --no-restore --filter $filter --logger ('trx;LogFileName=comparison-'+$Configuration+'.trx') --results-directory (Join-Path $PSScriptRoot 'tests') *> (Join-Path $PSScriptRoot ('comparison-'+$Configuration+'.log'))
 if($LASTEXITCODE -ne 0){throw 'Comparison regression failed'}
 Get-Content (Join-Path $PSScriptRoot ('comparison-'+$Configuration+'.log')) -Tail 3
}
