$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$oldRoot=Join-Path $repo 'artifacts/validation/dee-extended-precision-20261018'
New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot 'previous-tests'),(Join-Path $PSScriptRoot 'formal-runner') -Force|Out-Null
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path $repo 'validation/experiments/2026-10-19/autolens-managed-native-evidence.zip'))
try{
 foreach($name in 'delivery-core-debug','delivery-core-release','delivery-lab-debug','delivery-managed-release'){
  $entry=$zip.GetEntry('raw/'+$name+'.trx');$inputStream=$entry.Open();$outputStream=[IO.File]::Create((Join-Path $PSScriptRoot ('previous-tests/'+$name+'.trx')))
  try{$inputStream.CopyTo($outputStream)}finally{$inputStream.Dispose();$outputStream.Dispose()}
 }
}finally{$zip.Dispose()}
function GetTestFilter([string]$path){
 [xml]$xml=Get-Content $path -Raw
 @($xml.TestRun.TestDefinitions.UnitTest.TestMethod|ForEach-Object { 'FullyQualifiedName='+($_.className -split ',')[0]+'.'+$_.name }|Sort-Object -Unique) -join '|'
}
foreach($configuration in 'Release','Debug'){
 $old=[IO.File]::ReadAllText((Join-Path $oldRoot ($configuration+'-filter.txt'))).Trim()
 $managed=GetTestFilter (Join-Path $PSScriptRoot ('previous-tests/delivery-core-'+$configuration.ToLowerInvariant()+'.trx'))
 $filter=$old+'|'+$managed+'|FullyQualifiedName~DesignPrecisionRepairTests|FullyQualifiedName~LayeringArchitectureTests'
 [IO.File]::WriteAllText((Join-Path $PSScriptRoot ($configuration+'-filter.txt')),$filter)
}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'module-Debug-filter.txt'),(GetTestFilter (Join-Path $PSScriptRoot 'previous-tests/delivery-lab-debug.trx')))
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'module-Release-filter.txt'),(GetTestFilter (Join-Path $PSScriptRoot 'previous-tests/delivery-managed-release.trx')))
Copy-Item (Join-Path $oldRoot 'comparison-filter.txt') (Join-Path $PSScriptRoot 'comparison-filter.txt')
Copy-Item (Join-Path $oldRoot 'formal-runner/Program.cs') (Join-Path $PSScriptRoot 'formal-runner/Program.cs')
Copy-Item (Join-Path $oldRoot 'formal-runner/Runner.csproj') (Join-Path $PSScriptRoot 'formal-runner/Runner.csproj')
$changed=@('src/OpticalSystemDesign.Core/Differentiation/DifferentialScalar.cs','src/OpticalSystemDesign.Core/Differentiation/OpticalDesignParameters.cs','src/OpticalSystemDesign.Core/Differentiation/OpticalDifferentialContext.cs','src/OpticalSystemDesign.App/Laboratories/InitialStructure/CandidateRow.cs')
git -C $repo archive -o (Join-Path $PSScriptRoot 'source-before.zip') HEAD -- @changed tests/OpticalSystemDesign.Tests/OpticalDesignDerivativeTests.cs tests/OpticalSystemDesign.Tests/LayeringArchitectureTests.cs
if($LASTEXITCODE -ne 0){throw 'Before source archive failed'}
@{baseCommit=(git -C $repo rev-parse HEAD).Trim();changedProductFiles=$changed;beforeCoreSha256=(Get-FileHash (Join-Path $PSScriptRoot 'Core.before.dll')).Hash.ToLowerInvariant();mainBaseRelease=1148;mainBaseDebug=435;autoLensCorePerConfiguration=54;moduleDebug=71;moduleRelease=21}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $PSScriptRoot 'verification-inputs.json') -Encoding utf8NoBOM
