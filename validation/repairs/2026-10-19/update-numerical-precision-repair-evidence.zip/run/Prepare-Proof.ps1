$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}
function Read([string]$path){Get-Content (Join-Path $PSScriptRoot $path) -Raw|ConvertFrom-Json}
function Tests([string]$path){
 [xml]$xml=Get-Content $path -Raw
 $c=$xml.TestRun.ResultSummary.Counters
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.TestRun.Results.UnitTestResult.testName|Sort-Object);sha256=Hash $path}
}
$inputs=Read 'verification-inputs.json'
if((git -C $repo rev-parse HEAD).Trim() -ne $inputs.baseCommit){throw 'Audit base changed'}
$beforeCore=Hash (Join-Path $PSScriptRoot 'Core.before.dll');$afterCore=Hash (Join-Path $PSScriptRoot 'Core.release-final.dll')
if($beforeCore -ne $inputs.beforeCoreSha256 -or $beforeCore -eq $afterCore){throw 'Before/final Core differs from audit'}
$before=Tests (Join-Path $PSScriptRoot 'tests/precision-before-complete.trx')
$architectureBefore=Tests (Join-Path $PSScriptRoot 'tests/architecture-before.trx')
if($before.total -ne 25 -or $before.failed -ne 24 -or $before.passed -ne 1 -or $architectureBefore.total -ne 1 -or $architectureBefore.failed -ne 1){throw 'Counterfactual tests incomplete'}
$identity=Read 'before-test-identity.json'
if($identity.beforeCoreSha256 -ne $beforeCore -or $identity.candidateCoreSha256 -ne $afterCore -or !$identity.candidateRestored){throw 'Counterfactual Core identity differs'}
$previous=Get-Content (Join-Path $repo 'docs/validation/EXPANDED_SAMPLING_ENERGY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$previousRoot=Join-Path $repo 'artifacts/validation/dee-extended-precision-20261018'
$testResults=@{}
foreach($name in 'Release','Debug','module-Debug','module-Release','comparison-Release','comparison-Debug'){
 $result=Tests (Join-Path $PSScriptRoot ('tests/'+$name+'.trx'))
 $expected=switch($name){'Release'{1244};'Debug'{531};'module-Debug'{71};'module-Release'{21};default{5}}
 if($result.total -ne $expected -or $result.passed -ne $expected -or $result.failed -ne 0 -or $result.skipped -ne 0){throw ('Final regression incomplete: '+$name)}
 $testResults[$name]=$result
}
foreach($configuration in 'Release','Debug'){
 $old=Tests (Join-Path $previousRoot ('tests/'+$configuration+'.trx'))
 $core=Tests (Join-Path $PSScriptRoot ('previous-tests/delivery-core-'+$configuration.ToLowerInvariant()+'.trx'))
 foreach($name in @($old.names)+@($core.names)+@($before.names)+@($architectureBefore.names)){
  if($name -cnotin $testResults[$configuration].names){throw 'Old or new main test identity missing'}
 }
 $oldComparison=Tests (Join-Path $previousRoot ('tests/comparison-'+$configuration+'.trx'))
 foreach($name in $oldComparison.names){if($name -cnotin $testResults['comparison-'+$configuration].names){throw 'Old comparison identity missing'}}
}
foreach($spec in @(@('module-Debug','delivery-lab-debug'),@('module-Release','delivery-managed-release'))){
 $old=Tests (Join-Path $PSScriptRoot ('previous-tests/'+$spec[1]+'.trx'))
 if(($old.names -join "`n") -cne ($testResults[$spec[0]].names -join "`n")){throw 'Module test selection changed'}
}
$groups=@{};$deltas=@();$count=0
foreach($group in $previous.allFormalGroups.PSObject.Properties){
 $now=Read ($group.Name+'/summary.json');$old=$group.Value;$groups[$group.Name]=$now
 if($now.rows.Count -ne $old.rows.Count -or $now.excluded.Count -ne $old.excluded.Count -or $now.policySha256 -ne $old.policySha256 -or $now.coreSha256 -ne $afterCore){throw 'Formal inventory, policy or Core differs'}
 foreach($row in $now.rows){
  $match=@($old.rows|Where-Object id -ceq $row.id)
  if($match.Count -ne 1 -or $row.conclusion -ne 'Pass'){throw 'Old formal pass lost'}
  foreach($key in 'sourceSha256','executedRequestSha256','nativeDataSha256'){if($row.$key -ne $match[0].$key){throw 'Frozen formal input changed'}}
  $nativeRelative=$group.Name+'/'+$row.id+'/normalized-zemax.json'
  if((Hash (Join-Path $PSScriptRoot $nativeRelative)) -ne (Hash (Join-Path $previousRoot $nativeRelative))){throw 'Normalized native bytes changed'}
  for($series=0;$series -lt $row.metrics.Count;$series++){
   $delta=$row.metrics[$series].nrmse-$match[0].metrics[$series].nrmse
   if($delta -gt 1e-8){throw 'Original NRMSE increase limit exceeded'}
   if($delta -ne 0 -or $row.metrics[$series].maxAbsolute -ne $match[0].metrics[$series].maxAbsolute){throw 'Legacy numerical metric changed during additive derivative repair'}
   $deltas+=@{group=$group.Name;id=$row.id;series=$series;before=$match[0].metrics[$series].nrmse;after=$row.metrics[$series].nrmse;increase=$delta}
  }
  $count++
 }
}
if($count -ne 165){throw 'Expected 165 old formal instances'}
$configurations=@()
foreach($configuration in 'Release','Debug'){
 $log=Join-Path $PSScriptRoot ('build-'+$configuration+'.log');$text=[IO.File]::ReadAllText($log)
 if([regex]::Matches($text,'(?m)^\s*[^\r\n]+ -> [^\r\n]+\.dll\r?$').Count -ne 19 -or $text -notmatch '0 个警告' -or $text -notmatch '0 个错误'){throw 'Default root build incomplete'}
 $paths=@('src/OpticalSystemDesign.Core/bin/CONFIG/net10.0/OpticalSystemDesign.Core.dll','src/OpticalSystemDesign.App/bin/CONFIG/net10.0/OpticalSystemDesign.Core.dll','tests/OpticalSystemDesign.Tests/bin/CONFIG/net10.0/OpticalSystemDesign.Core.dll','tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/CONFIG/net10.0/OpticalSystemDesign.Core.dll','tools/OpticalSystemDesign.ZemaxComparison/bin/CONFIG/net10.0/OpticalSystemDesign.Core.dll','labs/InitialStructure/tests/OpticalSystemDesign.InitialStructure.Tests/bin/CONFIG/net10.0/OpticalSystemDesign.Core.dll')
 $expected=Hash (Join-Path $PSScriptRoot ('Core.'+$configuration.ToLowerInvariant()+'-final.dll'));$copies=@()
 foreach($template in $paths){$path=$template.Replace('CONFIG',$configuration);$actual=Hash (Join-Path $repo $path);if($actual -ne $expected){throw 'Default Core copies disagree'};$copies+=@{path=$path;sha256=$actual}}
 $configurations+=@{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies;logSha256=Hash $log}
}
$sync=Get-Content (Join-Path $repo 'docs/validation/SOURCE_SYNC_2026-10-18.json') -Raw|ConvertFrom-Json
foreach($source in $sync.VerifiedCSharpFiles){if((Hash (Join-Path $repo $source.path)) -ne $source.sha256){throw 'Unrelated legacy precision source changed'}}
foreach($archive in $sync.FrozenArchives){if((Hash (Join-Path $repo $archive.path)) -ne $archive.sha256){throw 'Frozen archive changed'}}
foreach($fixture in $sync.FrozenNativeFixtures){if((Hash (Join-Path $repo $fixture.path)) -ne $fixture.sha256){throw 'Frozen native fixture changed'}}
$additionalArchives=@()
foreach($path in @('validation/experiments/2026-10-19/autolens-cpu-experiment-evidence.zip','validation/experiments/2026-10-19/autolens-managed-native-evidence.zip','validation/rechecks/2026-10-19/local-build-and-regression-evidence.zip','validation/repairs/2026-10-19/frozen-evidence-relocation-repair.zip')){
 $committed=(git -C $repo rev-parse ('HEAD:'+$path)).Trim();$working=(git -C $repo hash-object --no-filters -- $path).Trim()
 if($committed -ne $working){throw 'Incoming frozen archive changed'}
 $additionalArchives+=@{path=$path;sha256=Hash (Join-Path $repo $path);gitBlob=$committed}
}
$integrity=Read 'frozen-integrity.json'
if($integrity.count -ne 2668 -or $integrity.matched -ne 2668 -or $integrity.workingTree.matched -ne 2668 -or !$integrity.unchanged -or !$integrity.workingTree.unchanged){throw 'Original frozen byte gate failed'}
$sourcePaths=@($inputs.changedProductFiles)+@('tests/OpticalSystemDesign.Tests/DesignPrecisionRepairTests.cs')
$sources=@($sourcePaths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
$target=@($groups['formal-final'].rows|Where-Object id -ceq '0472-n64-w3')[0]
$proof=@{date='2026-10-19';baseCommit=$inputs.baseCommit;scope='Post-update automatic derivative range/coordinate binding precision and App layering repair; original optical baselines replayed unchanged';beforeCoreSha256=$beforeCore;afterCoreSha256=$afterCore;sourceFiles=$sources;verification=@{tests=$testResults;newTests=25;newBefore=$before;architectureBefore=$architectureBefore;beforeGuardIdentity=$identity;configurations=$configurations;originalNativeCore54RetainedPerConfiguration=$true;originalMain1148And435IdentitiesRetained=$true;originalModule71And21IdentitiesRetained=$true;formatLogSha256=Hash (Join-Path $PSScriptRoot 'format.log')};allFormalGroups=$groups;formalValidCount=$count;metricDeltas=$deltas;maximumOldNrmseIncrease=($deltas.increase|Measure-Object -Maximum).Maximum;oldNrmseAndMaximumAbsoluteDifferencesExactlyUnchanged=$true;target=$target;originalMatrixMaximumNrmse=($groups['formal-final'].rows.metrics.nrmse|Measure-Object -Maximum).Maximum;expandedMatrixMaximumNrmse=($groups['matrix-circular'].rows.metrics.nrmse|Measure-Object -Maximum).Maximum;preservedArchives=@($sync.FrozenArchives)+$additionalArchives;preservedNativeFixtures=$sync.FrozenNativeFixtures;preservedLegacyPrecisionSources=$sync.VerifiedCSharpFiles;frozenIntegrity=@{count=2668;workingMatched=2668;headMatched=2668;aggregateSha256=$integrity.actualAggregateSha256;relocationMapSha256=$integrity.relocationMap.actualSha256;reportSha256=Hash (Join-Path $PSScriptRoot 'frozen-integrity.json')};constraints=@{oldTolerancesAndReferencesUnchanged=$true;newFiniteTangentRelativeLimit=2e-12;legacyEnergyLimit=1e-8;ordinaryQuotientEvaluationOrderRetained=$true;invalidTangentsNeverBecomeZeroPenalties=$true;noSecondOpticalEngine=$true;nativeDataUsedAtRuntime=$false};boundaries=@('No new native Zemax capture or new optical certification; 165 previous captured settings replayed','Binary normalization repair is scoped to division; not a general guarantee for every automatic-differentiation operation or ill-conditioned design','Spot/power derivatives still fix quadratic asphere A2 to zero; unsupported optimization is now rejected, geometry-only A2 derivatives remain available','AutoLens exact reference models, objective tolerances, Adam state and acceptance contracts unchanged; passing pipeline tests do not certify every design target or upstream numerical equivalence','No installer, commit or push')}
$proof.verification.newTests=25
$probe=Read 'subnormal-final.json'
if(!$probe.pass -or $probe.coreSha256 -ne $afterCore -or $probe.tangent -ne [double]::Epsilon){throw 'Final subnormal tangent repair failed'}
$proof.subnormalProbeBefore=Read 'subnormal-candidate-before.json'
$proof.subnormalProbeAfter=$probe
if($proof.preservedArchives.Count -ne 30 -or $proof.preservedNativeFixtures.Count -ne 19 -or $proof.sourceFiles.Count -ne 5){throw 'Proof inventory differs'}
$proof|ConvertTo-Json -Depth 80|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 80|Set-Content (Join-Path $repo 'docs/validation/UPDATE_NUMERICAL_PRECISION_REPAIR_2026-10-19.json') -Encoding utf8NoBOM
@{formal=$count;oldIncrease=$proof.maximumOldNrmseIncrease;release=$testResults.Release.total;debug=$testResults.Debug.total;moduleDebug=$testResults['module-Debug'].total;moduleRelease=$testResults['module-Release'].total;archives=30;fixtures=19;originalMatrix=$proof.originalMatrixMaximumNrmse;relayTarget=$target.metrics[1].nrmse}|ConvertTo-Json
