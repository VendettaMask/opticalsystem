$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$relativeTarget='validation/repairs/2026-10-19/update-numerical-precision-repair-evidence.zip'
$target=Join-Path $repo $relativeTarget
if(Test-Path -LiteralPath $target){throw 'Never overwrite frozen evidence'}
$proof=Get-Content (Join-Path $PSScriptRoot 'proof.json') -Raw|ConvertFrom-Json
$payload=@{}
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -File -Recurse){
 $relative=[IO.Path]::GetRelativePath($PSScriptRoot,$file.FullName).Replace('\','/')
 if($relative -match '(^|/)(bin|obj|runtimes)/' -or $relative -in 'archive-validation.log','archive-result.json','finalize.log','documentation-audit-final.json','documentation-audit-final.log'){continue}
 if($relative.StartsWith('candidate-v1/') -and $relative -notmatch '(/summary\.json$|\.log$|/tests/.*\.trx$|/before-test-identity\.json$)'){continue}
 if($relative -match '^(formal-final|extra-final|apochromat-final|high-sampling-final|fnum-final|polychromatic-final|polychromatic128-final|boundary128-final|offner-final|decenter-final|controls-final|aiming-final|matrix-circular|extended-controls-circular)/' -and $relative -notmatch '/(summary|normalized-workbench|normalized-zemax)\.json$'){continue}
 $payload['run/'+$relative]=$file.FullName
}
foreach($source in $proof.sourceFiles){$payload['source/'+$source.path]=Join-Path $repo $source.path}
foreach($path in 'AGENTS.md','ProductVersion.props','tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj','tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json','docs/CURRENT_STATUS.md','docs/NUMERICAL_PARITY.md','docs/OPEN_ISSUES_2026-10-08.md'){$payload['source/'+$path]=Join-Path $repo $path}
$report='docs/UPDATE_NUMERICAL_PRECISION_REPAIR_2026-10-19.md'
$payload['report/UPDATE_NUMERICAL_PRECISION_REPAIR_2026-10-19.md']=Join-Path $repo $report
$records=[Collections.Generic.List[object]]::new()
$stream=[IO.File]::Open($target,[IO.FileMode]::CreateNew)
try{
 $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
 try{
  foreach($key in @($payload.Keys|Sort-Object)){
   $bytes=[IO.File]::ReadAllBytes($payload[$key]);$entry=$zip.CreateEntry($key,[IO.Compression.CompressionLevel]::Optimal);$s=$entry.Open()
   try{$s.Write($bytes)}finally{$s.Dispose()}
   $records.Add(@{path=$key;bytes=$bytes.Length;sha256=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($bytes))})
  }
  $manifest=@{schemaVersion=1;scope='Post-update automatic derivative and coordinate precision repair; 25 counterexamples, App layering, old regressions and 165 unchanged formal numerical comparisons';entries=$records.ToArray();exclusions='Build intermediates and copied runtimes; duplicate first-candidate formal payloads except summaries; final report images and duplicate raw native inputs already frozen in preserved archives/fixtures; packaging and post-packaging audit logs'}|ConvertTo-Json -Depth 10
  $entry=$zip.CreateEntry('manifest.json');$s=$entry.Open();try{$s.Write([Text.Encoding]::UTF8.GetBytes($manifest))}finally{$s.Dispose()}
 }finally{$zip.Dispose()}
}finally{$stream.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($target)
try{
 if($zip.Entries.Count -ne $records.Count+1){throw 'Archive inventory differs'}
 foreach($record in $records){$s=$zip.GetEntry($record.path).Open();try{$actual=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($s))}finally{$s.Dispose()};if($actual -ne $record.sha256){throw 'Archive readback differs'}}
}finally{$zip.Dispose()}
$result=@{path=$relativeTarget;sha256=(Get-FileHash $target).Hash.ToLowerInvariant();bytes=(Get-Item $target).Length;entries=$records.Count+1;payloadEntries=$records.Count;allPayloadHashesVerified=$true}
$result|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'archive-result.json') -Encoding utf8NoBOM
$proof|Add-Member -NotePropertyName evidenceArchive -NotePropertyValue $result
$proof|ConvertTo-Json -Depth 80|Set-Content (Join-Path $repo 'docs/validation/UPDATE_NUMERICAL_PRECISION_REPAIR_2026-10-19.json') -Encoding utf8NoBOM
$result|ConvertTo-Json
