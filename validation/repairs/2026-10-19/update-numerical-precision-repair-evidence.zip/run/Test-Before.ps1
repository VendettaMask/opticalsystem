$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$core=Join-Path $repo 'tests/OpticalSystemDesign.Tests/bin/Release/net10.0/OpticalSystemDesign.Core.dll'
$candidate=[IO.File]::ReadAllBytes($core);$candidateHash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($candidate))
try{
 Copy-Item (Join-Path $PSScriptRoot 'Core.before.dll') $core
 dotnet test (Join-Path $repo 'tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj') -c Release --no-build --no-restore --filter FullyQualifiedName~DesignPrecisionRepairTests --logger 'trx;LogFileName=precision-before-complete.trx' --results-directory (Join-Path $PSScriptRoot 'tests') *> (Join-Path $PSScriptRoot 'tests-precision-before-complete.log')
 $exitCode=$LASTEXITCODE;if($exitCode -eq 0){throw 'Frozen before Core unexpectedly passed'}
}finally{[IO.File]::WriteAllBytes($core,$candidate)}
if((Get-FileHash $core).Hash.ToLowerInvariant() -ne $candidateHash){throw 'Final Core restore failed'}
@{beforeCoreSha256=(Get-FileHash (Join-Path $PSScriptRoot 'Core.before.dll')).Hash.ToLowerInvariant();candidateCoreSha256=$candidateHash;candidateRestored=$true;beforeExitCode=$exitCode}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'before-test-identity.json') -Encoding utf8NoBOM
Get-Content (Join-Path $PSScriptRoot 'tests-precision-before-complete.log') -Tail 3
