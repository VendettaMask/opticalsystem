$ErrorActionPreference='Stop'
$taskRoot=[IO.Path]::GetFullPath($PSScriptRoot)
$candidate=Join-Path $taskRoot 'candidate-v1'
New-Item -ItemType Directory -Path $candidate -Force|Out-Null
function Preserve([string]$name){
 $source=[IO.Path]::GetFullPath((Join-Path $taskRoot $name));$target=[IO.Path]::GetFullPath((Join-Path $candidate $name))
 if(!$source.StartsWith($taskRoot+[IO.Path]::DirectorySeparatorChar) -or !$target.StartsWith($candidate+[IO.Path]::DirectorySeparatorChar)){throw 'Move escaped audit folder'}
 if(!(Test-Path -LiteralPath $source) -or (Test-Path -LiteralPath $target)){throw ('Unexpected candidate path '+$name)}
 Move-Item -LiteralPath $source -Destination $target
}
foreach($name in 'tests','managed-results-Release','managed-results-Debug','formal-final','extra-final','apochromat-final','high-sampling-final','fnum-final','polychromatic-final','polychromatic128-final','boundary128-final','offner-final','decenter-final','controls-final','aiming-final','matrix-circular','extended-controls-circular'){
 Preserve $name
 if(Test-Path -LiteralPath (Join-Path $taskRoot ($name+'.log'))){Preserve ($name+'.log')}
}
foreach($file in Get-ChildItem -LiteralPath $taskRoot -File){
 if($file.Name -match '^(tests-|comparison-(Release|Debug)\.log$|build-(Release|Debug)\.log$|before-test-identity\.json$)' -or $file.Name -eq 'formal-groups.log'){Preserve $file.Name}
}
Copy-Item (Join-Path $taskRoot 'Core.release-final.dll') (Join-Path $taskRoot 'Core.candidate-v1.dll')
Copy-Item (Join-Path $taskRoot 'Core.debug-final.dll') (Join-Path $taskRoot 'Core.debug-candidate-v1.dll')
New-Item -ItemType Directory -Path (Join-Path $taskRoot 'tests') -Force|Out-Null
foreach($file in 'architecture-before.trx','precision-before.trx'){
 Copy-Item (Join-Path $candidate ('tests/'+$file)) (Join-Path $taskRoot ('tests/'+$file))
}
