$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
& (Join-Path $PSScriptRoot 'Prepare-Proof.ps1') *> (Join-Path $PSScriptRoot 'proof-validation.log')
if(!$?){throw 'Proof failed'}
git -C $repo diff --check
if($LASTEXITCODE -ne 0){throw 'Diff check failed'}
& (Join-Path $PSScriptRoot 'Pack-Evidence.ps1') *> (Join-Path $PSScriptRoot 'archive-validation.log')
if(!$?){throw 'Evidence packaging failed'}
$auditPath=Join-Path $PSScriptRoot 'documentation-audit-final.json'
& (Join-Path $repo 'scripts/verify-documentation.ps1') -RepositoryRoot $repo -OutputPath $auditPath -AuditDate 2026-10-19 -Strict *> (Join-Path $PSScriptRoot 'documentation-audit-final.log')
if(!$?){throw 'Documentation audit failed'}
$audit=Get-Content $auditPath -Raw|ConvertFrom-Json
if($audit.Documents -lt 934 -or $audit.BrokenLinks.Count -ne 0 -or $audit.MarkdownFenceIssues.Count -ne 0 -or $audit.LocalOnlyLinks.Count -ne 0 -or $audit.GuideRepeatedParagraphs.Count -ne 0){throw 'Documentation audit differs'}
$ledger=Join-Path $repo 'docs/validation/UPDATE_NUMERICAL_PRECISION_REPAIR_2026-10-19.json'
$proof=Get-Content $ledger -Raw|ConvertFrom-Json
$proof|Add-Member -NotePropertyName documentationAudit -NotePropertyValue @{documents=$audit.Documents;brokenLinks=0;markdownFenceIssues=0;localOnlyLinks=0;guideRepeatedParagraphGroups=0;sha256=(Get-FileHash $auditPath).Hash.ToLowerInvariant()}
$proof|ConvertTo-Json -Depth 80|Set-Content $ledger -Encoding utf8NoBOM
$archive=Join-Path $repo $proof.evidenceArchive.path
if((Get-FileHash $archive).Hash.ToLowerInvariant() -ne $proof.evidenceArchive.sha256){throw 'Final archive differs'}
$zip=[IO.Compression.ZipFile]::OpenRead($archive)
try{
 foreach($path in 'docs/CURRENT_STATUS.md','docs/NUMERICAL_PARITY.md','docs/OPEN_ISSUES_2026-10-08.md'){
  $s=$zip.GetEntry('source/'+$path).Open();try{$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($s))}finally{$s.Dispose()}
  if($hash -ne (Get-FileHash (Join-Path $repo $path)).Hash.ToLowerInvariant()){throw 'Archived current guide differs'}
 }
 $s=$zip.GetEntry('report/UPDATE_NUMERICAL_PRECISION_REPAIR_2026-10-19.md').Open();try{$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($s))}finally{$s.Dispose()}
 if($hash -ne (Get-FileHash (Join-Path $repo 'docs/UPDATE_NUMERICAL_PRECISION_REPAIR_2026-10-19.md')).Hash.ToLowerInvariant()){throw 'Archived report differs'}
}finally{$zip.Dispose()}
foreach($source in $proof.sourceFiles){if((Get-FileHash (Join-Path $repo $source.path)).Hash.ToLowerInvariant() -ne $source.sha256){throw 'Final source differs'}}
foreach($config in $proof.verification.configurations){foreach($copy in $config.coreCopies){if((Get-FileHash (Join-Path $repo $copy.path)).Hash.ToLowerInvariant() -ne $copy.sha256){throw 'Final default output differs'}}}
git -C $repo diff --check
if($LASTEXITCODE -ne 0){throw 'Final diff check failed'}
'Verified: 25 precision controls, original regression identities, 165 exactly unchanged formal metrics, default outputs, frozen evidence and archived source/documents.'
