using OpticalSystemDesign.Core.Differentiation;
using System.Security.Cryptography;
using System.Text.Json;

var a = DifferentialScalar.Variable(1, 1, 0, double.Epsilon);
var b = DifferentialScalar.Variable(2, 1, 0, -double.Epsilon);
var result = a / b;
Console.WriteLine(JsonSerializer.Serialize(new
{
    coreSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(DifferentialScalar).Assembly.Location))),
    value = result.Value,
    tangent = result.Derivative(0),
    expected = double.Epsilon,
    pass = result.Derivative(0) == double.Epsilon
}));
