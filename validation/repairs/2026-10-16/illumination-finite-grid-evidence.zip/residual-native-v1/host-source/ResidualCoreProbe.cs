using System.Text.Json;
using System.Reflection;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Services;
var root=Path.GetFullPath(args[0]);
var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root,"validation/zemax/2026-r1/tessar-ray-audit-2026-10-07/even-asphere-gq6-remove/source.zmx")),".zmx");
var type=typeof(IlluminationMetrics).GetNestedType("Integrator",BindingFlags.NonPublic)!;
var constructor=type.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance).Single();
var evaluate=type.GetMethod("Evaluate",BindingFlags.NonPublic|BindingFlags.Instance)!;
var records=new List<object>();
foreach(var density in new[]{5,10,20,40})
{
    var integrator=constructor.Invoke([optic,(0.0,0.0),.55,CancellationToken.None,false,false,optic.RayAimingEnabled]);
    var result=(IlluminationMetricResult)evaluate.Invoke(integrator,[density,IlluminationSamplingKind.FiniteImageCosine])!;
    var nodes=(System.Collections.IDictionary)type.GetField("_nodes",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(integrator)!;
    var sample=type.GetMethod("Sample",BindingFlags.NonPublic|BindingFlags.Instance)!;
    var ls=new List<double>(); var ms=new List<double>();
    var r=Math.Max(8,density/2)-1;
    for(var y=-r;y<=r;y++) for(var x=-r;x<=r;x++)
    {
        if(x*x+y*y>r*r)continue;
        var node=sample.Invoke(integrator,[x/(double)r,y/(double)r])!;
        var nt=node.GetType();
        if(!(bool)nt.GetProperty("Inside")!.GetValue(node)! || !(bool)nt.GetProperty("Mapped")!.GetValue(node)!)continue;
        ls.Add((double)nt.GetProperty("L")!.GetValue(node)!); ms.Add((double)nt.GetProperty("M")!.GetValue(node)!);
    }
    var cellArea=(ls.Max()-ls.Min())*(ms.Max()-ms.Min())*1.01*1.01/(4*density*density);
    records.Add(new{density,result.EffectiveFNumber,result.ProjectedCosineArea,cellArea});
}
File.WriteAllText(args[1],JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
