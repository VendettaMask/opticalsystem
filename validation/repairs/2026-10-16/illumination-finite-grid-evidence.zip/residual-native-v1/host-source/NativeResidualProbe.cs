using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using ZOSAPI;
using ZOSAPI.Editors.LDE;
using ZOSAPI.Editors.MFE;

internal static class NativeResidualProbe
{
    [STAThread]
    public static int Main(string[] args)
    {
        string api = args[0]; Host.Output = args[2];
        if (Directory.Exists(Host.Output) && Directory.EnumerateFileSystemEntries(Host.Output).Any()) return 2;
        Directory.CreateDirectory(Host.Output);
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e)
        {
            string path = Path.Combine(api, new AssemblyName(e.Name).Name + ".dll");
            return File.Exists(path) ? Assembly.LoadFrom(path) : null;
        };
        return Run(api, args[1]);
    }
    private static int Run(string api, string input)
    {
        IZOSAPI_Application app = null;
        try
        {
            if (!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api)) throw new Exception("Initialize failed");
            app = new ZOSAPI_Connection().CreateNewApplication();
            Host.Write("environment.json", Host.Object("version", app.OpticStudioVersion,"validLicense",app.IsValidLicenseForAPI));
            if (!app.IsValidLicenseForAPI || app.ZOSMajorVersion != 26 || app.ZOSMinorVersion != 1) throw new Exception("Wrong environment");
            var s = app.PrimarySystem;
            if (!s.LoadFile(input, false)) throw new Exception("Load failed");
            var records = new List<object>();
            foreach (int density in new[] { 5,10,20,40 })
                records.Add(Host.Object("kind","original","density",density,"efno",s.MFE.GetOperandValue(MeritOperandType.EFNO,density,1,1,0,0,0,0,0)));
            double distance = s.LDE.GetSurfaceAt(1).Thickness;
            s.LDE.GetSurfaceAt(1).Thickness = 0;
            var mask = s.LDE.InsertNewSurfaceAt(2); mask.Thickness = distance; mask.SemiDiameter = 20;
            s.UpdateStatus();
            foreach (int density in new[] { 5,10,20,40 })
                records.Add(Host.Object("kind","withPlane","density",density,"efno",s.MFE.GetOperandValue(MeritOperandType.EFNO,density,1,1,0,0,0,0,0)));
            var aperture = mask.ApertureData.CreateApertureTypeSettings(SurfaceApertureTypes.RectangularObscuration);
            aperture._S_RectangularObscuration.XHalfWidth = .001;
            aperture._S_RectangularObscuration.YHalfWidth = .001;
            if (!mask.ApertureData.ChangeApertureTypeSettings(aperture)) throw new Exception("Mask failed");
            s.UpdateStatus(); s.SaveAs(Path.Combine(Host.Output,"central-mask-control.zmx"));
            foreach (int density in new[] { 5,10,20,40 })
                records.Add(Host.Object("kind","centerBlocked","density",density,"efno",s.MFE.GetOperandValue(MeritOperandType.EFNO,density,1,1,0,0,0,0,0)));
            Host.Write("values.json",records); Host.Write("complete.json",Host.Object("complete",true)); return 0;
        }
        catch(Exception e) { Host.Write("error.json",Host.Object("error",e.ToString())); return 1; }
        finally { if(app != null) { try { app.PrimarySystem.LoadFile(input,false); } finally { app.CloseApplication(); } } }
    }
}
