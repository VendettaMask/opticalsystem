using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using ZOSAPI;
using ZOSAPI.Editors.LDE;
using ZOSAPI.Editors.MFE;

internal static class NativeWeightProbe
{
    [STAThread]
    public static int Main(string[] args)
    {
        Host.Output = args[2];
        if (Directory.Exists(Host.Output) && Directory.EnumerateFileSystemEntries(Host.Output).Any()) return 2;
        Directory.CreateDirectory(Host.Output);
        string api = args[0];
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e)
        {
            string path = Path.Combine(api, new AssemblyName(e.Name).Name + ".dll");
            return File.Exists(path) ? Assembly.LoadFrom(path) : null;
        };
        return Run(api, args[1]);
    }
    private static int Run(string api, string input)
    {
        IZOSAPI_Application app = null;
        try
        {
            if (!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api)) throw new Exception("Initialize failed");
            app = new ZOSAPI_Connection().CreateNewApplication();
            Host.Write("environment.json", Host.Object("version", app.OpticStudioVersion, "validLicense", app.IsValidLicenseForAPI));
            if (!app.IsValidLicenseForAPI || app.ZOSMajorVersion != 26 || app.ZOSMinorVersion != 1) throw new Exception("Wrong environment");
            var s = app.PrimarySystem;
            if (!s.LoadFile(input, false)) throw new Exception("Load failed");
            double distance = s.LDE.GetSurfaceAt(1).Thickness;
            s.LDE.GetSurfaceAt(1).Thickness = 0;
            var mask = s.LDE.InsertNewSurfaceAt(2); mask.Thickness = distance; mask.SemiDiameter = 2;
            s.UpdateStatus();
            var settings = mask.ApertureData.CreateApertureTypeSettings(SurfaceApertureTypes.RectangularObscuration);
            settings._S_RectangularObscuration.XHalfWidth = .0001;
            settings._S_RectangularObscuration.YHalfWidth = .0001;
            var records = new List<object>();
            foreach (int density in new[] { 5, 10, 20 })
            {
                if (!mask.ApertureData.ChangeApertureTypeSettings(mask.ApertureData.CreateApertureTypeSettings(SurfaceApertureTypes.None))) throw new Exception("Clear failed");
                s.UpdateStatus();
                double baseline = s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0);
                var rows = new List<object>();
                for (int iy = -density; iy <= density; iy++)
                {
                    for (int ix = -density; ix <= density; ix++)
                    {
                        double x = ix * 1.01 / density, y = iy * 1.01 / density;
                        var rectangle = settings._S_RectangularObscuration;
                        rectangle.ApertureXDecenter = x; rectangle.ApertureYDecenter = y;
                        if (!mask.ApertureData.ChangeApertureTypeSettings(settings)) throw new Exception("Mask failed");
                        s.UpdateStatus();
                        double value = s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0);
                        rows.Add(Host.Object("ix", ix, "iy", iy, "x", x, "y", y, "efno", Host.Finite(value)));
                    }
                    if (iy % 5 == 0) Console.WriteLine("density " + density + " row " + iy);
                }
                records.Add(Host.Object("density", density, "baseline", baseline, "rows", rows));
                Host.Write("weights.json", records);
            }
            Host.Write("complete.json", Host.Object("complete", true));
            return 0;
        }
        catch (Exception e) { Host.Write("error.json", Host.Object("error", e.ToString())); Console.Error.WriteLine(e); return 1; }
        finally
        {
            if (app != null)
            {
                try { app.PrimarySystem.LoadFile(input, false); }
                finally { app.CloseApplication(); }
            }
        }
    }
}
