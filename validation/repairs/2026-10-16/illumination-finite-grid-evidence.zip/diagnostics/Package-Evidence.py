import hashlib, json, re, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

task = Path(__file__).resolve().parent
root = task.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}

tests = {}
test_names = {}
for config in ['debug', 'release']:
    trx = ET.parse(task / f'test-results/related-{config}-final.trx')
    counters = trx.find('.//t:Counters', ns).attrib
    assert int(counters['total']) == int(counters['passed']) == 168 and int(counters['failed']) == 0
    results = trx.findall('.//t:UnitTestResult', ns)
    assert len(results) == 168 and all(row.attrib['outcome'] == 'Passed' for row in results)
    test_names[config] = sorted(row.attrib['testName'] for row in results)
    tests[config] = dict(total=168, passed=168, failed=0, skipped=0, source=f'test-results/related-{config}-final.trx')
    build = (task / f'build-{config}-final.log').read_text(encoding='utf-8-sig')
    assert '0 个警告' in build and '0 个错误' in build
    assert len(set(re.findall(r'^  ([A-Za-z0-9.]+) -> ', build, flags=re.M))) == 19
assert test_names['debug'] == test_names['release']

matrix = read(task / 'matrix-final.json')
before = read(root / 'artifacts/validation/native-illumination-20261016/current-illumination-accepted.json')
original = read(root / 'validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json')
summary = []
total = curvature = illumination = 0
maximum_curvature = 0
for case in matrix['Cases']:
    old = next(item for item in before['Cases'] if item['Name'] == case['Name'])
    reference = next(item for item in original['Cases'] if item['Name'] == case['Name'])
    assert case['SourceSha256'] == sha((root / reference['Source']).read_bytes()) == reference['SourceSha256']
    assert case['Capture'] == reference['Capture']
    assert all(row['Actual'] is not None and not row['Error'] for row in case['Comparisons'])
    for group in case['Summary']:
        total += group['Total']
        if group['Code'] in ['FCGS','FCGT']:
            assert group['Status'] == 'Pass' and group['ComparisonTarget'] == 1e-5
            curvature += group['Total']
            maximum_curvature = max(maximum_curvature, group['MaxAbsoluteError'])
        else:
            assert group['Status'] == 'Difference' and group['ComparisonTarget'] is None
            illumination += group['Total']
    summary.append(dict(name=case['Name'], source=reference['Source'], sourceSha256=reference['SourceSha256'],
        before=old['Summary'], after=case['Summary']))
assert total == 2416 and curvature == 2160 and illumination == 256
# The last direct tool run must agree with the earlier full prototype matrix.
assert [c['Comparisons'] for c in matrix['Cases']] == [c['Comparisons'] for c in read(task/'matrix-v3.json')['Cases']]

release_core = root / 'src/OpticalSystemDesign.Core/bin/Release/net10.0/OpticalSystemDesign.Core.dll'
assert sha(release_core.read_bytes()) == sha((root / 'tools/diagnostics/Accuracy20261014/bin/Release/net10.0/OpticalSystemDesign.Core.dll').read_bytes())

environment = read(task / 'native-final/environment.json')
assert environment['version'] == 260127 and environment['validLicense']
assert read(task / 'native-final/complete.json')['complete']
assert (task / 'NativeGridProbe.cs').read_bytes() == (root / 'tools/diagnostics/Accuracy20261014/NativeIlluminationGridCapture.cs').read_bytes()
for folder in ['native-final', 'node-v1', 'node-square-03-v1', 'node-square-05-v1', 'weights-v1','residual-native-v1','residual-native-v2']:
    assert read(task / folder / 'complete.json')['complete']

payloads = {}
def put(name, path):
    assert name not in payloads
    payloads[name] = path.read_bytes()

for folder in ['native-v1','native-v2','native-odd-v1','native-final','node-v1','node-square-03-v1','node-square-05-v1','weights-v1','residual-native-v1','residual-native-v2','test-results']:
    for path in sorted((task/folder).rglob('*')):
        if path.is_file() and path.suffix.lower() in ['.json','.zmx','.trx','.cs']:
            put(path.relative_to(task).as_posix(), path)
for path in sorted(task.iterdir()):
    if (path.is_file() and path.suffix.lower() in ['.cs','.csproj','.py','.ps1','.log','.json']
            and not path.name.startswith('package-') and not path.name.startswith('documentation-delivery')):
        put('diagnostics/'+path.name, path)

for path in sorted((root/'tools/OpticalSystemDesign.ZemaxComparison/ZemaxHost').glob('*.cs')):
    put('native-final/host-source/'+path.name, path)
put('native-final/host-source/NativeGridProbe.cs', task/'NativeGridProbe.cs')

source_files = [
    'src/OpticalSystemDesign.Core/Services/IlluminationMetrics.cs',
    'src/OpticalSystemDesign.Core/Services/IlluminationMetrics.FiniteImageCosine.cs',
    'src/OpticalSystemDesign.Core/Services/IlluminationMetrics.ImageCosine.cs',
    'src/OpticalSystemDesign.Core/Optimization/MeritFunction.Illumination.cs',
    'src/OpticalSystemDesign.Core/Analysis/RelativeIlluminationAnalysis.cs',
    'src/OpticalSystemDesign.Application/Runtime/WorkbenchRuntime.Analysis.cs',
    'src/OpticalSystemDesign.Application/Services/MeritOperandReferenceCatalog.cs',
    'tests/OpticalSystemDesign.Tests/FiniteIlluminationGridTests.cs',
    'tests/OpticalSystemDesign.Tests/GeometricIlluminationTests.cs',
    'tests/OpticalSystemDesign.Tests/IlluminationOperandTests.cs',
    'tools/diagnostics/Accuracy20261014/Program.cs',
    'tools/diagnostics/Accuracy20261014/Accuracy20261014.csproj',
    'tools/diagnostics/Accuracy20261014/NativeIlluminationGridCapture.cs',
]
for source in source_files: put('final-source/'+source, root/source)
put('before/current-illumination-accepted.json', root/'artifacts/validation/native-illumination-20261016/current-illumination-accepted.json')
for path in sorted((root/'validation/zemax/2026-r1/illumination-finite-grid-2026-10-16').iterdir()):
    if path.is_file(): put('controls/'+path.name, path)

for case in original['Cases']:
    put('original-four-sources/'+case['Name']+'.ZMX', root/case['Source'])
put('original-four-sources/manifest.json', root/'validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json')

readme = '''Final finite-grid repair evidence, 2026-10-16.
Original four-file captures/settings/acceptance targets remain unchanged.
native-final contains the exact Framework entry point/helper snapshot compiled for its capture.
diagnostics contains exploratory scripts at their LAST variant: NativeGridProbe densities were extended between native-v2/native-odd-v1/native-final; NativeNodeProbe mask half-width was 0.00035 in node-v1 and 0.00051 in square probes. Earlier variants are not asserted byte-identical to this last snapshot.
native-v1 is a failed column-type attempt and is excluded from native numerical conclusions.
One residual-node launcher invocation returned 2 before API startup because its output name assignment followed exit. The launcher was corrected; residual-native-v2 completed normally. Its exact compiled native source and fixed Core input are saved with the capture. ResidualCoreProbe's diagnostic source is its last variant; v3 additionally tests and rejects simple coarse-axis linear interpolation.
weights-v1 records one masked node at a time; the total native contribution reconstruction is in diagnostics/weight-reconstruction.log.
Final product source, default binary hashes and exact final tests are identified by the repository machine ledger. No DLL/EXE/PDB or proprietary API binary is distributed here.
Original sources use their registered identities; Cooke/Tessar independent cases are excluded.
'''
payloads['README.txt'] = readme.encode()
catalog = dict(files=[dict(path=name, size=len(data), sha256=sha(data)) for name,data in sorted(payloads.items())])
payloads['catalog.json'] = (json.dumps(catalog, indent=2)+'\n').encode()
archive = root/'validation/repairs/2026-10-16/illumination-finite-grid-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name,data in sorted(payloads.items()): output.writestr(name, data)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for row in catalog['files']:
        data = package.read(row['path'])
        assert sha(data) == row['sha256'] and len(data) == row['size']

curve_result = next(row for row in ET.parse(task/'test-results/related-release-final.trx').findall('.//t:UnitTestResult', ns)
    if '.ProductPolZeroCurveRetainsOriginalCapturedRelativeIlluminationGate' in row.attrib['testName'])
curve = json.loads(curve_result.find('t:Output/t:StdOut', ns).text.strip().split('ProductCapturedPolZero=')[1])
assert curve['Rmse'] <= .002 and curve['MaximumAbsoluteError'] <= .004

documentation = read(task/'documentation-final.json')
assert not documentation['BrokenLinks'] and not documentation['MarkdownFenceIssues'] and not documentation['LocalOnlyLinks']
assert not any(group['Scope']=='Guide' for group in documentation['RepeatedParagraphs'])
report = dict(date='2026-10-16', scope='Finite-grid EFNO/RELI repair; original four-file matrix and independent native square/node controls',
    nativeEnvironment=environment, originalMatrix=dict(total=2416, curvature=2160, illumination=256,
        curvatureTargetMm=1e-5, curvatureMaximumAbsoluteErrorMm=maximum_curvature, illuminationAcceptanceTarget=None,
        illuminationStatus='Difference', cases=summary), tests=tests, identicalTestNames=True, newTests=26,
    productCurve=dict(rmse=curve['Rmse'], maximumAbsoluteError=curve['MaximumAbsoluteError'], unchangedRmseGate=.002, unchangedMaximumGate=.004),
    remainingResidualIsolation=read(task/'residual-isolation-v1.json'),
    defaultBuilds=dict(debug=dict(projects=19,warnings=0,errors=0),release=dict(projects=19,warnings=0,errors=0)),
    defaultCoreSha256={config:sha((root/f'src/OpticalSystemDesign.Core/bin/{config}/net10.0/OpticalSystemDesign.Core.dll').read_bytes()) for config in ['Debug','Release']},
    finalSourceSha256={path:sha((root/path).read_bytes()) for path in source_files},
    evidence=dict(path=archive.relative_to(root).as_posix(),size=archive.stat().st_size,sha256=sha(archive.read_bytes()),
        entries=len(payloads),readbackVerified=True),
    limits=['No complete repository suite, installer rebuild, push or independent Cooke/Tessar investigation in this stage',
        'First-order scalar paraxial pupil-reference distance; not arbitrary 3D native certification',
        'Original four-file EFNO/RELI fine differences remain open; no acceptance threshold invented',
        'Native grid controls Pol=0; polarized software regressions are not new native polarization certification',
        'Synthetic PARAXIAL capture is constructed explicitly with the existing Core thin lens, not PARAXIAL import support'],
    retainedFailures=['build-release-v1: xUnit precision argument outside 0..15',
        'illumination-release-v2: 164 pass, 4 failures; target/moved synthetic thickness required Renumber; zero-distance IMSF is unavailable',
        'One residual launcher invocation returned 2 before API startup because the output-name assignment followed exit; corrected before successful v2 capture'],
    documentationVerification=dict(source='diagnostics/documentation-final.json',
        documents=read(task/'documentation-final.json')['Documents'], strict=True,
        brokenLinks=0,markdownFenceIssues=0,localOnlyLinks=0,guideRepeatedParagraphGroups=0))
target = root/'docs/validation/ILLUMINATION_FINITE_GRID_REPAIR_2026-10-16.json'
target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=report['evidence'],tests=tests,productCurve=report['productCurve']),indent=2))
