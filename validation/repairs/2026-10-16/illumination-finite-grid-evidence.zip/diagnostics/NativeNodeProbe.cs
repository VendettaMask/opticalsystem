using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using ZOSAPI;
using ZOSAPI.Editors.LDE;
using ZOSAPI.Editors.MFE;

internal static class NativeNodeProbe
{
    [STAThread]
    public static int Main(string[] args)
    {
        Host.Output = args[2];
        if (Directory.Exists(Host.Output) && Directory.EnumerateFileSystemEntries(Host.Output).Any()) return 2;
        Directory.CreateDirectory(Host.Output);
        string api = args[0];
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e)
        {
            string path = Path.Combine(api, new AssemblyName(e.Name).Name + ".dll");
            return File.Exists(path) ? Assembly.LoadFrom(path) : null;
        };
        return Run(api, args[1], args.Length > 3 ? double.Parse(args[3], System.Globalization.CultureInfo.InvariantCulture) : 0);
    }
    private static int Run(string api, string input, double width)
    {
        IZOSAPI_Application app = null;
        try
        {
            if (!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api)) throw new Exception("Initialize failed");
            app = new ZOSAPI_Connection().CreateNewApplication();
            Host.Write("environment.json", Host.Object("version", app.OpticStudioVersion, "major", app.ZOSMajorVersion,
                "minor", app.ZOSMinorVersion, "validLicense", app.IsValidLicenseForAPI, "license", app.LicenseStatus.ToString()));
            if (!app.IsValidLicenseForAPI || app.ZOSMajorVersion != 26 || app.ZOSMinorVersion != 1) throw new Exception("Wrong environment");
            var s = app.PrimarySystem;
            if (!s.LoadFile(input, false)) throw new Exception("Load failed");
            if (width > 0)
            {
                var a = s.LDE.GetSurfaceAt(1).ApertureData;
                var square = a.CreateApertureTypeSettings(SurfaceApertureTypes.RectangularAperture);
                square._S_RectangularAperture.XHalfWidth = width;
                square._S_RectangularAperture.YHalfWidth = width;
                if (!a.ChangeApertureTypeSettings(square)) throw new Exception("Square failed");
                s.UpdateStatus();
            }
            var baseline = new List<object>();
            foreach (int density in new[] { 5, 10, 20, 40 })
                baseline.Add(Host.Object("kind", "original", "density", density,
                    "efno", s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0)));
            double distance = s.LDE.GetSurfaceAt(1).Thickness;
            s.LDE.GetSurfaceAt(1).Thickness = 0;
            var mask = s.LDE.InsertNewSurfaceAt(2); mask.Thickness = distance; mask.SemiDiameter = 2;
            s.UpdateStatus();
            foreach (int density in new[] { 5, 10, 20, 40 })
                baseline.Add(Host.Object("kind", "withTransparentPlane", "density", density,
                    "efno", s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0)));
            Host.Write("baseline.json", baseline);
            s.SaveAs(Path.Combine(Host.Output, "transparent-control.zmx"));
            var settings = mask.ApertureData.CreateApertureTypeSettings(SurfaceApertureTypes.RectangularObscuration);
            foreach (bool point in new[] { false, true })
            {
                var rows = new List<object>();
                for (int index = -1000; index <= 1000; index++)
                {
                    var rectangle = settings._S_RectangularObscuration;
                    rectangle.XHalfWidth = .00051;
                    rectangle.YHalfWidth = point ? .00051 : 2;
                    rectangle.ApertureXDecenter = point ? 0 : index / 1000.0;
                    rectangle.ApertureYDecenter = point ? index / 1000.0 : 0;
                    if (!mask.ApertureData.ChangeApertureTypeSettings(settings)) throw new Exception("Mask change failed");
                    s.UpdateStatus();
                    var values = new List<object>();
                    foreach (int density in new[] { 5, 10 })
                        values.Add(Host.Object("density", density, "efno", Host.Finite(s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0))));
                    rows.Add(Host.Object("coordinate", index / 1000.0, "values", values));
                    if (index % 250 == 0) Console.WriteLine((point ? "point " : "strip ") + index);
                }
                Host.Write(point ? "point-scan.json" : "strip-scan.json", rows);
            }
            Host.Write("complete.json", Host.Object("complete", true));
            return 0;
        }
        catch (Exception e) { Host.Write("error.json", Host.Object("error", e.ToString())); Console.Error.WriteLine(e); return 1; }
        finally
        {
            if (app != null)
            {
                try { app.PrimarySystem.LoadFile(input, false); }
                finally { app.CloseApplication(); }
            }
        }
    }
}
