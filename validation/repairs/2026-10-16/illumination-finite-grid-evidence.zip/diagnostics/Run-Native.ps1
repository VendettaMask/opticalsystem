param([string]$OutputName = 'native-v1', [string]$MainName = 'NativeGridProbe', [string]$StopHalfWidth = '0')
$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$api = 'D:\Program Files\ANSYS Inc\v261\Zemax OpticStudio'
$exe = Join-Path $PSScriptRoot ($MainName+'.exe')
$compileArgs = @('/nologo','/target:exe','/platform:x64',('/main:'+$MainName),('/out:' + $exe),'/r:System.Web.Extensions.dll')
foreach ($name in @('ZOSAPI.dll','ZOSAPI_Interfaces.dll','ZOSAPI_NetHelper.dll')) { $compileArgs += '/r:' + (Join-Path $api $name) }
$compileArgs += @(Get-ChildItem (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/ZemaxHost') -Filter '*.cs' | ForEach-Object FullName)
$compileArgs += (Join-Path $PSScriptRoot ($MainName+'.cs'))
& (Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe') @compileArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
[IO.File]::WriteAllText(($exe+'.config'),'<configuration><startup useLegacyV2RuntimeActivationPolicy="true"><supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.8"/></startup></configuration>')
$env:PATH = $api + ';' + $env:PATH
& $exe $api (Join-Path $repo 'artifacts/validation/fcgt-efno-20261014/controls/slow-ideal-lens.ZMX') (Join-Path $PSScriptRoot $OutputName) $StopHalfWidth 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot ($OutputName+'.log'))
exit $LASTEXITCODE
