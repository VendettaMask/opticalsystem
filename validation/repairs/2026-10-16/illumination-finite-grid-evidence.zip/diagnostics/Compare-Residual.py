import json,math
from pathlib import Path
p=Path(__file__).resolve().parent
native=json.loads((p/'residual-native-v1/values.json').read_text(encoding='utf-8-sig'))
core=json.loads((p/'residual-core-v1.json').read_text(encoding='utf-8-sig'))
rows=[]
for item in core:
    density=item['density']
    values={r['kind']:r['efno'] for r in native if r['density']==density}
    assert values['original']==values['withPlane']
    cell_area=math.pi/4*(1/values['withPlane']**2-1/values['centerBlocked']**2)
    rows.append(dict(density=density,nativeBaseline=values['original'],nativeCellArea=cell_area,coreCellArea=item['cellArea'],
        relativeCellAreaDifference=item['cellArea']/cell_area-1,
        relativeEfnoDifference=item['EffectiveFNumber']/values['original']-1))
node_rows=[]
nodes_path=p/'residual-native-v2/inverse-nodes.json'
if nodes_path.exists():
    core_nodes=json.loads((p/'residual-core-v2.json').read_text(encoding='utf-8-sig'))
    for node in json.loads(nodes_path.read_text(encoding='utf-8-sig')):
        item=next(r for r in core_nodes if r['density']==node['density'])
        assert len(node['hits'])==2
        half=node['halfWidth']
        lower=max(hit['maskX']-half for hit in node['hits'])/10
        upper=min(hit['maskX']+half for hit in node['hits'])/10
        native_pupil=(lower+upper)/2
        edge=math.sin(math.pi/2*min(1,max(0,node['density']*(1-abs(native_pupil)))))**2
        measured=math.pi/4*(1/node['baseline']**2-1/node['hits'][0]['efno']**2)/item['cellArea']
        edge_bounds=[math.sin(math.pi/2*min(1,max(0,node['density']*(1-abs(value)))))**2 for value in [lower,upper]]
        assert min(edge_bounds)-1e-9 <= measured <= max(edge_bounds)+1e-9
        node_rows.append(dict(density=node['density'],corePupilX=item['pupilX'],nativePupilXInterval=[lower,upper],
            nativePupilXMidpoint=native_pupil,normalizedPupilDifference=native_pupil-item['pupilX'],
            coreEdgeWeight=item['edge'],nativeObservedWeight=measured,nativeCoordinateFormulaWeight=edge,
            coordinateFormulaWeightInterval=edge_bounds))
report=dict(scope='Even Asphere wave 1 axial field; central and edge nodes blocked after the stop; transparent plane leaves baseline identical',
    rows=rows,inverseNodes=node_rows,conclusion='Central cell area agrees at ~3e-11 relative; two native edge-node pupil positions differ from tightly converged shared-Core inversion by ~9e-6 normalized pupil. Observed native node weight is consistent with the same sine-squared profile evaluated at the native coordinate interval. This isolates a finite inverse-position difference in these controls, not universal native solver reconstruction.')
(p/'residual-isolation-v1.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
