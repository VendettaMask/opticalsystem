using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Apertures;
using OpticalSystemDesign.Core.Interactions;
using OpticalSystemDesign.Core.Services;

var records = new List<object>();
foreach (var width in new[] { .3, .5 })
foreach (var density in new[] { 5, 10, 18, 20, 40, 100, 128 })
{
    var optic = new Optic(); optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint()); optic.Wavelengths.Add(new Wavelength { Nanometers = 550 });
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = double.PositiveInfinity },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = 1000,
            InteractionModel = new ThinLensInteractionModel(1000), PhysicalAperture = new RectangularAperture(width, width) },
        new OpticalSurface()
    ]);
    var result = IlluminationMetrics.Evaluate(optic, (0, 0), .55, density,
        sampling: IlluminationSamplingKind.FiniteImageCosine, includeScalarTransmission: false);
    var record = new { width, density, result.EffectiveFNumber, result.IntegrationSamples };
    records.Add(record); Console.WriteLine(JsonSerializer.Serialize(record));
}
File.WriteAllText(args[0], JsonSerializer.Serialize(records, new JsonSerializerOptions { WriteIndented = true }));
