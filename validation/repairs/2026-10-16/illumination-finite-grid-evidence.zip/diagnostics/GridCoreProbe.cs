using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Services;

var root = Path.GetFullPath(args[0]);
var output = Path.GetFullPath(args[1]);
using var manifest = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json")));
var records = new List<object>();
foreach (var item in manifest.RootElement.GetProperty("Cases").EnumerateArray())
foreach (var aiming in new[] { false, true })
{
    var optic = OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root, item.GetProperty("Source").GetString()!)), ".zmx");
    var configuredAiming = optic.RayAimingEnabled;
    optic.RayAimingEnabled = aiming;
    using var capture = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, item.GetProperty("Capture").GetString()!, "operands.json")));
    foreach (var density in new[] { 5, 10, 40 })
    {
        var results = new List<(int Field, IlluminationMetricResult Result)>();
        foreach (var field in new[] { 1, optic.Fields.Count }.Distinct())
        {
            var definition = optic.Fields[field - 1];
            var normalized = FieldCoordinates.Normalize(optic.Fields, definition.X, definition.Y);
            try
            {
                results.Add((field, IlluminationMetrics.Evaluate(optic, normalized, optic.Wavelengths[0].Micrometers,
                    density, sampling: IlluminationSamplingKind.FiniteImageCosine, includeScalarTransmission: false)));
            }
            catch (Exception e) { Console.WriteLine(JsonSerializer.Serialize(new { Name = item.GetProperty("Name").GetString(), aiming, density, field, Error = e.ToString() })); }
        }
        foreach (var (field, result) in results)
        {
            var native = capture.RootElement.EnumerateArray().Single(row => row.GetProperty("code").GetString() == "EFNO"
                && row.GetProperty("wave").GetInt32() == 1 && row.GetProperty("field").GetInt32() == field && row.GetProperty("density").GetInt32() == density).GetProperty("value").GetDouble();
            var record = new { Name = item.GetProperty("Name").GetString(), Aiming = aiming, ConfiguredAiming = configuredAiming,
                Density = density, Field = field, Native = native, Actual = result.EffectiveFNumber,
                RelativeError = result.EffectiveFNumber / native - 1, result.ValidRays, result.SampledPupilNodes };
            records.Add(record); Console.WriteLine(JsonSerializer.Serialize(record));
        }
    }
}
File.WriteAllText(output, JsonSerializer.Serialize(records, new JsonSerializerOptions { WriteIndented = true }));
