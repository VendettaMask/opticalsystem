import hashlib, json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
task = Path(__file__).resolve().parent
target = root / 'validation/zemax/2026-r1/illumination-finite-grid-2026-10-16'
environment = json.loads((task / 'native-final/environment.json').read_text(encoding='utf-8-sig'))
assert environment['validLicense'] and environment['version'] == 260127
assert json.loads((task / 'native-final/complete.json').read_text(encoding='utf-8-sig'))['complete']
rows = []
for width in [.3, .5]:
    values = json.loads((task / f'native-final/square-{width}-operands.json').read_text(encoding='utf-8-sig'))
    before = [r for r in values if r['kind'] == 'beforeReload']
    after = [r for r in values if r['kind'] == 'afterReload']
    mfe = [r for r in values if r['kind'] == 'mfeRow']
    assert len(before) == len(after) == len(mfe) == 15
    for a, b, c in zip(before, after, mfe):
        assert a['density'] == b['density'] and c['density'] == min(a['density'], 100)
        assert a['value'] == b['value'] == c['value']
        rows.append(dict(halfWidth=width, density=a['density'], effectiveDensity=c['density'], value=c['value']))
source = target / 'slow-ideal-lens.ZMX'
report = dict(scope='Independent synthetic square-aperture finite-grid controls; not certification of native lens EFNO',
    environment=environment,
    source=dict(file=source.name, sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        interpretation='Native PARAXIAL focal length 1000 mm, ENPD 2 mm, infinite object, BFL 1000 mm; Core uses its existing ThinLensInteractionModel explicitly, not a claim of PARAXIAL import support'),
    settings=dict(wave=1, field=1, pol=0, configuration=1, aperture='RectangularAperture XHalfWidth=YHalfWidth',
        consistency='GetOperandValue before/after SaveAs new file/reload and actual MFE rows agree exactly'), rows=rows)
(target / 'controls.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print('Wrote', len(rows), 'verified controls')
