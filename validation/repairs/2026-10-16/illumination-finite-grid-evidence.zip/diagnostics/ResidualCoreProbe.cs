using System.Text.Json;
using System.Reflection;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Services;
var root=Path.GetFullPath(args[0]);
var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root,"validation/zemax/2026-r1/tessar-ray-audit-2026-10-07/even-asphere-gq6-remove/source.zmx")),".zmx");
var type=typeof(IlluminationMetrics).GetNestedType("Integrator",BindingFlags.NonPublic)!;
var constructor=type.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance).Single();
var evaluate=type.GetMethod("Evaluate",BindingFlags.NonPublic|BindingFlags.Instance)!;
var records=new List<object>();
foreach(var density in new[]{5,10,20,40})
{
    var integrator=constructor.Invoke([optic,(0.0,0.0),.55,CancellationToken.None,false,false,optic.RayAimingEnabled]);
    var result=(IlluminationMetricResult)evaluate.Invoke(integrator,[density,IlluminationSamplingKind.FiniteImageCosine])!;
    var nodes=(System.Collections.IDictionary)type.GetField("_nodes",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(integrator)!;
    var sample=type.GetMethod("Sample",BindingFlags.NonPublic|BindingFlags.Instance)!;
    var ls=new List<double>(); var ms=new List<double>();
    var r=Math.Max(8,density/2)-1;
    for(var y=-r;y<=r;y++) for(var x=-r;x<=r;x++)
    {
        if(x*x+y*y>r*r)continue;
        var node=sample.Invoke(integrator,[x/(double)r,y/(double)r])!;
        var nt=node.GetType();
        if(!(bool)nt.GetProperty("Inside")!.GetValue(node)! || !(bool)nt.GetProperty("Mapped")!.GetValue(node)!)continue;
        ls.Add((double)nt.GetProperty("L")!.GetValue(node)!); ms.Add((double)nt.GetProperty("M")!.GetValue(node)!);
    }
    var cellArea=(ls.Max()-ls.Min())*(ms.Max()-ms.Min())*1.01*1.01/(4*density*density);
    var l=(ls.Max()+ls.Min())/2+(density-1)*(ls.Max()-ls.Min())*1.01/(2*density);
    var m=(ms.Max()+ms.Min())/2;
    var inverse=type.GetMethod("InvertImageCosine",BindingFlags.NonPublic|BindingFlags.Instance)!;
    var boundaryNode=inverse.Invoke(integrator,[l,m,-(density-1)*1.01/density,0.0,1e-12])!;
    var pupilX=(double)boundaryNode.GetType().GetProperty("X")!.GetValue(boundaryNode)!;
    var pupilY=(double)boundaryNode.GetType().GetProperty("Y")!.GetValue(boundaryNode)!;
    var edge=Math.Pow(Math.Sin(Math.PI/2*Math.Clamp(density*(1-double.Hypot(pupilX,pupilY)),0,1)),2);
    var axis=new List<(double X,double L)>();
    for(var x=-r;x<=r;x++)
    {
        var node=sample.Invoke(integrator,[x/(double)r,0.0])!;
        axis.Add((x/(double)r,(double)node.GetType().GetProperty("L")!.GetValue(node)!));
    }
    axis=axis.OrderBy(p=>p.L).ToList();
    var bracket=Enumerable.Range(0,axis.Count-1).Single(i=>l>=axis[i].L&&l<axis[i+1].L);
    var a=axis[bracket]; var b=axis[bracket+1];
    var interpolatedX=a.X+(l-a.L)/(b.L-a.L)*(b.X-a.X);
    records.Add(new{density,result.EffectiveFNumber,result.ProjectedCosineArea,cellArea,pupilX,pupilY,edge,interpolatedX});
}
File.WriteAllText(args[1],JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
