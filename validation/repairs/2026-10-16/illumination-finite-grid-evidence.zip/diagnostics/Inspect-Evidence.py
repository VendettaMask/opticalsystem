import json, math
from pathlib import Path
task = Path(__file__).resolve().parent
for item in json.loads((task / 'weights-v1/weights.json').read_text(encoding='utf-8-sig')):
    d, efno = item['density'], item['baseline']
    area = math.pi / (4 * efno * efno)
    delta = 1.01 / (d * math.sqrt(1000001))
    changes = []
    for row in item['rows']:
        if row['efno'] is None: continue
        difference = area - math.pi / (4 * row['efno'] ** 2)
        changes.append(difference)
    print('Native node-weight reconstruction', d, 'relative area residual', sum(changes)/area - 1)
    for indices in ([(4,0),(4,2)] if d == 5 else [(d-1,0),(d-1,2)]):
        row = next(row for row in item['rows'] if (row['ix'],row['iy']) == indices)
        measured = (area - math.pi/(4*row['efno']**2))/delta**2
        angular2 = (row['ix']**2+row['iy']**2)*delta**2
        rho = 1000 * math.sqrt(angular2/(1-angular2))
        expected = math.sin(math.pi/2*min(1,max(0,d*(1-rho))))**2
        print(indices, 'observed edge weight', measured, 'formula', expected)
