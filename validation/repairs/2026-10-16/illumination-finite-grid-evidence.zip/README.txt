Final finite-grid repair evidence, 2026-10-16.
Original four-file captures/settings/acceptance targets remain unchanged.
native-final contains the exact Framework entry point/helper snapshot compiled for its capture.
diagnostics contains exploratory scripts at their LAST variant: NativeGridProbe densities were extended between native-v2/native-odd-v1/native-final; NativeNodeProbe mask half-width was 0.00035 in node-v1 and 0.00051 in square probes. Earlier variants are not asserted byte-identical to this last snapshot.
native-v1 is a failed column-type attempt and is excluded from native numerical conclusions.
One residual-node launcher invocation returned 2 before API startup because its output name assignment followed exit. The launcher was corrected; residual-native-v2 completed normally. Its exact compiled native source and fixed Core input are saved with the capture. ResidualCoreProbe's diagnostic source is its last variant; v3 additionally tests and rejects simple coarse-axis linear interpolation.
weights-v1 records one masked node at a time; the total native contribution reconstruction is in diagnostics/weight-reconstruction.log.
Final product source, default binary hashes and exact final tests are identified by the repository machine ledger. No DLL/EXE/PDB or proprietary API binary is distributed here.
Original sources use their registered identities; Cooke/Tessar independent cases are excluded.
