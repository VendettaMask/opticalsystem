using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Apertures;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Materials;
using OpticalSystemDesign.Core.Services;

var pixels = new double[1, 16, 16];
for (var row = 0; row < 16; row++)
    for (var column = 0; column < 16; column++) pixels[0, row, column] = 1;
var source = new RgbImage(pixels);

Run("no-aberration-uniform-image", () =>
{
    var result = ImageSimulationEngine.Simulate(Cone(), source, Config(illumination: false));
    return new { SourceCorner = result.Source[0, 0, 0], OutputCorner = result.Simulated[0, 0, 0],
        OutputEdge = result.Simulated[0, 0, 8], OutputCenter = result.Simulated[0, 8, 8],
        result.MeanAbsoluteChange, Minimum = result.Simulated.Values.Cast<double>().Min(),
        Maximum = result.Simulated.Values.Cast<double>().Max(), result.EffectiveAberrationMode };
});

Run("polarization-setting", () =>
{
    var optic = Cone(glass: true);
    var a = ImageSimulationEngine.Simulate(optic, source, Config(polarization: false));
    var b = ImageSimulationEngine.Simulate(optic, source, Config(polarization: true));
    var physicalScalar = IlluminationMetrics.RelativeToAxis(optic, (0, 1), .55, 5);
    var physicalPolarized = IlluminationMetrics.RelativeToAxis(optic, (0, 1), .55, 5, usePolarization: true);
    var advertised = new ImageSimulationAnalysis(optic, Config(polarization: true)).GenerateData();
    return new { MaximumImageDifference = Difference(a.Simulated.Values, b.Simulated.Values),
        PhysicalScalarRi = physicalScalar, PhysicalPolarizedRi = physicalPolarized,
        AdvertisedPolarization = advertised.Values["UsePolarization"], advertised.Outcome };
});

Run("absorbing-polarization-setting", () =>
{
    var optic = Cone(glass: true, extinction: 1e-6);
    string physicalOutcome;
    try { _ = IlluminationMetrics.Evaluate(optic, (0, 0), .55, 5, usePolarization: true); physicalOutcome = "Success"; }
    catch (Exception e) { physicalOutcome = e.GetType().Name + ": " + e.Message; }
    var advertised = new ImageSimulationAnalysis(optic, Config(polarization: true)).GenerateData();
    return new { PhysicalOutcome = physicalOutcome, ImageSimulationOutcome = advertised.Outcome,
        AdvertisedPolarization = advertised.Values["UsePolarization"] };
});

Run("fixed-aperture-setting", () =>
{
    var optic = Cone();
    var open = ImageSimulationEngine.Simulate(optic, source, Config());
    optic.SurfaceGroup.Items[2].PhysicalAperture = new OffsetRadialAperture(.55, offsetX: .25);
    var on = ImageSimulationEngine.Simulate(optic, source, Config(fixedApertures: true));
    var off = ImageSimulationEngine.Simulate(optic, source, Config(fixedApertures: false));
    return new { ApertureOnVsOff = Difference(on.Simulated.Values, off.Simulated.Values),
        DisabledVsActuallyOpen = Difference(off.Simulated.Values, open.Simulated.Values),
        ApertureStillPresent = optic.SurfaceGroup.Items[2].PhysicalAperture is not null };
});

Run("distortion-work-budget", () =>
{
    const int degree = 200;
    var cfg = Config(degree: degree);
    AnalysisResourceLimits.ValidateImageSimulation(source, cfg);
    var samples = (long)(degree + 1) * (degree + 1);
    var features = (long)(degree + 1) * (degree + 2) / 2;
    return new { Validation = "Accepted", SmallImage = "16 x 16", Degree = degree,
        DesignMatrixBytes = samples * features * sizeof(double), AllocationAttempted = false };
});

Run("distortion-grid-overflow", () =>
{
    var cfg = Config(distortionGrid: 65_536);
    AnalysisResourceLimits.ValidateImageSimulation(source, cfg);
    try { _ = ImageSimulationEngine.GenerateDistortionGrid(Cone(), new Wavelength { Nanometers = 550 }, 16, 16, 65_536, 1); return new { Validation = "Accepted", Outcome = "Success" }; }
    catch (Exception e) { return new { Validation = "Accepted", Outcome = e.GetType().Name + ": " + e.Message }; }
});

Run("psf-row-orientation", () =>
{
    var optic = OpticalFormatCatalog.Import(File.ReadAllText("artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX"), ".zmx");
    var wave = new Wavelength { Nanometers = 440 };
    ImageSimulationConfig BasisConfig(int rows, double center, double fieldHeight) => new()
    {
        ImageWidth = 16, ImageHeight = 16, PsfGridRows = rows, PsfGridColumns = 1,
        PsfSize = 16, NumRays = 16, Components = 2, Padding = 0, PixelSizeMillimeters = .0005,
        FieldHeight = fieldHeight, FieldCenterY = center, AberrationMode = "Geometric", Reference = "centroid"
    };
    var basis = ImageSimulationEngine.GenerateBasis(optic, wave, BasisConfig(3, .5, 1.8));
    var low = ImageSimulationEngine.GenerateBasis(optic, wave, BasisConfig(1, .3, 1e-8));
    var high = ImageSimulationEngine.GenerateBasis(optic, wave, BasisConfig(1, .7, 1e-8));
    return new { RowZeroVsLow = PsfDifference(Reconstruct(basis, 0), low.MeanPsf),
        RowZeroVsHigh = PsfDifference(Reconstruct(basis, 0), high.MeanPsf),
        LastRowVsLow = PsfDifference(Reconstruct(basis, 2), low.MeanPsf),
        LastRowVsHigh = PsfDifference(Reconstruct(basis, 2), high.MeanPsf) };
});

static Optic Cone(bool glass = false, double extinction = 0)
{
    var optic = new Optic { FieldDefinition = FieldDefinitionKind.ObjectHeight };
    optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint { Y = 2 });
    optic.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    var material = new ConstantIndexMaterial("audit-plate", glass ? 1.5 : 1, extinction);
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = 10 },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = 2, MaterialAfter = material },
        new OpticalSurface { Thickness = 8, MaterialBefore = material },
        new OpticalSurface()
    ]);
    return optic;
}

static ImageSimulationConfig Config(bool polarization = false, bool fixedApertures = true,
    bool illumination = true, int degree = 1, int distortionGrid = 3) => new()
{
    ImageWidth = 16, ImageHeight = 16, Padding = 0, WavelengthsMicrometers = [.55],
    PsfGridRows = 1, PsfGridColumns = 1, PsfSize = 8, NumRays = 8, Components = 1,
    PixelSizeMillimeters = .01, FieldHeight = 1, AberrationMode = "None",
    UseRelativeIllumination = illumination, UsePolarization = polarization,
    ApplyFixedApertures = fixedApertures, DistortionGridSize = distortionGrid, DistortionPolynomialDegree = degree,
    SourceImage = new RgbImage(Fill())
};

static double[,,] Fill()
{
    var values = new double[1, 16, 16];
    for (var y = 0; y < 16; y++) for (var x = 0; x < 16; x++) values[0, y, x] = 1;
    return values;
}

static double Difference(double[,,] a, double[,,] b) => a.Cast<double>().Zip(b.Cast<double>(), (x, y) => Math.Abs(x - y)).Max();
static double PsfDifference(double[,] a, double[,] b) => a.Cast<double>().Zip(b.Cast<double>(), (x, y) => Math.Abs(x - y)).Max();
static double[,] Reconstruct(PsfBasisResult basis, int row)
{
    var result = (double[,])basis.MeanPsf.Clone();
    for (var c = 0; c < basis.EigenPsfs.Length; c++)
        for (var y = 0; y < result.GetLength(0); y++)
            for (var x = 0; x < result.GetLength(1); x++) result[y, x] += basis.CoefficientGrid[c, row, 0] * basis.EigenPsfs[c][y, x];
    return result;
}

static void Run(string name, Func<object> action)
{
    var watch = System.Diagnostics.Stopwatch.StartNew();
    try { Console.WriteLine(JsonSerializer.Serialize(new { Name = name, Result = action(), Milliseconds = watch.ElapsedMilliseconds })); }
    catch (Exception e) { Console.WriteLine(JsonSerializer.Serialize(new { Name = name, Error = e.ToString(), Milliseconds = watch.ElapsedMilliseconds })); }
}
