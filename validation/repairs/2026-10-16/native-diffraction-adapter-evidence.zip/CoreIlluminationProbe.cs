using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Services;

var root = Path.GetFullPath(args[0]);
using var manifest = JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json")));
var records=new List<object>();
foreach(var entry in manifest.RootElement.GetProperty("Cases").EnumerateArray())
{
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root,entry.GetProperty("Source").GetString()!)),".zmx");
 var name=entry.GetProperty("Name").GetString();
 foreach(var wave in optic.Wavelengths.Select(w=>w.Micrometers))
 foreach(var hy in new[]{0d,1d})
 {
  OpticalSystemDesign.Core.Rays.RealRay sample(double x,double y)=>optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,hy,x,y,wave,aimAtStop:true).Rays.Single();
  var image=optic.SurfaceGroup.Items[^1];
  var c=optic.SequentialRayTracer.DiagnoseApertures(sample(0,0),stopAtIncidentImage:true,ignoreScalarTransmission:true).UnclippedImage!;
  var center=image.CoordinateSystem.ToLocalPoint(c.Position);
  var exit=optic.Paraxial.EstimateExitPupilLocation(wave);
  var raw=new List<(double X,double Y)>(); var corrected=new List<(double X,double Y)>(); int inside=0;
  for(int i=0;i<720;i++)
  {
   var angle=2*Math.PI*i/720;
   var ray=optic.SequentialRayTracer.DiagnoseApertures(sample(Math.Cos(angle),Math.Sin(angle)),stopAtIncidentImage:true,ignoreScalarTransmission:true);
   if(ray.InsideAllApertures)inside++;
   if(ray.UnclippedImage is not {} r)throw new Exception("No image");
   var p=image.CoordinateSystem.ToLocalPoint(r.Position); var d=image.CoordinateSystem.ToLocalDirection(r.IncidentDirection??r.Direction);
   raw.Add((d.X,d.Y));
   var delta=p-center; var correctedDirection=d+delta*(d.Z/(exit-p.Z)); correctedDirection/=correctedDirection.Length;
   corrected.Add((correctedDirection.X,correctedDirection.Y));
  }
  double Area(List<(double X,double Y)> points)=>Math.Abs(Enumerable.Range(0,points.Count).Sum(i=>points[i].X*points[(i+1)%points.Count].Y-points[(i+1)%points.Count].X*points[i].Y))/2;
  var a=Area(raw); var b=Area(corrected);
  var record=new {Name=name,Wave=wave,Hy=hy,Exit=exit,Inside=inside,RawF=.5*Math.Sqrt(Math.PI/a),CorrectedF=.5*Math.Sqrt(Math.PI/b)};
  records.Add(record); Console.WriteLine(JsonSerializer.Serialize(record));
 }
}
File.WriteAllText(Path.Combine(root,"artifacts/validation/native-illumination-20261016/exit-pupil-probe.json"),JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
