using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using ZOSAPI;
using ZOSAPI.Editors.LDE;
using ZOSAPI.Editors.MFE;

internal static class NativeIlluminationProbe
{
    [STAThread]
    public static int Main(string[] args)
    {
        string api = args[0], input = args[1];
        Host.Output = args[2];
        if (Directory.Exists(Host.Output) && Directory.EnumerateFileSystemEntries(Host.Output).Any()) return 2;
        Directory.CreateDirectory(Host.Output);
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e)
        {
            string path = Path.Combine(api, new AssemblyName(e.Name).Name + ".dll");
            return File.Exists(path) ? Assembly.LoadFrom(path) : null;
        };
        return Run(api, input);
    }
    private static int Run(string api, string input)
    {
        IZOSAPI_Application app = null;
        try
        {
            if (!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api)) throw new Exception("API initialization failed");
            app = new ZOSAPI_Connection().CreateNewApplication();
            Host.Write("environment.json", Host.Object("version", app.OpticStudioVersion, "major", app.ZOSMajorVersion,
                "minor", app.ZOSMinorVersion, "validLicense", app.IsValidLicenseForAPI, "license", app.LicenseStatus.ToString()));
            if (!app.IsValidLicenseForAPI || app.ZOSMajorVersion != 26 || app.ZOSMinorVersion != 1) throw new Exception("Wrong environment");
            var s = app.PrimarySystem;
            if (!s.LoadFile(input, false)) throw new Exception("Load failed");
            var baseline = new List<object>();
            foreach (int density in new[] { 5, 6, 7, 8, 9, 10, 12, 15, 20, 30, 40, 80, 100, 101, 128 })
                baseline.Add(Host.Object("density", density, "efno", s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0)));
            Host.Write("density-sweep.json", baseline);
            var focusRows = new List<object>();
            foreach (string name in new[] { "slow-ideal-lens.ZMX", "ideal-lens.ZMX", "cone.ZMX" })
            {
                if (!s.LoadFile(Path.Combine(Path.GetDirectoryName(input), name), false)) throw new Exception("Control load failed");
                double original = s.LDE.GetSurfaceAt(1).Thickness;
                foreach (double factor in new[] { .5, 1.0, 2.0 })
                {
                    s.LDE.GetSurfaceAt(1).Thickness = original * factor;
                    s.UpdateStatus();
                    var values = new List<object>();
                    foreach (int density in new[] { 5, 10, 40 })
                        values.Add(Host.Object("density", density, "efno", s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0)));
                    focusRows.Add(Host.Object("control", name, "distance", original * factor, "values", values));
                }
            }
            Host.Write("focus-sweep.json", focusRows);
            if (!s.LoadFile(input, false)) throw new Exception("Reset failed");
            var aperture = s.LDE.GetSurfaceAt(1).ApertureData;
            var squareRows = new List<object>();
            foreach (double width in new[] { .3, .5, .7, .99 })
            {
                var square = aperture.CreateApertureTypeSettings(SurfaceApertureTypes.RectangularAperture);
                square._S_RectangularAperture.XHalfWidth = width;
                square._S_RectangularAperture.YHalfWidth = width;
                if (!aperture.ChangeApertureTypeSettings(square)) throw new Exception("Square failed");
                s.UpdateStatus();
                var values = new List<object>();
                foreach (int density in new[] { 5, 10, 20, 40 })
                    values.Add(Host.Object("density", density, "efno", s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0)));
                squareRows.Add(Host.Object("halfWidth", width, "values", values));
            }
            Host.Write("square-sweep.json", squareRows);
            var settings = aperture.CreateApertureTypeSettings(SurfaceApertureTypes.RectangularObscuration);
            settings._S_RectangularObscuration.XHalfWidth = .004;
            settings._S_RectangularObscuration.YHalfWidth = 2;
            if (!aperture.ChangeApertureTypeSettings(settings)) throw new Exception("Aperture failed");
            var rows = new List<object>();
            for (int index = -100; index <= 100; index++)
            {
                var active = settings._S_RectangularObscuration;
                active.ApertureXDecenter = index / 100.0;
                if (!aperture.ChangeApertureTypeSettings(settings)) throw new Exception("Aperture shift failed");
                s.UpdateStatus();
                var values = new List<object>();
                foreach (int density in new[] { 5, 10 })
                    values.Add(Host.Object("density", density, "efno", s.MFE.GetOperandValue(MeritOperandType.EFNO, density, 1, 1, 0, 0, 0, 0, 0)));
                rows.Add(Host.Object("x", active.ApertureXDecenter, "halfWidth", active.XHalfWidth, "values", values));
                if (index % 20 == 0) Console.WriteLine("strip " + index);
            }
            Host.Write("strip-sweep.json", rows);
            if (!s.LoadFile(input, false)) throw new Exception("Final reset failed");
            Host.Write("complete.json", Host.Object("complete", true, "input", input));
            Console.WriteLine("Capture complete");
            return 0;
        }
        catch (Exception e) { Host.Write("error.json", Host.Object("error", e.ToString())); Console.Error.WriteLine(e); return 1; }
        finally { if (app != null) app.CloseApplication(); }
    }
}
