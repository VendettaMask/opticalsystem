param([string]$OutputName)
$ErrorActionPreference = 'Stop'
$taskRun = $PSScriptRoot
$repo = (Resolve-Path (Join-Path $taskRun '../../..')).Path
$apiDirectory = 'D:\Program Files\ANSYS Inc\v261\Zemax OpticStudio'
$exe = Join-Path $taskRun 'NativeIlluminationProbe.exe'
$compileArgs = @('/nologo','/target:exe','/platform:x64','/main:NativeIlluminationProbe',('/out:' + $exe),'/r:System.Web.Extensions.dll')
foreach ($name in @('ZOSAPI.dll','ZOSAPI_Interfaces.dll','ZOSAPI_NetHelper.dll')) { $compileArgs += '/r:' + (Join-Path $apiDirectory $name) }
$compileArgs += @(Get-ChildItem (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/ZemaxHost') -Filter '*.cs' | ForEach-Object FullName)
$compileArgs += (Join-Path $taskRun 'NativeIlluminationProbe.cs')
& (Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe') @compileArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$env:PATH = $apiDirectory + ';' + $env:PATH
& $exe $apiDirectory (Join-Path $repo 'artifacts/validation/fcgt-efno-20261014/controls/slow-ideal-lens.ZMX') (Join-Path $taskRun $OutputName) 2>&1 | Tee-Object -FilePath (Join-Path $taskRun ($OutputName+'.log'))
exit $LASTEXITCODE
