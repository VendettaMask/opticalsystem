import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
RUN = pathlib.Path(__file__).resolve().parent
DESTINATION = ROOT / 'validation/repairs/2026-10-16/native-diffraction-adapter-evidence.zip'
LEDGER = ROOT / 'docs/validation/ZEMAX_NATIVE_DIFFRACTION_ADAPTER_REPAIR_2026-10-16.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
tests = {}
test_names = []
for configuration in ('debug', 'release'):
    path = RUN / f'test-results/related-{configuration}-accepted.trx'
    tree = ET.parse(path)
    counts = {k: int(v) for k, v in tree.find('t:ResultSummary/t:Counters', ns).attrib.items()}
    assert counts['total'] == counts['passed'] == 115 and counts['failed'] == 0
    names = sorted(r.attrib['testName'] for r in tree.findall('t:Results/t:UnitTestResult', ns))
    test_names.append(names)
    tests[configuration] = {'Total': counts['total'], 'Passed': counts['passed'], 'Failed': 0,
                            'Skipped': counts['notExecuted'], 'TrxSha256': sha(path)}
assert test_names[0] == test_names[1]
new_methods = ('SymmetricDiffractionKernelDoesNotTranslateAnImpulse',
               'DiffractionKernelUsesDetectorRowsAndThePhysicalWindow',
               'DiffractionWorkBudgetsIncludeTheAdditionalPhysicalEdge',
               'MultispectralDiffractionWorkIncludesThePhysicalWindowForEveryFieldAndWave')
assert sum(any(name in test for name in new_methods) for test in test_names[0]) == 13

def controls(configuration):
    rows = [json.loads(s) for s in (RUN / f'original-controls-current-{configuration}.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    assert all('Error' not in row for row in rows)
    result = {row['Name']: row['Result'] for row in rows if 'Name' in row}
    assert sum(map(len, result.values())) == 10
    assert all(x['Modes'] == ['Diffraction'] and x['GeometricFallbackCount'] == 0 for group in result.values() for x in group)
    return result

original = controls('release')
assert original == controls('debug')
for row in original['diffraction-even-anchor']:
    assert max(abs(row['ConvolvedMoment'][axis] - 16) for axis in ('X', 'Y')) < 1e-10
offset_error = max(abs(r['ExpectedDownwardRasterOffsetPixels'] - r['ActualDownwardRasterOffsetPixels'])
                   for r in original['diffraction-y-orientation'])
assert offset_error < 1e-10

cases = read(ROOT / 'validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json')['Cases']
case_records = []
native_count = 0
for case in cases:
    assert sha(ROOT / case['Source']) == case['SourceSha256']
    folder = RUN / 'native-current-final' / case['Name']
    environment = read(folder / 'environment.json')
    assert environment['major'] == 26 and environment['minor'] == 1 and environment['validLicense']
    assert read(folder / 'capture-complete.json')['complete']
    current = read(folder / 'operands.json')
    previous = read(ROOT / case['Capture'] / 'operands.json')
    assert current == previous
    native_count += len(current)
    case_records.append(dict(case, NativeRows=len(current), MaxNativeChange=0,
                             Environment=environment, ArchiveFolder='native-current-final/' + case['Name']))
assert native_count == 256
comparison = read(RUN / 'current-illumination-accepted.json')
assert sum(len(case['Comparisons']) for case in comparison['Cases']) == 256
assert all(row['Actual'] is not None for case in comparison['Cases'] for row in case['Comparisons'])
assert all(s['Status'] == 'Difference' for case in comparison['Cases'] for s in case['Summary'])

source_paths = ['src/OpticalSystemDesign.Core/Analysis/AnalysisResourceLimits.cs',
                'src/OpticalSystemDesign.Core/Analysis/ImageSimulationEngine.cs',
                'tests/OpticalSystemDesign.Tests/ImageCoordinateReferenceRepairTests.cs',
                'tests/OpticalSystemDesign.Tests/ImageSimulationRepairTests.cs',
                'tools/diagnostics/Accuracy20261014/NativeAccuracyCapture.cs']
source_hashes = {name: sha(ROOT / name) for name in source_paths}
assert sha(RUN / 'native-current-final/host-source/NativeAccuracyCapture.cs') == source_hashes[source_paths[-1]]
binary_hashes = {}
builds = {}
for configuration in ('Debug', 'Release'):
    name = configuration.lower()
    log = (RUN / f'build-{name}-accepted.log').read_text(encoding='utf-8-sig')
    assert '0 个警告' in log and '0 个错误' in log and log.count(' -> ') == 19
    builds[configuration] = {'Projects': 19, 'Warnings': 0, 'Errors': 0, 'LogSha256': sha(RUN / f'build-{name}-accepted.log')}
    core = ROOT / f'src/OpticalSystemDesign.Core/bin/{configuration}/net10.0/OpticalSystemDesign.Core.dll'
    app = ROOT / f'src/OpticalSystemDesign.App/bin/{configuration}/net10.0/OpticalSystemDesign.Core.dll'
    assert sha(core) == sha(app)
    binary_hashes[configuration] = sha(core)
assert binary_hashes['Release'] == sha(ROOT / 'tools/diagnostics/Accuracy20261014/bin/Release/net10.0/OpticalSystemDesign.Core.dll')

entries = {}
def add(path, name):
    assert path.suffix.lower() not in ('.dll', '.exe', '.pdb')
    data = path.read_bytes()
    if name in entries:
        assert entries[name] == data
    entries[name] = data

for folder_name in ('native-current-final', 'grid-probe-v5', 'test-results'):
    for path in (RUN / folder_name).rglob('*'):
        if path.is_file():
            add(path, path.relative_to(RUN).as_posix())
for path in RUN.iterdir():
    if path.is_file() and path.suffix.lower() in ('.log', '.json', '.jsonl', '.cs', '.csproj', '.ps1', '.py', '.config', '.txt'):
        add(path, path.name)
for case in cases:
    add(ROOT / case['Source'], 'input-sources/' + case['Name'] + '.zmx')
for name in ('ideal-lens.ZMX', 'slow-ideal-lens.ZMX', 'cone.ZMX'):
    add(ROOT / 'artifacts/validation/fcgt-efno-20261014/controls' / name, 'diagnostic-inputs/' + name)
for name in ('Program.cs', 'IssueAudit.csproj'):
    add(RUN / 'original-controls' / name, 'original-controls/' + name)
for name in source_paths:
    add(ROOT / name, 'source-at-verification/' + name)

attempts = []
for path in sorted((RUN / 'test-results').glob('*.trx')):
    if '-accepted' in path.name:
        continue
    tree = ET.parse(path)
    c = tree.find('t:ResultSummary/t:Counters', ns).attrib
    attempts.append({'Name': path.name, 'Total': int(c['total']), 'Passed': int(c['passed']), 'Failed': int(c['failed']),
                     'Accepted': False, 'Sha256': sha(path)})

documentation = {'Status': 'Pending'}
if (RUN / 'documentation-exit-code.txt').exists():
    assert (RUN / 'documentation-exit-code.txt').read_text().strip() == '0'
    documentation = {'Status': 'Passed', 'Strict': True, 'ArchiveEntry': 'documentation-accepted.json',
                     'Sha256': sha(RUN / 'documentation-accepted.json')}

file_manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(entries.items())}
entries['archive-entry-sha256.json'] = json.dumps(file_manifest, indent=2).encode()
DESTINATION.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DESTINATION, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(DESTINATION) as archive:
    assert len(archive.namelist()) == len(entries)
    for name, data in entries.items():
        assert hashlib.sha256(archive.read(name)).digest() == hashlib.sha256(data).digest()

ledger = {
    'Date': '2026-10-16',
    'Status': 'Two diffraction-image adapter defects repaired; native environment restored; EFNO/RELI differences remain open',
    'SourceBaseCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'UserScope': {'LocalZemaxInstalledAndApiVerified': True, 'IndependentCookeTessarInvestigations': 'Excluded',
                  'OptionalFullSuite': 'Not run; user preference retained'},
    'NativeControls': {'Cases': case_records, 'Rows': native_count, 'MaxChangeFromFrozenValues': 0,
                       'AllFinalCaptureHostsExitedSuccessfully': True,
                       'CaptureSourceSnapshotMatchesCurrentTool': True, 'OriginalLensSaved': False},
    'CurrentCoreComparison': {'ArchiveEntry': 'current-illumination-accepted.json',
                              'Sha256': sha(RUN / 'current-illumination-accepted.json'),
                              'Cases': [{'Name': case['Name'], 'Summary': case['Summary']} for case in comparison['Cases']],
                              'Status': 'Difference', 'NewAcceptanceThreshold': False},
    'OriginalTenControls': {'DebugReleaseIdentical': True, 'ControlsPerConfiguration': 10,
                            'OriginalDiagnosticProgramSha256': sha(RUN / 'original-controls/Program.cs'),
                            'AllDiffractionWithoutGeometricFallback': True,
                            'MaxPhysicalYToRasterOffsetErrorPixels': offset_error,
                            'ReleaseResults': original},
    'Verification': {'Related': tests, 'AddedTests': 13, 'SelectedTestNamesMatch': True, 'DefaultBuilds': builds,
                     'ChangedCSharpFormatVerify': 'Passed; five files; no changes', 'Documentation': documentation,
                     'FullSuite': False, 'InstallerRebuilt': False, 'FcgsFcgtRerun': False},
    'DevelopmentAttemptsNotAccepted': attempts,
    'DevelopmentCorrections': ['Initial sandbox native IPC failure preserved; final native hosts use approved local access',
                              'Initial default test startup stopped before results; final builds use two MSBuild nodes',
                              'Intermediate even-kernel center-offset approach replaced by physical-window sampling to retain footprint',
                              'Impulse assertions corrected for finite-window tails and multi-lobed finite-sampling PSFs; final uses original diagnostic settings and centroid contract',
                              'Test-config compiler error fixed; no compiler failure counted as test success'],
    'SourceSha256': source_hashes, 'DefaultCoreBinarySha256': binary_hashes, 'DefaultAppCoreCopiesMatch': True,
    'Evidence': {'Path': DESTINATION.relative_to(ROOT).as_posix(), 'Entries': len(entries), 'Bytes': DESTINATION.stat().st_size,
                 'Sha256': sha(DESTINATION), 'EveryEntryReadbackSha256MatchesOriginal': True,
                 'ProprietaryApiBinariesIncluded': False},
    'ProductHuygensPhysicsOrGenericConvolutionChanged': False,
    'FrozenReferenceValuesOrTolerancesChanged': False,
    'StillOpen': ['EFNO/RELI finite-grid, image-point reference and aberration-removal differences',
                  'Broader coherent electric-field and native image certification',
                  'Previously documented standard-matrix unsupported glass, PARAXIAL, reflection and adapter boundaries']
}
LEDGER.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({'Evidence': ledger['Evidence'], 'Documentation': documentation, 'Tests': tests}, ensure_ascii=False))
