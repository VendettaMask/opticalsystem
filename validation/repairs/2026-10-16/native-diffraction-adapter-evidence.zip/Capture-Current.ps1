param([string]$OutputName = 'native-current')
$ErrorActionPreference = 'Stop'
$taskRun = $PSScriptRoot
$repo = (Resolve-Path (Join-Path $taskRun '../../..')).Path
$apiDirectory = 'D:\Program Files\ANSYS Inc\v261\Zemax OpticStudio'
$outputRoot = Join-Path $taskRun $OutputName
if (Test-Path -LiteralPath $outputRoot) { throw 'Use a fresh native output directory.' }
$hostSource = Join-Path $outputRoot 'host-source'
New-Item -ItemType Directory -Path $hostSource | Out-Null
Copy-Item -LiteralPath (Join-Path $repo 'tools/diagnostics/Accuracy20261014/NativeAccuracyCapture.cs') -Destination $hostSource
Get-ChildItem (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/ZemaxHost') -Filter '*.cs' | Copy-Item -Destination $hostSource
$exe = Join-Path $taskRun 'NativeAccuracyCaptureFinal.exe'
$compileArgs = @('/nologo','/target:exe','/platform:x64','/main:NativeAccuracyCapture',('/out:' + $exe),'/r:System.Web.Extensions.dll')
foreach ($name in @('ZOSAPI.dll','ZOSAPI_Interfaces.dll','ZOSAPI_NetHelper.dll')) { $compileArgs += '/r:' + (Join-Path $apiDirectory $name) }
$compileArgs += @(Get-ChildItem $hostSource -Filter '*.cs' | ForEach-Object FullName)
& (Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe') @compileArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Copy-Item -LiteralPath (Join-Path $taskRun 'NativeAccuracyCapture.exe.config') -Destination ($exe+'.config')
$env:PATH = $apiDirectory + ';' + $env:PATH
$manifest = Get-Content -LiteralPath (Join-Path $repo 'validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json') -Raw | ConvertFrom-Json
foreach ($case in $manifest.Cases) {
    $inputPath = Join-Path $repo $case.Source
    if ((Get-FileHash -LiteralPath $inputPath).Hash -ne $case.SourceSha256) { throw 'Source identity mismatch' }
    $request = Join-Path $taskRun ($OutputName+'-'+$case.Name+'-request.json')
    @{ zosApiPath=$apiDirectory; input=$inputPath; illuminationOnly=$true } | ConvertTo-Json | Set-Content -LiteralPath $request -Encoding utf8
    & $exe $request (Join-Path $outputRoot $case.Name) 2>&1 | Tee-Object -FilePath (Join-Path $taskRun ($OutputName+'-'+$case.Name+'.log'))
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    Write-Output ('Completed '+$case.Name)
}
