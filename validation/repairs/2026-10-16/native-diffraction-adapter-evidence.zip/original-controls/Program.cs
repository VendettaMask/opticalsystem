using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Interactions;

var records = new List<string>();
var evidenceDirectory = Path.GetFullPath(".tmp/issue-audit-20261016e/outputs-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(evidenceDirectory);
Run("diffraction-even-anchor", () =>
{
    var results = new List<object>();
    foreach (var size in new[] { 7, 8, 9, 15, 16, 17 })
    {
        var optic = ThinLens();
        var config = Config(size: size, pitch: .01, rays: 16, fieldHeight: 1);
        var basis = ImageSimulationEngine.GenerateBasis(optic, optic.Wavelengths[0], config);
        var impulse = new double[32, 32];
        impulse[16, 16] = 1;
        var convolved = ImageSimulationEngine.SpatiallyVariableConvolution(impulse, basis.EigenPsfs,
            ImageSimulationEngine.ResizeCoefficientMaps(basis.CoefficientGrid, 32, 32), basis.MeanPsf);
        var image = ImageSimulationEngine.Simulate(optic, new RgbImage(ToRgb(impulse)), config);
        var unblurred = ImageSimulationEngine.Simulate(optic, new RgbImage(ToRgb(impulse)),
            Config(size, .01, 16, mode: "None", fieldHeight: 1));
        results.Add(new { Size = size, Modes = basis.EffectiveModes, basis.GeometricFallbackCount,
            KernelPeak = Peak(basis.MeanPsf), ConvolutionAnchor = (size - 1) / 2,
            ConvolvedPeak = Peak(convolved), SimulatedPeak = Peak(Channel(image.Simulated.Values)),
            KernelMoment = Moment(basis.MeanPsf), ConvolvedMoment = Moment(convolved),
            SimulatedMoment = Moment(Channel(image.Simulated.Values)),
            UnblurredControlMoment = Moment(Channel(unblurred.Simulated.Values)) });
    }
    return results;
});
Run("diffraction-y-orientation", () =>
{
    var results = new List<object>();
    foreach (var field in new[] { -.8, -.5, .5, .8 })
    {
        const int size = 33;
        const double pitch = .0005;
        var optic = Primary();
        var wave = new Wavelength { Nanometers = 550, IsPrimary = true };
        var basis = ImageSimulationEngine.GenerateBasis(optic, wave, Config(size, pitch, 32, field));
        var raw = DiffractionEngine.ComputeHuygensPsf(optic, (0, field), wave, 32, size, pitch,
            aimAtStop: optic.RayAimingEnabled).Values;
        Normalize(raw);
        var geometric = ImageSimulationEngine.GenerateBasis(optic, wave,
            Config(size, pitch, 32, field, mode: "Geometric"));
        var coordinates = (Vector3D[,])typeof(DiffractionEngine).GetMethod("CreateHuygensImageCoordinates",
            BindingFlags.Static | BindingFlags.NonPublic)!.Invoke(null, [optic, (0d, field), wave, size, pitch, optic.RayAimingEnabled])!;
        var frame = DiffractionEngine.CreateHuygensImageFrame(optic, (0, field), wave, optic.RayAimingEnabled);
        var detector = optic.SurfaceGroup.Items[^1].CoordinateSystem;
        var localChief = detector.ToLocalPoint(frame.Center);
        var physicalY = 0d;
        for (var y = 0; y < size; y++)
            for (var x = 0; x < size; x++) physicalY += raw[y, x] * (detector.ToLocalPoint(coordinates[y, x]).Y - localChief.Y);
        var impulse = new double[65, 65];
        impulse[32, 32] = 1;
        var convolved = ImageSimulationEngine.SpatiallyVariableConvolution(impulse, basis.EigenPsfs,
            ImageSimulationEngine.ResizeCoefficientMaps(basis.CoefficientGrid, 65, 65), basis.MeanPsf);
        var reflected = new double[size, size];
        for (var y = 0; y < size; y++)
            for (var x = 0; x < size; x++) reflected[y, x] = raw[size - 1 - y, x];
        results.Add(new { Field = field, Modes = basis.EffectiveModes, basis.GeometricFallbackCount,
            RawHuygensPhysicalCentroidOffsetYmm = physicalY,
            ExpectedDownwardRasterOffsetPixels = -physicalY / pitch,
            ActualDownwardRasterOffsetPixels = Moment(convolved).Y - 32,
            GeometricDownwardRasterOffsetPixels = Moment(geometric.MeanPsf).Y - 16,
            BasisVersusUnadaptedRawMaximumDifference = Difference(raw, basis.MeanPsf),
            BasisVersusCorrectYReflectionMaximumDifference = Difference(reflected, basis.MeanPsf) });
    }
    return results;
});
var path = Path.Combine(evidenceDirectory, "results.jsonl");
File.WriteAllLines(path, records);
Console.WriteLine(JsonSerializer.Serialize(new { Evidence = path, CoreAssembly = typeof(Optic).Assembly.Location }));

void Run(string name, Func<object> action)
{
    var watch = System.Diagnostics.Stopwatch.StartNew();
    string record;
    try { record = JsonSerializer.Serialize(new { Name = name, Result = action(), Milliseconds = watch.ElapsedMilliseconds }); }
    catch (Exception exception) { record = JsonSerializer.Serialize(new { Name = name, Error = exception.ToString(), Milliseconds = watch.ElapsedMilliseconds }); }
    records.Add(record);
    Console.WriteLine(record);
}
static Optic Primary() => OpticalFormatCatalog.Import(File.ReadAllText(
    "artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX"), ".zmx");
static Optic ThinLens()
{
    var optic = new Optic { FieldDefinition = FieldDefinitionKind.Angle };
    optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint { Y = 1 });
    optic.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = double.PositiveInfinity },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = 10, InteractionModel = new ThinLensInteractionModel(10) },
        new OpticalSurface()
    ]);
    return optic;
}
static ImageSimulationConfig Config(int size = 16, double pitch = .0005, int rays = 16, double field = 0,
    string mode = "Diffraction", double fieldHeight = 1e-8) => new()
{
    ImageWidth = 32, ImageHeight = 32, Padding = 0, WavelengthsMicrometers = [.55],
    PsfGridRows = 1, PsfGridColumns = 1, PsfSize = size, NumRays = rays, Components = 1,
    PixelSizeMillimeters = pitch, FieldHeight = fieldHeight, FieldCenterY = field,
    Reference = "chief", AberrationMode = mode, UseRelativeIllumination = false,
    DistortionGridSize = 9, DistortionPolynomialDegree = 1
};
static RasterPeak Peak(double[,] values)
{
    var peak = new RasterPeak(0, 0, double.NegativeInfinity);
    for (var y = 0; y < values.GetLength(0); y++)
        for (var x = 0; x < values.GetLength(1); x++)
            if (values[y, x] > peak.Value) peak = new(x, y, values[y, x]);
    return peak;
}
static RasterMoment Moment(double[,] values)
{
    var sum = values.Cast<double>().Sum();
    double mx = 0, my = 0;
    for (var y = 0; y < values.GetLength(0); y++)
        for (var x = 0; x < values.GetLength(1); x++) { mx += x * values[y, x] / sum; my += y * values[y, x] / sum; }
    return new(mx, my);
}
static double[,,] ToRgb(double[,] source)
{
    var result = new double[1, source.GetLength(0), source.GetLength(1)];
    for (var y = 0; y < source.GetLength(0); y++)
        for (var x = 0; x < source.GetLength(1); x++) result[0, y, x] = source[y, x];
    return result;
}
static double[,] Channel(double[,,] source)
{
    var result = new double[source.GetLength(1), source.GetLength(2)];
    for (var y = 0; y < result.GetLength(0); y++)
        for (var x = 0; x < result.GetLength(1); x++) result[y, x] = source[0, y, x];
    return result;
}
static double Difference(Array a, Array b) => a.Cast<double>().Zip(b.Cast<double>(), (x, y) => Math.Abs(x - y)).Max();
static void Normalize(double[,] values)
{
    var sum = values.Cast<double>().Sum();
    for (var y = 0; y < values.GetLength(0); y++)
        for (var x = 0; x < values.GetLength(1); x++) values[y, x] /= sum;
}

readonly record struct RasterPeak(int X, int Y, double Value);
readonly record struct RasterMoment(double X, double Y);
