using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Apertures;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Coatings;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Materials;
using OpticalSystemDesign.Core.Services;

var wave = new Wavelength { Nanometers = 550, IsPrimary = true };
Run("rigid-translation-distortion", () =>
{
    var results = new List<object>();
    foreach (var degree in new[] { 1, 3, 5, 9 })
    {
        var optic = Cone();
        var reference = ImageSimulationEngine.Simulate(optic, Source(), Config(degree: degree));
        foreach (var shift in new[] { .1, 1, 10, 100, 1000 })
        {
            var moved = Cone();
            foreach (var surface in moved.SurfaceGroup.Items)
                surface.CoordinateSystem = surface.CoordinateSystem with
                { Origin = surface.CoordinateSystem.Origin + new Vector3D(shift, shift, 0) };
            var rayA = optic.TraceGenericFinalSample(.2, .3, .25, .1, .55)!;
            var rayB = moved.TraceGenericFinalSample(.2, .3, .25, .1, .55)!;
            var actual = ImageSimulationEngine.Simulate(moved, Source(), Config(degree: degree));
            results.Add(new { Degree = degree, ShiftMm = shift,
                MaxImageDifference = Difference(reference.Simulated.Values, actual.Simulated.Values),
                MovedMean = actual.Simulated.Values.Cast<double>().Average(),
                RayPositionTranslationError = (rayB.Position - rayA.Position - new Vector3D(shift, shift, 0)).Length,
                RayDirectionError = (rayB.Direction - rayA.Direction).Length });
        }
    }
    return results;
});

Run("empty-geometric-pupil", () =>
{
    var optic = Cone();
    optic.SurfaceGroup.Items[2].PhysicalAperture = new OffsetRadialAperture(.01, offsetX: 100);
    var ray = optic.TraceGenericFinalSample(0, 0, 0, 0, .55);
    var basis = ImageSimulationEngine.GenerateBasis(optic, wave, Config(mode: "Geometric"));
    object simulation;
    try
    {
        var result = ImageSimulationEngine.Simulate(optic, Source(), Config(mode: "Geometric"));
        simulation = new { Outcome = "Success", Mean = result.Simulated.Values.Cast<double>().Average(), result.MaximumValue };
    }
    catch (Exception exception) { simulation = new { Error = exception.GetType().Name, exception.Message }; }
    return new { TracedImage = ray, PsfSum = basis.MeanPsf.Cast<double>().Sum(),
        PsfPeak = basis.MeanPsf.Cast<double>().Max(), basis.EffectiveModes, basis.GeometricFallbackCount, Simulation = simulation };
});

Run("psf-window-no-energy", () =>
{
    var optic = Cone();
    var basis = ImageSimulationEngine.GenerateBasis(optic, wave, new ImageSimulationConfig
    {
        PsfGridRows = 1, PsfGridColumns = 1, PsfSize = 8, NumRays = 8, Components = 1,
        FieldHeight = 1e-8, PixelSizeMillimeters = 1e-9, AberrationMode = "Geometric"
    });
    var axis = Enumerable.Range(0, 8).Select(i => -1 + 2d * i / 7).ToArray();
    var samples = axis.SelectMany(y => axis.Select(x => new OpticalSystemDesign.Core.Raytrace.PupilSample(x, y, 1)))
        .Where(p => p.X * p.X + p.Y * p.Y <= 1).ToArray();
    var rays = optic.SequentialRayTracer.TraceFinalSamples(optic.SequentialRayTracer.RayGenerator
        .GenerateNormalizedPupilSamples(0, 0, .55, samples)).Where(p => p is { Vignetted: false, Intensity: > 0 }).ToArray();
    var cropCount = rays.Count(p => Math.Abs(p!.Position.X) <= .035 && Math.Abs(p.Position.Y) <= .035);
    var geometric = ImageSimulationEngine.Simulate(optic, Source(), Config(mode: "Geometric"));
    var noAberration = ImageSimulationEngine.Simulate(optic, Source(), Config(mode: "None"));
    return new { PsfSum = basis.MeanPsf.Cast<double>().Sum(), PsfPeak = basis.MeanPsf.Cast<double>().Max(),
        basis.EffectiveModes, basis.GeometricFallbackCount, ValidSampledRays = rays.Length,
        RaysInDefaultPsfWindow = cropCount,
        GeometricImageVsNoAberrationImage = Difference(geometric.Simulated.Values, noAberration.Simulated.Values),
        SuccessfulGeometricImageMode = geometric.EffectiveAberrationMode };
});

Run("partial-coherence-endpoint", () =>
{
    var optic = Cone();
    var incoherent = new PartiallyCoherentImageAnalysis(optic, imageSize: 16, pupilSampling: 4,
        coherence: 0, fieldHeight: 1, guardBand: 0, relativeIllumination: false).GenerateData();
    var coherent = new PartiallyCoherentImageAnalysis(optic, imageSize: 16, pupilSampling: 4,
        coherence: 1, fieldHeight: 1, guardBand: 0, relativeIllumination: false).GenerateData();
    static double DifferencePanes(AnalysisData data) => data.PlotPanes![0].Series[0].Points
        .Zip(data.PlotPanes[1].Series[0].Points, (a, b) => Math.Abs(a.Red!.Value - b.Red!.Value)).Max();
    return new { IncoherentVsSource = DifferencePanes(incoherent), CoherentVsSource = DifferencePanes(coherent),
        CoherentOutcome = coherent.Outcome, CoherentPipeline = coherent.Values["Pipeline"],
        IncoherentChangeMetric = incoherent.Values["MeanAbsoluteChange"], CoherentChangeMetric = coherent.Values["MeanAbsoluteChange"] };
});

Run("irradiance-detector-coating", () =>
{
    var optic = Cone();
    optic.SurfaceGroup.Items[^1].PhysicalAperture = new CircularAperture(10);
    var bare = new IncoherentIrradianceAnalysis(optic, 32, 9, 9, distribution: "sobol", normalize: false).GenerateData();
    var incidentBefore = IlluminationMetrics.Evaluate(optic, (0, 0), .55, 5).ProjectedCosineArea;
    optic.SurfaceGroup.Items[^1].CoatingModel = new SimpleCoatingModel(.25);
    var coated = new IncoherentIrradianceAnalysis(optic, 32, 9, 9, distribution: "sobol", normalize: false).GenerateData();
    var incidentAfter = IlluminationMetrics.Evaluate(optic, (0, 0), .55, 5).ProjectedCosineArea;
    var a = bare.PlotPanes![0].Series[0];
    var b = coated.PlotPanes![0].Series[0];
    return new { BareSum = a.Points.Sum(p => p.Value!.Value), CoatedSum = b.Points.Sum(p => p.Value!.Value),
        BarePeak = bare.Values["PeakIrradiance"], CoatedPeak = coated.Values["PeakIrradiance"],
        IncidentIntegralBefore = incidentBefore, IncidentIntegralAfter = incidentAfter, ValueUnit = b.ValueUnit.ToString() };
});

Run("radiant-intensity-solid-angle", () =>
{
    var optic = Cone();
    var result = new RadiantIntensityAnalysis(optic, binsX: 1, binsY: 1,
        angleXMinimum: -45, angleXMaximum: 45, angleYMinimum: -45, angleYMaximum: 45,
        numRays: 32, distribution: "sobol", normalize: false).GenerateData();
    var value = result.PlotPanes![0].Series[0].Points.Single().Value!.Value;
    var bundle = optic.SequentialRayTracer.RayGenerator.GenerateNormalizedPupilSamples(0, 0, .55,
        OpticalSystemDesign.Core.Raytrace.ApertureSampler.Generate(32, OpticalSystemDesign.Core.Raytrace.PupilSampling.Sobol));
    var power = optic.SequentialRayTracer.TraceFinalSamples(bundle).Where(p => p is { Vignetted: false }).Sum(p => p!.Intensity);
    // Solid angle of the square cone bounded by x/z,y/z in [-1,1]: four spherical triangles.
    var exactSolidAngle = 4 * Math.Atan(1 / Math.Sqrt(3));
    return new { ReportedWattsPerSteradian = value, CapturedRayPower = power,
        ExactPixelSteradians = exactSolidAngle, ReintegratedReportedPower = value * exactSolidAngle,
        RelativeEnergyError = value * exactSolidAngle / power - 1,
        ValueUnit = result.PlotPanes[0].Series[0].ValueUnit.ToString() };
});

Run("radiant-intensity-default-range-coarse-bin", () =>
{
    var optic = Cone();
    var result = new RadiantIntensityAnalysis(optic, binsX: 1, binsY: 1,
        numRays: 32, distribution: "sobol", normalize: false).GenerateData();
    var value = result.PlotPanes![0].Series[0].Points.Single().Value!.Value;
    var tangent = Math.Tan(Math.PI / 12);
    var exactSolidAngle = 4 * Math.Atan(tangent * tangent / Math.Sqrt(1 + 2 * tangent * tangent));
    return new { ReportedWattsPerSteradian = value, CapturedRays = result.Values["ValidRayCount"],
        ExactPixelSteradians = exactSolidAngle, ReintegratedReportedPower = value * exactSolidAngle,
        RelativeEnergyError = value * exactSolidAngle / Convert.ToDouble(result.Values["ValidRayCount"]) - 1 };
});

Run("displayed-image-statistics", () =>
{
    var optic = Cone();
    var result = ImageSimulationEngine.Simulate(optic, Source(), Config(imageFlip: "Horizontal", outputWidth: 1, outputHeight: 1));
    var reported = result.MeanAbsoluteChange;
    var actual = result.Source.Values.Cast<double>().Zip(result.Simulated.Values.Cast<double>(), (a, b) => Math.Abs(a - b)).Average();
    return new { ReportedMeanAbsoluteChange = reported, DisplayedMeanAbsoluteChange = actual,
        ReportedMaximum = result.MaximumValue, DisplayedMaximum = result.Simulated.Values.Cast<double>().Max() };
});

Run("flip-only-statistics", () =>
{
    var result = ImageSimulationEngine.Simulate(Cone(), Source(), Config(imageFlip: "Horizontal"));
    return new { ReportedMeanAbsoluteChange = result.MeanAbsoluteChange,
        DisplayedMeanAbsoluteChange = result.Source.Values.Cast<double>().Zip(result.Simulated.Values.Cast<double>(), (a, b) => Math.Abs(a - b)).Average() };
});

static Optic Cone()
{
    var optic = new Optic { FieldDefinition = FieldDefinitionKind.ObjectHeight };
    optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint { Y = 2 });
    optic.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = 10 },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = 2 },
        new OpticalSurface { Thickness = 8 },
        new OpticalSurface()
    ]);
    return optic;
}

static RgbImage Source()
{
    var pixels = new double[1, 16, 16];
    for (var y = 0; y < 16; y++)
        for (var x = 0; x < 16; x++) pixels[0, y, x] = .1 + .5 * x / 15 + .3 * y / 15;
    return new(pixels);
}

static ImageSimulationConfig Config(string mode = "None", int degree = 1, string imageFlip = "None",
    int outputWidth = 0, int outputHeight = 0) => new()
{
    ImageWidth = 16, ImageHeight = 16, Padding = 0, WavelengthsMicrometers = [.55],
    PsfGridRows = 1, PsfGridColumns = 1, PsfSize = 8, NumRays = 8, Components = 1,
    PixelSizeMillimeters = .01, FieldHeight = 1, AberrationMode = mode,
    UseRelativeIllumination = false, DistortionGridSize = 9, DistortionPolynomialDegree = degree,
    ImageFlip = imageFlip, OutputWidth = outputWidth, OutputHeight = outputHeight
};

static double Difference(Array a, Array b) => a.Cast<double>().Zip(b.Cast<double>(), (x, y) => Math.Abs(x - y)).Max();
static void Run(string name, Func<object> action)
{
    var watch = System.Diagnostics.Stopwatch.StartNew();
    try { Console.WriteLine(JsonSerializer.Serialize(new { Name = name, Result = action(), Milliseconds = watch.ElapsedMilliseconds })); }
    catch (Exception e) { Console.WriteLine(JsonSerializer.Serialize(new { Name = name, Error = e.ToString(), Milliseconds = watch.ElapsedMilliseconds })); }
}
