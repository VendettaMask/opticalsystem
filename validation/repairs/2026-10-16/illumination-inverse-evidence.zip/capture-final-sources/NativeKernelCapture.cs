using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using ZOSAPI;
using ZOSAPI.Editors.MFE;
using ZOSAPI.Tools.RayTrace;
internal static class NativeKernelCapture
{
    [STAThread] public static int Main(string[] args)
    {
        string api=args[0];Host.Output=args[2];if(Directory.Exists(Host.Output)&&Directory.EnumerateFileSystemEntries(Host.Output).Any())return 2;
        Directory.CreateDirectory(Host.Output);
        AppDomain.CurrentDomain.AssemblyResolve+=delegate(object sender,ResolveEventArgs e){string path=Path.Combine(api,new AssemblyName(e.Name).Name+".dll");return File.Exists(path)?Assembly.LoadFrom(path):null;};
        return Run(api,args[1]);
    }
    private static int Run(string api,string requestPath)
    {
        IZOSAPI_Application app=null;
        var request=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(requestPath));
        string input=Convert.ToString(request["input"]);
        try
        {
            if(!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api))throw new Exception("Initialize failed");
            app=new ZOSAPI_Connection().CreateNewApplication();Host.Write("environment.json",Host.Object("version",app.OpticStudioVersion,"validLicense",app.IsValidLicenseForAPI,"license",app.LicenseStatus.ToString()));
            if(!app.IsValidLicenseForAPI||app.ZOSMajorVersion!=26||app.ZOSMinorVersion!=1)throw new Exception("Wrong environment");
            var s=app.PrimarySystem;if(!s.LoadFile(input,false))throw new Exception("Load failed");
            int wave=Convert.ToInt32(request["wave"]),field=Convert.ToInt32(request["field"]),d=Convert.ToInt32(request["density"]);
            double hx=Convert.ToDouble(request["hx"]),hy=Convert.ToDouble(request["hy"]);
            double before=s.MFE.GetOperandValue(MeritOperandType.EFNO,d,wave,field,0,0,0,0,0);
            double pupil=s.MFE.GetOperandValue(MeritOperandType.EXPP,0,0,0,0,0,0,0,0);
            var inputs=new List<double[]>();object points;
            if(request.TryGetValue("points",out points))
                foreach(var item in (System.Collections.IEnumerable)points)
                {
                    var p=(Dictionary<string,object>)item;inputs.Add(new[]{Convert.ToDouble(p["x"]),Convert.ToDouble(p["y"])});
                }
            else
            {
                int r=Math.Max(8,d/2)-1;for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(x*x+y*y<=r*r)inputs.Add(new[]{x/(double)r,y/(double)r});
            }
            var tool=s.Tools.OpenBatchRayTrace();
            try
            {
                var data=tool.CreateNormUnpol(inputs.Count,RaysType.Real,s.LDE.NumberOfSurfaces-1);
                foreach(var p in inputs)data.AddRay(wave,hx,hy,p[0],p[1],OPDMode.None);
                tool.RunAndWaitForCompletion();data.StartReadingResults();var rows=new List<object>();
                int number,error,vignette;double x,y,z,l,m,n,nx,ny,nz,opd,intensity;
                while(data.ReadNextResult(out number,out error,out vignette,out x,out y,out z,out l,out m,out n,out nx,out ny,out nz,out opd,out intensity))
                    rows.Add(Host.Object("number",number,"error",error,"vignette",vignette,"px",inputs[number-1][0],"py",inputs[number-1][1],"x",x,"y",y,"z",z,"l",l,"m",m,"n",n,"intensity",intensity));
                Host.Write("rays.json",rows);
            }
            finally{tool.Close();}
            double after=s.MFE.GetOperandValue(MeritOperandType.EFNO,d,wave,field,0,0,0,0,0);
            Host.Write("control.json",Host.Object("efnoBefore",before,"efnoAfter",after,"primaryExitPupil",pupil,"aperture",Host.Properties(s.SystemData.Aperture)));
            Host.Write("request.json",request);Host.Write("complete.json",Host.Object("complete",true));return 0;
        }
        catch(Exception e){Host.Write("error.json",Host.Object("error",e.ToString()));Console.Error.WriteLine(e);return 1;}
        finally{if(app!=null){try{app.PrimarySystem.LoadFile(input,false);}finally{app.CloseApplication();}}}
    }
}
