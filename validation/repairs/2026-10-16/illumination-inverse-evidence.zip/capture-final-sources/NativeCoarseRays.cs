using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using ZOSAPI;
using ZOSAPI.Tools.RayTrace;
internal static class NativeCoarseRays
{
    [STAThread] public static int Main(string[] args)
    {
        string api=args[0];Host.Output=args[2];if(Directory.Exists(Host.Output)&&Directory.EnumerateFileSystemEntries(Host.Output).Any())return 2;
        Directory.CreateDirectory(Host.Output);
        AppDomain.CurrentDomain.AssemblyResolve+=delegate(object sender,ResolveEventArgs e){string path=Path.Combine(api,new AssemblyName(e.Name).Name+".dll");return File.Exists(path)?Assembly.LoadFrom(path):null;};
        return Run(api,args[1]);
    }
    private static int Run(string api,string input)
    {
        IZOSAPI_Application app=null;
        try
        {
            if(!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api))throw new Exception("Initialize failed");
            app=new ZOSAPI_Connection().CreateNewApplication();Host.Write("environment.json",Host.Object("version",app.OpticStudioVersion,"validLicense",app.IsValidLicenseForAPI));
            if(!app.IsValidLicenseForAPI||app.ZOSMajorVersion!=26||app.ZOSMinorVersion!=1)throw new Exception("Wrong environment");
            var s=app.PrimarySystem;if(!s.LoadFile(input,false))throw new Exception("Load failed");
            var all=new List<object>();
            foreach(int r in new[]{7,9,19})
            {
                var inputs=new List<double[]>();for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(x*x+y*y<=r*r)inputs.Add(new[]{x/(double)r,y/(double)r});
                var tool=s.Tools.OpenBatchRayTrace();
                try
                {
                    var data=tool.CreateNormUnpol(inputs.Count,RaysType.Real,s.LDE.NumberOfSurfaces-1);
                    foreach(var p in inputs)data.AddRay(1,0,1,p[0],p[1],OPDMode.None);
                    tool.RunAndWaitForCompletion();data.StartReadingResults();var rows=new List<object>();
                    int number,error,vignette;double x,y,z,l,m,n,nx,ny,nz,opd,intensity;
                    while(data.ReadNextResult(out number,out error,out vignette,out x,out y,out z,out l,out m,out n,out nx,out ny,out nz,out opd,out intensity))
                        rows.Add(Host.Object("number",number,"error",error,"vignette",vignette,"px",inputs[number-1][0],"py",inputs[number-1][1],"x",x,"y",y,"z",z,"l",l,"m",m,"n",n,"intensity",intensity));
                    all.Add(Host.Object("radius",r,"rows",rows));
                }
                finally{tool.Close();}
            }
            Host.Write("rays.json",all);Host.Write("complete.json",Host.Object("complete",true));return 0;
        }
        catch(Exception e){Host.Write("error.json",Host.Object("error",e.ToString()));return 1;}
        finally{if(app!=null){try{app.PrimarySystem.LoadFile(input,false);}finally{app.CloseApplication();}}}
    }
}
