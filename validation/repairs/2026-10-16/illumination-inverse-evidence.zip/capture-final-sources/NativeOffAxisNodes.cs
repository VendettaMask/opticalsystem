using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using ZOSAPI;
using ZOSAPI.Editors.LDE;
using ZOSAPI.Editors.MFE;
internal static class NativeOffAxisNodes
{
    [STAThread] public static int Main(string[] args)
    {
        string api=args[0];Host.Output=args[2];
        if(Directory.Exists(Host.Output)&&Directory.EnumerateFileSystemEntries(Host.Output).Any())return 2;
        Directory.CreateDirectory(Host.Output);
        AppDomain.CurrentDomain.AssemblyResolve+=delegate(object sender,ResolveEventArgs e)
        {
            string path=Path.Combine(api,new AssemblyName(e.Name).Name+".dll");return File.Exists(path)?Assembly.LoadFrom(path):null;
        };
        return Run(api,args[1],args[3]);
    }
    private static int Run(string api,string input,string targetsPath)
    {
        IZOSAPI_Application app=null;
        try
        {
            if(!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api))throw new Exception("Initialize failed");
            app=new ZOSAPI_Connection().CreateNewApplication();
            Host.Write("environment.json",Host.Object("version",app.OpticStudioVersion,"major",app.ZOSMajorVersion,"minor",app.ZOSMinorVersion,"validLicense",app.IsValidLicenseForAPI,"license",app.LicenseStatus.ToString()));
            if(!app.IsValidLicenseForAPI||app.ZOSMajorVersion!=26||app.ZOSMinorVersion!=1)throw new Exception("Wrong environment");
            var s=app.PrimarySystem;if(!s.LoadFile(input,false))throw new Exception("Load failed");
            var baseline=new Dictionary<int,double>();
            foreach(int d in new[]{5,10,20,40})baseline[d]=s.MFE.GetOperandValue(MeritOperandType.EFNO,d,1,2,0,0,0,0,0);
            double distance=s.LDE.GetSurfaceAt(1).Thickness;s.LDE.GetSurfaceAt(1).Thickness=0;
            var mask=s.LDE.InsertNewSurfaceAt(2);mask.Thickness=distance;mask.SemiDiameter=20;s.UpdateStatus();
            foreach(int d in baseline.Keys)if(baseline[d]!=s.MFE.GetOperandValue(MeritOperandType.EFNO,d,1,2,0,0,0,0,0))throw new Exception("Transparent plane changed baseline");
            var targets=new JavaScriptSerializer().Deserialize<List<Dictionary<string,object>>>(File.ReadAllText(targetsPath));
            File.Copy(targetsPath,Path.Combine(Host.Output,"targets.json"));var records=new List<object>();
            foreach(var target in targets)
            {
                int d=Convert.ToInt32(target["density"]),column=Convert.ToInt32(target["column"]),row=Convert.ToInt32(target["row"]);
                double px=Convert.ToDouble(target["pupilX"])*10,py=Convert.ToDouble(target["pupilY"])*10;
                var bounds=new List<object>();double removedValue=0;
                foreach(bool xAxis in new[]{true,false})
                {
                    double predicted=xAxis?px:py,left=predicted-.002,lower=left+.00001,upper=predicted+.002;
                    var aperture=mask.ApertureData.CreateApertureTypeSettings(SurfaceApertureTypes.RectangularObscuration);
                    Func<double,double> at=delegate(double right)
                    {
                        var a=aperture._S_RectangularObscuration;
                        a.XHalfWidth=xAxis?(right-left)/2:.002;a.YHalfWidth=xAxis?.002:(right-left)/2;
                        a.ApertureXDecenter=xAxis?(right+left)/2:px;a.ApertureYDecenter=xAxis?py:(right+left)/2;
                        if(!mask.ApertureData.ChangeApertureTypeSettings(aperture))throw new Exception("Mask failed");
                        s.UpdateStatus();return s.MFE.GetOperandValue(MeritOperandType.EFNO,d,1,2,0,0,0,0,0);
                    };
                    if(at(lower)!=baseline[d]||(removedValue=at(upper))==baseline[d])throw new Exception("Node not bracketed "+d+"/"+column);
                    for(int i=0;i<34;i++){double middle=(lower+upper)/2;if(at(middle)==baseline[d])lower=middle;else upper=middle;}
                    bounds.Add(Host.Object("axis",xAxis?"x":"y","low",lower/10,"high",upper/10));
                }
                records.Add(Host.Object("density",d,"column",column,"row",row,"baseline",baseline[d],"maskedValue",removedValue,"cellArea",target["cellArea"],"bounds",bounds));
                Host.Write("nodes.json",records);Console.WriteLine("Located "+d+"/"+column+"/"+row);
            }
            Host.Write("complete.json",Host.Object("complete",true));return 0;
        }
        catch(Exception e){Host.Write("error.json",Host.Object("error",e.ToString()));Console.Error.WriteLine(e);return 1;}
        finally{if(app!=null){try{app.PrimarySystem.LoadFile(input,false);}finally{app.CloseApplication();}}}
    }
}
