using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using ZOSAPI;
using ZOSAPI.Editors.LDE;
using ZOSAPI.Editors.MFE;

internal static class NativeAxisNodes
{
    [STAThread]
    public static int Main(string[] args)
    {
        string api = args[0]; Host.Output = args[2];
        if (Directory.Exists(Host.Output) && Directory.EnumerateFileSystemEntries(Host.Output).Any()) return 2;
        Directory.CreateDirectory(Host.Output);
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e)
        {
            string path = Path.Combine(api, new AssemblyName(e.Name).Name + ".dll");
            return File.Exists(path) ? Assembly.LoadFrom(path) : null;
        };
        return Run(api,args[1],args[3]);
    }
    private static int Run(string api,string input,string targetsPath)
    {
        IZOSAPI_Application app = null;
        try
        {
            if (!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api)) throw new Exception("Initialize failed");
            app = new ZOSAPI_Connection().CreateNewApplication();
            Host.Write("environment.json",Host.Object("version",app.OpticStudioVersion,"major",app.ZOSMajorVersion,"minor",app.ZOSMinorVersion,"validLicense",app.IsValidLicenseForAPI,"license",app.LicenseStatus.ToString()));
            if (!app.IsValidLicenseForAPI || app.ZOSMajorVersion != 26 || app.ZOSMinorVersion != 1) throw new Exception("Wrong environment");
            var s=app.PrimarySystem;
            if(!s.LoadFile(input,false)) throw new Exception("Load failed");
            var original = new Dictionary<int,double>();
            foreach(int density in new[]{5,10,20,40}) original[density]=s.MFE.GetOperandValue(MeritOperandType.EFNO,density,1,1,0,0,0,0,0);
            double distance=s.LDE.GetSurfaceAt(1).Thickness;
            s.LDE.GetSurfaceAt(1).Thickness=0;
            var mask=s.LDE.InsertNewSurfaceAt(2); mask.Thickness=distance; mask.SemiDiameter=20;
            s.UpdateStatus();
            foreach(int density in original.Keys) if(original[density]!=s.MFE.GetOperandValue(MeritOperandType.EFNO,density,1,1,0,0,0,0,0)) throw new Exception("Transparent plane changed baseline");
            var targets=new JavaScriptSerializer().Deserialize<List<Dictionary<string,object>>>(File.ReadAllText(targetsPath));
            File.Copy(targetsPath,Path.Combine(Host.Output,"targets.json"));
            var records=new List<object>();
            foreach(var target in targets)
            {
                int density=Convert.ToInt32(target["Density"]),column=Convert.ToInt32(target["Column"]);
                double predicted=Convert.ToDouble(target["PupilX"])*10;
                double coarseDistance=Convert.ToDouble(target["CoarseDistanceMm"]);
                double radius=Math.Min(.002,coarseDistance*.25);
                if(radius<.0002) { records.Add(Host.Object("density",density,"column",column,"skip","coarse node too close","radius",radius)); continue; }
                double left=predicted-radius, lower=left+radius*.01,upper=predicted+radius;
                var aperture=mask.ApertureData.CreateApertureTypeSettings(SurfaceApertureTypes.RectangularObscuration);
                aperture._S_RectangularObscuration.YHalfWidth=.0000001;
                Func<double,double> valueAt=delegate(double right)
                {
                    aperture._S_RectangularObscuration.XHalfWidth=(right-left)/2;
                    aperture._S_RectangularObscuration.ApertureXDecenter=(right+left)/2;
                    if(!mask.ApertureData.ChangeApertureTypeSettings(aperture))throw new Exception("Mask failed");
                    s.UpdateStatus();
                    return s.MFE.GetOperandValue(MeritOperandType.EFNO,density,1,1,0,0,0,0,0);
                };
                double lowValue=valueAt(lower),highValue=valueAt(upper);
                if(lowValue!=original[density] || highValue==original[density]) throw new Exception("Node not bracketed: "+density+"/"+column);
                for(int iteration=0;iteration<34;iteration++)
                {
                    double middle=(lower+upper)/2;
                    if(valueAt(middle)==original[density])lower=middle; else upper=middle;
                }
                records.Add(Host.Object("density",density,"column",column,"predictedPupilX",predicted/10,"nativePupilXLow",lower/10,"nativePupilXHigh",upper/10,"baseline",original[density],"maskedValue",highValue,"cellArea",target["CellArea"]));
                Host.Write("nodes.json",records);
                Console.WriteLine("Located "+density+"/"+column);
            }
            Host.Write("complete.json",Host.Object("complete",true)); return 0;
        }
        catch(Exception e) { Host.Write("error.json",Host.Object("error",e.ToString())); Console.Error.WriteLine(e); return 1; }
        finally { if(app!=null) { try { app.PrimarySystem.LoadFile(input,false); } finally { app.CloseApplication(); } } }
    }
}
