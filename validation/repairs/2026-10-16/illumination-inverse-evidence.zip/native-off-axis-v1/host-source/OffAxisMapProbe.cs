using System.Collections;
using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Services;
var root=Path.GetFullPath(args[0]);
var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root,"validation/zemax/2026-r1/tessar-ray-audit-2026-10-07/even-asphere-gq6-remove/source.zmx")),".zmx");
var integratorType=typeof(IlluminationMetrics).GetNestedType("Integrator",BindingFlags.NonPublic)!;
var ctor=integratorType.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance).Single();
var evaluate=integratorType.GetMethod("Evaluate",BindingFlags.NonPublic|BindingFlags.Instance)!;
var sample=integratorType.GetMethod("Sample",BindingFlags.NonPublic|BindingFlags.Instance)!;
var nodeType=typeof(IlluminationMetrics).GetNestedType("Node",BindingFlags.NonPublic)!;
var mapType=typeof(IlluminationMetrics).GetNestedType("FinitePupilMap",BindingFlags.NonPublic)!;
var mapCtor=mapType.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance).Single();
var mapEvaluate=mapType.GetMethod("Evaluate",BindingFlags.NonPublic|BindingFlags.Instance)!;
double Property(object node,string name)=>(double)nodeType.GetProperty(name)!.GetValue(node)!;
var records=new List<object>();var grids=new List<object>();
foreach(var density in new[]{5,10,20,40})
{
    var integrator=ctor.Invoke([optic,(0.0,1.0),.55,CancellationToken.None,false,false,optic.RayAimingEnabled]);
    var result=(IlluminationMetricResult)evaluate.Invoke(integrator,[density,IlluminationSamplingKind.FiniteImageCosine])!;
    var nodes=(IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(nodeType))!;
    var rows=new List<object>();var ls=new List<double>();var ms=new List<double>();
    var r=Math.Max(8,density/2)-1;
    for(var y=-r;y<=r;y++)for(var x=-r;x<=r;x++)
    {
        if(x*x+y*y>r*r)continue;
        var node=sample.Invoke(integrator,[x/(double)r,y/(double)r])!;
        nodes.Add(node);ls.Add(Property(node,"L"));ms.Add(Property(node,"M"));
        rows.Add(new{X=Property(node,"X"),Y=Property(node,"Y"),L=Property(node,"L"),M=Property(node,"M")});
    }
    var map=mapCtor.Invoke([nodes]);
    var centerL=(ls.Min()+ls.Max())/2;var centerM=(ms.Min()+ms.Max())/2;
    var deltaL=(ls.Max()-ls.Min())*1.01/(2*density);var deltaM=(ms.Max()-ms.Min())*1.01/(2*density);
    grids.Add(new{density,result.EffectiveFNumber,centerL,centerM,deltaL,deltaM,rows});
    foreach(var column in new[]{0,density-1})
    {
        var l=centerL+column*deltaL;var m=centerM;
        var pupil=((double X,double Y,double Determinant))mapEvaluate.Invoke(map,[l,m])!;
        records.Add(new{density,column,row=0,l,m,pupilX=pupil.X,pupilY=pupil.Y,cellArea=deltaL*deltaM});
    }
}
File.WriteAllText(Path.Combine(args[1],"off-axis-targets.json"),JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
File.WriteAllText(Path.Combine(args[1],"off-axis-maps.json"),JsonSerializer.Serialize(grids,new JsonSerializerOptions{WriteIndented=true}));
