using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Services;

var root = Path.GetFullPath(args[0]);
var optic = OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root,
    "validation/zemax/2026-r1/tessar-ray-audit-2026-10-07/even-asphere-gq6-remove/source.zmx")), ".zmx");
var type = typeof(IlluminationMetrics).GetNestedType("Integrator", BindingFlags.NonPublic)!;
var constructor = type.GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance).Single();
var evaluate = type.GetMethod("Evaluate", BindingFlags.NonPublic | BindingFlags.Instance)!;
var sample = type.GetMethod("Sample", BindingFlags.NonPublic | BindingFlags.Instance)!;
var inverse = type.GetMethod("InvertImageCosine", BindingFlags.NonPublic | BindingFlags.Instance)!;
var maps = new List<object>();
var targets = new List<object>();
double Property(object node, string name) => (double)node.GetType().GetProperty(name)!.GetValue(node)!;
foreach (var density in new[] { 5, 10, 20, 40 })
{
    var integrator = constructor.Invoke([optic, (0.0, 0.0), .55, CancellationToken.None, false, false, optic.RayAimingEnabled]);
    var result = (IlluminationMetricResult)evaluate.Invoke(integrator, [density, IlluminationSamplingKind.FiniteImageCosine])!;
    var r = Math.Max(8, density / 2) - 1;
    var coarse = Enumerable.Range(-r, 2 * r + 1).Select(index =>
    {
        var node = sample.Invoke(integrator, [index / (double)r, 0.0])!;
        return new { X = index / (double)r, L = Property(node, "L"), M = Property(node, "M") };
    }).ToArray();
    var delta = (coarse.Max(p => p.L) - coarse.Min(p => p.L)) * 1.01 / (2 * density);
    var fullCoarse = new List<object>();
    for(var row=-r;row<=r;row++) for(var column=-r;column<=r;column++)
    {
        if(row*row+column*column>r*r)continue;
        var node=sample.Invoke(integrator,[column/(double)r,row/(double)r])!;
        fullCoarse.Add(new { X=column/(double)r, Y=row/(double)r, L=Property(node,"L"), M=Property(node,"M") });
    }
    maps.Add(new { Density = density, Delta = delta, result.EffectiveFNumber, Coarse = coarse, FullCoarse=fullCoarse });
    for (var column = 1; column < density; column++)
    {
        var l = column * delta;
        var node = inverse.Invoke(integrator, [l, 0.0, -column * 1.01 / density, 0.0, 1e-11])!;
        var px = Property(node, "X");
        targets.Add(new { Density = density, Column = column, L = l, PupilX = px, PupilY = Property(node, "Y"),
            CoarseDistanceMm = coarse.Min(p => Math.Abs(p.X - px)) * 10, CellArea = delta * delta });
    }
    if (density == 5)
    {
        var axis = Enumerable.Range(-1000, 2001).Select(index =>
        {
            var x = index / 1000.0;
            var node = sample.Invoke(integrator, [x, 0.0])!;
            return new { X = x, L = Property(node, "L"), M = Property(node, "M") };
        }).ToArray();
        File.WriteAllText(Path.Combine(args[1], "dense-axis.json"), JsonSerializer.Serialize(axis));
    }
}
File.WriteAllText(Path.Combine(args[1], "axis-maps.json"), JsonSerializer.Serialize(maps, new JsonSerializerOptions { WriteIndented = true }));
File.WriteAllText(Path.Combine(args[1], "axis-targets.json"), JsonSerializer.Serialize(targets, new JsonSerializerOptions { WriteIndented = true }));
