import json,numpy as np,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
root=p.parents[2]
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
assert read(p/'native-axis-v1/complete.json')['complete']
assert read(p/'native-off-axis-full-v1/complete.json')['complete']
grid=read(p/'off-axis-full-maps.json')[0];d=grid['density'];nodes=grid['rows']
native=read(p/'native-off-axis-full-v1/nodes.json');targets=read(p/'native-off-axis-full-v1/targets.json')
powers=[(i,j) for i in range(7) for j in range(7-i)]
def features(l,m):return np.array([l**i*m**j for i,j in powers])
design=np.array([features(n['L'],n['M']) for n in nodes]);target=np.array([[n['X'],n['Y']] for n in nodes]);u,s,vt=np.linalg.svd(design,full_matrices=False)
retain=s>s[0]*1e-7
coeff=vt[retain].T@((u[:,retain].T@target)/s[retain,None])
errors=[]
for observation in native:
    t=next(t for t in targets if t['column']==observation['column'] and t['row']==observation['row'])
    value=features(t['l'],t['m'])@coeff
    actual=np.array([(b['low']+b['high'])/2 for b in observation['bounds']])
    errors.extend(value-actual)
assert max(map(abs,errors))<1e-9
report=dict(scope='Independent native off-axis node locations vs raw degree-six SVD map built only from shared-Core rays',
    nodes=len(native),rank=int(sum(retain)),relativeCutoff=1e-7,maximumPupilCoordinateDifference=max(map(abs,errors)),
    relativeSingularTail=(s/s[0]).tolist()[-4:],nativeEnvironment=read(p/'native-off-axis-full-v1/environment.json'))
(p/'node-map-verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
fixture=root/'validation/zemax/2026-r1/illumination-inverse-2026-10-16';fixture.mkdir(exist_ok=True)
original=read(root/'validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json')
case=next(c for c in original['Cases'] if c['Name']=='even-asphere')
source=root/case['Source'];assert hashlib.sha256(source.read_bytes()).hexdigest()==case['SourceSha256']
selected=[n for n in native if (n['column'],n['row']) in [(0,0),(-4,-9),(4,-9),(-5,0),(5,0),(-9,0),(9,0),(-4,9),(4,9),(0,-8),(0,8)]]
assert len(selected)>=10
circle=read(root/'artifacts/validation/illumination-grid-20261016/native-final/square-0-operands.json')
circles=[dict(density=r['density'],value=r['value']) for r in circle if r['kind']=='afterReload']
fixture_report=dict(source=case['Source'],sourceSha256=case['SourceSha256'],settings=dict(wave=1,field=2,pol=0,configuration=1,physicalStopRadiusMm=10),
    nativeEnvironment=report['nativeEnvironment'],nodes=selected,circularGrid=circles,
    note='Transparent plane directly after stop leaves all native baseline values unchanged. A local mask isolates one node. Polynomial coefficients are never fitted to these captured outputs.')
(fixture/'controls.json').write_text(json.dumps(fixture_report,indent=2)+'\n',encoding='utf-8')
