import json, math
from pathlib import Path
p=Path(__file__).resolve().parent
data=json.loads((p/'native-axis-v1/nodes.json').read_text(encoding='utf-8-sig'))
targets=json.loads((p/'axis-targets.json').read_text(encoding='utf-8-sig'))
valid=[r for r in data if 'skip' not in r]
for r in valid:
    r['nativePupilX']=(r['nativePupilXLow']+r['nativePupilXHigh'])/2
    r['difference']=r['nativePupilX']-r['predictedPupilX']
for r in valid:
    if r['density'] in [5,10] or r['column'] in [4,8,12,16,20,24,28,32,36,39]:
        print(r['density'],r['column'],'p=',format(r['nativePupilX'],'.15g'),'diff=',format(r['difference'],'.8g'))
print('Repeated target fractions:')
for c in range(1,10):
    rows=[next((r for r in valid if r['density']==d and r['column']==c*d//10),None) for d in [10,20,40]]
    print(c,[(r['density'],r['nativePupilX']) for r in rows if r is not None])
(p/'axis-differences.json').write_text(json.dumps(valid,indent=2)+'\n',encoding='utf-8')
