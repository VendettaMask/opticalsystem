import json,math,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
grids=json.loads((p/'off-axis-maps.json').read_text())
targets=json.loads((p/'off-axis-targets.json').read_text())
native=json.loads((p/'native-off-axis-v1/nodes.json').read_text(encoding='utf-8-sig'))
records=[]
print('Cell area:')
for g in grids:
    row=next(r for r in native if r['density']==g['density'] and r['column']==0)
    area=math.pi/4*(1/row['baseline']**2-1/row['maskedValue']**2)
    print(g['density'],g['deltaL']*g['deltaM']/area-1)
for degree in [4,5,6,7]:
 for normalization in ['centered','scaled','raw']:
  for solver in ['svd','normal']:
   for omit_center in [False,True]:
    errors=[]
    for g in grids:
        n=g['rows']
        if omit_center:n=[r for r in n if r['X']!=0 or r['Y']!=0]
        centerL=g['centerL'] if normalization=='centered' else 0
        centerM=g['centerM'] if normalization=='centered' else 0
        scaleL=g['deltaL']*g['density']/1.01 if normalization!='raw' else 1
        scaleM=g['deltaM']*g['density']/1.01 if normalization!='raw' else 1
        l=np.array([(r['L']-centerL)/scaleL for r in n]);m=np.array([(r['M']-centerM)/scaleM for r in n])
        powers=[(a,b) for a in range(degree+1) for b in range(degree+1-a)]
        a=np.array([l**i*m**j for i,j in powers]).T
        value=np.array([[r['X'],r['Y']] for r in n])
        coeff=np.linalg.lstsq(a,value,rcond=None)[0] if solver=='svd' else np.linalg.solve(a.T@a,a.T@value)
        for target in [r for r in targets if r['density']==g['density']]:
            tl=(target['l']-centerL)/scaleL;tm=(target['m']-centerM)/scaleM
            predicted=np.array([tl**i*tm**j for i,j in powers])@coeff
            obs=next(r for r in native if r['density']==g['density'] and r['column']==target['column'])
            actual=np.array([(b['low']+b['high'])/2 for b in obs['bounds']])
            errors.extend(predicted-actual)
    r=dict(degree=degree,normalization=normalization,solver=solver,omitCenter=omit_center,maximum=max(map(abs,errors)),rmse=float(np.linalg.norm(errors)/np.sqrt(len(errors))))
    records.append(r)
records.sort(key=lambda r:r['maximum'])
for r in records[:18]:print(r)
(p/'off-axis-hypotheses.json').write_text(json.dumps(records,indent=2)+'\n')
