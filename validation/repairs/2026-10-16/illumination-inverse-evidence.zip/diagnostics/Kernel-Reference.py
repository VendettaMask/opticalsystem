import json,math,sys,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
reports=[]
for name in ['123456','relay-lens']:
    coarse=p/('kernel-native-coarse-'+name)
    assert read(coarse/'complete.json')['complete']
    request=read(coarse/'request.json');control=read(coarse/'control.json');rays=read(coarse/'rays.json')
    assert control['aperture']['ApodizationType']=='Uniform' and control['efnoBefore']==control['efnoAfter']
    assert all(r['error']==0 for r in rays)
    chief=next(r for r in rays if r['px']==0 and r['py']==0)
    distance=(chief['z']-control['primaryExitPupil'])/chief['n']
    for r in rays:
        dx=r['x']-chief['x'];dy=r['y']-chief['y'];dz=r['z']-chief['z'];dot=r['l']*dx+r['m']*dy+r['n']*dz
        r['L']=r['l']-(dx-r['l']*dot)/distance;r['M']=r['m']-(dy-r['m']*dot)/distance
    powers=[(i,j) for i in range(7) for j in range(7-i)]
    def features(l,m):return np.array([l**i*m**j for i,j in powers])
    a=np.array([features(r['L'],r['M']) for r in rays]);targets=np.array([[r['px'],r['py']] for r in rays]);u,s,vt=np.linalg.svd(a,full_matrices=False);keep=s>s[0]*1e-7
    c=vt[keep].T@((u[:,keep].T@targets)/s[keep,None])
    accepted=[r for r in rays if r['vignette']==0]
    loL=min(r['L'] for r in accepted);hiL=max(r['L'] for r in accepted);loM=min(r['M'] for r in accepted);hiM=max(r['M'] for r in accepted)
    d=request['density'];deltaL=(hiL-loL)*1.01/(2*d);deltaM=(hiM-loM)*1.01/(2*d)
    points=[]
    for row in range(-d,d+1):
        for col in range(-d,d+1):
            l=(loL+hiL)/2+col*deltaL;m=(loM+hiM)/2+row*deltaM
            x,y=features(l,m)@c;rho=math.hypot(x,y)
            if rho>=1:continue
            edge=math.sin(math.pi/2*min(1,max(0,d*(1-rho))))**2
            points.append(dict(x=float(x),y=float(y),weight=edge))
    fine_request={k:v for k,v in request.items() if k!='points'};fine_request['points']=points
    target=p/(name+'-kernel-fine-request.json')
    if sys.argv[1]=='prepare':target.write_text(json.dumps(fine_request,indent=2)+'\n',encoding='utf-8')
    else:
        actual=read(p/('kernel-native-fine-'+name)/'rays.json');after=read(p/('kernel-native-fine-'+name)/'control.json')
        assert after['efnoBefore']==after['efnoAfter']==control['efnoBefore']
        assert len(actual)==len(points) and all(r['error']==0 for r in actual)
        total=sum(point['weight'] for point,ray in zip(points,actual) if ray['vignette']==0)
        efno=.5*math.sqrt(math.pi/(total*deltaL*deltaM))
        native=control['efnoBefore'];error=abs(efno/native-1)
        reports.append(dict(name=name,wave=request['wave'],field=request['field'],density=d,coarseRays=len(rays),fineRays=len(points),rank=int(sum(keep)),
            nativeEfno=native,nativeInputKernelEfno=efno,relativeDifference=error,primaryExitPupilCore=request['corePrimaryExitPupil'],primaryExitPupilNative=control['primaryExitPupil']))
        assert error<1e-10
if sys.argv[1]!='prepare':
    report=dict(scope='Native coarse and fine rays with independent offline finite-grid reconstruction; separates integration profile from end-to-end ray aiming differences',controls=reports)
    (p/'native-input-kernel-verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
