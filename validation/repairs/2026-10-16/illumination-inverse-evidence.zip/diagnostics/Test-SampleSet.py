import json,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
grids=json.loads((p/'off-axis-maps.json').read_text())
targets=json.loads((p/'off-axis-targets.json').read_text())
native=json.loads((p/'native-off-axis-v1/nodes.json').read_text(encoding='utf-8-sig'))
results=[]
for grid in grids:
 d=grid['density'];nodes=grid['rows']
 powers=[(i,j) for i in range(7) for j in range(7-i)]
 centerL=grid['centerL'];centerM=grid['centerM'];scaleL=grid['deltaL']*d/1.01;scaleM=grid['deltaM']*d/1.01
 def basis(l,m):
    x=(l-centerL)/scaleL;y=(m-centerM)/scaleM
    return [x**i*y**j for i,j in powers]
 a=np.array([basis(n['L'],n['M']) for n in nodes]);y=np.array([[n['X'],n['Y']] for n in nodes])
 ts=[t for t in targets if t['density']==d]
 predict=np.array([basis(t['l'],t['m']) for t in ts])
 actual=np.array([[(b['low']+b['high'])/2 for b in next(n for n in native if n['density']==d and n['column']==t['column'])['bounds']] for t in ts])
 base=np.linalg.lstsq(a,y,rcond=None)[0]
 print('base',d,np.max(np.abs(predict@base-actual)))
 scores=[]
 for index in range(len(nodes)):
    for mode in ['delete','duplicate']:
        if mode=='delete':
            aa=np.delete(a,index,axis=0); yy=np.delete(y,index,axis=0)
        else:aa=np.vstack([a,a[index]]); yy=np.vstack([y,y[index]])
        c=np.linalg.lstsq(aa,yy,rcond=None)[0]
        error=float(np.max(np.abs(predict@c-actual)))
        scores.append(dict(density=d,mode=mode,index=index,x=nodes[index]['X'],y=nodes[index]['Y'],error=error))
 scores.sort(key=lambda row:row['error'])
 for r in scores[:5]:print(r)
 results.extend(scores[:20])
(p/'sample-set-hypotheses.json').write_text(json.dumps(results,indent=2)+'\n')
