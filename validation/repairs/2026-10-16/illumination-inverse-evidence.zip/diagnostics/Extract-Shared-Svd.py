from pathlib import Path
root=Path(__file__).resolve().parents[3]
source=root/'src/OpticalSystemDesign.Core/Optimization/NumericalOptimizers.cs'
original=source.read_text(encoding='utf-8-sig')
start=original.index('    private static SvdFactor FactorSvd(double[,] matrix)')
end=original.index('    private static double[,] Multiply(double[,] left, double[,] right)',start)
block=original[start:end]
factor_record='''    private sealed record SvdFactor(
        double[,] Rotated,
        double[,] RightVectors,
        double[] SingularSquared,
        double Threshold);
'''
assert original.count(factor_record)==1
shared=block.replace('private static SvdFactor FactorSvd(double[,] matrix)',
    'internal static Factorization Factor(double[,] matrix, double? relativeCutoff = null)')
shared=shared.replace('var relativeTolerance = Math.Max(rows, columns) * 1e-12;',
    'var relativeTolerance = relativeCutoff ?? Math.Max(rows, columns) * 1e-12;')
shared=shared.replace('return new SvdFactor(', 'return new Factorization(')
shared=shared.replace('private static double[] Solve(SvdFactor factor,', 'internal static double[] Solve(Factorization factor,')
shared=shared.replace('        var rows = matrix.GetLength(0);',
    '''        ArgumentNullException.ThrowIfNull(matrix);
        if (relativeCutoff is { } cutoff && (!double.IsFinite(cutoff) || cutoff < 0 || cutoff >= 1))
            throw new ArgumentOutOfRangeException(nameof(relativeCutoff));
        ComputationCancellation.ThrowIfCancellationRequested();
        var rows = matrix.GetLength(0);''',1)
shared=shared.replace('            var changed = false;', '            ComputationCancellation.ThrowIfCancellationRequested();\n            var changed = false;',1)
shared=shared.replace('        var columns = factor.RightVectors.GetLength(0);',
    '''        ArgumentNullException.ThrowIfNull(factor);
        ArgumentNullException.ThrowIfNull(rightHandSide);
        if (rightHandSide.Count != factor.Rotated.GetLength(0))
            throw new ArgumentException("Target length must match the factor row count.", nameof(rightHandSide));
        var columns = factor.RightVectors.GetLength(0);''',1)
shared_record=factor_record.replace('private sealed record SvdFactor(', 'internal sealed record Factorization(')
destination=root/'src/OpticalSystemDesign.Core/Analysis/Shared/JacobiSvd.cs'
assert not destination.exists()
destination.write_text('''using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Analysis;

/// <summary>Shared one-sided Jacobi SVD; an explicit relative cutoff selects a finite numerical profile.</summary>
internal static class JacobiSvd
{
'''+shared+shared_record+'}\n',encoding='utf-8')
wrappers='''    private static SvdFactor FactorSvd(double[,] matrix) => JacobiSvd.Factor(matrix);

    private static double[] Solve(SvdFactor factor, IReadOnlyList<double> rightHandSide) =>
        JacobiSvd.Solve(factor, rightHandSide);

'''
updated=original[:start]+wrappers+original[end:]
updated=updated.replace(factor_record,'')
updated='using OpticalSystemDesign.Core.Analysis;\nusing SvdFactor = OpticalSystemDesign.Core.Analysis.JacobiSvd.Factorization;\n'+updated
source.write_text(updated,encoding='utf-8')
print('Extracted shared SVD; optimizer rotation, sums, default threshold and solve order preserved.')
