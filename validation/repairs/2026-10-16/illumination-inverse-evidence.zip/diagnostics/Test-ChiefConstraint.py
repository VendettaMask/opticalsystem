import json,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
gs=json.loads((p/'off-axis-maps.json').read_text());ts=json.loads((p/'off-axis-targets.json').read_text());native=json.loads((p/'native-off-axis-v1/nodes.json').read_text(encoding='utf-8-sig'))
records=[]
for g in gs:
    d=g['density'];nodes=g['rows'];chief=next(r for r in nodes if r['X']==r['Y']==0)
    powers=[(i,j) for i in range(7) for j in range(7-i)];sl=g['deltaL']*d/1.01;sm=g['deltaM']*d/1.01
    def feature(l,m):return np.array([((l-g['centerL'])/sl)**i*((m-g['centerM'])/sm)**j for i,j in powers])
    a=np.array([feature(r['L'],r['M']) for r in nodes]);y=np.array([[r['X'],r['Y']] for r in nodes]);q=feature(chief['L'],chief['M'])
    c=np.linalg.lstsq(a,y,rcond=None)[0]
    v=np.linalg.solve(a.T@a,q);leverage=q@v;residue=-q@c
    print('chief',d,q@c,'leverage',leverage)
    targets=[t for t in ts if t['density']==d];b=np.array([feature(t['l'],t['m']) for t in targets]);expected=np.array([[(r['low']+r['high'])/2 for r in next(n for n in native if n['density']==d and n['column']==t['column'])['bounds']] for t in targets])
    for count in [0,1,2,3,4,8,16,32,64,107,100000000]:
        cc=c+np.outer(v,residue)*(count/(1+count*leverage))
        err=np.max(np.abs(b@cc-expected))
        if count in [0,1,107,100000000]:print('count',count,'error',err)
        records.append(dict(density=d,count=count,error=float(err)))
    # Exact affine constraint: remove constant in chief-centered coordinates.
    def centered(l,m):return np.array([((l-chief['L'])/sl)**i*((m-chief['M'])/sm)**j for i,j in powers[1:]])
    cm=np.linalg.lstsq(np.array([centered(r['L'],r['M']) for r in nodes]),y,rcond=None)[0]
    print('hard anchor',np.max(np.abs(np.array([centered(t['l'],t['m']) for t in targets])@cm-expected)))
(p/'chief-constraint-hypotheses.json').write_text(json.dumps(records,indent=2)+'\n')
