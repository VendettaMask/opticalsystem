$ErrorActionPreference='Stop'
$repo=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$api='D:\Program Files\ANSYS Inc\v261\Zemax OpticStudio'
$exe=Join-Path $PSScriptRoot 'NativeOffAxisNodes.exe'
$compileArgs=@('/nologo','/target:exe','/platform:x64','/main:NativeOffAxisNodes',('/out:'+$exe),'/r:System.Web.Extensions.dll')
foreach($name in @('ZOSAPI.dll','ZOSAPI_Interfaces.dll','ZOSAPI_NetHelper.dll')) { $compileArgs+='/r:'+(Join-Path $api $name) }
$compileArgs+=@(Get-ChildItem (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/ZemaxHost') -Filter '*.cs' | ForEach-Object FullName)
$compileArgs+=Join-Path $PSScriptRoot 'NativeOffAxisNodes.cs'
& (Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe') @compileArgs
if($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
[IO.File]::WriteAllText(($exe+'.config'),'<configuration><startup useLegacyV2RuntimeActivationPolicy="true"><supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.8"/></startup></configuration>')
$env:PATH=$api+';'+$env:PATH
& $exe $api (Join-Path $repo 'validation/zemax/2026-r1/tessar-ray-audit-2026-10-07/even-asphere-gq6-remove/source.zmx') (Join-Path $PSScriptRoot 'native-off-axis-full-v1') (Join-Path $PSScriptRoot 'off-axis-full-targets.json') 2>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot 'native-off-axis-full-v1.log')
exit $LASTEXITCODE
