using System.Text.Json;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Services;
using OpticalSystemDesign.Core.Domain;
var root=Path.GetFullPath(args[0]);var folder=Path.GetFullPath(args[1]);
using var matrix=JsonDocument.Parse(File.ReadAllText(Path.Combine(folder,"matrix-primary-reference-v1.json")));
foreach(var name in new[]{"123456","relay-lens"})
{
    var item=matrix.RootElement.GetProperty("Cases").EnumerateArray().Single(c=>c.GetProperty("Name").GetString()==name);
    var row=item.GetProperty("Comparisons").EnumerateArray().Where(r=>r.GetProperty("Code").GetString()=="EFNO").MaxBy(r=>r.GetProperty("RelativeError").GetDouble());
    var source=Path.Combine(root,item.GetProperty("Source").GetString()!);var optic=OpticalFormatCatalog.Import(File.ReadAllText(source),".zmx");
    var field=optic.Fields[row.GetProperty("Field").GetInt32()-1];var normalized=FieldCoordinates.Normalize(optic.Fields,field.X,field.Y);
    var request=new{input=source,wave=row.GetProperty("Wave").GetInt32(),field=row.GetProperty("Field").GetInt32(),density=row.GetProperty("Density").GetInt32(),
        hx=normalized.X,hy=normalized.Y,corePrimaryExitPupil=optic.Paraxial.EstimateExitPupilLocation()};
    File.WriteAllText(Path.Combine(folder,name+"-kernel-coarse-request.json"),JsonSerializer.Serialize(request,new JsonSerializerOptions{WriteIndented=true}));
}
