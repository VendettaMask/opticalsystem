import json,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
native=json.loads((p/'native-coarse-v1/rays.json').read_text(encoding='utf-8-sig'))
grids=json.loads((p/'off-axis-maps.json').read_text())
observed=json.loads((p/'native-off-axis-v1/nodes.json').read_text(encoding='utf-8-sig'))
targets=json.loads((p/'off-axis-targets.json').read_text())
records=[]
for native_grid in native:
    radius=native_grid['radius'];d=10 if radius==7 else 20 if radius==9 else 40
    grid=next(g for g in grids if g['density']==d)
    rays=native_grid['rows'];chief=next(r for r in rays if r['px']==0 and r['py']==0)
    distance=65.4913715819311/chief['n']
    for r in rays:
        dx=r['x']-chief['x'];dy=r['y']-chief['y'];dot=r['l']*dx+r['m']*dy
        r['L']=r['l']-(dx-r['l']*dot)/distance;r['M']=r['m']-(dy-r['m']*dot)/distance
    errors=[max(abs(r['L']-c['L']),abs(r['M']-c['M'])) for r,c in zip(rays,grid['rows'])]
    print('radius',radius,'count',len(rays),'vignette',[r['vignette'] for r in rays if r['vignette']],'max native-Core cosine difference',max(errors))
    scaleL=grid['deltaL']*d/1.01;scaleM=grid['deltaM']*d/1.01
    def basis(l,m):
        u=(l-grid['centerL'])/scaleL;v=(m-grid['centerM'])/scaleM
        return [u**i*v**j for i in range(7) for j in range(7-i)]
    for keep in ['all','inside']:
        selected=rays if keep=='all' else [r for r in rays if r['vignette']==0 and r['error']==0]
        matrix=np.array([basis(r['L'],r['M']) for r in selected]);target=np.array([[r['px'],r['py']] for r in selected])
        coeff=np.linalg.lstsq(matrix,target,rcond=None)[0]
        for t in [t for t in targets if t['density']==d]:
            obs=next(o for o in observed if o['density']==d and o['column']==t['column'])
            pos=np.array([(b['low']+b['high'])/2 for b in obs['bounds']]);value=np.array(basis(t['l'],t['m']))@coeff
            print(keep,'column',t['column'],'x/y error',value-pos)
    records.append(dict(radius=radius,maximumCosineDifference=max(errors),vignetted=[r for r in rays if r['vignette']]))
(p/'coarse-ray-comparison.json').write_text(json.dumps(records,indent=2)+'\n')
