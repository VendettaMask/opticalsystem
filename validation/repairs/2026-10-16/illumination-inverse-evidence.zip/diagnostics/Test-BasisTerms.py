import itertools,json,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
grids=json.loads((p/'off-axis-maps.json').read_text());targets=json.loads((p/'off-axis-targets.json').read_text());native=json.loads((p/'native-off-axis-v1/nodes.json').read_text(encoding='utf-8-sig'))
g=next(g for g in grids if g['density']==10);n=g['rows'];d=10
lower=[(i,j) for i in range(6) for j in range(6-i)];highest=[(i,6-i) for i in range(7)]
scaleL=g['deltaL']*d/1.01;scaleM=g['deltaM']*d/1.01
l=np.array([(r['L']-g['centerL'])/scaleL for r in n]);m=np.array([(r['M']-g['centerM'])/scaleM for r in n]);xy=np.array([[r['X'],r['Y']] for r in n])
ts=[t for t in targets if t['density']==d];actual=np.array([[(b['low']+b['high'])/2 for b in next(r for r in native if r['density']==d and r['column']==t['column'])['bounds']] for t in ts])
results=[]
for mask in range(128):
    terms=lower+[power for i,power in enumerate(highest) if mask&(1<<i)]
    matrix=np.array([l**i*m**j for i,j in terms]).T
    coeff=np.linalg.lstsq(matrix,xy,rcond=None)[0]
    predict=np.array([[((t['l']-g['centerL'])/scaleL)**i*((t['m']-g['centerM'])/scaleM)**j for i,j in terms] for t in ts])@coeff
    errors=predict-actual
    results.append(dict(highest=[power for i,power in enumerate(highest) if mask&(1<<i)],maximum=float(np.max(np.abs(errors))),errors=errors.tolist()))
results.sort(key=lambda r:r['maximum'])
for r in results[:10]:print(r)
(p/'basis-term-hypotheses.json').write_text(json.dumps(results,indent=2)+'\n')
