import json,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
grids=json.loads((p/'off-axis-maps.json').read_text());targets=json.loads((p/'off-axis-targets.json').read_text());native=json.loads((p/'native-off-axis-v1/nodes.json').read_text(encoding='utf-8-sig'))
records=[]
for normalization in ['raw','centeredRaw','scaled','centered','chiefRaw','chiefScaled']:
 for g in grids:
    d=g['density'];nodes=g['rows'];chief=next(r for r in nodes if r['X']==r['Y']==0)
    centerL=g['centerL'] if normalization.startswith('centered') else chief['L'] if normalization.startswith('chief') else 0
    centerM=g['centerM'] if normalization.startswith('centered') else chief['M'] if normalization.startswith('chief') else 0
    sl=g['deltaL']*d/1.01 if normalization in ['scaled','centered','chiefScaled'] else 1
    sm=g['deltaM']*d/1.01 if normalization in ['scaled','centered','chiefScaled'] else 1
    powers=[(i,j) for i in range(7) for j in range(7-i)]
    def feature(l,m):return [((l-centerL)/sl)**i*((m-centerM)/sm)**j for i,j in powers]
    a=np.array([feature(r['L'],r['M']) for r in nodes]);xy=np.array([[r['X'],r['Y']] for r in nodes]);u,s,vt=np.linalg.svd(a,full_matrices=False)
    ts=[t for t in targets if t['density']==d];b=np.array([feature(t['l'],t['m']) for t in ts]);actual=np.array([[(q['low']+q['high'])/2 for q in next(n for n in native if n['density']==d and n['column']==t['column'])['bounds']] for t in ts])
    for rank in range(20,29):
        coeff=vt[:rank].T@((u[:,:rank].T@xy)/s[:rank,None])
        records.append(dict(normalization=normalization,density=d,rank=rank,error=float(np.max(np.abs(b@coeff-actual))),singularValues=s.tolist(),relativeSingularValues=(s/s[0]).tolist()))
records.sort(key=lambda r:r['error'])
for r in [r for r in records if r['density']==10][:12]: print({k:v for k,v in r.items() if 'Values' not in k})
print('Raw singular tails:')
for r in records:
 if r['normalization']=='raw' and r['rank']==28: print(r['density'],r['singularValues'][-5:],r['relativeSingularValues'][-5:])
(p/'svd-rank-hypotheses.json').write_text(json.dumps(records,indent=2)+'\n')
