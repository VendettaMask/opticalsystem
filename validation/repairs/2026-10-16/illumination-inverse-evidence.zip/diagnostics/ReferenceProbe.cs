using System.Collections;
using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Services;
using OpticalSystemDesign.Core.Raytrace;
using OpticalSystemDesign.Core.Rays;
var root=Path.GetFullPath(args[0]);
var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root,"validation/zemax/2026-r1/tessar-ray-audit-2026-10-07/even-asphere-gq6-remove/source.zmx")),".zmx");
var type=typeof(IlluminationMetrics).GetNestedType("Integrator",BindingFlags.NonPublic)!;
var ctor=type.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance).Single();
var eval=type.GetMethod("Evaluate",BindingFlags.NonPublic|BindingFlags.Instance)!;
var sample=type.GetMethod("Sample",BindingFlags.NonPublic|BindingFlags.Instance)!;
var integrate=type.GetMethod("IntegrateFiniteImageCosine",BindingFlags.NonPublic|BindingFlags.Instance)!;
var distanceField=type.GetField("_finiteReferenceDistance",BindingFlags.NonPublic|BindingFlags.Instance)!;
double Prop(object node,string name)=>(double)node.GetType().GetProperty(name)!.GetValue(node)!;
var records=new List<object>();
var nodeType=typeof(IlluminationMetrics).GetNestedType("Node",BindingFlags.NonPublic)!;
var mapType=typeof(IlluminationMetrics).GetNestedType("FinitePupilMap",BindingFlags.NonPublic)!;
var mapConstructor=mapType.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance).Single();
var mapEvaluate=mapType.GetMethod("Evaluate",BindingFlags.NonPublic|BindingFlags.Instance)!;
foreach(var density in new[]{5,10,40})
foreach(var variant in new[]{"axial","sphere","chiefPath","chiefProjection"})
{
    var integrator=ctor.Invoke([optic,(0.0,1.0),.55,CancellationToken.None,false,false,optic.RayAimingEnabled]);
    eval.Invoke(integrator,[5,IlluminationSamplingKind.FiniteImageCosine]);
    var distance=(double)distanceField.GetValue(integrator)!;
    var center=(Vector3D)type.GetField("_finiteImageCenter",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(integrator)!;
    var generator=(Delegate)type.GetField("_generate",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(integrator)!;
    var ray=(RealRay)generator.DynamicInvoke(0.0,0.0)!;
    var hit=optic.SequentialRayTracer.DiagnoseApertures(ray,stopAtIncidentImage:true,ignoreScalarTransmission:true).UnclippedImage!;
    var v=optic.SurfaceGroup.Items[^1].CoordinateSystem.ToLocalDirection(hit.IncidentDirection??hit.Direction);
    distance=variant switch { "sphere"=>Math.CopySign(Math.Sqrt(distance*distance+center.X*center.X+center.Y*center.Y),distance),"chiefPath"=>distance/v.Z,"chiefProjection"=>distance*v.Z,_=>distance };
    distanceField.SetValue(integrator,distance);
    ((IDictionary)type.GetField("_nodes",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(integrator)!).Clear();
    type.GetField("_orientation",BindingFlags.NonPublic|BindingFlags.Instance)!.SetValue(integrator,0);
    var result=(IlluminationMetricResult)integrate.Invoke(integrator,[density])!;
    var r=Math.Max(8,density/2)-1;
    var nodes=(IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(nodeType))!;
    var ls=new List<double>();var ms=new List<double>();
    for(var y=-r;y<=r;y++)for(var x=-r;x<=r;x++)
    {
        if(x*x+y*y>r*r)continue;
        var node=sample.Invoke(integrator,[x/(double)r,y/(double)r])!;
        nodes.Add(node);ls.Add(Prop(node,"L"));ms.Add(Prop(node,"M"));
    }
    var map=mapConstructor.Invoke([nodes]);
    var pupil=((double X,double Y,double Determinant))mapEvaluate.Invoke(map,[(ls.Min()+ls.Max())/2,(ms.Min()+ms.Max())/2])!;
    var cellArea=(ls.Max()-ls.Min())*(ms.Max()-ms.Min())*1.01*1.01/(4*density*density);
    var record=new{variant,density,distance,center,chiefN=v.Z,result.EffectiveFNumber,cellArea,pupilX=pupil.X,pupilY=pupil.Y};
    records.Add(record);Console.WriteLine(JsonSerializer.Serialize(record));
}
File.WriteAllText(args[1],JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
