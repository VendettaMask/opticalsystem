import hashlib,json,re,subprocess,zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
task=Path(__file__).resolve().parent;root=task.parents[2]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
test_inputs={'Debug':('related-debug-final.trx','build-debug-final.log'),'Release':('related-release-v1.trx','build-release-v1.log')}
tests={};names={}
for config,(trx_name,build_name) in test_inputs.items():
    tree=ET.parse(task/'test-results'/trx_name);counter=tree.find('.//t:Counters',ns).attrib
    results=tree.findall('.//t:UnitTestResult',ns)
    assert int(counter['total'])==int(counter['passed'])==212 and int(counter['failed'])==0
    assert len(results)==212 and all(r.attrib['outcome']=='Passed' for r in results)
    names[config]=sorted(r.attrib['testName'] for r in results)
    build=(task/build_name).read_text(encoding='utf-8-sig')
    assert '0 个警告' in build and '0 个错误' in build
    assert len(set(re.findall(r'^  ([A-Za-z0-9.]+) -> ',build,flags=re.M)))==19
    tests[config]=dict(passed=212,total=212,failed=0,skipped=0,trx='test-results/'+trx_name,buildLog='diagnostics/'+build_name)
assert names['Debug']==names['Release']
matrix=read(task/'matrix-final.json')
before=read(root/'artifacts/validation/illumination-grid-20261016/matrix-final.json')
original=read(root/'validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json')
cases=[];illumination=curvature=0;maximum_efno=maximum_reli=maximum_curvature=0
for case in matrix['Cases']:
    manifest=next(c for c in original['Cases'] if c['Name']==case['Name'])
    assert case['SourceSha256']==manifest['SourceSha256']==sha((root/manifest['Source']).read_bytes())
    assert case['Capture']==manifest['Capture']
    assert all(r['Actual'] is not None and not r['Error'] for r in case['Comparisons'])
    for row in case['Comparisons']:
        if row['Code']=='EFNO':assert row['RelativeError']<=1e-8
        if row['Code']=='RELI':assert row['AbsoluteError']<=1e-8
    for summary in case['Summary']:
        if summary['Code'] in ['FCGS','FCGT']:
            assert summary['Status']=='Pass' and summary['ComparisonTarget']==1e-5
            curvature+=summary['Total'];maximum_curvature=max(maximum_curvature,summary['MaxAbsoluteError'])
        else:
            assert summary['Status']=='Difference' and summary['ComparisonTarget'] is None
            illumination+=summary['Total']
            if summary['Code']=='EFNO':maximum_efno=max(maximum_efno,summary['MaxRelativeError'])
            else:maximum_reli=max(maximum_reli,summary['MaxAbsoluteError'])
    old=next(c for c in before['Cases'] if c['Name']==case['Name'])
    cases.append(dict(name=case['Name'],source=case['Source'],sourceSha256=case['SourceSha256'],before=old['Summary'],after=case['Summary']))
assert illumination==256 and curvature==2160
release=root/'src/OpticalSystemDesign.Core/bin/Release/net10.0/OpticalSystemDesign.Core.dll'
assert sha(release.read_bytes())==sha((root/'tools/diagnostics/Accuracy20261014/bin/Release/net10.0/OpticalSystemDesign.Core.dll').read_bytes())
for config in tests:
    default_hash=sha((root/f'src/OpticalSystemDesign.Core/bin/{config}/net10.0/OpticalSystemDesign.Core.dll').read_bytes())
    assert default_hash==sha((root/f'src/OpticalSystemDesign.App/bin/{config}/net10.0/OpticalSystemDesign.Core.dll').read_bytes())
    assert default_hash==sha((root/f'tests/OpticalSystemDesign.Tests/bin/{config}/net10.0/OpticalSystemDesign.Core.dll').read_bytes())
previous_archives={
 'validation/repairs/2026-10-16/native-diffraction-adapter-evidence.zip':'e452e029523ac4c2a0f806a07fe3a4a05920371ff797a04de4d503e81bfc2a6c',
 'validation/repairs/2026-10-16/illumination-finite-grid-evidence.zip':'a137625a22a2e7e333f637b17e2117b3602569add648b60445e09f8782d3e83d'}
for path,expected in previous_archives.items():assert sha((root/path).read_bytes())==expected
parity=read(task/'svd-parity.json');assert parity['matrices']==80 and parity['factorAndSolveBitwiseIdentical']
assert parity['afterSha256']==sha(release.read_bytes())
nodes=read(task/'node-map-verification.json');assert nodes['nodes']==305 and nodes['maximumPupilCoordinateDifference']<1e-9
kernel=read(task/'native-input-kernel-verification.json')
for control in kernel['controls']:
    assert control['relativeDifference']<1e-10
    row=next(r for c in matrix['Cases'] if c['Name']==control['name'] for r in c['Comparisons'] if r['Code']=='EFNO' and r['Wave']==control['wave'] and r['Field']==control['field'] and r['Density']==control['density'])
    assert control['nativeEfno']==row['Native']
native_folders=['native-axis-v1','native-off-axis-v1','native-off-axis-full-v1','native-coarse-v1',
    'kernel-native-coarse-123456','kernel-native-coarse-relay-lens','kernel-native-fine-123456','kernel-native-fine-relay-lens']
for folder in native_folders:
    assert read(task/folder/'complete.json')['complete']
    env=read(task/folder/'environment.json');assert env['validLicense'] and env['version']==260127

payloads={}
def put(name,path):
    assert name not in payloads;payloads[name]=path.read_bytes()
allowed={'.json','.log','.cs','.csproj','.py','.ps1','.trx','.zmx'}
for path in sorted(task.iterdir()):
    if path.is_file() and path.suffix.lower() in allowed and not path.name.startswith('package-') and not path.name.startswith('documentation-delivery'):
        put('diagnostics/'+path.name,path)
for folder in native_folders+['before-source','prototype5-source','prototype6-source','test-results']:
    for path in sorted((task/folder).rglob('*')):
        if path.is_file() and path.suffix.lower() in allowed:put(path.relative_to(task).as_posix(),path)
capture_files=['NativeAxisNodes.cs','NativeOffAxisNodes.cs','NativeCoarseRays.cs','NativeKernelCapture.cs']
for name in capture_files:put('capture-final-sources/'+name,task/name)
for path in sorted((root/'tools/OpticalSystemDesign.ZemaxComparison/ZemaxHost').glob('*.cs')):put('capture-final-sources/helpers/'+path.name,path)
source_files=[
 'src/OpticalSystemDesign.Core/Services/IlluminationMetrics.cs',
 'src/OpticalSystemDesign.Core/Services/IlluminationMetrics.FiniteImageCosine.cs',
 'src/OpticalSystemDesign.Core/Services/IlluminationMetrics.FinitePupilMap.cs',
 'src/OpticalSystemDesign.Core/Services/IlluminationMetrics.ImageCosine.cs',
 'src/OpticalSystemDesign.Core/Analysis/Shared/JacobiSvd.cs',
 'src/OpticalSystemDesign.Core/Optimization/NumericalOptimizers.cs',
 'src/OpticalSystemDesign.Application/Services/MeritOperandReferenceCatalog.cs',
 'tests/OpticalSystemDesign.Tests/IlluminationInverseNativeTests.cs',
 'tests/OpticalSystemDesign.Tests/FiniteIlluminationGridTests.cs',
 'tools/diagnostics/Accuracy20261014/Program.cs',
 'tools/diagnostics/Accuracy20261014/Accuracy20261014.csproj']
for path in source_files:put('final-source/'+path,root/path)
old_optimizer=subprocess.check_output(['git','show','HEAD:src/OpticalSystemDesign.Core/Optimization/NumericalOptimizers.cs'],cwd=root)
payloads['before-source/NumericalOptimizers.HEAD.cs']=old_optimizer
put('before/matrix-finite-grid-final.json',root/'artifacts/validation/illumination-grid-20261016/matrix-final.json')
for path in sorted((root/'validation/zemax/2026-r1/illumination-inverse-2026-10-16').iterdir()):
    if path.is_file():put('controls/'+path.name,path)
for case in original['Cases']:put('original-sources/'+case['Name']+'.ZMX',root/case['Source'])
put('original-sources/manifest.json',root/'validation/zemax/2026-r1/fcgt-efno-2026-10-14/manifest.json')
payloads['README.txt']=b'''EFNO/RELI inverse-map repair evidence, 2026-10-16.
The final product uses only shared C# Core rays. Native outputs are offline evidence, never runtime coefficients.
All original source identities, native references, fields, wavelengths, Samp settings and old tolerances remain unchanged.
The new scoped numerical identity regression is 1e-8 relative EFNO / absolute RELI; old null-target reports retain Difference semantics.
Native host entry points for the final captures are copied to capture-final-sources. native-off-axis-v1 retains its exact earlier entry point; the final version adds full-grid row metadata. Diagnostic Core probes are their last exploratory variants, not asserted byte-identical to all earlier prototype runs.
The axis-core failure used an excessively tight diagnostic inverse request. Reference/kernel request prototype compile errors were corrected; their logs remain. Final root builds/tests have zero failures.
SvdParityProbe compares the pre-extraction in-memory optimizer SVD against the final shared implementation. The pre-extraction DLL hash is recorded; no compiled DLL/EXE/PDB or proprietary API binary is distributed. The original optimizer source, exact extraction script and parity program are retained.
Independent Cooke/Tessar investigations remain excluded.
'''
catalog=dict(files=[dict(path=name,size=len(data),sha256=sha(data)) for name,data in sorted(payloads.items())])
payloads['catalog.json']=(json.dumps(catalog,indent=2)+'\n').encode()
archive=root/'validation/repairs/2026-10-16/illumination-inverse-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as package:
    for name,data in sorted(payloads.items()):package.writestr(name,data)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for row in catalog['files']:
        data=package.read(row['path']);assert sha(data)==row['sha256'] and len(data)==row['size']
curve_result=next(r for r in ET.parse(task/'test-results/related-release-v1.trx').findall('.//t:UnitTestResult',ns)
    if '.ProductPolZeroCurveRetainsOriginalCapturedRelativeIlluminationGate' in r.attrib['testName'])
curve=json.loads(curve_result.find('t:Output/t:StdOut',ns).text.strip().split('ProductCapturedPolZero=')[1])
docpath=task/'documentation-final.json'
documentation=read(docpath) if docpath.exists() else None
if documentation:
    assert not documentation['BrokenLinks'] and not documentation['MarkdownFenceIssues'] and not documentation['LocalOnlyLinks']
    assert not any(g['Scope']=='Guide' for g in documentation['RepeatedParagraphs'])
report=dict(date='2026-10-16',baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),workingTreeDirty=True,
 scope='Original four-file EFNO/RELI finite profile algorithm closure; new scoped identity assertions, independent native nodes and native-input kernel controls',
 algorithm=dict(inversePolynomialTotalDegree=6,rawUncenteredUnscaledImageCosines=True,relativeSingularCutoff=1e-7,
    pupilReference='system primary wavelength',distance='selected-wave chief-ray distance to scalar pupil-reference plane',coefficients='shared-Core coarse rays only'),
 matrix=dict(curvatureRows=2160,curvatureTargetMm=1e-5,curvatureMaximumAbsoluteErrorMm=maximum_curvature,
    illuminationRows=256,newScopedGuard=dict(efnoRelative=1e-8,reliAbsolute=1e-8,passed=256),
    maximumEfnoRelativeDifference=maximum_efno,maximumReliAbsoluteDifference=maximum_reli,
    legacyReporterStatus='Difference with null illumination target retained; new scoped regression passes separately',cases=cases),
 nativeNodeVerification=nodes,nativeInputKernelVerification=kernel,optimizerSvdParity=parity,
 tests=tests,identicalSelectedTestNames=True,newTests=21,
 builds={config:dict(projects=19,warnings=0,errors=0) for config in tests},
 productCurve=dict(rmse=curve['Rmse'],maximumAbsoluteError=curve['MaximumAbsoluteError'],unchangedRmseTarget=.002,unchangedMaximumTarget=.004),
 defaultCoreSha256={config:sha((root/f'src/OpticalSystemDesign.Core/bin/{config}/net10.0/OpticalSystemDesign.Core.dll').read_bytes()) for config in tests},
 defaultApplicationAndTestCoreCopiesIdentical=True,previousEvidenceArchivesUnchanged=previous_archives,
 finalSourceSha256={path:sha((root/path).read_bytes()) for path in source_files},
 evidence=dict(path=archive.relative_to(root).as_posix(),size=archive.stat().st_size,sha256=sha(archive.read_bytes()),entries=len(payloads),allEntriesReadbackVerified=True),
 documentation=dict(documents=documentation['Documents'],strict=True,source='diagnostics/documentation-final.json') if documentation else None,
 limits=['No complete repository suite, installer rebuild, submission or push in this stage',
    'Actual nonzero end-to-end differences remain reported; this is not bitwise identity or arbitrary native-system certification',
    'Independent Cooke/Tessar, native polarized/coherent fields, EFNO vignetting factors and Wave=0 are excluded',
    'Scalar paraxial pupil reference is not an aberrated 3D pupil model; native/core reference input differences are preserved'])
(root/'docs/validation/ILLUMINATION_INVERSE_REPAIR_2026-10-16.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(matrix=report['matrix']['newScopedGuard'],maximumEfno=maximum_efno,maximumReli=maximum_reli,evidence=report['evidence'],tests=tests),indent=2))
