using System.Collections;
using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Services;
var root=Path.GetFullPath(args[0]);
var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root,"validation/zemax/2026-r1/tessar-ray-audit-2026-10-07/even-asphere-gq6-remove/source.zmx")),".zmx");
var integratorType=typeof(IlluminationMetrics).GetNestedType("Integrator",BindingFlags.NonPublic)!;
var ctor=integratorType.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance).Single();
var evaluate=integratorType.GetMethod("Evaluate",BindingFlags.NonPublic|BindingFlags.Instance)!;
var sample=integratorType.GetMethod("Sample",BindingFlags.NonPublic|BindingFlags.Instance)!;
var nodeType=typeof(IlluminationMetrics).GetNestedType("Node",BindingFlags.NonPublic)!;
var mapType=typeof(IlluminationMetrics).GetNestedType("FinitePupilMap",BindingFlags.NonPublic)!;
var mapCtor=mapType.GetConstructors(BindingFlags.NonPublic|BindingFlags.Instance).Single();
var mapEvaluate=mapType.GetMethod("Evaluate",BindingFlags.NonPublic|BindingFlags.Instance)!;
double Property(object node,string name)=>(double)nodeType.GetProperty(name)!.GetValue(node)!;
var records=new List<object>();var grids=new List<object>();
var full=args.Length>2;
foreach(var density in full?new[]{10}:new[]{5,10,20,40})
{
    var integrator=ctor.Invoke([optic,(0.0,1.0),.55,CancellationToken.None,false,false,optic.RayAimingEnabled]);
    var result=(IlluminationMetricResult)evaluate.Invoke(integrator,[density,IlluminationSamplingKind.FiniteImageCosine])!;
    var nodes=(IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(nodeType))!;
    var rows=new List<object>();var ls=new List<double>();var ms=new List<double>();
    var r=Math.Max(8,density/2)-1;
    for(var y=-r;y<=r;y++)for(var x=-r;x<=r;x++)
    {
        if(x*x+y*y>r*r)continue;
        var node=sample.Invoke(integrator,[x/(double)r,y/(double)r])!;
        nodes.Add(node);ls.Add(Property(node,"L"));ms.Add(Property(node,"M"));
        rows.Add(new{X=Property(node,"X"),Y=Property(node,"Y"),L=Property(node,"L"),M=Property(node,"M")});
    }
    var map=mapCtor.Invoke([nodes]);
    var centerL=(ls.Min()+ls.Max())/2;var centerM=(ms.Min()+ms.Max())/2;
    var deltaL=(ls.Max()-ls.Min())*1.01/(2*density);var deltaM=(ms.Max()-ms.Min())*1.01/(2*density);
    grids.Add(new{density,result.EffectiveFNumber,centerL,centerM,deltaL,deltaM,rows});
    var locations=full?Enumerable.Range(-density,2*density+1).SelectMany(row=>Enumerable.Range(-density,2*density+1).Select(column=>(Column:column,Row:row)))
        :new[]{(Column:0,Row:0),(Column:density-1,Row:0)};
    foreach(var location in locations)
    {
        var column=location.Column;var row=location.Row;
        var l=centerL+column*deltaL;var m=centerM+row*deltaM;
        var pupil=((double X,double Y,double Determinant))mapEvaluate.Invoke(map,[l,m])!;
        if(pupil.X*pupil.X+pupil.Y*pupil.Y>=.9999)continue;
        if(full&&rows.Cast<object>().Any(n=>Math.Abs((double)n.GetType().GetProperty("X")!.GetValue(n)!-pupil.X)<.0006&&Math.Abs((double)n.GetType().GetProperty("Y")!.GetValue(n)!-pupil.Y)<.0006))continue;
        records.Add(new{density,column,row,l,m,pupilX=pupil.X,pupilY=pupil.Y,cellArea=deltaL*deltaM});
    }
}
File.WriteAllText(Path.Combine(args[1],full?"off-axis-full-targets.json":"off-axis-targets.json"),JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
File.WriteAllText(Path.Combine(args[1],full?"off-axis-full-maps.json":"off-axis-maps.json"),JsonSerializer.Serialize(grids,new JsonSerializerOptions{WriteIndented=true}));
