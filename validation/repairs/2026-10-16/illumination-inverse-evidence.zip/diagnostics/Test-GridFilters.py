import itertools,json,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
g=next(r for r in json.loads((p/'off-axis-maps.json').read_text()) if r['density']==10)
targets=[t for t in json.loads((p/'off-axis-targets.json').read_text()) if t['density']==10]
native=json.loads((p/'native-off-axis-v1/nodes.json').read_text(encoding='utf-8-sig'))
actual=np.array([[(b['low']+b['high'])/2 for b in next(n for n in native if n['density']==10 and n['column']==t['column'])['bounds']] for t in targets])
powers=[(i,j) for i in range(7) for j in range(7-i)];sl=g['deltaL']*10/1.01;sm=g['deltaM']*10/1.01
def feature(l,m):return [((l-g['centerL'])/sl)**i*((m-g['centerM'])/sm)**j for i,j in powers]
b=np.array([feature(t['l'],t['m']) for t in targets]);n=g['rows'];a=np.array([feature(r['L'],r['M']) for r in n]);xy=np.array([[r['X'],r['Y']] for r in n])
filters={'all':lambda r:True,'noX0':lambda r:r['X']!=0,'noY0':lambda r:r['Y']!=0,'noAxes':lambda r:r['X']!=0 and r['Y']!=0,'noChief':lambda r:r['X']!=0 or r['Y']!=0,'strictCircle':lambda r:r['X']**2+r['Y']**2<1-1e-10}
cardinals=[(-1,0),(1,0),(0,-1),(0,1)]
for mask in range(16):
    excluded=[value for i,value in enumerate(cardinals) if mask&(1<<i)]
    filters['noCardinals'+str(excluded)]=lambda r,excluded=excluded:(r['X'],r['Y']) not in excluded
results=[]
for name,func in filters.items():
    indices=[i for i,r in enumerate(n) if func(r)];c=np.linalg.lstsq(a[indices],xy[indices],rcond=None)[0]
    results.append(dict(name=name,count=len(indices),error=float(np.max(np.abs(b@c-actual))),errors=(b@c-actual).tolist()))
results.sort(key=lambda r:r['error'])
for r in results[:12]:print(r)
(p/'grid-filter-hypotheses.json').write_text(json.dumps(results,indent=2)+'\n')
