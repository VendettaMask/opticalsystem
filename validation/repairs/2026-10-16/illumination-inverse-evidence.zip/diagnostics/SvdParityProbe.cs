using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core.Services;
var oldPath=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);
var context=new AssemblyLoadContext("before-shared-svd",isCollectible:true);
var oldAssembly=context.LoadFromAssemblyPath(oldPath);
var oldType=oldAssembly.GetType("OpticalSystemDesign.Core.Optimization.DampedLeastSquaresSearch",throwOnError:true)!;
var newType=typeof(IlluminationMetrics).Assembly.GetType(oldType.FullName!,throwOnError:true)!;
var oldFactor=oldType.GetMethod("FactorSvd",BindingFlags.Static|BindingFlags.NonPublic)!;
var newFactor=newType.GetMethod("FactorSvd",BindingFlags.Static|BindingFlags.NonPublic)!;
var oldSolve=oldType.GetMethod("Solve",BindingFlags.Static|BindingFlags.NonPublic)!;
var newSolve=newType.GetMethod("Solve",BindingFlags.Static|BindingFlags.NonPublic)!;
var rng=new Random(648126);var compared=0;
foreach(var rows in new[]{2,4,8,16,30})
foreach(var columns in new[]{1,2,4,8})
foreach(var conditioning in new[]{1.0,1e-5,1e-10,1e-14})
{
    var matrix=new double[rows,columns];var target=new double[rows];
    for(var r=0;r<rows;r++)
    {
        target[r]=rng.NextDouble()*2-1;
        for(var c=0;c<columns;c++)matrix[r,c]=(rng.NextDouble()*2-1)*Math.Pow(conditioning,c/(double)Math.Max(1,columns-1));
    }
    var old=oldFactor.Invoke(null,[matrix])!;var current=newFactor.Invoke(null,[matrix])!;
    foreach(var property in new[]{"Rotated","RightVectors","SingularSquared"})
    {
        var a=(Array)old.GetType().GetProperty(property)!.GetValue(old)!;var b=(Array)current.GetType().GetProperty(property)!.GetValue(current)!;
        if(!a.Cast<double>().Select(BitConverter.DoubleToInt64Bits).SequenceEqual(b.Cast<double>().Select(BitConverter.DoubleToInt64Bits)))throw new Exception("Factor differs: "+property);
    }
    var av=(double[])oldSolve.Invoke(null,[old,target])!;var bv=(double[])newSolve.Invoke(null,[current,target])!;
    if(!av.Select(BitConverter.DoubleToInt64Bits).SequenceEqual(bv.Select(BitConverter.DoubleToInt64Bits)))throw new Exception("Solve differs");
    compared++;
}
var result=new{matrices=compared,factorAndSolveBitwiseIdentical=true,beforeSha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(oldPath))),
    afterSha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(IlluminationMetrics).Assembly.Location)))};
File.WriteAllText(output,JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine(JsonSerializer.Serialize(result));
