import json,numpy as np
from pathlib import Path
p=Path(__file__).resolve().parent
maps=json.loads((p/'axis-maps.json').read_text())
observed=json.loads((p/'axis-differences.json').read_text())
targets=json.loads((p/'axis-targets.json').read_text())
records=[]
for degree in range(1,11):
 for shape in ['total','tensor','radial']:
    errors=[]
    details=[]
    for grid in maps:
        d=grid['Density']
        nodes=grid['FullCoarse']
        scale=grid['Delta']*d/1.01
        l=np.array([n['L']/scale for n in nodes]);m=np.array([n['M']/scale for n in nodes])
        x=np.array([n['X'] for n in nodes])
        if shape=='radial':
            powers=[(1,k) for k in range((degree+1)//2)]
            matrix=np.array([l*(l*l+m*m)**k for _,k in powers]).T
        else:
            powers=[(a,b) for a in range(degree+1) for b in range(degree+1) if shape=='tensor' or a+b<=degree]
            matrix=np.array([l**a*m**b for a,b in powers]).T
        coeff=np.linalg.lstsq(matrix,x,rcond=None)[0]
        for row in observed:
            if row['density']!=d:continue
            target=next(t for t in targets if t['Density']==d and t['Column']==row['column'])
            tl=target['L']/scale
            if shape=='radial': basis=np.array([tl**(2*k+1) for _,k in powers])
            else:basis=np.array([tl**a*(0**b) for a,b in powers])
            value=float(basis@coeff)
            error=value-row['nativePupilX']
            errors.append(error)
            details.append(dict(density=d,column=row['column'],value=value,native=row['nativePupilX'],error=error))
    result=dict(degree=degree,shape=shape,terms=len(powers),maximumError=max(map(abs,errors)),rmse=float(np.linalg.norm(errors)/np.sqrt(len(errors))),details=details)
    records.append(result)
records.sort(key=lambda r:r['maximumError'])
for r in records[:15]: print({k:v for k,v in r.items() if k!='details'})
(p/'polynomial-hypotheses.json').write_text(json.dumps(records,indent=2)+'\n')
