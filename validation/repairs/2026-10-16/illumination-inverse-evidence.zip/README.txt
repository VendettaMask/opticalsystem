EFNO/RELI inverse-map repair evidence, 2026-10-16.
The final product uses only shared C# Core rays. Native outputs are offline evidence, never runtime coefficients.
All original source identities, native references, fields, wavelengths, Samp settings and old tolerances remain unchanged.
The new scoped numerical identity regression is 1e-8 relative EFNO / absolute RELI; old null-target reports retain Difference semantics.
Native host entry points for the final captures are copied to capture-final-sources. native-off-axis-v1 retains its exact earlier entry point; the final version adds full-grid row metadata. Diagnostic Core probes are their last exploratory variants, not asserted byte-identical to all earlier prototype runs.
The axis-core failure used an excessively tight diagnostic inverse request. Reference/kernel request prototype compile errors were corrected; their logs remain. Final root builds/tests have zero failures.
SvdParityProbe compares the pre-extraction in-memory optimizer SVD against the final shared implementation. The pre-extraction DLL hash is recorded; no compiled DLL/EXE/PDB or proprietary API binary is distributed. The original optimizer source, exact extraction script and parity program are retained.
Independent Cooke/Tessar investigations remain excluded.
