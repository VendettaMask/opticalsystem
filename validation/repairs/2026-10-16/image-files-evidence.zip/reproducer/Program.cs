using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Application.Runtime;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Domain;
using SkiaSharp;

var auditRecords = new List<string>();
var root = Path.GetFullPath(".tmp/issue-audit-20261016c");
var runDirectory = Path.Combine(root, "outputs-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(runDirectory);
var loader = typeof(WorkbenchRuntime).Assembly.GetType("OpticalSystemDesign.Application.Services.ImageFileLoader")!;
var save = loader.GetMethod("SaveAnalysisRaster", BindingFlags.Static | BindingFlags.NonPublic)!;
var sourceFile = Path.Combine(runDirectory, "external.png");
var jpegFile = Path.Combine(runDirectory, "external.jpg");
using (var bitmap = new SKBitmap(16, 16))
{
    bitmap.Erase(new SKColor(25, 100, 200));
    using var image = SKImage.FromBitmap(bitmap);
    using var png = image.Encode(SKEncodedImageFormat.Png, 100);
    using var stream = File.Create(sourceFile);
    png.SaveTo(stream);
    using var jpeg = image.Encode(SKEncodedImageFormat.Jpeg, 95);
    using var jpegStream = File.Create(jpegFile);
    jpeg.SaveTo(jpegStream);
}

Run("external-file-decode-and-stream-ownership", () => new[] { sourceFile, jpegFile }.Select(path =>
{
    using var bitmap = SKBitmap.Decode(path);
    using var stream = File.OpenRead(path);
    object metadata;
    using (var codec = SKCodec.Create(stream))
        metadata = new { codec.Info.Width, codec.Info.Height, StreamCanSeek = stream.CanSeek };
    var settings = Settings();
    settings["SourceMode"] = "外部位图";
    settings["SourceFile"] = path;
    object result;
    try { result = new WorkbenchRuntime(Cone()).BuildAnalysisData("Image Simulation", settings).Outcome.ToString(); }
    catch (Exception e) { result = new { Error = e.GetType().Name, e.Message, e.StackTrace }; }
    return new { Extension = Path.GetExtension(path), DecodeWidth = bitmap.Width, DecodeHeight = bitmap.Height,
        Metadata = metadata, StreamCanSeekAfterCodecDisposal = stream.CanSeek, WorkbenchResult = result };
}).ToArray());

Run("source-mode-vs-file", () =>
{
    var results = new List<object>();
    foreach (var mode in new[] { "内置图像", "外部位图" })
    {
        foreach (var path in new[] { "", sourceFile, Path.Combine(runDirectory, "missing.png") })
        {
            var settings = Settings();
            settings["SourceMode"] = mode;
            settings["SourceFile"] = path;
            try
            {
                var data = new WorkbenchRuntime(Cone()).BuildAnalysisData("Image Simulation", settings);
                var source = data.PlotPanes![0].Series[0].Points;
                results.Add(new { Mode = mode, Input = Path.GetFileName(path),
                    Outcome = data.Outcome.ToString(), ReportedMode = data.Values["SourceMode"],
                    FirstRed = source[0].Red, FirstGreen = source[0].Green, FirstBlue = source[0].Blue });
            }
            catch (Exception e) { results.Add(new { Mode = mode, Input = Path.GetFileName(path), Error = e.GetType().Name, e.Message }); }
        }
    }
    return results;
});

Run("supported-image-exports", () =>
{
    var results = new List<object>();
    foreach (var extension in new[] { "png", "jpg", "jpeg", "bmp" })
    {
        var path = Path.Combine(runDirectory, "export." + extension);
        var settings = Settings();
        settings["OutputFile"] = path;
        try
        {
            var data = new WorkbenchRuntime(Cone()).BuildAnalysisData("Image Simulation", settings);
            var bytes = File.ReadAllBytes(path);
            using var bitmap = SKBitmap.Decode(path);
            results.Add(new { Extension = extension, Outcome = data.Outcome.ToString(),
                Prefix = Convert.ToHexString(bytes.AsSpan(0, Math.Min(12, bytes.Length))),
                Decoded = bitmap is not null, Width = bitmap?.Width, Height = bitmap?.Height });
        }
        catch (Exception e) { results.Add(new { Extension = extension, Error = e.GetType().Name, e.Message, FileExists = File.Exists(path) }); }
    }
    return results;
});

Run("display-both-export-selection", () =>
{
    var data = new ImageSimulationAnalysis(Cone(), Config()).GenerateData();
    var path = Path.Combine(runDirectory, "both.png");
    save.Invoke(null, [data, path]);
    using var bitmap = SKBitmap.Decode(path);
    var pixel = bitmap.GetPixel(0, 0);
    return new { Titles = data.PlotPanes!.Select(p => p.Title).ToArray(),
        Exported = new[] { pixel.Red / 255d, pixel.Green / 255d, pixel.Blue / 255d },
        FirstPane = data.PlotPanes![0].Series[0].Points[0],
        SecondPane = data.PlotPanes![1].Series[0].Points[0] };
});

Run("final-raster-statistics", () =>
{
    var results = new List<object>();
    foreach (var (flip, width, height) in new[] { ("None", 0, 0), ("Horizontal", 0, 0), ("Horizontal", 1, 1) })
    {
        var result = ImageSimulationEngine.Simulate(Cone(), Source(), Config(flip, width, height));
        results.Add(new { Flip = flip, Width = width, Height = height,
            ReportedMaximum = result.MaximumValue, RasterMaximum = result.Simulated.Values.Cast<double>().Max(),
            ReportedChange = result.MeanAbsoluteChange,
            RasterChange = result.Source.Values.Cast<double>().Zip(result.Simulated.Values.Cast<double>(), (a, b) => Math.Abs(a - b)).Average() });
    }
    return results;
});

var recordPath = Path.Combine(runDirectory, "results.jsonl");
File.WriteAllLines(recordPath, auditRecords);
Console.WriteLine(JsonSerializer.Serialize(new { Evidence = recordPath,
    CoreAssembly = typeof(Optic).Assembly.Location, ApplicationAssembly = typeof(WorkbenchRuntime).Assembly.Location }));

static Optic Cone()
{
    var optic = new Optic { FieldDefinition = FieldDefinitionKind.ObjectHeight };
    optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint { Y = 2 });
    optic.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = 10 },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = 2 },
        new OpticalSurface { Thickness = 8 },
        new OpticalSurface()
    ]);
    return optic;
}

static Dictionary<string, string> Settings() => new()
{
    ["ImageWidth"] = "16", ["ImageHeight"] = "16", ["GuardBand"] = "无",
    ["PsfSize"] = "8 x 8", ["NumRays"] = "8 x 8", ["PsfGridRows"] = "1", ["PsfGridColumns"] = "1",
    ["EigenPsfComponents"] = "1", ["DistortionGridSize"] = "9", ["DistortionPolynomialDegree"] = "1",
    ["PixelSize"] = "0.01", ["FieldHeight"] = "1", ["AberrationMode"] = "无",
    ["RelativeIllumination"] = "false", ["DisplayAs"] = "源位图"
};

static RgbImage Source()
{
    var pixels = new double[1, 16, 16];
    for (var y = 0; y < 16; y++)
        for (var x = 0; x < 16; x++) pixels[0, y, x] = .1 + .5 * x / 15 + .3 * y / 15;
    return new(pixels);
}

static ImageSimulationConfig Config(string flip = "None", int width = 0, int height = 0) => new()
{
    SourceImage = Source(), ImageWidth = 16, ImageHeight = 16, Padding = 0, WavelengthsMicrometers = [.55],
    PsfGridRows = 1, PsfGridColumns = 1, PsfSize = 8, NumRays = 8, Components = 1,
    PixelSizeMillimeters = .01, FieldHeight = 1, AberrationMode = "None",
    UseRelativeIllumination = false, DistortionGridSize = 9, DistortionPolynomialDegree = 1,
    ImageFlip = flip, OutputWidth = width, OutputHeight = height
};

void Run(string name, Func<object> action)
{
    var watch = System.Diagnostics.Stopwatch.StartNew();
    string record;
    try { record = JsonSerializer.Serialize(new { Name = name, Result = action(), Milliseconds = watch.ElapsedMilliseconds }); }
    catch (Exception e) { record = JsonSerializer.Serialize(new { Name = name, Error = e.ToString(), Milliseconds = watch.ElapsedMilliseconds }); }
    auditRecords.Add(record);
    Console.WriteLine(record);
}
