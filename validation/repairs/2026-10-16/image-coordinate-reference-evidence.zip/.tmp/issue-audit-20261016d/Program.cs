using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Interactions;

var records = new List<string>();
var evidenceDirectory = Path.GetFullPath(".tmp/issue-audit-20261016d/outputs-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(evidenceDirectory);

Run("diffraction-reference-choice", () =>
{
    var results = new List<object>();
    foreach (var field in new[] { .2, .5, .8 })
    {
        var optic = Primary();
        var wavelength = new Wavelength { Nanometers = 550, IsPrimary = true };
        const int sampling = 16;
        const int size = 16;
        const double pitch = .0005;
        var chief = ImageSimulationEngine.GenerateBasis(optic, wavelength,
            Config(mode: "Diffraction", reference: "chief", fieldY: field, psfSize: size, pitch: pitch, rays: sampling));
        var centroid = ImageSimulationEngine.GenerateBasis(optic, wavelength,
            Config(mode: "Diffraction", reference: "centroid", fieldY: field, psfSize: size, pitch: pitch, rays: sampling));
        var offsetMethod = typeof(DiffractionEngine).GetMethod("HuygensGeometricCenterOffset", BindingFlags.NonPublic | BindingFlags.Static)!;
        var offset = ((double X, double Y))offsetMethod.Invoke(null,
            [optic, (0d, field), new Wavelength[] { wavelength }, wavelength, sampling, optic.RayAimingEnabled])!;
        var expectedChief = DiffractionEngine.ComputeHuygensPsf(optic, (0, field), wavelength, sampling, size, pitch,
            aimAtStop: optic.RayAimingEnabled).Values;
        var expectedCentroid = DiffractionEngine.ComputeHuygensPsf(optic, (0, field), wavelength, sampling, size, pitch,
            aimAtStop: optic.RayAimingEnabled, imageCenterOffset: offset).Values;
        var geometricChief = ImageSimulationEngine.GenerateBasis(optic, wavelength,
            Config(mode: "Geometric", reference: "chief", fieldY: field, psfSize: size, pitch: pitch, rays: sampling));
        var geometricCentroid = ImageSimulationEngine.GenerateBasis(optic, wavelength,
            Config(mode: "Geometric", reference: "centroid", fieldY: field, psfSize: size, pitch: pitch, rays: sampling));
        Normalize(expectedChief);
        Normalize(expectedCentroid);
        results.Add(new { Field = field, ChiefModes = chief.EffectiveModes, CentroidModes = centroid.EffectiveModes,
            ChiefFallback = chief.GeometricFallbackCount, CentroidFallback = centroid.GeometricFallbackCount,
            CentroidOffsetMm = new[] { offset.X, offset.Y }, OffsetPixels = double.Hypot(offset.X, offset.Y) / pitch,
            ActualReferenceDifference = Difference(chief.MeanPsf, centroid.MeanPsf),
            GeometricReferenceControlDifference = Difference(geometricChief.MeanPsf, geometricCentroid.MeanPsf),
            ExpectedReferenceDifference = Difference(expectedChief, expectedCentroid),
            ChiefVsExpected = Difference(chief.MeanPsf, expectedChief),
            CentroidVsExpected = Difference(centroid.MeanPsf, expectedCentroid) });
    }
    return results;
});

Run("perfect-geometric-psf-alignment", () =>
{
    var optic = ThinLens();
    var wave = new Wavelength { Nanometers = 550, IsPrimary = true };
    var results = new List<object>();
    foreach (var size in new[] { 7, 8, 9, 16 })
    {
        var geoConfig = Config(mode: "Geometric", psfSize: size, pitch: .01);
        var noneConfig = Config(mode: "None", psfSize: size, pitch: .01);
        var basis = ImageSimulationEngine.GenerateBasis(optic, wave, geoConfig);
        var sum = basis.MeanPsf.Cast<double>().Sum();
        double xCenter = 0, yCenter = 0;
        for (var y = 0; y < size; y++)
            for (var x = 0; x < size; x++)
            {
                xCenter += x * basis.MeanPsf[y, x] / sum;
                yCenter += y * basis.MeanPsf[y, x] / sum;
            }
        var uniform = new RgbImage(new double[1, 16, 16]);
        for (var y = 0; y < 16; y++)
            for (var x = 0; x < 16; x++) uniform.Values[0, y, x] = 1;
        var geoImage = ImageSimulationEngine.Simulate(optic, uniform, geoConfig);
        var noneImage = ImageSimulationEngine.Simulate(optic, uniform, noneConfig);
        var whitePlane = new double[16, 16];
        for (var y = 0; y < 16; y++)
            for (var x = 0; x < 16; x++) whitePlane[y, x] = 1;
        var convolved = ImageSimulationEngine.SpatiallyVariableConvolution(whitePlane, basis.EigenPsfs,
            ImageSimulationEngine.ResizeCoefficientMaps(basis.CoefficientGrid, 16, 16), basis.MeanPsf);
        var spotRadii = new List<double>();
        foreach (var (px, py) in new[] { (0d, 0d), (.5, .5), (-.5, .5), (.7, 0), (0, -.8) })
        {
            var ray = optic.TraceGenericFinalSample(0, 0, px, py, .55)!;
            spotRadii.Add(double.Hypot(ray.Position.X, ray.Position.Y));
        }
        results.Add(new { Size = size, PsfCenterPixels = new[] { xCenter, yCenter },
            ConvolutionAnchor = (size - 1) / 2, MaximumSpotRadiusMm = spotRadii.Max(),
            GeometricMinimum = geoImage.Simulated.Values.Cast<double>().Min(),
            MinimumBeforeDistortion = convolved.Cast<double>().Min(),
            NoneMinimum = noneImage.Simulated.Values.Cast<double>().Min(),
            ImageDifference = Difference(geoImage.Simulated.Values, noneImage.Simulated.Values) });
    }
    return results;
});

Run("joint-optic-frame-rotation", () =>
{
    var reference = Cone();
    var original = ImageSimulationEngine.Simulate(reference, Source(), Config());
    var results = new List<object>();
    foreach (var degrees in new[] { 15d, 30, 45, 60, 90 })
    {
        var optic = Cone();
        foreach (var surface in optic.SurfaceGroup.Items)
            surface.CoordinateSystem = surface.CoordinateSystem with { RotationZDegrees = degrees };
        double localChiefError = 0, localDirectionError = 0, minimumChiefIntensity = double.PositiveInfinity;
        foreach (var (hx, hy) in new[] { (.2, .3), (-.2, .1), (.5, -.6), (0d, 0d) })
        {
            var oldRay = reference.TraceGenericFinalSample(hx, hy, 0, 0, .55)!;
            var newRay = optic.TraceGenericFinalSample(hx, hy, 0, 0, .55)!;
            var oldLocal = reference.SurfaceGroup.Items[^1].CoordinateSystem.ToLocalPoint(oldRay.Position);
            var newLocal = optic.SurfaceGroup.Items[^1].CoordinateSystem.ToLocalPoint(newRay.Position);
            localChiefError = Math.Max(localChiefError, (oldLocal - newLocal).Length);
            localDirectionError = Math.Max(localDirectionError,
                (reference.SurfaceGroup.Items[^1].CoordinateSystem.ToLocalDirection(oldRay.Direction)
                - optic.SurfaceGroup.Items[^1].CoordinateSystem.ToLocalDirection(newRay.Direction)).Length);
            minimumChiefIntensity = Math.Min(minimumChiefIntensity, Math.Min(oldRay.Intensity, newRay.Intensity));
        }
        var result = ImageSimulationEngine.Simulate(optic, Source(), Config());
        results.Add(new { Degrees = degrees, MaximumLocalChiefPositionErrorMm = localChiefError,
            MaximumLocalChiefDirectionError = localDirectionError, MinimumChiefIntensity = minimumChiefIntensity,
            MaximumImageDifference = Difference(original.Simulated.Values, result.Simulated.Values),
            BlackPixels = result.Simulated.Values.Cast<double>().Count(value => value <= 1e-15),
            OriginalBlackPixels = original.Simulated.Values.Cast<double>().Count(value => value <= 1e-15) });
    }
    return results;
});

Run("output-pixel-size-control", () =>
{
    var a = ImageSimulationEngine.Simulate(Cone(), Source(), Config(pitch: .001));
    var b = ImageSimulationEngine.Simulate(Cone(), Source(), Config(pitch: 1));
    return new { Difference = Difference(a.Simulated.Values, b.Simulated.Values), a.Simulated.Width, a.Simulated.Height };
});

var output = Path.Combine(evidenceDirectory, "results.jsonl");
File.WriteAllLines(output, records);
Console.WriteLine(JsonSerializer.Serialize(new { Evidence = output, CoreAssembly = typeof(Optic).Assembly.Location }));

void Run(string name, Func<object> action)
{
    string record;
    var watch = System.Diagnostics.Stopwatch.StartNew();
    try { record = JsonSerializer.Serialize(new { Name = name, Result = action(), Milliseconds = watch.ElapsedMilliseconds }); }
    catch (Exception e) { record = JsonSerializer.Serialize(new { Name = name, Error = e.ToString(), Milliseconds = watch.ElapsedMilliseconds }); }
    records.Add(record);
    Console.WriteLine(record);
}

static Optic Primary() => OpticalFormatCatalog.Import(File.ReadAllText(
    "artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX"), ".zmx");

static Optic Cone()
{
    var optic = new Optic { FieldDefinition = FieldDefinitionKind.ObjectHeight };
    optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint { Y = 2 });
    optic.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = 10 },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = 2 },
        new OpticalSurface { Thickness = 8 },
        new OpticalSurface()
    ]);
    return optic;
}

static Optic ThinLens()
{
    var optic = new Optic { FieldDefinition = FieldDefinitionKind.Angle };
    optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint { Y = 1 });
    optic.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = double.PositiveInfinity },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = 10, InteractionModel = new ThinLensInteractionModel(10) },
        new OpticalSurface()
    ]);
    return optic;
}

static RgbImage Source()
{
    var values = new double[1, 16, 16];
    for (var y = 0; y < 16; y++)
        for (var x = 0; x < 16; x++) values[0, y, x] = .1 + .5 * x / 15 + .3 * y / 15;
    return new(values);
}

static ImageSimulationConfig Config(string mode = "None", string reference = "chief", double fieldY = 0,
    int psfSize = 8, double pitch = .01, int rays = 8) => new()
{
    ImageWidth = 16, ImageHeight = 16, Padding = 0, WavelengthsMicrometers = [.55],
    PsfGridRows = 1, PsfGridColumns = 1, PsfSize = psfSize, NumRays = rays, Components = 1,
    PixelSizeMillimeters = pitch, FieldHeight = mode == "Diffraction" ? 1e-8 : 1,
    FieldCenterY = fieldY, Reference = reference, AberrationMode = mode,
    UseRelativeIllumination = false, DistortionGridSize = 9, DistortionPolynomialDegree = 1
};

static double Difference(Array a, Array b) => a.Cast<double>().Zip(b.Cast<double>(), (x, y) => Math.Abs(x - y)).Max();
static void Normalize(double[,] values)
{
    var sum = values.Cast<double>().Sum();
    for (var y = 0; y < values.GetLength(0); y++)
        for (var x = 0; x < values.GetLength(1); x++) values[y, x] /= sum;
}
