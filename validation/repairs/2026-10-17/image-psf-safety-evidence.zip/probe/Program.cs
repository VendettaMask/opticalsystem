using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Interactions;

if (args.Length != 1 || !args[0].EndsWith(".json")) throw new ArgumentException("One JSON output path is required.");
var optic = OpticalFormatCatalog.Import(File.ReadAllText("artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX"), ".zmx");
optic.FieldDefinition = FieldDefinitionKind.ParaxialImageHeight;
var config = new ImageSimulationConfig {
    ImageWidth = 65, ImageHeight = 65, Padding = 0, WavelengthsMicrometers = [.55],
    PsfGridRows = 3, PsfGridColumns = 3, PsfSize = 33, NumRays = 12, Components = 3,
    PixelSizeMillimeters = .01, AberrationMode = "Geometric", UseRelativeIllumination = false,
    DistortionGridSize = 5, DistortionPolynomialDegree = 1
};
var wave = new Wavelength { Nanometers = 550 };
var basis = ImageSimulationEngine.GenerateBasis(optic, wave, config);
var input = new double[65, 65]; input[64, 64] = 1;
var maps = ImageSimulationEngine.ResizeCoefficientMaps(basis.CoefficientGrid, 65, 65);
var raw = ImageSimulationEngine.SpatiallyVariableConvolution(input, basis.EigenPsfs, maps, basis.MeanPsf);
var corrected = ImageSimulationEngine.ConvolvePsfIntensity(input, basis.EigenPsfs, maps, basis.MeanPsf);
var grid = ImageSimulationEngine.GenerateDistortionGrid(optic, wave, 65, 65, 5, 1,
    referenceWavelength: optic.Wavelengths.First(w => w.IsPrimary));
var rawWarp = ImageSimulationEngine.WarpImage(raw, grid);
var correctedWarp = ImageSimulationEngine.WarpImage(corrected.Values, grid);
var source = new double[1, 65, 65]; source[0, 64, 64] = 1;
var actual = ImageSimulationEngine.Simulate(optic, new RgbImage(source), config);
var point = new double[1, 5]; point[0, 2] = 1;
var syntheticMaps = new double[1, 1, 5]; syntheticMaps[0, 0, 2] = 1;
var synthetic = ImageSimulationEngine.ConvolvePsfIntensity(point,
    [new double[,] { { -.2, .2, 0 } }], syntheticMaps, new double[,] { { 0, .8, .2 } });
var extended = new ExtendedDiffractionImageAnalysis(ThinLens(12), imageSize: 16, pupilSampling: 8,
    fieldGrid: 3, guardBand: 0, relativeIllumination: false).GenerateData();
var rotations = new List<object>();
foreach (var dimensions in new[] { (16, 256), (256, 16) })
{
    var image = new RgbImage(new double[1, dimensions.Item2, dimensions.Item1]);
    var rotationConfig = new ImageSimulationConfig {
        SourceRotationDegrees = 90, OutputHeight = 2048, Padding = 0, WavelengthsMicrometers = [.55],
        PsfGridRows = 1, PsfGridColumns = 1, PsfSize = 1, NumRays = 2, Components = 1,
        PixelSizeMillimeters = .01, FieldHeight = 1, AberrationMode = "None",
        UseRelativeIllumination = false, DistortionGridSize = 5, DistortionPolynomialDegree = 1
    };
    string? rejection = null; ImageSimulationResult? result = null;
    try { result = ImageSimulationEngine.Simulate(ThinLens(10), image, rotationConfig); }
    catch (ArgumentOutOfRangeException exception) { rejection = exception.Message; }
    rotations.Add(new { SourceWidth = image.Width, SourceHeight = image.Height, Rejection = rejection,
        ActualWidth = result?.Simulated.Width, ActualHeight = result?.Simulated.Height });
}
var corePath = typeof(Optic).Assembly.Location;
var record = new {
    Date = "2026-10-17", CorePath = corePath,
    CoreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(corePath))).ToLowerInvariant(),
    Psf = new {
        LegacySignedWarpMinimum = rawWarp.Cast<double>().Min(),
        LegacySignedWarpPower = rawWarp.Cast<double>().Sum(),
        LegacyFinalClampedPower = rawWarp.Cast<double>().Select(v => Math.Max(0, v)).Sum(),
        CorrectedWarpMinimum = correctedWarp.Cast<double>().Min(),
        CorrectedWarpPower = correctedWarp.Cast<double>().Sum(),
        ActualMinimum = actual.Simulated.Values.Cast<double>().Min(),
        ActualPower = actual.Simulated.Values.Cast<double>().Sum(),
        CorrectedVsActualMaximumDifference = correctedWarp.Cast<double>()
            .Zip(actual.Simulated.Values.Cast<double>(), (a,b) => Math.Abs(a-b)).Max(),
        actual.PsfIntensityCorrectionCount, actual.MaximumPsfNegativeMass,
        actual.GeometricFallbackCount, UnitPointPower = synthetic.Values.Cast<double>().Sum(),
        UnitPointMinimum = synthetic.Values.Cast<double>().Min()
    },
    ExtendedDiffraction = extended.Values, Rotations = rotations
};
File.WriteAllText(args[0], JsonSerializer.Serialize(record, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Recorded repair controls: {args[0]}");

static Optic ThinLens(double distance)
{
    var lens = new Optic { FieldDefinition = FieldDefinitionKind.Angle };
    lens.Aperture.Value = 2; lens.Fields.Add(new FieldPoint { Y = 1 });
    lens.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    lens.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = double.PositiveInfinity },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = distance,
            InteractionModel = new ThinLensInteractionModel(10) }, new OpticalSurface()
    ]);
    return lens;
}
