using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
var records = new List<object>();
foreach (var rays in new[] { 2, 4 })
foreach (var analysis in new BaseAnalysis[] {
    new GeometricImageAnalysis(Optic.CreateCookeTriplet(), imageSize: 16, numRays: rays, relativeIllumination: rays == 2),
    new GeometricBitmapImageAnalysis(Optic.CreateCookeTriplet(), imageSize: 16, raysPerPixel: rays, relativeIllumination: rays == 2)
})
{
    var data = analysis.GenerateData();
    records.Add(new { Rays = rays, analysis.Name, Outcome = data.Outcome.ToString(), data.OutcomeReason, data.Values,
        Panes = data.PlotPanes?.Count });
    Console.WriteLine($"{rays} {analysis.Name}: {data.Outcome} {data.OutcomeReason}");
}
var core = typeof(Optic).Assembly.Location;
File.WriteAllText(args[0], JsonSerializer.Serialize(new {
    CoreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(), Records = records
}, new JsonSerializerOptions { WriteIndented = true }));
