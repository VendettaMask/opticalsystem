$ErrorActionPreference = 'Stop'
$taskRepo = 'D:\Projects\opticalsystem'
Set-Location -LiteralPath $taskRepo
$taskDirectory = 'artifacts/validation/image-psf-safety-repair-20261017'
function Read-TestRun([string]$taskPath) {
    [xml]$taskXml = Get-Content -LiteralPath $taskPath -Raw
    $taskCounters = $taskXml.TestRun.ResultSummary.Counters
    [pscustomobject]@{
        path = $taskPath; total = [int]$taskCounters.total; passed = [int]$taskCounters.passed
        failed = [int]$taskCounters.failed; notExecuted = [int]$taskCounters.notExecuted
        names = @($taskXml.TestRun.Results.UnitTestResult | ForEach-Object { $_.testName } | Sort-Object)
        newTests = @($taskXml.TestRun.Results.UnitTestResult | Where-Object testName -Like '*ImagePsfSafetyRepairTests*').Count
    }
}
$taskBefore = Read-TestRun "$taskDirectory/before/before.trx"
$taskRelease = Read-TestRun "$taskDirectory/final/related-release-v2.trx"
$taskDebug = Read-TestRun "$taskDirectory/final/related-debug-v2.trx"
if ($taskBefore.total -ne 10 -or $taskBefore.failed -ne 10) { throw 'Missing original failure controls' }
foreach ($taskRun in @($taskRelease, $taskDebug)) {
    if ($taskRun.total -ne $taskRun.passed -or $taskRun.failed -ne 0 -or $taskRun.notExecuted -ne 0 -or $taskRun.newTests -ne 34) {
        throw "Incomplete final regression: $($taskRun.path)"
    }
}
if (($taskRelease.names -join "`n") -cne ($taskDebug.names -join "`n")) { throw 'Final test names differ' }
$taskControlsR = Get-Content "$taskDirectory/controls-release.json" -Raw | ConvertFrom-Json
$taskControlsD = Get-Content "$taskDirectory/controls-debug.json" -Raw | ConvertFrom-Json
foreach ($taskName in @('Psf','ExtendedDiffraction','Rotations')) {
    if (($taskControlsR.$taskName | ConvertTo-Json -Depth 20 -Compress) -cne ($taskControlsD.$taskName | ConvertTo-Json -Depth 20 -Compress)) {
        throw "Repair control differs: $taskName"
    }
}
if ($taskControlsR.Psf.ActualMinimum -lt 0 -or $taskControlsR.Psf.UnitPointPower -ne 1 -or
    $taskControlsR.Psf.CorrectedVsActualMaximumDifference -ne 0 -or
    $taskControlsR.ExtendedDiffraction.GeometricFallbackCount -ne 27 -or
    $taskControlsR.ExtendedDiffraction.AberrationMode -ne 'Geometric' -or
    -not $taskControlsR.Rotations[0].Rejection -or $taskControlsR.Rotations[1].ActualWidth -ne 16) {
    throw 'Repair control not satisfied'
}
$taskOldEvidence = @{
    'validation/repairs/2026-10-17/product-image-audit-evidence.zip' = '252b9e2c236698a57130e82da28aba409fff10403fa5ff061d3e33f63b7aedd9'
    'validation/repairs/2026-10-16/illumination-inverse-evidence.zip' = 'bcd5df8b59d0e7437c906503e4b4cbfc514fbe032f09f90595236a845c2657bb'
    'validation/repairs/2026-10-16/illumination-finite-grid-evidence.zip' = 'a137625a22a2e7e333f637b17e2117b3602569add648b60445e09f8782d3e83d'
    'validation/repairs/2026-10-16/native-diffraction-adapter-evidence.zip' = 'e452e029523ac4c2a0f806a07fe3a4a05920371ff797a04de4d503e81bfc2a6c'
    'artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX' = '0cd65a2f823baf5079f20f91d8310765899a182a6be72ddac53ede943f2bf75b'
}
foreach ($taskPath in $taskOldEvidence.Keys) {
    if ((Get-FileHash $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskOldEvidence[$taskPath]) {
        throw "Preserved evidence changed: $taskPath"
    }
}
$taskConfigurations = foreach ($taskConfiguration in @('Debug','Release')) {
    $taskCore = "src/OpticalSystemDesign.Core/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll"
    $taskCoreHash = (Get-FileHash $taskCore -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskCopies = @("src/OpticalSystemDesign.App/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll",
        "tests/OpticalSystemDesign.Tests/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll")
    foreach ($taskCopy in $taskCopies) {
        if ((Get-FileHash $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskCoreHash) { throw "Core copy mismatch: $taskCopy" }
    }
    $taskControlHash = if ($taskConfiguration -eq 'Debug') { $taskControlsD.CoreSha256 } else { $taskControlsR.CoreSha256 }
    if ($taskControlHash -ne $taskCoreHash) { throw 'Probe did not use default Core' }
    $taskBuildLog = Get-Content "$taskDirectory/build-$($taskConfiguration.ToLowerInvariant())-v2.log" -Raw
    $taskProjects = @([regex]::Matches($taskBuildLog, '(?m)^\s+(\S+) -> ') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
    if ($taskProjects.Count -ne 19 -or $taskBuildLog -notmatch '0 个警告' -or $taskBuildLog -notmatch '0 个错误') { throw 'Incomplete root build' }
    [ordered]@{ configuration = $taskConfiguration; projects = $taskProjects; projectCount = 19
        warnings = 0; errors = 0; corePath = $taskCore; coreSha256 = $taskCoreHash; matchingCopies = $taskCopies }
}
$taskCodeFiles = @((git diff --name-only -- '*.cs'), (git ls-files --others --exclude-standard -- '*.cs')) |
    ForEach-Object { $_ } | Sort-Object -Unique
$taskCode = foreach ($taskPath in $taskCodeFiles) {
    [ordered]@{ path = $taskPath; sha256 = (Get-FileHash $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$taskProof = [ordered]@{
    date = '2026-10-17'; sourceBaseCommit = (git rev-parse HEAD).Trim(); status = 'IMG01 IMG02 IMG03 repaired and verified'
    sourceFiles = @($taskCode); configurations = @($taskConfigurations)
    tests = [ordered]@{ before = $taskBefore; finalRelease = $taskRelease; finalDebug = $taskDebug
        sameFinalNames = $true; newCases = 36; psfSafetyClassCases = 34; retainedCoarseInputRejectionCases = 2
        focusedFirstStage = 'focused/focused-release.trx: 33/33, not added to final counts'
        firstRelatedRelease = '228 total, 227 passed, 1 failed: existing renderability smoke expected a raster for an empty coarse PSF'
        firstRelatedDebug = 'Interrupted after the same pre-existing bad assertion was isolated; not a passing run' }
    renderabilityInputAudit = [ordered]@{
        old = (Get-Content "$taskDirectory/compatibility-old.json" -Raw | ConvertFrom-Json)
        current = (Get-Content "$taskDirectory/compatibility-new.json" -Raw | ConvertFrom-Json)
        decision = 'Keep original density-2 rejection cases. Use density 4 and omit unrelated illumination integration in the renderability smoke. Physical illumination has separate regressions.'
    }
    controlsEqualAcrossConfigurations = $true; controls = $taskControlsR
    preservedEvidence = $taskOldEvidence
    stillOpen = @('IMG04 guard-band physical sampling','IMG05 output statistics','IMG06 partially coherent propagation')
    scope = [ordered]@{ nativeCapture = $false; fullSuite = $false; installerRebuilt = $false
        committed = $false; pushed = $false; independentCookeTessar = 'Excluded' }
}
$taskProof | ConvertTo-Json -Depth 40 | Set-Content "$taskDirectory/proof.json" -Encoding utf8
$taskFiles = [ordered]@{}
foreach ($taskRelative in @('before/before.trx','focused/focused-release.trx','final/related-release.trx',
    'final/related-debug.trx','final/related-release-v2.trx','final/related-debug-v2.trx',
    'build-release.log','build-debug.log','build-release-v2.log','build-debug-v2.log',
    'related-release.log','related-debug.log','related-release-v2.log','related-debug-v2.log',
    'related-filter.txt','controls-release.json','controls-debug.json','probe/Program.cs','probe/RepairProbe.csproj',
    'compatibility/Program.cs','compatibility/Compatibility.csproj','compatibility-old.json','compatibility-new.json',
    'proof.json','create-evidence.ps1')) { $taskFiles[$taskRelative] = "$taskDirectory/$taskRelative" }
foreach ($taskPath in $taskCodeFiles) { $taskFiles["source/$taskPath"] = $taskPath }
$taskFiles['docs/IMAGE_PSF_SAFETY_REPAIR_2026-10-17.md'] = 'docs/IMAGE_PSF_SAFETY_REPAIR_2026-10-17.md'
$taskArchivePath = 'validation/repairs/2026-10-17/image-psf-safety-evidence.zip'
if (Test-Path $taskArchivePath) { throw 'Evidence archive already exists; preserve its bytes' }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$taskArchive = [IO.Compression.ZipFile]::Open((Join-Path $taskRepo $taskArchivePath), [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($taskEntryName in $taskFiles.Keys) {
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskArchive,
            (Join-Path $taskRepo $taskFiles[$taskEntryName]), $taskEntryName,
            [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $taskArchive.Dispose() }
$taskReadback = [IO.Compression.ZipFile]::OpenRead((Join-Path $taskRepo $taskArchivePath))
try {
    $taskCatalog = foreach ($taskEntry in $taskReadback.Entries) {
        $taskStream = $taskEntry.Open(); $taskHasher = [Security.Cryptography.SHA256]::Create()
        try { $taskHash = [BitConverter]::ToString($taskHasher.ComputeHash($taskStream)).Replace('-','').ToLowerInvariant() }
        finally { $taskStream.Dispose(); $taskHasher.Dispose() }
        if ($taskHash -ne (Get-FileHash $taskFiles[$taskEntry.FullName] -Algorithm SHA256).Hash.ToLowerInvariant()) {
            throw "Archive bytes changed: $($taskEntry.FullName)"
        }
        [ordered]@{ path = $taskEntry.FullName; bytes = $taskEntry.Length; sha256 = $taskHash }
    }
} finally { $taskReadback.Dispose() }
$taskLedger = [ordered]@{
    date = '2026-10-17'; status = 'IMG01 IMG02 IMG03 closed within image software scope'
    proof = $taskProof; evidence = [ordered]@{
        path = $taskArchivePath; bytes = (Get-Item $taskArchivePath).Length
        sha256 = (Get-FileHash $taskArchivePath -Algorithm SHA256).Hash.ToLowerInvariant()
        entries = @($taskCatalog); allEntriesReadbackVerified = $true
    }
}
$taskLedger | ConvertTo-Json -Depth 40 | Set-Content docs/validation/IMAGE_PSF_SAFETY_REPAIR_2026-10-17.json -Encoding utf8
Write-Output "Final same-name Debug/Release: $($taskRelease.passed)/$($taskRelease.total); new cases: 36; archive entries: $($taskCatalog.Count)"
Write-Output "Evidence SHA-256: $($taskLedger.evidence.sha256)"
