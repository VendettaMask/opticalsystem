$ErrorActionPreference = 'Stop'
$taskRepo = 'D:\Projects\opticalsystem'
Set-Location -LiteralPath $taskRepo
$taskAuditDirectory = 'artifacts/validation/product-audit-20261017'
$taskRelease = Get-Content "$taskAuditDirectory/observations-release.json" -Raw | ConvertFrom-Json
$taskDebug = Get-Content "$taskAuditDirectory/observations-debug.json" -Raw | ConvertFrom-Json
if ($taskRelease.Records.Count -ne 7 -or $taskDebug.Records.Count -ne 7) { throw 'Incomplete diagnostic records' }
$taskComparison = foreach ($taskRecord in $taskRelease.Records) {
    $taskOther = $taskDebug.Records | Where-Object Name -eq $taskRecord.Name
    if ($taskRecord.Status -ne 'Observed' -or $taskOther.Status -ne 'Observed') { throw "Incomplete group $($taskRecord.Name)" }
    $taskEqual = ($taskRecord.Values | ConvertTo-Json -Depth 40 -Compress) -ceq ($taskOther.Values | ConvertTo-Json -Depth 40 -Compress)
    if (-not $taskEqual) { throw "Configuration discrepancy: $($taskRecord.Name)" }
    [ordered]@{ name = $taskRecord.Name; debug = 'Reproduced'; release = 'Reproduced'; observationValuesEqual = $taskEqual }
}
$taskProductChanges = @(git diff --name-only HEAD -- src tests)
if ($LASTEXITCODE -ne 0 -or $taskProductChanges.Count -ne 0) { throw 'Product code changed during read-only audit' }
$taskBase = (git rev-parse HEAD).Trim()
if ($taskBase -ne 'cfcf7aeadb9c359fd18b8f2862527c29af8bf348') { throw 'Unexpected audit source commit' }
$taskLens = 'artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX'
$taskLensHash = (Get-FileHash $taskLens -Algorithm SHA256).Hash.ToLowerInvariant()
if ($taskLensHash -ne '0cd65a2f823baf5079f20f91d8310765899a182a6be72ddac53ede943f2bf75b') { throw 'Baseline identity changed' }
$taskSourcePaths = @(
    'src/OpticalSystemDesign.Core/Analysis/ImageSimulationEngine.cs',
    'src/OpticalSystemDesign.Core/Analysis/AnalysisResourceLimits.cs',
    'src/OpticalSystemDesign.Core/Analysis/Extended/ExtendedSceneImageAnalyses.cs',
    'src/OpticalSystemDesign.Core/Analysis/Extended/ImageAndPolarizationAnalyses.cs',
    'src/OpticalSystemDesign.Core/Analysis/RealImageFieldConversion.cs'
)
$taskSources = foreach ($taskPath in $taskSourcePaths) {
    [ordered]@{ path = $taskPath; sha256 = (Get-FileHash $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$taskAssemblies = foreach ($taskConfiguration in @('Debug','Release')) {
    $taskCore = "src/OpticalSystemDesign.Core/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll"
    $taskAppCore = "src/OpticalSystemDesign.App/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll"
    $taskHash = (Get-FileHash $taskCore -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskHash -ne (Get-FileHash $taskAppCore -Algorithm SHA256).Hash.ToLowerInvariant()) { throw 'App Core differs' }
    $taskRecordedHash = if ($taskConfiguration -eq 'Debug') { $taskDebug.CoreSha256 } else { $taskRelease.CoreSha256 }
    if ($taskHash -ne $taskRecordedHash) { throw 'Diagnostic Core differs' }
    [ordered]@{ configuration = $taskConfiguration; corePath = $taskCore; appCorePath = $taskAppCore; sha256 = $taskHash }
}
$taskProof = [ordered]@{
    date = '2026-10-17'; sourceCommit = $taskBase; status = 'Open defects reproduced; not repaired'
    nativeCapture = $false; productCodeChanged = $false; formalTestsChanged = $false
    rootSolutionRebuilt = $false; fullSuiteRerun = $false; installerRebuilt = $false
    independentCookeTessar = 'Excluded'
    baseline = [ordered]@{ path = $taskLens; sha256 = $taskLensHash }
    sourceFiles = @($taskSources); defaultCoreAssemblies = @($taskAssemblies)
    verification = @($taskComparison)
}
$taskProof | ConvertTo-Json -Depth 40 | Set-Content "$taskAuditDirectory/proof.json" -Encoding utf8
$taskArchivePath = 'validation/repairs/2026-10-17/product-image-audit-evidence.zip'
if (Test-Path -LiteralPath $taskArchivePath) { throw 'Evidence archive already exists; preserve existing bytes' }
New-Item -ItemType Directory -Path (Split-Path $taskArchivePath -Parent) -Force | Out-Null
$taskArchiveFiles = [ordered]@{
    'probe/Program.cs' = "$taskAuditDirectory/probe/Program.cs"
    'probe/IssueAudit.csproj' = "$taskAuditDirectory/probe/IssueAudit.csproj"
    'observations-release.json' = "$taskAuditDirectory/observations-release.json"
    'observations-debug.json' = "$taskAuditDirectory/observations-debug.json"
    'proof.json' = "$taskAuditDirectory/proof.json"
    'record-evidence.ps1' = "$taskAuditDirectory/record-evidence.ps1"
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$taskArchive = [System.IO.Compression.ZipFile]::Open((Join-Path $taskRepo $taskArchivePath), [System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($taskName in $taskArchiveFiles.Keys) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskArchive,
            (Join-Path $taskRepo $taskArchiveFiles[$taskName]), $taskName,
            [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $taskArchive.Dispose() }
$taskReadback = [System.IO.Compression.ZipFile]::OpenRead((Join-Path $taskRepo $taskArchivePath))
try {
    $taskCatalog = foreach ($taskEntry in $taskReadback.Entries) {
        $taskStream = $taskEntry.Open()
        $taskHasher = [System.Security.Cryptography.SHA256]::Create()
        try { $taskHash = [BitConverter]::ToString($taskHasher.ComputeHash($taskStream)).Replace('-','').ToLowerInvariant() }
        finally { $taskStream.Dispose(); $taskHasher.Dispose() }
        $taskExpectedHash = (Get-FileHash $taskArchiveFiles[$taskEntry.FullName] -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($taskHash -ne $taskExpectedHash) { throw "Archive mismatch: $($taskEntry.FullName)" }
        [ordered]@{ path = $taskEntry.FullName; bytes = $taskEntry.Length; sha256 = $taskHash }
    }
} finally { $taskReadback.Dispose() }
$taskFindings = @(
    [ordered]@{ id = 'IMG01'; priority = 'P1'; status = 'Open'; newlyConfirmed = $true; subject = 'Negative EigenPSF intensity and final-clamp power increase'; finalImageClampRelativeIncrease = 0.0030650680493664595; actualVsReplayedMaximumDifference = 0.0; kernelControlPositiveMass = 1.0510316340088868; scope = 'Kernel control and finite edge-source image are separate; no whole-system native equivalence claim' },
    [ordered]@{ id = 'IMG02'; priority = 'P1'; status = 'Open'; newlyConfirmed = $true; subject = 'Extended diffraction hides geometric fallback'; nativeCapture = $false; geometricFallbackPsfCount = 27; engineMode = 'Geometric'; reportedAberrationMode = 'Diffraction' },
    [ordered]@{ id = 'IMG03'; priority = 'P1'; status = 'Open'; newlyConfirmed = $true; subject = 'Rotation/output resource validation mismatch'; acceptedOutputPixels = 524288; configuredPixelLimit = 262144; wronglyRejectedOutputPixels = 32768 },
    [ordered]@{ id = 'IMG04'; priority = 'P2'; status = 'Open'; newlyConfirmed = $true; subject = 'Guard band changes automatic physical sampling'; noGuardRmsPixels = 1.3809317793261022; guard16RmsPixels = 2.614800745476042; fixedPitchControlRmsPixels = 1.3809317793261024 },
    [ordered]@{ id = 'IMG05'; priority = 'P2'; status = 'Open'; newlyConfirmed = $false; subject = 'Displayed image and statistics refer to different stages'; displayedFlippedMeanChange = 0.42666509915708134; reportedMeanChange = 0.000004113920565120043; resizedDisplayedMaximum = 0.0; reportedMaximum = 0.9999961922810465 },
    [ordered]@{ id = 'IMG06'; priority = 'P1'; status = 'Open'; newlyConfirmed = $false; subject = 'Partial coherence is intensity/source blending'; sourceBlendMaximumDifference = 0.0; coherenceOneOutputVsSourceDifference = 0.0; unchangedReportedMeanChange = 0.3585283914577544 }
)
$taskLedger = [ordered]@{
    date = '2026-10-17'; status = 'Six open findings reproduced; no product repair'
    sourceCommit = $taskBase; findings = $taskFindings; proof = $taskProof
    evidence = [ordered]@{
        path = $taskArchivePath; bytes = (Get-Item $taskArchivePath).Length
        sha256 = (Get-FileHash $taskArchivePath -Algorithm SHA256).Hash.ToLowerInvariant()
        entries = @($taskCatalog); allEntriesReadbackVerified = $true
    }
}
$taskLedger | ConvertTo-Json -Depth 40 | Set-Content docs/validation/PRODUCT_IMAGE_AUDIT_2026-10-17.json -Encoding utf8
Write-Output "Seven groups match across Debug/Release. Six findings remain open. Archive SHA-256: $($taskLedger.evidence.sha256)"
