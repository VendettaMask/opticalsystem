using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Interactions;

if (args.Length != 1 || !args[0].EndsWith(".json", StringComparison.OrdinalIgnoreCase))
    throw new ArgumentException("Pass exactly one JSON observation output path.");
var records = new List<object>();
Run("rotation-output-budget", () =>
{
    var controls = new List<object>();
    foreach (var dimensions in new[] { (16, 256), (256, 16) })
    {
        var source = Source(dimensions.Item1, dimensions.Item2);
        var config = Config(rotation: 90, outputHeight: 2048);
        var expectedWidth = source.Height;
        var expectedHeight = config.OutputHeight;
        string? rejection = null;
        try { AnalysisResourceLimits.ValidateImageSimulation(source, config); }
        catch (ArgumentException exception) { rejection = exception.Message; }
        ImageSimulationResult? result = rejection is null
            ? ImageSimulationEngine.Simulate(ThinLens(), source, config) : null;
        controls.Add(new { SourceWidth = source.Width, SourceHeight = source.Height,
            RotationDegrees = 90, ExpectedWidth = expectedWidth, ExpectedHeight = expectedHeight,
            ExpectedPixels = (long)expectedWidth * expectedHeight,
            Limit = AnalysisResourceLimits.MaximumImagePixels, Rejection = rejection,
            ActualWidth = result?.Simulated.Width, ActualHeight = result?.Simulated.Height });
    }
    return controls;
});
Run("display-statistics", () =>
{
    var source = Source(16, 16);
    var flipped = ImageSimulationEngine.Simulate(ThinLens(), source, Config(flip: "Horizontal"));
    var impulse = Source(16, 16, impulse: true);
    var reduced = ImageSimulationEngine.Simulate(ThinLens(), impulse, Config(outputWidth: 1, outputHeight: 1));
    return new {
        Flip = new { flipped.MeanAbsoluteChange, DisplayedMeanAbsoluteChange = MeanDifference(flipped.Source, flipped.Simulated),
            flipped.MaximumValue, DisplayedMaximum = flipped.Simulated.Values.Cast<double>().Max() },
        Downsample = new { reduced.MeanAbsoluteChange, DisplayedMeanAbsoluteChange = MeanDifference(reduced.Source, reduced.Simulated),
            reduced.MaximumValue, DisplayedMaximum = reduced.Simulated.Values.Cast<double>().Max(),
            Width = reduced.Simulated.Width, Height = reduced.Simulated.Height }
    };
});
Run("partial-coherence", () =>
{
    var data = new[] { 0d, .5, 1 }.Select(coherence => new PartiallyCoherentImageAnalysis(
        Primary(), imageSize: 16, pupilSampling: 4, coherence: coherence, guardBand: 0,
        fieldHeight: 1, relativeIllumination: false).GenerateData()).ToArray();
    var source = RasterValues(data[0], 0);
    var blurred = RasterValues(data[0], 1);
    return data.Select((item, index) => new {
        Coherence = new[] { 0d, .5, 1 }[index], ReportedMeanAbsoluteChange = item.Values["MeanAbsoluteChange"],
        DisplayedMeanAbsoluteChange = source.Zip(RasterValues(item, 1), (a, b) => Math.Abs(a - b)).Average(),
        DifferenceFromArithmeticBlend = source.Zip(blurred, (s, b) => index == 0 ? b : index == 1 ? .5 * s + .5 * b : s)
            .Zip(RasterValues(item, 1), (a, b) => Math.Abs(a - b)).Max(),
        item.Values
    }).ToArray();
});
Run("guard-band-scale", () =>
{
    var controls = new List<object>();
    foreach (var pitch in new[] { 0d, .0057 })
    {
        foreach (var padding in new[] { 0, 16 })
        {
            var result = ImageSimulationEngine.Simulate(ThinLens(10.1), Source(32, 32, impulse: true),
                Config(mode: "Geometric", size: 17, rays: 16, padding: padding, pitch: pitch));
            controls.Add(new { PixelPitch = pitch, Padding = padding,
                Width = result.Simulated.Width, Height = result.Simulated.Height,
                Moment = Moment(result.Simulated), result.EffectiveAberrationMode });
        }
    }
    return controls;
});
Run("eigen-psf-negative-power", () =>
{
    var controls = new List<object>();
    foreach (var pitch in new[] { .002, .005, .01, .02, .05 })
    {
        var optic = Primary();
        var config = Config(mode: "Geometric", size: 33, rays: 12, rows: 3, columns: 3,
            components: 3, pitch: pitch, fieldHeight: 0);
        var basis = ImageSimulationEngine.GenerateBasis(optic, optic.Wavelengths.First(w => w.IsPrimary), config);
        for (var row = 0; row < 3; row++)
        {
            for (var column = 0; column < 3; column++)
            {
                var kernel = (double[,])basis.MeanPsf.Clone();
                for (var y = 0; y < 33; y++)
                    for (var x = 0; x < 33; x++)
                        for (var component = 0; component < basis.EigenPsfs.Length; component++)
                            kernel[y, x] += basis.EigenPsfs[component][y, x] * basis.CoefficientGrid[component, row, column];
                var values = kernel.Cast<double>().ToArray();
                var maps = new double[basis.EigenPsfs.Length, 65, 65];
                for (var component = 0; component < basis.EigenPsfs.Length; component++)
                    for (var y = 0; y < 65; y++)
                        for (var x = 0; x < 65; x++) maps[component, y, x] = basis.CoefficientGrid[component, row, column];
                var impulse = new double[65, 65]; impulse[32, 32] = 1;
                var response = ImageSimulationEngine.SpatiallyVariableConvolution(impulse, basis.EigenPsfs, maps, basis.MeanPsf);
                controls.Add(new { PixelPitch = pitch, Row = row, Column = column,
                    Minimum = values.Min(), NegativeMass = -values.Where(v => v < 0).Sum(),
                    SignedMass = values.Sum(), ClippedMass = values.Where(v => v > 0).Sum(),
                    ConvolutionMinimum = response.Cast<double>().Min(),
                    ConvolutionSignedMass = response.Cast<double>().Sum(),
                    ConvolutionClippedMass = response.Cast<double>().Where(v => v > 0).Sum() });
            }
        }
    }
    return controls;
});
Run("extended-diffraction-mode-reporting", () =>
{
    var optic = ThinLens(12);
    var data = new ExtendedDiffractionImageAnalysis(optic, imageSize: 16, pupilSampling: 8,
        fieldGrid: 3, guardBand: 0, relativeIllumination: false).GenerateData();
    var config = new ImageSimulationConfig {
        ImageWidth = 16, ImageHeight = 16, NumRays = 8, PsfSize = 32,
        PsfGridRows = 3, PsfGridColumns = 3, Components = 3, Padding = 0,
        DistortionGridSize = 7, DistortionPolynomialDegree = 5, UseRelativeIllumination = false,
        AberrationMode = "Diffraction"
    };
    var engine = ImageSimulationEngine.Simulate(optic,
        ImageSimulationEngine.CreateSourceImage(ImageSimulationSourcePattern.ResolutionTarget, 16, 16), config);
    return new { ExtendedValues = data.Values, EngineMode = engine.EffectiveAberrationMode,
        engine.GeometricFallbackCount,
        HasMode = data.Values.ContainsKey("EffectiveAberrationMode"),
        HasFallbackCount = data.Values.ContainsKey("GeometricFallbackCount") };
});
Run("eigen-psf-end-to-end", () =>
{
    var optic = Primary();
    // Match the formal Simulate preparation, retaining its current field contract.
    optic.FieldDefinition = FieldDefinitionKind.ParaxialImageHeight;
    double minimum = 0, selectedWave = 0, selectedPitch = 0;
    int selectedX = 0, selectedY = 0, selectedComponents = 0;
    ImageSimulationConfig? selectedConfig = null;
    PsfBasisResult? selectedBasis = null;
    var candidates = new List<object>();
    foreach (var wavelength in new[] { .42, .55, .65 })
    foreach (var pitch in new[] { .002, .005, .01, .02 })
    foreach (var components in new[] { 1, 3 })
    {
        var candidateConfig = Config(mode: "Geometric", size: 33, rays: 12, rows: 3,
            columns: 3, components: components, pitch: pitch, fieldHeight: 0, wave: wavelength);
        var candidateBasis = ImageSimulationEngine.GenerateBasis(optic,
            new Wavelength { Nanometers = 1000 * wavelength }, candidateConfig);
        var candidateMaps = ImageSimulationEngine.ResizeCoefficientMaps(candidateBasis.CoefficientGrid, 65, 65);
        var candidateMinimum = 0d;
        foreach (var py in new[] { 0, 8, 16, 32, 48, 56, 64 })
        foreach (var px in new[] { 0, 8, 16, 32, 48, 56, 64 })
        for (var y = 0; y < 33; y++) for (var x = 0; x < 33; x++)
        {
            if (py + y - 16 is < 0 or >= 65 || px + x - 16 is < 0 or >= 65) continue;
            var value = candidateBasis.MeanPsf[y, x];
            for (var component = 0; component < candidateBasis.EigenPsfs.Length; component++)
                value += candidateBasis.EigenPsfs[component][y, x] * candidateMaps[component, py, px];
            candidateMinimum = Math.Min(candidateMinimum, value);
            if (value < minimum)
            {
                minimum = value; selectedWave = wavelength; selectedPitch = pitch;
                selectedX = px; selectedY = py; selectedComponents = components;
                selectedConfig = candidateConfig; selectedBasis = candidateBasis;
            }
        }
        candidates.Add(new { Wavelength = wavelength, PixelPitch = pitch, Components = components,
            Minimum = candidateMinimum });
    }
    if (selectedConfig is null || selectedBasis is null)
        return new { Status = "No negative formal-pipeline candidate", Candidates = candidates };
    var wave = new Wavelength { Nanometers = 1000 * selectedWave };
    var input = new double[65, 65]; input[selectedY, selectedX] = 1;
    var values = new double[1, 65, 65]; values[0, selectedY, selectedX] = 1;
    var source = new RgbImage(values);
    var basis = selectedBasis;
    var maps = ImageSimulationEngine.ResizeCoefficientMaps(basis.CoefficientGrid, 65, 65);
    var convolved = ImageSimulationEngine.SpatiallyVariableConvolution(input,
        basis.EigenPsfs, maps, basis.MeanPsf);
    var grid = ImageSimulationEngine.GenerateDistortionGrid(optic, wave, 65, 65, 5, 1,
        referenceWavelength: optic.Wavelengths.First(w => w.IsPrimary));
    var raw = ImageSimulationEngine.WarpImage(convolved, grid);
    var actual = ImageSimulationEngine.Simulate(optic, source, selectedConfig);
    var signedPower = raw.Cast<double>().Sum();
    var clippedPower = raw.Cast<double>().Where(value => value > 0).Sum();
    var maximumDifference = raw.Cast<double>().Select(value => Math.Max(0, value))
        .Zip(actual.Simulated.Values.Cast<double>(), (a, b) => Math.Abs(a - b)).Max();
    return new { Mode = actual.EffectiveAberrationMode, actual.GeometricFallbackCount,
        Wavelength = selectedWave, PixelPitch = selectedPitch, Components = selectedComponents,
        SourceX = selectedX, SourceY = selectedY, Candidates = candidates,
        ConvolutionMinimum = convolved.Cast<double>().Min(), MinimumBeforeFinalClamp = raw.Cast<double>().Min(),
        SignedPower = signedPower, PowerAfterClamp = clippedPower,
        RelativeIncreaseFromClamp = clippedPower / signedPower - 1,
        ActualSimulatedPower = actual.Simulated.Values.Cast<double>().Sum(),
        ActualVsReplayedPipelineMaximumDifference = maximumDifference };
});

var core = typeof(Optic).Assembly.Location;
var root = new { Date = "2026-10-17", CorePath = core,
    CoreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(),
    Runtime = Environment.Version.ToString(), Records = records };
File.WriteAllText(args[0], JsonSerializer.Serialize(root, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Recorded {records.Count} audit groups to {args[0]}");

void Run(string name, Func<object> action)
{
    var started = DateTimeOffset.UtcNow;
    try { var values = action(); records.Add(new { Name = name, Status = "Observed", Values = values });
        Console.WriteLine($"{name}: observed ({(DateTimeOffset.UtcNow-started).TotalSeconds:F2}s)"); }
    catch (Exception exception) { records.Add(new { Name = name, Status = "Error", Error = exception.ToString() });
        Console.WriteLine($"{name}: {exception.GetType().Name}: {exception.Message}"); }
}
static double[] RasterValues(AnalysisData data, int pane) => data.PlotPanes![pane].Series[0].Points
    .SelectMany(point => new[] { point.Red!.Value, point.Green!.Value, point.Blue!.Value }).ToArray();
static double MeanDifference(RgbImage a, RgbImage b) => Enumerable.Range(0, b.Channels)
    .SelectMany(c => Enumerable.Range(0, b.Height).SelectMany(y => Enumerable.Range(0, b.Width)
        .Select(x => Math.Abs(a[Math.Min(c, a.Channels - 1), y, x] - b[c, y, x])))).Average();
static object Moment(RgbImage image)
{
    double power = 0, mx = 0, my = 0;
    for (var y = 0; y < image.Height; y++) for (var x = 0; x < image.Width; x++)
    { var value = image[0, y, x]; power += value; mx += x * value; my += y * value; }
    mx /= power; my /= power;
    double variance = 0;
    for (var y = 0; y < image.Height; y++) for (var x = 0; x < image.Width; x++)
        variance += ((x - mx) * (x - mx) + (y - my) * (y - my)) * image[0, y, x];
    return new { Power = power, CenterX = mx, CenterY = my, RmsPixels = Math.Sqrt(variance / power) };
}
static RgbImage Source(int width, int height, bool impulse = false)
{
    var values = new double[1, height, width];
    if (impulse) values[0, height / 2, width / 2] = 1;
    else for (var y = 0; y < height; y++) for (var x = 0; x < width; x++)
        values[0, y, x] = .1 + .8 * x / Math.Max(1, width - 1d);
    return new RgbImage(values);
}
static Optic ThinLens(double imageDistance = 10)
{
    var optic = new Optic { FieldDefinition = FieldDefinitionKind.Angle };
    optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint { Y = 1 });
    optic.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = double.PositiveInfinity },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = imageDistance,
            InteractionModel = new ThinLensInteractionModel(10) },
        new OpticalSurface()
    ]);
    return optic;
}
static Optic Primary() => OpticalFormatCatalog.Import(File.ReadAllText(
    "artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX"), ".zmx");
static ImageSimulationConfig Config(string mode = "None", int size = 1, int rays = 2,
    int rows = 1, int columns = 1, int components = 1, int padding = 0, int rotation = 0,
    int outputWidth = 0, int outputHeight = 0, string flip = "None", double pitch = .01,
    double fieldHeight = 1, double wave = .55) => new() {
        ImageWidth = 32, ImageHeight = 32, Padding = padding, SourceRotationDegrees = rotation,
        WavelengthsMicrometers = [wave], PsfGridRows = rows, PsfGridColumns = columns,
        PsfSize = size, NumRays = rays, Components = components, PixelSizeMillimeters = pitch,
        FieldHeight = fieldHeight, AberrationMode = mode, UseRelativeIllumination = false,
        DistortionGridSize = 5, DistortionPolynomialDegree = 1,
        OutputWidth = outputWidth, OutputHeight = outputHeight, ImageFlip = flip
    };
