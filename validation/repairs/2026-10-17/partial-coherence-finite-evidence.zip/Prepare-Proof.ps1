$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Read-Run([string]$taskFile) {
    [xml]$taskXml=Get-Content -LiteralPath $taskFile -Raw
    $taskNs=[Xml.XmlNamespaceManager]::new($taskXml.NameTable)
    $taskNs.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
    $taskCounter=$taskXml.SelectSingleNode('//t:ResultSummary/t:Counters',$taskNs)
    $taskNames=@($taskXml.SelectNodes('//t:Results/t:UnitTestResult',$taskNs) | ForEach-Object {$_.testName} | Sort-Object)
    @{total=[int]$taskCounter.total;passed=[int]$taskCounter.passed;failed=[int]$taskCounter.failed;skipped=[int]$taskCounter.notExecuted;names=$taskNames;newTests=@($taskNames | Where-Object {$_ -match '\.FiniteSpatialCoherenceNativeTests\.'}).Count}
}
$taskRelease=Read-Run (Join-Path $PSScriptRoot 'final/related-release-final.trx')
$taskDebug=Read-Run (Join-Path $PSScriptRoot 'final/related-debug-final.trx')
foreach($taskRun in @($taskRelease,$taskDebug)) {if($taskRun.total -ne 523 -or $taskRun.passed -ne 523 -or $taskRun.failed -ne 0 -or $taskRun.skipped -ne 0 -or $taskRun.newTests -ne 153) {throw 'Incomplete final relevant test set'}}
if(($taskRelease.names -join "`n") -cne ($taskDebug.names -join "`n")) {throw 'Final test names differ'}
$taskPrior=Get-Content (Join-Path $taskRepo 'docs/validation/PARTIAL_COHERENCE_NATIVE_REPAIR_2026-10-17.json') -Raw | ConvertFrom-Json
$taskOldNames=@($taskRelease.names | Where-Object {$_ -notmatch '\.FiniteSpatialCoherenceNativeTests\.'})
$taskOldRun=Read-Run (Join-Path $taskRepo 'artifacts/validation/partial-coherence-native-20261017/final/related-release-final.trx')
if(($taskOldNames -join "`n") -cne ($taskOldRun.names -join "`n")) {throw 'Previous 370 tests changed or missing'}
$taskConfigurations=@()
foreach($taskConfig in @('Release','Debug')) {
    $taskLog=Get-Content (Join-Path $PSScriptRoot "build-$($taskConfig.ToLowerInvariant())-final.log") -Raw
    if(@($taskLog -split "`n" | Where-Object {$_ -match ' -> '}).Count -ne 19 -or -not $taskLog.Contains('0 个警告') -or -not $taskLog.Contains('0 个错误')) {throw 'Incomplete default root build'}
    $taskPaths=@("src/OpticalSystemDesign.Core/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll")
    $taskHashes=@($taskPaths | ForEach-Object { @{path=$_;sha256=(Get-FileHash (Join-Path $taskRepo $_)).Hash.ToLowerInvariant()} })
    if(@($taskHashes.sha256 | Sort-Object -Unique).Count -ne 1) {throw 'Default Core copies differ'}
    $taskConfigurations+=@{configuration=$taskConfig;projects=19;warnings=0;errors=0;defaultCoreCopies=$taskHashes}
}
$taskMetric=Get-Content (Join-Path $PSScriptRoot 'metrics-release-final.json') -Raw | ConvertFrom-Json
if($taskMetric.coreSha256 -ne $taskConfigurations[0].defaultCoreCopies[0].sha256 -or $taskMetric.count -ne 142 -or @($taskMetric.metrics | Where-Object error -gt 1e-9).Count -ne 0) {throw 'Final native metrics do not match the default Release Core'}
$taskPreserved=@{
    'validation/repairs/2026-10-17/partial-coherence-native-evidence.zip'='4efbe05188d84348745dfb35c416b5e3f17d789d9bd8f06e9816d171ab70a402';
    'validation/repairs/2026-10-17/partial-coherence-evidence.zip'='f52185274a24079ff411fcbf1bf42be2bec7e19200767950d9fd707931b5653d';
    'validation/repairs/2026-10-17/image-sampling-statistics-evidence.zip'='22daf84d477f762a2129d8a7d2c56a9c60f1ce0ac8de88ec0156b19672b3473c';
    'validation/repairs/2026-10-17/image-psf-safety-evidence.zip'='042f1a564379bad9b1be57e5f2c9f8139616f9327074fcfabbbcee9437987a65';
    'validation/repairs/2026-10-17/product-image-audit-evidence.zip'='252b9e2c236698a57130e82da28aba409fff10403fa5ff061d3e33f63b7aedd9';
    'validation/repairs/2026-10-16/illumination-inverse-evidence.zip'='bcd5df8b59d0e7437c906503e4b4cbfc514fbe032f09f90595236a845c2657bb';
    'validation/repairs/2026-10-16/illumination-finite-grid-evidence.zip'='a137625a22a2e7e333f637b17e2117b3602569add648b60445e09f8782d3e83d';
    'validation/repairs/2026-10-16/native-diffraction-adapter-evidence.zip'='e452e029523ac4c2a0f806a07fe3a4a05920371ff797a04de4d503e81bfc2a6c'
}
foreach($taskPath in $taskPreserved.Keys) {if((Get-FileHash (Join-Path $taskRepo $taskPath)).Hash.ToLowerInvariant() -ne $taskPreserved[$taskPath]) {throw "Frozen evidence changed: $taskPath"}}
$taskOldZip=[IO.Compression.ZipFile]::OpenRead((Join-Path $taskRepo 'validation/repairs/2026-10-17/partial-coherence-native-evidence.zip'))
try {
    $taskReader=[IO.StreamReader]::new($taskOldZip.GetEntry('capture-manifest.json').Open())
    try {$taskOldManifest=$taskReader.ReadToEnd() | ConvertFrom-Json} finally {$taskReader.Dispose()}
    if((Get-FileHash (Join-Path $taskRepo 'tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-zemax-2026-r1.json')).Hash.ToLowerInvariant() -ne $taskOldManifest.fixtureSha256) {throw 'Previous eighteen-image fixture changed'}
} finally {$taskOldZip.Dispose()}
if((Get-FileHash (Join-Path $PSScriptRoot 'Core.before.dll')).Hash.ToLowerInvariant() -ne 'b3021d868f1f0295408c9fa07ad71d1574796fa360543a21db7621b545ce6268') {throw 'Before Core changed'}
foreach($taskGroup in @('scan-v1','boundary-v1','holdout-v1','wide-v1')) {
    $taskEnv=Get-Content (Join-Path $PSScriptRoot "$taskGroup/environment.json") -Raw | ConvertFrom-Json
    if($taskEnv.major -ne 26 -or $taskEnv.minor -ne 1 -or $taskEnv.build -ne 260127 -or -not $taskEnv.validLicense) {throw 'Unexpected native runtime'}
}
$taskCapture=Get-Content (Join-Path $PSScriptRoot 'capture-manifest.json') -Raw | ConvertFrom-Json
if($taskCapture.caseCount -ne 142) {throw 'Capture count changed'}
$taskSources=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt') | ForEach-Object { @{path=$_;sha256=(Get-FileHash (Join-Path $taskRepo $_)).Hash.ToLowerInvariant()} })
$taskProof=[ordered]@{date='2026-10-17';baseCommit=(git -C $taskRepo rev-parse HEAD);scope='Original three 2D source and six type-7 residuals';nativeRuntime='OpticStudio 2026 R1 build 260127 Enterprise API';sourceSha256=$taskCapture.lensSha256;testRelease=$taskRelease;testDebug=$taskDebug;previous370NamesPreserved=$true;finalNamesEqual=$true;configurations=$taskConfigurations;nativeCaptureCount=142;nativePhysicalAxisCases=138;noPaddingRasterOnlyCases=4;nativeMaximumAbsoluteDifference=($taskMetric.metrics.error | Measure-Object -Maximum).Maximum;nativeMetricsCoreSha256=$taskMetric.coreSha256;capturedFixtureSha256=$taskCapture.fixtureSha256;fixedTolerance=1e-9;frozenArchivesPreserved=$taskPreserved;changedCSharpFiles=$taskSources;formatFileCount=22;formatExitCode=0;noFullSuite=$true;noUnrelatedPrecisionMatrixRerun=$true;noInstallerRebuild=$true;noCommitOrPush=$true}
$taskProof | ConvertTo-Json -Depth 18 | Set-Content (Join-Path $PSScriptRoot 'proof.json')
'Verified 142 native rasters, unchanged previous 370 tests, final 523/523 twice, 19 default projects twice, and preserved frozen archives'
