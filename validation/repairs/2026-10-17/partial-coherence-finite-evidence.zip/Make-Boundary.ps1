$ErrorActionPreference='Stop'
$taskReq=@()
foreach($taskAlpha in @(.0005,.002,.004)) {
    foreach($taskGamma in @(0,1)) {
        foreach($taskD in @(4,5,6,7)) {
            $taskReq += @{name="a$taskAlpha-g$taskGamma-d$taskD";file=(Join-Path $PSScriptRoot "source/d$taskD-0.IMA");fileSize=.008;changes=@(@{offset=48;integer=6},@{offset=792;integer=$taskGamma},@{offset=808;number=$taskAlpha},@{offset=800;number=.98},@{offset=32;integer=3})}
        }
    }
}
$taskPath=Join-Path $PSScriptRoot 'boundary-requests.json'
$taskReq | ConvertTo-Json -Depth 7 | Set-Content $taskPath
& (Join-Path $PSScriptRoot 'Run-Cases.ps1') -Requests $taskPath -OutputName boundary-v1
exit $LASTEXITCODE
