$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$taskStage=Join-Path $PSScriptRoot 'archive-input'
if(Test-Path -LiteralPath $taskStage) {throw 'Evidence staging already exists; use a fresh staging directory'}
New-Item -ItemType Directory -Path $taskStage | Out-Null
function Copy-Evidence([string]$taskSource,[string]$taskRelative) {
    $taskDest=Join-Path $taskStage $taskRelative
    New-Item -ItemType Directory -Path (Split-Path -Parent $taskDest) -Force | Out-Null
    Copy-Item -LiteralPath $taskSource -Destination $taskDest
}
foreach($taskFile in Get-ChildItem -LiteralPath $PSScriptRoot -File) {
    if($taskFile.Extension -ne '.exe') {Copy-Evidence $taskFile.FullName $taskFile.Name}
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'accepted-native-captures') -Destination $taskStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'source') -Destination $taskStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'final') -Destination $taskStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'tests') -Destination $taskStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'wide-v1') -Destination (Join-Path $taskStage 'diagnostic-wide-v1') -Recurse
foreach($taskDir in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'scan-v1') -Directory | Where-Object Name -Match 'f90') {
    $taskDest=Join-Path (Join-Path $taskStage 'diagnostic-f90') $taskDir.Name
    New-Item -ItemType Directory -Path $taskDest -Force | Out-Null
    Get-ChildItem -LiteralPath $taskDir.FullName -File | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination $taskDest}
}
foreach($taskGroup in @('scan-v1','boundary-v1','holdout-v1')) {
    foreach($taskName in @('environment.json','analysis-settings.json','native-model.json','reset.CFG')) {Copy-Evidence (Join-Path $PSScriptRoot "$taskGroup/$taskName") "capture-runtime/$taskGroup/$taskName"}
}
foreach($taskName in @('Program.cs','Probe.csproj')) {Copy-Evidence (Join-Path $PSScriptRoot "probe/$taskName") "probe/$taskName"}
foreach($taskPath in Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')) {Copy-Evidence (Join-Path $taskRepo $taskPath) "product-source/$taskPath"}
foreach($taskPath in @('docs/PARTIAL_COHERENCE_FINITE_REPAIR_2026-10-17.md','docs/CURRENT_STATUS.md','docs/NUMERICAL_PARITY.md','docs/OPEN_ISSUES_2026-10-08.md','tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj','tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-finite-zemax-2026-r1.json')) {Copy-Evidence (Join-Path $taskRepo $taskPath) "product-source/$taskPath"}
$taskManifest=@(Get-ChildItem -LiteralPath $taskStage -File -Recurse | ForEach-Object {@{path=[IO.Path]::GetRelativePath($taskStage,$_.FullName).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}} | Sort-Object path)
$taskManifest | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $taskStage 'files-manifest.json')
$taskZipPath=Join-Path $taskRepo 'validation/repairs/2026-10-17/partial-coherence-finite-evidence.zip'
if(Test-Path -LiteralPath $taskZipPath) {throw 'Final evidence already exists; never overwrite frozen evidence'}
[IO.Compression.ZipFile]::CreateFromDirectory($taskStage,$taskZipPath,[IO.Compression.CompressionLevel]::Optimal,$false)
$taskZip=[IO.Compression.ZipFile]::OpenRead($taskZipPath)
try {
    foreach($taskFile in $taskManifest) {
        $taskEntry=$taskZip.GetEntry($taskFile.path)
        if($null -eq $taskEntry -or $taskEntry.Length -ne $taskFile.bytes) {throw 'Evidence entry incomplete'}
        $taskStream=$taskEntry.Open()
        try {$taskSha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($taskStream)).ToLowerInvariant()} finally {$taskStream.Dispose()}
        if($taskSha -ne $taskFile.sha256) {throw 'Evidence entry hash differs'}
    }
    $taskResult=@{path='validation/repairs/2026-10-17/partial-coherence-finite-evidence.zip';sha256=(Get-FileHash -LiteralPath $taskZipPath).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $taskZipPath).Length;entries=$taskZip.Entries.Count;allEntryHashesVerified=$true}
} finally {$taskZip.Dispose()}
$taskResult | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'archive-result.json')
$taskResult | ConvertTo-Json
