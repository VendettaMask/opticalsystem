$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$taskFixturePath=Join-Path $taskRepo 'tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-finite-zemax-2026-r1.json'
$taskFixture=Get-Content -LiteralPath $taskFixturePath -Raw | ConvertFrom-Json
$taskRecords=@()
foreach($taskCase in $taskFixture.Cases) {
    $taskDir=Join-Path $taskRepo $taskCase.Capture
    $taskCfg=[IO.File]::ReadAllBytes((Join-Path $taskDir 'readback.CFG'))
    $taskRequest=Get-Content (Join-Path $taskDir 'request.json') -Raw | ConvertFrom-Json
    $taskMode=if($taskCase.Method -eq 'FiniteCorrelationWindow'){6}else{7}
    $taskGamma=if($taskCase.Function -eq 'Gaussian'){0}else{1}
    $taskPad=if($taskCase.Padding -eq 0){0}else{1}
    $taskSampling=[int][Math]::Log2($taskCase.Sampling)-5
    foreach($taskPair in @(@(0,2000),@(4,422),@(32,$taskSampling),@(36,0),@(40,$taskPad),@(44,4),@(48,$taskMode),@(52,1),@(56,2),@(584,0),@(588,0),@(792,$taskGamma))) {
        if([BitConverter]::ToInt32($taskCfg,$taskPair[0]) -ne $taskPair[1]) { throw "Native integer setting mismatch: $($taskCase.Name), $($taskPair[0])" }
    }
    foreach($taskPair in @(@(24,$taskCase.FileSize),@(800,$taskCase.Fraction),@(808,$taskCase.Alpha))) {
        if([BitConverter]::ToDouble($taskCfg,$taskPair[0]) -ne $taskPair[1]) { throw 'Native floating setting mismatch' }
    }
    $taskFile=[Text.Encoding]::Unicode.GetString($taskCfg,60,520).Split([char]0)[0]
    if($taskFile -cne $taskRequest.file) { throw 'Input filename readback mismatch' }
    if((Get-FileHash -LiteralPath $taskFile).Hash.ToLowerInvariant() -ne $taskCase.SourceSha256) { throw 'Source IMA hash changed' }
    $taskLines=Get-Content -LiteralPath $taskFile
    $taskSourceSize=[int]$taskLines[0]
    for($taskY=0;$taskY -lt $taskSourceSize;$taskY++) { for($taskX=0;$taskX -lt $taskSourceSize;$taskX++) {
        if(([int][char]$taskLines[$taskY+1][$taskX]-[int][char]'0')/9.0 -ne $taskCase.Source[$taskY][$taskX]) {throw 'Fixture source differs from IMA'}
    } }
    $taskData=Get-Content (Join-Path $taskDir 'data.json') -Raw | ConvertFrom-Json
    if(-not $taskData.TextSaved -or $taskData.Grids.Count -ne 1 -or $taskData.Messages.Count -ne 0) {throw 'Incomplete or messaged native result'}
    $taskSize=$taskSourceSize+2*$taskCase.Padding
    $taskGrid=$taskData.Grids[0]
    if($taskGrid.Nx -ne $taskSize -or $taskGrid.Ny -ne $taskSize -or $taskGrid.Values.Count -ne $taskSize) {throw 'Native grid dimensions differ'}
    $taskPitch=$taskCase.FileSize/$taskSourceSize
    # This native analysis reports a two-FileSize header even when zero padding is disabled.
    # Keep that observed header distinct from the source-derived physical pitch.
    $taskReportedPitch=2*$taskCase.FileSize/$taskSize
    if($taskGrid.Dx -ne $taskReportedPitch -or $taskGrid.Dy -ne $taskReportedPitch) {throw 'Unexpected native grid header'}
    for($taskY=0;$taskY -lt $taskSize;$taskY++) {
        if($taskGrid.Values[$taskY].Count -ne $taskSize) {throw 'Missing native columns'}
        for($taskX=0;$taskX -lt $taskSize;$taskX++) {
            $taskValue=$taskGrid.Values[$taskY][$taskX]
            if(-not [double]::IsFinite($taskValue) -or $taskValue -lt 0 -or $taskValue -ne $taskCase.Values[$taskY][$taskX]) {throw 'Fixture differs from raw native array'}
        }
    }
    if(-not (Get-Content (Join-Path $taskDir 'data.txt') -Raw).Contains('0.4400')) {throw 'Native text wave mismatch'}
    $taskDest=Join-Path (Join-Path $PSScriptRoot 'accepted-native-captures') $taskCase.Name
    New-Item -ItemType Directory -Path $taskDest -Force | Out-Null
    foreach($taskName in @('data.json','data.txt','request.json','requested.CFG','readback.CFG')) {Copy-Item -LiteralPath (Join-Path $taskDir $taskName) -Destination (Join-Path $taskDest $taskName)}
    Copy-Item -LiteralPath $taskFile -Destination (Join-Path $taskDest 'source.IMA')
    $taskSha=(Get-FileHash (Join-Path $taskDir 'data.json')).Hash.ToLowerInvariant()
    if($taskSha -ne $taskCase.NativeSha256 -or $taskSha -ne (Get-FileHash (Join-Path $taskDest 'data.json')).Hash.ToLowerInvariant()) {throw 'Native data hash changed'}
    $taskRecords+=@{name=$taskCase.Name;method=$taskCase.Method;nativeDataType=$taskMode;fraction=$taskCase.Fraction;alpha=$taskCase.Alpha;coherenceSampling=64;coherenceSamplingAuthority='Inferred discrete profile, not an exposed native setting';dataSha256=$taskSha;cfgSha256=(Get-FileHash (Join-Path $taskDir 'readback.CFG')).Hash.ToLowerInvariant();sourceSha256=$taskCase.SourceSha256;grid=$taskSize;sourceDerivedPitch=$taskPitch;nativeHeaderPitch=$taskGrid.Dx;headerMatchesDerivedPitch=($taskPitch -eq $taskGrid.Dx);physicalAxisCertified=($taskPitch -eq $taskGrid.Dx)}
}
if((Get-FileHash (Join-Path $PSScriptRoot 'source/123456.ZMX')).Hash.ToLowerInvariant() -ne $taskFixture.LensSha256) {throw 'Lens changed'}
$taskRecord=@{native='OpticStudio 2026 R1 build 260127 Enterprise';caseCount=$taskRecords.Count;allNativeSettingsReadBack=$true;allFixtureValuesMatchRawCapture=$true;allSourcesMatchIma=$true;completeFiniteNonnegativeGrids=$true;rowMapping='native[N-1-y,x]';lensSha256=$taskFixture.LensSha256;fixtureSha256=(Get-FileHash $taskFixturePath).Hash.ToLowerInvariant();cases=$taskRecords}
$taskRecord | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $PSScriptRoot 'capture-manifest.json')
"Verified $($taskRecords.Count) complete native image captures and exact fixture arrays"
