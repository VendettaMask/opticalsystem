$ErrorActionPreference='Stop'
$taskReq=@()
foreach($taskD in @(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24)) {
    $taskLines=@('64')
    for($taskY=0;$taskY -lt 64;$taskY++) {
        $taskRow=('0'*64).ToCharArray()
        if($taskY -eq 32) { $taskRow[32]='9'; $taskRow[32-$taskD]='3' }
        $taskLines+= -join $taskRow
    }
    $taskFile=Join-Path $PSScriptRoot "source/wide-d$taskD.IMA"
    $taskLines | Set-Content -Encoding ascii $taskFile
    foreach($taskGamma in @(0,1)) {
        foreach($taskAlpha in @(.0005,.002,.004)) {
            if(($taskAlpha -eq .0005 -and $taskD -gt 4) -or ($taskAlpha -eq .002 -and ($taskD -lt 8 -or $taskD -gt 13)) -or ($taskAlpha -eq .004 -and $taskD -lt 16)) {continue}
            $taskReq+=@{name="wide-a$taskAlpha-g$taskGamma-d$taskD";file=$taskFile;fileSize=.032;changes=@(@{offset=48;integer=6},@{offset=792;integer=$taskGamma},@{offset=808;number=$taskAlpha},@{offset=800;number=.98},@{offset=32;integer=3})}
        }
    }
}
foreach($taskGamma in @(0,1)) {
    $taskReq+=@{name="wide-mode7-g$taskGamma-d1";file=(Join-Path $PSScriptRoot 'source/wide-d1.IMA');fileSize=.032;changes=@(@{offset=48;integer=7},@{offset=792;integer=$taskGamma},@{offset=808;number=.001},@{offset=800;number=.98},@{offset=32;integer=3})}
}
$taskPath=Join-Path $PSScriptRoot 'wide-requests.json'
$taskReq | ConvertTo-Json -Depth 7 | Set-Content $taskPath
& (Join-Path $PSScriptRoot 'Run-Cases.ps1') -Requests $taskPath -OutputName wide-v1
exit $LASTEXITCODE
