using System.Numerics;
using System.Text.Json;
using System.Security.Cryptography;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var root=Path.GetFullPath(args[0]);var repo=Path.GetFullPath(Path.Combine(root,"../../.."));var old=Path.Combine(repo,"artifacts/validation/partial-coherence-native-20261017");
var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(root,"source/123456.ZMX")),".zmx");
var cases=new List<object>();var metrics=new List<object>();var dirs=new List<string>();
dirs.AddRange(Directory.GetDirectories(Path.Combine(root,"scan-v1")).Where(d=>!Path.GetFileName(d).Contains("f90")));
dirs.AddRange(Directory.GetDirectories(Path.Combine(root,"boundary-v1")));
dirs.AddRange(Directory.GetDirectories(Path.Combine(old,"spatial-boundary-capture-v1")));
dirs.AddRange(Directory.GetDirectories(Path.Combine(old,"two-capture-v1")).Where(d=>Path.GetFileName(d).EndsWith("t7")));
dirs.AddRange(Directory.GetDirectories(Path.Combine(root,"holdout-v1")));
foreach(var dir in dirs){var cfg=File.ReadAllBytes(Path.Combine(dir,"readback.CFG"));var sampling=1<<(BitConverter.ToInt32(cfg,32)+5);var alpha=BitConverter.ToDouble(cfg,808);var fraction=BitConverter.ToDouble(cfg,800);var gamma=BitConverter.ToInt32(cfg,792);var mode=BitConverter.ToInt32(cfg,48);
using var req=JsonDocument.Parse(File.ReadAllText(Path.Combine(dir,"request.json")));var lines=File.ReadAllLines(req.RootElement.GetProperty("file").GetString()!);var nSource=int.Parse(lines[0]);var source=new double[1,nSource,nSource];var sourceRows=new List<double[]>();for(var y=0;y<nSource;y++){var row=new double[nSource];for(var x=0;x<nSource;x++)row[x]=source[0,y,x]=(lines[y+1][x]-'0')/9d;sourceRows.Add(row);}
using var native=JsonDocument.Parse(File.ReadAllText(Path.Combine(dir,"data.json")));var grid=native.RootElement.GetProperty("Grids")[0];var n=grid.GetProperty("Nx").GetInt32();var values=grid.GetProperty("Values");var function=gamma==0?SpatialCoherenceFunction.Gaussian:SpatialCoherenceFunction.Sinc;var method=mode==6?SpatialCoherenceMethod.FiniteCorrelationWindow:SpatialCoherenceMethod.FourierModes;
var config=new ImageSimulationConfig{AberrationMode="Partially Coherent",CoherenceFunction=function,CoherenceAlphaMillimeters=alpha,CoherenceMethod=method,CoherenceFraction=fraction,CoherenceSampling=64,FileSizeMillimeters=BitConverter.ToDouble(cfg,24),NormalizeImagePeak=true,UseRelativeIllumination=false,WavelengthsMicrometers=[.44],NumRays=sampling,PsfSize=65,PsfGridRows=1,PsfGridColumns=1,Padding=(n-nSource)/2};
var actual=ImageSimulationEngine.Simulate(optic,new RgbImage(source),config);double error=0;for(var y=0;y<n;y++)for(var x=0;x<n;x++)error=Math.Max(error,Math.Abs(actual.Simulated[0,y,x]-values[n-1-y][x].GetDouble()));
var name=Path.GetFileName(Path.GetDirectoryName(dir))+"/"+Path.GetFileName(dir);metrics.Add(new{name,method=method.ToString(),error});if(error>1e-9)Console.WriteLine(JsonSerializer.Serialize(new{name,error}));
cases.Add(new{Name=name,Function=function.ToString(),Method=method.ToString(),Alpha=alpha,Fraction=fraction,CoherenceSampling=64,FileSize=config.FileSizeMillimeters,Sampling=sampling,Padding=config.Padding,Source=sourceRows,Values=values.Clone(),Capture=Path.GetRelativePath(repo,dir).Replace('\\','/'),SourceSha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(req.RootElement.GetProperty("file").GetString()!))).ToLowerInvariant(),NativeSha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(dir,"data.json")))).ToLowerInvariant()});
}
File.WriteAllText(Path.Combine(root,"metrics-release-final.json"),JsonSerializer.Serialize(new{coreSha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(DiffractionEngine).Assembly.Location))).ToLowerInvariant(),count=cases.Count,metrics},new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine(JsonSerializer.Serialize(new{count=cases.Count,failures=metrics.Count(v=>((JsonElement)JsonSerializer.SerializeToElement(v)).GetProperty("error").GetDouble()>1e-9)}));


