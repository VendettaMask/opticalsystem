using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
if (args.Length != 1) throw new ArgumentException("Pass a JSON output path.");
var optic = OpticalFormatCatalog.Import(File.ReadAllText("artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX"), ".zmx");
var records = new List<object>();
foreach (var wave in optic.Wavelengths.Take(3))
foreach (var field in new[] { (0d, 0d), (0d, .5) })
foreach (var samples in new[] { 8, 16 })
foreach (var cells in new[] { false, true })
{
    var psf = DiffractionEngine.ComputeFftPsf(optic, field, wave, samples, 4 * samples, cellCenteredPupil: cells);
    var bytes = new byte[Buffer.ByteLength(psf.Values)]; Buffer.BlockCopy(psf.Values, 0, bytes, 0, bytes.Length);
    records.Add(new { wave.Nanometers, Field = new[] { field.Item1, field.Item2 }, Samples = samples, CellCentered = cells,
        ValuesSha256 = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(), psf.WorkingFNumber,
        psf.SampleSpacingMicrometers, psf.UseRayAiming, psf.StopAimingFallbackUsed });
}
var core = typeof(Optic).Assembly.Location;
File.WriteAllText(args[0], JsonSerializer.Serialize(new { CorePath = core,
    CoreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(), Records = records },
    new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Recorded {records.Count} exact FFT controls.");
