using System.Numerics;
using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
if (args.Length != 1) throw new ArgumentException("Pass a JSON output path.");
var interference = new List<object>();
foreach (var gamma in new[] { 0d, .25, .5, .75, 1 }) foreach (var shift in new[] { 0d, Math.PI })
{
    var actual = MutualIntensityEngine.PropagateUniformCoherence(new double[,] { { 0, 1, 0, 1, 0 } },
        new Complex[,] { { .5, .5, .5 } }, gamma, new double[,] { { 0, 0, 0, shift, 0 } });
    interference.Add(new { Gamma = gamma, PhaseDifference = shift, Intensity = actual[0, 2],
        Expected = .5 * (1 + gamma * Math.Cos(shift)), Error = Math.Abs(actual[0, 2] - .5 * (1 + gamma * Math.Cos(shift))) });
}
var optic = OpticalFormatCatalog.Import(File.ReadAllText("artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX"), ".zmx");
var source = new double[1, 24, 24]; source[0, 12, 11] = 1; source[0, 12, 13] = 1;
var phase = new double[1, 24, 24]; phase[0, 12, 13] = Math.PI;
var results = new[] { 0d, .5, 1 }.Select(gamma => ImageSimulationEngine.Simulate(optic, new RgbImage(source), Config(gamma))).ToArray();
var changed = ImageSimulationEngine.Simulate(optic, new RgbImage(source), Config(1, phase));
var primary = results.Select((result, index) => new { Gamma = new[] { 0d, .5, 1 }[index],
    result.EffectiveAberrationMode, result.GeometricFallbackCount, result.CoherentImaging,
    ImagePower = result.Simulated.Values.Cast<double>().Sum(), Maximum = result.MaximumValue,
    SourceDifference = result.MeanAbsoluteChange }).ToArray();
var previousBlendError = results[1].Simulated.Values.Cast<double>().Zip(results[0].Simulated.Values.Cast<double>()
    .Zip(results[0].Source.Values.Cast<double>()), (a, pair) => Math.Abs(a - .5 * (pair.First + pair.Second))).Max();
var core = typeof(Optic).Assembly.Location;
File.WriteAllText(args[0], JsonSerializer.Serialize(new { Date = "2026-10-17", CorePath = core,
    CoreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(),
    Interference = interference, PrimaryLens = primary, SourceBlendMaximumError = previousBlendError,
    PrimaryLensCoherentVsIncoherentDifference = Difference(results[0], results[2]),
    PrimaryLensSuppliedPhaseDifference = Difference(results[2], changed) }, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine("Recorded physical interference and original primary-lens controls.");
static double Difference(ImageSimulationResult a, ImageSimulationResult b) => a.Simulated.Values.Cast<double>()
    .Zip(b.Simulated.Values.Cast<double>(), (x, y) => Math.Abs(x - y)).Max();
static ImageSimulationConfig Config(double gamma, double[,,]? phase = null) => new()
{
    ImageWidth = 24, ImageHeight = 24, Padding = 8, PsfSize = 33, NumRays = 16,
    PsfGridRows = 1, PsfGridColumns = 1, Components = 1, PixelSizeMillimeters = .001,
    FieldHeight = .01, WavelengthsMicrometers = [.55], UseRelativeIllumination = false,
    AberrationMode = "Partially Coherent", SpatialCoherence = gamma, SourcePhaseRadians = phase
};
