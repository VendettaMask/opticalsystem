using System.Numerics;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Coordinates;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Rays;
using OpticalSystemDesign.Core.Raytrace;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Analysis;

public enum HuygensPolarizationMode
{
    None,
    LegacyScalarApproximation,
    UnpolarizedMeanPower,
    CoherentXyz
}

public sealed record PsfResult(
    double[,] Values,
    int PupilSampling,
    int GridSize,
    double WorkingFNumber,
    double SampleSpacingMicrometers,
    double TangentialWorkingFNumber = 0,
    double SagittalWorkingFNumber = 0,
    double FrequencySampleCount = 0,
    AnalysisAxisUnit SampleSpacingUnit = AnalysisAxisUnit.Micrometer)
{
    public bool UseRayAiming { get; init; }
    public bool StopAimingFallbackUsed { get; init; }
    public HuygensPolarizationMode HuygensPolarization { get; init; }
    public bool FiniteCellHuygensUsed { get; init; }
    public double PupilGridStretch { get; init; } = 1;
    public double StrehlRatio => Values[GridSize / 2, GridSize / 2] / 100;

    public double PeakStrehlRatio => Values.Cast<double>().DefaultIfEmpty(0).Max() / 100;
}

/// <summary>Global image-plane frame tangent to the image surface at the chief-ray intercept.</summary>
public readonly record struct HuygensImageFrame(Vector3D Center, Vector3D TangentX, Vector3D TangentY);

public sealed record MtfResult(
    IReadOnlyList<double> Frequency,
    IReadOnlyList<double> Tangential,
    IReadOnlyList<double> Sagittal,
    double CutoffFrequency,
    IReadOnlyList<Complex>? TangentialOtf = null,
    IReadOnlyList<Complex>? SagittalOtf = null,
    IReadOnlyList<double>? TangentialFrequency = null,
    IReadOnlyList<double>? SagittalFrequency = null);

public enum FftMtfDataType
{
    Modulation,
    Real,
    Imaginary,
    Phase,
    SquareWave
}

public static partial class DiffractionEngine
{
    public static MtfResult LimitFrequency(MtfResult result, double? maximumFrequency)
    {
        if (!maximumFrequency.HasValue
            || !double.IsFinite(maximumFrequency.Value)
            || maximumFrequency.Value <= 0
            || result.Frequency.Count == 0
            || maximumFrequency.Value >= result.Frequency[^1])
        {
            return result;
        }

        var limit = maximumFrequency.Value;
        var frequency = new List<double>();
        var tangential = new List<double>();
        var sagittal = new List<double>();
        var tangentialOtf = result.TangentialOtf is null ? null : new List<Complex>();
        var sagittalOtf = result.SagittalOtf is null ? null : new List<Complex>();
        var index = 0;
        while (index < result.Frequency.Count && result.Frequency[index] <= limit)
        {
            frequency.Add(result.Frequency[index]);
            tangential.Add(result.Tangential[index]);
            sagittal.Add(result.Sagittal[index]);
            tangentialOtf?.Add(result.TangentialOtf![index]);
            sagittalOtf?.Add(result.SagittalOtf![index]);
            index++;
        }

        if (frequency.Count > 0
            && frequency[^1] < limit
            && index < result.Frequency.Count)
        {
            var leftFrequency = result.Frequency[index - 1];
            var rightFrequency = result.Frequency[index];
            var fraction = (limit - leftFrequency) / (rightFrequency - leftFrequency);
            frequency.Add(limit);
            tangential.Add(result.Tangential[index - 1]
                + ((result.Tangential[index] - result.Tangential[index - 1]) * fraction));
            sagittal.Add(result.Sagittal[index - 1]
                + ((result.Sagittal[index] - result.Sagittal[index - 1]) * fraction));
            tangentialOtf?.Add(result.TangentialOtf![index - 1]
                + ((result.TangentialOtf[index] - result.TangentialOtf[index - 1]) * fraction));
            sagittalOtf?.Add(result.SagittalOtf![index - 1]
                + ((result.SagittalOtf[index] - result.SagittalOtf[index - 1]) * fraction));
        }

        return new MtfResult(
            frequency,
            tangentialOtf?.Select(value => value.Magnitude).ToArray() ?? (IReadOnlyList<double>)tangential,
            sagittalOtf?.Select(value => value.Magnitude).ToArray() ?? (IReadOnlyList<double>)sagittal,
            result.CutoffFrequency,
            tangentialOtf,
            sagittalOtf,
            LimitAxis(result.TangentialFrequency),
            LimitAxis(result.SagittalFrequency));

        IReadOnlyList<double>? LimitAxis(IReadOnlyList<double>? axis)
        {
            if (axis is null) return null;
            var limited = axis.Take(index).ToList();
            if (frequency.Count > limited.Count && index > 0 && index < axis.Count)
            {
                var fraction = (limit - result.Frequency[index - 1])
                    / (result.Frequency[index] - result.Frequency[index - 1]);
                limited.Add(axis[index - 1] + (axis[index] - axis[index - 1]) * fraction);
            }
            return limited;
        }
    }

    /// <summary>Trace each selected wavelength on a common Fourier-conjugate image grid.</summary>
    public static (Wavelength Wavelength, PsfResult Result)[] ComputeFftPsfSpectrum(
        Optic optic, (double Hx, double Hy) field, IReadOnlyList<Wavelength> wavelengths,
        int pupilSampling, int gridSize, bool usePolarization = false,
        bool cellCenteredPupil = false, bool zemaxFftSampling = false,
        bool ignoreOpd = false, bool? aimAtStop = null,
        Wavelength? referenceWavelength = null, double imageDelta = 0,
        bool ignoreScalarTransmission = false)
    {
        ArgumentNullException.ThrowIfNull(wavelengths);
        if (wavelengths.Count == 0) throw new ArgumentException("No selected wavelengths.", nameof(wavelengths));
        var reference = referenceWavelength ?? wavelengths.FirstOrDefault(w => w.IsPrimary) ?? wavelengths[0];
        var shortestIndex = Enumerable.Range(0, wavelengths.Count).MinBy(i => wavelengths[i].Nanometers);
        var shortest = Compute(wavelengths[shortestIndex], imageDelta);
        // Negative delta explicitly requests an unstretched pupil at every wavelength.
        // Otherwise choose the shortest selected wavelength's default pitch before
        // tracing the longer wavelengths, rather than interpolating their old PSFs.
        var commonDelta = zemaxFftSampling && imageDelta == 0
            ? shortest.SampleSpacingMicrometers : imageDelta;
        return wavelengths.Select((wave, index) => (wave,
            index == shortestIndex ? shortest : Compute(wave, commonDelta))).ToArray();

        PsfResult Compute(Wavelength wave, double delta) => ComputeFftPsf(optic, field, wave,
            pupilSampling, gridSize, usePolarization: usePolarization,
            cellCenteredPupil: cellCenteredPupil, zemaxFftSampling: zemaxFftSampling,
            ignoreOpd: ignoreOpd, aimAtStop: aimAtStop,
            referenceWavelength: reference, imageDelta: delta,
            ignoreScalarTransmission: ignoreScalarTransmission);
    }

    /// <summary>
    /// Scalar transmission can be explicitly omitted from automatically generated
    /// pupils. Prepared amplitudes remain authoritative; polarized pupils retain
    /// their traced/Jones transmission. The default includes scalar transmission.
    /// </summary>
    public static PsfResult ComputeFftPsf(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        int pupilSampling,
        int gridSize,
        bool usePolarization = false,
        bool cellCenteredPupil = false,
        double defocusMillimeters = 0,
        WavefrontResult? preparedWavefront = null,
        JonesPupilResult? preparedPolarization = null,
        bool zemaxFftSampling = false,
        bool ignoreOpd = false,
        bool? aimAtStop = null,
        Wavelength? referenceWavelength = null,
        double imageDelta = 0,
        bool ignoreScalarTransmission = false)
    {
        return ComputeFftPsfCore(optic, field, wavelength, pupilSampling, gridSize, usePolarization,
            cellCenteredPupil, defocusMillimeters, preparedWavefront, preparedPolarization,
            zemaxFftSampling, ignoreOpd, aimAtStop, referenceWavelength, imageDelta,
            ignoreScalarTransmission, out _);
    }

    private static PsfResult ComputeFftPsfCore(
        Optic optic, (double Hx, double Hy) field, Wavelength wavelength, int pupilSampling, int gridSize,
        bool usePolarization, bool cellCenteredPupil, double defocusMillimeters,
        WavefrontResult? preparedWavefront, JonesPupilResult? preparedPolarization,
        bool zemaxFftSampling, bool ignoreOpd, bool? aimAtStop, Wavelength? referenceWavelength,
        double imageDelta, bool ignoreScalarTransmission, out Complex[,] complexPupil)
    {
        AnalysisResourceLimits.ValidateFftGrid(pupilSampling, gridSize);

        var pupilAimAtStop = aimAtStop ?? optic.RayAimingEnabled;
        var fallbackUsed = false;
        if (!TryWorkingFNumbersAtPupilZone(optic, field, wavelength, pupilAimAtStop, false, 1, out var workingAxes))
        {
            // A paraxial entrance-pupil launch can miss the real stop in high-NA systems.
            // Retry the entire pupil convention, not just the F-number used to scale its FFT.
            if ((preparedWavefront is not null && preparedWavefront.UseRayAiming != true)
                || (usePolarization && preparedPolarization is not null && preparedPolarization.UseRayAiming != true))
            {
                throw new InvalidOperationException(
                    "FFT PSF requires stop aiming. Regenerate the prepared wavefront and polarization with stop aiming and pass aimAtStop: true.");
            }

            workingAxes = WorkingFNumbers(optic, field, wavelength, aimAtStop: true);
            fallbackUsed = !pupilAimAtStop;
            pupilAimAtStop = true;
        }

        var fNumber = CombineWorkingFNumbers(workingAxes);
        var pupilGridStretch = zemaxFftSampling && imageDelta >= 0
            ? Math.Sqrt(Math.Max(1, pupilSampling / 32.0))
            : 1;
        if (!double.IsFinite(imageDelta) || (!zemaxFftSampling && imageDelta < 0))
        {
            throw new ArgumentOutOfRangeException(nameof(imageDelta));
        }
        if (zemaxFftSampling && imageDelta > 0)
        {
            if (preparedWavefront is not null || preparedPolarization is not null)
            {
                throw new ArgumentException("Explicit FFT image sampling requires regenerating the pupil grid.");
            }
            // Fourier-conjugate grids: requesting image pitch changes the pupil
            // spacing before tracing; resampling an existing PSF is not equivalent.
            pupilGridStretch = optic.ImageSpaceAfocal
                ? ImageSpaceAnalysisSupport.FftSampleSpacingMilliradians(
                    optic, wavelength, pupilSampling, gridSize, true, 1) / imageDelta
                : wavelength.Micrometers * fNumber * (pupilSampling - 2) / (gridSize * imageDelta);
            var automaticStretch = Math.Sqrt(Math.Max(1, pupilSampling / 32.0));
            // Preserve exactly the same boundary nodes when the requested pitch
            // is the default pitch, including floating-point round trips.
            if (Math.Abs(pupilGridStretch - automaticStretch) <= 1e-14 * automaticStretch)
                pupilGridStretch = automaticStretch;
        }
        var grid = new PupilGridSpecification(pupilSampling, cellCenteredPupil, zemaxFftSampling, pupilGridStretch);
        var currentSource = preparedWavefront is not null || (usePolarization && preparedPolarization is not null)
            ? PupilSourceIdentity.Capture(optic) : null;
        if (zemaxFftSampling && imageDelta > 0)
        {
            if (!double.IsFinite(pupilGridStretch) || pupilGridStretch <= 0)
                throw new InvalidOperationException("FFT image delta cannot produce a finite pupil grid.");
            if (grid.Coordinate(0) > -1 + 1e-12 || grid.Coordinate(pupilSampling - 1) < 1 - 1e-12)
                throw new InvalidOperationException("FFT image delta is too large: the sampling grid does not cover the full pupil.");
            if (Enumerable.Range(0, pupilSampling).Count(i => Math.Abs(grid.Coordinate(i)) <= 1) < 2)
                throw new InvalidOperationException("FFT image delta is too small: insufficient pupil samples for two-dimensional diffraction.");
        }
        if (preparedWavefront is not null)
        {
            ValidatePreparedSource(preparedWavefront.SourceIdentity, "wavefront");
            ValidatePreparedPupil(preparedWavefront.UseRayAiming, preparedWavefront.PupilGrid,
                preparedWavefront.SourceField, preparedWavefront.SourceWavelengthNanometers, "wavefront");
            if (preparedWavefront.SourceReferenceWavelengthNanometers != (referenceWavelength?.Nanometers ?? wavelength.Nanometers))
                throw new InvalidOperationException("FFT PSF prepared wavefront reference wavelength does not match the computation request.");
            var expectedNodes = new HashSet<(double X, double Y)>();
            for (var row = 0; row < pupilSampling; row++)
                for (var column = 0; column < pupilSampling; column++)
                {
                    var x = grid.Coordinate(column); var y = grid.Coordinate(row);
                    if (x * x + y * y <= 1) expectedNodes.Add((x, y));
                }
            if (preparedWavefront.Samples.Count != expectedNodes.Count
                || preparedWavefront.Samples.Any(sample => !expectedNodes.Remove((sample.NormalizedPupilX, sample.NormalizedPupilY))))
                throw new InvalidOperationException("FFT PSF prepared wavefront samples do not match the requested pupil nodes.");
        }
        if (usePolarization && preparedPolarization is not null)
        {
            ValidatePreparedSource(preparedPolarization.SourceIdentity, "polarization");
            ValidatePreparedPupil(preparedPolarization.UseRayAiming, preparedPolarization.PupilGrid,
                preparedPolarization.Field, preparedPolarization.Wavelength.Nanometers, "polarization");
            if (!preparedPolarization.UsesFresnelCoatings || preparedPolarization.IncludesBulkAbsorption
                || preparedPolarization.Samples.Count != pupilSampling * pupilSampling
                || preparedPolarization.Samples.Where((sample, index) =>
                    sample.Px != grid.Coordinate(index % pupilSampling)
                    || sample.Py != grid.Coordinate(index / pupilSampling)).Any())
                throw new InvalidOperationException("FFT PSF prepared polarization nodes, coating or bulk-absorption model do not match the computation request.");
        }
        var wavefront = preparedWavefront ?? WavefrontEngine.GenerateChiefRayUniform(
            optic,
            field,
            wavelength,
            pupilSampling,
            cellCenteredPupil,
            aimAtStop: pupilAimAtStop,
            pupilGridStretch: pupilGridStretch,
            zemaxCentered: zemaxFftSampling,
            referenceWavelength: referenceWavelength);
        if (ignoreScalarTransmission && !usePolarization && preparedWavefront is null)
        {
            // The frozen native scalar FFT captures exclude transmission when
            // polarization is off. Keep launch apodization and traced acceptance;
            // preserve prepared amplitudes and rays absent from the final trace.
            wavefront = wavefront with
            {
                Samples = wavefront.Samples.Select(sample => sample.Intensity > 0
                    && sample.LaunchIntensity is { } launch
                    ? sample with { Intensity = launch }
                    : sample).ToArray()
            };
        }
        if (zemaxFftSampling && pupilSampling >= 32
            && (pupilSampling & (pupilSampling - 1)) == 0 && !ignoreOpd)
            wavefront = InterpolateFftPupilPhase(wavefront, grid);
        var polarization = usePolarization
            ? preparedPolarization ?? JonesPupilEngine.Generate(
                    optic,
                    field,
                    wavelength,
                    pupilSampling,
                    useFresnelCoatings: true,
                    cellCentered: cellCenteredPupil,
                    aimAtStop: pupilAimAtStop,
                    pupilGridStretch: pupilGridStretch,
                    zemaxCentered: zemaxFftSampling)
            : null;
        var (tangentialFNumber, sagittalFNumber) = cellCenteredPupil
            ? WorkingFNumbers(
                optic,
                field,
                wavelength,
                aimAtStop: pupilAimAtStop,
                zemaxDirectionalAverage: true)
            : (fNumber, fNumber);
        var pupil = BuildComplexPupilCore(
            wavefront,
            polarization,
            pupilSampling,
            wavelength,
            tangentialFNumber,
            sagittalFNumber,
            cellCenteredPupil,
            defocusMillimeters,
            pupilGridStretch,
            ignoreOpd,
            zemaxCentered: zemaxFftSampling);
        complexPupil = pupil;

        var nonzeroCount = pupil.Cast<Complex>().Count(value => value.Magnitude > 0);
        if (nonzeroCount == 0)
        {
            throw new AnalysisDataUnavailableException("FFT PSF", "no illuminated pupil samples reached the image surface");
        }
        var normalization = (double)nonzeroCount * nonzeroCount;
        var padded = new Complex[gridSize, gridSize];
        var offset = (gridSize - pupilSampling) / 2;
        for (var row = 0; row < pupilSampling; row++)
        {
            for (var column = 0; column < pupilSampling; column++)
            {
                padded[row + offset, column + offset] = pupil[row, column];
            }
        }

        Fft2D(padded);
        var shifted = FftShift(padded);
        var psf = new double[gridSize, gridSize];
        for (var row = 0; row < gridSize; row++)
        {
            for (var column = 0; column < gridSize; column++)
            {
                psf[row, column] = shifted[row, column].Magnitude * shifted[row, column].Magnitude / normalization * 100;
            }
        }

        var sampleSpacing = optic.ImageSpaceAfocal
            ? ImageSpaceAnalysisSupport.FftSampleSpacingMilliradians(
                optic,
                wavelength,
                pupilSampling,
                gridSize,
                zemaxFftSampling,
                pupilGridStretch)
            : zemaxFftSampling
                ? wavelength.Micrometers * fNumber * (pupilSampling - 2)
                    / (gridSize * pupilGridStretch)
                : wavelength.Micrometers * fNumber * (pupilSampling - 1) / gridSize;
        sampleSpacing = Math.Max(1e-12, sampleSpacing);
        return new PsfResult(
            psf,
            pupilSampling,
            gridSize,
            fNumber,
            sampleSpacing,
            cellCenteredPupil ? tangentialFNumber : 0,
            cellCenteredPupil ? sagittalFNumber : 0,
            cellCenteredPupil ? pupilSampling : pupilSampling - 1,
            optic.ImageSpaceAfocal ? AnalysisAxisUnit.Milliradian : AnalysisAxisUnit.Micrometer)
        {
            UseRayAiming = pupilAimAtStop,
            StopAimingFallbackUsed = fallbackUsed,
            PupilGridStretch = pupilGridStretch
        };

        void ValidatePreparedSource(PupilSourceIdentity? source, string component)
        {
            if (source is null || currentSource is null || source.Fingerprint != currentSource.Fingerprint)
                throw new InvalidOperationException($"FFT PSF prepared {component} source does not match the current optical snapshot or cannot be verified. Regenerate the prepared wavefront and polarization.");
        }

        void ValidatePreparedPupil(bool? aiming, PupilGridSpecification? preparedGrid,
            (double Hx, double Hy)? sourceField, double? sourceWavelength, string component)
        {
            if (aiming != pupilAimAtStop)
                throw new InvalidOperationException($"FFT PSF pupil aiming mismatch. Regenerate the prepared wavefront and polarization with the requested aiming ({pupilAimAtStop}).");
            if (sourceField != field || sourceWavelength != wavelength.Nanometers
                || preparedGrid is null || preparedGrid.SampleCount != grid.SampleCount
                || !double.IsFinite(preparedGrid.Stretch) || preparedGrid.Stretch <= 0
                || Enumerable.Range(0, pupilSampling).Any(index =>
                    Math.Abs(preparedGrid.Coordinate(index) - grid.Coordinate(index)) > 1e-12))
                throw new InvalidOperationException($"FFT PSF prepared {component} field, wavelength or pupil grid does not match the computation request.");
        }
    }

    internal static (Complex Tangential, Complex Sagittal) ComputeFastFftMtfAtFrequency(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        int pupilSampling,
        double spatialFrequency,
        double defocusMillimeters,
        bool usePolarization,
        WavefrontResult preparedWavefront,
        JonesPupilResult? preparedPolarization = null,
        Wavelength? referenceWavelength = null)
    {
        var (tangentialFNumber, sagittalFNumber) = WorkingFNumbers(
            optic,
            field,
            wavelength,
            aimAtStop: preparedWavefront.UseRayAiming ?? optic.RayAimingEnabled,
            zemaxDirectionalAverage: true);
        var frequencyTangentialFNumber = tangentialFNumber;
        var frequencySagittalFNumber = sagittalFNumber;
        var pupil = BuildComplexPupil(
            preparedWavefront,
            usePolarization ? preparedPolarization : null,
            pupilSampling,
            wavelength,
            tangentialFNumber,
            sagittalFNumber,
            cellCenteredPupil: true,
            defocusMillimeters);
        var tangentialCutoff = optic.ImageSpaceAfocal
            ? ImageSpaceAnalysisSupport.AfocalCutoffFrequencyCyclesPerMilliradian(optic, wavelength)
            : frequencyTangentialFNumber <= 1e-30
                ? 0
                : 1 / (wavelength.Micrometers * 1e-3 * frequencyTangentialFNumber);
        var sagittalCutoff = optic.ImageSpaceAfocal
            ? ImageSpaceAnalysisSupport.AfocalCutoffFrequencyCyclesPerMilliradian(optic, wavelength)
            : frequencySagittalFNumber <= 1e-30
                ? 0
                : 1 / (wavelength.Micrometers * 1e-3 * frequencySagittalFNumber);
        var tangentialShift = tangentialCutoff <= 1e-30
            ? 2
            : 2 * spatialFrequency / tangentialCutoff;
        var sagittalShift = sagittalCutoff <= 1e-30
            ? 2
            : 2 * spatialFrequency / sagittalCutoff;
        if (!usePolarization)
        {
            return (
                SparsePupilAutocorrelation(
                    optic,
                    field,
                    wavelength,
                    pupilSampling,
                    0,
                    tangentialShift,
                    defocusMillimeters,
                    tangentialFNumber,
                    sagittalFNumber,
                    preparedWavefront,
                    referenceWavelength),
                SparsePupilAutocorrelation(
                    optic,
                    field,
                    wavelength,
                    pupilSampling,
                    sagittalShift,
                    0,
                    defocusMillimeters,
                    tangentialFNumber,
                    sagittalFNumber,
                    preparedWavefront,
                    referenceWavelength));
        }

        return (
            PupilAutocorrelation(pupil, 0, tangentialShift),
            PupilAutocorrelation(pupil, sagittalShift, 0));
    }

    private static Complex SparsePupilAutocorrelation(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        int pupilSampling,
        double shiftX,
        double shiftY,
        double defocusMillimeters,
        double tangentialFNumber,
        double sagittalFNumber,
        WavefrontResult normalizationWavefront,
        Wavelength? referenceWavelength)
    {
        if (Math.Abs(shiftX) >= 2 || Math.Abs(shiftY) >= 2)
        {
            return Complex.Zero;
        }

        var coordinates = new List<(double X, double Y)>();
        var integrationWeights = new List<double>();
        const int boundarySubdivisions = 8;
        for (var row = 0; row < pupilSampling; row++)
        {
            for (var column = 0; column < pupilSampling; column++)
            {
                var accepted = 0;
                var centroidX = 0.0;
                var centroidY = 0.0;
                for (var subRow = 0; subRow < boundarySubdivisions; subRow++)
                {
                    var subcellY = -1
                        + (2.0 * (row + ((subRow + 0.5) / boundarySubdivisions))
                            / pupilSampling);
                    for (var subColumn = 0; subColumn < boundarySubdivisions; subColumn++)
                    {
                        var subcellX = -1
                            + (2.0 * (column + ((subColumn + 0.5) / boundarySubdivisions))
                                / pupilSampling);
                        var leftX = subcellX - (shiftX / 2);
                        var leftY = subcellY - (shiftY / 2);
                        var rightX = subcellX + (shiftX / 2);
                        var rightY = subcellY + (shiftY / 2);
                        if ((leftX * leftX) + (leftY * leftY) > 1
                            || (rightX * rightX) + (rightY * rightY) > 1)
                        {
                            continue;
                        }

                        accepted++;
                        centroidX += subcellX;
                        centroidY += subcellY;
                    }
                }

                if (accepted == 0)
                {
                    continue;
                }

                var x = centroidX / accepted;
                var y = centroidY / accepted;
                coordinates.Add((x - (shiftX / 2), y - (shiftY / 2)));
                coordinates.Add((x + (shiftX / 2), y + (shiftY / 2)));
                integrationWeights.Add(accepted / (double)(boundarySubdivisions * boundarySubdivisions));
            }
        }

        if (coordinates.Count == 0)
        {
            return Complex.Zero;
        }

        var pairWavefront = GenerateDefocusedWavefront(
            optic,
            field,
            wavelength,
            coordinates,
            defocusMillimeters,
            referenceWavelength,
            aimAtStop: normalizationWavefront.UseRayAiming ?? optic.RayAimingEnabled);
        var normalizationSamples = normalizationWavefront.Samples
            .Where(sample => sample.Intensity > 0)
            .ToArray();
        var meanNormalizationIntensity = normalizationSamples
            .Select(sample => sample.Intensity)
            .DefaultIfEmpty(0)
            .Average();
        var normalization = meanNormalizationIntensity * Math.PI * pupilSampling * pupilSampling / 4;
        if (normalization <= 1e-30)
        {
            return Complex.Zero;
        }

        var sum = Complex.Zero;
        for (var index = 0; index < pairWavefront.Samples.Count; index += 2)
        {
            var left = pairWavefront.Samples[index];
            var right = pairWavefront.Samples[index + 1];
            var leftValue = PupilValue(left, wavelength, 0, pairWavefront);
            var rightValue = PupilValue(right, wavelength, 0, pairWavefront);
            sum += integrationWeights[index / 2]
                * rightValue
                * Complex.Conjugate(leftValue);
        }

        return sum / normalization;
    }

    public static WavefrontResult GenerateDefocusedWavefront(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        IReadOnlyList<(double X, double Y)> coordinates,
        double defocusMillimeters,
        Wavelength? referenceWavelength = null,
        bool? aimAtStop = null)
    {
        var useRayAiming = aimAtStop ?? optic.RayAimingEnabled;
        if (optic.ImageSpaceAfocal)
        {
            var wavefront = WavefrontEngine.GenerateChiefRaySamples(
                optic,
                field,
                wavelength,
                coordinates,
                aimAtStop: useRayAiming,
                referenceWavelength: referenceWavelength);
            return ApplyAfocalDefocus(wavefront, wavelength, defocusMillimeters);
        }

        if (Math.Abs(defocusMillimeters) <= 1e-30)
        {
            return WavefrontEngine.GenerateChiefRaySamples(
                optic,
                field,
                wavelength,
                coordinates,
                aimAtStop: useRayAiming,
                referenceWavelength: referenceWavelength);
        }

        lock (optic)
        {
            var surfaces = optic.SurfaceGroup.Items;
            if (surfaces.Count < 2)
            {
                return WavefrontEngine.GenerateChiefRaySamples(
                    optic,
                    field,
                    wavelength,
                    coordinates,
                    aimAtStop: useRayAiming,
                    referenceWavelength: referenceWavelength);
            }

            var previous = surfaces[^2];
            var image = surfaces[^1];
            (double X, double Y)? nominalRealImageLaunch = null;
            if (optic.FieldDefinition == FieldDefinitionKind.RealImageHeight)
            {
                var target = FieldCoordinates.Denormalize(
                    optic.Fields,
                    field.Hx,
                    field.Hy);
                nominalRealImageLaunch = optic.SequentialRayTracer.RayGenerator
                    .ResolveRealImageFieldCoordinates(
                        target.X,
                        target.Y,
                        aimAtStop: useRayAiming);
            }

            var originalThickness = previous.Thickness;
            var originalCoordinate = image.CoordinateSystem;
            var shift = previous.CoordinateSystem.ToGlobalDirection(
                new Vector3D(0, 0, defocusMillimeters));
            optic.InvalidateRayTraceCache();
            previous.Thickness = originalThickness + defocusMillimeters;
            image.CoordinateSystem = new CoordinateSystem(
                originalCoordinate.Origin + shift,
                originalCoordinate.RotationXDegrees,
                originalCoordinate.RotationYDegrees,
                originalCoordinate.RotationZDegrees);
            try
            {
                return WavefrontEngine.GenerateChiefRaySamples(
                    optic,
                    field,
                    wavelength,
                    coordinates,
                    aimAtStop: useRayAiming,
                    nominalRealImageLaunch,
                    referenceWavelength: referenceWavelength);
            }
            finally
            {
                optic.InvalidateRayTraceCache();
                previous.Thickness = originalThickness;
                image.CoordinateSystem = originalCoordinate;
            }
        }
    }

    private static WavefrontResult ApplyAfocalDefocus(
        WavefrontResult wavefront,
        Wavelength wavelength,
        double defocusDiopters)
    {
        if (!wavefront.ImageSpaceAfocal || Math.Abs(defocusDiopters) <= 1e-30)
        {
            return wavefront;
        }

        var samples = wavefront.Samples
            .Select(sample => sample with
            {
                OpdWaves = sample.OpdWaves
                    + ImageSpaceAnalysisSupport.AfocalDefocusOpdWaves(
                        sample,
                        wavelength,
                        defocusDiopters,
                        wavefront.AfocalPupilDiameterMillimeters)
            })
            .ToArray();
        return wavefront with { Samples = samples };
    }

    private static Complex PupilValue(
        WavefrontSample sample,
        Wavelength wavelength,
        double defocusMillimeters,
        WavefrontResult wavefront)
    {
        if (sample.Intensity <= 0)
        {
            return Complex.Zero;
        }

        var defocusOpdWaves = DefocusOpdWaves(sample, wavelength, defocusMillimeters, wavefront);
        return Complex.FromPolarCoordinates(
            FieldAmplitudeFromPower(sample.Intensity),
            -2 * Math.PI * (sample.OpdWaves + defocusOpdWaves));
    }

    private static double DefocusOpdWaves(
        WavefrontSample sample,
        Wavelength wavelength,
        double defocus,
        WavefrontResult wavefront)
    {
        if (Math.Abs(defocus) <= 1e-30)
        {
            return 0;
        }

        return wavefront.ImageSpaceAfocal
            ? ImageSpaceAnalysisSupport.AfocalDefocusOpdWaves(
                sample,
                wavelength,
                defocus,
                wavefront.AfocalPupilDiameterMillimeters)
            : wavefront.ImageRefractiveIndex * defocus
                * (wavefront.ChiefImageDirectionZ - sample.ImageDirectionZ)
                / (wavelength.Micrometers * 1e-3);
    }

    internal static double FieldAmplitudeFromPower(double power) =>
        double.IsFinite(power) && power > 0 ? Math.Sqrt(power) : 0;

    private static Complex[,] BuildComplexPupil(
        WavefrontResult wavefront,
        JonesPupilResult? polarization,
        int pupilSampling,
        Wavelength wavelength,
        double tangentialFNumber,
        double sagittalFNumber,
        bool cellCenteredPupil,
        double defocusMillimeters)
    {
        return BuildComplexPupilCore(
            wavefront,
            polarization,
            pupilSampling,
            wavelength,
            tangentialFNumber,
            sagittalFNumber,
            cellCenteredPupil,
            defocusMillimeters,
            pupilGridStretch: 1,
            ignoreOpd: false);
    }

    public static IReadOnlyList<WavefrontResult> GenerateDefocusedPolychromaticWavefronts(
        Optic optic,
        (double Hx, double Hy) field,
        IReadOnlyList<Wavelength> wavelengths,
        IReadOnlyList<(double X, double Y)> coordinates,
        double defocusMillimeters,
        bool usePolarization = false,
        bool? aimAtStop = null)
    {
        var useRayAiming = aimAtStop ?? optic.RayAimingEnabled;
        if (wavelengths.Count == 0)
        {
            return Array.Empty<WavefrontResult>();
        }

        if (optic.ImageSpaceAfocal)
        {
            return wavelengths.Select(wavelength =>
            {
                var wavefront = WavefrontEngine.GenerateChiefRaySamples(
                    optic,
                    field,
                    wavelength,
                    coordinates,
                    aimAtStop: useRayAiming,
                    usePolarization: usePolarization,
                    referenceWavelength: wavelengths.FirstOrDefault(item => item.IsPrimary) ?? wavelengths[0]);
                return ApplyAfocalDefocus(wavefront, wavelength, defocusMillimeters);
            }).ToArray();
        }

        lock (optic)
        {
            var surfaces = optic.SurfaceGroup.Items;
            var previous = surfaces.Count >= 2 ? surfaces[^2] : null;
            var image = surfaces.Count >= 1 ? surfaces[^1] : null;
            var originalThickness = previous?.Thickness ?? 0;
            var originalCoordinate = image?.CoordinateSystem;
            (double X, double Y)? nominalRealImageLaunch = null;
            if (optic.FieldDefinition == FieldDefinitionKind.RealImageHeight)
            {
                var target = FieldCoordinates.Denormalize(optic.Fields, field.Hx, field.Hy);
                nominalRealImageLaunch = optic.SequentialRayTracer.RayGenerator
                    .ResolveRealImageFieldCoordinates(target.X, target.Y, aimAtStop: useRayAiming);
            }

            if (previous is not null && image is not null && Math.Abs(defocusMillimeters) > 1e-30)
            {
                optic.InvalidateRayTraceCache();
                var shift = previous.CoordinateSystem.ToGlobalDirection(
                    new Vector3D(0, 0, defocusMillimeters));
                previous.Thickness = originalThickness + defocusMillimeters;
                image.CoordinateSystem = new CoordinateSystem(
                    originalCoordinate!.Origin + shift,
                    originalCoordinate.RotationXDegrees,
                    originalCoordinate.RotationYDegrees,
                    originalCoordinate.RotationZDegrees);
            }

            try
            {
                var spheres = wavelengths.Select(wavelength =>
                    WavefrontEngine.CreateChiefRayReferenceSphere(
                        optic,
                        field,
                        wavelength,
                        aimAtStop: useRayAiming,
                        nominalRealImageLaunch,
                        usePolarization)).ToArray();
                var primaryIndex = Enumerable.Range(0, wavelengths.Count)
                    .FirstOrDefault(index => wavelengths[index].IsPrimary);
                var primary = spheres[primaryIndex];
                return wavelengths.Select((wavelength, index) =>
                    WavefrontEngine.GenerateChiefRaySamples(
                        optic,
                        field,
                        wavelength,
                        coordinates,
                        aimAtStop: useRayAiming,
                        resolvedRealImageLaunch: nominalRealImageLaunch,
                        referenceSphere: new WavefrontReferenceSphere(
                            primary.CenterX,
                            primary.CenterY,
                            primary.CenterZ,
                            spheres[index].Radius),
                        usePolarization: usePolarization)).ToArray();
            }
            finally
            {
                if (previous is not null && image is not null && originalCoordinate is not null)
                {
                    optic.InvalidateRayTraceCache();
                    previous.Thickness = originalThickness;
                    image.CoordinateSystem = originalCoordinate;
                }
            }
        }
    }

    private static WavefrontResult InterpolateFftPupilPhase(
        WavefrontResult wavefront, PupilGridSpecification grid)
    {
        // Native 2026 R1 scalar FFT captures interpolate the interior even
        // checkerboard from cardinal neighbors, retaining the chief and edge.
        // Keep the traced wavefront and any caller-owned prepared input intact.
        var nodes = wavefront.Samples.ToDictionary(sample => Index(sample), sample => sample);
        var samples = wavefront.Samples.Select(sample =>
        {
            var (column, row) = Index(sample);
            if ((column + row) % 2 != 0
                || (sample.NormalizedPupilX == 0 && sample.NormalizedPupilY == 0)
                || !Illuminated(sample)
                || !nodes.TryGetValue((column - 1, row), out var left) || !Illuminated(left)
                || !nodes.TryGetValue((column + 1, row), out var right) || !Illuminated(right)
                || !nodes.TryGetValue((column, row - 1), out var bottom) || !Illuminated(bottom)
                || !nodes.TryGetValue((column, row + 1), out var top) || !Illuminated(top))
                return sample;
            return sample with { OpdWaves = (left.OpdWaves + right.OpdWaves + bottom.OpdWaves + top.OpdWaves) / 4 };
        }).ToArray();
        return wavefront with { Samples = samples };

        (int Column, int Row) Index(WavefrontSample sample) => (
            (int)Math.Round(sample.NormalizedPupilX / grid.Stretch * (grid.SampleCount / 2d - 1) + grid.SampleCount / 2d),
            (int)Math.Round(sample.NormalizedPupilY / grid.Stretch * (grid.SampleCount / 2d - 1) + grid.SampleCount / 2d));
        static bool Illuminated(WavefrontSample sample) => sample.Intensity > 0 && double.IsFinite(sample.OpdWaves);
    }

    private static Complex[,] BuildComplexPupilCore(
        WavefrontResult wavefront,
        JonesPupilResult? polarization,
        int pupilSampling,
        Wavelength wavelength,
        double tangentialFNumber,
        double sagittalFNumber,
        bool cellCenteredPupil,
        double defocusMillimeters,
        double pupilGridStretch = 1,
        bool ignoreOpd = false,
        bool zemaxCentered = false)
    {
        var pupil = new Complex[pupilSampling, pupilSampling];
        var valid = wavefront.Samples.Where(sample => sample.Intensity > 0).ToArray();
        var meanIntensity = valid.Select(sample => sample.Intensity).DefaultIfEmpty(0).Average();
        foreach (var sample in wavefront.Samples)
        {
            var column = PupilIndex(sample.NormalizedPupilX);
            var row = PupilIndex(sample.NormalizedPupilY);
            var relativeIntensity = meanIntensity <= 1e-30 ? 0 : sample.Intensity / meanIntensity;
            if (polarization is not null)
            {
                var jones = polarization.Samples[(row * pupilSampling) + column];
                relativeIntensity *= jones.IsValid
                    ? (jones.Jxx.Magnitude * jones.Jxx.Magnitude
                        + (jones.Jxy.Magnitude * jones.Jxy.Magnitude)
                        + (jones.Jyx.Magnitude * jones.Jyx.Magnitude)
                        + (jones.Jyy.Magnitude * jones.Jyy.Magnitude)) / 2
                    : 0;
            }

            var amplitude = FieldAmplitudeFromPower(relativeIntensity);
            var defocusOpdWaves = DefocusOpdWaves(
                sample,
                wavelength,
                defocusMillimeters,
                wavefront);
            var phase = -2 * Math.PI * ((ignoreOpd ? 0 : sample.OpdWaves) + defocusOpdWaves);
            pupil[row, column] = Complex.FromPolarCoordinates(amplitude, phase);
        }

        return pupil;

        int PupilIndex(double coordinate) => (int)Math.Round(zemaxCentered && pupilSampling % 2 == 0
            ? coordinate / pupilGridStretch * (pupilSampling / 2.0 - 1) + pupilSampling / 2.0
            : ((coordinate / pupilGridStretch) + 1) / 2 * (pupilSampling - 1));
    }

    private static Complex PupilAutocorrelation(
        Complex[,] pupil,
        double shiftX,
        double shiftY)
    {
        var size = pupil.GetLength(0);
        var normalization = pupil.Cast<Complex>()
            .Sum(value => value.Magnitude * value.Magnitude);
        if (normalization <= 1e-30 || Math.Abs(shiftX) >= 2 || Math.Abs(shiftY) >= 2)
        {
            return Complex.Zero;
        }

        var sum = Complex.Zero;
        for (var row = 0; row < size; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var y = -1 + ((2.0 * row + 1) / size);
            for (var column = 0; column < size; column++)
            {
                var x = -1 + ((2.0 * column + 1) / size);
                var left = BilinearPupilSample(
                    pupil,
                    x - (shiftX / 2),
                    y - (shiftY / 2));
                var right = BilinearPupilSample(
                    pupil,
                    x + (shiftX / 2),
                    y + (shiftY / 2));
                sum += right * Complex.Conjugate(left);
            }
        }

        return sum / normalization;
    }

    private static Complex BilinearPupilSample(Complex[,] pupil, double x, double y)
    {
        var size = pupil.GetLength(0);
        var column = (((x + 1) * size) - 1) / 2;
        var row = (((y + 1) * size) - 1) / 2;
        if (column < 0 || row < 0 || column > size - 1 || row > size - 1)
        {
            return Complex.Zero;
        }

        var left = (int)Math.Floor(column);
        var top = (int)Math.Floor(row);
        var right = Math.Min(size - 1, left + 1);
        var bottom = Math.Min(size - 1, top + 1);
        var fx = column - left;
        var fy = row - top;
        var upper = (pupil[top, left] * (1 - fx)) + (pupil[top, right] * fx);
        var lower = (pupil[bottom, left] * (1 - fx)) + (pupil[bottom, right] * fx);
        return (upper * (1 - fy)) + (lower * fy);
    }

    public static MtfResult ComputeFftMtf(
        PsfResult psf,
        Optic optic,
        Wavelength wavelength)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        ValidatePsfGrid(psf);
        AnalysisResourceLimits.ValidateFftGrid(psf.GridSize, psf.GridSize);
        var complex = new Complex[psf.GridSize, psf.GridSize];
        var center = psf.GridSize / 2;
        for (var row = 0; row < psf.GridSize; row++)
        {
            for (var column = 0; column < psf.GridSize; column++)
            {
                // PSF arrays store the physical origin at N/2. Move it to the
                // DFT origin before transforming so interpolation and spectral
                // combination retain physical phase, not an alternating sign.
                complex[(row - center + psf.GridSize) % psf.GridSize,
                    (column - center + psf.GridSize) % psf.GridSize] = new Complex(psf.Values[row, column], 0);
            }
        }

        Fft2D(complex);
        var shifted = FftShift(complex);
        var dc = shifted[center, center];
        var normalization = dc.Magnitude <= 1e-30 ? Complex.One : dc;
        var tangentialOtf = Enumerable.Range(center, psf.GridSize - center)
            .Select(row => shifted[row, center] / normalization)
            .ToArray();
        var sagittalOtf = Enumerable.Range(center, psf.GridSize - center)
            .Select(column => shifted[center, column] / normalization)
            .ToArray();
        var tangential = tangentialOtf.Select(value => value.Magnitude).ToArray();
        var sagittal = sagittalOtf.Select(value => value.Magnitude).ToArray();
        var sampleCount = psf.FrequencySampleCount > 0
            ? psf.FrequencySampleCount
            : psf.PupilSampling - 1;
        // Retain the PSF's field and launch convention when scaling its OTF.
        // Re-tracing an on-axis probe here can change an off-axis PSF's scale.
        var legacyFNumber = psf.WorkingFNumber;
        var tangentialFNumber = psf.TangentialWorkingFNumber > 0
            ? psf.TangentialWorkingFNumber
            : legacyFNumber;
        var sagittalFNumber = psf.SagittalWorkingFNumber > 0
            ? psf.SagittalWorkingFNumber
            : legacyFNumber;
        var afocalCutoff = optic.ImageSpaceAfocal
            ? ImageSpaceAnalysisSupport.AfocalCutoffFrequencyCyclesPerMilliradian(optic, wavelength)
            : 0;
        var tangentialStep = optic.ImageSpaceAfocal
            ? afocalCutoff / sampleCount
            : 1 / (sampleCount * wavelength.Micrometers * 1e-3 * tangentialFNumber);
        var sagittalStep = optic.ImageSpaceAfocal
            ? afocalCutoff / sampleCount
            : 1 / (sampleCount * wavelength.Micrometers * 1e-3 * sagittalFNumber);
        var tangentialFrequency = Enumerable.Range(0, tangential.Length)
            .Select(index => index * tangentialStep)
            .ToArray();
        var sagittalFrequency = Enumerable.Range(0, sagittal.Length)
            .Select(index => index * sagittalStep)
            .ToArray();
        var cutoff = optic.ImageSpaceAfocal
            ? afocalCutoff
            : Math.Min(
                1 / (wavelength.Micrometers * 1e-3 * tangentialFNumber),
                1 / (wavelength.Micrometers * 1e-3 * sagittalFNumber));
        return new MtfResult(
            tangentialFrequency,
            tangential,
            sagittal,
            cutoff,
            tangentialOtf,
            sagittalOtf,
            tangentialFrequency,
            sagittalFrequency);
    }

    public static PsfResult ComputeMmdftPsf(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        int numRays,
        int imageSize,
        double? pixelPitchMicrometers = null)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        if (numRays < 2)
        {
            throw new ArgumentOutOfRangeException(nameof(numRays), "MMDFT requires at least two pupil samples.");
        }

        if (imageSize < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(imageSize), "Image size must be positive.");
        }

        AnalysisResourceLimits.ValidateDirectPsfWork(numRays, imageSize);

        var wavefront = WavefrontEngine.GenerateChiefRayUniform(optic, field, wavelength, numRays,
            aimAtStop: optic.RayAimingEnabled);
        var pupil = CreateUniformPupil(wavefront, numRays);
        var fNumber = WorkingFNumber(optic, field, wavelength, aimAtStop: optic.RayAimingEnabled);
        var clearSize = numRays - 1;
        var afocalImageSpace = optic.ImageSpaceAfocal;
        var pupilDiameter = ImageSpaceAnalysisSupport.AfocalDiffractionPupilDiameterMillimeters(optic);
        var defaultSampleSpacing = afocalImageSpace && pupilDiameter > 1e-30
            ? wavelength.Micrometers * clearSize / (pupilDiameter * imageSize)
            : wavelength.Micrometers * fNumber * clearSize / imageSize;
        var sampleSpacing = pixelPitchMicrometers ?? defaultSampleSpacing;
        var padSize = afocalImageSpace && pupilDiameter > 1e-30
            ? wavelength.Micrometers * clearSize / (pupilDiameter * sampleSpacing)
            : wavelength.Micrometers * fNumber * clearSize / sampleSpacing;
        if (imageSize > padSize)
        {
            throw new ArgumentException("Image size exceeds the MMDFT pad size for the requested pixel pitch.");
        }

        var imagePlane = new Complex[imageSize, imageSize];
        for (var imageRow = 0; imageRow < imageSize; imageRow++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var imageY = imageRow - (imageSize / 2);
            for (var imageColumn = 0; imageColumn < imageSize; imageColumn++)
            {
                ComputationCancellation.ThrowIfCancellationRequested();
                var imageX = imageColumn - (imageSize / 2);
                var sum = Complex.Zero;
                for (var pupilRow = 0; pupilRow < numRays; pupilRow++)
                {
                    ComputationCancellation.ThrowIfCancellationRequested();
                    var pupilY = pupilRow - (numRays / 2);
                    var left = Complex.FromPolarCoordinates(1, -2 * Math.PI * imageY * pupilY / padSize);
                    for (var pupilColumn = 0; pupilColumn < numRays; pupilColumn++)
                    {
                        var pupilX = pupilColumn - (numRays / 2);
                        var right = Complex.FromPolarCoordinates(1, -2 * Math.PI * pupilX * imageX / padSize);
                        sum += left * pupil[pupilRow, pupilColumn] * right;
                    }
                }

                imagePlane[imageRow, imageColumn] = sum;
            }
        }

        var normalization = Math.Max(1, pupil.Cast<Complex>().Count(value => value.Magnitude > 0));
        normalization *= normalization;
        var psf = new double[imageSize, imageSize];
        for (var row = 0; row < imageSize; row++)
        {
            for (var column = 0; column < imageSize; column++)
            {
                psf[row, column] = imagePlane[row, column].Magnitude * imagePlane[row, column].Magnitude * 100 / normalization;
            }
        }

        return new PsfResult(
            psf,
            numRays,
            imageSize,
            fNumber,
            sampleSpacing,
            SampleSpacingUnit: afocalImageSpace ? AnalysisAxisUnit.Milliradian : AnalysisAxisUnit.Micrometer);
    }

    public static PsfResult ComputeHuygensPsf(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        int numRays,
        int imageSize,
        double pixelPitchMillimeters,
        bool usePolarization = false,
        bool aimAtStop = false,
        double defocus = 0,
        Wavelength? referenceWavelength = null,
        (double X, double Y)? imageCenterOffset = null)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        if (numRays < 2)
        {
            throw new ArgumentOutOfRangeException(nameof(numRays), "Huygens PSF requires at least two pupil samples.");
        }

        if (imageSize < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(imageSize), "Image size must be positive.");
        }


        AnalysisResourceLimits.ValidateDirectPsfWork(numRays, imageSize);

        if (!double.IsFinite(pixelPitchMillimeters) || pixelPitchMillimeters <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(pixelPitchMillimeters), "Pixel pitch must be positive.");
        }
        if (imageCenterOffset is { } offset && (!double.IsFinite(offset.X) || !double.IsFinite(offset.Y)))
            throw new ArgumentOutOfRangeException(nameof(imageCenterOffset), "Image-center offsets must be finite.");
        if (usePolarization && optic.ImageSpaceAfocal && !optic.Polarization.Unpolarized)
            throw new NotSupportedException("Afocal coherent Jones Huygens propagation is not implemented; it cannot be collapsed to unpolarized power.");

        // Use the traced image directions in the image-surface tangent frame
        // for axial and oblique scalar pupils. Native off-axis complex-field
        // controls verify this projection independently of the MTF transform.
        if (!optic.ImageSpaceAfocal)
        {
            var pupilDistance = Math.Abs(optic.Paraxial.EstimateExitPupilLocation());
            var halfWidth = (imageSize / 2d) * pixelPitchMillimeters;
            var cornerX = halfWidth + Math.Abs(imageCenterOffset?.X ?? 0);
            var cornerY = halfWidth + Math.Abs(imageCenterOffset?.Y ?? 0);
            var corner = Math.Sqrt(cornerX * cornerX + cornerY * cornerY);
            // The plane-wave reference is adequate when the phase curvature
            // across the requested image is no more than a quarter wavelength.
            var curvature = corner * corner / (Math.Sqrt(pupilDistance * pupilDistance + corner * corner) + pupilDistance);
            var imageIndex = optic.SurfaceGroup.Items[^1].MaterialAfter.RefractiveIndex(wavelength.Nanometers);
            if (double.IsFinite(pupilDistance) && pupilDistance > 0)
                return ComputeFocusedHuygensPsf(optic, field, wavelength, numRays, imageSize,
                    pixelPitchMillimeters, aimAtStop, referenceWavelength, imageCenterOffset,
                    spherical: curvature * imageIndex > wavelength.Micrometers * .001 / 4,
                    usePolarization: usePolarization);
            if (usePolarization && !optic.Polarization.Unpolarized)
                throw new AnalysisDataUnavailableException("Huygens PSF", "coherent XYZ propagation requires a finite nonzero exit-pupil distance");
        }

        var wavefront = WavefrontEngine.GenerateChiefRayUniform(
            optic,
            field,
            wavelength,
            numRays,
            aimAtStop: aimAtStop,
            referenceWavelength: optic.ImageSpaceAfocal ? referenceWavelength : null);
        var polarization = usePolarization
            ? JonesPupilEngine.Generate(optic, field, wavelength, numRays, useFresnelCoatings: true, aimAtStop: aimAtStop)
            : null;
        if (optic.ImageSpaceAfocal)
        {
            var afocalRaw = HuygensFarFieldSummation(
                wavefront,
                wavelength,
                imageSize,
                pixelPitchMillimeters,
                idealOpd: false,
                polarization,
                defocus,
                imageCenterOffset);
            var afocalNormalizationWavefront = field.Hx == 0 && field.Hy == 0
                ? wavefront
                : WavefrontEngine.GenerateChiefRayUniform(
                    optic,
                    (0, 0),
                    wavelength,
                    numRays,
                    aimAtStop: aimAtStop);
            var afocalNormalizationPolarization = !usePolarization
                ? null
                : field.Hx == 0 && field.Hy == 0
                    ? polarization
                    : JonesPupilEngine.Generate(
                        optic,
                        (0, 0),
                        wavelength,
                        numRays,
                        useFresnelCoatings: true, aimAtStop: aimAtStop);
            var afocalNormalization = HuygensFarFieldSummation(
                afocalNormalizationWavefront,
                wavelength,
                1,
                pixelPitchMillimeters,
                idealOpd: true,
                afocalNormalizationPolarization,
                defocus: 0)[0, 0];
            afocalNormalization = Math.Max(1e-300, afocalNormalization);

            var afocalPsf = new double[imageSize, imageSize];
            for (var row = 0; row < imageSize; row++)
            {
                for (var column = 0; column < imageSize; column++)
                {
                    afocalPsf[row, column] = afocalRaw[row, column] / afocalNormalization * 100;
                }
            }

            return new PsfResult(
                afocalPsf,
                numRays,
                imageSize,
                WorkingFNumber(optic, field, wavelength, aimAtStop),
                pixelPitchMillimeters,
                SampleSpacingUnit: AnalysisAxisUnit.Milliradian)
            {
                UseRayAiming = aimAtStop,
                HuygensPolarization = usePolarization ? HuygensPolarizationMode.LegacyScalarApproximation : HuygensPolarizationMode.None
            };
        }

        var imageCoordinates = CreateHuygensImageCoordinatesAtCenter(optic, field, referenceWavelength ?? wavelength,
            imageSize, pixelPitchMillimeters, aimAtStop, imageCenterOffset);
        var raw = HuygensSummation(
            imageCoordinates,
            wavefront,
            wavelength,
            idealOpd: false,
            polarization);
        var normalizationWavefront = field.Hx == 0 && field.Hy == 0
            ? wavefront
            : WavefrontEngine.GenerateChiefRayUniform(
                optic,
                (0, 0),
                wavelength,
                numRays,
                aimAtStop: aimAtStop);
        var normalizationPolarization = !usePolarization
            ? null
            : field.Hx == 0 && field.Hy == 0
                ? polarization
                : JonesPupilEngine.Generate(
                    optic,
                    (0, 0),
                    wavelength,
                    numRays,
                    useFresnelCoatings: true, aimAtStop: aimAtStop);
        var normalizationPoint = CreateHuygensImageCoordinates(optic, (0, 0), wavelength, 1, pixelPitchMillimeters, aimAtStop);
        var normalization = HuygensSummation(
            normalizationPoint,
            normalizationWavefront,
            wavelength,
            idealOpd: true,
            normalizationPolarization)[0, 0];
        normalization = Math.Max(1e-300, normalization);

        var psf = new double[imageSize, imageSize];
        for (var row = 0; row < imageSize; row++)
        {
            for (var column = 0; column < imageSize; column++)
            {
                psf[row, column] = raw[row, column] / normalization * 100;
            }
        }

        return new PsfResult(
            psf,
            numRays,
            imageSize,
            WorkingFNumber(optic, field, wavelength, aimAtStop),
            pixelPitchMillimeters * 1000.0)
        {
            UseRayAiming = aimAtStop,
            HuygensPolarization = usePolarization ? HuygensPolarizationMode.LegacyScalarApproximation : HuygensPolarizationMode.None
        };
    }

    private static IReadOnlyList<PupilSample> HuygensPupilSamples(int count)
    {
        var nativeGrid = count >= 8 && count % 2 == 0;
        var radius = nativeGrid ? count / 2d - 1 : (count - 1) / 2d;
        // Cell centers stop half a radial cell inside the endpoint boundary.
        var limit = nativeGrid ? 1 - .5 / radius : 1;
        var samples = new List<PupilSample>();
        for (var row = 0; row < count; row++)
            for (var column = 0; column < count; column++)
            {
                var x = nativeGrid ? (column - count / 2d) / radius : -1 + 2d * column / (count - 1);
                var y = nativeGrid ? (row - count / 2d) / radius : -1 + 2d * row / (count - 1);
                if (x * x + y * y <= limit * limit) samples.Add(new(x, y, 1));
            }
        return samples;
    }

    private static PsfResult ComputePlanarHuygensPsf(
        Optic optic, (double Hx, double Hy) field, Wavelength wavelength,
        int pupilSampling, int imageSize, double pitch, bool aimAtStop,
        Wavelength? referenceWavelength, (double X, double Y)? imageCenterOffset)
        => ComputeFocusedHuygensPsf(optic, field, wavelength, pupilSampling, imageSize,
            pitch, aimAtStop, referenceWavelength, imageCenterOffset, spherical: false);

    private static PsfResult ComputeFocusedHuygensPsf(
        Optic optic, (double Hx, double Hy) field, Wavelength wavelength,
        int pupilSampling, int imageSize, double pitch, bool aimAtStop,
        Wavelength? referenceWavelength, (double X, double Y)? imageCenterOffset, bool spherical,
        bool usePolarization = false)
    {
        var useUnpolarizedPower = usePolarization && optic.Polarization.Unpolarized;
        var coherentVector = usePolarization && !optic.Polarization.Unpolarized;
        var pupils = HuygensPupilSamples(pupilSampling);
        WavefrontResult Wavefront((double Hx, double Hy) sourceField)
        {
            var result = WavefrontEngine.GenerateChiefRaySamples(optic, sourceField, wavelength,
                pupils.Select(p => (p.X, p.Y)).ToArray(), aimAtStop: aimAtStop);
            if (!useUnpolarizedPower) return result;
            // Native Unpolarized mode averages the two transported input powers
            // before the scalar Huygens sum. It does not retain their XYZ fields.
            // Source illumination, coating and bulk attenuation enter exactly once.
            return result with
            {
                Samples = result.Samples.Select(sample =>
            {
                if (sample.Intensity <= 0) return sample;
                var source = optic.SequentialRayTracer.RayGenerator.GenerateGeneric(sourceField.Hx, sourceField.Hy,
                    sample.NormalizedPupilX, sample.NormalizedPupilY, wavelength.Micrometers, aimAtStop).Rays.Single();
                var diagnostic = optic.SequentialRayTracer.DiagnoseApertures(source, stopAtIncidentImage: true,
                    usePolarization: true, allowHomogeneousAbsorbingPower: true);
                var intensity = diagnostic.InsideAllApertures ? diagnostic.UnpolarizedIntensity
                    ?? throw new InvalidOperationException("Missing unpolarized pupil power.") : 0;
                return sample with { Intensity = intensity };
            }).ToArray()
            };
        }
        var wavefront = Wavefront(field);
        // Transmission-weighted Strehl uses the unaberrated pupil of this
        // field. An on-axis polarization throughput is not its ideal peak.
        var normalizer = usePolarization || (field.Hx == 0 && field.Hy == 0) ? wavefront : Wavefront((0, 0));
        // Non-polarized native diffraction retains pupil illumination and ray
        // masks. Coating/material attenuation requires polarization tracing.
        double Amplitude(WavefrontSample sample) => sample.Intensity > 0
            ? FieldAmplitudeFromPower(useUnpolarizedPower ? sample.Intensity : sample.LaunchIntensity ?? sample.Intensity) : 0;
        var vectorFields = coherentVector ? wavefront.Samples.Select(sample =>
        {
            if (sample.Intensity <= 0) return default(ComplexElectricField);
            var source = optic.SequentialRayTracer.RayGenerator.GenerateGeneric(field.Hx, field.Hy,
                sample.NormalizedPupilX, sample.NormalizedPupilY, wavelength.Micrometers, aimAtStop).Rays.Single();
            return optic.SequentialRayTracer.TracePolarized(source, optic.Polarization.Input,
                inputCoordinates: optic.SurfaceGroup.Items[0].CoordinateSystem,
                includePropagationPhase: false).LocalField;
        }).ToArray() : null;
        // Remove phase and orientation aberrations for the ideal peak, not
        // the actual XYZ field. Normalization must not hide polarization phase.
        var idealAmplitude = vectorFields is null ? normalizer.Samples.Sum(Amplitude)
            : vectorFields.Sum(value => FieldAmplitudeFromPower(value.SquaredNorm));
        if (!double.IsFinite(idealAmplitude) || idealAmplitude <= 0)
            throw new AnalysisDataUnavailableException("Huygens PSF", "no positive ideal pupil amplitude");
        var frame = CreateHuygensImageFrame(optic, field, referenceWavelength ?? wavelength, aimAtStop);
        var center = frame.Center + frame.TangentX * (imageCenterOffset?.X ?? 0)
            + frame.TangentY * (imageCenterOffset?.Y ?? 0);
        var pupilDiameter = Math.Abs(optic.Paraxial.EstimateExitPupilDiameter());
        var pupilDistance = Math.Abs(optic.Paraxial.EstimateExitPupilLocation());
        var intervals = pupilSampling >= 8 && pupilSampling % 2 == 0 ? pupilSampling - 2 : pupilSampling - 1;
        var wavelengthMillimeters = wavelength.Micrometers * .001;
        // The finite sampling footprint is the transform of a rectangular
        // pupil cell. Its first zero is half the pupil interval count times
        // the paraxial Airy radius (1.22 lambda R/D), in the image medium.
        var halfExtent = .61 * wavelengthMillimeters * pupilDistance * intervals
            / (wavefront.ImageRefractiveIndex * pupilDiameter);
        // The scalar paraxial pupil is an axial plane relative to the image
        // vertex, as in the shared reference-sphere construction. Recover its
        // ray positions and optical paths from that sphere before applying
        // spherical phase and inverse-distance amplitude. A sphere-centered
        // source with a lens-datum obliquity gives a different field.
        var pupilPlaneZ = optic.SurfaceGroup.Items[^1].CoordinateSystem.Origin.Z
            + optic.Paraxial.EstimateExitPupilLocation();
        var emitters = wavefront.Samples.Select((sample, index) =>
        {
            var pupil = new Vector3D(sample.PupilX, sample.PupilY, sample.PupilZ);
            var direction = sample.ImageDirection ?? Vector3D.Zero;
            var shift = spherical && Math.Abs(direction.Z) > 1e-14
                ? (pupil.Z - pupilPlaneZ) / direction.Z : 0;
            return (Pupil: pupil - direction * shift, Direction: direction,
                OpticalPath: -sample.OpdWaves * wavelengthMillimeters,
                Path: -sample.OpdWaves * wavelengthMillimeters
                    - wavefront.ImageRefractiveIndex * (wavefront.Radius + shift),
                Amplitude: vectorFields is null ? Amplitude(sample)
                    : FieldAmplitudeFromPower(vectorFields[index].SquaredNorm),
                VectorField: vectorFields is null ? default : vectorFields[index]);
        }).ToArray();
        var k = 2 * Math.PI / wavelengthMillimeters;
        var values = new double[imageSize, imageSize];
        for (var row = 0; row < imageSize; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var y = (row - imageSize / 2) * pitch;
            for (var column = 0; column < imageSize; column++)
            {
                var x = (column - imageSize / 2) * pitch;
                if (Math.Abs(x) >= halfExtent || Math.Abs(y) >= halfExtent) continue;
                var point = center + frame.TangentX * x + frame.TangentY * y;
                var sum = Complex.Zero;
                var vectorSum = default(ComplexElectricField);
                foreach (var emitter in emitters)
                {
                    var amplitude = emitter.Amplitude;
                    if (amplitude <= 0 || emitter.Direction.Length <= 0) continue;
                    var delta = point - emitter.Pupil;
                    var distance = spherical ? delta.Length : 0;
                    if (spherical && distance <= 1e-300) continue;
                    var phasePath = spherical
                        ? emitter.Path + wavefront.ImageRefractiveIndex * distance
                        : emitter.OpticalPath + wavefront.ImageRefractiveIndex
                            * (Dot(delta, emitter.Direction) - wavefront.Radius);
                    if (vectorFields is null)
                    {
                        if (spherical) amplitude *= pupilDistance / distance;
                        sum += Complex.FromPolarCoordinates(amplitude, k * phasePath);
                    }
                    else
                    {
                        var propagation = Complex.FromPolarCoordinates(spherical ? pupilDistance / distance : 1, k * phasePath);
                        vectorSum += emitter.VectorField * propagation;
                    }
                }
                var footprint = Sinc(Math.PI * x / halfExtent) * Sinc(Math.PI * y / halfExtent);
                values[row, column] = (vectorFields is null ? sum.Magnitude * sum.Magnitude : vectorSum.SquaredNorm) * footprint * footprint
                    / (idealAmplitude * idealAmplitude) * 100;
            }
        }
        return new(values, pupilSampling, imageSize, WorkingFNumber(optic, field, wavelength, aimAtStop), pitch * 1000)
        {
            UseRayAiming = aimAtStop,
            FiniteCellHuygensUsed = true,
            HuygensPolarization = coherentVector ? HuygensPolarizationMode.CoherentXyz
                : useUnpolarizedPower ? HuygensPolarizationMode.UnpolarizedMeanPower : HuygensPolarizationMode.None
        };

        static double Sinc(double argument) => Math.Abs(argument) < 1e-8
            ? 1 - argument * argument / 6 : Math.Sin(argument) / argument;
    }

    public static double DefaultHuygensImageDeltaMillimeters(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        int pupilSampling)
    {
        if (optic.ImageSpaceAfocal)
        {
            var airy = ImageSpaceAnalysisSupport.AfocalAiryRadiusMilliradians(optic, wavelength);
            return Math.Max(1e-12, airy / Math.Sqrt(Math.Max(2, pupilSampling)));
        }

        var workingFNumber = WorkingFNumber(
            optic,
            field,
            wavelength,
            aimAtStop: optic.RayAimingEnabled);
        var deltaMicrometers = wavelength.Micrometers
            * workingFNumber
            / Math.Sqrt(Math.Max(2, pupilSampling));
        return Math.Max(1e-12, deltaMicrometers / 1000.0);
    }

    public static MtfResult ComputePsfMtf(PsfResult psf, bool doubleTransformSize = false)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        ValidatePsfGrid(psf);
        var transformSize = doubleTransformSize ? checked(2 * psf.GridSize) : psf.GridSize;
        AnalysisResourceLimits.ValidateMtfTransformWork(transformSize);

        // Padding changes the frequency spacing, not the PSF pixel pitch.
        // A spatial translation contributes only phase, so placement at the
        // array origin preserves the modulation on both transform axes.
        var complex = new Complex[transformSize, transformSize];
        for (var row = 0; row < psf.GridSize; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var column = 0; column < psf.GridSize; column++)
            {
                complex[row, column] = new Complex(psf.Values[row, column], 0);
            }
        }

        Transform2D(complex);
        var shifted = FftShift(complex);
        var center = transformSize / 2;
        var count = transformSize / 2;
        var dc = Math.Max(1e-300, shifted[center, center].Magnitude);
        var tangential = Enumerable.Range(0, count)
            .Select(index => Math.Clamp(shifted[center + index, center].Magnitude / dc, 0, 1))
            .ToArray();
        var sagittal = Enumerable.Range(0, count)
            .Select(index => Math.Clamp(shifted[center, center + index].Magnitude / dc, 0, 1))
            .ToArray();
        var frequencyStep = psf.SampleSpacingUnit == AnalysisAxisUnit.Milliradian
            ? 1.0 / (transformSize * psf.SampleSpacingMicrometers)
            : 1000.0 / (transformSize * psf.SampleSpacingMicrometers);
        var frequency = Enumerable.Range(0, count).Select(index => index * frequencyStep).ToArray();
        var cutoff = count == 0 ? 0 : frequency[^1];
        return new MtfResult(frequency, tangential, sagittal, cutoff);
    }

    public static MtfResult ComputePsfMtfAtFrequencies(
        PsfResult psf,
        IReadOnlyList<double> spatialFrequencies)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        ValidatePsfGrid(psf);
        ArgumentNullException.ThrowIfNull(spatialFrequencies);
        AnalysisResourceLimits.ValidateDirectMtfWork(psf.GridSize, spatialFrequencies.Count);
        if (spatialFrequencies.Count == 0)
        {
            return new MtfResult(Array.Empty<double>(), Array.Empty<double>(), Array.Empty<double>(), 0);
        }

        var frequencies = spatialFrequencies
            .Select(frequency => Math.Max(0, frequency))
            .ToArray();
        var tangential = new double[frequencies.Length];
        var sagittal = new double[frequencies.Length];
        var dc = psf.Values.Cast<double>().Sum();
        if (!double.IsFinite(dc) || dc <= 0)
        {
            return new MtfResult(frequencies, tangential, sagittal, frequencies.Max());
        }

        var center = (psf.GridSize - 1) / 2.0;
        var spacing = psf.SampleSpacingUnit == AnalysisAxisUnit.Milliradian
            ? psf.SampleSpacingMicrometers
            : psf.SampleSpacingMicrometers / 1000.0;
        for (var frequencyIndex = 0; frequencyIndex < frequencies.Length; frequencyIndex++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var angularFrequency = 2 * Math.PI * frequencies[frequencyIndex];
            var tangentialOtf = Complex.Zero;
            var sagittalOtf = Complex.Zero;
            for (var row = 0; row < psf.GridSize; row++)
            {
                ComputationCancellation.ThrowIfCancellationRequested();
                var y = (row - center) * spacing;
                var tangentialPhase = Complex.FromPolarCoordinates(1, -angularFrequency * y);
                for (var column = 0; column < psf.GridSize; column++)
                {
                    var intensity = psf.Values[row, column];
                    tangentialOtf += intensity * tangentialPhase;
                    var x = (column - center) * spacing;
                    sagittalOtf += intensity * Complex.FromPolarCoordinates(1, -angularFrequency * x);
                }
            }

            tangential[frequencyIndex] = Math.Clamp(tangentialOtf.Magnitude / dc, 0, 1);
            sagittal[frequencyIndex] = Math.Clamp(sagittalOtf.Magnitude / dc, 0, 1);
        }

        return new MtfResult(frequencies, tangential, sagittal, frequencies.Max());
    }

    private static void ValidatePsfGrid(PsfResult psf)
    {
        ArgumentNullException.ThrowIfNull(psf);
        if (psf.GridSize < 1 || psf.GridSize > AnalysisResourceLimits.MaximumFftGridSize
            || psf.Values is null || psf.Values.GetLength(0) != psf.GridSize
            || psf.Values.GetLength(1) != psf.GridSize
            || !double.IsFinite(psf.SampleSpacingMicrometers) || psf.SampleSpacingMicrometers <= 0)
            throw new ArgumentException("PSF must have a bounded square grid and positive finite sample spacing.", nameof(psf));
    }

    public static double WorkingFNumber(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        bool aimAtStop = false)
    {
        var axes = WorkingFNumbers(optic, field, wavelength, aimAtStop);
        return CombineWorkingFNumbers(axes);
    }

    private static double CombineWorkingFNumbers((double Tangential, double Sagittal) axes)
    {
        var inverseSquared = (1 / (axes.Tangential * axes.Tangential)
            + (1 / (axes.Sagittal * axes.Sagittal))) / 2;
        return inverseSquared <= 0 ? 10000 : Math.Min(10000, 1 / Math.Sqrt(inverseSquared));
    }

    public static (double Tangential, double Sagittal) WorkingFNumbers(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        bool aimAtStop = false,
        bool zemaxDirectionalAverage = false,
        bool strictFullPupil = false)
    {
        if (strictFullPupil)
            return TryWorkingFNumbersAtPupilZone(optic, field, wavelength, aimAtStop, zemaxDirectionalAverage, 1, out var strictAxes, strict: true)
                ? strictAxes : throw new InvalidOperationException("全瞳边缘光线未到达像面，无法计算工作 F 数。");
        return TryWorkingFNumbers(optic, field, wavelength, aimAtStop, zemaxDirectionalAverage, out var axes)
            ? axes
            : throw new InvalidOperationException("Working-F-number ray did not reach the image surface.");
    }

    private static bool TryWorkingFNumbers(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        bool aimAtStop,
        bool zemaxDirectionalAverage,
        out (double Tangential, double Sagittal) axes)
    {
        // OpticStudio's Working F/# ignores surface apertures. If a full-pupil
        // marginal ray still has a ray error, it retries at a smaller pupil zone
        // and scales the measured numerical aperture back to the full pupil.
        ReadOnlySpan<double> pupilZones = [1.0, 0.99, 0.95, 0.9, 0.8, 0.7, 0.5, 0.25];
        foreach (var pupilZone in pupilZones)
        {
            if (TryWorkingFNumbersAtPupilZone(
                optic,
                field,
                wavelength,
                aimAtStop,
                zemaxDirectionalAverage,
                pupilZone,
                out axes))
            {
                return true;
            }
        }

        axes = default;
        return false;
    }

    private static bool TryWorkingFNumbersAtPupilZone(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        bool aimAtStop,
        bool zemaxDirectionalAverage,
        double pupilZone,
        out (double Tangential, double Sagittal) axes,
        bool strict = false)
    {
        axes = default;
        var pupil = new[]
        {
            (0.0, 0.0),
            (0.0, pupilZone),
            (0.0, -pupilZone),
            (pupilZone, 0.0),
            (-pupilZone, 0.0)
        };
        var directions = new Vector3D[pupil.Length];
        for (var index = 0; index < pupil.Length; index++)
        {
            var item = pupil[index];
            var bundle = optic.SequentialRayTracer.RayGenerator.GenerateGeneric(
                field.Hx,
                field.Hy,
                item.Item1,
                item.Item2,
                wavelength.Micrometers,
                aimAtStop);
            // These probes define the diffraction coordinate scale, not pupil
            // transmission. Wavefront/Jones sampling still applies every aperture.
            var sample = optic.SequentialRayTracer.TraceToSurface(
                bundle.Rays.Single(),
                optic.SurfaceGroup.Items.Count - 1);
            if (sample is null || sample.Vignetted || sample.Intensity <= 0)
            {
                return false;
            }

            directions[index] = sample.Direction;
        }
        var chief = directions[0];
        var imageIndex = optic.SurfaceGroup.Items[^1].MaterialAfter.RefractiveIndex(wavelength.Nanometers);
        double DirectionalFNumber(IEnumerable<Vector3D> marginalDirections)
        {
            var numericalApertures = marginalDirections.Select(direction =>
            {
                if (strict)
                    return imageIndex * optic.Backend.Current.Cross(chief, direction).Length
                        / (chief.Length * direction.Length * pupilZone);
                var dot = Math.Clamp(
                    (chief.X * direction.X) + (chief.Y * direction.Y) + (chief.Z * direction.Z),
                    -1,
                    1);
                var angle = Math.Acos(dot);
                return imageIndex * Math.Sin(angle) / pupilZone;
            }).ToArray();
            var equivalentNumericalAperture = zemaxDirectionalAverage
                ? numericalApertures.Average()
                : Math.Sqrt(numericalApertures.Average(value => value * value));
            if (strict)
            {
                if (!double.IsFinite(equivalentNumericalAperture) || equivalentNumericalAperture <= 0)
                    throw new InvalidOperationException("像方数值孔径必须为正有限值。");
                var value = 1 / (2 * equivalentNumericalAperture);
                return double.IsFinite(value) ? value : throw new InvalidOperationException("工作 F 数不是有限值。");
            }
            return equivalentNumericalAperture <= 0
                ? 10000
                : Math.Min(10000, 1 / (2 * equivalentNumericalAperture));
        }

        axes = (
            DirectionalFNumber(directions.Skip(1).Take(2)),
            DirectionalFNumber(directions.Skip(3).Take(2)));
        return true;
    }

    /// <summary>Shared unshifted DFT; inverse includes the 1/N² normalization.</summary>
    internal static void FourierTransform2D(Complex[,] data, bool inverse = false)
    {
        ArgumentNullException.ThrowIfNull(data);
        var size = data.GetLength(0);
        if (size != data.GetLength(1)) throw new ArgumentException("Fourier grid must be square.", nameof(data));
        AnalysisResourceLimits.ValidateFftGrid(size, size);
        if (inverse)
            for (var row = 0; row < size; row++)
                for (var column = 0; column < size; column++)
                    data[row, column] = Complex.Conjugate(data[row, column]);
        Fft2D(data);
        if (inverse)
            for (var row = 0; row < size; row++)
                for (var column = 0; column < size; column++)
                    data[row, column] = Complex.Conjugate(data[row, column]) / ((double)size * size);
    }

    private static void Fft2D(Complex[,] data)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        var size = data.GetLength(0);
        var buffer = new Complex[size];
        for (var row = 0; row < size; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var column = 0; column < size; column++)
            {
                buffer[column] = data[row, column];
            }

            Fft(buffer);
            for (var column = 0; column < size; column++)
            {
                data[row, column] = buffer[column];
            }
        }

        for (var column = 0; column < size; column++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var row = 0; row < size; row++)
            {
                buffer[row] = data[row, column];
            }

            Fft(buffer);
            for (var row = 0; row < size; row++)
            {
                data[row, column] = buffer[row];
            }
        }
    }

    private static void Transform2D(Complex[,] data)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        var size = data.GetLength(0);
        AnalysisResourceLimits.ValidateMtfTransformWork(size);
        if (IsPowerOfTwo(size))
        {
            Fft2D(data);
            return;
        }

        // The separable DFT keeps the requested sampling exactly, while reducing
        // the direct transform from N^4 terms to 2*N^3 terms.
        var buffer = new Complex[size];
        var transformed = new Complex[size];
        for (var row = 0; row < size; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var column = 0; column < size; column++) buffer[column] = data[row, column];
            DirectTransform(buffer, transformed);
            for (var column = 0; column < size; column++) data[row, column] = transformed[column];
        }
        for (var column = 0; column < size; column++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var row = 0; row < size; row++) buffer[row] = data[row, column];
            DirectTransform(buffer, transformed);
            for (var row = 0; row < size; row++) data[row, column] = transformed[row];
        }
    }

    private static void DirectTransform(Complex[] input, Complex[] output)
    {
        for (var frequency = 0; frequency < input.Length; frequency++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var sum = Complex.Zero;
            for (var index = 0; index < input.Length; index++)
                sum += input[index] * Complex.FromPolarCoordinates(1, -2 * Math.PI * frequency * index / input.Length);
            output[frequency] = sum;
        }
    }

    private static Complex[,] CreateUniformPupil(WavefrontResult wavefront, int numRays)
    {
        var pupil = new Complex[numRays, numRays];
        var valid = wavefront.Samples.Where(sample => sample.Intensity > 0).ToArray();
        var meanIntensity = valid.Select(sample => sample.Intensity).DefaultIfEmpty(0).Average();
        foreach (var sample in wavefront.Samples)
        {
            var column = (int)Math.Round((sample.NormalizedPupilX + 1) / 2 * (numRays - 1));
            var row = (int)Math.Round((sample.NormalizedPupilY + 1) / 2 * (numRays - 1));
            var relativePower = meanIntensity <= 1e-30 ? 0 : sample.Intensity / meanIntensity;
            var amplitude = FieldAmplitudeFromPower(relativePower);
            var phase = -2 * Math.PI * sample.OpdWaves;
            pupil[row, column] = Complex.FromPolarCoordinates(amplitude, phase);
        }

        return pupil;
    }

    private static Vector3D[,] CreateHuygensImageCoordinates(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        int imageSize,
        double pixelPitchMillimeters,
        bool aimAtStop = false) => CreateHuygensImageCoordinatesAtCenter(
            optic, field, wavelength, imageSize, pixelPitchMillimeters, aimAtStop);

    private static Vector3D[,] CreateHuygensImageCoordinatesAtCenter(
        Optic optic,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        int imageSize,
        double pixelPitchMillimeters,
        bool aimAtStop = false,
        (double X, double Y)? imageCenterOffset = null)
    {
        var frame = CreateHuygensImageFrame(optic, field, wavelength, aimAtStop);
        var coordinates = new Vector3D[imageSize, imageSize];
        var centerIndex = imageSize / 2;
        for (var row = 0; row < imageSize; row++)
        {
            var y = (row - centerIndex) * pixelPitchMillimeters + (imageCenterOffset?.Y ?? 0);
            for (var column = 0; column < imageSize; column++)
            {
                var x = (column - centerIndex) * pixelPitchMillimeters + (imageCenterOffset?.X ?? 0);
                coordinates[row, column] = frame.Center + (frame.TangentX * x) + (frame.TangentY * y);
            }
        }
        return coordinates;
    }

    public static HuygensImageFrame CreateHuygensImageFrame(
        Optic optic, (double Hx, double Hy) field, Wavelength wavelength, bool aimAtStop = false)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        var imageSurface = optic.SurfaceGroup.Items[^1];
        var chiefBundle = optic.SequentialRayTracer.RayGenerator.GenerateGeneric(
            field.Hx,
            field.Hy,
            0,
            0,
            wavelength.Micrometers,
            aimAtStop: aimAtStop);
        var chief = optic.SequentialRayTracer.TraceFinalSamples(chiefBundle).SingleOrDefault()
            ?? throw new InvalidOperationException("Chief ray did not reach the image surface.");
        var center = chief.Position;
        var localCenter = imageSurface.CoordinateSystem.ToLocalPoint(center);
        var localNormal = imageSurface.Geometry.SurfaceNormal(localCenter);
        var normal = Normalize(imageSurface.CoordinateSystem.ToGlobalDirection(localNormal));
        var imageLocalX = imageSurface.CoordinateSystem.ToGlobalDirection(new Vector3D(1, 0, 0));
        var tangentX = imageLocalX - (normal * Dot(imageLocalX, normal));
        if (tangentX.Length <= 1e-12)
        {
            tangentX = new Vector3D(1, 0, 0) - (normal * normal.X);
        }

        tangentX = Normalize(tangentX);
        var tangentY = Normalize(Cross(normal, tangentX));
        return new HuygensImageFrame(center, tangentX, tangentY);
    }

    // Offset from the reference chief ray in the image grid's physical units:
    // millimeters for a focal image, milliradians for an afocal image.
    internal static (double X, double Y) HuygensGeometricCenterOffset(
        Optic optic,
        (double Hx, double Hy) field,
        IReadOnlyList<Wavelength> wavelengths,
        Wavelength referenceWavelength,
        int pupilSampling,
        bool aimAtStop)
    {
        var imageSurface = optic.SurfaceGroup.Items[^1];
        var frame = CreateHuygensImageFrame(optic, field, referenceWavelength, aimAtStop);
        var chiefAngle = optic.ImageSpaceAfocal
            ? ImageSpaceAnalysisSupport.DirectionAnglesMilliradians(imageSurface,
                (optic.TraceGenericFinalSample(field.Hx, field.Hy, 0, 0,
                    referenceWavelength.Micrometers, aimAtStop)
                    ?? throw new InvalidOperationException("Chief ray did not reach the image surface.")).Direction)
            : (X: 0.0, Y: 0.0);
        var pupilSamples = !optic.ImageSpaceAfocal && pupilSampling >= 8 && pupilSampling % 2 == 0
            ? HuygensPupilSamples(pupilSampling) : SpotAnalysisEngine.CreatePupilSamples(pupilSampling, "uniform");
        var useWeights = wavelengths.Any(wavelength => wavelength.Weight > 0);
        var projected = new List<SpotRayData>();
        foreach (var wavelength in wavelengths)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            if (useWeights && wavelength.Weight <= 0) continue;
            var bundle = optic.SequentialRayTracer.RayGenerator.GenerateNormalizedPupilSamples(
                field.Hx, field.Hy, wavelength.Micrometers, pupilSamples, aimAtStop: aimAtStop);
            var samples = optic.SequentialRayTracer.TraceFinalSamples(bundle);
            for (var index = 0; index < samples.Count; index++)
            {
                if (samples[index] is not { Vignetted: false, Intensity: > 0 } sample) continue;
                var delta = sample.Position - frame.Center;
                var coordinates = optic.ImageSpaceAfocal
                    ? ImageSpaceAnalysisSupport.DirectionAnglesMilliradians(imageSurface, sample.Direction)
                    : (X: Dot(delta, frame.TangentX), Y: Dot(delta, frame.TangentY));
                var weight = bundle.Rays[index].Intensity * (useWeights ? Math.Max(0, wavelength.Weight) : 1);
                if (double.IsFinite(coordinates.X) && double.IsFinite(coordinates.Y)
                    && double.IsFinite(weight) && weight > 0)
                    projected.Add(new SpotRayData(coordinates.X - chiefAngle.X,
                        coordinates.Y - chiefAngle.Y, weight));
            }
        }
        if (projected.Count == 0)
            throw new AnalysisDataUnavailableException("Huygens PSF", "no valid geometric centroid rays");
        return SpotAnalysisEngine.Centroid(projected);
    }

    private static double[,] HuygensFarFieldSummation(
        WavefrontResult wavefront,
        Wavelength wavelength,
        int imageSize,
        double angularPixelPitchMilliradians,
        bool idealOpd,
        JonesPupilResult? polarization = null,
        double defocus = 0,
        (double X, double Y)? imageCenterOffset = null)
    {
        var psf = new double[imageSize, imageSize];
        var pupilDiameter = wavefront.AfocalPupilDiameterMillimeters;
        if (pupilDiameter <= 1e-30)
        {
            return psf;
        }

        var pupilRadius = pupilDiameter / 2.0;
        var wavelengthMillimeters = wavelength.Micrometers * 1e-3;
        var k = 2 * Math.PI / wavelengthMillimeters;
        var propagationK = k * wavefront.ImageRefractiveIndex;
        var centerIndex = imageSize / 2;
        var polarizationByPupil = polarization?.Samples.ToDictionary(
            sample => (
                X: (long)Math.Round(sample.Px * 1_000_000_000),
                Y: (long)Math.Round(sample.Py * 1_000_000_000)),
            PolarizationAmplitude);
        for (var row = 0; row < imageSize; row++)
        {
            var thetaY = ((row - centerIndex) * angularPixelPitchMilliradians
                + (imageCenterOffset?.Y ?? 0)) / 1_000.0;
            for (var column = 0; column < imageSize; column++)
            {
                ComputationCancellation.ThrowIfCancellationRequested();
                var thetaX = ((column - centerIndex) * angularPixelPitchMilliradians
                    + (imageCenterOffset?.X ?? 0)) / 1_000.0;
                var field = Complex.Zero;
                var sampleIndex = 0;
                foreach (var sample in wavefront.Samples)
                {
                    if ((sampleIndex++ & 255) == 0) ComputationCancellation.ThrowIfCancellationRequested();
                    if (sample.Intensity <= 0)
                    {
                        continue;
                    }

                    var pupilX = sample.NormalizedPupilX * pupilRadius;
                    var pupilY = sample.NormalizedPupilY * pupilRadius;
                    var opdWaves = idealOpd
                        ? 0
                        : sample.OpdWaves
                            + ImageSpaceAnalysisSupport.AfocalDefocusOpdWaves(
                                sample,
                                wavelength,
                                defocus,
                                pupilDiameter);
                    var pupilPhase = -k * opdWaves * wavelengthMillimeters;
                    // OPD is already an optical path; only the geometric
                    // propagation term needs the image-medium index.
                    var anglePhase = -propagationK * ((pupilX * thetaX) + (pupilY * thetaY));
                    var polarizationAmplitude = polarizationByPupil?.GetValueOrDefault((
                        (long)Math.Round(sample.NormalizedPupilX * 1_000_000_000),
                        (long)Math.Round(sample.NormalizedPupilY * 1_000_000_000))) ?? 1;
                    var sampleAmplitude = FieldAmplitudeFromPower(sample.Intensity);
                    field += sampleAmplitude
                        * polarizationAmplitude
                        * Complex.FromPolarCoordinates(1, pupilPhase + anglePhase);
                }

                psf[row, column] = field.Magnitude * field.Magnitude;
            }
        }

        return psf;

        static double PolarizationAmplitude(JonesPupilSample sample)
        {
            if (!sample.IsValid)
            {
                return 0;
            }

            var power = (
                (sample.Jxx.Magnitude * sample.Jxx.Magnitude)
                + (sample.Jxy.Magnitude * sample.Jxy.Magnitude)
                + (sample.Jyx.Magnitude * sample.Jyx.Magnitude)
                + (sample.Jyy.Magnitude * sample.Jyy.Magnitude)) / 2;
            return Math.Sqrt(Math.Max(0, power));
        }
    }

    private static double[,] HuygensSummation(
        Vector3D[,] imageCoordinates,
        WavefrontResult wavefront,
        Wavelength wavelength,
        bool idealOpd,
        JonesPupilResult? polarization = null)
    {
        var rows = imageCoordinates.GetLength(0);
        var columns = imageCoordinates.GetLength(1);
        var psf = new double[rows, columns];
        var wavelengthMillimeters = wavelength.Micrometers * 1e-3;
        var k = 2 * Math.PI / wavelengthMillimeters;
        var propagationK = k * wavefront.ImageRefractiveIndex;
        var radius = wavefront.Radius;
        var polarizationByPupil = polarization?.Samples.ToDictionary(
            sample => (
                X: (long)Math.Round(sample.Px * 1_000_000_000),
                Y: (long)Math.Round(sample.Py * 1_000_000_000)),
            PolarizationAmplitude);
        foreach (var row in Enumerable.Range(0, rows))
        {
            for (var column = 0; column < columns; column++)
            {
                ComputationCancellation.ThrowIfCancellationRequested();
                var image = imageCoordinates[row, column];
                var field = Complex.Zero;
                var sampleIndex = 0;
                foreach (var sample in wavefront.Samples)
                {
                    if ((sampleIndex++ & 255) == 0) ComputationCancellation.ThrowIfCancellationRequested();
                    var pupil = new Vector3D(sample.PupilX, sample.PupilY, sample.PupilZ);
                    var delta = image - pupil;
                    var distance = delta.Length;
                    if (distance <= 1e-300)
                    {
                        continue;
                    }

                    // Wavelength and index use the same reference medium.
                    // Do not apply this index again to the optical OPD below.
                    var wave = Complex.FromPolarCoordinates(1 / distance, propagationK * distance);
                    // Retain the existing scalar weight in the lens datum frame,
                    // not in an arbitrary global frame. A reference-sphere-normal
                    // or native planar/spherical propagator is a different model
                    // and still needs independent numerical certification.
                    var localPupil = pupil - wavefront.HuygensCoordinateOrigin;
                    var obliquity = 0.5 * (1 + Dot(delta, localPupil / radius) / distance);
                    var opd = idealOpd ? 0 : sample.OpdWaves * wavelengthMillimeters;
                    var pupilPhase = Complex.FromPolarCoordinates(1, -k * opd);
                    var polarizationAmplitude = polarizationByPupil?.GetValueOrDefault((
                        (long)Math.Round(sample.NormalizedPupilX * 1_000_000_000),
                        (long)Math.Round(sample.NormalizedPupilY * 1_000_000_000))) ?? 1;
                    var sampleAmplitude = FieldAmplitudeFromPower(sample.Intensity);
                    field += sampleAmplitude * polarizationAmplitude * pupilPhase * wave * obliquity;
                }

                psf[row, column] = field.Magnitude * field.Magnitude;
            }
        }

        return psf;

        static double PolarizationAmplitude(JonesPupilSample sample)
        {
            if (!sample.IsValid)
            {
                return 0;
            }

            var power = (
                (sample.Jxx.Magnitude * sample.Jxx.Magnitude)
                + (sample.Jxy.Magnitude * sample.Jxy.Magnitude)
                + (sample.Jyx.Magnitude * sample.Jyx.Magnitude)
                + (sample.Jyy.Magnitude * sample.Jyy.Magnitude)) / 2;
            return Math.Sqrt(Math.Max(0, power));
        }
    }


    private static double Dot(Vector3D left, Vector3D right)
    {
        return (left.X * right.X) + (left.Y * right.Y) + (left.Z * right.Z);
    }

    private static Vector3D Cross(Vector3D left, Vector3D right)
    {
        return new Vector3D(
            (left.Y * right.Z) - (left.Z * right.Y),
            (left.Z * right.X) - (left.X * right.Z),
            (left.X * right.Y) - (left.Y * right.X));
    }

    private static Vector3D Normalize(Vector3D value)
    {
        var length = value.Length;
        return length <= 1e-30 ? new Vector3D(0, 0, 1) : value / length;
    }

    private static void Fft(Complex[] values)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        var count = values.Length;
        for (int index = 1, reversed = 0; index < count; index++)
        {
            var bit = count >> 1;
            for (; (reversed & bit) != 0; bit >>= 1)
            {
                reversed ^= bit;
            }

            reversed ^= bit;
            if (index < reversed)
            {
                (values[index], values[reversed]) = (values[reversed], values[index]);
            }
        }

        for (var length = 2; length <= count; length <<= 1)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var root = Complex.FromPolarCoordinates(1, -2 * Math.PI / length);
            for (var start = 0; start < count; start += length)
            {
                var factor = Complex.One;
                for (var offset = 0; offset < length / 2; offset++)
                {
                    var even = values[start + offset];
                    var odd = values[start + offset + (length / 2)] * factor;
                    values[start + offset] = even + odd;
                    values[start + offset + (length / 2)] = even - odd;
                    factor *= root;
                }
            }
        }
    }

    private static Complex[,] FftShift(Complex[,] source)
    {
        var size = source.GetLength(0);
        var shifted = new Complex[size, size];
        var half = (size + 1) / 2;
        for (var row = 0; row < size; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var column = 0; column < size; column++)
            {
                shifted[row, column] = source[(row + half) % size, (column + half) % size];
            }
        }

        return shifted;
    }

    private static bool IsPowerOfTwo(int value)
    {
        return value > 0 && (value & (value - 1)) == 0;
    }
}
