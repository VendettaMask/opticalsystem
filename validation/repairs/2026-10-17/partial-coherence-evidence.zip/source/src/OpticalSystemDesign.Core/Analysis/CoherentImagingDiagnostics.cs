namespace OpticalSystemDesign.Core.Analysis;

public sealed record CoherentImagingDiagnostics(double SpatialCoherence, int FourierGridSize,
    double DetectorPixelPitchMillimeters, double MinimumKernelCapturedFraction, string SourcePhaseModel)
{
    public const string Pipeline = "Complex pupil transfer + uniform spatial mutual-intensity propagation";

    internal void AddValues(IDictionary<string, object> values)
    {
        values["Coherence"] = SpatialCoherence;
        values["CoherenceModel"] = "W_ij = (1-gamma) I_i delta_ij + gamma sqrt(I_i I_j) exp(i(phi_i-phi_j))";
        values["CoherentFieldModel"] = "Scalar isoplanatic, one reference pupil per wavelength; no geometric distortion or lateral-color warp";
        values["ObjectSamplingModel"] = "Band-limited sampled object in image-scaled coordinates; wavelengths mutually incoherent";
        values["IntensityNormalization"] = "Unit maximum pupil amplitude; no kernel or output renormalization";
        values["IntensityUnits"] = "Relative linear intensity, not absolute watts; values above one are retained";
        values["ScalarTransmissionModel"] = "Traced OPD phase and power amplitude (including bulk absorption); no vector interface or thin-film phase model";
        values["SourcePhaseModel"] = SourcePhaseModel;
        values["FourierGridSize"] = FourierGridSize;
        values["DetectorPixelPitchMillimeters"] = DetectorPixelPitchMillimeters;
        values["MinimumKernelCapturedFraction"] = MinimumKernelCapturedFraction;
        values["FieldGrid"] = "1 x 1 (isoplanatic)";
    }
}
