$ErrorActionPreference = 'Stop'
$taskDirectory = 'artifacts/validation/partial-coherence-20261017'
$taskRoot = (Get-Location).Path
function Read-TaskRun([string]$Path) {
    [xml]$taskXml = Get-Content $Path -Raw
    $taskCounters = $taskXml.TestRun.ResultSummary.Counters
    $taskResults = @($taskXml.TestRun.Results.UnitTestResult)
    [ordered]@{ path = $Path; total = [int]$taskCounters.total; passed = [int]$taskCounters.passed
        failed = [int]$taskCounters.failed; skipped = [int]$taskCounters.notExecuted
        names = @($taskResults.testName | Sort-Object)
        newTests = @($taskResults | Where-Object testName -Like '*PartiallyCoherentImagingTests*').Count }
}
$taskRelease = Read-TaskRun "$taskDirectory/final/related-release-final.trx"
$taskDebug = Read-TaskRun "$taskDirectory/final/related-debug-final.trx"
foreach ($taskRun in @($taskRelease, $taskDebug)) {
    if ($taskRun.total -ne 338 -or $taskRun.passed -ne 338 -or $taskRun.failed -ne 0 -or $taskRun.skipped -ne 0 -or $taskRun.newTests -ne 47) { throw 'Incomplete final regression' }
}
if (($taskRelease.names -join "`n") -cne ($taskDebug.names -join "`n")) { throw 'Final test names differ' }
$taskFirst = Read-TaskRun "$taskDirectory/first/first-release.trx"
if ($taskFirst.total -ne 27 -or $taskFirst.failed -ne 7) { throw 'Initial failure evidence missing' }
$taskFailedRelated = foreach ($taskConfiguration in @('release', 'debug')) {
    $taskRun = Read-TaskRun "$taskDirectory/final/related-$taskConfiguration.trx"
    if ($taskRun.total -ne 333 -or $taskRun.failed -ne 1) { throw 'Old assertion failure evidence missing' }
    $taskRun
}
$taskControlsR = Get-Content "$taskDirectory/controls-release-final.json" -Raw | ConvertFrom-Json
$taskControlsD = Get-Content "$taskDirectory/controls-debug-final.json" -Raw | ConvertFrom-Json
foreach ($taskName in @('Interference', 'PrimaryLens', 'SourceBlendMaximumError', 'PrimaryLensCoherentVsIncoherentDifference', 'PrimaryLensSuppliedPhaseDifference')) {
    if (($taskControlsR.$taskName | ConvertTo-Json -Depth 12 -Compress) -cne ($taskControlsD.$taskName | ConvertTo-Json -Depth 12 -Compress)) { throw "Cross-configuration control differs: $taskName" }
}
if (($taskControlsR.Interference.Error | Measure-Object -Maximum).Maximum -gt 1e-12 -or
    $taskControlsR.PrimaryLensCoherentVsIncoherentDifference -lt 1e-5 -or $taskControlsR.PrimaryLensSuppliedPhaseDifference -lt 1e-5 -or
    $taskControlsR.SourceBlendMaximumError -lt .1) { throw 'Physical interference controls not satisfied' }
$taskOldFft = Get-Content "$taskDirectory/compatibility-old.json" -Raw | ConvertFrom-Json
$taskNewFft = Get-Content "$taskDirectory/compatibility-new-final.json" -Raw | ConvertFrom-Json
if ($taskOldFft.Records.Count -ne 24 -or ($taskOldFft.Records | ConvertTo-Json -Depth 8 -Compress) -cne ($taskNewFft.Records | ConvertTo-Json -Depth 8 -Compress)) { throw 'Original FFT outputs changed' }
if ($taskOldFft.CoreSha256 -ne '8fa7f0b301b2e75d3f94f53785d5a293a679a01c2034522b2367b7b472e87041') { throw 'Old Core identity changed' }
$taskPreserved = [ordered]@{
    'validation/repairs/2026-10-17/image-sampling-statistics-evidence.zip' = '22daf84d477f762a2129d8a7d2c56a9c60f1ce0ac8de88ec0156b19672b3473c'
    'validation/repairs/2026-10-17/image-psf-safety-evidence.zip' = '042f1a564379bad9b1be57e5f2c9f8139616f9327074fcfabbbcee9437987a65'
    'validation/repairs/2026-10-17/product-image-audit-evidence.zip' = '252b9e2c236698a57130e82da28aba409fff10403fa5ff061d3e33f63b7aedd9'
    'validation/repairs/2026-10-16/illumination-inverse-evidence.zip' = 'bcd5df8b59d0e7437c906503e4b4cbfc514fbe032f09f90595236a845c2657bb'
    'validation/repairs/2026-10-16/illumination-finite-grid-evidence.zip' = 'a137625a22a2e7e333f637b17e2117b3602569add648b60445e09f8782d3e83d'
    'validation/repairs/2026-10-16/native-diffraction-adapter-evidence.zip' = 'e452e029523ac4c2a0f806a07fe3a4a05920371ff797a04de4d503e81bfc2a6c'
    'artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX' = '0cd65a2f823baf5079f20f91d8310765899a182a6be72ddac53ede943f2bf75b'
}
foreach ($taskPath in $taskPreserved.Keys) {
    if ((Get-FileHash $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskPreserved[$taskPath]) { throw "Preserved evidence changed: $taskPath" }
}
$taskConfigurations = foreach ($taskConfiguration in @('Debug', 'Release')) {
    $taskCore = "src/OpticalSystemDesign.Core/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll"
    $taskHash = (Get-FileHash $taskCore -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskCopies = @("src/OpticalSystemDesign.App/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll", "tests/OpticalSystemDesign.Tests/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll")
    foreach ($taskCopy in $taskCopies) { if ((Get-FileHash $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskHash) { throw "Default Core mismatch: $taskCopy" } }
    $taskControl = if ($taskConfiguration -eq 'Debug') { $taskControlsD } else { $taskControlsR }
    if ($taskControl.CoreSha256 -ne $taskHash) { throw 'Physical probe used stale Core' }
    if ($taskConfiguration -eq 'Release' -and $taskNewFft.CoreSha256 -ne $taskHash) { throw 'FFT probe used stale Core' }
    $taskBuild = Get-Content "$taskDirectory/build-$($taskConfiguration.ToLowerInvariant())-final.log" -Raw
    $taskProjects = @([regex]::Matches($taskBuild, '(?m)^\s+(\S+) -> ') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
    if ($taskProjects.Count -ne 19 -or $taskBuild -notmatch '0 个警告' -or $taskBuild -notmatch '0 个错误') { throw 'Root build incomplete' }
    [ordered]@{ configuration = $taskConfiguration; projectCount = 19; projects = $taskProjects; warnings = 0; errors = 0
        corePath = $taskCore; coreSha256 = $taskHash; matchingCopies = $taskCopies }
}
$taskSourcePaths = @((git diff --name-only -- '*.cs'), (git ls-files --others --exclude-standard -- '*.cs')) | ForEach-Object { $_ } | Sort-Object -Unique
if ($taskSourcePaths.Count -ne 19) { throw 'Unexpected changed-code inventory' }
$taskSources = foreach ($taskPath in $taskSourcePaths) { [ordered]@{ path = $taskPath; sha256 = (Get-FileHash $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() } }
$taskProof = [ordered]@{
    date = '2026-10-17'; sourceBaseCommit = (git rev-parse HEAD).Trim(); status = 'Uniform discrete spatial mutual-intensity imaging implemented and verified'
    model = [ordered]@{ coherence = 'W_ij=(1-gamma)I_i delta_ij + gamma a_i conjugate(a_j)'; propagation = '(1-gamma)(|h|^2 * I) + gamma |h*a|^2'
        opticalScope = 'Scalar isoplanatic, one complex reference pupil per wavelength; relative fixed peak-pupil scale'
        statisticalSampling = 'Source covariance defined on prepared sample grid; fixed continuous coherence area under oversampling is not implemented'
        limitations = @('No arbitrary source covariance, field-dependent coherent imaging, full vector/coating phase or afocal support', 'No new same-settings Zemax image certification') }
    sources = @($taskSources); configurations = @($taskConfigurations)
    tests = [ordered]@{ finalRelease = $taskRelease; finalDebug = $taskDebug; first = $taskFirst; firstRelated = @($taskFailedRelated)
        newTestCount = 47; previousBoundaryAssertionsUpgraded = 4; noFullSuite = $true; noEfnoReliMatrixRerun = $true; noNativeCapture = $true }
    controls = [ordered]@{ release = $taskControlsR; debug = $taskControlsD; crossConfigurationValuesEqual = $true }
    legacyFft = [ordered]@{ old = $taskOldFft; current = $taskNewFft; exactArrayHashCases = 24; recordsEqual = $true }
    preservedSha256 = $taskPreserved
    formatVerifiedCodeFiles = 19; documentationReportIncluded = (Test-Path "$taskDirectory/documentation-verification.json")
    delivery = 'Default Debug/Release App updated; no installer, commit or push'
}
$taskProof | ConvertTo-Json -Depth 30 | Set-Content "$taskDirectory/proof.json" -Encoding utf8
$taskEntries = @(Get-ChildItem $taskDirectory -Recurse -File | Where-Object { $_.FullName -notmatch '[\\/](bin|obj)[\\/]' -and $_.Extension -in @('.cs', '.csproj', '.json', '.log', '.ps1', '.trx', '.txt') } | ForEach-Object {
    [pscustomobject]@{ path = [IO.Path]::GetRelativePath($taskRoot, $_.FullName).Replace('\','/'); entry = [IO.Path]::GetRelativePath((Join-Path $taskRoot $taskDirectory), $_.FullName).Replace('\','/') }
})
$taskEntries += @($taskSourcePaths | ForEach-Object { [pscustomobject]@{ path = $_; entry = "source/$_" } })
$taskArchivePath = 'validation/repairs/2026-10-17/partial-coherence-evidence.zip'
$taskStream = [IO.File]::Open($taskArchivePath, [IO.FileMode]::Create)
$taskArchive = [IO.Compression.ZipArchive]::new($taskStream, [IO.Compression.ZipArchiveMode]::Create)
try { foreach ($taskEntry in $taskEntries) { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskArchive, (Join-Path $taskRoot $taskEntry.path), $taskEntry.entry, [IO.Compression.CompressionLevel]::Optimal) } }
finally { $taskArchive.Dispose(); $taskStream.Dispose() }
$taskArchive = [IO.Compression.ZipFile]::OpenRead((Join-Path $taskRoot $taskArchivePath))
try {
    $taskManifest = foreach ($taskEntry in $taskEntries) {
        $taskStream = $taskArchive.GetEntry($taskEntry.entry).Open()
        try { $taskHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($taskStream)).ToLowerInvariant() } finally { $taskStream.Dispose() }
        if ($taskHash -ne (Get-FileHash $taskEntry.path -Algorithm SHA256).Hash.ToLowerInvariant()) { throw 'Archive readback mismatch' }
        [ordered]@{ path = $taskEntry.path; entry = $taskEntry.entry; sha256 = $taskHash }
    }
} finally { $taskArchive.Dispose() }
$taskLedger = [ordered]@{ date = '2026-10-17'; sourceBaseCommit = $taskProof.sourceBaseCommit; status = $taskProof.status
    evidence = [ordered]@{ path = $taskArchivePath; sha256 = (Get-FileHash $taskArchivePath -Algorithm SHA256).Hash.ToLowerInvariant(); bytes = (Get-Item $taskArchivePath).Length
        entryCount = $taskEntries.Count; allEntriesReadbackVerified = $true; files = @($taskManifest) }
    model = $taskProof.model; tests = $taskProof.tests; configurations = $taskProof.configurations; preservedSha256 = $taskPreserved; delivery = $taskProof.delivery }
$taskLedger | ConvertTo-Json -Depth 30 | Set-Content 'docs/validation/PARTIAL_COHERENCE_IMPLEMENTATION_2026-10-17.json' -Encoding utf8
[pscustomobject]$taskLedger.evidence | Select-Object path, sha256, bytes, entryCount, allEntriesReadbackVerified | ConvertTo-Json
