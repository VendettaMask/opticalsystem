using System.Numerics;
using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);
var output=Path.GetFullPath(args[1]);
var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(repo,"artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX")),".zmx");
using var fixture=JsonDocument.Parse(File.ReadAllText(Path.Combine(repo,"tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-zemax-2026-r1.json")));
var rows=new List<object>();
foreach(var c in fixture.RootElement.GetProperty("Cases").EnumerateArray()){
 var name=c.GetProperty("Name").GetString()!;var os=c.GetProperty("Oversampling").GetInt32();
 var source=new double[1,16,16];var negative=c.GetProperty("SourceKind").GetString()=="Negative";
 source[0,8,negative?6:7]=1;source[0,8,negative?9:8]=1d/3;
 var alpha=c.GetProperty("Alpha").GetDouble();var function=c.GetProperty("Function").GetString()!;var wave=c.GetProperty("Wavelength").GetDouble();
 var config=new ImageSimulationConfig{
 AberrationMode="Partially Coherent",PsfGridRows=1,PsfGridColumns=1,NumRays=256,PsfSize=os==1?65:129,
 UseRelativeIllumination=false,WavelengthsMicrometers=[wave],Oversampling=os,Padding=8*os,
#if BEFORE
 SpatialCoherence=.5,PixelSizeMillimeters=.0005/os
#else
 CoherenceFunction=Enum.Parse<SpatialCoherenceFunction>(function),CoherenceAlphaMillimeters=alpha,
 FileSizeMillimeters=.008,NormalizeImagePeak=true
#endif
 };
 var result=ImageSimulationEngine.Simulate(optic,new RgbImage(source),config);var native=c.GetProperty("Values");
 var peak=result.MaximumValue;double max=0,sq=0;int iy=0,ix=0;var n=result.Simulated.Width;
 for(var y=0;y<n;y++)for(var x=0;x<n;x++){
  var d=result.Simulated[0,y,x]/peak-native[n-1-y][x].GetDouble();sq+=d*d;
  if(Math.Abs(d)>max){max=Math.Abs(d);iy=y;ix=x;}
 }
 rows.Add(new{name,function,alpha,wave,oversampling=os,n,pixelPitch=result.CoherentImaging!.DetectorPixelPitchMillimeters,max,rms=Math.Sqrt(sq/(n*n)),iy,ix});
}
var boundaryRows=new List<object>();
#if !BEFORE
var nativeRoot=Path.Combine(repo,"artifacts/validation/partial-coherence-native-20261017");
using(var requests=JsonDocument.Parse(File.ReadAllText(Path.Combine(nativeRoot,"spatial-boundary-requests.json"))))foreach(var request in requests.RootElement.EnumerateArray()){
 var name=request.GetProperty("name").GetString()!;var lines=File.ReadAllLines(request.GetProperty("file").GetString()!);
 var source=new double[1,16,16];for(var y=0;y<16;y++)for(var x=0;x<16;x++)source[0,y,x]=(lines[y+1][x]-'0')/9d;
 var changes=request.GetProperty("changes").EnumerateArray().ToArray();var alpha=changes.Single(c=>c.GetProperty("offset").GetInt32()==808).GetProperty("number").GetDouble();
 var function=changes.Single(c=>c.GetProperty("offset").GetInt32()==792).GetProperty("integer").GetInt32()==0?SpatialCoherenceFunction.Gaussian:SpatialCoherenceFunction.Sinc;
 var result=ImageSimulationEngine.Simulate(optic,new RgbImage(source),new ImageSimulationConfig{AberrationMode="Partially Coherent",CoherenceFunction=function,CoherenceAlphaMillimeters=alpha,FileSizeMillimeters=.008,NormalizeImagePeak=true,UseRelativeIllumination=false,WavelengthsMicrometers=[.44],NumRays=256,PsfSize=65,PsfGridRows=1,PsfGridColumns=1,Padding=8});
 using var nativeDoc=JsonDocument.Parse(File.ReadAllText(Path.Combine(nativeRoot,"spatial-boundary-capture-v1",name,"data.json")));var native=nativeDoc.RootElement.GetProperty("Grids")[0].GetProperty("Values");double max=0,sq=0;
 for(var y=0;y<32;y++)for(var x=0;x<32;x++){var d=result.Simulated[0,y,x]-native[31-y][x].GetDouble();max=Math.Max(max,Math.Abs(d));sq+=d*d;}
 boundaryRows.Add(new{name,function=function.ToString(),alpha,max,rms=Math.Sqrt(sq/1024)});
}
#endif
var hash=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(ImageSimulationEngine).Assembly.Location))).ToLowerInvariant();
File.WriteAllText(output,JsonSerializer.Serialize(new{coreSha256=hash,cases=rows,boundaryCases=boundaryRows},new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine(JsonSerializer.Serialize(new{coreSha256=hash,count=rows.Count,output}));
