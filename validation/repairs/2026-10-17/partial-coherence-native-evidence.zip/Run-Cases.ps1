param([Parameter(Mandatory=$true)][string]$Requests, [Parameter(Mandatory=$true)][string]$OutputName)
$ErrorActionPreference = 'Stop'
$taskApi = 'D:\Program Files\ANSYS Inc\v261\Zemax OpticStudio'
$taskExe = Join-Path $PSScriptRoot 'NativeCoherenceCapture.exe'
$taskArgs = @('/nologo','/target:exe','/platform:x64',('/out:'+$taskExe),'/r:System.Web.Extensions.dll')
foreach ($taskName in @('ZOSAPI.dll','ZOSAPI_Interfaces.dll','ZOSAPI_NetHelper.dll')) { $taskArgs += '/r:' + (Join-Path $taskApi $taskName) }
$taskArgs += Join-Path $PSScriptRoot 'NativeCoherenceCapture.cs'
& (Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe') @taskArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$env:PATH = $taskApi + ';' + $env:PATH
& $taskExe $taskApi (Join-Path $PSScriptRoot 'source/123456.ZMX') (Join-Path $PSScriptRoot $OutputName) (Resolve-Path $Requests).Path
exit $LASTEXITCODE
