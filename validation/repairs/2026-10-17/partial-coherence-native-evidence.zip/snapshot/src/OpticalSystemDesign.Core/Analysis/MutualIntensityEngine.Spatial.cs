using System.Numerics;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Analysis;

public enum SpatialCoherenceFunction
{
    Uniform,
    Gaussian,
    Sinc
}

public static partial class MutualIntensityEngine
{
    /// <summary>Stationary complex degree of coherence in image-space millimeters.
    /// Sinc is signed: sin(pi x)/(pi x), rather than its magnitude or intensity.</summary>
    public static double EvaluateSpatialCoherence(SpatialCoherenceFunction function, double dxMillimeters,
        double dyMillimeters, double alphaMillimeters)
    {
        if (function is not (SpatialCoherenceFunction.Gaussian or SpatialCoherenceFunction.Sinc)
            || !double.IsFinite(dxMillimeters) || !double.IsFinite(dyMillimeters)
            || !double.IsFinite(alphaMillimeters) || alphaMillimeters <= 0)
            throw new ArgumentOutOfRangeException(nameof(alphaMillimeters));
        var x = dxMillimeters / alphaMillimeters;
        var y = dyMillimeters / alphaMillimeters;
        return function == SpatialCoherenceFunction.Gaussian
            ? Math.Exp(-(x * x + y * y)) : Sinc(x) * Sinc(y);
    }

    /// <summary>Exact finite sampled-source mutual-intensity sum, including complex response phase.
    /// No correlation truncation, peak fitting, or clipping of signed Sinc correlations is used.</summary>
    public static double[,] PropagateSpatialCoherence(double[,] sourceIntensity, Complex[,] impulseResponse,
        SpatialCoherenceFunction function, double alphaMillimeters, double pixelPitchMillimeters,
        double[,]? sourcePhaseRadians = null)
    {
        ComputationCancellation.ThrowIfCancellationRequested();
        ArgumentNullException.ThrowIfNull(sourceIntensity);
        ArgumentNullException.ThrowIfNull(impulseResponse);
        _ = EvaluateSpatialCoherence(function, 0, 0, alphaMillimeters);
        if (!double.IsFinite(pixelPitchMillimeters) || pixelPitchMillimeters <= 0)
            throw new ArgumentOutOfRangeException(nameof(pixelPitchMillimeters));
        var height = sourceIntensity.GetLength(0);
        var width = sourceIntensity.GetLength(1);
        var kh = impulseResponse.GetLength(0);
        var kw = impulseResponse.GetLength(1);
        AnalysisResourceLimits.ValidateImageDimensions(width, height, "Mutual-intensity source");
        AnalysisResourceLimits.ValidateImageDimensions(kw, kh, "Complex impulse response");
        if (sourcePhaseRadians is not null && (sourcePhaseRadians.GetLength(0) != height || sourcePhaseRadians.GetLength(1) != width))
            throw new ArgumentException("Source phase must match source intensity dimensions.", nameof(sourcePhaseRadians));
        double kernelPower = 0;
        foreach (var value in impulseResponse)
        {
            if (!double.IsFinite(value.Real) || !double.IsFinite(value.Imaginary))
                throw new ArgumentException("The complex impulse response must be finite.", nameof(impulseResponse));
            kernelPower += Power(value);
        }
        if (!double.IsFinite(kernelPower) || kernelPower <= 0)
            throw new AnalysisDataUnavailableException("Mutual Intensity", "a finite nonzero complex impulse response is required");
        var points = new List<(int Y, int X, Complex Amplitude)>();
        for (var y = 0; y < height; y++) for (var x = 0; x < width; x++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var intensity = sourceIntensity[y, x];
            var phase = sourcePhaseRadians?[y, x] ?? 0;
            if (!double.IsFinite(intensity) || intensity < 0 || !double.IsFinite(phase))
                throw new ArgumentException("Source intensity must be finite and nonnegative, and source phase finite.");
            if (intensity > 0) points.Add((y, x, Complex.FromPolarCoordinates(Math.Sqrt(intensity), phase)));
        }
        var count = points.Count;
        var work = (double)count * (count + 1) / 2 * width * height;
        if (work > AnalysisResourceLimits.MaximumImageSimulationConvolutionOperations)
            throw new ArgumentOutOfRangeException(nameof(sourceIntensity), "Exact spatial mutual-intensity propagation exceeds the image convolution work budget. Reduce the source sampling or active source area.");
        var correlations = new double[count][];
        for (var i = 0; i < count; i++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            correlations[i] = new double[i];
            for (var j = 0; j < i; j++)
                correlations[i][j] = EvaluateSpatialCoherence(function,
                    (points[i].X - points[j].X) * pixelPitchMillimeters,
                    (points[i].Y - points[j].Y) * pixelPitchMillimeters, alphaMillimeters);
        }
        var image = new double[height, width];
        var contributions = new Complex[count];
        var anchorY = (kh - 1) / 2;
        var anchorX = (kw - 1) / 2;
        for (var y = 0; y < height; y++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var x = 0; x < width; x++)
            {
                ComputationCancellation.ThrowIfCancellationRequested();
                double value = 0, absoluteSum = 0;
                for (var i = 0; i < count; i++)
                {
                    var py = y - points[i].Y + anchorY;
                    var px = x - points[i].X + anchorX;
                    var a = py >= 0 && py < kh && px >= 0 && px < kw
                        ? points[i].Amplitude * impulseResponse[py, px] : Complex.Zero;
                    contributions[i] = a;
                    var diagonal = Power(a);
                    value += diagonal;
                    absoluteSum += diagonal;
                    for (var j = 0; j < i; j++)
                    {
                        var b = contributions[j];
                        var term = 2 * correlations[i][j] * (a.Real * b.Real + a.Imaginary * b.Imaginary);
                        value += term;
                        absoluteSum += Math.Abs(term);
                    }
                }
                // A PSD covariance can only acquire a negative value through floating-point cancellation.
                if (!double.IsFinite(value) || !double.IsFinite(absoluteSum) || value < -1e-12 * absoluteSum)
                    throw new AnalysisDataUnavailableException("Mutual Intensity", "spatial propagation exceeded finite nonnegative intensity range");
                image[y, x] = Math.Max(0, value);
            }
        }
        return image;
    }

    private static double Sinc(double x) => x == 0 ? 1
        : double.IsFinite(x) && Math.Abs(x) <= double.MaxValue / Math.PI ? Math.Sin(Math.PI * x) / (Math.PI * x) : 0;
}
