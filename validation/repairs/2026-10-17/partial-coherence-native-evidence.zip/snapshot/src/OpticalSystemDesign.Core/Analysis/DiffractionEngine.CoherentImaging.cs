using System.Numerics;
using OpticalSystemDesign.Core.Coatings;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Analysis;

public sealed record CoherentImageKernel(Complex[,] Values, double PixelPitchMillimeters,
    int FourierGridSize, double CapturedPowerFraction, double KernelPower, double FullKernelPower);

public static partial class DiffractionEngine
{
    /// <summary>Scalar isoplanatic imaging of a band-limited sampled object. Retains the traced pupil OPD phase.
    /// The transfer pupil has unit maximum amplitude; neither the kernel nor output is renormalized.</summary>
    public static CoherentImageKernel ComputeCoherentImageKernel(Optic optic, (double Hx, double Hy) field,
        Wavelength wavelength, int pupilSampling, int kernelSize, double pixelPitchMillimeters,
        bool fourierConjugateSampling = false)
    {
        if (optic.ImageSpaceAfocal)
            throw new AnalysisDataUnavailableException("Partially Coherent Image", "finite image-space scalar imaging is required; afocal complex imaging is not implemented");
        if (optic.SurfaceGroup.Items.Any(surface => surface.IsReflective
            || surface.CoatingModel is not (NoneCoatingModel or SimpleCoatingModel)))
            throw new AnalysisDataUnavailableException("Partially Coherent Image",
                "the scalar model requires a transmitted refractive pupil and no phase-bearing coatings; reflected or thin-film complex fields require vector propagation");
        var gridSize = AnalysisResourceLimits.RoundUpPowerOfTwo(pupilSampling, nameof(pupilSampling));
        if (fourierConjugateSampling)
            return ComputeConjugateCoherentKernel(optic, field, wavelength, gridSize, kernelSize, pixelPitchMillimeters);
        var psf = ComputeFftPsfCore(optic, field, wavelength, pupilSampling, gridSize,
            usePolarization: false, cellCenteredPupil: true, defocusMillimeters: 0,
            preparedWavefront: null, preparedPolarization: null, zemaxFftSampling: false,
            ignoreOpd: false, aimAtStop: optic.RayAimingEnabled, referenceWavelength: null,
            imageDelta: 0, ignoreScalarTransmission: false, out var pupil);
        return CreateCoherentImageKernel(pupil, psf.TangentialWorkingFNumber, psf.SagittalWorkingFNumber,
            wavelength.Micrometers, pixelPitchMillimeters, kernelSize);
    }

    private static CoherentImageKernel ComputeConjugateCoherentKernel(Optic optic, (double Hx, double Hy) field,
        Wavelength wavelength, int size, int kernelSize, double pitch)
    {
        if (kernelSize < 1 || kernelSize > size || kernelSize > 256 || !double.IsFinite(pitch) || pitch <= 0)
            throw new ArgumentOutOfRangeException(nameof(kernelSize), "The finite kernel must fit inside the Fourier-conjugate pupil grid.");
        // Trace at the actual Fourier-conjugate nodes. Interpolating a separately traced cell-centered
        // complex pupil changes edge amplitudes and phase, even if both nominal grids have the same size.
        _ = ComputeFftPsfCore(optic, field, wavelength, size, size,
            usePolarization: false, cellCenteredPupil: true, defocusMillimeters: 0,
            preparedWavefront: null, preparedPolarization: null, zemaxFftSampling: true,
            ignoreOpd: false, aimAtStop: optic.RayAimingEnabled, referenceWavelength: null,
            imageDelta: pitch * 1000, ignoreScalarTransmission: true, out var pupil);
        var peak = pupil.Cast<Complex>().Max(value => value.Magnitude);
        var fullPower = pupil.Cast<Complex>().Sum(Power) / ((double)size * size * peak * peak);
        var fieldValues = new Complex[size, size];
        for (var y = 0; y < size; y++) for (var x = 0; x < size; x++)
            fieldValues[(y + size / 2) % size, (x + size / 2) % size] = pupil[y, x] / peak;
        FourierTransform2D(fieldValues);
        var kernel = new Complex[kernelSize, kernelSize];
        var anchor = (kernelSize - 1) / 2;
        double power = 0;
        for (var y = 0; y < kernelSize; y++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var x = 0; x < kernelSize; x++)
            {
                var value = fieldValues[(anchor - y + size) % size, (x - anchor + size) % size] / ((double)size * size);
                kernel[y, x] = value;
                power += Power(value);
            }
        }
        return new CoherentImageKernel(kernel, pitch, size, Math.Min(1, power / fullPower), power, fullPower);

        static double Power(Complex value) => value.Real * value.Real + value.Imaginary * value.Imaginary;
    }

    /// <summary>Samples a cell-centered complex pupil on the object's discrete spatial-frequency lattice.
    /// Frequencies outside the circular pupil are zero; object frequencies above Nyquist are absent.
    /// Image rows run downward, while pupil Y runs upward.</summary>
    public static CoherentImageKernel CreateCoherentImageKernel(Complex[,] pupil, double tangentialFNumber,
        double sagittalFNumber, double wavelengthMicrometers, double pixelPitchMillimeters, int kernelSize,
        int fourierGridSize = 0)
    {
        ArgumentNullException.ThrowIfNull(pupil);
        var sampling = pupil.GetLength(0);
        if (sampling < 2 || sampling != pupil.GetLength(1)) throw new ArgumentException("A square complex pupil is required.", nameof(pupil));
        if (!double.IsFinite(tangentialFNumber) || tangentialFNumber <= 0 || !double.IsFinite(sagittalFNumber) || sagittalFNumber <= 0
            || !double.IsFinite(wavelengthMicrometers) || wavelengthMicrometers <= 0
            || !double.IsFinite(pixelPitchMillimeters) || pixelPitchMillimeters <= 0 || kernelSize is < 1 or > 256)
            throw new ArgumentOutOfRangeException(nameof(pixelPitchMillimeters), "Finite positive optical scales and a kernel of 1..256 pixels are required.");
        var minimumGrid = AnalysisResourceLimits.RoundUpPowerOfTwo(Math.Max(2 * kernelSize, 2 * sampling), nameof(kernelSize));
        var size = fourierGridSize == 0 ? minimumGrid : fourierGridSize;
        AnalysisResourceLimits.ValidateFftGrid(minimumGrid, size);
        double peak = 0;
        foreach (var value in pupil)
        {
            if (!double.IsFinite(value.Real) || !double.IsFinite(value.Imaginary)) throw new ArgumentException("Pupil amplitudes must be finite.", nameof(pupil));
            peak = Math.Max(peak, value.Magnitude);
        }
        if (!double.IsFinite(peak) || peak <= 0)
            throw new AnalysisDataUnavailableException("Coherent Image Pupil", "no complex pupil power reached the image surface");
        var transfer = new Complex[size, size];
        double spectralPower = 0;
        for (var row = 0; row < size; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var fy = -(row < size / 2 ? row : row - size) / (size * pixelPitchMillimeters);
            for (var column = 0; column < size; column++)
            {
                var fx = (column < size / 2 ? column : column - size) / (size * pixelPitchMillimeters);
                // The shared OPD pupil is Fourier-transformed with a negative sign.
                // Reverse pupil frequency for the inverse transform, retaining that image-axis convention.
                var px = -2 * wavelengthMicrometers * .001 * sagittalFNumber * fx;
                var py = -2 * wavelengthMicrometers * .001 * tangentialFNumber * fy;
                var value = px * px + py * py <= 1 ? SampleCellCenteredPupil(pupil, px, py) / peak : Complex.Zero;
                transfer[row, column] = value;
                spectralPower += value.Real * value.Real + value.Imaginary * value.Imaginary;
            }
        }
        var fullPower = spectralPower / ((double)size * size);
        if (!double.IsFinite(fullPower) || fullPower <= 0)
            throw new AnalysisDataUnavailableException("Coherent Image Pupil", "the sampled object frequency band has no transmitted complex power");
        FourierTransform2D(transfer, inverse: true);
        var kernel = new Complex[kernelSize, kernelSize];
        var anchor = (kernelSize - 1) / 2;
        double captured = 0;
        for (var row = 0; row < kernelSize; row++)
            for (var column = 0; column < kernelSize; column++)
            {
                var value = transfer[(row - anchor + size) % size, (column - anchor + size) % size];
                kernel[row, column] = value;
                captured += value.Real * value.Real + value.Imaginary * value.Imaginary;
            }
        if (!double.IsFinite(captured) || captured <= 0)
            throw new AnalysisDataUnavailableException("Coherent Image Kernel", "the finite kernel window contains no complex power");
        return new CoherentImageKernel(kernel, pixelPitchMillimeters, size,
            Math.Min(1, captured / fullPower), captured, fullPower);
    }

    private static Complex SampleCellCenteredPupil(Complex[,] pupil, double x, double y)
    {
        var sampling = pupil.GetLength(0);
        var column = ((x + 1) * sampling - 1) / 2;
        var row = ((y + 1) * sampling - 1) / 2;
        var left = (int)Math.Floor(column);
        var top = (int)Math.Floor(row);
        var fx = column - left;
        var fy = row - top;
        Complex At(int r, int c) => r >= 0 && r < sampling && c >= 0 && c < sampling ? pupil[r, c] : Complex.Zero;
        return (1 - fy) * ((1 - fx) * At(top, left) + fx * At(top, left + 1))
            + fy * ((1 - fx) * At(top + 1, left) + fx * At(top + 1, left + 1));
    }
}
