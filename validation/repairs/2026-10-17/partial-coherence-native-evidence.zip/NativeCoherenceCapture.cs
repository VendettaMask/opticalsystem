using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using ZOSAPI;
using ZOSAPI.Analysis;

internal static class NativeCoherenceCapture
{
    static string Output;
    static void Write(string name, object value) { File.WriteAllText(Path.Combine(Output, name), new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Serialize(value)); }
    static string Hash(string path) { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(path))).Replace("-", "").ToLowerInvariant(); }
    static Dictionary<string, object> Properties(object value)
    {
        var result = new Dictionary<string, object>();
        if (value == null) return result;
        foreach (var p in value.GetType().GetInterfaces().SelectMany(t => t.GetProperties()).Where(p => p.GetIndexParameters().Length == 0).GroupBy(p => p.Name).Select(g => g.First()))
            try { var v = p.GetValue(value, null); if (v == null || v is string || v is bool || v is int || v is double || v.GetType().IsEnum) result[p.Name] = v == null ? null : v.GetType().IsEnum ? v.ToString() : v; } catch { }
        return result;
    }
    [STAThread]
    static int Main(string[] args)
    {
        string api = args[0]; Output = args[2]; Directory.CreateDirectory(Output);
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e) { string p = Path.Combine(api, new AssemblyName(e.Name).Name + ".dll"); return File.Exists(p) ? Assembly.LoadFrom(p) : null; };
        return Run(api, args[1], args.Length > 3 ? args[3] : null);
    }
    static int Run(string api, string input, string requestPath)
    {
        IZOSAPI_Application app = null; ZOSAPI.Analysis.IA_ analysis = null;
        try
        {
            if (!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(api)) throw new Exception("API initialization failed");
            app = new ZOSAPI_Connection().CreateNewApplication();
            if (app == null || !app.IsValidLicenseForAPI) throw new Exception("API license unavailable");
            Write("environment.json", new { major = app.ZOSMajorVersion, minor = app.ZOSMinorVersion, build = app.OpticStudioVersion,
                validLicense = app.IsValidLicenseForAPI, license = app.LicenseStatus.ToString(), imagesDir = app.ImagesDir });
            if (app.ZOSMajorVersion != 26 || app.ZOSMinorVersion != 1) throw new Exception("Expected 2026 R1");
            var system = app.PrimarySystem;
            if (!system.LoadFile(input, false)) throw new Exception("Native source load failed");
            Write("native-model.json", new { Wavelengths = Enumerable.Range(1, system.SystemData.Wavelengths.NumberOfWavelengths).Select(i => new { Number = i, Data = Properties(system.SystemData.Wavelengths.GetWavelength(i)) }).ToArray() });
            analysis = system.Analyses.New_Analysis_SettingsFirst(AnalysisIDM.PartiallyCoherentImageAnalysis);
            var settings = analysis.GetSettings(); settings.Reset();
            string baseline = Path.Combine(Output, "reset.CFG"); settings.SaveTo(baseline);
            Write("analysis-settings.json", new { Analysis = Properties(analysis), Settings = Properties(settings), SourceSha256 = Hash(input) });
            if (requestPath != null)
            {
                string root = Output;
                var cases = new JavaScriptSerializer { MaxJsonLength = int.MaxValue }.Deserialize<object[]>(File.ReadAllText(requestPath));
                foreach (Dictionary<string, object> request in cases)
                {
                    Output = Path.Combine(root, (string)request["name"]); Directory.CreateDirectory(Output);
                    string cfg = Path.Combine(Output, "requested.CFG"); File.Copy(baseline, cfg, true);
                    settings.ModifySettings(cfg, "PCI_FILESIZE", Convert.ToString(request.ContainsKey("fileSize") ? request["fileSize"] : .032, System.Globalization.CultureInfo.InvariantCulture));
                    settings.ModifySettings(cfg, "PCI_WAVE", Convert.ToString(request.ContainsKey("wave") ? request["wave"] : 2)); settings.ModifySettings(cfg, "PCI_FIELD", "1");
                    var bytes = File.ReadAllBytes(cfg);
                    if (BitConverter.ToInt32(bytes, 0) != 2000 || BitConverter.ToInt32(bytes, 4) != 422) throw new Exception("Unknown saved settings schema");
                    if (request.ContainsKey("file"))
                    {
                        var text = System.Text.Encoding.Unicode.GetBytes((string)request["file"] + "\0");
                        if (text.Length > 520) throw new Exception("Diagnostic source name too long");
                        Array.Clear(bytes, 60, 520); Array.Copy(text, 0, bytes, 60, text.Length);
                    }
                    if (request.ContainsKey("changes")) foreach (Dictionary<string, object> change in (object[])request["changes"])
                    {
                        int offset = Convert.ToInt32(change["offset"]);
                        var value = change.ContainsKey("integer") ? BitConverter.GetBytes(Convert.ToInt32(change["integer"])) : BitConverter.GetBytes(Convert.ToDouble(change["number"]));
                        Array.Copy(value, 0, bytes, offset, value.Length);
                    }
                    if (request.ContainsKey("gammaText"))
                    {
                        var gammaText = System.Text.Encoding.Unicode.GetBytes((string)request["gammaText"] + "\0");
                        Array.Clear(bytes, 592, 200); Array.Copy(gammaText, 0, bytes, 592, gammaText.Length);
                    }
                    File.WriteAllBytes(cfg, bytes); settings.LoadFrom(cfg); settings.SaveTo(Path.Combine(Output, "readback.CFG"));
                    Write("request.json", request);
                    var status = analysis.ApplyAndWaitForCompletion();
                    var data = analysis.GetResults(); bool textSaved = data.GetTextFile(Path.Combine(Output, "data.txt"));
                    var grids = Enumerable.Range(0, data.NumberOfDataGrids).Select(i => {
                        var grid = data.GetDataGrid(i); var values = grid.Values;
                        return new { grid.Description, grid.Nx, grid.Ny, grid.Dx, grid.Dy, grid.MinX, grid.MinY,
                            Values = Enumerable.Range(0, values.GetLength(0)).Select(y => Enumerable.Range(0, values.GetLength(1)).Select(x => values[y,x]).ToArray()).ToArray() };
                    }).ToArray();
                    Write("data.json", new { TextSaved = textSaved, Status = Properties(status), Grids = grids, Messages = Enumerable.Range(0, data.NumberOfMessages).Select(i => Properties(data.GetMessageAt(i))).ToArray() });
                    Console.WriteLine("Captured " + request["name"] + ": " + grids.Length + " grids");
                }
                Output = root; return 0;
            }
            var probes = new List<object>();
            foreach (var key in new[] { "PCI_FIELD", "PCI_FILESIZE", "PCI_WAVE", "PCI_TYPE", "PCI_DATA", "PCI_DATATYPE", "PCI_GAMMA", "PCI_ALPHA", "PCI_FRACTION", "PCI_OVERSAMPLING", "PCI_SAMP", "PCI_OTFSAMP", "PCI_ZEROPAD", "PCI_ZEROPADDING", "PCI_FILE", "PCI_FILENAME", "PCI_INPUTFILE", "PCI_POLARIZATION", "PCI_DIFFRACTIONLIMITED", "PCI_NORMALIZE", "PCI_SKIPNORMALIZATION" })
            {
                string file = Path.Combine(Output, key + ".CFG"); File.Copy(baseline, file, true);
                try { bool accepted = settings.ModifySettings(file, key, key.IndexOf("FILESIZE") >= 0 ? "0.032" : "1"); probes.Add(new { Key = key, Accepted = accepted, Changed = Hash(file) != Hash(baseline), Sha256 = Hash(file) }); }
                catch (Exception e) { probes.Add(new { Key = key, Error = e.Message }); }
            }
            Write("modify-settings-probes.json", probes);
            settings.LoadFrom(baseline); analysis.ApplyAndWaitForCompletion();
            var results = analysis.GetResults(); results.GetTextFile(Path.Combine(Output, "reset.txt"));
            Write("reset-results.json", new { Properties = Properties(results), GridCount = results.NumberOfDataGrids });
            Console.WriteLine("Native partial-coherence settings inspection completed."); return 0;
        }
        catch (Exception e) { Write("error.json", new { Error = e.ToString() }); Console.Error.WriteLine(e); return 2; }
        finally { if (analysis != null) analysis.Close(); if (app != null) app.CloseApplication(); }
    }
}
