$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$taskRepo=[IO.Path]::GetFullPath((Join-Path $taskRoot '../../..'))
$taskFixturePath=Join-Path $taskRepo 'tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-zemax-2026-r1.json'
$taskFixture=Get-Content -LiteralPath $taskFixturePath -Raw|ConvertFrom-Json
$taskRecords=@()
foreach($taskCase in $taskFixture.Cases){
    $taskCapture=if($taskCase.Name.StartsWith('two-')){'two-capture-v1'}elseif($taskCase.Name.StartsWith('wave')){'spectral-capture-v1'}else{'extended-capture-v1'}
    $taskDir=Join-Path (Join-Path $taskRoot $taskCapture) $taskCase.Name
    $taskBytes=[IO.File]::ReadAllBytes((Join-Path $taskDir 'readback.CFG'))
    $taskWave=if($taskCase.Wavelength -eq .42){1}elseif($taskCase.Wavelength -eq .46){3}else{2}
    $taskGamma=if($taskCase.Function -eq 'Gaussian'){0}else{1}
    $taskIntSettings=@{0=2000;4=422;32=3;36=($taskCase.Oversampling-1);40=1;44=4;48=6;52=1;56=$taskWave;584=0;588=0;792=$taskGamma}
    foreach($taskOffset in $taskIntSettings.Keys){if([BitConverter]::ToInt32($taskBytes,$taskOffset) -ne $taskIntSettings[$taskOffset]){throw "Unexpected native integer setting $($taskCase.Name) at $taskOffset"}}
    foreach($taskPair in @(@(24,.008),@(800,.98),@(808,$taskCase.Alpha))){if([math]::Abs([BitConverter]::ToDouble($taskBytes,$taskPair[0])-$taskPair[1]) -gt 1e-15){throw "Unexpected native scalar setting $($taskCase.Name) at $($taskPair[0])"}}
    $taskData=Get-Content (Join-Path $taskDir 'data.json') -Raw|ConvertFrom-Json
    if(-not $taskData.TextSaved -or $taskData.Grids.Count -ne 1 -or $taskData.Messages.Count -ne 0){throw "Incomplete native result $($taskCase.Name)"}
    $taskSize=32*$taskCase.Oversampling
    $taskGrid=$taskData.Grids[0]
    if($taskGrid.Nx -ne $taskSize -or $taskGrid.Ny -ne $taskSize -or $taskGrid.Values.Count -ne $taskSize){throw 'Unexpected native image grid'}
    for($taskY=0;$taskY -lt $taskSize;$taskY++){if($taskGrid.Values[$taskY].Count -ne $taskSize){throw 'Native grid has missing columns'};for($taskX=0;$taskX -lt $taskSize;$taskX++){if(-not [double]::IsFinite($taskGrid.Values[$taskY][$taskX]) -or $taskGrid.Values[$taskY][$taskX] -ne $taskCase.Values[$taskY][$taskX]){throw 'Fixture differs from native result'}}}
    $taskText=Get-Content (Join-Path $taskDir 'data.txt') -Raw
    if(-not $taskText.Contains($taskCase.Wavelength.ToString('F4',[cultureinfo]::InvariantCulture))){throw 'Native text wavelength differs'}
    $taskRecords+=@{name=$taskCase.Name;capture=$taskCapture;waveNumber=$taskWave;wavelength=$taskCase.Wavelength;gamma=$taskCase.Function;alpha=$taskCase.Alpha;fraction=[BitConverter]::ToDouble($taskBytes,800);otfSampling=256;oversampling=$taskCase.Oversampling;nativeFileSize=.008;imagePixelPitch=.0005/$taskCase.Oversampling;grid=$taskSize;cfgSha256=(Get-FileHash (Join-Path $taskDir 'readback.CFG')).Hash.ToLowerInvariant();dataSha256=(Get-FileHash (Join-Path $taskDir 'data.json')).Hash.ToLowerInvariant();textSha256=(Get-FileHash (Join-Path $taskDir 'data.txt')).Hash.ToLowerInvariant()}
}
$taskSourceSha=(Get-FileHash (Join-Path $taskRoot 'source/123456.ZMX')).Hash.ToLowerInvariant()
if($taskSourceSha -ne $taskFixture.SourceSha256){throw 'Native source changed'}
$taskSummary=@{native='OpticStudio 2026 R1 build 260127 Enterprise';sourceSha256=$taskSourceSha;fixtureSha256=(Get-FileHash $taskFixturePath).Hash.ToLowerInvariant();caseCount=$taskRecords.Count;allReadbackSettingsVerified=$true;allNativeGridsCompleteAndFinite=$true;allFixtureValuesIdenticalToNative=$true;cases=$taskRecords}
ConvertTo-Json -InputObject $taskSummary -Depth 12 | Set-Content (Join-Path $taskRoot 'capture-manifest.json')
"Verified $($taskRecords.Count) complete native captures and exact fixture data"
