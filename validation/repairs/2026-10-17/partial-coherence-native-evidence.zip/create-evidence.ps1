$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$taskRepo=[IO.Path]::GetFullPath((Join-Path $taskRoot '../../..'))
$taskArchive=Join-Path $taskRepo 'validation/repairs/2026-10-17/partial-coherence-native-evidence.zip'
$taskMetadataPath=Join-Path $taskRoot 'archive-metadata.json'
if(Test-Path -LiteralPath $taskArchive){if(-not (Test-Path -LiteralPath $taskMetadataPath)){throw 'Existing archive is not owned by this staging run'};$taskPreviousArchive=Get-Content $taskMetadataPath -Raw|ConvertFrom-Json;if((Get-FileHash $taskArchive).Hash.ToLowerInvariant() -ne $taskPreviousArchive.sha256){throw 'Archive changed after last staging write'}}
$taskFiles=[Collections.Generic.List[object]]::new()
$taskNames=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
function Add-ArchiveFile([string]$taskPath,[string]$taskEntry){
    if(-not (Test-Path -LiteralPath $taskPath -PathType Leaf)){return}
    $taskEntry=$taskEntry.Replace('\','/')
    if(-not $taskNames.Add($taskEntry)){throw "Duplicate archive entry $taskEntry"}
    $taskFiles.Add([ordered]@{path=[IO.Path]::GetRelativePath($taskRepo,$taskPath).Replace('\','/');entry=$taskEntry;sha256=(Get-FileHash -LiteralPath $taskPath).Hash.ToLowerInvariant()})
}
foreach($taskDirectory in @('two-capture-v1','extended-capture-v1','spectral-capture-v1','pair-capture-v1','fraction-capture-v1','raw-three-capture-v1','spatial-boundary-capture-v1','tests-first','initial-related','final')){
    foreach($taskFile in Get-ChildItem -LiteralPath (Join-Path $taskRoot $taskDirectory) -File -Recurse){Add-ArchiveFile $taskFile.FullName ([IO.Path]::GetRelativePath($taskRoot,$taskFile.FullName))}
}
foreach($taskDirectory in @('alpha-later-probes-v1/alpha-808','gamma-slots-probes-v1/gamma-slot-792')){foreach($taskFile in Get-ChildItem -LiteralPath (Join-Path $taskRoot $taskDirectory) -File){Add-ArchiveFile $taskFile.FullName ([IO.Path]::GetRelativePath($taskRoot,$taskFile.FullName))}}
foreach($taskFile in Get-ChildItem -LiteralPath (Join-Path $taskRoot 'source') -File|Where-Object{$_.Extension -in @('.ZMX','.IMA')}){Add-ArchiveFile $taskFile.FullName ('source/'+$taskFile.Name)}
foreach($taskName in @('NativeCoherenceCapture.cs','NativeCoherenceCapture.exe.config','Run-Cases.ps1','two-requests.json','extended-requests.json','spectral-requests.json','pair-requests.json','fraction-requests.json','raw-three-requests.json','spatial-boundary-requests.json','audit-captures.ps1','prepare-proof.ps1','create-evidence.ps1','write-ledger.ps1','capture-manifest.json','diagnostic-findings.json','proof.json','metrics-before.json','metrics-release-final.json','metrics-debug-final.json','spatial-first-comparison.json','conjugate-spatial-comparison.json','fraction-convergence-comparison.json','two-spatial-comparison.json','build-release-final.log','build-debug-final.log','tests-release-final.log','tests-debug-final.log','format-apply.log','format-verify.log','changed-csharp-files.txt','final-test-filter.txt','documentation-verification.json','documentation-check.log')){Add-ArchiveFile (Join-Path $taskRoot $taskName) $taskName}
foreach($taskName in @('metrics/Metrics.csproj','metrics/Program.cs','metrics/before-reference/OpticalSystemDesign.Core.dll','probe/BoundaryExperiment.cs.txt')){Add-ArchiveFile (Join-Path $taskRoot $taskName) $taskName}
$taskSources=@(Get-Content (Join-Path $taskRoot 'changed-csharp-files.txt'))+@('tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj','tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-zemax-2026-r1.json','docs/CURRENT_STATUS.md','docs/NUMERICAL_PARITY.md','docs/OPEN_ISSUES_2026-10-08.md','docs/PARTIAL_COHERENCE_NATIVE_REPAIR_2026-10-17.md')
foreach($taskSource in $taskSources){Add-ArchiveFile (Join-Path $taskRepo $taskSource) ('snapshot/'+$taskSource)}
$taskStream=[IO.File]::Open($taskArchive,[IO.FileMode]::Create,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
$taskZip=[IO.Compression.ZipArchive]::new($taskStream,[IO.Compression.ZipArchiveMode]::Create,$false)
try{foreach($taskFile in $taskFiles){$taskEntry=$taskZip.CreateEntry($taskFile.entry,[IO.Compression.CompressionLevel]::Optimal);$taskOutput=$taskEntry.Open();try{$taskInput=[IO.File]::OpenRead((Join-Path $taskRepo $taskFile.path));try{$taskInput.CopyTo($taskOutput)}finally{$taskInput.Dispose()}}finally{$taskOutput.Dispose()}}}finally{$taskZip.Dispose()}
$taskRead=[IO.Compression.ZipFile]::OpenRead($taskArchive)
try{if($taskRead.Entries.Count -ne $taskFiles.Count){throw 'Archive count differs'};foreach($taskFile in $taskFiles){$taskInput=$taskRead.GetEntry($taskFile.entry).Open();try{$taskSha=[Security.Cryptography.SHA256]::Create();try{$taskHash=[Convert]::ToHexString($taskSha.ComputeHash($taskInput)).ToLowerInvariant()}finally{$taskSha.Dispose()}}finally{$taskInput.Dispose()};if($taskHash -ne $taskFile.sha256){throw "Archive readback differs: $($taskFile.entry)"}}}finally{$taskRead.Dispose()}
$taskMetadata=[ordered]@{path='validation/repairs/2026-10-17/partial-coherence-native-evidence.zip';sha256=(Get-FileHash $taskArchive).Hash.ToLowerInvariant();bytes=(Get-Item $taskArchive).Length;entryCount=$taskFiles.Count;allEntriesReadbackVerified=$true;files=$taskFiles}
ConvertTo-Json -InputObject $taskMetadata -Depth 9 | Set-Content $taskMetadataPath
"Archived and verified $($taskFiles.Count) entries; SHA-256 $($taskMetadata.sha256)"
