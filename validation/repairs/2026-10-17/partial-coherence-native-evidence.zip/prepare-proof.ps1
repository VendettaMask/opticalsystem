$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$taskRepo=[IO.Path]::GetFullPath((Join-Path $taskRoot '../../..'))
function Read-TestRun([string]$taskPath){
    [xml]$taskXml=Get-Content -LiteralPath $taskPath -Raw
    $taskNs=[Xml.XmlNamespaceManager]::new($taskXml.NameTable);$taskNs.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
    $taskCounter=$taskXml.SelectSingleNode('//t:ResultSummary/t:Counters',$taskNs)
    $taskNames=@($taskXml.SelectNodes('//t:Results/t:UnitTestResult',$taskNs)|ForEach-Object{$_.testName}|Sort-Object)
    [ordered]@{total=[int]$taskCounter.total;passed=[int]$taskCounter.passed;failed=[int]$taskCounter.failed;skipped=[int]$taskCounter.notExecuted;names=$taskNames;newTests=@($taskNames|Where-Object{$_ -match 'SpatialCoherenceNativeTests\.'}).Count}
}
$taskRelease=Read-TestRun (Join-Path $taskRoot 'final/related-release-final.trx')
$taskDebug=Read-TestRun (Join-Path $taskRoot 'final/related-debug-final.trx')
foreach($taskRun in @($taskRelease,$taskDebug)){if($taskRun.total -ne 370 -or $taskRun.passed -ne 370 -or $taskRun.failed -ne 0 -or $taskRun.skipped -ne 0 -or $taskRun.newTests -ne 32){throw 'Incomplete final test set'}}
if(($taskRelease.names -join "`n") -cne ($taskDebug.names -join "`n")){throw 'Test selections differ'}
$taskPrevious=Get-Content (Join-Path $taskRepo 'docs/validation/PARTIAL_COHERENCE_IMPLEMENTATION_2026-10-17.json') -Raw|ConvertFrom-Json
$taskOldNames=@($taskRelease.names|Where-Object{$_ -notmatch 'SpatialCoherenceNativeTests\.'})
if(($taskOldNames -join "`n") -cne (($taskPrevious.tests.finalRelease.names|Sort-Object) -join "`n")){throw 'Previous 338 tests not retained'}
$taskConfigs=@()
foreach($taskConfig in @('Release','Debug')){
    $taskBuild=Get-Content (Join-Path $taskRoot "build-$($taskConfig.ToLowerInvariant())-final.log") -Raw
    if(@($taskBuild -split "`n"|Where-Object{$_ -match ' -> '}).Count -ne 19 -or -not $taskBuild.Contains('0 个警告') -or -not $taskBuild.Contains('0 个错误')){throw 'Root build incomplete'}
    $taskPaths=@("src/OpticalSystemDesign.Core/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll")
    $taskHashes=@($taskPaths|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash (Join-Path $taskRepo $_)).Hash.ToLowerInvariant()}})
    if(@($taskHashes.sha256|Sort-Object -Unique).Count -ne 1){throw 'Default Core output copies differ'}
    $taskMetric=Get-Content (Join-Path $taskRoot "metrics-$($taskConfig.ToLowerInvariant())-final.json") -Raw|ConvertFrom-Json
    if($taskMetric.coreSha256 -ne $taskHashes[0].sha256 -or $taskMetric.cases.Count -ne 18 -or @($taskMetric.cases|Where-Object max -gt 1e-9).Count -ne 0){throw 'Native metrics do not describe final default Core'}
    $taskConfigs+=@{configuration=$taskConfig;buildProjects=19;warnings=0;errors=0;coreCopies=$taskHashes;nativeMaximumAbsoluteDifference=($taskMetric.cases.max|Measure-Object -Maximum).Maximum}
}
$taskMRelease=Get-Content (Join-Path $taskRoot 'metrics-release-final.json') -Raw|ConvertFrom-Json
$taskMDebug=Get-Content (Join-Path $taskRoot 'metrics-debug-final.json') -Raw|ConvertFrom-Json
$taskEqualCases=(ConvertTo-Json -InputObject $taskMRelease.cases -Depth 8 -Compress) -ceq (ConvertTo-Json -InputObject $taskMDebug.cases -Depth 8 -Compress)
$taskEqualBoundary=(ConvertTo-Json -InputObject $taskMRelease.boundaryCases -Depth 8 -Compress) -ceq (ConvertTo-Json -InputObject $taskMDebug.boundaryCases -Depth 8 -Compress)
if(-not $taskEqualCases -or -not $taskEqualBoundary){throw 'Numerical results differ across configurations'}
$taskPreserved=@{
'validation/repairs/2026-10-17/partial-coherence-evidence.zip'='f52185274a24079ff411fcbf1bf42be2bec7e19200767950d9fd707931b5653d';
'validation/repairs/2026-10-17/image-sampling-statistics-evidence.zip'='22daf84d477f762a2129d8a7d2c56a9c60f1ce0ac8de88ec0156b19672b3473c';
'validation/repairs/2026-10-17/image-psf-safety-evidence.zip'='042f1a564379bad9b1be57e5f2c9f8139616f9327074fcfabbbcee9437987a65';
'validation/repairs/2026-10-17/product-image-audit-evidence.zip'='252b9e2c236698a57130e82da28aba409fff10403fa5ff061d3e33f63b7aedd9';
'validation/repairs/2026-10-16/illumination-inverse-evidence.zip'='bcd5df8b59d0e7437c906503e4b4cbfc514fbe032f09f90595236a845c2657bb';
'validation/repairs/2026-10-16/illumination-finite-grid-evidence.zip'='a137625a22a2e7e333f637b17e2117b3602569add648b60445e09f8782d3e83d';
'validation/repairs/2026-10-16/native-diffraction-adapter-evidence.zip'='e452e029523ac4c2a0f806a07fe3a4a05920371ff797a04de4d503e81bfc2a6c'}
foreach($taskPath in $taskPreserved.Keys){if((Get-FileHash (Join-Path $taskRepo $taskPath)).Hash.ToLowerInvariant() -ne $taskPreserved[$taskPath]){throw "Prior frozen archive changed: $taskPath"}}
$taskCapture=Get-Content (Join-Path $taskRoot 'capture-manifest.json') -Raw|ConvertFrom-Json
$taskProof=[ordered]@{date='2026-10-17';sourceBaseCommit=(git -C $taskRepo rev-parse HEAD);nativeCaptures=$taskCapture;testRelease=$taskRelease;testDebug=$taskDebug;previous338Preserved=$true;testNamesEqualAcrossConfigurations=$true;configurations=$taskConfigs;caseMetricsEqualAcrossConfigurations=$taskEqualCases;boundaryMetricsEqualAcrossConfigurations=$taskEqualBoundary;boundaryCases=$taskMRelease.boundaryCases;preservedSha256=$taskPreserved;changedCSharpFiles=@(Get-Content (Join-Path $taskRoot 'changed-csharp-files.txt'));noFullSuite=$true;noEfnoReliMatrixRerun=$true;noInstallerRebuild=$true;noCommitOrPush=$true}
ConvertTo-Json -InputObject $taskProof -Depth 18 | Set-Content (Join-Path $taskRoot 'proof.json')
'Final proof verified: 18 native cases, 370/370 per configuration, default binaries identical and prior archives preserved'
