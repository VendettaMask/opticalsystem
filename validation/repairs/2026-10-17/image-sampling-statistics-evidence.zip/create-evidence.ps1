$ErrorActionPreference = 'Stop'
$taskRoot = (Get-Location).Path
$taskDirectory = 'artifacts/validation/image-sampling-statistics-repair-20261017'
function Read-TaskTestRun([string]$Path) {
    [xml]$taskXml = Get-Content $Path -Raw
    $taskCounters = $taskXml.TestRun.ResultSummary.Counters
    $taskResults = @($taskXml.TestRun.Results.UnitTestResult)
    [ordered]@{
        path = $Path; total = [int]$taskCounters.total; passed = [int]$taskCounters.passed
        failed = [int]$taskCounters.failed; skipped = [int]$taskCounters.notExecuted
        names = @($taskResults.testName | Sort-Object)
        newTests = @($taskResults | Where-Object testName -Like '*ImageSamplingStatisticsRepairTests*').Count
    }
}
$taskBefore = Read-TaskTestRun "$taskDirectory/before/before.trx"
$taskRelease = Read-TaskTestRun "$taskDirectory/final/related-release-final.trx"
$taskDebug = Read-TaskTestRun "$taskDirectory/final/related-debug-final.trx"
if ($taskBefore.total -ne 20 -or $taskBefore.failed -ne 18 -or $taskBefore.passed -ne 2) { throw 'Original controls missing' }
foreach ($taskRun in @($taskRelease, $taskDebug)) {
    if ($taskRun.total -ne 242 -or $taskRun.passed -ne 242 -or $taskRun.failed -ne 0 -or $taskRun.skipped -ne 0 -or $taskRun.newTests -ne 27) {
        throw "Final tests incomplete: $($taskRun.path)"
    }
}
if (($taskRelease.names -join "`n") -cne ($taskDebug.names -join "`n")) { throw 'Configuration test names differ' }
$taskControlsR = Get-Content "$taskDirectory/controls-release.json" -Raw | ConvertFrom-Json
$taskControlsD = Get-Content "$taskDirectory/controls-debug.json" -Raw | ConvertFrom-Json
foreach ($taskName in @('GuardBand', 'Flip', 'Downsample', 'PartialCoherence')) {
    if (($taskControlsR.$taskName | ConvertTo-Json -Depth 20 -Compress) -cne ($taskControlsD.$taskName | ConvertTo-Json -Depth 20 -Compress)) {
        throw "Configuration control differs: $taskName"
    }
}
if ([Math]::Abs($taskControlsR.GuardBand[0].Moment.RmsPixels - $taskControlsR.GuardBand[1].Moment.RmsPixels) -gt 1e-12) { throw 'Guard changes sampling' }
foreach ($taskName in @('Flip', 'Downsample')) {
    if ($taskControlsR.$taskName.MeanAbsoluteChange -ne $taskControlsR.$taskName.DisplayedMeanAbsoluteChange -or
        $taskControlsR.$taskName.MaximumValue -ne $taskControlsR.$taskName.DisplayedMaximum) { throw 'Display statistics differ' }
}
if ($taskControlsR.Downsample.MaximumValue -ne 0 -or $taskControlsR.PartialCoherence[0].Outcome -ne 'Success') { throw 'Control not satisfied' }
foreach ($taskControl in $taskControlsR.PartialCoherence[1..2]) {
    if ($taskControl.Outcome -ne 'Unavailable' -or $taskControl.PaneCount -ne 0 -or $taskControl.OutcomeReason -notmatch 'mutual coherence') { throw 'False partial coherence result' }
}
$taskPreserved = [ordered]@{
    'validation/repairs/2026-10-17/image-psf-safety-evidence.zip' = '042f1a564379bad9b1be57e5f2c9f8139616f9327074fcfabbbcee9437987a65'
    'validation/repairs/2026-10-17/product-image-audit-evidence.zip' = '252b9e2c236698a57130e82da28aba409fff10403fa5ff061d3e33f63b7aedd9'
    'validation/repairs/2026-10-16/illumination-inverse-evidence.zip' = 'bcd5df8b59d0e7437c906503e4b4cbfc514fbe032f09f90595236a845c2657bb'
    'validation/repairs/2026-10-16/illumination-finite-grid-evidence.zip' = 'a137625a22a2e7e333f637b17e2117b3602569add648b60445e09f8782d3e83d'
    'validation/repairs/2026-10-16/native-diffraction-adapter-evidence.zip' = 'e452e029523ac4c2a0f806a07fe3a4a05920371ff797a04de4d503e81bfc2a6c'
    'artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX' = '0cd65a2f823baf5079f20f91d8310765899a182a6be72ddac53ede943f2bf75b'
}
foreach ($taskPath in $taskPreserved.Keys) {
    if ((Get-FileHash $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskPreserved[$taskPath]) { throw "Preserved identity changed: $taskPath" }
}
$taskConfigurations = foreach ($taskConfiguration in @('Debug', 'Release')) {
    $taskCore = "src/OpticalSystemDesign.Core/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll"
    $taskCoreHash = (Get-FileHash $taskCore -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskCopies = @("src/OpticalSystemDesign.App/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll",
        "tests/OpticalSystemDesign.Tests/bin/$taskConfiguration/net10.0/OpticalSystemDesign.Core.dll")
    foreach ($taskCopy in $taskCopies) {
        if ((Get-FileHash $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskCoreHash) { throw "Core copy mismatch: $taskCopy" }
    }
    $taskControl = if ($taskConfiguration -eq 'Debug') { $taskControlsD } else { $taskControlsR }
    if ($taskControl.CoreSha256 -ne $taskCoreHash) { throw 'Probe did not use the default Core' }
    $taskBuildLog = Get-Content "$taskDirectory/build-$($taskConfiguration.ToLowerInvariant())-final.log" -Raw
    $taskProjects = @([regex]::Matches($taskBuildLog, '(?m)^\s+(\S+) -> ') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
    if ($taskProjects.Count -ne 19 -or $taskBuildLog -notmatch '0 个警告' -or $taskBuildLog -notmatch '0 个错误') { throw 'Root build incomplete' }
    [ordered]@{ configuration = $taskConfiguration; projects = $taskProjects; projectCount = 19
        warnings = 0; errors = 0; corePath = $taskCore; coreSha256 = $taskCoreHash; matchingCopies = $taskCopies }
}
$taskSourcePaths = @(
    'src/OpticalSystemDesign.Core/Analysis/ImageSimulationEngine.cs',
    'src/OpticalSystemDesign.Core/Analysis/ImageSimulationEngine.Sampling.cs',
    'src/OpticalSystemDesign.Core/Analysis/Extended/ExtendedSceneImageAnalyses.cs',
    'src/OpticalSystemDesign.Application/Runtime/WorkbenchRuntime.Analysis.Parameters.cs',
    'tests/OpticalSystemDesign.Tests/ImageSamplingStatisticsRepairTests.cs',
    'tests/OpticalSystemDesign.Tests/ExtendedImageAnalysisTests.cs',
    'tests/OpticalSystemDesign.Tests/CommercialReliabilityTests.cs')
$taskSources = foreach ($taskPath in $taskSourcePaths) {
    [ordered]@{ path = $taskPath; sha256 = (Get-FileHash $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$taskProof = [ordered]@{
    date = '2026-10-17'; sourceBaseCommit = (git rev-parse HEAD).Trim()
    status = 'IMG04 IMG05 repaired; IMG06 false blend removed; physical partially coherent imaging remains unavailable'
    sourceFiles = @($taskSources); configurations = @($taskConfigurations)
    tests = [ordered]@{ before = $taskBefore; finalRelease = $taskRelease; finalDebug = $taskDebug
        intermediateFocused = '20/20 Release'; intermediateRelated = '239/239 Release'; notAdditive = $true
        noFullSuite = $true; noNativeMatrixRerun = $true }
    controls = [ordered]@{ release = $taskControlsR; debug = $taskControlsD; comparedValuesEqual = $true }
    preservedSha256 = $taskPreserved
    limitations = @('True complex-field and mutual-coherence imaging is not implemented',
        'Guard inverse mapping extends the active-field polynomial; it is not certification of additional fields',
        'No new Zemax capture, installer, commit or push')
}
$taskProof | ConvertTo-Json -Depth 30 | Set-Content "$taskDirectory/proof.json" -Encoding utf8
$taskFiles = @('before/before.trx', 'focused/focused-release.trx', 'final/related-release.trx',
    'final/related-release-final.trx', 'final/related-debug-final.trx', 'related-release.log',
    'related-release-final.log', 'related-debug-final.log', 'related-filter.txt',
    'build-release.log', 'build-debug.log', 'build-release-final.log', 'build-debug-final.log',
    'format.log', 'format-apply.log', 'format-final.log', 'probe-build-release.log', 'probe-build-debug.log',
    'probe/SamplingProbe.csproj', 'probe/Program.cs', 'controls-release.json', 'controls-debug.json',
    'create-evidence.ps1', 'proof.json')
if (Test-Path "$taskDirectory/documentation-verification.json") { $taskFiles += 'documentation-verification.json' }
$taskEntries = @($taskFiles | ForEach-Object { [pscustomobject]@{ path = "$taskDirectory/$_"; entry = $_ } })
$taskEntries += @($taskSourcePaths | ForEach-Object { [pscustomobject]@{ path = $_; entry = "source/$_" } })
$taskArchivePath = 'validation/repairs/2026-10-17/image-sampling-statistics-evidence.zip'
$taskArchiveStream = [IO.File]::Open($taskArchivePath, [IO.FileMode]::Create)
$taskArchive = [IO.Compression.ZipArchive]::new($taskArchiveStream, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($taskEntry in $taskEntries) {
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskArchive,
            (Join-Path $taskRoot $taskEntry.path), $taskEntry.entry, [IO.Compression.CompressionLevel]::Optimal)
    }
} finally { $taskArchive.Dispose(); $taskArchiveStream.Dispose() }
$taskArchive = [IO.Compression.ZipFile]::OpenRead((Join-Path $taskRoot $taskArchivePath))
try {
    $taskManifest = foreach ($taskEntry in $taskEntries) {
        $taskStream = $taskArchive.GetEntry($taskEntry.entry).Open()
        try { $taskHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($taskStream)).ToLowerInvariant() }
        finally { $taskStream.Dispose() }
        if ($taskHash -ne (Get-FileHash $taskEntry.path -Algorithm SHA256).Hash.ToLowerInvariant()) { throw "Archive readback mismatch: $($taskEntry.path)" }
        [ordered]@{ path = $taskEntry.path; entry = $taskEntry.entry; sha256 = $taskHash }
    }
} finally { $taskArchive.Dispose() }
$taskLedger = [ordered]@{
    date = '2026-10-17'; sourceBaseCommit = (git rev-parse HEAD).Trim(); status = $taskProof.status
    evidence = [ordered]@{ path = $taskArchivePath; bytes = (Get-Item $taskArchivePath).Length
        sha256 = (Get-FileHash $taskArchivePath -Algorithm SHA256).Hash.ToLowerInvariant()
        entryCount = $taskEntries.Count; allEntriesReadbackVerified = $true; files = @($taskManifest) }
    tests = $taskProof.tests; configurations = $taskProof.configurations
    preservedSha256 = $taskPreserved; limitations = $taskProof.limitations
}
$taskLedger | ConvertTo-Json -Depth 30 | Set-Content 'docs/validation/IMAGE_SAMPLING_STATISTICS_REPAIR_2026-10-17.json' -Encoding utf8
[pscustomobject]$taskLedger.evidence | Select-Object path, bytes, sha256, entryCount, allEntriesReadbackVerified | ConvertTo-Json
