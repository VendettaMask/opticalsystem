using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Interactions;

if (args.Length != 1) throw new ArgumentException("Pass the JSON output path.");
var guard = new List<object>();
foreach (var pitch in new[] { 0d, .0057 })
    foreach (var padding in new[] { 0, 16 })
    {
        var result = ImageSimulationEngine.Simulate(Lens(10.1), Source(32, true), Config(padding, pitch: pitch));
        guard.Add(new { PixelPitch = pitch, Padding = padding, result.Simulated.Width, result.Simulated.Height,
            Moment = Moment(result.Simulated), result.EffectiveAberrationMode });
    }
var flipped = ImageSimulationEngine.Simulate(Lens(10), Source(16), Config(0, mode: "None", flip: "Horizontal"));
var reduced = ImageSimulationEngine.Simulate(Lens(10), Source(16, true), Config(0, mode: "None", size: 1));
var coherence = new[] { 0d, .5, 1 }.Select(value =>
{
    var data = new PartiallyCoherentImageAnalysis(Lens(10.1), imageSize: 16, pupilSampling: 4,
        coherence: value, fieldHeight: 1, guardBand: 0, relativeIllumination: false).GenerateData();
    return new { Coherence = value, Outcome = data.Outcome.ToString(), data.OutcomeReason,
        PaneCount = data.PlotPanes?.Count ?? 0, data.Values };
}).ToArray();
var core = typeof(Optic).Assembly.Location;
File.WriteAllText(args[0], JsonSerializer.Serialize(new
{
    Date = "2026-10-17", CorePath = core,
    CoreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(),
    GuardBand = guard,
    Flip = Statistics(flipped), Downsample = Statistics(reduced), PartialCoherence = coherence
}, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Recorded scoped controls to {args[0]}");

static object Statistics(ImageSimulationResult result)
{
    double change = 0;
    for (var c = 0; c < result.Simulated.Channels; c++) for (var y = 0; y < result.Simulated.Height; y++)
            for (var x = 0; x < result.Simulated.Width; x++)
                change += Math.Abs(result.Simulated[c, y, x] - result.Source[Math.Min(c, result.Source.Channels - 1), y, x]);
    return new { result.MeanAbsoluteChange, DisplayedMeanAbsoluteChange = change / result.Simulated.Values.Length,
        result.MaximumValue, DisplayedMaximum = result.Simulated.Values.Cast<double>().Max(),
        result.Simulated.Width, result.Simulated.Height };
}
static object Moment(RgbImage image)
{
    double power = 0, mx = 0, my = 0;
    for (var y = 0; y < image.Height; y++) for (var x = 0; x < image.Width; x++)
        { var value = image[0, y, x]; power += value; mx += x * value; my += y * value; }
    mx /= power; my /= power;
    double variance = 0;
    for (var y = 0; y < image.Height; y++) for (var x = 0; x < image.Width; x++)
        variance += ((x - mx) * (x - mx) + (y - my) * (y - my)) * image[0, y, x];
    return new { Power = power, CenterX = mx, CenterY = my, RmsPixels = Math.Sqrt(variance / power) };
}
static RgbImage Source(int size, bool impulse = false)
{
    var values = new double[1, size, size];
    if (impulse) values[0, size / 2, size / 2] = 1;
    else for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) values[0, y, x] = .1 + .8 * x / (size - 1d);
    return new RgbImage(values);
}
static Optic Lens(double imageDistance)
{
    var optic = new Optic { FieldDefinition = FieldDefinitionKind.Angle };
    optic.Aperture.Value = 2;
    optic.Fields.Add(new FieldPoint { Y = 1 });
    optic.Wavelengths.Add(new Wavelength { Nanometers = 550, IsPrimary = true });
    optic.SurfaceGroup.Replace([
        new OpticalSurface { Thickness = double.PositiveInfinity },
        new OpticalSurface { IsStop = true, SemiDiameter = 1, Thickness = imageDistance,
            InteractionModel = new ThinLensInteractionModel(10) }, new OpticalSurface()
    ]);
    return optic;
}
static ImageSimulationConfig Config(int padding, double pitch = .01, string mode = "Geometric", string flip = "None", int size = 0) => new()
{
    Padding = padding, WavelengthsMicrometers = [.55], PsfGridRows = 1, PsfGridColumns = 1,
    PsfSize = mode == "None" ? 1 : 17, NumRays = mode == "None" ? 2 : 16, Components = 1,
    FieldHeight = 1, PixelSizeMillimeters = pitch, AberrationMode = mode, ImageFlip = flip,
    OutputWidth = size, OutputHeight = size, UseRelativeIllumination = false,
    DistortionGridSize = 5, DistortionPolynomialDegree = 1
};
