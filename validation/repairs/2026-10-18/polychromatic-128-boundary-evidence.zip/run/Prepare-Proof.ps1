$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadJson([string]$relative){Get-Content (Join-Path $PSScriptRoot $relative) -Raw|ConvertFrom-Json}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/POLYCHROMATIC_128_ENERGY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$unchangedTests=@($previous.sourceFiles|Where-Object {$_.path -like 'tests/*.cs'})
foreach($s in $unchangedTests){if((Hash (Join-Path $repo $s.path)) -ne $s.sha256){throw 'Previously verified test source changed'}}
$release=Tests 'related-release-final.trx';$debug=Tests 'related-debug-final.trx'
foreach($run in @($release,$debug)){
 if($run.passed -ne $run.total -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Final main tests incomplete'}
 if(@($run.names|Where-Object {$_ -match '\.Polychromatic128BoundaryEnergyTests\.'}).Count -ne 16){throw 'Sixteen new checks missing'}
}
if($release.total -ne 1016 -or $debug.total -ne 303){throw 'Final test scope differs'}
foreach($name in $previous.verification.testRelease.names){if($name -cnotin $release.names){throw 'Prior Release test missing'}}
foreach($name in $previous.verification.testDebug.names){if($name -cnotin $debug.names){throw 'Prior Debug test missing'}}
foreach($name in $debug.names){if($name -cnotin $release.names){throw 'Debug identity absent from Release'}}
$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx'
foreach($run in @($comparisonRelease,$comparisonDebug)){if($run.total -ne 5 -or $run.passed -ne 5 -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Comparison tests incomplete'}}
$beforeTests=Tests 'boundary128-before.trx'
if($beforeTests.total -ne 16 -or $beforeTests.failed -ne 8 -or $beforeTests.passed -ne 8 -or $beforeTests.skipped -ne 0){throw 'Before counterexample differs'}
$beforeHash=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeHash -ne $previous.verification.configurations[0].coreCopies[0].sha256){throw 'Wrong before Core'}
$configurations=foreach($configuration in @('Release','Debug')){
 $log=Get-Content (Join-Path $PSScriptRoot ('build-'+$configuration.ToLowerInvariant()+'-final.log')) -Raw
 if(@($log -split "`n"|Where-Object {$_ -match ' -> '}).Count -ne 19 -or !$log.Contains('0 个警告') -or !$log.Contains('0 个错误')){throw 'Default solution build incomplete'}
 $paths=@("src/OpticalSystemDesign.Core/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tools/OpticalSystemDesign.ZemaxComparison/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll")
 $copies=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
 if(@($copies.sha256|Sort-Object -Unique).Count -ne 1 -or (Hash (Join-Path $PSScriptRoot ('Core.'+$configuration.ToLowerInvariant()+'-final.dll'))) -ne $copies[0].sha256){throw 'Default Core copies differ'}
 @{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies}
}
$summaries=@{};$comparisons=@();$pointwise=@()
foreach($spec in @(@('formal-final',$previous.formalAfter,48,0),@('extra-final',$previous.independentControls,6,1),@('apochromat-final',$previous.priorApochromatControls,5,2),@('high-sampling-final',$previous.priorHighSamplingControls,8,0),@('fnum-final',$previous.priorFNumberControls,5,0),@('polychromatic-final',$previous.priorPolychromaticControls,15,0),@('polychromatic128-final',$previous.newControlsAfter,12,0))){
 $current=ReadJson ($spec[0]+'/summary.json');$summaries[$spec[0]]=$current
 if($current.rows.Count -ne $spec[2] -or $current.excluded.Count -ne $spec[3]){throw 'Old comparison inventory differs'}
 foreach($row in $current.rows){
  $old=@($spec[1].rows|Where-Object id -ceq $row.id)
  if($old.Count -ne 1 -or $row.sourceSha256 -ne $old[0].sourceSha256 -or $row.executedRequestSha256 -ne $old[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $old[0].nativeDataSha256){throw 'Old source/request/reference changed'}
  $a=($row.metrics|Measure-Object nrmse -Maximum).Maximum;$b=($old[0].metrics|Measure-Object nrmse -Maximum).Maximum
  if($null -eq $a -or $null -eq $b -or $a -gt $b+1e-8){throw ('Old numerical regression: '+$row.id)}
  $comparisons+=@{group=$spec[0];id=$row.id;beforeWorstNrmse=$b;afterWorstNrmse=$a}
  $oldGroup=if($spec[0] -eq 'polychromatic128-final'){'controls-final'}else{$spec[0]}
  $oldPath=Join-Path $repo ('artifacts/validation/dee-poly128-20261018/'+$oldGroup+'/'+$row.id+'/normalized-workbench.json')
  $newPath=Join-Path $PSScriptRoot ($spec[0]+'/'+$row.id+'/normalized-workbench.json')
  $pointwise+=@{group=$spec[0];id=$row.id;normalizedBytesUnchanged=((Hash $oldPath) -eq (Hash $newPath))}
 }
}
if($comparisons.Count -ne 99){throw 'Missing prior formal controls'}
if(@($pointwise|Where-Object normalizedBytesUnchanged).Count -ne 88){throw 'Unaffected prior normalized curves changed'}
$new=ReadJson 'controls-final/summary.json';$newBefore=ReadJson 'controls-before/summary.json';$summaries['controls-final']=$new
if($new.rows.Count -ne 8 -or $new.excluded.Count -ne 0 -or $newBefore.coreSha256 -ne $beforeHash){throw 'New controls differ'}
foreach($summary in $summaries.Values){
 if($summary.coreSha256 -ne $configurations[0].coreCopies[0].sha256){throw 'Final comparison Core differs'}
 if($summary.policySha256 -ne $previous.formalAfter.policySha256 -or $summary.policySha256 -ne (Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'))){throw 'Original policy changed'}
 if(@($summary.rows|Where-Object conclusion -ne 'Pass').Count -ne 0){throw 'Comparison failed'}
}
foreach($row in $new.rows){
 $old=@($newBefore.rows|Where-Object id -ceq $row.id)
 if($old.Count -ne 1 -or $row.sourceSha256 -ne $old[0].sourceSha256 -or $row.executedRequestSha256 -ne $old[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $old[0].nativeDataSha256){throw 'New comparison input changed'}
 if(@($row.metrics|Where-Object nrmse -ge 1e-8).Count -ne 0){throw 'New precision target not closed'}
}
$archives=@{};foreach($p in $previous.preservedArchives.PSObject.Properties){$archives[$p.Name]=$p.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen archive changed'}}
if($archives.Count -ne 18){throw 'Expected eighteen prior archives'}
$fixtures=@{};foreach($p in $previous.preservedNativeFixtures.PSObject.Properties){$fixtures[$p.Name]=$p.Value};foreach($f in $previous.newFixtures){$fixtures[$f.name]=$f.sha256}
foreach($name in $fixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $fixtures[$name]){throw 'Frozen fixture changed'}}
if($fixtures.Count -ne 12){throw 'Expected twelve prior native fixtures'}
$fixturePath=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-poly128-boundary-zemax-2026-r1.zip';$zip=[IO.Compression.ZipFile]::OpenRead($fixturePath)
try{
 $reader=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open());try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
 foreach($entry in $manifest.entries){$stream=$zip.GetEntry($entry.path).Open();try{$h=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($h -ne $entry.sha256){throw 'New fixture payload changed'}}
 if($manifest.cases.Count -ne 8 -or $manifest.excluded.Count -ne 0){throw 'New fixture inventory differs'}
 $fixture=@{name=[IO.Path]::GetFileName($fixturePath);sha256=Hash $fixturePath;cases=8;excluded=@();payloadEntries=$manifest.entries.Count}
}finally{$zip.Dispose()}
$captures=@();$dee=0;$psf=0;$rays=0
foreach($list in @('native-jobs.json','isolation/native-jobs.json')){foreach($job in @(ReadJson $list)){
 $request=Get-Content $job.request -Raw|ConvertFrom-Json;$batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json
 $envData=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
 if($batch.exitCode -ne 0 -or $envData.major -ne 26 -or $envData.minor -ne 1 -or $envData.opticStudioVersion -ne 260127 -or !$envData.validLicense){throw 'Native run/version/license differs'}
 if($request.adapter -eq 'ray-audit'){
  $audit=Get-Content (Join-Path $job.output 'ray-audit.json') -Raw|ConvertFrom-Json
  if($audit.inputs.Count -ne 9 -or @($audit.launches|Where-Object success -ne $true).Count -ne 0 -or @($audit.surfaces.rays|Where-Object error -ne 0).Count -ne 0){throw 'Incomplete ray audit'};$rays++
 }else{
  $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
  if($request.analysisType -eq 'DiffractionEncircledEnergy'){
   if($data.dataSeries.Count -ne 2){throw 'Missing DEE curves'}
   foreach($s in $data.dataSeries){if($s.x.Count -ne 401 -or $s.y.Count -ne 401){throw 'Incomplete DEE curves'};foreach($y in $s.y){if($y.Count -ne 1 -or ![double]::IsFinite($y[0]) -or $y[0] -lt 0 -or $y[0] -gt 1){throw 'Invalid DEE energy'}}};$dee++
  }else{
   if($data.dataGrids.Count -ne 1){throw 'Missing PSF grid'};$g=$data.dataGrids[0]
   if($g.nx -ne $request.imageSampling -or $g.ny -ne $request.imageSampling -or $g.values.Count -ne $g.ny -or $g.dx -le 0 -or $g.dy -le 0){throw 'Invalid PSF dimensions'}
   foreach($row in $g.values){if($row.Count -ne $g.nx){throw 'Incomplete PSF row'};foreach($value in $row){if(![double]::IsFinite($value) -or $value -lt 0){throw 'Invalid PSF intensity'}}};$psf++
  }
 }
 $files=@(Get-ChildItem -LiteralPath $job.output -File|ForEach-Object {@{name=$_.Name;bytes=$_.Length;sha256=Hash $_.FullName}})
 $captures+=@{id=$job.id;state='Usable';group=$list;requestSha256=Hash $job.request;sourceSha256=Hash $request.input;files=$files}
}}
if($captures.Count -ne 20 -or $dee -ne 8 -or $psf -ne 10 -or $rays -ne 2){throw 'Native inventory differs'}
$repeats=@()
foreach($id in @('0472','0852')){
 $reference='artifacts/validation/dee-poly128-20261018/native/'+$id+'-poly128/data.json'
 $a=ReadJson ('native/'+$id+'-poly128/data.json');$b=Get-Content (Join-Path $repo $reference) -Raw|ConvertFrom-Json
 for($c=0;$c -lt 2;$c++){for($i=0;$i -lt 401;$i++){if($a.dataSeries[$c].x[$i] -ne $b.dataSeries[$c].x[$i] -or $a.dataSeries[$c].y[$i][0] -ne $b.dataSeries[$c].y[$i][0]){throw 'Native repeat differs'}}}
 $repeats+=@{id=$id;maximumPointDifference=0;reference=$reference}
}
$nativeProof=ReadJson 'boundary-diagnosis.json'
if($nativeProof.coreSha256 -ne $beforeHash -or $nativeProof.nativeRows.Count -ne 2){throw 'Diagnostic Core differs'}
foreach($row in $nativeProof.nativeRows){if($row.nrmse -gt 1e-12 -or $row.mixtureError -gt 1e-14){throw 'Native decomposition proof differs'}}
$support=ReadJson 'support-audit.json'
foreach($row in $support){if($row.id -in @('0472','0852') -and $row.changedNodes.Count -ne 4){throw 'Expected four changed rim nodes'}}
$sources=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
if($sources.Count -ne 41){throw 'C# source inventory differs'}
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log');if($LASTEXITCODE -ne 0){throw 'Diff check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='Relay and 123456 n128 polychromatic residuals closed with six spectral isolations; original tolerances and all previous regression identities retained'
 beforeCoreSha256=$beforeHash;beforeTests=$beforeTests
 constraints=@{originalTolerancePolicyUnchanged=$true;all99PriorFormalPassesPreserved=$true;noPriorNrmseIncreaseAbove1eMinus8=$true;prior1000ReleaseIdentitiesPreserved=$true;prior287FocusedDebugIdentitiesPreserved=$true;unchangedPriorTestSources=$unchangedTests;independentCookeTessarExcluded=$true}
 verification=@{testRelease=$release;testDebug=$debug;comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;configurations=$configurations;newMainTests=16;newPrecisionChecks=16;debugScope='Prior focused 287 plus sixteen new checks';format=@{includedCSharpFiles=41;exitCode=0;log='format-verify.log'};gitDiffCheckExitCode=0}
 formalBefore=$previous.formalAfter;formalAfter=$summaries['formal-final'];independentControls=$summaries['extra-final'];priorApochromatControls=$summaries['apochromat-final'];priorHighSamplingControls=$summaries['high-sampling-final'];priorFNumberControls=$summaries['fnum-final'];priorPolychromaticControls=$summaries['polychromatic-final'];priorPolychromatic128Controls=$summaries['polychromatic128-final'];newControlsBefore=$newBefore;newControlsAfter=$new;oldNumericalControls=$comparisons;unchangedPathControls=$pointwise
 supportProof=@{nativeSpectralDecomposition=$nativeProof;nativeRepeats=$repeats;pupilNodeAudit=$support;note='Uniform scalar effective support inferred from PSF Parseval energy; no captured complex-pupil inversion claimed'}
 numericalLimitations=@{allResidualsZero=$false;relay123456128PolychromaticControlsClosed=$true;originalMatrixWorstNrmse=($summaries['formal-final'].rows.metrics|Measure-Object nrmse -Maximum).Maximum;samplingScope='Captured four-lens n128 spectra and spectral isolations; higher polychromatic sampling, arbitrary pupils and critical perturbations not certified'}
 preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@($fixture);sourceFiles=$sources
 nativeCaptureSummary=@{attempts=20;usableCaptures=20;deeCaptures=8;psfCaptures=10;rayAuditCaptures=2;requestErrors=0;nativeUnavailable=0;note='Two lenses; includes repeats, six single-weight isolations, Huygens and FFT, plus two nine-ray audits'};nativeCaptures=$captures
 retainedFailureRecords=@('tests/boundary128-before.trx','tests-before.log','controls-before/summary.json')
 boundaries=@{fullRepositorySuiteRun=$false;fullDebugSuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false;generalNativePolychromaticConventionCertified=$false}
}
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $repo 'docs/validation/POLYCHROMATIC_128_BOUNDARY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified two n128 polychromatic closures, 99 prior plus 8 current formal passes, 1016/303 tests and frozen original evidence.'
