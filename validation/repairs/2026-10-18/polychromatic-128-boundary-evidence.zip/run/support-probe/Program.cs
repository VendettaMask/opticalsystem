using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var task=Path.Combine(args[0],"artifacts/validation/dee-poly128-boundary-20261018");const int n=128;
var cm=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;var rows=new List<object>();
foreach(var id in new[]{"0014","0308","0472","0852"}){
 var root=Path.Combine(args[0],"artifacts/validation/"+(id is "0014" or "0308"?"dee-poly128-20261018":"dee-poly128-boundary-20261018"));
 using var request=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,$"requests/{id}-poly128/dee.json")));
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(request.RootElement.GetProperty("input").GetString()!),".zmx");
 using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,$"native/{id}-poly128/model.json")));optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 var reference=optic.Wavelengths.First(w=>w.IsPrimary);var wave=optic.Wavelengths.MaxBy(w=>w.Micrometers)!;
 var cp=((double Rms,double T,double S))cm.Invoke(null,new object[]{optic,(0d,0d),reference})!;
 var pitch=Math.Sqrt(1d/n)/(2*cp.Rms/wave.Micrometers);var automatic=Math.Sqrt(n/32d);
 var f=DiffractionEngine.WorkingFNumber(optic,(0,0),wave,optic.RayAimingEnabled);var defaultPitch=wave.Micrometers*f*(n-2)/(2*n*automatic);var perF=automatic*defaultPitch/pitch/f;
 var oldStepX=perF*(.5/cp.S)/(n/2d-1);var oldStepY=perF*(.5/cp.T)/(n/2d-1);
 var stepX=1/(n*pitch/wave.Micrometers/(.5/cp.S));var stepY=1/(n*pitch/wave.Micrometers/(.5/cp.T));
 var changed=new List<object>();var beforeCount=0;var afterCount=0;
 for(var y=0;y<n;y++)for(var x=0;x<n;x++){
  var bx=(x-n/2d)*oldStepX;var by=(y-n/2d)*oldStepY;var ax=(x-n/2d)*stepX;var ay=(y-n/2d)*stepY;
  var b=bx*bx+by*by<=1;var a=ax*ax+ay*ay<=1;if(b)beforeCount++;if(a)afterCount++;
  if(b!=a)changed.Add(new{x,y,beforeX=bx,beforeY=by,afterX=ax,afterY=ay,beforeRadiusSquared=bx*bx+by*by,afterRadiusSquared=ax*ax+ay*ay,acceptedBefore=b,acceptedAfter=a});
 }
 rows.Add(new{id,oldStepX,oldStepY,stepX,stepY,beforeCircleCount=beforeCount,afterCircleCount=afterCount,changedNodes=changed});
}
File.WriteAllText(Path.Combine(task,"support-audit.json"),JsonSerializer.Serialize(rows));Console.WriteLine(JsonSerializer.Serialize(rows));
