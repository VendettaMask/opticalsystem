$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$jobs=@();$dee=@()
foreach($code in @('0472','0852')){
 $r=Get-Content (Join-Path $repo ('artifacts/validation/dee-poly128-20261018/requests/'+$code+'-poly128/dee.json')) -Raw|ConvertFrom-Json
 $id=$code+'-poly128';$dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir|Out-Null
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $job=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))};$jobs+=$job;$dee+=$job
 $r.canonicalAnalysisKey='Huygens PSF';$r.analysisType='HuygensPsf';$r.imageSampling=32;$r.imageDeltaMicrometers=0
 $r.zemaxSettings=[ordered]@{Normalize=$false;PupilSampleSize='S_128x128';ImageSampleSize='S_32x32';ImageDelta=0;Wavelength=0;UseCentroid=$false;Configuration=1;Rotation='Rotate_0';Type='Linear';Field=1;UsePolarization=$false}
 $path=Join-Path $dir 'huygens.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$id+'-huygens';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-huygens'))}
 $r=Get-Content (Join-Path $dir 'dee.json') -Raw|ConvertFrom-Json
 $r.adapter='ray-audit';$r.wavelength=2;$r|Add-Member removeVignettingFactors $false;$r|Add-Member surfaceRecordLimit 10000
 $inputs=@(@{px=0;py=0},@{px=0;py=1},@{px=0;py=-1},@{px=1;py=0},@{px=-1;py=0});$a=1/[Math]::Sqrt(2)
 foreach($x in @(-$a,$a)){foreach($y in @(-$a,$a)){$inputs+=@{px=$x;py=$y}}}
 for($i=0;$i -lt $inputs.Count;$i++){$inputs[$i].hx=0;$inputs[$i].hy=0;$inputs[$i].fieldIndex=0;$inputs[$i].pupilIndex=$i}
 $r|Add-Member rayAuditInputs $inputs;$path=Join-Path $dir 'rays.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$id+'-rays';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-rays'))}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($dee) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'dee-jobs.json') -Encoding utf8NoBOM
