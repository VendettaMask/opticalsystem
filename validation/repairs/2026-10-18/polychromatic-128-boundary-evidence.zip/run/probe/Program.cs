using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-poly128-boundary-20261018");
const int n=128,m=256;
var cm=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;
var rows=new List<object>();var nativeRows=new List<object>();
foreach(var id in new[]{"0014","0308","0472","0852"}){
 var prior=Path.Combine(repo,"artifacts/validation/dee-poly128-20261018");var root=id is "0014" or "0308"?prior:task;
 using var request=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,$"requests/{id}-poly128/dee.json")));
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(request.RootElement.GetProperty("input").GetString()!),".zmx");
 using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,$"native/{id}-poly128/model.json")));optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 var waves=optic.Wavelengths.ToArray();var primary=waves.First(w=>w.IsPrimary);var longest=waves.MaxBy(w=>w.Micrometers)!;
 var fp=DiffractionEngine.WorkingFNumber(optic,(0,0),primary,optic.RayAimingEnabled);
 var cp=((double Rms,double T,double S))cm.Invoke(null,new object[]{optic,(0d,0d),primary})!;
 var pitch=Math.Sqrt(1d/n)/(2*cp.Rms/longest.Micrometers);var automatic=Math.Sqrt(n/32d);
 var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),primary,optic.RayAimingEnabled);
 var expected=ReadCurves(Path.Combine(root,$"native/{id}-poly128/data.json"));
 var weights=waves.Select(w=>w.Weight/(w.Micrometers*w.Micrometers)).ToArray();
 double[][,]? nativeGrids=null;double nativePitch=0;
 if(id is "0472" or "0852"){
  using var hu=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,$"native/{id}-poly128-huygens/data.json")));nativePitch=hu.RootElement.GetProperty("dataGrids")[0].GetProperty("dx").GetDouble();
  nativeGrids=Enumerable.Range(1,3).Select(w=>ReadGrid(Path.Combine(root,$"isolation/{id}-w{w}/fft/data.json"))).ToArray();
  var nativePoly=ReadGrid(Path.Combine(root,$"isolation/{id}-fft-poly/data.json"));var sum=weights.Sum();var mix=0d;
  for(var y=0;y<m;y++)for(var x=0;x<m;x++)mix=Math.Max(mix,Math.Abs(nativeGrids.Select((a,i)=>weights[i]*a[y,x]).Sum()/sum-nativePoly[y,x]));
  nativeRows.Add(new{id,nativePitch,corePitch=pitch,nrmse=Metric(Curve(new[]{nativePoly},new[]{1d},nativePitch),expected[1]),mixtureError=mix,components=nativeGrids.Select((a,i)=>new{wave=i+1,count=m*(double)m/a.Cast<double>().Sum(),nrmse=Metric(Curve(new[]{a},new[]{1d},nativePitch),ReadCurves(Path.Combine(root,$"isolation/{id}-w{i+1}/dee/data.json"))[1])}).ToArray()});
 }
 foreach(var mode in new[]{"current","regular","referenceF","referenceF-regular","rmsF","rmsF-regular","direct","direct-regular","normalized","ratio","ratio-regular","rmsDefault","rmsDefault-regular","referenceF-exactPitch","perimeter"})foreach(var ideal in new[]{true,false}){
  var spectrum=mode=="current"?DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),waves,n,ideal).Select(p=>p.Result).ToArray():waves.Select(w=>{
   var fftF=DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled);
   var dp=w.Micrometers*fftF*(n-2)/(2*n*automatic);var perF=automatic*dp/pitch/fftF;
   var sx=perF*(.5/cp.S);var sy=perF*(.5/cp.T);
   if(mode.StartsWith("referenceF")){sx=sy=automatic*(w.Micrometers*fp*(n-2)/(2*n*automatic))/pitch;}
   if(mode.StartsWith("rmsF")){sx=sy=automatic*(w.Micrometers*(.5/cp.Rms)*(n-2)/(2*n*automatic))/pitch;}
   if(mode.StartsWith("direct")){sx=w.Micrometers*(.5/cp.S)*(n-2)/(2*n*pitch);sy=w.Micrometers*(.5/cp.T)*(n-2)/(2*n*pitch);}
   if(mode.StartsWith("ratio")){sx=(w.Micrometers/longest.Micrometers)*(cp.Rms/cp.S)/Math.Sqrt(n)*(n/2d-1);sy=(w.Micrometers/longest.Micrometers)*(cp.Rms/cp.T)/Math.Sqrt(n)*(n/2d-1);}
   if(mode.StartsWith("rmsDefault")){dp=w.Micrometers*(.5/cp.Rms)*(n-2)/(2*n*automatic);perF=automatic*dp/pitch/(.5/cp.Rms);sx=perF*(.5/cp.S);sy=perF*(.5/cp.T);}
   double? stepx=sx/(n/2d-1),stepy=sy/(n/2d-1);
   if(mode.EndsWith("regular")){stepx=stepy=null;}
   if(mode=="normalized"){stepx=1/(n*pitch/w.Micrometers/(.5/cp.S));stepy=1/(n*pitch/w.Micrometers/(.5/cp.T));}
   if(mode=="perimeter"){stepx=(w.Micrometers/longest.Micrometers)*(cp.Rms/cp.S)*Math.Sqrt(1d/n);stepy=(w.Micrometers/longest.Micrometers)*(cp.Rms/cp.T)*Math.Sqrt(1d/n);}
   var grid=new PupilGridSpecification(n,true,true,sx){StretchY=sy,ExplicitCoordinateStep=stepx,ExplicitCoordinateStepY=stepy};
   return (PsfResult)compute.Invoke(null,new object?[]{optic,(0d,0d),w,n,m,false,true,0d,null,null,true,ideal,optic.RayAimingEnabled,primary,pitch,true,null,sphere,grid})!;
  }).ToArray();
  var components=spectrum.Select((p,i)=>new{wave=i+1,count=ideal?100d*m*m/p.Values.Cast<double>().Sum():0,nrmse=nativeGrids==null?0:Metric(Curve(new[]{p.Values},new[]{1d},pitch),ReadCurves(Path.Combine(root,$"isolation/{id}-w{i+1}/dee/data.json"))[ideal?0:1])}).ToArray();
  var nr=Metric(Curve(spectrum.Select(p=>p.Values).ToArray(),weights,pitch),expected[ideal?0:1]);rows.Add(new{id,mode,ideal,pitch,fp,exactF=.5/cp.Rms,nrmse=nr,components});Console.WriteLine($"{id} {mode} {ideal}: {nr:G6} [{string.Join(',',components.Select(c=>c.count.ToString("F0")))}]");
 }
}
File.WriteAllText(Path.Combine(task,"boundary-diagnosis.json"),JsonSerializer.Serialize(new{coreSha256=Convert.ToHexStringLower(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(DiffractionEngine).Assembly.Location))),nativeRows,rows}));
static double[,] ReadGrid(string path){using var d=JsonDocument.Parse(File.ReadAllText(path));var values=d.RootElement.GetProperty("dataGrids")[0].GetProperty("values");var a=new double[m,m];for(var y=0;y<m;y++)for(var x=0;x<m;x++)a[(y+1)%m,(x+1)%m]=values[y][x].GetDouble();return a;}
static double[][] ReadCurves(string path){using var d=JsonDocument.Parse(File.ReadAllText(path));return d.RootElement.GetProperty("dataSeries").EnumerateArray().Select(s=>s.GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray()).ToArray();}
static double Metric(double[] values,double[] reference)=>Math.Sqrt(values.Zip(reference,(a,b)=>(a-b)*(a-b)).Average())/(reference.Max()-reference.Min());
static double[] Curve(double[][,] psfs,double[] weights,double pitch){
 var samples=Enumerable.Range(0,m).SelectMany(y=>Enumerable.Range(0,m).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,psfs.Select((s,i)=>weights[i]*s[(y+1)%m,(x+1)%m]).Sum()))).ToArray();
 var total=samples.Sum(s=>s.Weight);var center=(samples.Sum(s=>s.X*s.Weight)/total,samples.Sum(s=>s.Y*s.Weight)/total);
 var grid=new FftCumulativeEnergyGrid(samples,center,"encircled");var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(grid.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;
 var values=MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());var previous=0d;return values.Select(v=>previous=Math.Clamp(Math.Max(previous,v),0,1)).ToArray();}
