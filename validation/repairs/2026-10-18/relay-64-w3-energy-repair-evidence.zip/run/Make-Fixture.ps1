$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$target=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-finite-aiming-zemax-2026-r1.zip'
if(Test-Path $target){throw 'Never overwrite native fixture'}
$payload=@{};$cases=@();$records=@()
foreach($job in @(Get-Content (Join-Path $PSScriptRoot 'controls-v2/native-jobs.json') -Raw|ConvertFrom-Json)){
 $r=Get-Content $job.request -Raw|ConvertFrom-Json;$settings=Get-Content (Join-Path $job.output 'captured-settings.json') -Raw|ConvertFrom-Json
 if($r.pupilSampling -ne [int]$r.workbenchSettings.PupilSampling -or $r.wavelength -ne [int]$r.workbenchSettings.WavelengthNumber -or $settings.properties.SampleSize -ne ('S_'+$r.pupilSampling+'x'+$r.pupilSampling) -or $settings.selectors.Wavelength -ne $r.wavelength){throw 'Inconsistent settings'}
 $d=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json;if($d.dataSeries.Count -ne 2){throw 'Native curves unavailable'}
 $cases+=@{id=$job.id;pupilSampling=$r.pupilSampling;wavelength=$r.wavelength;settingsMatched=$true}
 $payload[$job.id+'/request.json']=$job.request;$payload[$job.id+'/source.zmx']=$r.input
 foreach($name in 'data.json','model.json','captured-settings.json','environment.json','batch-result.json'){$payload[$job.id+'/'+$name]=Join-Path $job.output $name}
}
foreach($wave in 1,2,3){$path=Join-Path $repo ('artifacts/validation/dee-relay64w3-repair-20261018/single-chief-relay-n64-w'+$wave);foreach($name in 'ray-audit.json','model.json','environment.json','batch-result.json'){$payload['rays/w'+$wave+'/'+$name]=Join-Path $path $name}}
$stream=[IO.File]::Open($target,[IO.FileMode]::CreateNew)
try{$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true);try{
 foreach($key in @($payload.Keys|Sort-Object)){
  $bytes=[IO.File]::ReadAllBytes($payload[$key]);$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($bytes));$entry=$zip.CreateEntry($key,[IO.Compression.CompressionLevel]::Optimal);$entryStream=$entry.Open();try{$entryStream.Write($bytes)}finally{$entryStream.Dispose()};$records+=@{path=$key;sha256=$hash;bytes=$bytes.Length}
 }
 $manifest=@{schemaVersion=1;scope='Finite centered refractive FFT pupil-map parity, original frozen 1e-8 curve guard, native first-quadrant stop-map and precise ordinary-ray invariance';cases=$cases;entries=$records;originalResidualReference='0472-n64-w3, unchanged native data SHA-256 884e1dd8b5020fdcbe1d01c82eabf8c2b45d2982f7f7ad0f13cd645264b5db25'}|ConvertTo-Json -Depth 12
 $entry=$zip.CreateEntry('manifest.json',[IO.Compression.CompressionLevel]::Optimal);$entryStream=$entry.Open();try{$entryStream.Write([Text.Encoding]::UTF8.GetBytes($manifest))}finally{$entryStream.Dispose()}
}finally{$zip.Dispose()}}finally{$stream.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($target);try{foreach($record in $records){$s=$zip.GetEntry($record.path).Open();try{$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($s))}finally{$s.Dispose()};if($hash -ne $record.sha256){throw 'Fixture readback mismatch'}}}finally{$zip.Dispose()}
@{path=[IO.Path]::GetRelativePath($repo,$target).Replace('\','/');sha256=(Get-FileHash $target).Hash.ToLowerInvariant();caseCount=$cases.Count;rayWaveCount=3;allPayloadHashesVerified=$true}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'fixture-result.json') -Encoding utf8NoBOM
