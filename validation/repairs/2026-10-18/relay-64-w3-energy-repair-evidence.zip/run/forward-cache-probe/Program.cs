using System.Text.Json;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Analysis;
var task=Path.Combine(args[0],"artifacts/validation/dee-relay64w3-repair-20261018");var current=Path.Combine(args[0],"artifacts/validation/dee-relay64w3-algorithm-20261018");using var req=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"tomography-fixed/zero/dee.json")));var optic=OpticalFormatCatalog.Import(File.ReadAllText(req.RootElement.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=true;var wave=optic.Wavelengths[2];var primary=optic.Wavelengths.First(w=>w.IsPrimary);var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),primary,true);var precise=new DecimalMeridional(optic,wave,sphere);
using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"cache-proof/original-rays/ray-audit.json")));var inputs=audit.RootElement.GetProperty("inputs");var rays=audit.RootElement.GetProperty("surfaces")[3].GetProperty("rays");const double radius=11.153414102018992;var scale=optic.Paraxial.EstimateEntrancePupilDiameter()/2/(optic.Paraxial.EstimateEntrancePupilLocation()-optic.SurfaceGroup.Items[0].CoordinateSystem.Origin.Z);
var output=new List<object>();
foreach(var representation in new[]{"slope","cosine"})foreach(var updateCount in new[]{0,1,2}){
 (double X,double Y) Sample(double x,double y) {var z=representation=="cosine"?Math.Sqrt(1-scale*scale*(x*x+y*y)):1;return precise.Stop(x*scale/z,y*scale/z);}
 var cache=new (double X,double Y)[3,3];for(var y=0;y<3;y++)for(var x=0;x<3;x++)cache[y,x]=Sample(x*.5,y*.5);
 (double X,double Y,double A,double B,double C,double D) Polynomial(double qx,double qy){var lx=L(qx);var ly=L(qy);var dx=D(qx);var dy=D(qy);double vx=0,vy=0,a=0,b=0,c=0,d=0;for(var y=0;y<3;y++)for(var x=0;x<3;x++){var v=cache[y,x];vx+=v.X*lx[x]*ly[y];vy+=v.Y*lx[x]*ly[y];a+=v.X*dx[x]*ly[y];b+=v.X*lx[x]*dy[y];c+=v.Y*dx[x]*ly[y];d+=v.Y*lx[x]*dy[y];}return(vx,vy,a,b,c,d);}
 var nodes=new List<object>();var error=new List<double>();var nativeValues=new List<double>();var computedValues=new List<double>();
 for(var i=0;i<inputs.GetArrayLength();i++){
 var px=inputs[i].GetProperty("px").GetDouble();var py=inputs[i].GetProperty("py").GetDouble();if(px<0||py<0||(px==0&&py==0))continue;
 var qx=px;var qy=py;for(var it=0;it<12;it++){var p=Polynomial(qx,qy);var ex=px-p.X;var ey=py-p.Y;var det=p.A*p.D-p.B*p.C;qx+=(p.D*ex-p.B*ey)/det;qy+=(p.A*ey-p.C*ex)/det;if(double.Hypot(ex,ey)<1e-15)break;}
 for(var it=0;it<updateCount;it++){var p=Polynomial(qx,qy);var actual=Sample(qx,qy);var ex=px-actual.X;var ey=py-actual.Y;var det=p.A*p.D-p.B*p.C;qx+=(p.D*ex-p.B*ey)/det;qy+=(p.A*ey-p.C*ex)/det;}
 var result=Sample(qx,qy);var actualRay=rays[i];var nx=actualRay.GetProperty("x").GetDouble()/radius;var ny=actualRay.GetProperty("y").GetDouble()/radius;var computed=double.Hypot(result.X,result.Y)/double.Hypot(px,py)-1;var native=double.Hypot(nx,ny)/double.Hypot(px,py)-1;nativeValues.Add(native);computedValues.Add(computed);error.Add(Math.Abs(computed-native));nodes.Add(new{px,py,computed,native});
 }
 var item=new{representation,updateCount,maximumDifference=error.Max(),meanDifference=error.Average(),nativeRms=Math.Sqrt(nativeValues.Average(v=>v*v)),computedRms=Math.Sqrt(computedValues.Average(v=>v*v)),nodes};output.Add(item);Console.WriteLine(JsonSerializer.Serialize(new{representation,updateCount,item.maximumDifference,item.meanDifference,item.nativeRms,item.computedRms}));
}
File.WriteAllText(Path.Combine(current,"forward-cache-diagnosis.json"),JsonSerializer.Serialize(output));
static double[] L(double x)=>new[]{2*(x-.5)*(x-1),4*x*(1-x),2*x*(x-.5)};
static double[] D(double x)=>new[]{4*x-3,4-8*x,4*x-1};
