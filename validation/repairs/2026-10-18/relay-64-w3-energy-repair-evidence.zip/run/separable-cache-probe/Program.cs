using System.Text.Json;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Analysis;
var previous=Path.Combine(args[0],"artifacts/validation/dee-relay64w3-repair-20261018");var current=Path.Combine(args[0],"artifacts/validation/dee-relay64w3-algorithm-20261018");var output=new List<object>();
foreach(var waveIndex in new[]{1,2,3}){
 using var req=JsonDocument.Parse(File.ReadAllText(Path.Combine(previous,"tomography-fixed/zero/dee.json")));var optic=OpticalFormatCatalog.Import(File.ReadAllText(req.RootElement.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=true;var wave=optic.Wavelengths[waveIndex-1];var primary=optic.Wavelengths.First(w=>w.IsPrimary);var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),primary,true);var precise=new DecimalMeridional(optic,wave,sphere);
 using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(previous,$"single-chief-relay-n64-w{waveIndex}/ray-audit.json")));var inputs=audit.RootElement.GetProperty("inputs");var rays=audit.RootElement.GetProperty("surfaces")[3].GetProperty("rays");const double radius=11.153414102018992;
 var cache=Enumerable.Range(0,3).Select(x=>precise.Launch(x*.5,0).X).ToArray();
 foreach(var update in new[]{"damped-full","two-damped-full","damped-diagonal","two-damped-diagonal"}){
 var nodes=new List<object>();var error=new List<double>();
 for(var i=0;i<inputs.GetArrayLength();i++){
  var px=inputs[i].GetProperty("px").GetDouble();var py=inputs[i].GetProperty("py").GetDouble();if(px<0||py<0||(px==0&&py==0))continue;
  var vx=cache.Zip(L(px),(v,l)=>v*l).Sum();var vy=cache.Zip(L(py),(v,l)=>v*l).Sum();var initial=precise.Stop(vx,vy);var steps=0;
  foreach(var damping in update.StartsWith("two")?new[]{.75,.9998}:new[]{.99995}){
   var p0=precise.Stop(vx,vy);if(double.Hypot(px-p0.X,py-p0.Y)*radius<1e-7)break;
   const double h=1e-6;var x1=precise.Stop(vx+h,vy);var x0=precise.Stop(vx-h,vy);var y1=precise.Stop(vx,vy+h);var y0=precise.Stop(vx,vy-h);var a=(x1.X-x0.X)/(2*h);var b=(y1.X-y0.X)/(2*h);var c=(x1.Y-x0.Y)/(2*h);var d=(y1.Y-y0.Y)/(2*h);if(update.EndsWith("diagonal")){b=c=0;}var det=a*d-b*c;var ex=px-p0.X;var ey=py-p0.Y;vx+=damping*(d*ex-b*ey)/det;vy+=damping*(a*ey-c*ex)/det;steps++;
  }
  var result=precise.Stop(vx,vy);var actual=rays[i];var nx=actual.GetProperty("x").GetDouble()/radius;var ny=actual.GetProperty("y").GetDouble()/radius;var distance=double.Hypot(result.X-nx,result.Y-ny);error.Add(distance);nodes.Add(new{px,py,x=result.X,y=result.Y,nx,ny,initialX=initial.X,initialY=initial.Y,steps,difference=distance});
 }
 var item=new{waveIndex,update,maximumDifference=error.Max(),meanDifference=error.Average(),rmsDifference=Math.Sqrt(error.Average(v=>v*v)),nodes};output.Add(item);Console.WriteLine(JsonSerializer.Serialize(new{waveIndex,update,item.maximumDifference,item.meanDifference,item.rmsDifference}));
 }
}
File.WriteAllText(Path.Combine(current,"separable-cache-diagnosis.json"),JsonSerializer.Serialize(output));
static double[] L(double x)=>new[]{2*(x-.5)*(x-1),4*x*(1-x),2*x*(x-.5)};
