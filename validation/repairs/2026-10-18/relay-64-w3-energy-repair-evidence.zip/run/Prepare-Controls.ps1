$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'));$prior=Join-Path $repo 'artifacts/validation/dee-relay64w3-20261018'
$base=Get-Content (Join-Path $prior 'requests/relay-n64-w3/dee.json') -Raw|ConvertFrom-Json
$dir=Join-Path $PSScriptRoot 'controls-v2';New-Item -ItemType Directory "$dir/sources"|Out-Null
$specs=@(@('original32',32,3,25,250),@('original64',64,3,25,250),@('original128',128,3,25,250),@('original256',256,3,25,250),@('epd24',64,3,24,250),@('epd26',64,3,26,250),@('object-minus',64,3,25,249.99),@('object-plus',64,3,25,250.01),@('wave1',64,1,25,250),@('wave2',64,2,25,250))
$jobs=@()
foreach($spec in $specs){
 $r=Get-Content (Join-Path $prior 'requests/relay-n64-w3/dee.json') -Raw|ConvertFrom-Json;$id=$spec[0];$r.pupilSampling=$spec[1];$r.imageSampling=2*$spec[1];$r.wavelength=$spec[2]; $r.workbenchSettings.PupilSampling=[string]$spec[1]; $r.workbenchSettings.ImageSampling=[string](2*$spec[1]); $r.workbenchSettings.WavelengthNumber=[string]$spec[2]; $r.zemaxSettings.SampleSize="S_"+$spec[1]+"x"+$spec[1]; $r.zemaxSettings.HuygensSample=$r.zemaxSettings.SampleSize; $r.zemaxSettings.Wavelength=$spec[2]
 if($spec[3] -ne 25 -or $spec[4] -ne 250){
  $text=[IO.File]::ReadAllText($base.input)
  if($spec[3] -ne 25){$text=[regex]::Replace($text,'(?m)^ENPD 25\s*$','ENPD '+$spec[3])}
  if($spec[4] -ne 250){foreach($surf in @(0,7)){$pattern='(?ms)(^SURF '+$surf+'\r?\n.*?^\s*DISZ )250(?=\s)';if([regex]::Matches($text,$pattern).Count -ne 1){throw 'Unexpected thickness source'};$text=[regex]::Replace($text,$pattern,('${1}'+$spec[4]))}}
  $r.input=Join-Path $dir ('sources/'+$id+'.zmx');[IO.File]::WriteAllText($r.input,$text)
 }
 $path=Join-Path $dir ($id+'.json');$r|ConvertTo-Json -Depth 35|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$id;request=$path;output=(Join-Path $dir $id)}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content "$dir/native-jobs.json" -Encoding utf8NoBOM

