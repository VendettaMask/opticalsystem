$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read([string]$path){Get-Content -LiteralPath (Join-Path $PSScriptRoot $path) -Raw|ConvertFrom-Json}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object);trxSha256=Hash (Join-Path $PSScriptRoot ('tests/'+$name))}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/RELAY_64_W3_AIMING_DIAGNOSIS_2026-10-18.json') -Raw|ConvertFrom-Json
$beforeCore=Hash (Join-Path $PSScriptRoot 'Core.before.dll');$afterCore=Hash (Join-Path $PSScriptRoot 'Core.release-final.dll')
if($beforeCore -ne $previous.afterCoreSha256 -or $beforeCore -eq $afterCore){throw 'Wrong before/after Core'}
$changedExisting=@('src/OpticalSystemDesign.Core/Analysis/DiffractionEngine.cs','src/OpticalSystemDesign.Core/Analysis/DiffractionEngine.CumulativeEnergy.cs','src/OpticalSystemDesign.Core/Analysis/WavefrontEngine.cs')
foreach($source in $previous.sourceFiles){if($source.path -notin $changedExisting -and (Hash (Join-Path $repo $source.path)) -ne $source.sha256){throw ('Unrelated C# source changed: '+$source.path)}}
$paths=@($previous.sourceFiles.path)+@('src/OpticalSystemDesign.Core/Raytrace/RayGenerator.FftAiming.cs','tests/OpticalSystemDesign.Tests/FiniteFftAimingEnergyTests.cs')
$paths=$paths|Sort-Object -Unique;if($paths.Count -ne 46){throw 'Expected 46 C# files in the cumulative repair inventory'}
$sourceFiles=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
$paths|Set-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt') -Encoding utf8NoBOM
foreach($path in $paths){foreach($line in [IO.File]::ReadAllLines((Join-Path $repo $path))){if($line -match '\s+$'){throw ('Trailing whitespace: '+$path)}}}
$summaries=@{};$identity=@();$deltas=@();$changedCurves=0;$oldCount=0
foreach($group in $previous.allFormalGroups.PSObject.Properties){
 $now=Read ($group.Name+'/summary.json');$old=$group.Value;$summaries[$group.Name]=$now
 if($now.rows.Count -ne $old.rows.Count -or $now.excluded.Count -ne $old.excluded.Count -or $now.policySha256 -ne $old.policySha256 -or $now.coreSha256 -ne $afterCore){throw 'Old formal inventory/policy/Core differs'}
 foreach($row in $now.rows){
  $match=@($old.rows|Where-Object id -ceq $row.id);if($match.Count -ne 1 -or $row.conclusion -ne 'Pass'){throw 'Old formal pass lost'}
  foreach($key in 'sourceSha256','executedRequestSha256','nativeDataSha256'){if($row.$key -ne $match[0].$key){throw 'Frozen input changed'}}
  for($series=0;$series -lt $row.metrics.Count;$series++){
   $increase=$row.metrics[$series].nrmse-$match[0].metrics[$series].nrmse
   if($increase -gt 1e-8){throw 'Old NRMSE increased beyond unchanged delta guard'}
   $deltas+=@{group=$group.Name;id=$row.id;series=$series;before=$match[0].metrics[$series].nrmse;after=$row.metrics[$series].nrmse;increase=$increase}
  }
  $newWb=Join-Path $PSScriptRoot ($group.Name+'/'+$row.id+'/normalized-workbench.json')
  $oldWb=Join-Path $repo ('artifacts/validation/dee-relay64w3-repair-20261018/'+$group.Name+'/'+$row.id+'/normalized-workbench.json')
  $same=(Hash $newWb) -eq (Hash $oldWb);if(!$same){$changedCurves++}
  $newZ=Join-Path $PSScriptRoot ($group.Name+'/'+$row.id+'/normalized-zemax.json')
  $oldZ=Join-Path $repo ('artifacts/validation/dee-relay64w3-repair-20261018/'+$group.Name+'/'+$row.id+'/normalized-zemax.json')
  if((Hash $newZ) -ne (Hash $oldZ)){throw 'Normalized native reference changed'}
  $identity+=@{group=$group.Name;id=$row.id;allInputHashesUnchanged=$true;normalizedNativeBytesUnchanged=$true;workbenchBytesUnchanged=$same;normalizedWorkbenchSha256=Hash $newWb};$oldCount++
 }
}
if($oldCount -ne 125){throw 'Expected 125 prior comparison instances'}
$fresh=Read 'aiming-final/summary.json';$beforeFresh=Read 'aiming-before/summary.json';$summaries['aiming-final']=$fresh
if($fresh.rows.Count -ne 10 -or $fresh.excluded.Count -ne 0 -or $beforeFresh.rows.Count -ne 10 -or $beforeFresh.coreSha256 -ne $beforeCore){throw 'Fresh before/after controls incomplete'}
foreach($row in $fresh.rows){if($row.conclusion -ne 'Pass' -or @($row.metrics|Where-Object nrmse -ge 1e-8).Count -gt 0){throw 'New control does not pass original strict guard'};$old=@($beforeFresh.rows|Where-Object id -ceq $row.id)[0];foreach($key in 'sourceSha256','executedRequestSha256','nativeDataSha256'){if($old.$key -ne $row.$key){throw 'Before/after control input changed'}}}
$target=@($summaries['formal-final'].rows|Where-Object id -ceq '0472-n64-w3')[0];$beforeTarget=$previous.target
if($target.metrics[1].nrmse -ge 1e-8 -or $target.metrics[1].nrmse -ne 1.270036400965231e-9 -or $target.metrics[1].nrmse -ge $beforeTarget.metrics[1].nrmse/8){throw 'Original target not substantially repaired'}
$policy=Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json')
foreach($summary in $summaries.Values){if($summary.coreSha256 -ne $afterCore -or $summary.policySha256 -ne $policy -or @($summary.rows|Where-Object conclusion -ne 'Pass').Count -gt 0){throw 'Formal status/core/policy differs'}}
$testRelease=Tests 'related-release-final.trx';$testDebug=Tests 'related-debug-final.trx';$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx';$newCandidate=Tests 'aiming-release-candidate.trx';$newBefore=Tests 'aiming-before.trx'
foreach($spec in @(@($testRelease,1066,$previous.verification.testRelease),@($testDebug,353,$previous.verification.testDebug),@($comparisonRelease,5,$previous.verification.comparisonRelease),@($comparisonDebug,5,$previous.verification.comparisonDebug))){
 $test=$spec[0];if($test.total -ne $spec[1] -or $test.passed -ne $spec[1] -or $test.failed -ne 0 -or $test.skipped -ne 0){throw 'Completed tests mismatch'}
 foreach($name in $spec[2].names){if($name -cnotin $test.names){throw 'Old test identity lost'}}
}
if($newCandidate.total -ne 26 -or $newCandidate.passed -ne 26 -or $newBefore.total -ne 20 -or $newBefore.failed -ne 2 -or $newBefore.passed -ne 18){throw 'New guard before/after proof differs'}
$configurations=@()
foreach($oldConfiguration in $previous.defaultConfigurationsUnchanged){
 $configuration=$oldConfiguration.configuration;$log=Join-Path $PSScriptRoot ('build-'+$configuration.ToLowerInvariant()+'-final.log');$text=[IO.File]::ReadAllText($log)
 $projects=@([regex]::Matches($text,'(?m)^\s*[^\r\n]+ -> [^\r\n]+\.dll\r?$'))
 if($projects.Count -ne 19 -or $text -notmatch '0 个警告' -or $text -notmatch '0 个错误'){throw ('Root build incomplete: '+$configuration)}
 $expected=Hash (Join-Path $repo ('src/OpticalSystemDesign.Core/bin/'+$configuration+'/net10.0/OpticalSystemDesign.Core.dll'));$copies=@()
 foreach($copy in $oldConfiguration.coreCopies){$hash=Hash (Join-Path $repo $copy.path);if($hash -ne $expected){throw 'Default output Core identity mismatch'};$copies+=@{path=$copy.path;sha256=$hash}}
 if($configuration -eq 'Release' -and $expected -ne $afterCore){throw 'Test/formal Core mismatch'}
 $configurations+=@{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies;logSha256=Hash $log}
}
$archives=@{};foreach($a in $previous.preservedArchives.PSObject.Properties){$archives[$a.Name]=$a.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen archive changed'}};if($archives.Count -ne 23){throw 'Expected 23 frozen archives'}
$fixtures=$previous.preservedNativeFixtures;foreach($f in $fixtures.PSObject.Properties){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$f.Name))) -ne $f.Value){throw 'Old fixture changed'}};if(@($fixtures.PSObject.Properties).Count -ne 15){throw 'Expected 15 old fixtures'}
$newFixture=Read 'fixture-result.json';if((Hash (Join-Path $repo $newFixture.path)) -ne $newFixture.sha256){throw 'New fixture changed'}
$captures=@()
foreach($list in 'controls-v2/native-jobs.json','dense/native-jobs.json','controls/native-jobs.json'){
 foreach($job in @(Read $list)){
  $request=Get-Content $job.request -Raw|ConvertFrom-Json;$environment=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json;$batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json;$model=Get-Content (Join-Path $job.output 'model.json') -Raw|ConvertFrom-Json
  if($batch.exitCode -ne 0 -or $environment.major -ne 26 -or $environment.minor -ne 1 -or $environment.opticStudioVersion -ne 260127 -or !$environment.validLicense){throw 'Native version/license/completion differs'}
  $accepted=$list -ne 'controls/native-jobs.json';$dataName=if($request.adapter -eq 'ray-audit'){'ray-audit.json'}else{'data.json'};$data=Get-Content (Join-Path $job.output $dataName) -Raw|ConvertFrom-Json
  $settings=$null
  if($list -eq 'controls-v2/native-jobs.json'){
   $settings=Get-Content (Join-Path $job.output 'captured-settings.json') -Raw|ConvertFrom-Json
   if($data.dataSeries.Count -ne 2 -or @($data.dataSeries|Where-Object {$_.x.Count -ne 401 -or $_.y.Count -ne 401}).Count -gt 0){throw 'Native control unavailable/incomplete'}
   if($request.pupilSampling -ne [int]$request.workbenchSettings.PupilSampling -or $request.wavelength -ne [int]$request.workbenchSettings.WavelengthNumber -or $settings.properties.SampleSize -ne ('S_'+$request.pupilSampling+'x'+$request.pupilSampling) -or $settings.selectors.Wavelength -ne $request.wavelength){throw 'Native/workbench settings inconsistent'}
   if(!$model.rayAiming.UseRayAimingCache -or $model.rayAiming.UseEnhancedRayAiming -or $model.rayAiming.RayAiming -ne 'Paraxial'){throw 'Original aiming settings changed'}
   if($job.id -eq 'object-minus' -and ($model.surfaces[0].Thickness -ne 249.99 -or $model.surfaces[7].Thickness -ne 249.99)){throw 'Negative conjugate control differs'}
   if($job.id -eq 'object-plus' -and ($model.surfaces[0].Thickness -ne 250.01 -or $model.surfaces[7].Thickness -ne 250.01)){throw 'Positive conjugate control differs'}
  }
  if($list -eq 'dense/native-jobs.json' -and ($data.inputs.Count -ne 1080 -or @($data.surfaces.rays|Where-Object error -ne 0).Count -ne 0)){throw 'Dense native rays incomplete'}
  $captures+=@{group=$list;id=$job.id;usableDiagnosticOrControl=$accepted;excludedReason=$(if(!$accepted){'Initial top-level and nested analysis settings not synchronized; two large conjugate cases have no native curves'}else{$null});requestSha256=Hash $job.request;sourceSha256=Hash $request.input;dataSha256=Hash (Join-Path $job.output $dataName);modelSha256=Hash (Join-Path $job.output 'model.json');version='2026 R1 build 260127';validLicense=$true;rayAiming=$model.rayAiming;capturedSettings=$settings;nativeCurveAvailable=$(if($dataName -eq 'data.json'){$data.dataSeries.Count -eq 2}else{$null})}
 }
}
if($captures.Count -ne 21 -or @($captures|Where-Object usableDiagnosticOrControl).Count -ne 11){throw 'Native capture inventory differs'}
if((Hash (Join-Path $PSScriptRoot 'controls-v2/original64/data.json')) -ne $beforeTarget.nativeDataSha256){throw 'Original native repeat differs'}
$dense=Read 'dense-product-map.json';if($dense.count -ne 1080 -or $dense.maximumStopErrorMillimeters -gt 1.01e-7){throw 'Dense map diagnostic boundary differs'}
$proof=@{date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD);scope='Relay n64 selected wavelength 3 FFT cumulative-energy input mapping repair';targetClosed=$true;closureCriterion='Original strict curve guard 1e-8, original frozen request/reference, substantive product reduction greater than 8x, prior regressions retained';productCodeChanged=$true;coreUnchanged=$false;beforeCoreSha256=$beforeCore;afterCoreSha256=$afterCore;beforeTarget=$beforeTarget;target=$target;allFormalGroups=$summaries;formalBeforeNewControls=$beforeFresh;priorComparisonIdentities=$identity;metricDeltas=$deltas;priorInstanceCount=$oldCount;priorWorkbenchChangedCount=$changedCurves;maximumOldNrmseIncrease=($deltas.increase|Measure-Object -Maximum).Maximum;formalValidCount=135;originalMatrixMaximumNrmse=($summaries['formal-final'].rows.metrics.nrmse|Measure-Object -Maximum).Maximum;sourceFiles=$sourceFiles;changedExistingCSharp=$changedExisting;preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@($newFixture);verification=@{testRelease=$testRelease;testDebug=$testDebug;comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;newTests=26;newBefore=$newBefore;newAfter=$newCandidate;beforeGuardIdentity=(Read 'before-guard-identity.json');configurations=$configurations};nativeCaptures=$captures;nativeCaptureSummary=@{successfulExecutions=21;acceptedControls=10;acceptedDenseAudits=1;excludedInitialControls=10};denseProductMap=$dense;nativeInputModelCandidates=(Read 'separable-cache-diagnosis.json');constraints=@{originalComparisonPolicyUnchanged=$true;originalCurveGuardUnchanged='1e-8';ordinaryPreciseStopAimingUnchanged=$true;physicalAperturesUnchanged=$true;nativeDataUsedAtRuntime=$false;curveOrPhaseFitting=$false;rayInputModelInferredFromCaptures=$true;independentCookeTessarExcluded=$true};boundaries=@('Finite centered refractive scalar FFT cumulative-energy mapping only; other geometry/fields and ordinary precise rays retain prior paths','Dense arbitrary pupil points near stop-map stopping branches differ up to 1.00089e-7 mm; no universal bitwise native cache claim','Original strict residual item closed at 1.270036400965231e-9; nonzero residual remains','Initial inconsistent control requests, unavailable native curves, early tool-build audit warnings and log-driver collision preserved and excluded from final success counts','No installer, commit or push')}
$proof|ConvertTo-Json -Depth 75|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 75|Set-Content (Join-Path $repo 'docs/validation/RELAY_64_W3_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified repaired frozen target, 135 passing formal instances, old input hashes, 1066/353/5/5 tests, 2 failing old-Core guards, 19-project default builds, 23 archives and 15 old fixtures.'
