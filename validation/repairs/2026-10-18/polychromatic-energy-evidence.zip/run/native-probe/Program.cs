using System.Text.Json;
using System.Numerics;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-polychromatic-20261018");const int n=64,m=128;
var optic=OpticalFormatCatalog.Import(File.ReadAllText(Path.Combine(repo,"artifacts/zemax-standard-samples/20261015/full-matrix-v1/sources/apochromat.zmx")),".zmx");
var waves=optic.Wavelengths.ToArray();var grids=new List<double[,]>();double pitch=0;
for(var w=0;w<=8;w++){using var d=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"fft-diagnostic/w{w}/data.json")));var g=d.RootElement.GetProperty("dataGrids")[0];pitch=g.GetProperty("dx").GetDouble();var a=new double[m,m];for(var y=0;y<m;y++)for(var x=0;x<m;x++)a[(y+1)%m,(x+1)%m]=g.GetProperty("values")[y][x].GetDouble();grids.Add(a);}
using var native=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"native/apo-poly64/data.json")));var expected=native.RootElement.GetProperty("dataSeries")[1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
var rows=new List<object>();
var isolated=new List<double[,]>();var isolationMetrics=new List<object>();
for(var w=1;w<=8;w++){
 using var d=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"isolation/w{w}/fft/data.json")));var gg=d.RootElement.GetProperty("dataGrids")[0];var a=new double[m,m];var err=0d;
 for(var y=0;y<m;y++)for(var x=0;x<m;x++){var value=gg.GetProperty("values")[y][x].GetDouble();a[(y+1)%m,(x+1)%m]=value;err=Math.Max(err,Math.Abs(value-grids[w][(y+1)%m,(x+1)%m]));}
 isolated.Add(a);isolationMetrics.Add(new{wave=w,maxDifferenceFromSelected=err,sum=a.Cast<double>().Sum(),peak=a.Cast<double>().Max()});
}
var polyDifference=0d;var spectralWeights=waves.Select(w=>w.Weight/(w.Micrometers*w.Micrometers)).ToArray();var spectralNorm=spectralWeights.Sum();
for(var y=0;y<m;y++)for(var x=0;x<m;x++)polyDifference=Math.Max(polyDifference,Math.Abs(isolated.Select((a,i)=>a[y,x]*spectralWeights[i]).Sum()/spectralNorm-grids[0][y,x]));
foreach(var mode in new[]{"polyNative","lambda2","weights","flux","fluxLambda2","pupilArea","pupilAreaF4","pupilCountSquared","pupilCount"}){
 var psfs=mode=="polyNative"?new[]{grids[0]}:grids.Skip(1).ToArray();
 var weights=mode=="polyNative"?new[]{1d}:waves.Select((w,i)=>{
  var count=4d*n*n/grids[i+1].Cast<double>().Sum();
  var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,false);
  return w.Weight*(mode switch{"lambda2"=>1/Math.Pow(w.Micrometers,2),"flux"=>1/grids[i+1].Cast<double>().Sum(),"fluxLambda2"=>1/grids[i+1].Cast<double>().Sum()/Math.Pow(w.Micrometers,2),"pupilArea"=>Math.Pow(w.Micrometers*count,2),"pupilAreaF4"=>Math.Pow(w.Micrometers*count*f*f,2),"pupilCountSquared"=>count*count,"pupilCount"=>count,_=>1});
 }).ToArray();
 var yy=Curve(psfs,weights,pitch);var rmse=Math.Sqrt(yy.Zip(expected,(a,b)=>(a-b)*(a-b)).Average())/(expected.Max()-expected.Min());
 var maxPolyError=0d;var norm=weights.Sum();for(var y=0;y<m;y++)for(var x=0;x<m;x++)maxPolyError=Math.Max(maxPolyError,Math.Abs(psfs.Select((a,i)=>a[y,x]*weights[i]).Sum()/norm-grids[0][y,x]));
 rows.Add(new{mode,nrmse=rmse,maxError=yy.Zip(expected,(a,b)=>Math.Abs(a-b)).Max(),maxPolyError});
}
var components=new List<object>();
for(var i=0;i<8;i++){
 var w=waves[i];var p=DiffractionEngine.ComputeFftPsf(optic,(0,0),w,n,m,zemaxFftSampling:true,cellCenteredPupil:true,referenceWavelength:waves.First(w=>w.IsPrimary),imageDelta:pitch,ignoreScalarTransmission:true);
 var err=0d;for(var y=0;y<m;y++)for(var x=0;x<m;x++)err=Math.Max(err,Math.Abs(p.Values[y,x]/100-grids[i+1][y,x]));
 components.Add(new{wavelength=i+1,lambda=w.Micrometers,coreSum=p.Values.Cast<double>().Sum()/100,nativeSum=grids[i+1].Cast<double>().Sum(),corePeak=p.PeakStrehlRatio,nativePeak=grids[i+1].Cast<double>().Max(),maxError=err});
}
// Offline linear decomposition only: coefficients are diagnostic evidence,
// never read by product computation or used as acceptance references.
var q=new List<double[]>();var rr=new double[8,8];var projections=new double[8];
for(var i=0;i<8;i++){
 var v=grids[i+1].Cast<double>().ToArray();
 for(var pass=0;pass<2;pass++)for(var j=0;j<i;j++){var a=v.Zip(q[j],(x,y)=>x*y).Sum();rr[j,i]+=a;for(var k=0;k<v.Length;k++)v[k]-=a*q[j][k];}
 rr[i,i]=Math.Sqrt(v.Sum(x=>x*x));for(var k=0;k<v.Length;k++)v[k]/=rr[i,i];q.Add(v);projections[i]=v.Zip(grids[0].Cast<double>(),(a,b)=>a*b).Sum();
}
var coefficients=new double[8];for(var i=7;i>=0;i--){var value=projections[i];for(var j=i+1;j<8;j++)value-=rr[i,j]*coefficients[j];coefficients[i]=value/rr[i,i];}
var fitError=0d;for(var y=0;y<m;y++)for(var x=0;x<m;x++)fitError=Math.Max(fitError,Math.Abs(Enumerable.Range(0,8).Sum(i=>grids[i+1][y,x]*coefficients[i])-grids[0][y,x]));
var normalized=waves.Select(w=>w.Weight/(w.Micrometers*w.Micrometers)).ToArray();var normsum=normalized.Sum();
var unmix=waves.Select((w,i)=>new{wave=i+1,coefficient=coefficients[i],expected=normalized[i]/normsum,ratio=coefficients[i]*normsum/normalized[i],count=4d*n*n/grids[i+1].Cast<double>().Sum()}).ToArray();
var result=new{pitch,rows,components,fitError,unmix,isolationMetrics,isolatedPolyMaxDifference=polyDifference};Console.WriteLine(JsonSerializer.Serialize(result));File.WriteAllText(Path.Combine(task,"native-spectral-diagnosis.json"),JsonSerializer.Serialize(result));
static double[] Curve(double[][,] psfs,double[] weights,double pitch){
 var samples=Enumerable.Range(0,m).SelectMany(y=>Enumerable.Range(0,m).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,psfs.Select((s,i)=>weights[i]*s[(y+1)%m,(x+1)%m]).Sum()))).ToArray();var total=samples.Sum(s=>s.Weight);var grid=new FftCumulativeEnergyGrid(samples,(samples.Sum(s=>s.X*s.Weight)/total,samples.Sum(s=>s.Y*s.Weight)/total),"encircled");
 var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(grid.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;
 return MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());
}
