$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$template=Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout/0014-all-waves/request.json'
$jobs=@();$dee=@()
foreach($n in @(32,64,128)){
 $id='apo-poly'+$n;$r=Get-Content $template -Raw|ConvertFrom-Json
 $r.pupilSampling=$n;$r.imageSampling=2*$n;$r.workbenchSettings.PupilSampling="$n";$r.workbenchSettings.ImageSampling="$(2*$n)";$r.zemaxSettings.SampleSize="S_${n}x${n}"
 $dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir|Out-Null
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $job=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))};$jobs+=$job;$dee+=$job
 if($n -eq 64){
  $r.canonicalAnalysisKey='Huygens PSF';$r.analysisType='HuygensPsf';$r.imageSampling=32;$r.imageDeltaMicrometers=0
  $r.zemaxSettings=[ordered]@{Normalize=$false;PupilSampleSize='S_64x64';ImageSampleSize='S_32x32';ImageDelta=0;Wavelength=0;UseCentroid=$false;Configuration=1;Rotation='Rotate_0';Type='Linear';Field=1;UsePolarization=$false}
  $path=Join-Path $dir 'huygens.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-huygens';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-huygens'))}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($dee) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'dee-jobs.json') -Encoding utf8NoBOM
