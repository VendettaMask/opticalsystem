using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Domain;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-polychromatic-20261018");
var rows=new List<object>();
using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(repo,"artifacts/validation/numerical-residuals-20261018/holdout-jobs.json")));
foreach(var job in jobs.RootElement.EnumerateArray().Where(j=>j.GetProperty("id").GetString()!.EndsWith("all-waves"))){
 var id=job.GetProperty("id").GetString()!;
 using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=request.RootElement;
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");
 using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));
 optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 var n=r.GetProperty("pupilSampling").GetInt32();var waves=optic.Wavelengths.ToArray();
 using var native=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"data.json")));
 var spectrum=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),waves,n,true);
 var pitch=spectrum[0].Result.SampleSpacingMicrometers;
 var primary=waves.First(w=>w.IsPrimary);var longest=waves.MaxBy(w=>w.Nanometers)!;
 var coneMethod=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
 var coneRows=waves.Select(w=>{var c=((double Rms,double T,double S))coneMethod.Invoke(null,new object[]{optic,(0d,0d),w})!;return new{lambda=w.Micrometers,w.Weight,c.Rms,c.T,c.S,f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled)};}).ToArray();
 var variants=new List<object>();
 foreach(var ideal in new[]{true,false}){
  if(!ideal)spectrum=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),waves,n,false);
  foreach(var mode in new[]{"lambda2","weightOnly","flux","rawCount","rawCountSquared"}){
   var weights=spectrum.Select(item=>{
    var sum=item.Result.Values.Cast<double>().Sum();var count=100d*4*n*n/sum;
    return item.Wavelength.Weight*(mode switch{"lambda2"=>1/Math.Pow(item.Wavelength.Micrometers,2),"flux"=>1/sum,"rawCount"=>count,"rawCountSquared"=>count*count,_=>1});
   }).ToArray();
   var values=Enumerable.Range(0,2*n).SelectMany(y=>Enumerable.Range(0,2*n).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,spectrum.Select((s,i)=>weights[i]*s.Result.Values[(y+1)%(2*n),(x+1)%(2*n)]).Sum()))).ToArray();
   var sum=values.Sum(s=>s.Weight);var center=(X:values.Sum(s=>s.X*s.Weight)/sum,Y:values.Sum(s=>s.Y*s.Weight)/sum);
   var grid=new FftCumulativeEnergyGrid(values,center,"encircled");var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(grid.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;
   var xx=Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray();var yy=MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,xx);
   var expected=native.RootElement.GetProperty("dataSeries")[ideal?0:1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
   var rmse=Math.Sqrt(yy.Zip(expected,(a,b)=>(a-b)*(a-b)).Average());
   variants.Add(new{ideal,mode,nrmse=rmse/(expected.Max()-expected.Min()),maxError=yy.Zip(expected,(a,b)=>Math.Abs(a-b)).Max()});
  }
 }
 rows.Add(new{id,n,pitch,cones=coneRows,support=spectrum.Select(s=>new{lambda=s.Wavelength.Micrometers,count=100d*4*n*n/s.Result.Values.Cast<double>().Sum()}).ToArray(),variants});
 Console.WriteLine(id+": "+JsonSerializer.Serialize(variants));
}
File.WriteAllText(Path.Combine(task,"spectral-weight-diagnosis.json"),JsonSerializer.Serialize(rows));
