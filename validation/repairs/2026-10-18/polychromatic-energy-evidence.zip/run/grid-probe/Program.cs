using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Domain;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-polychromatic-20261018");
var cm=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;
var rows=new List<object>();
var jobs=new List<JsonElement>();foreach(var list in new[]{Path.Combine(repo,"artifacts/validation/numerical-residuals-20261018/holdout-jobs.json"),Path.Combine(task,"dee-jobs.json")}){using var j=JsonDocument.Parse(File.ReadAllText(list));jobs.AddRange(j.RootElement.EnumerateArray().Where(e=>e.GetProperty("id").GetString()!.Contains("all-waves")||e.GetProperty("id").GetString()!.StartsWith("apo-poly")).Select(e=>e.Clone()));}
foreach(var job in jobs){
 var id=job.GetProperty("id").GetString()!;using var req=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=req.RootElement;
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 using var native=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"data.json")));var n=r.GetProperty("pupilSampling").GetInt32();var waves=optic.Wavelengths.ToArray();var longest=waves.MaxBy(w=>w.Micrometers)!;var primary=waves.First(w=>w.IsPrimary);
 (double Rms,double T,double S) Cone(Wavelength w)=>((double,double,double))cm.Invoke(null,new object[]{optic,(0d,0d),w})!;
 var cp=Cone(primary);var cl=Cone(longest);var fp=DiffractionEngine.WorkingFNumber(optic,(0,0),primary,optic.RayAimingEnabled);var fl=DiffractionEngine.WorkingFNumber(optic,(0,0),longest,optic.RayAimingEnabled);var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),primary,optic.RayAimingEnabled);
 var variants=new List<object>();
 foreach(var mode in new[]{"current","primaryAllDefaultExplicit","primaryAllAxesExplicit","primaryAllDefaultHighExplicit"})foreach(var ideal in new[]{true,false}){
  var pitch=longest.Micrometers*fp/Math.Sqrt(n);
  if(n>=128)pitch=longest.Micrometers*fp*(n-2)/(2*n*Math.Sqrt(n/4d-1));
  if(mode=="primaryCone")pitch=Math.Sqrt(1d/n)/(2*cp.Rms/longest.Micrometers);
  if(mode=="longestCone")pitch=Math.Sqrt(1d/n)/(2*cl.Rms/longest.Micrometers);
  if(mode is "primaryAllF" or "primaryAllCone" or "primaryAllDefault")pitch=Math.Sqrt(1d/n)/(2*cp.Rms/longest.Micrometers);
  if(mode.StartsWith("primaryAll"))pitch=Math.Sqrt(1d/n)/(2*cp.Rms/longest.Micrometers);
  if(mode=="primaryAllReciprocalCutoff")pitch=Math.Sqrt(1d/n)/(1/(longest.Micrometers*(.5/cp.Rms)));
  if(mode=="primaryAllInverseSqrt")pitch=1/(Math.Sqrt(n)*(2*cp.Rms/longest.Micrometers));
  if(mode is "primaryAllWorkingPitch" or "primaryAllWorkingHigh")pitch=longest.Micrometers*fp/Math.Sqrt(n);
  if(mode=="primaryAllWorkingCutoff")pitch=Math.Sqrt(1d/n)/(1/(longest.Micrometers*fp));
  if(mode=="primaryAllWorkingInverse")pitch=1/(Math.Sqrt(n)/(longest.Micrometers*fp));
  if(mode=="primaryAllWorkingHigh"&&n>=128)pitch=longest.Micrometers*fp*(n-2)/(2*n*Math.Sqrt(n/4d-1));
  if(mode=="primaryAllFullCutoff")pitch=longest.Micrometers/(2*cp.Rms*Math.Sqrt(n));
  if(mode=="primaryAllMmForward")pitch=(longest.Micrometers*.001/Math.Sqrt(n))*fp*1000;
  if(mode=="primaryAllMmCutoff")pitch=Math.Sqrt(1d/n)/(2*cp.Rms/(longest.Micrometers*.001))*1000;
  if(mode=="primaryAllCommonPitch")pitch=(longest.Micrometers*.001)*fp/Math.Sqrt(n)*1000;
  if(mode is "primaryAllDefaultExplicit" or "primaryAllAxesExplicit" or "primaryAllDefaultHighExplicit")pitch=longest.Micrometers*fp/Math.Sqrt(n);
  if(mode=="primaryAllDefaultHighExplicit"&&n>=128)pitch=longest.Micrometers*fp*(n-2)/(2*n*Math.Sqrt(n/4d-1));
  var spectrum=mode=="current"?DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),waves,n,ideal):waves.Select(w=>{
   var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled);var c=Cone(w);var auto=Math.Sqrt(n/32d);
   var step=w.Micrometers*f/(n*pitch);var sx=step*(n/2d-1);var sy=sx;
   if(mode=="primaryExactAxes"){step=w.Micrometers*(.5/c.S)/(n*pitch);sx=step*(n/2d-1);sy=w.Micrometers*(.5/c.T)/(n*pitch)*(n/2d-1);}
   if(mode=="primaryDefaultStretch"){var dp=w.Micrometers*f*(n-2)/(2*n*auto);sx=(auto*dp/pitch/f)*(.5/c.S);sy=(auto*dp/pitch/f)*(.5/c.T);}
   if(mode is "primaryAllF" or "primaryAllLegacy"){step=w.Micrometers*fp/(n*pitch);sx=step*(n/2d-1);sy=sx;}
   if(mode=="primaryAllCone"){step=(w.Micrometers/longest.Micrometers)/Math.Sqrt(n);sx=step*(n/2d-1);sy=sx;}
   if(mode=="primaryAllDefault"){var dp=w.Micrometers*fp*(n-2)/(2*n*auto);sx=auto*dp/pitch;sy=sx;}
   if(mode=="primaryAllExactF"){step=w.Micrometers*(.5/cp.Rms)/(n*pitch);sx=step*(n/2d-1);sy=sx;}
   if(mode=="primaryAllMillimeters"){step=1/(n*(pitch*.001)/(w.Micrometers*.001)/(.5/cp.Rms));sx=step*(n/2d-1);sy=sx;}
   if(mode=="primaryAllExactDefault"){var dp=w.Micrometers*(.5/cp.Rms)*(n-2)/(2*n*auto);sx=auto*dp/pitch;sy=sx;}
   if(mode=="primaryAllDirectDefault"){sx=w.Micrometers*(.5/cp.Rms)*(n-2)/(2*n*pitch);sy=sx;}
   if(mode=="primaryAllDirectional"){var dp=w.Micrometers*fp*(n-2)/(2*n*auto);sx=(auto*dp/pitch/fp)*(.5/cp.S);sy=(auto*dp/pitch/fp)*(.5/cp.T);}
   if(mode is "primaryAllSharedDefault" or "primaryAllSharedLegacy"){var dp=w.Micrometers*f*(n-2)/(2*n*auto);sx=(auto*dp/pitch/f)*(mode=="primaryAllSharedLegacy"?fp:.5/cp.S);sy=(auto*dp/pitch/f)*(mode=="primaryAllSharedLegacy"?fp:.5/cp.T);}
   if(mode is "primaryAllReciprocalCutoff" or "primaryAllInverseSqrt"){var af=.5/cp.Rms;var dp=w.Micrometers*af*(n-2)/(2*n*auto);sx=auto*dp/pitch;sy=sx;}
   if(mode=="primaryAllFrequency"){step=1/(n*pitch*(2*cp.Rms/w.Micrometers));sx=step*(n/2d-1);sy=sx;}
   if(mode is "primaryAllWorkingPitch" or "primaryAllWorkingCutoff" or "primaryAllWorkingInverse" or "primaryAllWorkingHigh" or "primaryAllFullCutoff"){var dp=w.Micrometers*f*(n-2)/(2*n*auto);sx=(auto*dp/pitch/f)*(mode=="primaryAllFullCutoff"?.5/cp.Rms:fp);sy=sx;}
   if(mode is "primaryAllMmForward" or "primaryAllMmCutoff" or "primaryAllCommonPitch"){step=1/(n*(pitch*.001)/(w.Micrometers*.001)/fp);sx=step*(n/2d-1);sy=sx;}
   if(mode=="primaryAllFrequencyStretch"){sx=auto*(w.Micrometers*f*(n-2)/(2*n*auto))/(pitch*(f/fp));sy=sx;}
   if(mode=="primaryAllAxisDefault"){sx=auto*(w.Micrometers*fp*(n-2)/(2*n*auto))/pitch;sy=sx;}
   if(mode is "primaryAllDefaultExplicit" or "primaryAllAxesExplicit" or "primaryAllDefaultHighExplicit"){
    var axes=DiffractionEngine.WorkingFNumbers(optic,(0,0),primary,optic.RayAimingEnabled,true);
    sx=auto*(w.Micrometers*(mode=="primaryAllAxesExplicit"?axes.Sagittal:fp)*(n-2)/(2*n*auto))/pitch;
    sy=auto*(w.Micrometers*(mode=="primaryAllAxesExplicit"?axes.Tangential:fp)*(n-2)/(2*n*auto))/pitch;
   }
   var grid=new PupilGridSpecification(n,true,true,sx){ExplicitCoordinateStep=sx/(n/2d-1),ExplicitCoordinateStepY=sy/(n/2d-1)};
   var psf=(PsfResult)compute.Invoke(null,new object?[]{optic,(0d,0d),w,n,2*n,false,true,0d,null,null,true,ideal,optic.RayAimingEnabled,primary,pitch,true,null,sphere,grid})!;
   return (Wavelength:w,Result:psf with { SampleSpacingMicrometers=pitch });
  }).ToArray();
  pitch=spectrum[0].Result.SampleSpacingMicrometers;
  var yy=Curve(spectrum.Select(s=>s.Result.Values).ToArray(),waves.Select(w=>w.Weight/(w.Micrometers*w.Micrometers)).ToArray(),n,pitch);
  var expected=native.RootElement.GetProperty("dataSeries")[ideal?0:1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
  var metric=Math.Sqrt(yy.Zip(expected,(a,b)=>(a-b)*(a-b)).Average())/(expected.Max()-expected.Min());
  variants.Add(new{mode,ideal,pitch,nrmse=metric,maxError=yy.Zip(expected,(a,b)=>Math.Abs(a-b)).Max(),counts=ideal?spectrum.Select(s=>100d*4*n*n/s.Result.Values.Cast<double>().Sum()).ToArray():null});
 }
 rows.Add(new{id,n,variants});Console.WriteLine(id+": "+JsonSerializer.Serialize(variants));
}
File.WriteAllText(Path.Combine(task,"grid-diagnosis.json"),JsonSerializer.Serialize(rows));
static double[] Curve(double[][,] psfs,double[] weights,int n,double pitch){
 var values=Enumerable.Range(0,2*n).SelectMany(y=>Enumerable.Range(0,2*n).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,psfs.Select((s,i)=>weights[i]*s[(y+1)%(2*n),(x+1)%(2*n)]).Sum()))).ToArray();
 var sum=values.Sum(s=>s.Weight);var center=(X:values.Sum(s=>s.X*s.Weight)/sum,Y:values.Sum(s=>s.Y*s.Weight)/sum);
 var grid=new FftCumulativeEnergyGrid(values,center,"encircled");var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(grid.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;
 return MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());
}
