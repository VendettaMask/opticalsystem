using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=args[0];var root=Path.Combine(repo,"artifacts/validation/dee-polychromatic-20261018");
var lenses=new List<(string Id,double F,double[] Lambdas,double[] Fs)>();
using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(repo,"artifacts/validation/numerical-residuals-20261018/holdout-jobs.json")));
foreach(var job in jobs.RootElement.EnumerateArray().Where(j=>new[]{"0014-all-waves","0308-all-waves","0472-all-waves","0852-all-waves"}.Contains(j.GetProperty("id").GetString()))){
 using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var optic=OpticalFormatCatalog.Import(File.ReadAllText(request.RootElement.GetProperty("input").GetString()!),".zmx");
 using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 var primary=optic.Wavelengths.First(w=>w.IsPrimary);var fp=DiffractionEngine.WorkingFNumber(optic,(0,0),primary,optic.RayAimingEnabled);lenses.Add((job.GetProperty("id").GetString()!,fp,optic.Wavelengths.Select(w=>w.Micrometers).ToArray(),optic.Wavelengths.Select(w=>DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled)).ToArray()));
 var cone=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static)!.Invoke(null,new object[]{optic,(0d,0d),primary});
 var c=((double Rms,double T,double S))cone!;var axes=DiffractionEngine.WorkingFNumbers(optic,(0,0),primary,optic.RayAimingEnabled,true);Console.WriteLine(JsonSerializer.Serialize(new{id=job.GetProperty("id").GetString(),fp,rms=c.Rms,t=c.T,s=c.S,exactF=.5/c.Rms,ft=axes.Tangential,fs=axes.Sagittal}));
}
var records=new List<object>();var matches=new List<object>();const int n=64;var auto=Math.Sqrt(n/32d);
foreach(var pm in Enumerable.Range(0,9))foreach(var sm in Enumerable.Range(0,10)){
 var rows=new List<object>();var correct=true;
 foreach(var lens in lenses){var l=lens.Lambdas.Max();var fp=lens.F;var inv=1/(l*fp);
  var pitch=pm switch{0=>l*fp/Math.Sqrt(n),1=>Math.Sqrt(1d/n)/inv,2=>1/(Math.Sqrt(n)*inv),3=>Math.Sqrt(1d/(n*inv*inv)),4=>Math.Sqrt(1d/n/(inv*inv)),5=>(l*.001/Math.Sqrt(n))*fp*1000,6=>Math.Sqrt((l*fp)*(l*fp)/n),7=>l/Math.Sqrt(n)*fp,_=>l*(fp/Math.Sqrt(n))};
  var counts=new List<int>();foreach(var i in Enumerable.Range(0,lens.Lambdas.Length)){var w=lens.Lambdas[i];var f=lens.Fs[i];var dp=w*f*(n-2)/(2*n*auto);
   var stretch=sm switch{0=>auto*dp/pitch/f*fp,1=>dp/pitch*auto*(fp/f),2=>auto*dp/pitch*(fp/f),3=>dp*auto*fp/(pitch*f),4=>dp/pitch/f*(auto*fp),5=>w*fp*(n-2)/(2*n*pitch),6=>auto*(w*fp*(n-2)/(2*n*auto))/pitch,7=>(dp/pitch)*(auto*fp/f),8=>auto*dp/(pitch*(f/fp)),_=>((dp/pitch)*fp/f)*auto};
   var grid=new PupilGridSpecification(n,true,true,stretch){ExplicitCoordinateStep=stretch/(n/2d-1)};var count=0;for(var y=0;y<n;y++)for(var x=0;x<n;x++){var px=grid.Coordinate(x);var py=grid.Coordinate(y);if(px*px+py*py<=1)count++;}counts.Add(count);
  }
  var expected=lens.Id.StartsWith("0014")?new[]{517,497,437,373,325,261,221,193}:lens.Id.StartsWith("0852")?new[]{241,221,197}:new[]{365,241,197};
  correct&=counts.SequenceEqual(expected);rows.Add(new{lens.Id,pitch,counts});
 }
 var record=new{pitchFormula=pm,stretchFormula=sm,correct,rows};records.Add(record);if(correct)matches.Add(record);
}
File.WriteAllText(Path.Combine(root,"scalar-grid-order-diagnosis.json"),JsonSerializer.Serialize(records));Console.WriteLine(JsonSerializer.Serialize(matches));


