$ErrorActionPreference='Stop'
$dir=Join-Path $PSScriptRoot 'fft-diagnostic';New-Item -ItemType Directory -Path $dir|Out-Null
$h=Get-Content (Join-Path $PSScriptRoot 'native/apo-poly64-huygens/data.json') -Raw|ConvertFrom-Json
$delta=$h.dataGrids[0].dx;$jobs=@()
foreach($w in @(0..8)){
 $r=Get-Content (Join-Path $PSScriptRoot 'requests/apo-poly64/dee.json') -Raw|ConvertFrom-Json
 $r.canonicalAnalysisKey='PSF';$r.analysisType='FftPsf';$r.imageDeltaMicrometers=$delta;$r.wavelength=$w
 $r.zemaxSettings=[ordered]@{Normalize=$false;OutputSize='PsfS_128x128';SampleSize='PsfS_64x64';ImageDelta=$delta;Wavelength=$w;Surface=-1;Rotation='CW0';Type='Linear';Field=1;UsePolarization=$false}
 $path=Join-Path $dir ('w'+$w+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id='w'+$w;request=$path;output=(Join-Path $dir ('w'+$w))}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $dir 'native-jobs.json') -Encoding utf8NoBOM
