using System.Numerics;
using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Rays;
var repo=args[0];var prior=Path.Combine(repo,"artifacts/validation/dee-relay64w3-20261018");var task=Path.Combine(repo,"artifacts/validation/dee-relay64w3-repair-20261018");var output=new List<object>();var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;
using var diagnosis=JsonDocument.Parse(File.ReadAllText(Path.Combine(prior,"phase-diagnosis.json")));
foreach(var id in new[]{"relay-n64-w1","relay-n64-w2","relay-n64-w3"}){
 const int n=64,m=128;var old=diagnosis.RootElement.EnumerateArray().Single(v=>v.GetProperty("id").GetString()==id&&v.TryGetProperty("nodes",out _));var pitch=old.GetProperty("pitch").GetDouble();var sx=old.GetProperty("grid").GetProperty("Stretch").GetDouble();
 using var request=JsonDocument.Parse(File.ReadAllText(Path.Combine(prior,$"requests/{id}/dee.json")));var r=request.RootElement;var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=true;var wave=optic.Wavelengths[r.GetProperty("wavelength").GetInt32()-1];var reference=optic.Wavelengths.First(w=>w.IsPrimary);var grid=new PupilGridSpecification(n,true,true,sx);var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),reference,true);var wf=WavefrontEngine.GenerateChiefRayGrid(optic,(0,0),wave,grid,true,reference,sphere);var precise=new DecimalMeridional(optic,wave,sphere);var generator=optic.SequentialRayTracer.RayGenerator;var stop=optic.SurfaceGroup.Items.ToList().FindIndex(s=>s.IsStop);var radius=optic.Paraxial.TraceNormalizedPupil(0,new[]{1d},reference.Micrometers).Heights[stop][0];
 using var dee=JsonDocument.Parse(File.ReadAllText(Path.Combine(prior,$"native/{id}/data.json")));var expected=dee.RootElement.GetProperty("dataSeries")[1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
 using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"single-chief-{id}/ray-audit.json")));var inputs=audit.RootElement.GetProperty("inputs");var rows=audit.RootElement.GetProperty("surfaces").EnumerateArray().Single(s=>s.GetProperty("surface").GetInt32()==stop).GetProperty("rays");
 var native=Enumerable.Range(0,inputs.GetArrayLength()).ToDictionary(i=>(inputs[i].GetProperty("px").GetDouble(),inputs[i].GetProperty("py").GetDouble()),i=>rows[i]);
 foreach(var mode in new[]{"native-coordinate","primary-one-newton","primary-two-newton","primary-central-newton"}){
 var nodes=new List<object>();var modified=wf with{Samples=wf.Samples.Select(s=>{
  var px=Math.Abs(s.NormalizedPupilX);var py=Math.Abs(s.NormalizedPupilY);double nx,ny;
  if(mode=="native-coordinate") {var nr=native[(px,py)];nx=nr.GetProperty("x").GetDouble()/radius;ny=nr.GetProperty("y").GetDouble()/radius;}
  else{
   var ray=generator.GenerateGeneric(0,0,px,py,reference.Micrometers,true).Rays[0];var ux=ray.Direction.X/ray.Direction.Z;var uy=ray.Direction.Y/ray.Direction.Z;
   for(var i=0;i<(mode=="primary-two-newton"?2:1);i++){
    const double h=1e-6;var p0=Sample(ux,uy);var x1=Sample(ux+h,uy);var y1=Sample(ux,uy+h);var x0=mode=="primary-central-newton"?Sample(ux-h,uy):p0;var y0=mode=="primary-central-newton"?Sample(ux,uy-h):p0;var divisor=mode=="primary-central-newton"?2*h:h;var a=(x1.X-x0.X)/divisor;var b=(y1.X-y0.X)/divisor;var c=(x1.Y-x0.Y)/divisor;var d=(y1.Y-y0.Y)/divisor;var det=a*d-b*c;var ex=radius*px-p0.X;var ey=radius*py-p0.Y;ux+=(d*ex-b*ey)/det;uy+=(a*ey-c*ex)/det;
   }
   var result=Sample(ux,uy);nx=result.X/radius;ny=result.Y/radius;
   Vector3D Sample(double x,double y){var d=new Vector3D(x,y,1);var rr=new RealRay(ray.Origin,d/d.Length,wave.Nanometers);return optic.SurfaceGroup.Items[stop].CoordinateSystem.ToLocalPoint(optic.SequentialRayTracer.TraceToSurface(rr,stop)!.Position);}
  }
  var opd=precise.Opd(nx,ny);nodes.Add(new{px,py,nx,ny,relativeShift=double.Hypot(nx,ny)/double.Hypot(px,py)-1,opd});return s with{OpdWaves=opd,Intensity=1};
 }).ToArray()};object?[] p={optic,(0d,0d),wave,n,m,false,true,0d,modified,null,true,false,true,reference,0d,true,null,sphere,grid};var psf=(PsfResult)compute.Invoke(null,p)!;var metric=Metric(Curve(psf.Values),expected);output.Add(new{id,mode,metric,nodes});Console.WriteLine($"{id} {mode} {metric:R}");
 }
 double[] Curve(double[,] a){var samples=Enumerable.Range(0,m).SelectMany(y=>Enumerable.Range(0,m).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,a[(y+1)%m,(x+1)%m]))).ToArray();var total=samples.Sum(s=>s.Weight);var center=(samples.Sum(s=>s.X*s.Weight)/total,samples.Sum(s=>s.Y*s.Weight)/total);var eg=new FftCumulativeEnergyGrid(samples,center,"encircled");var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(eg.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;var values=MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());var previous=0d;return values.Select(v=>previous=Math.Clamp(Math.Max(previous,v),0,1)).ToArray();}
}
File.WriteAllText(Path.Combine(task,"primary-aim-diagnosis.json"),JsonSerializer.Serialize(output,new JsonSerializerOptions{NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals}));
static double Metric(double[] a,double[] b)=>Math.Sqrt(a.Zip(b,(x,y)=>(x-y)*(x-y)).Average())/(b.Max()-b.Min());
