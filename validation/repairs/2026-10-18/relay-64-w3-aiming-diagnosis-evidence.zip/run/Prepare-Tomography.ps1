$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$prior=Join-Path $repo 'artifacts/validation/dee-relay64w3-20261018'
$dir=Join-Path $PSScriptRoot 'tomography-fixed';New-Item -ItemType Directory -Path $dir|Out-Null
$jobs=@();$dee=@()
foreach($spec in @(@('minus2',-2),@('minus1',-1),@('zero',0),@('plus1',1),@('plus2',2))){
 $id=$spec[0];$shift=$spec[1];$case=Join-Path $dir $id;New-Item -ItemType Directory -Path $case|Out-Null
 $r=Get-Content (Join-Path $prior 'requests/relay-n64-w3/dee.json') -Raw|ConvertFrom-Json
 if($shift -ne 0){
  $text=[IO.File]::ReadAllText($r.input);$pattern='(?ms)(^SURF 7\r?\n.*?^\s*DISZ )250(?=\s)'
  if([regex]::Matches($text,$pattern).Count -ne 1){throw 'Unexpected final-space prescription'}
  $text=[regex]::Replace($text,$pattern,('${1}'+[string](250+$shift)))
  $block=[regex]::Match($text,'(?ms)^SURF 7\r?\n.*?(?=^SURF 8\r?\n)')
  $pickup='(?m)^\s*PZUP[^\r\n]*\r?\n'
  if([regex]::Matches($block.Value,$pickup).Count -ne 1){throw 'Expected object-thickness pickup on final space'}
  $text=$text.Substring(0,$block.Index)+[regex]::Replace($block.Value,$pickup,'')+$text.Substring($block.Index+$block.Length)
  $source=Join-Path $case 'source.zmx';[IO.File]::WriteAllText($source,$text)
  $r.input=$source
 }
 $path=Join-Path $case 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $job=@{id=$id+'-dee';request=$path;output=(Join-Path $case 'dee')};$jobs+=$job;$dee+=$job
 $source=$r.input
 foreach($type in @('Real','Imaginary')){
  $r=Get-Content (Join-Path $prior ('psf/relay-n64-w3-'+$type+'.json')) -Raw|ConvertFrom-Json;$r.input=$source
  $path=Join-Path $case ($type+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-'+$type;request=$path;output=(Join-Path $case $type)}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $dir 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($dee) -Depth 10|Set-Content (Join-Path $dir 'dee-jobs.json') -Encoding utf8NoBOM
