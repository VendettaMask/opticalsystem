$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$dir=Join-Path $PSScriptRoot 'cache-proof'; New-Item -ItemType Directory "$dir/source" | Out-Null
Copy-Item "$PSScriptRoot/source/*.cs" "$dir/source"
$hostPath=Join-Path $dir 'source/Host.cs';$hostText=[IO.File]::ReadAllText($hostPath)
$anchor='system.MCE.SetCurrentConfiguration(Int("configuration"));'
if($hostText.Split($anchor).Length -ne 2){throw 'Configuration hook changed'}
$replacement=$anchor+' if (Request.ContainsKey("diagnosticAimingCache")) system.SystemData.RayAiming.UseRayAimingCache = Convert.ToBoolean(Request["diagnosticAimingCache"]); if (Request.ContainsKey("diagnosticEnhancedAiming")) { system.SystemData.RayAiming.UseEnhancedRayAiming = Convert.ToBoolean(Request["diagnosticEnhancedAiming"]); system.SystemData.RayAiming.UseAdvancedConvergence = true; }'
[IO.File]::WriteAllText($hostPath,$hostText.Replace($anchor,$replacement))
$jobs=@()
foreach($mode in @('original','cache-off','enhanced')){
 foreach($kind in @('rays','dee','Real','Imaginary')){
  $case=Join-Path $dir ($mode+'-'+$kind);$path=$case+'.json'
  $inputPath=if($kind -eq 'rays'){Join-Path $PSScriptRoot 'single-chief-relay-n64-w3.json'}elseif($kind -eq 'dee'){Join-Path $PSScriptRoot 'tomography-fixed/zero/dee.json'}else{Join-Path $PSScriptRoot ('tomography-fixed/zero/'+$kind+'.json')}
  $r=Get-Content $inputPath -Raw|ConvertFrom-Json
  if($mode -eq 'cache-off'){$r|Add-Member diagnosticAimingCache $false}
  if($mode -eq 'enhanced'){$r|Add-Member diagnosticEnhancedAiming $true}
  $r|ConvertTo-Json -Depth 40|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$mode+'-'+$kind;request=$path;output=$case}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content "$dir/native-jobs.json" -Encoding utf8NoBOM
