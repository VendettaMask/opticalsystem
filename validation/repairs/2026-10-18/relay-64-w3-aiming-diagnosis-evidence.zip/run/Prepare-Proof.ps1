$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read([string]$path){Get-Content -LiteralPath (Join-Path $PSScriptRoot $path) -Raw|ConvertFrom-Json}
$previous=Get-Content (Join-Path $repo 'docs/validation/RELAY_64_W3_RESIDUAL_DIAGNOSIS_2026-10-18.json') -Raw|ConvertFrom-Json
$core=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($core -ne $previous.afterCoreSha256){throw 'Before Core differs'}
foreach($source in $previous.sourceFiles){if((Hash (Join-Path $repo $source.path)) -ne $source.sha256){throw ('C# source changed: '+$source.path)}}
$previous.sourceFiles.path|Set-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt') -Encoding utf8NoBOM
foreach($c in $previous.verification.defaultConfigurationsUnchanged){foreach($copy in $c.coreCopies){if((Hash (Join-Path $repo $copy.path)) -ne $copy.sha256){throw 'Default Core changed'}}}
$summaries=@{};$identities=@()
foreach($group in $previous.allFormalGroups.PSObject.Properties){
 $name=$group.Name;$old=$group.Value;$now=Read ($name+'/summary.json');$summaries[$name]=$now
 if($now.rows.Count -ne $old.rows.Count -or $now.excluded.Count -ne $old.excluded.Count -or $now.policySha256 -ne $old.policySha256 -or $now.coreSha256 -ne $core){throw ('Formal inventory/core/policy changed: '+$name)}
 foreach($row in $now.rows){
  $match=@($old.rows|Where-Object id -ceq $row.id)
  if($match.Count -ne 1 -or $row.conclusion -ne 'Pass'){throw 'Formal status differs'}
  foreach($key in 'sourceSha256','executedRequestSha256','nativeDataSha256'){if($row.$key -ne $match[0].$key){throw 'Frozen formal input changed'}}
  foreach($file in 'normalized-workbench.json','normalized-zemax.json'){
   $currentPath=Join-Path $PSScriptRoot ($name+'/'+$row.id+'/'+$file)
   $oldPath=Join-Path $repo ('artifacts/validation/dee-relay64w3-20261018/'+$name+'/'+$row.id+'/'+$file)
   if((Hash $currentPath) -ne (Hash $oldPath)){throw 'Normalized comparison bytes changed'}
  }
  $identities+=@{group=$name;id=$row.id;allInputHashesUnchanged=$true;normalizedBytesUnchanged=$true;normalizedWorkbenchSha256=Hash (Join-Path $PSScriptRoot ($name+'/'+$row.id+'/normalized-workbench.json'))}
 }
}
if($identities.Count -ne 125){throw 'Expected 119 prior comparisons and six prior controls'}
$target=@($summaries['formal-final'].rows|Where-Object id -ceq '0472-n64-w3')[0]
if($target.metrics[1].nrmse -ne 1.0480732682054777e-8){throw 'Target changed unexpectedly'}
$archives=@{};foreach($a in $previous.preservedArchives.PSObject.Properties){$archives[$a.Name]=$a.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen archive changed'}}
if($archives.Count -ne 22){throw 'Expected 22 frozen archives'}
$fixtures=$previous.preservedNativeFixtures
foreach($f in $fixtures.PSObject.Properties){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$f.Name))) -ne $f.Value){throw 'Frozen fixture changed'}}
if(@($fixtures.PSObject.Properties).Count -ne 15){throw 'Expected 15 frozen fixtures'}
$captures=@();$types=@{rays=0;dee=0;psf=0;excludedPhysicalControl=0}
foreach($list in 'native-jobs.json','radial/native-jobs.json','tomography-fixed/native-jobs.json','cache-proof/native-jobs.json','tomography/native-jobs.json'){
 foreach($job in @(Read $list)){
  $request=Get-Content $job.request -Raw|ConvertFrom-Json;$folder=$job.output
  $batch=Get-Content (Join-Path $folder 'batch-result.json') -Raw|ConvertFrom-Json
  $envData=Get-Content (Join-Path $folder 'environment.json') -Raw|ConvertFrom-Json
  if($batch.exitCode -ne 0 -or $envData.major -ne 26 -or $envData.minor -ne 1 -or $envData.opticStudioVersion -ne 260127 -or !$envData.validLicense){throw 'Native failure/version/license mismatch'}
  $modelPath=Join-Path $folder 'model.json';$model=Get-Content $modelPath -Raw|ConvertFrom-Json
  $usable=$list -ne 'tomography/native-jobs.json'
  if(!$usable){$types.excludedPhysicalControl++}
  $kind=if($request.adapter -eq 'ray-audit'){'rays'}elseif($request.analysisType -eq 'DiffractionEncircledEnergy'){'dee'}else{'psf'}
  if($usable){$types[$kind]++}
  $dataPath=Join-Path $folder $(if($kind -eq 'rays'){'ray-audit.json'}else{'data.json'})
  $data=Get-Content $dataPath -Raw|ConvertFrom-Json
  if($kind -eq 'rays'){
   if($data.inputs.Count -ne 193 -or @($data.launches|Where-Object success -ne $true).Count -ne 0 -or @($data.surfaces.rays|Where-Object error -ne 0).Count -ne 0){throw 'Native ray audit incomplete'}
  }elseif($kind -eq 'dee'){
   if($data.dataSeries.Count -ne 2 -or @($data.dataSeries|Where-Object {$_.x.Count -ne 401 -or $_.y.Count -ne 401}).Count -gt 0){throw 'DEE incomplete'}
  }elseif($data.dataGrids.Count -ne 1 -or $data.dataGrids[0].nx -ne 128 -or $data.dataGrids[0].ny -ne 128){throw 'PSF incomplete'}
  $captures+=@{group=$list;id=$job.id;usableDiagnostic=$usable;exclusionReason=$(if(!$usable){'Intended defocus suppressed by SURF 7 PZUP; actual final-space thickness remains 250 mm'}else{$null});requestPath=[IO.Path]::GetRelativePath($repo,$job.request).Replace('\','/');requestSha256=Hash $job.request;sourceSha256=Hash $request.input;modelSha256=Hash $modelPath;dataSha256=Hash $dataPath;rayAiming=$model.rayAiming;finalSpaceThickness=$model.surfaces[7].Thickness;version='2026 R1 build 260127';validLicense=$true;exitCode=$batch.exitCode}
 }
}
if($captures.Count -ne 54 -or $types.rays -ne 15 -or $types.dee -ne 8 -or $types.psf -ne 16 -or $types.excludedPhysicalControl -ne 15){throw 'Native inventory differs'}
$thickness=@{minus2=248;minus1=249;zero=250;plus1=251;plus2=252}
foreach($item in $captures|Where-Object group -eq 'tomography-fixed/native-jobs.json'){
 $case=($item.id -split '-')[0];if($item.finalSpaceThickness -ne $thickness[$case]){throw 'Defocus did not take effect'}
}
foreach($item in $captures|Where-Object group -eq 'tomography/native-jobs.json'){if($item.finalSpaceThickness -ne 250){throw 'Retained invalid controls differ'}}
foreach($item in $captures|Where-Object group -eq 'cache-proof/native-jobs.json'){
 if($item.id -like 'cache-off-*'){if($item.rayAiming.UseRayAimingCache){throw 'Cache-off control was not off'}}
 elseif($item.id -like 'enhanced-*'){if(!$item.rayAiming.UseRayAimingCache -or !$item.rayAiming.UseEnhancedRayAiming -or !$item.rayAiming.UseAdvancedConvergence){throw 'Enhanced readback differs'}}
 elseif(!$item.rayAiming.UseRayAimingCache -or $item.rayAiming.UseEnhancedRayAiming){throw 'Original settings differ'}
}
if((Hash (Join-Path $PSScriptRoot 'cache-proof/original-dee/data.json')) -ne $target.nativeDataSha256){throw 'Repeated original data changed'}
$aim=@(Read 'aim-single-chief-.json'|Where-Object {$_.x -ge 0 -and $_.y -ge 0})
$offsetError=@($aim|ForEach-Object {[Math]::Abs($_.inferred-$_.stopOffset)})
$aimSummary=@{count=$aim.Count;maximumOffsetDifference=($offsetError|Measure-Object -Maximum).Maximum;meanAbsoluteOffsetDifference=($offsetError|Measure-Object -Average).Average}
if($aimSummary.count -ne 28 -or $aimSummary.maximumOffsetDifference -gt 2.2e-10){throw 'Tomography correspondence differs'}
$tests=@{}
foreach($spec in @(@('related-release-final.trx','testRelease',1040),@('related-debug-final.trx','testDebug',327),@('comparison-release-final.trx','comparisonRelease',5),@('comparison-debug-final.trx','comparisonDebug',5))){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$spec[0])) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns);$names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)
 if([int]$c.total -ne $spec[2] -or [int]$c.passed -ne $spec[2] -or [int]$c.failed -ne 0 -or [int]$c.notExecuted -ne 0){throw ('Test mismatch: '+$spec[0])}
 $old=$previous.verification.($spec[1]);if(@(Compare-Object $old.names $names).Count -ne 0){throw 'Test identity changed'}
 $tests[$spec[1]]=@{passed=[int]$c.passed;total=[int]$c.total;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=$names;trxSha256=Hash (Join-Path $PSScriptRoot ('tests/'+$spec[0]))}
}
$proof=@{date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD);scope='Relay n64 wavelength 3, native aiming/phase isolation, unresolved';targetClosed=$false;productCodeChanged=$false;coreUnchanged=$true;beforeCoreSha256=$core;afterCoreSha256=$core;target=$target;allFormalGroups=$summaries;priorComparisonIdentities=$identities;sourceFiles=$previous.sourceFiles;preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@();verification=$tests;defaultConfigurationsUnchanged=$previous.verification.defaultConfigurationsUnchanged;rootSolutionBuiltThisTask=$false;newTests=0;nativeCaptures=$captures;nativeCaptureSummary=$types;tomography=(Read 'tomography-fixed-diagnosis.json');aimingCorrespondence=$aimSummary;cacheProof=(Read 'cache-proof-diagnosis.json');primaryAimCandidates=(Read 'primary-aim-diagnosis.json');cacheAlgorithmCandidates=(Read 'cache-algorithm-diagnosis.json');opdProbe=(Read 'native-opd-diagnosis.json');radialOpdProbe=(Read 'native-radial-opd-diagnosis.json');constraints=@{originalTolerancesUnchanged=$true;originalReferenceUnchanged=$true;nativeCoordinatesAreDiagnosticOnly=$true;decimalIsIndependentDiagnosticUsingDoublePrescription=$true;noCurveOrPhaseFitting=$true;independentCookeTessarExcluded=$true};boundaries=@('Residual remains open; no product improvement claimed','Changed native cache/enhanced settings do not replace original acceptance','15 initial tomography jobs retained but excluded as defocus controls','Initial sandbox test-host communication stalled; only this run terminated and tests rerun with normal permissions','No full root solution rebuild, installer, commit or push')}
$proof|ConvertTo-Json -Depth 70|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 70|Set-Content (Join-Path $repo 'docs/validation/RELAY_64_W3_AIMING_DIAGNOSIS_2026-10-18.json') -Encoding utf8NoBOM
'Verified unchanged target and all 125 comparison instances, 54 native captures with 15 excluded physical controls, source/fixture/archive identities and completed regression tests.'

