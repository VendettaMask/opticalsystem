using System.Globalization;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Geometries;
using OpticalSystemDesign.Core.Rays;

// Independent diagnostic for this centered, spherical, homogeneous Relay only.
// It never supplies product evaluation, aperture acceptance or runtime rays.
internal sealed class DecimalMeridional
{
    private readonly Optic optic;
    private readonly decimal[] vertex;
    private readonly decimal[] radii;
    private readonly decimal[] indices;
    private readonly decimal start;
    private readonly int stop;
    private readonly decimal pupilRadius;
    private readonly decimal chiefPath;
    private readonly decimal referenceRadius;
    private readonly decimal wavelength;

    internal DecimalMeridional(Optic optic, OpticalSystemDesign.Core.Domain.Wavelength wave,
        WavefrontReferenceSphere sphere)
    {
        this.optic = optic;
        var surfaces = optic.SurfaceGroup.Items;
        if (surfaces.Any(s => s.IsReflective || s.CoordinateSystem.Origin.X != 0
            || s.CoordinateSystem.Origin.Y != 0 || s.CoordinateSystem.RotationXDegrees != 0
            || s.CoordinateSystem.RotationYDegrees != 0 || s.CoordinateSystem.RotationZDegrees != 0
            || s.Geometry is not (StandardGeometry or PlaneGeometry)
            || s.Geometry is StandardGeometry standard && standard.Conic != 0))
            throw new InvalidOperationException("Diagnostic only supports the centered spherical source.");
        vertex = surfaces.Select(s => D(s.CoordinateSystem.Origin.Z)).ToArray();
        radii = surfaces.Select(s => s.Geometry is not StandardGeometry standard || double.IsInfinity(standard.Radius)
            ? 0m : D(standard.Radius)).ToArray();
        indices = surfaces.Select(s => D(s.MaterialAfter.RefractiveIndex(wave.Nanometers))).ToArray();
        start = vertex[0];
        stop = surfaces.ToList().FindIndex(s => s.IsStop);
        var primary = optic.Wavelengths.First(w => w.IsPrimary);
        pupilRadius = D(optic.Paraxial.TraceNormalizedPupil(0, new[] { 1d }, primary.Micrometers).Heights[stop][0]);
        referenceRadius = D(sphere.Radius);
        wavelength = D(wave.Micrometers) / 1000;
        chiefPath = Trace(0, surfaces.Count - 1).Path;
    }

    internal double Opd(double px, double py)
    {
        var rho = Sqrt(D(px) * D(px) + D(py) * D(py));
        if (rho == 0) return 0;
        var target = pupilRadius * rho;
        var slope = target / (vertex[stop] - start);
        for (var iteration = 0; iteration < 12; iteration++)
        {
            var error = target - Trace(slope, stop).R;
            if (Math.Abs(error) < 0.00000000000000000000001m) break;
            const decimal h = 0.00000001m;
            var derivative = (Trace(slope + h, stop).R - Trace(slope - h, stop).R) / (2 * h);
            slope += error / derivative;
        }
        if (Math.Abs(target - Trace(slope, stop).R) > 0.000000000000000000001m)
            throw new InvalidOperationException("Decimal diagnostic aiming did not converge.");
        var ray = Trace(slope, vertex.Length - 1);
        var perpendicularSquared = ray.R * ray.R * ray.Dz * ray.Dz;
        var correction = ray.Dr * ray.R - perpendicularSquared
            / (referenceRadius + Sqrt(referenceRadius * referenceRadius - perpendicularSquared));
        return (double)((chiefPath - ray.Path + correction) / wavelength);
    }

    private (decimal R, decimal Z, decimal Dr, decimal Dz, decimal Path) Trace(decimal slope, int end)
    {
        decimal r = 0, z = start, index = 1, path = 0;
        var dz = 1 / Sqrt(1 + slope * slope);
        var dr = slope * dz;
        for (var i = 1; i <= end; i++)
        {
            var radius = radii[i];
            decimal t;
            if (radius == 0) t = (vertex[i] - z) / dz;
            else
            {
                var local = z - vertex[i];
                var a = dr * dr + dz * dz;
                var b = 2 * (r * dr + (local - radius) * dz);
                var c = r * r + local * local - 2 * radius * local;
                var root = Sqrt(b * b - 4 * a * c);
                var q = -(b + Math.Sign(b) * root) / 2;
                var first = q / a;
                var second = q == 0 ? 0 : c / q;
                t = Math.Abs(local + first * dz) < Math.Abs(local + second * dz) ? first : second;
            }
            r += dr * t;
            z += dz * t;
            path += t * index;
            var next = indices[i];
            if (next != index)
            {
                var nr = radius == 0 ? 0 : -r / radius;
                var nz = radius == 0 ? 1 : 1 - (z - vertex[i]) / radius;
                var norm = Sqrt(nr * nr + nz * nz); nr /= norm; nz /= norm;
                var cosine = dr * nr + dz * nz;
                var eta = index / next;
                var factor = Sqrt(1 - eta * eta * (1 - cosine * cosine)) - eta * cosine;
                dr = eta * dr + factor * nr;
                dz = eta * dz + factor * nz;
                norm = Sqrt(dr * dr + dz * dz); dr /= norm; dz /= norm;
            }
            index = next;
        }
        return (r, z, dr, dz, path);
    }

    private static decimal D(double value) => decimal.Parse(value.ToString("R", CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
    private static decimal Sqrt(decimal value)
    {
        if (value == 0) return 0;
        var root = (decimal)Math.Sqrt((double)value);
        for (var iteration = 0; iteration < 8; iteration++) root = (root + value / root) / 2;
        return root;
    }
}
