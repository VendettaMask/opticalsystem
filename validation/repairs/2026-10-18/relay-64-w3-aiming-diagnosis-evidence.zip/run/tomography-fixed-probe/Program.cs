using System.Numerics;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var task=Path.Combine(args[0],"artifacts/validation/dee-relay64w3-repair-20261018");var prior=Path.Combine(args[0],"artifacts/validation/dee-relay64w3-20261018");const int n=64,m=128;
using var old=JsonDocument.Parse(File.ReadAllText(Path.Combine(prior,"phase-diagnosis.json")));var original=old.RootElement.EnumerateArray().Single(v=>v.GetProperty("id").GetString()=="relay-n64-w3"&&v.TryGetProperty("nodes",out _));var extent=original.GetProperty("grid").GetProperty("Stretch").GetDouble();var grid=new PupilGridSpecification(n,true,true,extent);var all=new Dictionary<string,Node[]>();var summary=new List<object>();
foreach(var id in new[]{"minus2","minus1","zero","plus1","plus2"}){
 using var req=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"tomography-fixed/{id}/dee.json")));var optic=OpticalFormatCatalog.Import(File.ReadAllText(req.RootElement.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=true;var wave=optic.Wavelengths[2];var reference=optic.Wavelengths.First(w=>w.IsPrimary);var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),reference,true);var precise=new DecimalMeridional(optic,wave,sphere);
 var real=Read("Real");var imag=Read("Imaginary");var native=new Complex[m,m];for(var y=0;y<m;y++)for(var x=0;x<m;x++)native[y,x]=new(real[y,x],imag[y,x]);DiffractionEngine.FourierTransform2D(native,true);var peak=native.Cast<Complex>().Max(v=>v.Magnitude);var magError=0d;var leak=0d;var points=new List<Node>();
 for(var y=0;y<n;y++)for(var x=0;x<n;x++){
  var ix=x-n/2;var iy=y-n/2;var z=native[(-iy+m)%m,(-ix+m)%m]*(((ix+iy)%2==0)?1:-1);var px=grid.Coordinate(x);var py=grid.Coordinate(y);
  if(px*px+py*py>1){leak=Math.Max(leak,z.Magnitude/peak);continue;}magError=Math.Max(magError,Math.Abs(z.Magnitude/peak-1));
  var raw=-2*Math.PI*precise.Opd(px,py);var phase=-z.Phase;phase+=2*Math.PI*Math.Round((raw-phase)/(2*Math.PI));const double h=1e-6;var derivative=-2*Math.PI*(precise.Opd(px*(1+h),py*(1+h))-precise.Opd(px*(1-h),py*(1-h)))/(2*h);
  points.Add(new(ix,iy,px,py,phase,raw,phase-raw,derivative));
 }
 var nodes=points.ToArray();all[id]=nodes;summary.Add(new{id,count=nodes.Length,amplitudeError=magError,leak,oddMaximum=nodes.Where(v=>(v.X+v.Y)%2!=0).Max(v=>Math.Abs(v.Error)),chief=nodes.Single(v=>v.X==0&&v.Y==0)});Console.WriteLine(JsonSerializer.Serialize(summary[^1]));
 double[,] Read(string type){using var d=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"tomography-fixed/{id}/{type}/data.json")));var v=d.RootElement.GetProperty("dataGrids")[0].GetProperty("values");var a=new double[m,m];for(var y=0;y<m;y++)for(var x=0;x<m;x++)a[(y+1)%m,(x+1)%m]=v[y][x].GetDouble();return a;}
}
var inferred=all["zero"].Where(v=>(v.X+v.Y)%2!=0).Select(v=>{var a=all["plus2"].Single(w=>w.X==v.X&&w.Y==v.Y);var b=all["minus2"].Single(w=>w.X==v.X&&w.Y==v.Y);return new{v.X,v.Y,v.Px,v.Py,scaleOffset=(a.Error-b.Error)/(a.ScaleDerivative-b.ScaleDerivative),baselineError=v.Error,plus2Error=a.Error,minus2Error=b.Error};}).ToArray();var values=inferred.Select(v=>v.scaleOffset).Order().ToArray();var mean=values.Average();var stats=new{minimum=values[0],maximum=values[^1],median=values[values.Length/2],mean,standardDeviation=Math.Sqrt(values.Average(v=>(v-mean)*(v-mean)))};Console.WriteLine(JsonSerializer.Serialize(stats));
File.WriteAllText(Path.Combine(task,"tomography-fixed-diagnosis.json"),JsonSerializer.Serialize(new{summary,stats,inferred,cases=all}));
record Node(int X,int Y,double Px,double Py,double NativePhase,double DecimalPhase,double Error,double ScaleDerivative);
