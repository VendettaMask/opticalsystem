using System.Text.Json;
using OpticalSystemDesign.Core.FileIO;
var task=Path.Combine(args[0],"artifacts/validation/dee-relay64w3-repair-20261018");
using var r=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"tomography-fixed/zero/dee.json")));
var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.RootElement.GetProperty("input").GetString()!),".zmx");
var stop=optic.SurfaceGroup.Items.ToList().FindIndex(s=>s.IsStop);var radius=optic.Paraxial.TraceNormalizedPupil(0,new[]{1d},optic.Wavelengths.First(w=>w.IsPrimary).Micrometers).Heights[stop][0];Console.WriteLine($"stop {stop} radius {radius:R}");
using var t=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"tomography-fixed-diagnosis.json")));
foreach(var mode in new[]{"single-chief-","radial/"}){
 using var a=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,mode+"relay-n64-w3/ray-audit.json")));var root=a.RootElement;var inputs=root.GetProperty("inputs");var rays=root.GetProperty("surfaces").EnumerateArray().Single(s=>s.GetProperty("surface").GetInt32()==stop).GetProperty("rays");
 var values=t.RootElement.GetProperty("inferred").EnumerateArray().Select(v=>{var px=v.GetProperty("Px").GetDouble();var py=v.GetProperty("Py").GetDouble();var rho=double.Hypot(px,py);var tx=mode=="radial/"?0:px;var ty=mode=="radial/"?rho:py;var i=Enumerable.Range(0,inputs.GetArrayLength()).First(i=>Math.Abs(inputs[i].GetProperty("px").GetDouble()-tx)<1e-14&&Math.Abs(inputs[i].GetProperty("py").GetDouble()-ty)<1e-14);var ray=rays[i];var actual=double.Hypot(ray.GetProperty("x").GetDouble(),ray.GetProperty("y").GetDouble());return new{x=v.GetProperty("X").GetInt32(),y=v.GetProperty("Y").GetInt32(),inferred=v.GetProperty("scaleOffset").GetDouble(),stopOffset=actual/(rho*radius)-1};}).ToArray();
 File.WriteAllText(Path.Combine(task,"aim-"+mode.Replace('/','-')+".json"),JsonSerializer.Serialize(values));Console.WriteLine(mode+" "+JsonSerializer.Serialize(values.Where(v=>v.x==0&&v.y>0)));
}


