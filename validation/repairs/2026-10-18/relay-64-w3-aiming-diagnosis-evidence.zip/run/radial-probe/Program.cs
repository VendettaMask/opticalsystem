using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=args[0];var prior=Path.Combine(repo,"artifacts/validation/dee-relay64w3-20261018");var task=Path.Combine(repo,"artifacts/validation/dee-relay64w3-repair-20261018");var output=new List<object>();
var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;
using var diagnosis=JsonDocument.Parse(File.ReadAllText(Path.Combine(prior,"phase-diagnosis.json")));
foreach(var id in new[]{"relay-n64-w1","relay-n64-w2","relay-n64-w3"}){
 const int n=64,m=128;var old=diagnosis.RootElement.EnumerateArray().Single(v=>v.GetProperty("id").GetString()==id && v.TryGetProperty("nodes",out _));var pitch=old.GetProperty("pitch").GetDouble();var sx=old.GetProperty("grid").GetProperty("Stretch").GetDouble();
 using var request=JsonDocument.Parse(File.ReadAllText(Path.Combine(prior,$"requests/{id}/dee.json")));var r=request.RootElement;var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=true;var wave=optic.Wavelengths[r.GetProperty("wavelength").GetInt32()-1];var reference=optic.Wavelengths.First(w=>w.IsPrimary);var grid=new PupilGridSpecification(n,true,true,sx);var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),reference,true);var wf=WavefrontEngine.GenerateChiefRayGrid(optic,(0,0),wave,grid,true,reference,sphere);
 using var dee=JsonDocument.Parse(File.ReadAllText(Path.Combine(prior,$"native/{id}/data.json")));var expected=dee.RootElement.GetProperty("dataSeries")[1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
 foreach(var mode in new[]{"radial"}){
  using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"radial/{id}/ray-audit.json")));var data=audit.RootElement;var inputs=data.GetProperty("inputs");var rays=data.GetProperty("surfaces").EnumerateArray().Last().GetProperty("rays");using var original=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"single-chief-{id}/ray-audit.json")));var originalInputs=original.RootElement.GetProperty("inputs");var map=Enumerable.Range(0,inputs.GetArrayLength()).ToDictionary(i=>(originalInputs[i].GetProperty("px").GetDouble(),originalInputs[i].GetProperty("py").GetDouble()),i=>rays[i]);var points=old.GetProperty("nodes").EnumerateArray().Select(node=>{
   var native=map[(node.GetProperty("px").GetDouble(),node.GetProperty("py").GetDouble())].GetProperty("opd").GetDouble();var np=node.GetProperty("nativePhase").GetDouble();var raw=node.GetProperty("rawOpd").GetDouble();var x=node.GetProperty("x").GetInt32();var y=node.GetProperty("y").GetInt32();return new{x,y,opd=native,core=raw,nativeFftPhase=np,rawPhaseError=Wrap(-2*Math.PI*native-np),opdError=raw-native};
  }).ToArray();
  var modified=wf with{Samples=wf.Samples.Select(s=>s with{OpdWaves=map[(s.NormalizedPupilX,s.NormalizedPupilY)].GetProperty("opd").GetDouble(),Intensity=1}).ToArray()};
  object?[] p={optic,(0d,0d),wave,n,m,false,true,0d,modified,null,true,false,true,reference,0d,true,null,sphere,grid};var psf=(PsfResult)compute.Invoke(null,p)!;
  var result=new{id,mode,chief=map[(0d,0d)].GetProperty("opd").GetDouble(),maximumOddPhaseError=points.Where(v=>(v.x+v.y)%2!=0).Max(v=>Math.Abs(v.rawPhaseError)),maximumRawOpdError=points.Max(v=>Math.Abs(v.opdError)),curveNrmse=Metric(Curve(psf.Values),expected),points};output.Add(result);Console.WriteLine(JsonSerializer.Serialize(new{id,mode,result.chief,result.maximumOddPhaseError,result.maximumRawOpdError,result.curveNrmse}));
 }
 double[] Curve(double[,] a){var samples=Enumerable.Range(0,m).SelectMany(y=>Enumerable.Range(0,m).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,a[(y+1)%m,(x+1)%m]))).ToArray();var total=samples.Sum(s=>s.Weight);var center=(samples.Sum(s=>s.X*s.Weight)/total,samples.Sum(s=>s.Y*s.Weight)/total);var eg=new FftCumulativeEnergyGrid(samples,center,"encircled");var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(eg.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;var values=MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());var previous=0d;return values.Select(v=>previous=Math.Clamp(Math.Max(previous,v),0,1)).ToArray();}
}
File.WriteAllText(Path.Combine(task,"native-radial-opd-diagnosis.json"),JsonSerializer.Serialize(output));
static double Wrap(double value)=>Math.Atan2(Math.Sin(value),Math.Cos(value));
static double Metric(double[] a,double[] b)=>Math.Sqrt(a.Zip(b,(x,y)=>(x-y)*(x-y)).Average())/(b.Max()-b.Min());
