using System.Text.Json;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Analysis;
var task=Path.Combine(args[0],"artifacts/validation/dee-relay64w3-repair-20261018");using var req=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"tomography-fixed/zero/dee.json")));var optic=OpticalFormatCatalog.Import(File.ReadAllText(req.RootElement.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=true;var wave=optic.Wavelengths[2];var primary=optic.Wavelengths.First(w=>w.IsPrimary);var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),primary,true);var precise=new DecimalMeridional(optic,wave,sphere);
using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"cache-proof/original-rays/ray-audit.json")));var inputs=audit.RootElement.GetProperty("inputs");var rays=audit.RootElement.GetProperty("surfaces")[3].GetProperty("rays");const double radius=11.153414102018992;
var output=new List<object>();
foreach(var representation in new[]{"slope","cosine"})foreach(var update in new[]{"none","inverse-derivative","chief-derivative","exact-newton","diagonal"}){
 var cache=new (double X,double Y)[3,3];for(var y=0;y<3;y++)for(var x=0;x<3;x++){var v=precise.Launch(x*.5,y*.5);if(representation=="cosine"){var norm=Math.Sqrt(1+v.X*v.X+v.Y*v.Y);v=(v.X/norm,v.Y/norm);}cache[y,x]=v;}
 var chief=precise.Launch(0,.00001).Y/.00001;var nodes=new List<object>();var error=new List<double>();var nativeValues=new List<double>();var computedValues=new List<double>();
 for(var i=0;i<inputs.GetArrayLength();i++){
 var px=inputs[i].GetProperty("px").GetDouble();var py=inputs[i].GetProperty("py").GetDouble();if(px<0||py<0||(px==0&&py==0))continue;
 var lx=L(px);var ly=L(py);var dx=D(px);var dy=D(py);double vx=0,vy=0,a=0,b=0,c=0,d=0;
 for(var y=0;y<3;y++)for(var x=0;x<3;x++){var v=cache[y,x];vx+=v.X*lx[x]*ly[y];vy+=v.Y*lx[x]*ly[y];a+=v.X*dx[x]*ly[y];b+=v.X*lx[x]*dy[y];c+=v.Y*dx[x]*ly[y];d+=v.Y*lx[x]*dy[y];}
 (double X,double Y) Aim(double x,double y)=>representation=="cosine"?(x/Math.Sqrt(1-x*x-y*y),y/Math.Sqrt(1-x*x-y*y)):(x,y);
 var slope=Aim(vx,vy);var p0=precise.Stop(slope.X,slope.Y);var ex=px-p0.X;var ey=py-p0.Y;
 if(update=="inverse-derivative"){vx+=a*ex+b*ey;vy+=c*ex+d*ey;}
 if(update=="diagonal"){vx+=a*ex;vy+=d*ey;}
 if(update=="chief-derivative"){vx+=chief*ex;vy+=chief*ey;}
 if(update=="exact-newton"){
 const double h=1e-6;var s1=Aim(vx+h,vy);var s2=Aim(vx,vy+h);var p1=precise.Stop(s1.X,s1.Y);var p2=precise.Stop(s2.X,s2.Y);a=(p1.X-p0.X)/h;b=(p2.X-p0.X)/h;c=(p1.Y-p0.Y)/h;d=(p2.Y-p0.Y)/h;var det=a*d-b*c;vx+=(d*ex-b*ey)/det;vy+=(a*ey-c*ex)/det;
 }
 slope=Aim(vx,vy);var result=precise.Stop(slope.X,slope.Y);var actual=rays[i];var nx=actual.GetProperty("x").GetDouble()/radius;var ny=actual.GetProperty("y").GetDouble()/radius;var computed=double.Hypot(result.X,result.Y)/double.Hypot(px,py)-1;var native=double.Hypot(nx,ny)/double.Hypot(px,py)-1;nativeValues.Add(native);computedValues.Add(computed);error.Add(Math.Abs(computed-native));nodes.Add(new{px,py,computed,native});
 }
 var item=new{representation,update,maximumDifference=error.Max(),meanDifference=error.Average(),nativeRms=Math.Sqrt(nativeValues.Average(v=>v*v)),computedRms=Math.Sqrt(computedValues.Average(v=>v*v)),nodes};output.Add(item);Console.WriteLine(JsonSerializer.Serialize(new{representation,update,item.maximumDifference,item.meanDifference,item.nativeRms,item.computedRms}));
}
File.WriteAllText(Path.Combine(task,"cache-algorithm-diagnosis.json"),JsonSerializer.Serialize(output));
static double[] L(double x)=>new[]{2*(x-.5)*(x-1),4*x*(1-x),2*x*(x-.5)};
static double[] D(double x)=>new[]{4*x-3,4-8*x,4*x-1};

