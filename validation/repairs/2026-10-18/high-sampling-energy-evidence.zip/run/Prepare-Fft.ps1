$ErrorActionPreference='Stop'
$dir=Join-Path $PSScriptRoot 'fft-diagnostic';New-Item -ItemType Directory -Path $dir|Out-Null
$jobs=@()
foreach($id in @('apo-minus128','base128')){
 $h=Get-Content (Join-Path $PSScriptRoot ('native/'+$id+'-huygens/data.json')) -Raw|ConvertFrom-Json
 $delta=$h.dataGrids[0].dx
 foreach($type in @('Linear','Real','Imaginary')){
  $r=Get-Content (Join-Path $PSScriptRoot ('requests/'+$id+'/dee.json')) -Raw|ConvertFrom-Json
  $r.canonicalAnalysisKey='PSF';$r.analysisType='FftPsf';$r.imageDeltaMicrometers=$delta
  $r.zemaxSettings=[ordered]@{Normalize=$false;OutputSize='PsfS_256x256';SampleSize='PsfS_128x128';ImageDelta=$delta;Wavelength=$r.wavelength;Surface=-1;Rotation='CW0';Type=$type;Field=1;UsePolarization=$false}
  $path=Join-Path $dir ($id+'-'+$type+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-'+$type;request=$path;output=(Join-Path $dir ($id+'-'+$type))}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $dir 'native-jobs.json') -Encoding utf8NoBOM
