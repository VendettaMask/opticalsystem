using System.Numerics;
using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-perturb128-20261018");
if(args.Length>1 && args[1]=="launch"){
 var output=new List<object>();
 foreach(var id in new[]{"apo-minus128","base128"}){
  using var request=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"requests",id,"dee.json")));
  using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"native",id+"-rays/ray-audit.json")));
  var optic=OpticalFormatCatalog.Import(File.ReadAllText(request.RootElement.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=id=="base128";var wave=optic.Wavelengths.First(w=>w.IsPrimary);
  var origin=optic.SurfaceGroup.Items[0].CoordinateSystem;var last=optic.SurfaceGroup.Items[^1];var native=audit.RootElement.GetProperty("surfaces").EnumerateArray().Last().GetProperty("rays");
  var rows=new List<object>();var i=0;
  foreach(var launch in audit.RootElement.GetProperty("launches").EnumerateArray().Take(5)){
   var input=audit.RootElement.GetProperty("inputs")[i];var px=input.GetProperty("px").GetDouble();var py=input.GetProperty("py").GetDouble();
   var own=optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,px,py,wave.Micrometers,optic.RayAimingEnabled).Rays[0];
   var p=new OpticalSystemDesign.Core.Backend.Vector3D(launch.GetProperty("x").GetDouble(),launch.GetProperty("y").GetDouble(),launch.GetProperty("z").GetDouble());
   var d=new OpticalSystemDesign.Core.Backend.Vector3D(launch.GetProperty("l").GetDouble(),launch.GetProperty("m").GetDouble(),launch.GetProperty("n").GetDouble());
   var ray=new OpticalSystemDesign.Core.Rays.RealRay(origin.ToGlobalPoint(p),origin.ToGlobalDirection(d),wave.Nanometers);
   var ownResult=optic.SequentialRayTracer.TraceToSurface(own,optic.SurfaceGroup.Items.Count-1)!;var replay=optic.SequentialRayTracer.TraceToSurface(ray,optic.SurfaceGroup.Items.Count-1)!;
   rows.Add(new{i,ownLaunch=own,ownDirection=ownResult.Direction,replayedDirection=replay.Direction,native=native[i].Clone()});i++;
  }
  output.Add(new{id,rows});
 }
 File.WriteAllText(Path.Combine(task,"launch-isolation.json"),JsonSerializer.Serialize(output));return;
}
if(args.Length>1 && args[1]=="invert"){
 var rows=new List<object>();
 foreach(var id in new[]{"apo-minus128","base128"}){
  using var re=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic",id+"-Real/data.json")));
  using var im=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic",id+"-Imaginary/data.json")));
  using var li=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic",id+"-Linear/data.json")));
  var rg=re.RootElement.GetProperty("dataGrids")[0];var ig=im.RootElement.GetProperty("dataGrids")[0];var lg=li.RootElement.GetProperty("dataGrids")[0];
  int m=rg.GetProperty("nx").GetInt32();var pupil=new Complex[m,m];double error=0;
  for(int y=0;y<m;y++)for(int x=0;x<m;x++){var v=new Complex(rg.GetProperty("values")[y][x].GetDouble(),ig.GetProperty("values")[y][x].GetDouble());pupil[(y+1)%m,(x+1)%m]=v;error=Math.Max(error,Math.Abs(v.Magnitude*v.Magnitude-lg.GetProperty("values")[y][x].GetDouble()));}
  DiffractionEngine.FourierTransform2D(pupil,true);var max=pupil.Cast<Complex>().Max(v=>v.Magnitude);
  var nodes=new List<object>();for(int y=0;y<m;y++)for(int x=0;x<m;x++)if(pupil[y,x].Magnitude>max*.5)nodes.Add(new{x=x<m/2?x:x-m,y=y<m/2?y:y-m,amplitude=pupil[y,x].Magnitude/max,phase=pupil[y,x].Phase});
  rows.Add(new{id,count=nodes.Count,complexIntensityError=error,spacing=rg.GetProperty("dx").GetDouble(),nodes});Console.WriteLine($"{id}: {nodes.Count} nodes, error {error:R}");
 }
 File.WriteAllText(Path.Combine(task,"native-inverted-pupils.json"),JsonSerializer.Serialize(rows));return;
}
var method=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
var rows2=new List<object>();
var lists=args.Length>1 && args[1]=="scalarsall"?new[]{Path.Combine(repo,"artifacts/validation/numerical-residuals-20261018/holdout-jobs.json"),Path.Combine(repo,"artifacts/validation/dee-multi-lens-20261018/perturbed/native-jobs.json"),Path.Combine(repo,"artifacts/validation/dee-apochromat128-20261018/native-jobs.json"),Path.Combine(task,"dee-jobs.json")}:new[]{Path.Combine(task,"dee-jobs.json")};
foreach(var listPath in lists){
using var list=JsonDocument.Parse(File.ReadAllText(listPath));
foreach(var job in list.RootElement.EnumerateArray()){
 using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=request.RootElement;var id=job.GetProperty("id").GetString()!;
 if(r.GetProperty("wavelength").GetInt32()==0)continue;
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");
 using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));
 optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 var primary=optic.Wavelengths.First(w=>w.IsPrimary);var wave=optic.Wavelengths[r.GetProperty("wavelength").GetInt32()-1];var n=r.GetProperty("pupilSampling").GetInt32();
 var scale=((double Rms,double T,double S))method.Invoke(null,new object[]{optic,(0d,0d),primary})!;var cone=((double Rms,double T,double S))method.Invoke(null,new object[]{optic,(0d,0d),wave})!;
 var psf=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),new[]{wave},n,true)[0].Result;
 var f=DiffractionEngine.WorkingFNumber(optic,(0,0),wave,optic.RayAimingEnabled);var fp=DiffractionEngine.WorkingFNumber(optic,(0,0),primary,optic.RayAimingEnabled);
 rows2.Add(new{id,n,lambda=wave.Micrometers,nanometers=wave.Nanometers,na=scale.Rms,t=cone.T,s=cone.S,f,fp,rms=cone.Rms,count=100d*4*n*n/psf.Values.Cast<double>().Sum(),spacing=psf.SampleSpacingMicrometers});
}
}
File.WriteAllText(Path.Combine(task,args.Length>1 && args[1]=="scalarsall"?"scalars-all.json":"scalar-controls.json"),JsonSerializer.Serialize(rows2));
