import math,json
from pathlib import Path
root=Path(__file__).parent
old=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
new=json.loads((root/'scalar-controls.json').read_text())
expected={'0014-n64':197,'0014-n128':405,'0308-n64':197,'0308-n128':405,'0360-n64':197,'0360-n128':405,'0472-n64':193,'0472-n128':401,'0592-n64':193,'0592-n128':401,'0852-n64':197,'0852-n128':401,'0014-minus':197,'0014-plus':197,'0472-minus':197,'0472-plus':197,'decenter-minus1p5':195,'decenter-plus3':193,'original':405,'epd-minus-small':405,'epd-plus-small':405,'apo-minus128':405,'base128':401,'apo-half-minus':405,'apo-half-plus':405,'base-fnum-minus':405,'base-fnum-plus':405,'base-wave1':401,'base-wave3':405}
out=[]
for v in range(12):
 for dpMode in range(2):
  counts={}
  for row in old+new:
   if row['id'] not in expected:continue
   n=row['n'];l=row['lambda'];r=row['na'];a=math.sqrt(n/32);f=.5/r
   c=[2*r/l,2*(r/l),(2/l)*r,(1/l)*(2*r),1/(l*f),1/l/f,1/(l/(2*r)),2/(l/r),1/(l*(1/(2*r))),1/(f/(1/l)),(1/f)/l,(1/f)*(1/l)][v]
   p=math.sqrt(1/n)/c
   def stretch(na):
    f=.5/na;dp=(l*f*(n-2) if dpMode==0 else l*(f*(n-2)))/(2*n*a);return a*dp/p
   sx=stretch(row['s']);sy=stretch(row['t']);xs=[sx*((x-n/2)/(n/2-1)) for x in range(n)];ys=[sy*((y-n/2)/(n/2-1)) for y in range(n)]
   counts[row['id']]=sum(x*x+y*y<=1 for x in xs for y in ys)
  misses={k:c for k,c in counts.items() if c!=expected[k]};out.append(dict(cutoff=v,dp=dpMode,misses=misses,counts=counts))
  if len(misses)<=3:print(v,dpMode,misses)
(root/'cutoff-periods.json').write_text(json.dumps(out,indent=2))
