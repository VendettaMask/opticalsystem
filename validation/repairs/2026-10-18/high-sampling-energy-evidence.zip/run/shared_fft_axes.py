import math,json
from pathlib import Path
root=Path(__file__).parent
rows=json.loads((root/'scalars-all.json').read_text())
expected={'0014-n64':197,'0014-n128':405,'0308-n64':197,'0308-n128':405,'0360-n64':197,'0360-n128':405,'0472-n64':193,'0472-n128':401,'0592-n64':193,'0592-n128':401,'0852-n64':197,'0852-n128':401,'0014-minus':197,'0014-plus':197,'0472-minus':197,'0472-plus':197,'original':405,'epd-minus-small':405,'epd-plus-small':405,'apo-minus128':405,'base128':401,'apo-half-minus':405,'apo-half-plus':405,'base-fnum-minus':405,'base-fnum-plus':405,'base-wave1':401,'base-wave3':405}
out=[]
for baseMode in range(3):
 for dpMode in range(2):
  for scaleMode in range(6):
   counts={}
   for r in rows:
    if r['id'] not in expected:continue
    n=r['n'];l=r['lambda'];f=[r['f'],.5/r['rms'],r['fp']][baseMode];a=math.sqrt(n/32);p=math.sqrt(1/n)/(2*r['na']/l)
    dp=(l*f*(n-2) if dpMode==0 else l*(f*(n-2)))/(2*n*a)
    b=a*dp/p
    def stretch(na):
     af=.5/na
     return [lambda:b*(af/f),lambda:(b*af)/f,lambda:(b/f)*af,lambda:b/(f/af),lambda:b*(.5/(f*na)),lambda:(b*.5)/(f*na)][scaleMode]()
    sx=stretch(r['s']);sy=stretch(r['t']);xs=[sx*((x-n/2)/(n/2-1)) for x in range(n)];ys=[sy*((y-n/2)/(n/2-1)) for y in range(n)]
    counts[r['id']]=sum(x*x+y*y<=1 for x in xs for y in ys)
   misses={k:c for k,c in counts.items() if c!=expected[k]};out.append(dict(base=baseMode,dp=dpMode,scale=scaleMode,misses=misses,counts=counts))
   if len(misses)<=2:print(baseMode,dpMode,scaleMode,misses)
(root/'shared-fft-axes.json').write_text(json.dumps(out,indent=2))
