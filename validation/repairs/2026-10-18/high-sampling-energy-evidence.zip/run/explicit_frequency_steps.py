import math,json
from pathlib import Path
root=Path(__file__).parent
rows=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
out=[]
for r in rows:
 if r['id'] in ('epd-minus5pct','epd-plus5pct','wave1','wave8'):continue
 n=r['n'];l=r['lambda'];c=r['cutoff'];a=math.sqrt(n/32);p=math.sqrt(1/n)/c
 counts=[]
 for v in range(16):
  def step(na):
   f=.5/na;ll=l if v<8 else l*.001;pp=p if v<8 else p*.001
   return [lambda:1/(n*pp/ll/f),lambda:1/(n*(pp/ll)/f),lambda:1/((n*pp)/(ll*f)),
     lambda:(ll*f)/(n*pp),lambda:ll*(f/(n*pp)),lambda:(ll/pp)*(f/n),lambda:(ll/(n*pp))*f,lambda:1/(pp*(n/ll)/f)][v%8]()
  sx=step(r['s']);sy=step(r['t']);xs=[sx*(x-n/2) for x in range(n)];ys=[sy*(y-n/2) for y in range(n)]
  counts.append(sum(x*x+y*y<=1 for x in xs for y in ys))
 out.append(dict(id=r['id'],counts=counts));print(r['id'],counts)
(root/'explicit-frequency-steps.json').write_text(json.dumps(out,indent=2))
