import math,json
from pathlib import Path
root=Path(__file__).parent
rows=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
out=[]
for r in rows:
 if r['id'] in ('epd-minus5pct','epd-plus5pct','wave1','wave8'):continue
 n=r['n'];l=r['lambda'];c=r['cutoff'];a=math.sqrt(n/32);sn=math.sqrt(n);ds=math.sqrt(1/n);p=ds/c
 counts=[]
 for v in range(12):
  def coordinate(k,na):
   f=.5/na;dp=l*(f*(n-2))/(2*n*a);q=(k-n/2)/(n/2-1);g=a*q
   return [lambda:((g*dp)*c)*sn,lambda:((g*c)*dp)*sn,lambda:((dp*c)*sn)*g,
      lambda:((g*sn)*dp)*c,lambda:((g*dp)*sn)*c,lambda:g*((dp*sn)*c),
      lambda:g*(dp*(c*sn)),lambda:((g*dp)/p),lambda:((g/p)*dp),
      lambda:(g/c)*(dp/(1/(c*c*sn))),lambda:((q*dp)/p)*a,
      lambda:((g*dp)*(c/ds))][v]()
  xs=[coordinate(x,r['s']) for x in range(n)];ys=[coordinate(y,r['t']) for y in range(n)]
  counts.append(sum(x*x+y*y<=1 for x in xs for y in ys))
 out.append(dict(id=r['id'],counts=counts));print(r['id'],counts)
(root/'coordinate-frequencies.json').write_text(json.dumps(out,indent=2))
