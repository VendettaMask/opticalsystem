$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$old=Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout'
$aperture=Join-Path $repo 'artifacts/validation/dee-apochromat128-20261018/requests/epd-minus-small/dee.json'
$jobs=@();$deeJobs=@()
foreach($id in @('apo-minus128','base128','apo-half-minus','apo-half-plus','base-fnum-minus','base-fnum-plus','base-wave1','base-wave3')){
 $template=if($id.StartsWith('apo-')){$aperture}else{Join-Path $old '0852-n128/request.json'}
 $r=Get-Content $template -Raw|ConvertFrom-Json
 $dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir|Out-Null
 if($id.StartsWith('apo-half')){
  $original=Get-Content (Join-Path $old '0014-n128/request.json') -Raw|ConvertFrom-Json
  $text=[IO.File]::ReadAllText($original.input);$epd=if($id.EndsWith('minus')){'9.999999999999975'}else{'10.000000000000027'}
  if([regex]::Matches($text,'(?m)^ENPD 10[ \t]*\r?$').Count -ne 1){throw 'Unexpected original aperture'}
  $source=Join-Path $dir 'aperture.zmx';[IO.File]::WriteAllText($source,[regex]::Replace($text,'(?m)^ENPD 10[ \t]*\r?$','ENPD '+$epd),[Text.UTF8Encoding]::new($false));$r.input=$source
 }
 if($id.StartsWith('base-fnum')){
  $text=[IO.File]::ReadAllText($r.input);$number=if($id.EndsWith('minus')){'2.699999999999987'}else{'2.700000000000014'}
  if([regex]::Matches($text,'(?m)^FNUM 2\.7000000000000002 0[ \t]*\r?$').Count -ne 1){throw 'Unexpected base aperture'}
  $source=Join-Path $dir 'aperture.zmx';[IO.File]::WriteAllText($source,[regex]::Replace($text,'(?m)^FNUM 2\.7000000000000002 0[ \t]*\r?$','FNUM '+$number+' 0'),[Text.UTF8Encoding]::new($false));$r.input=$source
 }
 if($id.StartsWith('base-wave')){$w=[int]$id.Substring(9);$r.wavelength=$w;$r.workbenchSettings.WavelengthNumber="$w";$r.zemaxSettings.Wavelength=$w}
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $j=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))};$jobs+=$j;$deeJobs+=$j
 if($id -in 'apo-minus128','base128'){
  $r.canonicalAnalysisKey='Huygens PSF';$r.analysisType='HuygensPsf';$r.imageSampling=32;$r.imageDeltaMicrometers=0
  $r.zemaxSettings=[ordered]@{Normalize=$false;PupilSampleSize='S_128x128';ImageSampleSize='S_32x32';ImageDelta=0;Wavelength=$r.wavelength;UseCentroid=$false;Configuration=1;Rotation='Rotate_0';Type='Linear';Field=1;UsePolarization=$false}
  $path=Join-Path $dir 'huygens.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-huygens';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-huygens'))}
  $r=Get-Content (Join-Path $dir 'dee.json') -Raw|ConvertFrom-Json
  $r.adapter='ray-audit';$r|Add-Member removeVignettingFactors $false;$r|Add-Member surfaceRecordLimit 10000
  $inputs=@(@{px=0;py=0},@{px=0;py=1},@{px=0;py=-1},@{px=1;py=0},@{px=-1;py=0});$a=1/[Math]::Sqrt(2)
  foreach($x in @(-$a,$a)){foreach($y in @(-$a,$a)){$inputs+=@{px=$x;py=$y}}}
  for($i=0;$i -lt $inputs.Count;$i++){$inputs[$i].hx=0;$inputs[$i].hy=0;$inputs[$i].fieldIndex=0;$inputs[$i].pupilIndex=$i}
  $r|Add-Member rayAuditInputs $inputs;$path=Join-Path $dir 'rays.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-rays';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-rays'))}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($deeJobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'dee-jobs.json') -Encoding utf8NoBOM
