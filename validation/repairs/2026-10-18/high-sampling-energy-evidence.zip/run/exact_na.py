import json,math
from decimal import Decimal as D,getcontext
from pathlib import Path
getcontext().prec=120
root=Path(__file__).parent
old=root.parent/'dee-apochromat128-20261018'
out=[]
for row in json.loads((old/'marginal-directions.json').read_text()):
 dirs=[[D(d[k]) for k in ('X','Y','Z')] for d in row['directions']];chief=dirs[0]
 sq=lambda v:sum(x*x for x in v)
 true=[];raw=[]
 for d in dirs[1:]:
  c=[chief[1]*d[2]-chief[2]*d[1],chief[2]*d[0]-chief[0]*d[2],chief[0]*d[1]-chief[1]*d[0]]
  true.append(sq(c)/(sq(chief)*sq(d)));raw.append(sq(c))
 nas=[a.sqrt() for a in true]
 rr=float((sum(true)/4).sqrt());tt=float((nas[0]+nas[1])/2);ss=float((nas[2]+nas[3])/2)
 rr2=float((sum(raw)/4).sqrt())
 naive=float((sum(D(float(v))**2 for v in nas)/4).sqrt())
 out.append(dict(id=row['id'],rms=rr,t=tt,s=ss,naive=naive,rawRms=rr2))
 print(row['id'],rr,tt,ss,naive,rr2)
(root/'exact-na.json').write_text(json.dumps(out,indent=2))
