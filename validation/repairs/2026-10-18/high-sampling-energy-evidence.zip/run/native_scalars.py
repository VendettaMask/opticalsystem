from decimal import Decimal as D,getcontext
from pathlib import Path
import json,math
getcontext().prec=100
root=Path(__file__).parent
out=[]
for id,l in [('apo-minus128',.4788303),('base128',.44)]:
 ray=json.loads((root/'native'/f'{id}-rays'/'ray-audit.json').read_text(encoding='utf-8'))['surfaces'][-1]['rays']
 chief=[ray[0][k] for k in ('l','m','n')]
 norm=lambda a:math.sqrt(sum(v*v for v in a))
 nas=[]
 for r in ray[1:5]:
  d=[r[k] for k in ('l','m','n')]
  c=[chief[1]*d[2]-chief[2]*d[1],chief[2]*d[0]-chief[0]*d[2],chief[0]*d[1]-chief[1]*d[0]]
  nas.append(norm(c)/(norm(chief)*norm(d)))
 rms=float((sum(D(v)**2 for v in nas)/4).sqrt());t=(nas[0]+nas[1])/2;s=(nas[2]+nas[3])/2
 counts=[]
 for formula in range(4):
  p=(math.sqrt(1/128)/(2*rms/l)) if formula<2 else 1/((2*rms/l)*math.sqrt(128))
  stretch=lambda a:2*(l*(.5/a)*126/512 if formula%2==0 else l*((.5/a)*126)/512)/p
  xx=[stretch(s)*(k/63) for k in range(-64,64)];yy=[stretch(t)*(k/63) for k in range(-64,64)]
  counts.append(sum(x*x+y*y<=1 for x in xx for y in yy))
 out.append(dict(id=id,nas=nas,rms=rms,t=t,s=s,counts=counts));print(out[-1])
(root/'native-scalars.json').write_text(json.dumps(out,indent=2))
