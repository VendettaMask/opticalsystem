import json
from pathlib import Path
root=Path(__file__).parent
required={'0014-n64':197,'0014-n128':405,'0308-n64':197,'0360-n64':197,'0360-n128':405,'0472-n64':193,'0472-n128':401,'0592-n64':193,'0852-n64':197,'0852-n128':401,'0014-minus':197,'0014-plus':197,'0472-minus':197,'0472-plus':197,'original':405,'epd-minus-small':405}
out=[]
for name in ['unit-intervals','angular-intervals','shared-fft-axes','fnumber-cones','na-frequency-steps','cutoff-periods']:
 for row in json.loads((root/f'{name}.json').read_text()):
  c=row['counts'];misses={k:c[k] for k,v in required.items() if k in c and c[k]!=v}
  if c.get('0852-n128')==401 and c.get('epd-minus-small')==405 and c.get('original')==405:
   out.append(dict(route=name,meta={k:v for k,v in row.items() if k not in ('counts','misses')},misses=misses,otherMisses=row['misses']))
for row in sorted(out,key=lambda x:len(x['misses']))[:20]:print(row)
(root/'qualified-routes.json').write_text(json.dumps(sorted(out,key=lambda x:len(x['misses'])),indent=2))
