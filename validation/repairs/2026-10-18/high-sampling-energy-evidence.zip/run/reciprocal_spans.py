import math,json
from pathlib import Path
root=Path(__file__).parent
rows=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
out=[]
for r in rows:
 if r['id'] in ('epd-minus5pct','epd-plus5pct','wave1','wave8'):continue
 n=r['n'];l=r['lambda'];c=r['cutoff'];a=math.sqrt(n/32);p=math.sqrt(1/n)/c
 counts=[]
 for v in range(14):
  def stretch(na):
   f=.5/na;dp=l*(f*(n-2))/(2*n*a)
   return [lambda:a/(p/dp),lambda:1/(p/(a*dp)),lambda:a*((1/p)/(1/dp)),lambda:(a/p)/(1/dp),
     lambda:(l*f)/((2*n/(n-2))*a)*a/p,
     lambda:l*(f/((2*n/(n-2))*a))*a/p,
     lambda:(l*f)/(2*a*(n/(n-2)))*a/p,
     lambda:(l*f)/(n/(n-2))/(2*a)*a/p,
     lambda:l*(f/(n/(n-2)))/(2*a)*a/p,
     lambda:l/(n/(n-2))*f/(2*a)*a/p,
     lambda:((l*f)/a)/(2*n/(n-2))*a/p,
     lambda:(l*f)/(a*(2*n/(n-2)))*a/p,
     lambda:(l*f)/((2*n*a)/(n-2))*a/p,
     lambda:l*(f/((2*n*a)/(n-2)))*a/p][v]()
  sx=stretch(r['s']);sy=stretch(r['t']);xs=[sx*((x-n/2)/(n/2-1)) for x in range(n)];ys=[sy*((y-n/2)/(n/2-1)) for y in range(n)]
  counts.append(sum(x*x+y*y<=1 for x in xs for y in ys))
 out.append(dict(id=r['id'],counts=counts));print(r['id'],counts)
(root/'reciprocal-spans.json').write_text(json.dumps(out,indent=2))
