import math,json
from pathlib import Path
root=Path(__file__).parent
old=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
new=json.loads((root/'scalar-controls.json').read_text())
expected={'0014-n64':197,'0014-n128':405,'0308-n64':197,'0308-n128':405,'0360-n64':197,'0360-n128':405,'0472-n64':193,'0472-n128':401,'0592-n64':193,'0592-n128':401,'0852-n64':197,'0852-n128':401,'0014-minus':197,'0014-plus':197,'0472-minus':197,'0472-plus':197,'decenter-minus1p5':195,'decenter-plus3':193,'original':405,'epd-minus-small':405,'epd-plus-small':405,'apo-minus128':405,'base128':401,'apo-half-minus':405,'apo-half-plus':405,'base-fnum-minus':405,'base-fnum-plus':405,'base-wave1':401,'base-wave3':405}
out=[]
for unit in (1,.001):
 for pitchMode in range(4):
  for mode in range(10):
   counts={}
   for r in old+new:
    if r['id'] not in expected:continue
    n=r['n'];l=r['lambda']*unit;k=2*math.pi/l;a=math.sqrt(n/32);rms=r['na'];ds=math.sqrt(1/n)
    period=math.pi/(k*rms)
    p=[ds/(2*rms/l),ds*period,ds*((2*math.pi)/(2*rms*k)),ds/(rms*k/math.pi)][pitchMode]
    def span(na):
     period=[math.pi/(k*na),(math.pi/k)/na,(math.pi/na)/k,(2*math.pi)/(2*na*k),1/(na*k/math.pi)][mode//2]
     dp=period*(n-2)/(2*n*a) if mode%2==0 else period*((n-2)/(2*n*a))
     return a*dp/p
    sx=span(r['s']);sy=span(r['t']);xs=[sx*((x-n/2)/(n/2-1)) for x in range(n)];ys=[sy*((y-n/2)/(n/2-1)) for y in range(n)]
    counts[r['id']]=sum(x*x+y*y<=1 for x in xs for y in ys)
   misses={k:c for k,c in counts.items() if c!=expected[k]}
   out.append(dict(unit=unit,pitch=pitchMode,mode=mode,misses=misses,counts=counts))
   if len(misses)<=2:print(unit,pitchMode,mode,misses)
(root/'angular-intervals.json').write_text(json.dumps(out,indent=2))
