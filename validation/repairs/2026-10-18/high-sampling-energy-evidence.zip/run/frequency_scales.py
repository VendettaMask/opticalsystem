import math,json
from pathlib import Path
root=Path(__file__).parent
rows=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
out=[]
for r in rows:
 n=r['n'];l=r['lambda'];c=r['cutoff'];a=math.sqrt(n/32);ds=math.sqrt(1/n);p=ds/c
 counts=[]
 for v in range(12):
  def stretch(na):
   f=.5/na;dp=(l*f*(n-2) if v<6 else l*(f*(n-2)))/(2*n*a)
   frequency=[1/p,c/ds,c*(1/ds),c*math.sqrt(n),math.sqrt(n)*c,(1/ds)/(1/c)][v%6]
   return a*dp*frequency
  sx=stretch(r['s']);sy=stretch(r['t']);xs=[sx*((x-n/2)/(n/2-1)) for x in range(n)];ys=[sy*((y-n/2)/(n/2-1)) for y in range(n)]
  counts.append(sum(x*x+y*y<=1 for x in xs for y in ys))
 out.append(dict(id=r['id'],counts=counts));print(r['id'],counts)
(root/'frequency-scales.json').write_text(json.dumps(out,indent=2))
