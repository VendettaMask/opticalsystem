import math,json
from pathlib import Path
root=Path(__file__).parent
old=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
new=json.loads((root/'scalar-controls.json').read_text())
expected=json.loads((root/'angular-intervals.json').read_text())[0]['counts']
expected.update({'0014-n64':197,'0014-n128':405,'0308-n64':197,'0308-n128':405,'0360-n64':197,'0360-n128':405,'0472-n64':193,'0472-n128':401,'0592-n64':193,'0592-n128':401,'0852-n64':197,'0852-n128':401,'0014-minus':197,'0014-plus':197,'0472-minus':197,'0472-plus':197,'decenter-minus1p5':195,'decenter-plus3':193,'original':405,'epd-minus-small':405,'epd-plus-small':405,'apo-minus128':405,'base128':401,'apo-half-minus':405,'apo-half-plus':405,'base-fnum-minus':405,'base-fnum-plus':405,'base-wave1':401,'base-wave3':405})
out=[]
for v in range(8):
 for pm in range(3):
  counts={}
  for r in old+new:
   if r['id'] not in expected:continue
   n=r['n'];l=r['lambda'];na=r['na'];a=math.sqrt(n/32);f=.5/na
   ff=[f,1/math.sqrt(1/(f*f)),math.sqrt(f*f),.5/math.sqrt(.25/(f*f)),1/(math.sqrt(2/(f*f))/math.sqrt(2)),math.sqrt(1/(1/(f*f))),1/math.sqrt(.5*(1/(f*f)+1/(f*f))),2/math.sqrt(4/(f*f))][v]
   p=[math.sqrt(1/n)/(1/(l*ff)),math.sqrt(1/n)*(l*ff),math.sqrt(1/n)/(2*(.5/ff)/l)][pm]
   def stretch(na):
    dp=l*((.5/na)*(n-2))/(2*n*a);return a*dp/p
   sx=stretch(r['s']);sy=stretch(r['t']);xs=[sx*((x-n/2)/(n/2-1)) for x in range(n)];ys=[sy*((y-n/2)/(n/2-1)) for y in range(n)]
   counts[r['id']]=sum(x*x+y*y<=1 for x in xs for y in ys)
  misses={k:c for k,c in counts.items() if c!=expected[k]};out.append(dict(v=v,pitch=pm,misses=misses,counts=counts))
  if len(misses)<=3:print(v,pm,misses)
(root/'fnumber-cones.json').write_text(json.dumps(out,indent=2))
