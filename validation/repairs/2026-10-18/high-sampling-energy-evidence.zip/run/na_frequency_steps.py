import math,json
from pathlib import Path
root=Path(__file__).parent
rows=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
expected={'0014-n64':197,'0014-n128':405,'0308-n64':197,'0308-n128':405,'0360-n64':197,'0360-n128':405,'0472-n64':193,'0472-n128':401,'0592-n64':193,'0592-n128':401,'0852-n64':197,'0852-n128':401,'0014-minus':197,'0014-plus':197,'0472-minus':197,'0472-plus':197,'decenter-minus1p5':195,'decenter-plus3':193,'original':405,'epd-minus-small':405,'epd-plus-small':405}
out=[]
for unit in (1,.001):
 for rep in range(2):
  for v in range(10):
   counts={}
   for r in rows:
    if r['id'] not in expected:continue
    n=r['n'];l=r['lambda']*unit;c=r['cutoff']/unit;p=math.sqrt(1/n)/c
    def step(na):
     return [lambda:1/(n*p*(2*na/l)),lambda:1/(n*p*(na/l)*2),lambda:1/(n*p*na/l*2),lambda:l/(2*n*p*na),lambda:(l/(2*n*p))/na,lambda:(l/(2*na))/(n*p),lambda:l/((2*na)*(n*p)),lambda:1/(n*(p*(2*na/l))),lambda:(1/(n*p))/(2*na/l),lambda:(1/(2*na/l))/(n*p)][v]()
    sx=step(r['s']);sy=step(r['t'])
    xs=[sx*(x-n/2) if rep==0 else (sx*(n/2-1))*((x-n/2)/(n/2-1)) for x in range(n)]
    ys=[sy*(y-n/2) if rep==0 else (sy*(n/2-1))*((y-n/2)/(n/2-1)) for y in range(n)]
    counts[r['id']]=sum(x*x+y*y<=1 for x in xs for y in ys)
   misses={k:c for k,c in counts.items() if c!=expected[k]}
   out.append(dict(unit=unit,rep=rep,v=v,misses=misses,counts=counts))
   if len(misses)<=2:print(unit,rep,v,misses)
(root/'na-frequency-steps.json').write_text(json.dumps(out,indent=2))
