$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadJson([string]$relative){Get-Content (Join-Path $PSScriptRoot $relative) -Raw|ConvertFrom-Json}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/APOCHROMAT_128_ENERGY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$unchangedTests=@($previous.sourceFiles|Where-Object {$_.path -like 'tests/*.cs'})
foreach($s in $unchangedTests){if((Hash (Join-Path $repo $s.path)) -ne $s.sha256){throw 'Previously verified test source changed'}}
$release=Tests 'related-release-final.trx';$debug=Tests 'related-debug-final.trx'
foreach($run in @($release,$debug)){
 if($run.passed -ne $run.total -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Final main tests incomplete'}
 if(@($run.names|Where-Object {$_ -match '\.CumulativeEnergyHighSamplingTests\.'}).Count -ne 16){throw 'Sixteen new curve checks missing'}
}
if($release.total -ne 936 -or $debug.total -ne 223){throw 'Final test scope differs'}
foreach($name in $previous.verification.testRelease.names){if($name -cnotin $release.names){throw 'Prior Release test missing'}}
foreach($name in $previous.verification.testDebug.names){if($name -cnotin $debug.names){throw 'Prior Debug test missing'}}
foreach($name in $debug.names){if($name -cnotin $release.names){throw 'Debug identity absent from Release'}}
$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx'
foreach($run in @($comparisonRelease,$comparisonDebug)){if($run.total -ne 5 -or $run.passed -ne 5 -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Comparison tests incomplete'}}
$beforeTests=Tests 'high-sampling-before.trx'
if($beforeTests.total -ne 16 -or $beforeTests.failed -ne 4 -or $beforeTests.passed -ne 12 -or $beforeTests.skipped -ne 0){throw 'Before counterexample differs'}
$beforeHash=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeHash -ne $previous.verification.configurations[0].coreCopies[0].sha256){throw 'Wrong before Core'}
$configurations=foreach($configuration in @('Release','Debug')){
 $log=Get-Content (Join-Path $PSScriptRoot ('build-'+$configuration.ToLowerInvariant()+'-final.log')) -Raw
 if(@($log -split "`n"|Where-Object {$_ -match ' -> '}).Count -ne 19 -or !$log.Contains('0 个警告') -or !$log.Contains('0 个错误')){throw 'Default solution build incomplete'}
 $paths=@("src/OpticalSystemDesign.Core/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tools/OpticalSystemDesign.ZemaxComparison/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll")
 $copies=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
 if(@($copies.sha256|Sort-Object -Unique).Count -ne 1){throw 'Default Core copies differ'}
 @{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies}
}
$after=ReadJson 'formal-final/summary.json';$extra=ReadJson 'extra-final/summary.json';$apo=ReadJson 'apochromat-final/summary.json';$new=ReadJson 'controls-final/summary.json';$newBefore=ReadJson 'new-before/summary.json';$before=$previous.formalAfter
if($before.coreSha256 -ne $beforeHash -or $newBefore.coreSha256 -ne $beforeHash){throw 'Before comparison Core differs'}
foreach($s in @($after,$extra,$apo,$new)){
 if($s.coreSha256 -ne $configurations[0].coreCopies[0].sha256){throw 'Final comparison Core differs'}
 if($s.policySha256 -ne $before.policySha256 -or $s.policySha256 -ne (Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'))){throw 'Original tolerance policy changed'}
 if(@($s.rows|Where-Object conclusion -ne 'Pass').Count -ne 0){throw 'Formal control failed'}
}
if($after.rows.Count -ne 48 -or $after.excluded.Count -ne 0 -or $extra.rows.Count -ne 6 -or $extra.excluded.Count -ne 1 -or $apo.rows.Count -ne 5 -or $apo.excluded.Count -ne 2 -or $new.rows.Count -ne 8 -or $new.excluded.Count -ne 0){throw 'Comparison inventory differs'}
foreach($pair in @(@($after,$before),@($extra,$previous.independentControls),@($apo,$previous.newControlsAfter))){foreach($row in $pair[0].rows){
 $original=@($pair[1].rows|Where-Object id -ceq $row.id)
 if($original.Count -ne 1 -or $row.sourceSha256 -ne $original[0].sourceSha256 -or $row.executedRequestSha256 -ne $original[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $original[0].nativeDataSha256){throw 'Old source/request/native reference changed'}
}}
$unchangedPaths=@(ReadJson 'unchanged-path-controls.json');if($unchangedPaths.Count -ne 41 -or @($unchangedPaths|Where-Object maxPointDifference -ne 0).Count -ne 0){throw 'Unchanged low/common-grid paths differ'}
$archives=@{};foreach($p in $previous.preservedArchives.PSObject.Properties){$archives[$p.Name]=$p.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen evidence archive changed'}}
if($archives.Count -ne 14){throw 'Expected fourteen prior archives'}
$fixtures=@{};foreach($p in $previous.preservedNativeFixtures.PSObject.Properties){$fixtures[$p.Name]=$p.Value};foreach($f in $previous.newFixtures){$fixtures[$f.name]=$f.sha256}
foreach($name in $fixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $fixtures[$name]){throw 'Frozen native fixture changed'}}
if($fixtures.Count -ne 8){throw 'Expected eight prior native fixtures'}
$fixturePath=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-perturb128-zemax-2026-r1.zip';$zip=[IO.Compression.ZipFile]::OpenRead($fixturePath)
try{
 $reader=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open());try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
 foreach($e in $manifest.entries){$stream=$zip.GetEntry($e.path).Open();try{$h=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($h -ne $e.sha256){throw 'New fixture payload changed'}}
 if($manifest.cases.Count -ne 8 -or $manifest.excluded.Count -ne 0){throw 'New fixture inventory differs'}
 $fixture=@{name=[IO.Path]::GetFileName($fixturePath);sha256=Hash $fixturePath;cases=8;excluded=@();payloadEntries=$manifest.entries.Count}
}finally{$zip.Dispose()}
$captures=@();$dee=0;$grids=0;$rays=0
foreach($list in @('native-jobs.json','fft-diagnostic/native-jobs.json')){foreach($job in @(ReadJson $list)){
 $request=Get-Content $job.request -Raw|ConvertFrom-Json;$batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json;if($batch.exitCode -ne 0){throw 'Native execution error'}
 $envData=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
 if($envData.major -ne 26 -or $envData.minor -ne 1 -or $envData.opticStudioVersion -ne 260127 -or !$envData.validLicense){throw 'Native version/license differs'}
 if($request.adapter -eq 'ray-audit'){
  $data=Get-Content (Join-Path $job.output 'ray-audit.json') -Raw|ConvertFrom-Json
  if($data.inputs.Count -ne 9 -or $data.launches.Count -ne 9 -or @($data.launches|Where-Object success -ne $true).Count -ne 0){throw 'Native launch audit incomplete'}
  foreach($surface in $data.surfaces){if($surface.rays.Count -ne 9 -or @($surface.rays|Where-Object error -ne 0).Count -ne 0){throw 'Native ray audit incomplete'}};$rays++
 }else{
  $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
  if($request.analysisType -eq 'DiffractionEncircledEnergy'){
   if($data.dataSeries.Count -ne 2){throw 'Native energy curve pair missing'}
   foreach($s in $data.dataSeries){if($s.x.Count -ne 401 -or $s.y.Count -ne 401){throw 'Native energy samples missing'};foreach($y in $s.y){if($y.Count -ne 1 -or ![double]::IsFinite($y[0]) -or $y[0] -lt 0 -or $y[0] -gt 1){throw 'Invalid native energy value'}}};$dee++
  }else{
   if($data.dataGrids.Count -ne 1){throw 'Native PSF grid missing'};$g=$data.dataGrids[0]
   if($g.nx -ne $request.imageSampling -or $g.ny -ne $request.imageSampling -or $g.values.Count -ne $g.ny -or $g.dx -le 0 -or $g.dy -le 0){throw 'PSF axes invalid'}
   foreach($y in $g.values){if($y.Count -ne $g.nx){throw 'PSF row incomplete'};foreach($v in $y){if(![double]::IsFinite($v) -or ($request.zemaxSettings.Type -eq 'Linear' -and $v -lt 0)){throw 'Invalid PSF value'}}};$grids++
  }
 }
 $files=@(Get-ChildItem -LiteralPath $job.output -File|ForEach-Object {@{name=$_.Name;bytes=$_.Length;sha256=Hash $_.FullName}})
 $captures+=@{id=$job.id;state='Usable';group=$list;requestSha256=Hash $job.request;sourceSha256=Hash $request.input;files=$files}
}}
if($captures.Count -ne 18 -or $dee -ne 8 -or $grids -ne 8 -or $rays -ne 2){throw 'Native inventory differs'}
$repeats=@()
foreach($pair in @(@('apo-minus128','artifacts/validation/dee-apochromat128-20261018/native/epd-minus-small/data.json'),@('base128','artifacts/validation/numerical-residuals-20261018/holdout/0852-n128/data.json'))){
 $a=ReadJson ('native/'+$pair[0]+'/data.json');$b=Get-Content (Join-Path $repo $pair[1]) -Raw|ConvertFrom-Json
 for($c=0;$c -lt 2;$c++){for($i=0;$i -lt 401;$i++){if($a.dataSeries[$c].x[$i] -ne $b.dataSeries[$c].x[$i] -or $a.dataSeries[$c].y[$i][0] -ne $b.dataSeries[$c].y[$i][0]){throw 'Native repeat differs'}}};$repeats+=@{id=$pair[0];maximumPointDifference=0;reference=$pair[1]}
}
$supportBefore=ReadJson 'scalar-controls-before.json';$supportAfter=ReadJson 'scalar-controls-final.json';$nativeSupport=ReadJson 'native-inverted-pupils.json'
if((Get-Content (Join-Path $PSScriptRoot 'scalar-controls-final-core-sha256.txt') -Raw).Trim() -ne $after.coreSha256){throw 'Support diagnosis uses a different Core'}
foreach($pair in @(@('apo-minus128',401,405),@('base128',405,401))){
 $a=$supportBefore|Where-Object id -ceq $pair[0];$b=$supportAfter|Where-Object id -ceq $pair[0];$n=$nativeSupport|Where-Object id -ceq $pair[0]
 if([Math]::Abs($a.count-$pair[1]) -gt 1e-8 -or [Math]::Abs($b.count-$pair[2]) -gt 1e-8 -or $n.count -ne $pair[2] -or $n.complexIntensityError -gt 1e-14){throw 'Target pupil support differs'}
}
$sourceFiles=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}});if($sourceFiles.Count -ne 37){throw 'Current C# inventory differs'}
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log');if($LASTEXITCODE -ne 0){throw 'Whitespace check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='Previously reported Apochromat tiny-EPD perturbation and original 123456 n128 captures close below 1e-8, with original policy and all prior tests preserved'
 beforeCoreSha256=$beforeHash;beforeTests=$beforeTests
 constraints=@{originalTolerancePolicyUnchanged=$true;all59PriorFormalPassesPreserved=$true;prior920ReleaseIdentitiesPreserved=$true;prior207FocusedDebugIdentitiesPreserved=$true;unchangedPriorTestSources=$unchangedTests;independentCookeTessarExcluded=$true}
 verification=@{testRelease=$release;testDebug=$debug;debugScope='Prior focused 207 plus sixteen new curve checks';comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;configurations=$configurations;newMainTests=16;format=@{includedCSharpFiles=37;exitCode=0;log='format-verify.log'};gitDiffCheckExitCode=0}
 formalBefore=$before;formalAfter=$after;independentControls=$extra;priorApochromatControls=$apo;newControlsBefore=$newBefore;newControlsAfter=$new;unchangedPathControls=$unchangedPaths
 supportProof=@{before=$supportBefore;after=$supportAfter;native=$nativeSupport;nativeRepeats=$repeats;launchIsolationSha256=Hash (Join-Path $PSScriptRoot 'launch-isolation.json')}
 numericalLimitations=@{allNativeBoundaryResidualsZero=$false;newFNumberPerturbation='New 123456 FNUM minus control remains near 0.001231033617 NRMSE before and after; original-tolerance Pass, not numerically closed';samplingScope='Existing 32/64 conventions retained; high-sampling remap exercised at 128 only; higher settings not certified'}
 preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@($fixture)
 nativeCaptureSummary=@{attempts=18;usableCaptures=18;deeCaptures=8;psfCaptures=8;rayAudits=2;requestErrors=0;nativeUnavailable=0;note='Includes repeats and auxiliary Huygens/complex FFT, not eighteen lens certifications'};nativeCaptures=$captures;sourceFiles=$sourceFiles
 retainedFailureRecords=@('tests/high-sampling-before.trx','tests-before.log')
 boundaries=@{fullRepositorySuiteRun=$false;fullDebugSuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false;generalNativeBoundaryConventionCertified=$false}
}
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $repo 'docs/validation/HIGH_SAMPLING_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified two target closures, 48+6+5+8 original-policy passes, 936/223 tests, and preserved sources/references/archives/fixtures.'
