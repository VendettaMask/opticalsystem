import math,json
from pathlib import Path
root=Path(__file__).parent
rows=json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text())
functions=[
 lambda l,f,n,a:(l*f*(n-2))/(2*n*a),
 lambda l,f,n,a:(l*(f*(n-2)))/(2*n*a),
 lambda l,f,n,a:l*((f*(n-2))/(2*n*a)),
 lambda l,f,n,a:l*(f*((n-2)/(2*n*a))),
 lambda l,f,n,a:(l*f)*(1-2/n)/(2*a),
 lambda l,f,n,a:l*(f*(1-2/n))/(2*a),
 lambda l,f,n,a:((l/a)*f)*(1-2/n)/2,
 lambda l,f,n,a:((l/a)*(f*(n-2)))/(2*n),
 lambda l,f,n,a:(l*(f/a))*(n-2)/(2*n),
 lambda l,f,n,a:l*((f/a)*((n-2)/(2*n))),
 lambda l,f,n,a:(l*f)/(2*n*a)*(n-2),
 lambda l,f,n,a:l/(2*n*a)*(f*(n-2)),
 lambda l,f,n,a:(l/(2*a))*(f*(1-2/n)),
 lambda l,f,n,a:(l*f)/(2*a)*(1-2/n),
 lambda l,f,n,a:(l*(.5*f))*(1-2/n)/a,
 lambda l,f,n,a:l*((.5*f)*(1-2/n))/a,
]
out=[]
for row in rows:
 if row['unit']!=1 or row['v']!=0:continue
 n=row['n'];l=row['lambda'];c=row['cutoff'];a=math.sqrt(n/32);p=math.sqrt(1/n)/c
 counts=[]
 for fn in functions:
  sx=a*fn(l,.5/row['s'],n,a)/p;sy=a*fn(l,.5/row['t'],n,a)/p
  xs=[sx*((x-n/2)/(n/2-1)) for x in range(n)];ys=[sy*((y-n/2)/(n/2-1)) for y in range(n)]
  counts.append(sum(x*x+y*y<=1 for x in xs for y in ys))
 out.append(dict(id=row['id'],counts=counts))
 print(row['id'],counts)
(root/'default-intervals.json').write_text(json.dumps(out,indent=2))
