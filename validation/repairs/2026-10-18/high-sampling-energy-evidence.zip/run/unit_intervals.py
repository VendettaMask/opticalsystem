import math,json
from pathlib import Path
root=Path(__file__).parent
rows=[r for r in json.loads((root.parent/'dee-apochromat128-20261018/scalar-grid-units.json').read_text()) if r['unit']==1 and r['v']==0]
functions=[lambda l,f,n,a:l*f*(n-2)/(2*n*a),lambda l,f,n,a:l*(f*(n-2))/(2*n*a),lambda l,f,n,a:l*((f*(n-2))/(2*n*a)),lambda l,f,n,a:l*(f*((n-2)/(2*n*a)))]
expected={'0014-n64':197,'0014-n128':405,'0308-n64':197,'0308-n128':405,'0360-n64':197,'0360-n128':405,'0472-n64':193,'0472-n128':401,'0592-n64':193,'0592-n128':401,'0852-n64':197,'0852-n128':401,'0014-minus':197,'0014-plus':197,'0472-minus':197,'0472-plus':197,'decenter-minus1p5':195,'decenter-plus3':193,'original':405,'epd-minus-small':405,'epd-plus-small':405}
out=[]
for v in range(5):
 for dp,fn in enumerate(functions):
  for p in range(3):
   counts={}
   for r in rows:
    if r['id'] not in expected:continue
    n=r['n'];l=r['lambda'];l=[l,l*1000/1e6,l*1000*1e-6,l*.001,l/1000][v];c=2*r['na']/l;a=math.sqrt(n/32)
    pitch=[math.sqrt(1/n)/c,1/(c*math.sqrt(n)),(1/c)/math.sqrt(n)][p]
    sx=a*fn(l,.5/r['s'],n,a)/pitch;sy=a*fn(l,.5/r['t'],n,a)/pitch
    xs=[sx*((x-n/2)/(n/2-1)) for x in range(n)];ys=[sy*((y-n/2)/(n/2-1)) for y in range(n)]
    counts[r['id']]=sum(x*x+y*y<=1 for x in xs for y in ys)
   misses={k:c for k,c in counts.items() if c!=expected[k]}
   row=dict(unit=v,dp=dp,pitch=p,misses=misses,counts=counts);out.append(row)
   if len(misses)<=2:print(row['unit'],dp,p,len(misses),misses)
(root/'unit-intervals.json').write_text(json.dumps(out,indent=2))
