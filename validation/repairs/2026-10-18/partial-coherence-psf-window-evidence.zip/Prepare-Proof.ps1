$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Read-ZipJson($taskZip,[string]$taskName) {$taskReader=[IO.StreamReader]::new($taskZip.GetEntry($taskName).Open());try {return $taskReader.ReadToEnd() | ConvertFrom-Json} finally {$taskReader.Dispose()}}
function Read-Run([string]$taskFile) {
    [xml]$taskXml=Get-Content -LiteralPath $taskFile -Raw
    $taskNs=[Xml.XmlNamespaceManager]::new($taskXml.NameTable);$taskNs.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
    $taskCounters=$taskXml.SelectSingleNode('//t:ResultSummary/t:Counters',$taskNs)
    $taskNames=@($taskXml.SelectNodes('//t:Results/t:UnitTestResult',$taskNs) | ForEach-Object {$_.testName} | Sort-Object)
    @{total=[int]$taskCounters.total;passed=[int]$taskCounters.passed;failed=[int]$taskCounters.failed;skipped=[int]$taskCounters.notExecuted;names=$taskNames;newTests=@($taskNames | Where-Object {$_ -match '\.PsfEnergyWindowNativeTests\.'}).Count}
}
$taskPriorPath='validation/repairs/2026-10-17/partial-coherence-finite-evidence.zip'
if((Get-FileHash (Join-Path $taskRepo $taskPriorPath)).Hash.ToLowerInvariant() -ne '432e35047887f0f4f83b562e05f3838c8cd45d6a810b5e3aaff6b84c00ed6ba4') {throw 'Previous finite evidence changed'}
$taskZip=[IO.Compression.ZipFile]::OpenRead((Join-Path $taskRepo $taskPriorPath))
try {$taskPrior=Read-ZipJson $taskZip 'proof.json';$taskPriorCapture=Read-ZipJson $taskZip 'capture-manifest.json'} finally {$taskZip.Dispose()}
$taskPreserved=@{$taskPriorPath='432e35047887f0f4f83b562e05f3838c8cd45d6a810b5e3aaff6b84c00ed6ba4'}
foreach($taskProperty in $taskPrior.frozenArchivesPreserved.PSObject.Properties) {$taskPreserved[$taskProperty.Name]=$taskProperty.Value}
foreach($taskPath in $taskPreserved.Keys) {if((Get-FileHash (Join-Path $taskRepo $taskPath)).Hash.ToLowerInvariant() -ne $taskPreserved[$taskPath]) {throw 'Frozen evidence changed'}}
if((Get-FileHash (Join-Path $taskRepo 'tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-finite-zemax-2026-r1.json')).Hash.ToLowerInvariant() -ne $taskPriorCapture.fixtureSha256) {throw 'Previous 142-image fixture changed'}
if((Get-FileHash (Join-Path $taskRepo 'tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-zemax-2026-r1.json')).Hash.ToLowerInvariant() -ne '884b68907ae76f4e560397957724e4d20be54c84550231dc564bce63e52bac14') {throw 'Previous 18-image fixture changed'}
$taskRelease=Read-Run (Join-Path $PSScriptRoot 'final/related-release-final-v2.trx');$taskDebug=Read-Run (Join-Path $PSScriptRoot 'final/related-debug-final-v2.trx')
foreach($taskRun in @($taskRelease,$taskDebug)) {if($taskRun.total -ne 691 -or $taskRun.passed -ne 691 -or $taskRun.failed -ne 0 -or $taskRun.skipped -ne 0 -or $taskRun.newTests -ne 168) {throw 'Incomplete final related run'}}
if(($taskRelease.names -join "`n") -cne ($taskDebug.names -join "`n")) {throw 'Final test names differ'}
$taskPreviousNames=@($taskRelease.names | Where-Object {$_ -notmatch '\.PsfEnergyWindowNativeTests\.'})
if(($taskPreviousNames -join "`n") -cne (($taskPrior.testRelease.names | Sort-Object) -join "`n")) {throw 'Previous 523 tests missing or changed'}
$taskConfigurations=@()
foreach($taskConfig in @('Release','Debug')) {
    $taskLog=Get-Content (Join-Path $PSScriptRoot "build-$($taskConfig.ToLowerInvariant())-final.log") -Raw
    if(@($taskLog -split "`n" | Where-Object {$_ -match ' -> '}).Count -ne 19 -or -not $taskLog.Contains('0 个警告') -or -not $taskLog.Contains('0 个错误')) {throw 'Default root build incomplete'}
    $taskPaths=@("src/OpticalSystemDesign.Core/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll")
    $taskHashes=@($taskPaths | ForEach-Object {@{path=$_;sha256=(Get-FileHash (Join-Path $taskRepo $_)).Hash.ToLowerInvariant()}})
    if(@($taskHashes.sha256 | Sort-Object -Unique).Count -ne 1) {throw 'Default Core copies differ'}
    $taskConfigurations+=@{configuration=$taskConfig;projects=19;warnings=0;errors=0;coreCopies=$taskHashes}
}
$taskMetrics=Get-Content (Join-Path $PSScriptRoot 'metrics-release-final.json') -Raw | ConvertFrom-Json
if($taskMetrics.CoreSha256 -ne $taskConfigurations[0].coreCopies[0].sha256 -or $taskMetrics.Count -ne 96 -or @($taskMetrics.Metrics | Where-Object Error -gt 1e-9).Count -ne 0 -or @($taskMetrics.Psfs | Where-Object Error -gt 1e-9).Count -ne 0) {throw 'Numerical metrics do not describe the final default Core'}
$taskBoundaries=$taskMetrics.SamplingBoundaries
if($taskBoundaries.Count -ne 55 -or @($taskBoundaries | Where-Object NativeAvailable).Count -ne 12 -or @($taskBoundaries | Where-Object {-not $_.NativeAvailable}).Count -ne 43 -or @($taskBoundaries | Where-Object Error -gt 1e-9).Count -ne 0) {throw 'Boundary outcomes incomplete'}
foreach($taskCase in $taskBoundaries | Where-Object {-not $_.NativeAvailable}) {if($taskCase.UnavailableReason -notmatch 'intensity sampling is too low') {throw 'Unavailable boundary reason differs'}}
$taskBefore=Get-Content (Join-Path $PSScriptRoot 'metrics-before.json') -Raw | ConvertFrom-Json
if($taskBefore.CoreSha256 -ne '2b387b117e1fcb1284458c962a160ededdd94a8a7d81f93476f2296da2ef0f46' -or (Get-FileHash (Join-Path $PSScriptRoot 'Core.before.dll')).Hash.ToLowerInvariant() -ne $taskBefore.CoreSha256) {throw 'Before Core provenance differs'}
foreach($taskGroup in @('single-v1','holdout-v1','sampling-v1','sampling-fine-v1','sampling-tight-v1')) {$taskEnv=Get-Content (Join-Path $PSScriptRoot "$taskGroup/environment.json") -Raw | ConvertFrom-Json;if($taskEnv.major -ne 26 -or $taskEnv.minor -ne 1 -or $taskEnv.build -ne 260127 -or -not $taskEnv.validLicense) {throw 'Native runtime differs'}}
$taskCapture=Get-Content (Join-Path $PSScriptRoot 'capture-manifest.json') -Raw | ConvertFrom-Json
$taskBoundaryCapture=Get-Content (Join-Path $PSScriptRoot 'sampling-boundary-manifest.json') -Raw | ConvertFrom-Json
if($taskCapture.imageCaseCount -ne 96 -or $taskCapture.fullPsfCaseCount -ne 2 -or $taskBoundaryCapture.caseCount -ne 55) {throw 'Native capture counts differ'}
$taskSources=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt') | ForEach-Object {@{path=$_;sha256=(Get-FileHash (Join-Path $taskRepo $_)).Hash.ToLowerInvariant()}})
if($taskSources.Count -ne 23) {throw 'Unexpected C# format set'}
$taskProof=@{date='2026-10-18';baseCommit=(git -C $taskRepo rev-parse HEAD);scope='PSF energy window, automatic Gamma grid, and intensity sampling';testRelease=$taskRelease;testDebug=$taskDebug;previous523NamesPreserved=$true;testNamesEqual=$true;configurations=$taskConfigurations;sourceSha256=$taskCapture.sourceSha256;images=108;fullPsfs=2;unavailableCases=43;fixedImageTolerance=1e-9;metrics=$taskMetrics;before=$taskBefore;captures=$taskCapture;boundaryCaptures=$taskBoundaryCapture;preservedArchives=$taskPreserved;old18ImageFixtureUnchanged=$true;old142ImageFixtureUnchanged=$true;sourceFiles=$taskSources;format=@{fileCount=23;exitCode=0};noFullSuite=$true;noUnrelatedPrecisionMatrix=$true;noInstallerRebuild=$true;noCommitOrPush=$true}
$taskProof | ConvertTo-Json -Depth 24 | Set-Content (Join-Path $PSScriptRoot 'proof.json')
'Verified 691/691 twice, original 523 test names, 108 images, 2 full PSFs, 43 unavailable cases, and 9 frozen archives'
