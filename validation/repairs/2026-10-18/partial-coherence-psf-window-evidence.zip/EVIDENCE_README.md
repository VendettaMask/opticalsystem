# PSF energy-window and sampling evidence

Scope: original 123456.ZMX, OpticStudio 2026 R1 build 260127, scalar on-axis PCI. No independent Cooke or Tessar certification.

- proof.json: final default builds, test identities, loaded Core hashes, and preservation of prior evidence.
- metrics-release-final.json: 96 main images, 12 valid boundary images, 43 explicit unavailable outcomes, and two complete PSFs. All image comparisons use fixed axis mappings and a 1e-9 absolute normalized-intensity threshold.
- metrics-before.json: frozen prior Core public kernel/pair APIs with complete manual supports and Gamma=64. It does not represent successful old Simulate validation for all oversized-support requests.
- capture-manifest.json and accepted-native-captures/: exact source/settings/grid checks for the main images and complete PSFs.
- sampling-boundary-manifest.json and boundary-native-captures/: both sides of the native sampling boundary, including messages with ErrorCode=Success and zero-sized grids.
- product-source/: the source snapshot and frozen regression fixture ZIP files.
- Core.before.dll: prior product-owned Core with verified SHA-256. This is not a redistributed native API assembly.

Failed diagnostic candidates are retained separately from final metrics. These include fixed Gamma=64 at small Fraction, an interrupted candidate bundle after a zero-sized native grid, early probe syntax/assembly-file-name errors, and a Release build locked by an active testhost. pre-sampling snapshots are intermediate 635-test verification, not the final 691-test result.

Native internal discrete conventions were inferred and independently checked. The fixtures preserve raw native doubles; no fitted gains, shifted best matches, changed old references, or widened tolerances supply runtime or acceptance values. Automatic PSF selection and the stronger intensity-band sampling gate are opt-in through positive PsfEnergyFraction; manual defaults remain as before.
