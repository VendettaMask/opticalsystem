$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$taskFixture=Join-Path $taskRepo 'tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-sampling-boundary-zemax-2026-r1.zip'
$taskZip=[IO.Compression.ZipFile]::OpenRead($taskFixture)
function Read-BoundaryEntry([string]$taskName) {
    $taskReader=[IO.StreamReader]::new($taskZip.GetEntry($taskName).Open())
    try {return $taskReader.ReadToEnd() | ConvertFrom-Json -NoEnumerate} finally {$taskReader.Dispose()}
}
try {
    $taskManifest=Read-BoundaryEntry 'manifest.json'
    $taskRows=@()
    foreach($taskCase in $taskManifest.Cases) {
        $taskDir=Join-Path $taskRepo $taskCase.Capture
        $taskCfg=[IO.File]::ReadAllBytes((Join-Path $taskDir readback.CFG))
        $taskType=if($taskCase.Method -eq 'FourierModes'){7}else{6}
        $taskGamma=if($taskCase.Function -eq 'Sinc'){1}else{0}
        foreach($taskPair in @(@(0,2000),@(4,422),@(32,([int][Math]::Log2($taskCase.Sampling)-5)),@(36,0),@(40,1),@(44,4),@(48,$taskType),@(52,1),@(56,$taskCase.Wave),@(584,0),@(588,0),@(792,$taskGamma))) {
            if([BitConverter]::ToInt32($taskCfg,$taskPair[0]) -ne $taskPair[1]) {throw 'Boundary integer setting mismatch'}
        }
        foreach($taskPair in @(@(24,$taskCase.FileSize),@(800,$taskCase.Fraction),@(808,$taskCase.Alpha))) {
            if([BitConverter]::ToDouble($taskCfg,$taskPair[0]) -ne $taskPair[1]) {throw 'Boundary floating setting mismatch'}
        }
        $taskFile=[Text.Encoding]::Unicode.GetString($taskCfg,60,520).Split([char]0)[0]
        if((Get-FileHash -LiteralPath $taskFile).Hash.ToLowerInvariant() -ne $taskCase.SourceSha256) {throw 'Boundary source changed'}
        $taskData=Get-Content (Join-Path $taskDir data.json) -Raw | ConvertFrom-Json
        if((Get-FileHash (Join-Path $taskDir data.json)).Hash.ToLowerInvariant() -ne $taskCase.NativeSha256) {throw 'Boundary data changed'}
        if($taskCase.Available) {
            if(-not $taskData.TextSaved -or $taskData.Messages.Count -ne 0 -or $taskData.Grids.Count -ne 1 -or $taskData.Grids[0].Nx -ne 128 -or $taskData.Grids[0].Ny -ne 128) {throw 'Invalid available boundary result'}
            $taskValues=Read-BoundaryEntry $taskCase.Entry
            for($taskY=0;$taskY -lt 128;$taskY++) {for($taskX=0;$taskX -lt 128;$taskX++) {
                $taskValue=$taskData.Grids[0].Values[$taskY][$taskX]
                if(-not [double]::IsFinite($taskValue) -or $taskValue -lt 0 -or $taskValue -ne $taskValues[$taskY][$taskX]) {throw 'Boundary array differs from raw native values'}
            }}
        } else {
            if($taskData.Messages.Count -ne 1 -or $taskData.Messages[0].Text -notmatch '取样太低' -or $taskData.Grids[0].Nx -ne 0) {throw 'Unexpected unavailable boundary result'}
        }
        $taskDest=Join-Path (Join-Path $PSScriptRoot 'boundary-native-captures') $taskCase.Name
        New-Item -ItemType Directory -Path $taskDest -Force | Out-Null
        foreach($taskName in @('data.json','data.txt','request.json','requested.CFG','readback.CFG')) {Copy-Item -LiteralPath (Join-Path $taskDir $taskName) -Destination (Join-Path $taskDest $taskName)}
        Copy-Item -LiteralPath $taskFile -Destination (Join-Path $taskDest source.IMA)
        $taskRows+=@{name=$taskCase.Name;available=$taskCase.Available;wave=$taskCase.Wave;sampling=$taskCase.Sampling;pitch=$taskCase.FileSize/$taskCase.SourceSize;nativeSha256=$taskCase.NativeSha256;cfgSha256=(Get-FileHash (Join-Path $taskDir readback.CFG)).Hash.ToLowerInvariant();sourceSha256=$taskCase.SourceSha256;message=$taskCase.NativeMessages}
    }
} finally {$taskZip.Dispose()}
$taskResult=@{caseCount=$taskRows.Count;availableCount=@($taskRows | Where-Object available).Count;unavailableCount=@($taskRows | Where-Object {-not $_.available}).Count;allSettingsReadBack=$true;allAvailableValuesMatchRawNative=$true;fixtureSha256=(Get-FileHash $taskFixture).Hash.ToLowerInvariant();cases=$taskRows}
if($taskResult.caseCount -ne 55 -or $taskResult.availableCount -ne 12 -or $taskResult.unavailableCount -ne 43) {throw 'Boundary counts changed'}
$taskResult | ConvertTo-Json -Depth 15 | Set-Content (Join-Path $PSScriptRoot 'sampling-boundary-manifest.json')
'Verified 55 native boundary controls: 12 complete images and 43 unavailable results'
