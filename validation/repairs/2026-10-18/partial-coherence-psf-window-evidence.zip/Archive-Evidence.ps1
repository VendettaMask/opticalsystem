$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$taskStage=Join-Path $PSScriptRoot 'archive-input'
if(Test-Path -LiteralPath $taskStage) {throw 'Evidence staging already exists; use a fresh staging directory'}
New-Item -ItemType Directory -Path $taskStage | Out-Null
function Copy-Evidence([string]$taskSource,[string]$taskRelative) {
    $taskDest=Join-Path $taskStage $taskRelative
    New-Item -ItemType Directory -Path (Split-Path -Parent $taskDest) -Force | Out-Null
    Copy-Item -LiteralPath $taskSource -Destination $taskDest
}
foreach($taskFile in Get-ChildItem -LiteralPath $PSScriptRoot -File) {
    if($taskFile.Extension -ne '.exe') {Copy-Evidence $taskFile.FullName $taskFile.Name}
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'accepted-native-captures') -Destination $taskStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'source') -Destination $taskStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'final') -Destination $taskStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'tests') -Destination $taskStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'boundary-native-captures') -Destination $taskStage -Recurse
foreach($taskGroup in @('single-v1','holdout-v1','sampling-v1','sampling-fine-v1','sampling-tight-v1')) {
    foreach($taskName in @('environment.json','analysis-settings.json','native-model.json','reset.CFG')) {Copy-Evidence (Join-Path $PSScriptRoot "$taskGroup/$taskName") "capture-runtime/$taskGroup/$taskName"}
}
foreach($taskProject in @('probe','before-probe','boundary-probe')) {foreach($taskName in @('Program.cs','Probe.csproj')) {Copy-Evidence (Join-Path $PSScriptRoot "$taskProject/$taskName") "$taskProject/$taskName"}} 
foreach($taskPath in Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')) {Copy-Evidence (Join-Path $taskRepo $taskPath) "product-source/$taskPath"}
foreach($taskPath in @('docs/PARTIAL_COHERENCE_PSF_WINDOW_REPAIR_2026-10-18.md','docs/CURRENT_STATUS.md','docs/NUMERICAL_PARITY.md','docs/OPEN_ISSUES_2026-10-08.md','tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj','tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-psf-window-zemax-2026-r1.zip','tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-sampling-boundary-zemax-2026-r1.zip')) {Copy-Evidence (Join-Path $taskRepo $taskPath) "product-source/$taskPath"}
Copy-Evidence (Join-Path $PSScriptRoot 'Core.before.dll') 'before-probe/reference/OpticalSystemDesign.Core.dll'
$taskManifest=@(Get-ChildItem -LiteralPath $taskStage -File -Recurse | ForEach-Object {@{path=[IO.Path]::GetRelativePath($taskStage,$_.FullName).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}} | Sort-Object path)
$taskManifest | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $taskStage 'files-manifest.json')
$taskZipPath=Join-Path $taskRepo 'validation/repairs/2026-10-18/partial-coherence-psf-window-evidence.zip'
if(Test-Path -LiteralPath $taskZipPath) {throw 'Final evidence already exists; never overwrite frozen evidence'}
[IO.Compression.ZipFile]::CreateFromDirectory($taskStage,$taskZipPath,[IO.Compression.CompressionLevel]::Optimal,$false)
$taskZip=[IO.Compression.ZipFile]::OpenRead($taskZipPath)
try {
    foreach($taskFile in $taskManifest) {
        $taskEntry=$taskZip.GetEntry($taskFile.path)
        if($null -eq $taskEntry -or $taskEntry.Length -ne $taskFile.bytes) {throw 'Evidence entry incomplete'}
        $taskStream=$taskEntry.Open()
        try {$taskSha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($taskStream)).ToLowerInvariant()} finally {$taskStream.Dispose()}
        if($taskSha -ne $taskFile.sha256) {throw 'Evidence entry hash differs'}
    }
    $taskResult=@{path='validation/repairs/2026-10-18/partial-coherence-psf-window-evidence.zip';sha256=(Get-FileHash -LiteralPath $taskZipPath).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $taskZipPath).Length;entries=$taskZip.Entries.Count;allEntryHashesVerified=$true}
} finally {$taskZip.Dispose()}
$taskResult | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'archive-result.json')
$taskResult | ConvertTo-Json


