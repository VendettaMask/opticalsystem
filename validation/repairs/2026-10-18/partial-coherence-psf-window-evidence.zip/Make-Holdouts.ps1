$ErrorActionPreference='Stop'
$taskFile=Join-Path $PSScriptRoot 'source/three64.IMA'
$taskLines=@('64')
for($taskY=0;$taskY -lt 64;$taskY++) {
    $taskRow=('0'*64).ToCharArray()
    if($taskY -eq 32) {$taskRow[31]='9';$taskRow[32]='3'}
    if($taskY -eq 27) {$taskRow[29]='1'}
    $taskLines+= -join $taskRow
}
$taskLines | Set-Content -Encoding ascii $taskFile
$taskReq=@()
foreach($taskFraction in @(.91,.94,.96,.975)) { foreach($taskMode in @(6,7)) {foreach($taskGamma in @(0,1)) {foreach($taskSetup in @(@(2,1),@(3,3))) {
    $taskReq+=@{name="spectral-f$taskFraction-m$taskMode-g$taskGamma-s$($taskSetup[0])-w$($taskSetup[1])";file=$taskFile;fileSize=.032;wave=$taskSetup[1];changes=@(@{offset=48;integer=$taskMode},@{offset=792;integer=$taskGamma},@{offset=808;number=.001},@{offset=800;number=$taskFraction},@{offset=32;integer=$taskSetup[0]})}
} } } }
foreach($taskSize in @(.016,.064)) {foreach($taskFraction in @(.9,.98)) {foreach($taskMode in @(6,7)) {foreach($taskGamma in @(0,1)) {
    $taskReq+=@{name="pitch-size$taskSize-f$taskFraction-m$taskMode-g$taskGamma";file=$taskFile;fileSize=$taskSize;changes=@(@{offset=48;integer=$taskMode},@{offset=792;integer=$taskGamma},@{offset=808;number=.001},@{offset=800;number=$taskFraction},@{offset=32;integer=3})}
} } } }
$taskReq | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $PSScriptRoot 'holdout-requests.json')
& (Join-Path $PSScriptRoot 'Run-Cases.ps1') -Requests (Join-Path $PSScriptRoot 'holdout-requests.json') -OutputName holdout-v1
exit $LASTEXITCODE
