$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$taskFixture=Join-Path $taskRepo 'tests/OpticalSystemDesign.Tests/Fixtures/partial-coherence-psf-window-zemax-2026-r1.zip'
function Read-Entry($taskZip,[string]$taskName) {
    $taskReader=[IO.StreamReader]::new($taskZip.GetEntry($taskName).Open())
    try {return $taskReader.ReadToEnd() | ConvertFrom-Json -NoEnumerate} finally {$taskReader.Dispose()}
}
function Check-Settings([byte[]]$taskCfg,$taskExpected,[int]$taskType) {
    $taskGamma=if($taskExpected.Function -eq 'Sinc'){1}else{0}
    $taskSampling=[int][Math]::Log2($taskExpected.Sampling)-5
    foreach($taskPair in @(@(0,2000),@(4,422),@(32,$taskSampling),@(36,0),@(40,1),@(44,4),@(48,$taskType),@(52,1),@(56,$taskExpected.Wave),@(584,0),@(588,0),@(792,$taskGamma))) {
        if([BitConverter]::ToInt32($taskCfg,$taskPair[0]) -ne $taskPair[1]) {throw 'Native integer setting mismatch'}
    }
    foreach($taskPair in @(@(24,$taskExpected.FileSize),@(800,$taskExpected.Fraction),@(808,$taskExpected.Alpha))) {
        if([BitConverter]::ToDouble($taskCfg,$taskPair[0]) -ne $taskPair[1]) {throw 'Native floating setting mismatch'}
    }
}
function Preserve-Capture([string]$taskDir,[string]$taskName,[string]$taskSource) {
    $taskDest=Join-Path (Join-Path $PSScriptRoot 'accepted-native-captures') $taskName
    New-Item -ItemType Directory -Path $taskDest -Force | Out-Null
    foreach($taskFile in @('data.json','data.txt','request.json','requested.CFG','readback.CFG')) {Copy-Item -LiteralPath (Join-Path $taskDir $taskFile) -Destination (Join-Path $taskDest $taskFile)}
    if($taskSource) {Copy-Item -LiteralPath $taskSource -Destination (Join-Path $taskDest 'source.IMA')}
}
$taskZip=[IO.Compression.ZipFile]::OpenRead($taskFixture)
try {
    $taskManifest=Read-Entry $taskZip 'manifest.json'
    $taskRecords=@()
    foreach($taskCase in $taskManifest.Cases) {
        $taskDir=Join-Path $taskRepo $taskCase.Capture
        $taskCfg=[IO.File]::ReadAllBytes((Join-Path $taskDir 'readback.CFG'))
        $taskType=if($taskCase.Method -eq 'FourierModes'){7}else{6}
        Check-Settings $taskCfg $taskCase $taskType
        $taskRequest=Get-Content (Join-Path $taskDir 'request.json') -Raw | ConvertFrom-Json
        $taskFile=[Text.Encoding]::Unicode.GetString($taskCfg,60,520).Split([char]0)[0]
        if($taskFile -cne $taskRequest.file -or (Get-FileHash -LiteralPath $taskFile).Hash.ToLowerInvariant() -ne $taskCase.SourceSha256) {throw 'Native source changed'}
        $taskLines=Get-Content -LiteralPath $taskFile
        $taskSourceSize=[int]$taskLines[0]
        if($taskSourceSize -ne $taskCase.SourceSize) {throw 'Source dimension changed'}
        $taskActualPoints=@()
        for($taskY=0;$taskY -lt $taskSourceSize;$taskY++) {for($taskX=0;$taskX -lt $taskSourceSize;$taskX++) {
            $taskI=([int][char]$taskLines[$taskY+1][$taskX]-[int][char]'0')/9.0
            if($taskI -gt 0) {$taskActualPoints+=@{Y=$taskY;X=$taskX;Intensity=$taskI}}
        }}
        if($taskActualPoints.Count -ne $taskCase.Points.Count) {throw 'Source active points changed'}
        for($taskI=0;$taskI -lt $taskActualPoints.Count;$taskI++) {foreach($taskKey in @('Y','X','Intensity')) {if($taskActualPoints[$taskI][$taskKey] -ne $taskCase.Points[$taskI].$taskKey) {throw 'Source point differs from native IMA'}}}
        $taskData=Get-Content (Join-Path $taskDir 'data.json') -Raw | ConvertFrom-Json
        $taskFixtureData=Read-Entry $taskZip $taskCase.Entry
        $taskGrid=$taskData.Grids[0]
        $taskN=$taskSourceSize+2*$taskCase.Padding
        if(-not $taskData.TextSaved -or $taskData.Grids.Count -ne 1 -or $taskData.Messages.Count -ne 0 -or $taskGrid.Nx -ne $taskN -or $taskGrid.Ny -ne $taskN) {throw 'Incomplete native image result'}
        if($taskGrid.Dx -ne $taskCase.FileSize/$taskSourceSize -or $taskGrid.Dy -ne $taskGrid.Dx) {throw 'Native physical pitch differs'}
        for($taskY=0;$taskY -lt $taskN;$taskY++) {
            if($taskGrid.Values[$taskY].Count -ne $taskN) {throw 'Missing native columns'}
            for($taskX=0;$taskX -lt $taskN;$taskX++) {
                $taskValue=$taskGrid.Values[$taskY][$taskX]
                if(-not [double]::IsFinite($taskValue) -or $taskValue -lt 0 -or $taskValue -ne $taskFixtureData.Values[$taskY][$taskX]) {throw 'Image fixture differs from raw native values'}
            }
        }
        $taskSha=(Get-FileHash (Join-Path $taskDir 'data.json')).Hash.ToLowerInvariant()
        if($taskSha -ne $taskCase.NativeSha256) {throw 'Native image hash changed'}
        Preserve-Capture $taskDir $taskCase.Name $taskFile
        $taskRecords+=@{name=$taskCase.Name;nativeType=$taskType;fraction=$taskCase.Fraction;wave=$taskCase.Wave;wavelength=$taskCase.Wavelength;otfSampling=$taskCase.Sampling;sourceSize=$taskSourceSize;grid=$taskN;physicalPitch=$taskGrid.Dx;nativeSha256=$taskSha;cfgSha256=(Get-FileHash (Join-Path $taskDir 'readback.CFG')).Hash.ToLowerInvariant();sourceSha256=$taskCase.SourceSha256;coherenceSamplingPolicy='Automatic from actual even PSF width; inferred native implementation, not a typed native setting'}
    }
    $taskPsfRecords=@()
    foreach($taskPsf in $taskManifest.Psfs) {
        $taskDir=Join-Path $taskRepo $taskPsf.Capture
        $taskCfg=[IO.File]::ReadAllBytes((Join-Path $taskDir 'readback.CFG'))
        Check-Settings $taskCfg @{Function='Gaussian';Sampling=$taskPsf.Sampling;Wave=2;FileSize=.032;Fraction=.98;Alpha=.001} 8
        $taskData=Get-Content (Join-Path $taskDir 'data.json') -Raw | ConvertFrom-Json
        $taskValues=Read-Entry $taskZip $taskPsf.Entry
        if(-not $taskData.TextSaved -or $taskData.Grids.Count -ne 1 -or $taskData.Messages.Count -ne 0 -or $taskData.Grids[0].Nx -ne $taskPsf.Sampling) {throw 'Incomplete full PSF result'}
        for($taskY=0;$taskY -lt $taskPsf.Sampling;$taskY++) {for($taskX=0;$taskX -lt $taskPsf.Sampling;$taskX++) {if($taskData.Grids[0].Values[$taskY][$taskX] -ne $taskValues[$taskY][$taskX]) {throw 'Full PSF fixture differs'}}}
        if((Get-FileHash (Join-Path $taskDir 'data.json')).Hash.ToLowerInvariant() -ne $taskPsf.NativeSha256) {throw 'Native full PSF hash changed'}
        Preserve-Capture $taskDir "psfs/$($taskPsf.Sampling)" ''
        $taskPsfRecords+=@{sampling=$taskPsf.Sampling;nativeSha256=$taskPsf.NativeSha256;axisMapping='native[(2*N-2-y)%N,x]'}
    }
} finally {$taskZip.Dispose()}
$taskRejected=@()
foreach($taskDir in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'holdout-v1') -Directory | Where-Object Name -Like 'pitch-size0.064*') {
    $taskData=Get-Content (Join-Path $taskDir.FullName 'data.json') -Raw | ConvertFrom-Json
    if($taskData.Messages.Count -ne 1 -or $taskData.Grids[0].Nx -ne 0 -or $taskData.Messages[0].Text -notmatch '取样太低') {throw 'Unexpected native undersampling result'}
    $taskRejected+=@{name=$taskDir.Name;nativeMessage=$taskData.Messages[0].Text;nativeErrorCode=$taskData.Messages[0].ErrorCode;result='Unavailable, excluded from numerical pass count'}
}
if($taskRecords.Count -ne 96 -or $taskPsfRecords.Count -ne 2 -or $taskRejected.Count -ne 8) {throw 'Unexpected capture counts'}
if((Get-FileHash (Join-Path $PSScriptRoot 'source/123456.ZMX')).Hash.ToLowerInvariant() -ne $taskManifest.LensSha256) {throw 'Lens changed'}
$taskResult=@{native='OpticStudio 2026 R1 build 260127 Enterprise';imageCaseCount=96;fullPsfCaseCount=2;nativeRejectedCount=8;allEffectiveSettingsReadBack=$true;allValuesIdenticalToNative=$true;allPhysicalPitchesVerified=$true;fixtureSha256=(Get-FileHash $taskFixture).Hash.ToLowerInvariant();sourceSha256=$taskManifest.LensSha256;images=$taskRecords;psfs=$taskPsfRecords;rejected=$taskRejected}
$taskResult | ConvertTo-Json -Depth 15 | Set-Content (Join-Path $PSScriptRoot 'capture-manifest.json')
'Verified 96 complete native images, 2 complete PSFs, and 8 excluded native undersampling results'
