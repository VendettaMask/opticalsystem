$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$prior=Join-Path $repo 'artifacts/validation/numerical-residuals-20261018'
$target=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/multi-lens-dee-zemax-2026-r1.zip'
if(Test-Path $target){throw 'Fixture already exists'}
$zip=[IO.Compression.ZipFile]::Open($target,[IO.Compression.ZipArchiveMode]::Create)
$entries=@();$cases=@()
function Add-File([string]$path,[string]$entry){
    [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$path,$entry,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    $script:entries+=@{path=$entry;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $path).Length}
}
try {
 foreach($list in @('native-jobs-v2.json','holdout-jobs.json','old-ms-l7-jobs.json','native-jobs-v3.json',(Join-Path $PSScriptRoot 'native-jobs.json'))){
  $listPath=if([IO.Path]::IsPathRooted($list)){$list}else{Join-Path $prior $list}
  foreach($job in @(Get-Content $listPath -Raw|ConvertFrom-Json)){
   if($list -eq 'native-jobs-v2.json' -and $job.id -like 'slit-*'){continue}
   $r=Get-Content $job.request -Raw|ConvertFrom-Json
   $model=Get-Content (Join-Path $job.output 'model.json') -Raw|ConvertFrom-Json
   $id=$job.id
   $group=if($id -like '*-c1-primary-*'){'Original'}elseif($id -like '*-n64-w*'){'Spectral'}elseif($id -like '*-all-waves' -and $id.Substring(0,4) -in @('0014','0308','0472','0852')){'Polychromatic'}elseif($id -like 'slit-*'){'Slit'}elseif($id -like 'ms-l7-*'){'Legacy'}else{'Holdout'}
   $primary=($model.wavelengths|Where-Object {$_.data.IsPrimary}|Select-Object -First 1).number
   $cases+=@{id=$id;group=$group;pupilSampling=$r.pupilSampling;wavelength=$r.wavelength;primaryWavelength=$primary;maximum=$r.zemaxSettings.RadiusMaximum;aiming=$model.rayAiming.RayAiming -ne 'Off';type=if($group -eq 'Slit'){'X'}else{'encircled'}}
   Add-File $r.input "$id/source.zmx"
   Add-File $job.request "$id/request.json"
   foreach($name in @('data.json','data.txt','model.json','environment.json','captured-settings.json','settings.CFG','batch-result.json')){Add-File (Join-Path $job.output $name) "$id/$name"}
  }
 }
 $inverse=Get-ChildItem (Join-Path $PSScriptRoot 'apertures') -Directory|Where-Object Name -like '*0412*'
 Add-File (Join-Path $inverse.FullName 'apertures.json') 'aperture/original-apertures.json'
 Add-File (Join-Path $inverse.FullName 'ray-audit.json') 'aperture/original-rays.json'
 Add-File (Join-Path $PSScriptRoot 'floating-stop-native/explicit-floating-stop.zmx') 'aperture/explicit-floating-stop.zmx'
 Add-File (Join-Path $PSScriptRoot 'floating-stop-native/ray-audit.json') 'aperture/explicit-floating-rays.json'
 $manifest=@{date='2026-10-18';nativeVersion='OpticStudio 2026 R1 build 260127';cases=$cases;entries=$entries;scope='All 48 captures retained; automated optical cases select Original, nonprimary Spectral, four Polychromatic, and Slit. Holdout failures are explicitly retained in the repair ledger.'}
 $e=$zip.CreateEntry('manifest.json');$writer=[IO.StreamWriter]::new($e.Open());try{$writer.Write(($manifest|ConvertTo-Json -Depth 15))}finally{$writer.Dispose()}
} finally {$zip.Dispose()}
$manifest|ConvertTo-Json -Depth 15|Set-Content (Join-Path $PSScriptRoot 'fixture-manifest.json')
Get-FileHash -LiteralPath $target
