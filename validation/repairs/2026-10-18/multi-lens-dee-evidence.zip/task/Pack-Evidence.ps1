$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$target=Join-Path $repo 'validation/repairs/2026-10-18/multi-lens-dee-evidence.zip'
if(Test-Path -LiteralPath $target){throw 'Evidence already frozen; use a new name'}
$proof=Get-Content (Join-Path $PSScriptRoot 'proof.json') -Raw|ConvertFrom-Json
$entries=[Collections.Generic.List[object]]::new()
$names=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$archive=[IO.Compression.ZipFile]::Open($target,[IO.Compression.ZipArchiveMode]::Create)
function Add-Evidence([string]$path,[string]$name){
 if(-not $names.Add($name)){throw "Duplicate entry: $name"}
 [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$path,$name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
 $entries.Add(@{path=$name;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $path).Length})
}
try{
 foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -File -Recurse|Sort-Object FullName){
  $name=[IO.Path]::GetRelativePath($PSScriptRoot,$file.FullName).Replace('\','/')
  if($name -match '(^|/)(bin|obj)/' -or $name -eq 'archive-result.json' -or $name -eq 'archive-validation.log'){continue}
  if($name.StartsWith('formal-v3/') -and $name -ne 'formal-v3/summary.json'){continue}
  if($name.StartsWith('formal-v2/') -and -not $name.StartsWith('formal-v2/0360-n128/') -and $name -ne 'formal-v2/summary.json'){continue}
  if($name.StartsWith('formal/') -and -not $name.StartsWith('formal/slit-0014/')){continue}
  Add-Evidence $file.FullName ('task/'+$name)
 }
 foreach($source in $proof.sourceFiles){Add-Evidence (Join-Path $repo $source.path) ('source/'+$source.path)}
 Add-Evidence (Join-Path $repo 'tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj') 'source/tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj'
 Add-Evidence (Join-Path $repo $proof.fixture.path) 'fixture/multi-lens-dee-zemax-2026-r1.zip'
 $manifest=@{date='2026-10-18';scope=$proof.scope;allResidualsClosed=$false;entries=$entries.ToArray()}
 $entry=$archive.CreateEntry('manifest.json')
 $writer=[IO.StreamWriter]::new($entry.Open());try{$writer.Write(($manifest|ConvertTo-Json -Depth 12))}finally{$writer.Dispose()}
}finally{$archive.Dispose()}
$read=[IO.Compression.ZipFile]::OpenRead($target)
try{
 if($read.Entries.Count -ne $entries.Count+1){throw 'Archive entry count differs'}
 foreach($expected in $entries){
  $stream=$read.GetEntry($expected.path).Open()
  try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
  if($hash -ne $expected.sha256){throw "Archive readback failed: $($expected.path)"}
 }
}finally{$read.Dispose()}
$result=@{path='validation/repairs/2026-10-18/multi-lens-dee-evidence.zip';sha256=(Get-FileHash -LiteralPath $target).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $target).Length;payloads=$entries.Count;entries=$entries.Count+1;allPayloadHashesVerified=$true}
$result|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'archive-result.json') -Encoding utf8NoBOM
$ledgerPath=Join-Path $repo 'docs/validation/MULTI_LENS_ENCIRCLED_ENERGY_REPAIR_2026-10-18.json'
$ledger=Get-Content $ledgerPath -Raw|ConvertFrom-Json
$ledger|Add-Member -NotePropertyName archive -NotePropertyValue $result
$ledger|ConvertTo-Json -Depth 45|Set-Content $ledgerPath -Encoding utf8NoBOM
$result
