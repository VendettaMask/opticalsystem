$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read-Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot "tests/$name") -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$prior=Get-Content (Join-Path $repo 'docs/validation/COHERENCE_NUMERICAL_STABILITY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$beforeCore=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeCore -ne 'c253468b245daf8becbf469740f9856dc3e2e23671a36929f878573dbc150372'){throw 'Before Core changed'}
$unchangedTests=@()
foreach($source in $prior.sourceFiles|Where-Object {$_.path -like 'tests/*.cs'}){
 if((Hash (Join-Path $repo $source.path)) -ne $source.sha256){throw "Existing test source changed: $($source.path)"}
 $unchangedTests+=$source
}
$release=Read-Tests 'related-release-final-v2.trx';$debug=Read-Tests 'related-debug-final-v2.trx'
foreach($run in @($release,$debug)){
 if($run.total -ne $run.passed -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Related verification incomplete'}
 if(@($run.names|Where-Object {$_ -match '\.MultiLensEncircledEnergyTests\.'}).Count -ne 66){throw 'Expected 66 new cases'}
 if(@($run.names|Where-Object {$_ -match '\.ZemaxImportTests\.'}).Count -ne 65){throw 'Expected 65 import cases'}
}
if($release.total -ne 861 -or $debug.total -ne 148){throw 'Final verification scope differs'}
foreach($name in $prior.verification.testRelease.names){if($name -cnotin $release.names){throw "Original regression missing: $name"}}
foreach($name in $debug.names){if($name -cnotin $release.names){throw 'Focused Debug identity absent from Release'}}
if(@($debug.names|Where-Object {$_ -match '\.FftCumulativeEnergyTests\.'}).Count -ne 17){throw 'Debug original energy tests missing'}
$comparisonRelease=Read-Tests 'comparison-release-final-v2.trx';$comparisonDebug=Read-Tests 'comparison-debug-final-v2.trx'
foreach($run in @($comparisonRelease,$comparisonDebug)){if($run.total -ne 5 -or $run.passed -ne 5 -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Comparison regression incomplete'}}
$beforeTests=Read-Tests 'multi-lens-before-final-v2.trx'
if($beforeTests.total -ne 66 -or $beforeTests.failed -ne 40 -or $beforeTests.passed -ne 26){throw 'Before counterexamples incomplete'}
$configurations=foreach($config in @('Release','Debug')){
 $log=Get-Content (Join-Path $PSScriptRoot "build-$($config.ToLowerInvariant())-final-v3.log") -Raw
 if(@($log -split "`n"|Where-Object {$_ -match ' -> '}).Count -ne 19 -or -not $log.Contains('0 个警告') -or -not $log.Contains('0 个错误')){throw 'Default solution build incomplete'}
 $paths=@("src/OpticalSystemDesign.Core/bin/$config/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$config/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$config/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$config/net10.0/OpticalSystemDesign.Core.dll","tools/OpticalSystemDesign.ZemaxComparison/bin/$config/net10.0/OpticalSystemDesign.Core.dll")
 $copies=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
 if(@($copies.sha256|Sort-Object -Unique).Count -ne 1){throw 'Default Core copies differ'}
 @{configuration=$config;projects=19;warnings=0;errors=0;coreCopies=$copies}
}
$before=Get-Content (Join-Path $PSScriptRoot 'formal-before/summary.json') -Raw|ConvertFrom-Json
$after=Get-Content (Join-Path $PSScriptRoot 'formal-v4/summary.json') -Raw|ConvertFrom-Json
if($before.coreSha256 -ne $beforeCore -or $after.coreSha256 -ne $configurations[0].coreCopies[0].sha256){throw 'Formal comparison Core identity differs'}
if($before.policySha256 -ne $after.policySha256 -or $after.policySha256 -ne (Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'))){throw 'Tolerance policy changed'}
if($after.rows.Count -ne 48 -or @($after.rows|Where-Object conclusion -eq 'Pass').Count -ne 43 -or @($after.rows|Where-Object conclusion -eq 'Close').Count -ne 5){throw 'Unexpected final numerical conclusions'}
$previousPass=@($before.rows|Where-Object conclusion -eq 'Pass')
if($previousPass.Count -ne 22){throw 'Unexpected before pass count'}
foreach($row in $previousPass){if(($after.rows|Where-Object id -eq $row.id).conclusion -ne 'Pass'){throw "Prior numerical Pass regressed: $($row.id)"}}
foreach($row in $after.rows){$old=$before.rows|Where-Object id -eq $row.id;if($row.sourceSha256 -ne $old.sourceSha256 -or $row.executedRequestSha256 -ne $old.executedRequestSha256 -or $row.nativeDataSha256 -ne $old.nativeDataSha256){throw 'Formal reference/request bytes changed'}}
$original=@($after.rows|Where-Object id -like '*-c1-primary-*')
if($original.Count -ne 7 -or @($original|Where-Object conclusion -ne 'Pass').Count -ne 0){throw 'Original seven cases not closed'}
$preserved=@{}
foreach($p in $prior.preservedArchives.PSObject.Properties){$preserved[$p.Name]=$p.Value}
$preserved['validation/repairs/2026-10-18/coherence-numerical-stability-evidence.zip']='c0c5e507689e6d8acccd869a2d77c56a622e5b61ba3f15cc31825b00ac4b5b98'
foreach($p in $preserved.Keys){if((Hash (Join-Path $repo $p)) -ne $preserved[$p]){throw "Frozen archive changed: $p"}}
$nativeFixtures=@{}
foreach($p in $prior.preservedNativeFixtures.PSObject.Properties){
 $path=Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$p.Name)
 if((Hash $path) -ne $p.Value){throw "Frozen native fixture changed: $($p.Name)"}
 $nativeFixtures[$p.Name]=$p.Value
}
$fixture=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/multi-lens-dee-zemax-2026-r1.zip'
$fixtureSha=Hash $fixture
if($fixtureSha -ne 'bf561676bdda9655a719c2cd2604c591e9f9cfab1bd4e3b15f43d97f0f5f4677'){throw 'New native fixture changed'}
$zip=[IO.Compression.ZipFile]::OpenRead($fixture)
try{
 $reader=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open());try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
 if($manifest.cases.Count -ne 48){throw 'Fixture cases incomplete'}
 foreach($record in $manifest.entries){$stream=$zip.GetEntry($record.path).Open();try{$actual=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($actual -ne $record.sha256){throw 'Fixture entry changed'}}
}finally{$zip.Dispose()}
$captures=@()
foreach($list in @('native-jobs.json','ray-native/native-jobs-v2.json','fft-controls/native-jobs.json','boundary-native/native-jobs.json','aperture-jobs.json','perturbed/native-jobs.json','floating-stop-jobs.json')){
 foreach($job in @(Get-Content (Join-Path $PSScriptRoot $list) -Raw|ConvertFrom-Json)){
  $result=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json
  $nativeEnvironment=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
  if($result.exitCode -ne 0 -or $nativeEnvironment.major -ne 26 -or $nativeEnvironment.minor -ne 1 -or $nativeEnvironment.opticStudioVersion -ne 260127 -or -not $nativeEnvironment.validLicense){throw 'Native capture identity invalid'}
  if($list -in @('native-jobs.json','perturbed/native-jobs.json')){
   $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
   if($data.dataSeries.Count -ne 2){throw 'Native energy curves unavailable'}
   foreach($series in $data.dataSeries){
    if($series.x.Count -ne 401 -or $series.y.Count -ne 401){throw 'Native energy sampling differs'}
    foreach($row in $series.y){if($row.Count -ne 1 -or -not [double]::IsFinite($row[0]) -or $row[0] -lt 0 -or $row[0] -gt 1){throw 'Native energy data invalid'}}
   }
  }elseif($list -eq 'fft-controls/native-jobs.json'){
   $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
   if($data.dataGrids.Count -ne 1 -or $data.dataGrids[0].nx -ne 128 -or $data.dataGrids[0].ny -ne 128){throw 'Native FFT grid unavailable'}
   foreach($row in $data.dataGrids[0].values){if($row.Count -ne 128){throw 'Native FFT grid incomplete'};foreach($value in $row){if(-not [double]::IsFinite($value) -or $value -lt 0){throw 'Native FFT intensity invalid'}}}
  }else{
   $rays=Get-Content (Join-Path $job.output 'ray-audit.json') -Raw|ConvertFrom-Json
   if($rays.surfaces.Count -lt 1 -or $rays.inputs.Count -lt 4){throw 'Native ray audit incomplete'}
   foreach($surface in $rays.surfaces){if($surface.rays.Count -ne $rays.inputs.Count -or @($surface.rays|Where-Object error -ne 0).Count -ne 0){throw 'Native explicit ray propagation failed'}}
  }
  $request=Get-Content $job.request -Raw|ConvertFrom-Json
  $files=@(Get-ChildItem -LiteralPath $job.output -File|ForEach-Object {@{name=$_.Name;sha256=Hash $_.FullName;bytes=$_.Length}})
  $captures+=@{id=$job.id;group=$list;directory=[IO.Path]::GetRelativePath($PSScriptRoot,$job.output).Replace('\','/');requestSha256=Hash $job.request;sourceSha256=Hash $request.input;files=$files;nativeEnvironment=$nativeEnvironment}
 }
}
if($captures.Count -ne 58){throw 'Unexpected fresh native capture count'}
$sources=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log')
if($LASTEXITCODE -ne 0){throw 'Whitespace check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='Original seven DEE cases repaired; staged higher-sampling compatibility retained; three distinct extended controls remain open'
 allMultiLensResidualsClosed=$false
 constraints=@{originalTolerancesUnchanged=$true;original730TestNamesPreserved=$true;previous22FormalPassesPreserved=$true;independentCookeTessarExcluded=$true;unchangedPriorTestSources=$unchangedTests}
 beforeCoreSha256=$beforeCore;beforeTests=$beforeTests
 verification=@{testRelease=$release;testDebug=$debug;debugScope='Focused 66 new cases + 65 import cases + 17 original energy cases; no full Debug suite conclusion';comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;configurations=$configurations;newMainTests=66;additionalImportTests=65;newComparisonTests=4;originalRelatedTests=730;format=@{exitCode=0;includedCSharpFiles=$sources.Count;log='format-final-v3-verify.log'};gitDiffCheckExitCode=0}
 formalBefore=$before;formalAfter=$after
 remainingDistinctControls=@('0472-n64','0472-n128','0592-n64')
 retainedFailureRecords=@('formal-v2/0360-n128','product-v1','product-v2','ray-native/launch.log','aborted-fixture-v1.zip','cancelled-obsolete-debug-run.json','tests/related-debug-final.trx','aborted-evidence-v1.zip','archive-attempt-v1.log')
 preservedArchives=$preserved;preservedNativeFixtures=$nativeFixtures
 fixture=@{path='tests/OpticalSystemDesign.Tests/Fixtures/multi-lens-dee-zemax-2026-r1.zip';sha256=$fixtureSha;cases=48;entries=$manifest.entries.Count}
 nativeCaptures=$captures;sourceFiles=$sources
 boundaries=@{fullRepositorySuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false;generalNativeBoundaryConventionCertified=$false}
}
$proof|ConvertTo-Json -Depth 40|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 40|Set-Content (Join-Path $repo 'docs/validation/MULTI_LENS_ENCIRCLED_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified default builds, Release 861/861, focused Debug 148/148, comparison 5/5 per configuration, original 730 Release identities, 22 previous numerical passes, 48 comparisons, 58 native captures, 11 frozen archives and four prior fixtures.'
