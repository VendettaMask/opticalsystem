using System.Reflection;
using System.Numerics;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Domain;
var root=Path.GetFullPath(args[0]);
var old=Path.Combine(root,"artifacts/validation/numerical-residuals-20261018");
var fresh=Path.Combine(root,"artifacts/validation/dee-multi-lens-20261018");
var mode=args.Length>1?args[1]:"pitch";
var assembly=typeof(DiffractionEngine).Assembly;
var sampleType=assembly.GetType("OpticalSystemDesign.Core.Analysis.EnergySample")!;
var gridType=assembly.GetType("OpticalSystemDesign.Core.Analysis.FftCumulativeEnergyGrid")!;
var build=typeof(DiffractionEncircledEnergyAnalysis).GetMethod("BuildCurve",BindingFlags.Instance|BindingFlags.NonPublic)!;
var records=new List<object>();
if(mode=="nativefft")
{
 foreach(var code in new[]{"0014","0308","0472","0852"})
 {
  using var input=JsonDocument.Parse(File.ReadAllText(Path.Combine(fresh,"fft-controls",code+"-w0","data.json")));
  using var energy=JsonDocument.Parse(File.ReadAllText(Path.Combine(old,"holdout",code+"-all-waves","data.json")));
  var g=input.RootElement.GetProperty("dataGrids")[0];var size=g.GetProperty("nx").GetInt32();var pitch=g.GetProperty("dx").GetDouble();
  var optic=OpticalFormatCatalog.Import(File.ReadAllText(JsonDocument.Parse(File.ReadAllText(Path.Combine(old,"holdout",code+"-all-waves","request.json"))).RootElement.GetProperty("input").GetString()!),".zmx");
  var an=new DiffractionEncircledEnergyAnalysis(optic,size/2,size,401,0,1,maximumDistanceMicrometers:5);
  var single=optic.Wavelengths.Select((w,i)=>{
   using var s=JsonDocument.Parse(File.ReadAllText(Path.Combine(fresh,"fft-controls",code+"-w"+(i+1),"data.json")));
   var a=s.RootElement.GetProperty("dataGrids")[0].GetProperty("values").EnumerateArray().SelectMany(row=>row.EnumerateArray().Select(p=>p.GetDouble())).ToArray();
   var result=CustomPsf(optic,w,optic.Wavelengths.First(a=>a.IsPrimary),optic.Wavelengths.Max(a=>a.Micrometers),size/2,pitch,false,5);
   var raw=result.Values.Cast<double>().Sum();var count=raw/(size*size);
   var cv=Enumerable.Range(0,size).SelectMany(y=>Enumerable.Range(0,size).Select(x=>result.Values[(y+1)%size,(x+1)%size]/(count*count))).ToArray();
   var nativeCount=size*size/a.Sum();var errors=cv.Zip(a,(x,y)=>x-y).ToArray();
   Console.WriteLine($"PUPILFFT {code} w{i+1} native={nativeCount:R} core={count:R} coreMaxErr={errors.Max(Math.Abs):G6}");
   return (Wave:w,Values:a);
  }).ToArray();
  var nativePixels=g.GetProperty("values").EnumerateArray().SelectMany(row=>row.EnumerateArray().Select(p=>p.GetDouble())).ToArray();
  var nativeTotal=nativePixels.Sum();
  for(var option=0;option<7;option++){
   var mixture=Enumerable.Range(0,size*size).Select(p=>single.Sum(s=>s.Wave.Weight*s.Values[p]*(option==0?1:option==1?1/s.Values.Sum():Math.Pow(s.Wave.Micrometers,option-4)))).ToArray();
   var sum=mixture.Sum();var diff=mixture.Select((x,i)=>x/sum-nativePixels[i]/nativeTotal).ToArray();
   Console.WriteLine($"MIX {code} option={option} nrmse={Math.Sqrt(diff.Average(x=>x*x))/(nativePixels.Max()/nativeTotal):G6} max={diff.Max(Math.Abs):G6}");
  }
  for(var shift=-1;shift<=1;shift++)
  {
   var samples=Array.CreateInstance(sampleType,size*size);double total=0,cx=0,cy=0;
   for(var row=0;row<size;row++)for(var col=0;col<size;col++){
    var x=(col-size/2d+1)*pitch;var y=(row-size/2d+1)*pitch;var value=g.GetProperty("values")[(row+shift+size)%size][(col+shift+size)%size].GetDouble();
    samples.SetValue(Activator.CreateInstance(sampleType,x,y,value),row*size+col);total+=value;cx+=x*value;cy+=y*value;
   }
   var grid=Activator.CreateInstance(gridType,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance,null,new object[]{samples,(cx/total,cy/total),"encircled"},null)!;
   var points=(IReadOnlyList<AnalysisPoint>)build.Invoke(an,new object[]{grid,5d})!;
   var target=energy.RootElement.GetProperty("dataSeries")[1].GetProperty("y").EnumerateArray().Select(a=>a[0].GetDouble()).ToArray();
   var errors=points.Select((p,i)=>p.Y-target[i]).ToArray();var nr=Math.Sqrt(errors.Average(e=>e*e))/(target.Max()-target.Min());
   var rec=new{code,shift,pitch,total,cx=cx/total,cy=cy/total,nrmse=nr,maxAbs=errors.Max(Math.Abs)};records.Add(rec);Console.WriteLine(JsonSerializer.Serialize(rec));
  }
 }
 File.WriteAllText(Path.Combine(fresh,"nativefft.json"),JsonSerializer.Serialize(records));return;
}
foreach(var list in new[]{"native-jobs-v2.json","holdout-jobs.json","old-ms-l7-jobs.json",Path.Combine(fresh,"native-jobs.json")})
{
 using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(old,list)));
 foreach(var job in jobs.RootElement.EnumerateArray())
 {
  var id=job.GetProperty("id").GetString()!;if(id.StartsWith("slit-"))continue;
  if(args.Length>2 && !id.Contains(args[2]))continue;
  var folder=job.GetProperty("output").GetString()!;
  using var req=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=req.RootElement;
  using var native=JsonDocument.Parse(File.ReadAllText(Path.Combine(folder,"data.json")));
  using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(folder,"model.json")));
  var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");
  optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
  if(mode=="global")foreach(var surface in optic.SurfaceGroup.Items.Where(s=>s.IsStop&&s.Radius==0&&!s.IsReflective&&s.MaterialBefore.Name==s.MaterialAfter.Name))surface.PhysicalAperture=null;
  var n=r.GetProperty("pupilSampling").GetInt32();var size=2*n;var wn=r.GetProperty("wavelength").GetInt32();
  var waves=wn>0?new[]{optic.Wavelengths[wn-1]}:optic.Wavelengths.ToArray();
  var shortest=waves.MinBy(w=>w.Nanometers)!;var primary=waves.FirstOrDefault(w=>w.IsPrimary)??waves[0];
  var field=(Hx:0d,Hy:0d);var max=r.GetProperty("zemaxSettings").GetProperty("RadiusMaximum").GetDouble();
  var analysis=new DiffractionEncircledEnergyAnalysis(optic,n,size,401,wn,1,maximumDistanceMicrometers:max);
  if(mode=="boundary")
  {
   var points=new[]{(X:0d,Y:0d),(X:Math.Sqrt(.5),Y:Math.Sqrt(.5)),(X:1/Math.Sqrt(2),Y:1/Math.Sqrt(2)),(X:.7,Y:.7),(X:1d,Y:0d),(X:0d,Y:1d)};
   var diagnostics=points.Select(p=>{var ray=optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,p.X,p.Y,primary.Micrometers,optic.RayAimingEnabled).Rays[0];
    return new{p,ray,diagnostic=optic.SequentialRayTracer.DiagnoseApertures(ray)};}).ToArray();
   File.WriteAllText(Path.Combine(fresh,"boundary-core-"+id+".json"),JsonSerializer.Serialize(diagnostics));
   var inputs=points.Select((p,i)=>new{hx=0,hy=0,px=p.X,py=p.Y,fieldIndex=0,pupilIndex=i}).ToArray();
   var request=System.Text.Json.Nodes.JsonNode.Parse(r.GetRawText())!;request["adapter"]="ray-audit";request["removeVignettingFactors"]=false;request["surfaceRecordLimit"]=10000;
   request["rayAuditInputs"]=JsonSerializer.SerializeToNode(inputs);
   File.WriteAllText(Path.Combine(fresh,"boundary-request-"+id+".json"),request.ToJsonString());continue;
  }
  if(mode=="mask")
  {
   if(wn==0)continue;
   var w=waves[0];var ff=DiffractionEngine.WorkingFNumber(optic,field,w,optic.RayAimingEnabled);
   var primaryGlobal=optic.Wavelengths.FirstOrDefault(a=>a.IsPrimary)??optic.Wavelengths[0];
   var dirs=new[]{(0d,0d),(0d,1d),(0d,-1d),(1d,0d),(-1d,0d)}.Select(p=>{
    var rr=optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,p.Item1,p.Item2,primaryGlobal.Micrometers,optic.RayAimingEnabled).Rays[0];
    return optic.SequentialRayTracer.DiagnoseApertures(rr).UnclippedImage!.Direction;}).ToArray();
   var fp=DiffractionEngine.WorkingFNumber(optic,field,primaryGlobal,optic.RayAimingEnabled);
   var fStable=.5/Math.Sqrt(dirs.Skip(1).Select(d=>{var c=optic.Backend.Current.Cross(dirs[0],d);return c.Length*c.Length/(dirs[0].Length*dirs[0].Length*d.Length*d.Length);}).Average());
   var axes=DiffractionEngine.WorkingFNumbers(optic,field,primaryGlobal,optic.RayAimingEnabled);
   var average=DiffractionEngine.WorkingFNumbers(optic,field,primaryGlobal,optic.RayAimingEnabled,true);
   var stableAxes=DiffractionEngine.WorkingFNumbers(optic,field,primaryGlobal,optic.RayAimingEnabled,strictFullPupil:true);
   var stableCombined=1/Math.Sqrt(.5*(1/(stableAxes.Tangential*stableAxes.Tangential)+1/(stableAxes.Sagittal*stableAxes.Sagittal)));
   records.Add(new{id,n,w=w.Micrometers,f=ff,fp,fStable,stableT=stableAxes.Tangential,stableS=stableAxes.Sagittal,stableCombined,ft=axes.Tangential,fs=axes.Sagittal,fAvg=average.Tangential,epd=optic.Paraxial.EstimateEntrancePupilDiameter()});continue;
  }
  var variants=mode=="pitch"?Enumerable.Range(0,7):mode=="poly"?Enumerable.Range(0,24):Enumerable.Range(0,12);
  foreach(var v in variants)
  {
   var wave=mode=="poly"&&(v/2)%4==1?primary:mode=="poly"&&(v/2)%4==2?waves.MaxBy(w=>w.Nanometers)!:shortest;
   var f=DiffractionEngine.WorkingFNumber(optic,field,wave,optic.RayAimingEnabled);var l=wave.Micrometers;
   if(mode=="poly"&&(v/2)%4==3)l=waves.Sum(w=>w.Micrometers*w.Weight)/waves.Sum(w=>w.Weight);
   if(mode=="poly"&&v/8==1)f=DiffractionEngine.WorkingFNumber(optic,field,primary,optic.RayAimingEnabled);
   if(mode=="poly"&&v/8==2)f=waves.Sum(w=>DiffractionEngine.WorkingFNumber(optic,field,w,optic.RayAimingEnabled)*w.Weight)/waves.Sum(w=>w.Weight);
   var pitch=mode is "custom" or "global" or "norm" or "dual" or "nativeweight"?waves.Max(w=>w.Micrometers)*DiffractionEngine.WorkingFNumber(optic,field,mode=="nativeweight"?waves.MaxBy(w=>w.Micrometers)!:mode is "global" or "norm" or "dual"?optic.Wavelengths.First(w=>w.IsPrimary):primary,optic.RayAimingEnabled)/Math.Sqrt(n):mode=="poly"?l*f/Math.Sqrt(n):v switch {
    0=>l*f*(n-2)/(size*Math.Sqrt(n/4d-1)),
    1=>l*f/Math.Sqrt(n),
    2=>Math.Sqrt(l*l*f*f/n),
    3=>l/Math.Sqrt(n)*f,
    4=>l*(f/Math.Sqrt(n)),
    5=>l*f/Math.Sqrt(n)*(1-4e-15),
    _=>l*f/Math.Sqrt(n)*(1+4e-15)};
   var curves=new List<object>();
   for(var ideal=0;ideal<2;ideal++)
   {
    var longestWave=waves.MaxBy(w=>w.Micrometers)!;
    var pupilPitch=mode=="dual"?longestWave.Micrometers*DiffractionEngine.WorkingFNumber(optic,field,longestWave,optic.RayAimingEnabled)/Math.Sqrt(n):pitch;
    var psfs=mode is "custom" or "global" or "norm" or "dual" or "nativeweight"?waves.Select(w=>(Wavelength:w,Result:CustomPsf(optic,w,primary,waves.Max(w=>w.Micrometers),n,pupilPitch,ideal==0,v))).ToArray()
     :DiffractionEngine.ComputeFftPsfSpectrum(optic,field,waves,n,size,cellCenteredPupil:true,zemaxFftSampling:true,
      ignoreOpd:ideal==0,aimAtStop:optic.RayAimingEnabled,referenceWavelength:primary,imageDelta:pitch,ignoreScalarTransmission:true);
    var weights=waves.Select(w=>w.Weight).ToArray();
    if(mode is "custom" or "global"||mode=="poly"&&v%2==1)for(var w=0;w<waves.Length;w++)weights[w]/=psfs[w].Result.Values.Cast<double>().Sum();
    if(mode is "norm" or "dual")for(var wi=0;wi<waves.Length;wi++)weights[wi]*=v/4==0?1/psfs[wi].Result.Values.Cast<double>().Sum():v/4==1?waves[wi].Micrometers*waves[wi].Micrometers:Math.Pow(waves[wi].Micrometers*psfs[wi].Result.WorkingFNumber,2);
    if(mode=="nativeweight")for(var wi=0;wi<waves.Length;wi++){
     var sum=psfs[wi].Result.Values.Cast<double>().Sum();var count=sum/(size*size);
     weights[wi]*=v/4==0?1/sum:1/(count*count*Math.Pow(waves[wi].Micrometers*(v/4==2?psfs[wi].Result.WorkingFNumber:1),2));
    }
    var powers=new double[size*size];double total=0,cx=0,cy=0;
    for(var row=0;row<size;row++)for(var col=0;col<size;col++)
    {
     var power=psfs.Select((p,i)=>weights[i]*p.Result.Values[(row+1)%size,(col+1)%size]).Sum();
     powers[row*size+col]=power;total+=power;cx+=(col-size/2d+1)*pitch*power;cy+=(row-size/2d+1)*pitch*power;
    }
    var samples=Array.CreateInstance(sampleType,powers.Length);
    for(var row=0;row<size;row++)for(var col=0;col<size;col++)samples.SetValue(Activator.CreateInstance(sampleType,
     (col-size/2d+1)*pitch,(row-size/2d+1)*pitch,powers[row*size+col]),row*size+col);
    var grid=Activator.CreateInstance(gridType,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance,null,new object[]{samples,(cx/total,cy/total),"encircled"},null)!;
    var points=(IReadOnlyList<AnalysisPoint>)build.Invoke(analysis,new object[]{grid,max})!;
    var expected=native.RootElement.GetProperty("dataSeries")[ideal].GetProperty("y").EnumerateArray().Select(a=>a[0].GetDouble()).ToArray();
    var errors=points.Select((p,i)=>p.Y-expected[i]).ToArray();
    var nr=Math.Sqrt(errors.Average(x=>x*x))/(expected.Max()-expected.Min());var ma=errors.Max(Math.Abs);
    curves.Add(new{ideal,nrmse=nr,maxAbs=ma,centroid=new[]{cx/total,cy/total},totalPower=total});
   }
   Console.WriteLine($"{id} v={v} pitch={pitch:R} "+JsonSerializer.Serialize(curves));
   records.Add(new{id,v,pitch,curves});
  }
 }
}
File.WriteAllText(Path.Combine(fresh,$"{mode}-{(args.Length>2?args[2]:"all")}.json"),JsonSerializer.Serialize(records));
PsfResult CustomPsf(Optic optic,Wavelength w,Wavelength primary,double longest,int n,double pitch,bool ideal,int variant)
{
 var global=optic.Wavelengths.FirstOrDefault(a=>a.IsPrimary)??optic.Wavelengths[0];
 var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled);
 var scale=variant/4==0?w.Micrometers/longest:variant/4==1?w.Micrometers*f/pitch:w.Micrometers/longest;
 var step=mode is "norm" or "dual" or "nativeweight"?w.Micrometers*f/pitch/n:variant/4==0?scale/Math.Sqrt(n):variant/4==1?scale/n:scale*Math.Sqrt(1d/n);
 var pupils=new List<(double,double)>();
 for(var y=-n/2;y<n/2;y++)for(var x=-n/2;x<n/2;x++)
 {
  var px=x*step;var py=y*step;var r2=px*px+py*py;
  if(variant%4>=2?r2<1:r2<=1)pupils.Add((px,py));
 }
 var sphere=variant%2==1?WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),global,optic.RayAimingEnabled):null;
 var wavefront=WavefrontEngine.GenerateChiefRaySamples(optic,(0,0),w,pupils,aimAtStop:optic.RayAimingEnabled,referenceSphere:sphere,referenceWavelength:variant%2==1?w:primary);
 if(ideal&&variant==0)Console.WriteLine("PUPIL "+JsonSerializer.Serialize(new{w=w.Micrometers,f,pitch,step,count=pupils.Count,zeros=wavefront.Samples.Where(s=>s.Intensity<=0).Select(s=>new{s.NormalizedPupilX,s.NormalizedPupilY}),epd=optic.Paraxial.EstimateEntrancePupilDiameter()}));
 wavefront=wavefront with{Samples=wavefront.Samples.Select(s=>s.Intensity>0?s with{Intensity=s.LaunchIntensity??s.Intensity}:s).ToArray()};
 var stretch=step*(n/2d-1);
 if(!ideal)wavefront=(WavefrontResult)typeof(DiffractionEngine).GetMethod("InterpolateFftPupilPhase",BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,new object[]{wavefront,new PupilGridSpecification(n,true,true,stretch)})!;
 var pupil=(Complex[,])typeof(DiffractionEngine).GetMethod("BuildComplexPupilCore",BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,new object?[]{wavefront,null,n,w,f,f,true,0d,stretch,ideal,true})!;
 var size=2*n;var padded=new Complex[size,size];
 for(var y=0;y<n;y++)for(var x=0;x<n;x++)padded[y+n/2,x+n/2]=pupil[y,x];
 typeof(DiffractionEngine).GetMethod("FourierTransform2D",BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,new object[]{padded,false});
 var power=new double[size,size];for(var y=0;y<size;y++)for(var x=0;x<size;x++)power[y,x]=Complex.Abs(padded[(y+n)%size,(x+n)%size])*Complex.Abs(padded[(y+n)%size,(x+n)%size]);
 return new(power,n,size,f,pitch);
}
