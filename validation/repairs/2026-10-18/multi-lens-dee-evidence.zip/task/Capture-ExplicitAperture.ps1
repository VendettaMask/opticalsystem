$ErrorActionPreference='Stop'
$d=$PSScriptRoot
$h=New-Item -ItemType Directory -Path "$d/aperture-export-host"
Get-ChildItem "$d/aperture-host" -Filter '*.cs'|Copy-Item -Destination $h
$hp="$h/Host.cs"
$s=[IO.File]::ReadAllText($hp)
$mark='system.MCE.SetCurrentConfiguration(Int("configuration"));'
$insert='if (Request.ContainsKey("diagnosticFloatingStop")) { var aperture = system.LDE.GetSurfaceAt(9).ApertureData; aperture.ChangeApertureTypeSettings(aperture.CreateApertureTypeSettings(ZOSAPI.Editors.LDE.SurfaceApertureTypes.FloatingAperture)); system.SaveAs(Path.Combine(Output, "explicit-floating-stop.zmx")); }'
[IO.File]::WriteAllText($hp,$s.Replace($mark,$mark+$insert))
$api='D:\Program Files\ANSYS Inc\v261\Zemax OpticStudio'
$c=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$ex="$h/NativeBatchHost.exe"
$aa=@('/nologo','/target:exe','/platform:x64','/main:NativeBatchHost',"/out:$ex",'/r:System.Web.Extensions.dll')
foreach($f in @('ZOSAPI.dll','ZOSAPI_Interfaces.dll','ZOSAPI_NetHelper.dll')){$aa+="/r:$api/$f"}
$aa+=@(Get-ChildItem $h -Filter '*.cs'|ForEach-Object FullName)
& $c @aa 2>&1 | Tee-Object "$h/build.log"
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
Copy-Item "$d/aperture-host/NativeBatchHost.exe.config" "$ex.config"
$r=Get-Content (Get-ChildItem "$d/boundary-request-0412*.json").FullName -Raw|ConvertFrom-Json
$r|Add-Member -NotePropertyName diagnosticFloatingStop -NotePropertyValue $true
$rp="$d/floating-stop-request.json"
$r|ConvertTo-Json -Depth 20|Set-Content $rp
$j=@{id='floating-stop';request=$rp;output="$d/floating-stop-native"}
ConvertTo-Json -InputObject @($j) -Depth 6 | Set-Content "$d/floating-stop-jobs.json"
$env:PATH=$api+';'+$env:PATH
& $ex $api "$d/floating-stop-jobs.json" > "$d/floating-stop-native.log" 2>&1
exit $LASTEXITCODE
