using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;
var repo=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);
Directory.CreateDirectory(output);
var prior=Path.Combine(repo,"artifacts/validation/numerical-residuals-20261018");
var fresh=Path.Combine(repo,"artifacts/validation/dee-multi-lens-20261018");
var configuration=ComparisonConfiguration.Load(Path.Combine(repo,"tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json"));
var setting=configuration.Analyses["Diffraction Encircled Energy"];
var entry=AnalysisComparisonRegistry.Get("Diffraction Encircled Energy");
var rows=new List<object>();
foreach(var list in new[]{"native-jobs-v2.json","holdout-jobs.json","old-ms-l7-jobs.json","native-jobs-v3.json",Path.Combine(fresh,"native-jobs.json")})
{
 using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(prior,list)));
 foreach(var job in jobs.RootElement.EnumerateArray())
 {
  var id=job.GetProperty("id").GetString()!;
  if(list=="native-jobs-v2.json"&&id.StartsWith("slit-"))continue;
  var folder=job.GetProperty("output").GetString()!;
  var requestPath=job.GetProperty("request").GetString()!;
  var json=JsonFiles.Read<JsonElement>(requestPath);
  var request=JsonFiles.Read<CanonicalAnalysisRequest>(requestPath);
  var source=json.GetProperty("input").GetString()!;
  var model=JsonFiles.Read<JsonElement>(Path.Combine(folder,"model.json"));
  var optic=OpticalFormatCatalog.Import(File.ReadAllText(source),".zmx");
  optic.RayAimingEnabled=model.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
  var path=Path.Combine(output,id);Directory.CreateDirectory(path);
  var nativeDirectory=Path.Combine(path,"native");Directory.CreateDirectory(nativeDirectory);
  foreach(var file in Directory.EnumerateFiles(folder))File.Copy(file,Path.Combine(nativeDirectory,Path.GetFileName(file)),false);
  var snapshot=Path.Combine(path,"source.optic.json");JsonFiles.Write(snapshot,optic.ToSnapshot());
  var wb=Path.Combine(path,"workbench");Directory.CreateDirectory(wb);
  var wbJob=new WorkbenchJob(snapshot,wb,request);JsonFiles.Write(Path.Combine(wb,"request.json"),wbJob);
  WorkbenchExecutor.Execute(wbJob);
  var w=ResultNormalizer.Workbench(Path.Combine(wb,"data.json"),entry,request);
  var z=ResultNormalizer.Zemax(Path.Combine(nativeDirectory,"data.json"),entry,request);
  JsonFiles.Write(Path.Combine(path,"normalized-workbench.json"),w);
  JsonFiles.Write(Path.Combine(path,"normalized-zemax.json"),z);
  var run=new AnalysisRun{Key=entry.CanonicalAnalysisKey,Directory=id,Request=request,Support=entry.Support,ZemaxStatus=CaptureStatus.Captured,WorkbenchStatus=CaptureStatus.Captured,Tolerances=setting.Quantities};
  var settings=setting with{Field=request.Field,Wavelength=request.Wavelength,PupilSampling=request.PupilSampling,ImageSampling=request.ImageSampling};
  ComparisonRunner.Compare(run,entry,settings,w,z,path);
  rows.Add(new{id,run.Conclusion,run.Metrics,source,sourceSha256=JsonFiles.Hash(File.ReadAllBytes(source)),executedRequestSha256=JsonFiles.Hash(File.ReadAllBytes(requestPath)),nativeDataSha256=JsonFiles.Hash(File.ReadAllBytes(Path.Combine(folder,"data.json")))});
  Console.WriteLine($"{id}: {run.Conclusion} {run.Metrics.Select(m=>m.Nrmse).DefaultIfEmpty().Max():G6}");
 }
}
JsonFiles.Write(Path.Combine(output,"summary.json"),new{coreSha256=JsonFiles.Hash(File.ReadAllBytes(typeof(Optic).Assembly.Location)),policySha256=JsonFiles.Hash(File.ReadAllBytes(Path.Combine(repo,"tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json"))),rows});
