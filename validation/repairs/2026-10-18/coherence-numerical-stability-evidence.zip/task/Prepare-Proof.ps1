$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$taskPath) {(Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read-Run([string]$taskPath) {
    [xml]$taskXml=Get-Content -LiteralPath $taskPath -Raw
    $taskNs=[Xml.XmlNamespaceManager]::new($taskXml.NameTable);$taskNs.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
    $taskC=$taskXml.SelectSingleNode('//t:ResultSummary/t:Counters',$taskNs)
    @{total=[int]$taskC.total;passed=[int]$taskC.passed;failed=[int]$taskC.failed;skipped=[int]$taskC.notExecuted;names=@($taskXml.SelectNodes('//t:Results/t:UnitTestResult',$taskNs) | ForEach-Object testName | Sort-Object)}
}
$taskPrior=Get-Content (Join-Path $taskRepo 'docs/validation/PARTIAL_COHERENCE_PSF_WINDOW_REPAIR_2026-10-18.json') -Raw | ConvertFrom-Json
$taskRelease=Read-Run (Join-Path $PSScriptRoot 'tests/related-release-final-v2.trx')
$taskDebug=Read-Run (Join-Path $PSScriptRoot 'tests/related-debug-final-v2.trx')
foreach($taskRun in @($taskRelease,$taskDebug)) {
    if($taskRun.total -ne 730 -or $taskRun.passed -ne 730 -or $taskRun.failed -ne 0 -or $taskRun.skipped -ne 0) {throw 'Final related tests incomplete'}
    if(@($taskRun.names | Where-Object {$_ -match '\.CoherenceNumericalStabilityTests\.'}).Count -ne 22) {throw 'New stability cases missing'}
    if(@($taskRun.names | Where-Object {$_ -match '\.FftCumulativeEnergyTests\.'}).Count -ne 17) {throw 'Existing energy cases missing'}
    foreach($taskName in $taskPrior.verification.testRelease.names) {if($taskName -cnotin $taskRun.names) {throw 'Previous test identity missing'}}
}
if(($taskRelease.names -join "`n") -cne ($taskDebug.names -join "`n")) {throw 'Configuration test identities differ'}
$taskConfigs=foreach($taskConfig in @('Release','Debug')) {
    $taskLogPath=if($taskConfig -eq 'Release') {'build-release-final-v2.log'} else {'build-debug-final.log'}
    $taskLog=Get-Content (Join-Path $PSScriptRoot $taskLogPath) -Raw
    if(@($taskLog -split "`n" | Where-Object {$_ -match ' -> '}).Count -ne 19 -or -not $taskLog.Contains('0 个警告') -or -not $taskLog.Contains('0 个错误')) {throw 'Default solution build incomplete'}
    $taskPaths=@("src/OpticalSystemDesign.Core/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll")
    $taskHashes=@($taskPaths | ForEach-Object {@{path=$_;sha256=Hash (Join-Path $taskRepo $_)}})
    if(@($taskHashes.sha256 | Sort-Object -Unique).Count -ne 1) {throw 'Default Core copies differ'}
    @{configuration=$taskConfig;projects=19;warnings=0;errors=0;coreCopies=$taskHashes}
}
$taskOldProof=Get-Content (Join-Path $taskRepo 'artifacts/validation/partial-coherence-psf-window-20261018/proof.json') -Raw | ConvertFrom-Json
$taskPreserved=@{}
foreach($taskProp in $taskOldProof.preservedArchives.PSObject.Properties) {$taskPreserved[$taskProp.Name]=$taskProp.Value}
$taskPreserved['validation/repairs/2026-10-18/partial-coherence-psf-window-evidence.zip']='48e30bd1b3a27f70a03e9cfa66401aa141f43241de2c54a081d5f2bd4fd05413'
foreach($taskPath in $taskPreserved.Keys) {if((Hash (Join-Path $taskRepo $taskPath)) -ne $taskPreserved[$taskPath]) {throw 'Frozen archive changed'}}
$taskFiniteZip=[IO.Compression.ZipFile]::OpenRead((Join-Path $taskRepo 'validation/repairs/2026-10-17/partial-coherence-finite-evidence.zip'))
try {$taskReader=[IO.StreamReader]::new($taskFiniteZip.GetEntry('capture-manifest.json').Open());try {$taskFiniteCapture=$taskReader.ReadToEnd() | ConvertFrom-Json} finally {$taskReader.Dispose()}} finally {$taskFiniteZip.Dispose()}
$taskFixtures=@{
    'partial-coherence-zemax-2026-r1.json'='884b68907ae76f4e560397957724e4d20be54c84550231dc564bce63e52bac14'
    'partial-coherence-finite-zemax-2026-r1.json'=$taskFiniteCapture.fixtureSha256
    'partial-coherence-psf-window-zemax-2026-r1.zip'=$taskOldProof.captures.fixtureSha256
    'partial-coherence-sampling-boundary-zemax-2026-r1.zip'=$taskOldProof.boundaryCaptures.fixtureSha256
}
foreach($taskName in $taskFixtures.Keys) {if((Hash (Join-Path $taskRepo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$taskName))) -ne $taskFixtures[$taskName]) {throw 'Existing native fixture changed'}}
$taskBefore=Get-Content (Join-Path $PSScriptRoot 'numerics-before/stability.json') -Raw | ConvertFrom-Json
$taskAfter=Get-Content (Join-Path $PSScriptRoot 'numerics-after/stability.json') -Raw | ConvertFrom-Json
if($taskBefore.coreSha256 -ne 'abdda2de2cdf4027ed1a9aca951693d4142257a2d8220913d3a91932c6248dfb' -or (Hash (Join-Path $PSScriptRoot 'Core.before.dll')) -ne $taskBefore.coreSha256) {throw 'Before binary identity differs'}
if($taskAfter.coreSha256 -ne $taskConfigs[0].coreCopies[0].sha256 -or $taskAfter.cases.Count -ne 21 -or @($taskAfter.cases | Where-Object {$_.error -or $_.relativeError -gt 1e-10}).Count -ne 0) {throw 'Final independent values incomplete'}
$taskBeforeRun=Read-Run (Join-Path $PSScriptRoot 'tests/stability-before-final.trx')
if($taskBeforeRun.total -ne 22 -or $taskBeforeRun.failed -ne 20 -or $taskBeforeRun.passed -ne 2) {throw 'Before counterexample provenance differs'}
$taskNativeCaptures=@()
foreach($taskJobsName in @('native-jobs-v2.json','native-jobs-v3.json','holdout-jobs.json','old-ms-l7-jobs.json','wfno-jobs.json')) {
    foreach($taskJob in @(Get-Content (Join-Path $PSScriptRoot $taskJobsName) -Raw | ConvertFrom-Json)) {
        if($taskJobsName -eq 'native-jobs-v2.json' -and $taskJob.id -like 'slit-*') {continue}
        $taskResult=Get-Content (Join-Path $taskJob.output 'batch-result.json') -Raw | ConvertFrom-Json
        $taskEnv=Get-Content (Join-Path $taskJob.output 'environment.json') -Raw | ConvertFrom-Json
        if($taskResult.exitCode -ne 0 -or $taskEnv.major -ne 26 -or $taskEnv.minor -ne 1 -or $taskEnv.opticStudioVersion -ne 260127 -or -not $taskEnv.validLicense) {throw 'Native capture provenance incomplete'}
        $taskReq=Get-Content -LiteralPath $taskJob.request -Raw | ConvertFrom-Json
        $taskNativeCaptures+=@{id=$taskJob.id;directory=[IO.Path]::GetRelativePath($PSScriptRoot,$taskJob.output).Replace('\','/');source=$taskReq.input;sourceSha256=Hash $taskReq.input;requestSha256=Hash $taskJob.request;dataSha256=Hash (Join-Path $taskJob.output 'data.json');nativeEnvironment=$taskEnv;meaning='Diagnostic capture succeeded; does not certify final DEE precision'}
    }
}
if($taskNativeCaptures.Count -ne 32) {throw 'Unexpected native capture count'}
$taskSources=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt') | ForEach-Object {@{path=$_;sha256=Hash (Join-Path $taskRepo $_)}})
$taskProof=@{date='2026-10-18';scope='Two-source coherence cancellation and representable-intensity dynamic range';baseCommit=(git -C $taskRepo rev-parse HEAD);testRelease=$taskRelease;testDebug=$taskDebug;previous691NamesPreserved=$true;additionalExistingEnergyTests=17;newTests=22;configurations=$taskConfigs;beforeTest=$taskBeforeRun;numericsBefore=$taskBefore;numericsAfter=$taskAfter;preservedArchives=$taskPreserved;preservedNativeFixtures=$taskFixtures;nativeDiagnosticCaptures=$taskNativeCaptures;deeCandidateWithdrawn=$true;deeFinalResiduals=(Get-Content (Join-Path $PSScriptRoot 'final-energy/results.json') -Raw | ConvertFrom-Json);sourceFiles=$taskSources;noFullSuite=$true;noInstallerRebuild=$true;noCommitOrPush=$true;independentCookeTessarExcluded=$true}
$taskProof | ConvertTo-Json -Depth 30 | Set-Content (Join-Path $PSScriptRoot 'proof.json')
'Verified 730/730 in each configuration, previous 691 identities, 21 numerical values, 32 diagnostic captures, 10 frozen archives and four native fixtures.'
