$ErrorActionPreference='Stop'
$taskRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$taskArchive=Join-Path $taskRepo 'validation/repairs/2026-10-18/coherence-numerical-stability-evidence.zip'
if(Test-Path -LiteralPath $taskArchive) {throw 'Refusing to overwrite an evidence archive'}
$taskMap=[Collections.Generic.SortedDictionary[string,string]]::new([StringComparer]::Ordinal)
foreach($taskFile in Get-ChildItem -LiteralPath $PSScriptRoot -File -Recurse) {
    $taskRelative=[IO.Path]::GetRelativePath($PSScriptRoot,$taskFile.FullName).Replace('\','/')
    if($taskRelative -match '(^|/)(bin|obj|before-replay|stability-before-tests)(/|$)' -or $taskRelative -match '^archive-' -or $taskRelative -match '\.(exe|pdb|cache)$') {continue}
    if($taskRelative -match '\.dll$' -and $taskRelative -ne 'Core.before.dll') {continue}
    $taskMap.Add('task/'+$taskRelative,$taskFile.FullName)
}
$taskSourceFiles=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt'))
foreach($taskPath in $taskSourceFiles) {$taskMap.Add('source/'+$taskPath.Replace('\','/'),(Join-Path $taskRepo $taskPath))}
$taskProof=Get-Content (Join-Path $PSScriptRoot 'proof.json') -Raw | ConvertFrom-Json
$taskLensPaths=@($taskProof.nativeDiagnosticCaptures.source | Sort-Object -Unique)
foreach($taskPath in $taskLensPaths) {
    $taskName=if([IO.Path]::GetFileName($taskPath) -eq 'source.ZMX') {'ms-l7-source.ZMX'} else {[IO.Path]::GetFileName($taskPath)}
    $taskMap.Add('lenses/'+$taskName,$taskPath)
}
foreach($taskConfig in @('Release','Debug')) {$taskMap.Add('binaries/'+$taskConfig+'/OpticalSystemDesign.Core.dll',(Join-Path $taskRepo "src/OpticalSystemDesign.Core/bin/$taskConfig/net10.0/OpticalSystemDesign.Core.dll"))}
$taskManifest=@($taskMap.Keys | ForEach-Object {@{path=$_;bytes=(Get-Item -LiteralPath $taskMap[$_]).Length;sha256=(Get-FileHash -LiteralPath $taskMap[$_] -Algorithm SHA256).Hash.ToLowerInvariant()}})
$taskZip=[IO.Compression.ZipFile]::Open($taskArchive,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($taskEntry in $taskManifest) {[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskZip,$taskMap[$taskEntry.path],$taskEntry.path,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
    $taskEntry=$taskZip.CreateEntry('manifest.json');$taskWriter=[IO.StreamWriter]::new($taskEntry.Open(),[Text.UTF8Encoding]::new($false));try {$taskWriter.Write(($taskManifest | ConvertTo-Json -Depth 8))} finally {$taskWriter.Dispose()}
} finally {$taskZip.Dispose()}
$taskZip=[IO.Compression.ZipFile]::OpenRead($taskArchive)
try {
    if($taskZip.Entries.Count -ne $taskManifest.Count+1) {throw 'Archive entry count differs'}
    foreach($taskItem in $taskManifest) {
        $taskStream=$taskZip.GetEntry($taskItem.path).Open()
        try {$taskHash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($taskStream))} finally {$taskStream.Dispose()}
        if($taskHash -ne $taskItem.sha256) {throw 'Archive read-back hash differs'}
    }
    $taskReader=[IO.StreamReader]::new($taskZip.GetEntry('manifest.json').Open())
    try {$taskReadManifest=$taskReader.ReadToEnd() | ConvertFrom-Json} finally {$taskReader.Dispose()}
    if($taskReadManifest.Count -ne $taskManifest.Count) {throw 'Manifest read-back count differs'}
    for($taskIndex=0;$taskIndex -lt $taskManifest.Count;$taskIndex++) {
        if($taskReadManifest[$taskIndex].path -cne $taskManifest[$taskIndex].path -or $taskReadManifest[$taskIndex].sha256 -cne $taskManifest[$taskIndex].sha256 -or $taskReadManifest[$taskIndex].bytes -ne $taskManifest[$taskIndex].bytes) {throw 'Manifest read-back differs'}
    }
} finally {$taskZip.Dispose()}
$taskResult=@{path=[IO.Path]::GetRelativePath($taskRepo,$taskArchive).Replace('\','/');sha256=(Get-FileHash -LiteralPath $taskArchive).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $taskArchive).Length;entries=$taskManifest.Count+1;verifiedPayloadEntries=$taskManifest.Count;manifestReadBackVerified=$true;everyPayloadEntryVerified=$true;containsProprietaryApiBinaries=$false}
$taskResult | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $PSScriptRoot 'archive-result.json')
$taskResult | ConvertTo-Json -Depth 6
