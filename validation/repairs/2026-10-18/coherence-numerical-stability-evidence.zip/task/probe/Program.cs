using System.Text.Json;
using System.Security.Cryptography;
using System.Numerics;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var root=Path.GetFullPath(args[0]);
var task=Path.Combine(root,"artifacts/validation/numerical-residuals-20261018");
var output=Path.GetFullPath(args[1]); Directory.CreateDirectory(output);
var records=new List<object>();
if(args.Length>2 && args[2]=="stability")
{
    var cases=new List<object>();
    void Measure(string name,double expected,Func<double> calculation) {
        double? actual=null;string? error=null;try{actual=calculation();}catch(Exception e){error=e.GetType().Name+": "+e.Message;}
        cases.Add(new{name,expected,actual,error,relativeError=actual.HasValue?Math.Abs(actual.Value/expected-1):(double?)null});
    }
    foreach(var function in new[]{SpatialCoherenceFunction.Gaussian,SpatialCoherenceFunction.Sinc})
    foreach(var alpha in new[]{1e6,1e9,1e12}) {
        var expected=function==SpatialCoherenceFunction.Gaussian?2/(alpha*alpha):Math.PI*Math.PI/(3*alpha*alpha);
        Measure($"dark-{function}-{alpha:R}",expected,()=>MutualIntensityEngine.PropagateSpatialCoherence(new double[,]{{1,1}},new Complex[,]{{1,-1}},function,alpha,1)[0,1]);
    }
    foreach(var range in new[]{(Source:1e-300,Kernel:1e200,Expected:1e100),(Source:1e300,Kernel:1e-200,Expected:1e-100)}) {
        foreach(var g in new[]{0d,.5,1}) Measure($"range-Uniform-{g:R}-{range.Kernel:R}",range.Expected,()=>MutualIntensityEngine.PropagateUniformCoherence(new double[,]{{range.Source}},new Complex[,]{{range.Kernel}},g)[0,0]);
        foreach(var method in Enum.GetValues<SpatialCoherenceMethod>()) Measure($"range-{method}-{range.Kernel:R}",range.Expected,()=>MutualIntensityEngine.PropagateSpatialCoherence(new double[,]{{range.Source}},new Complex[,]{{range.Kernel}},SpatialCoherenceFunction.Gaussian,1,1,method:method)[0,0]);
    }
    foreach(var function in new[]{SpatialCoherenceFunction.Gaussian,SpatialCoherenceFunction.Sinc})
        Measure($"bright-subnormal-{function}",function==SpatialCoherenceFunction.Gaussian?2e-100:3.289868133696453e-100,()=>MutualIntensityEngine.PropagateSpatialCoherence(new double[,]{{1e300,1e300}},new Complex[,]{{1,-1}},function,1e200,1)[0,1]);
    Measure("signed-sinc",38-8/Math.PI,()=>MutualIntensityEngine.PropagateSpatialCoherence(new double[,]{{4,9}},new Complex[,]{{new(1,1),new(2,-1)}},SpatialCoherenceFunction.Sinc,2d/3,1)[0,1]);
    File.WriteAllText(Path.Combine(output,"stability.json"),JsonSerializer.Serialize(new{coreSha256=Hash(typeof(DiffractionEngine).Assembly.Location),cases}));
    Console.WriteLine($"Saved {cases.Count} independent intensity values");return;
}
foreach(var jobsName in new[]{"native-jobs-v2.json","holdout-jobs.json","old-ms-l7-jobs.json"})
{
    using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,jobsName)));
    foreach(var job in jobs.RootElement.EnumerateArray())
    {
        var id=job.GetProperty("id").GetString()!;
        if(id.StartsWith("slit-")) continue;
        var folder=job.GetProperty("output").GetString()!;
        using var native=JsonDocument.Parse(File.ReadAllText(Path.Combine(folder,"data.json")));
        using var req=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));
        using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(folder,"model.json")));
        var r=req.RootElement;var source=r.GetProperty("input").GetString()!;
        var optic=OpticalFormatCatalog.Import(File.ReadAllText(source),".zmx");
        var mode=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString();
        optic.RayAimingEnabled=mode!="Off";
        var n=r.GetProperty("pupilSampling").GetInt32();var w=r.GetProperty("wavelength").GetInt32();
        var max=r.GetProperty("zemaxSettings").GetProperty("RadiusMaximum").GetDouble();
        var data=new DiffractionEncircledEnergyAnalysis(optic,n,2*n,401,w,r.GetProperty("field").GetInt32(),maximumDistanceMicrometers:max).GenerateData();
        var targets=native.RootElement.GetProperty("dataSeries");
        var curves=data.PlotSeries.Select((s,i)=>{
            var expected=targets[i].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
            var actual=s.Points.Select(p=>p.Y).ToArray();var d=actual.Zip(expected,(a,b)=>a-b).ToArray();
            return new{index=i,actual,expected,maximumAbsolute=d.Max(Math.Abs),nrmse=Math.Sqrt(d.Average(v=>v*v))/(expected.Max()-expected.Min())};
        }).ToArray();
        Console.WriteLine($"{id} aim={mode}, "+string.Join("; ",curves.Select(c=>$"{c.index}: {c.nrmse:G6}/{c.maximumAbsolute:G6}")));
        records.Add(new{id,folder,source,sourceSha256=Hash(source),sampling=n,wavelength=w,aiming=mode,nativeSha256=Hash(Path.Combine(folder,"data.json")),messages=native.RootElement.GetProperty("messages").Clone(),curves});
    }
}
File.WriteAllText(Path.Combine(output,"results.json"),JsonSerializer.Serialize(new{coreSha256=Hash(typeof(DiffractionEngine).Assembly.Location),records}));
static string Hash(string path)=>Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path)));
