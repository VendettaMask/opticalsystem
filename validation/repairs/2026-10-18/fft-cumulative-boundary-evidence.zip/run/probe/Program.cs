using System.Numerics;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Rays;
using OpticalSystemDesign.Core.Raytrace;
var root=Path.GetFullPath(args[0]);
var task=Path.Combine(root,"artifacts/validation/dee-boundary-20261018");
if(args.Length<2||args[1]=="invert"){
 var records=new List<object>();
 foreach(var id in new[]{"relay64","relay128","offner64","annular128","relay64-minus","relay64-plus"}){
  using var re=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"native",id+"-Real/data.json")));
  using var im=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"native",id+"-Imaginary/data.json")));
  using var intensity=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"native",id+"-Linear/data.json")));
  var rg=re.RootElement.GetProperty("dataGrids")[0];var ig=im.RootElement.GetProperty("dataGrids")[0];var lg=intensity.RootElement.GetProperty("dataGrids")[0];
  var n=rg.GetProperty("nx").GetInt32();var pupil=new Complex[n,n];double residual=0,sum=0;
  for(int y=0;y<n;y++)for(int x=0;x<n;x++){
   var v=new Complex(rg.GetProperty("values")[y][x].GetDouble(),ig.GetProperty("values")[y][x].GetDouble());
   pupil[(y+1)%n,(x+1)%n]=v;
   var lv=lg.GetProperty("values")[y][x].GetDouble();sum+=lv;
   residual=Math.Max(residual,Math.Abs(v.Magnitude*v.Magnitude-lv));
  }
  DiffractionEngine.FourierTransform2D(pupil,true);
  var max=pupil.Cast<Complex>().Max(v=>v.Magnitude);
  var nodes=new List<object>();var count=0;
  for(int y=0;y<n;y++)for(int x=0;x<n;x++){
   var v=pupil[y,x];if(v.Magnitude<max*.5)continue;count++;
   var px=x<n/2?x:x-n;var py=y<n/2?y:y-n;
   nodes.Add(new{x=px,y=py,amplitude=v.Magnitude/max,phase=v.Phase});
  }
  var record=new{id,n,dx=rg.GetProperty("dx").GetDouble(),count,pupilMax=max,complexIntensityError=residual,nativeIntensitySum=sum,nodes};
  records.Add(record);Console.WriteLine(JsonSerializer.Serialize(new{id,n,count,max,residual,sum}));
 }
 File.WriteAllText(Path.Combine(task,"inverted-pupils.json"),JsonSerializer.Serialize(records));return;
}
if(args[1]=="scalars"){
 var old=Path.Combine(root,"artifacts/validation/numerical-residuals-20261018");
 var prior=Path.Combine(root,"artifacts/validation/dee-multi-lens-20261018");
 var records=new List<object>();
 foreach(var file in new[]{Path.Combine(old,"native-jobs-v2.json"),Path.Combine(old,"holdout-jobs.json"),Path.Combine(old,"old-ms-l7-jobs.json"),Path.Combine(prior,"native-jobs.json"),Path.Combine(task,"native-jobs.json")}){
  using var list=JsonDocument.Parse(File.ReadAllText(file));
  foreach(var j in list.RootElement.EnumerateArray()){
   var id=j.GetProperty("id").GetString()!;
   if(id.StartsWith("slit-")||file.StartsWith(task)&&!id.EndsWith("-dee"))continue;
   using var req=JsonDocument.Parse(File.ReadAllText(j.GetProperty("request").GetString()!));var r=req.RootElement;
   var source=r.GetProperty("input").GetString()!;
   var optic=OpticalFormatCatalog.Import(File.ReadAllText(source),".zmx");
   using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(j.GetProperty("output").GetString()!,"model.json")));
   optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
   var w=optic.Wavelengths.First(w=>w.IsPrimary);
   var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled);
   var a=DiffractionEngine.WorkingFNumbers(optic,(0,0),w,optic.RayAimingEnabled,strictFullPupil:true);
   var normals=new[]{(0d,0d),(0d,1d),(0d,-1d),(1d,0d),(-1d,0d)}.Select(p=>{
    var ray=optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,p.Item1,p.Item2,w.Micrometers,optic.RayAimingEnabled).Rays[0];
    return optic.SequentialRayTracer.TraceToSurface(ray,optic.SurfaceGroup.Items.Count-1)!.Direction;
   }).ToArray();
   var nas=normals.Skip(1).Select(d=>optic.Backend.Current.Cross(normals[0],d).Length/(normals[0].Length*d.Length)).ToArray();
   var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),w,optic.RayAimingEnabled);
   var naAcos=Math.Sqrt(normals.Skip(1).Select(d=>Math.Pow(Math.Sin(Math.Acos(Math.Clamp(d.X*normals[0].X+d.Y*normals[0].Y+d.Z*normals[0].Z,-1,1))),2)).Average());
   var fNoAim=DiffractionEngine.WorkingFNumber(optic,(0,0),w,false);
   var fAim=DiffractionEngine.WorkingFNumber(optic,(0,0),w,true);
   var dots=normals.Skip(1).Select(d=>Math.Clamp(d.X*normals[0].X+d.Y*normals[0].Y+d.Z*normals[0].Z,-1,1)).ToArray();
   var pb=new[]{new PupilSample(0,0,1),new PupilSample(0,1,1),new PupilSample(0,-1,1),new PupilSample(1,0,1),new PupilSample(-1,0,1)};
   var batch=optic.SequentialRayTracer.RayGenerator.GenerateNormalizedPupilSamples(0,0,w.Micrometers,pb,optic.RayAimingEnabled);
   var batchDirs=batch.Rays.Select(ray=>optic.SequentialRayTracer.TraceToSurface(ray,optic.SurfaceGroup.Items.Count-1)!.Direction).ToArray();
   var batchNa=batchDirs.Skip(1).Select(d=>optic.Backend.Current.Cross(batchDirs[0],d).Length/(batchDirs[0].Length*d.Length)).ToArray();
   var batchF=.5/Math.Sqrt(batchNa.Average(v=>v*v));
   records.Add(new{id,n=r.GetProperty("pupilSampling").GetInt32(),lambda=w.Micrometers,f,fNoAim,fAim,batchF,epd=optic.Paraxial.EstimateEntrancePupilDiameter(),radius=sphere.Radius,ft=a.Tangential,fs=a.Sagittal,naRms=Math.Sqrt(nas.Average(v=>v*v)),naAcos,nas,dots,source});
  }
 }
 File.WriteAllText(Path.Combine(task,"scalars.json"),JsonSerializer.Serialize(records));
 Console.WriteLine($"Recorded {records.Count} scalar controls");return;
}
