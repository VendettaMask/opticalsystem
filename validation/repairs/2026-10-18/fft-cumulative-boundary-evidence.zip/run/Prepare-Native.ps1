$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$old=Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout'
$previous=Join-Path $repo 'artifacts/validation/dee-multi-lens-20261018'
$definitions=@(
 @{id='relay64';folder=(Join-Path $old '0472-n64');f=11.39816091091422;wave=.5875618},
 @{id='relay128';folder=(Join-Path $old '0472-n128');f=11.39816091091422;wave=.5875618},
 @{id='offner64';folder=(Join-Path $old '0592-n64');f=2.6656437301332616;wave=.55},
 @{id='annular128';folder=(Join-Path $old '0360-n128');f=11.682840966976181;wave=.6328},
 @{id='relay64-minus';folder=(Join-Path $previous 'perturbed/0472-minus');f=11.39816091091422;wave=.5875618},
 @{id='relay64-plus';folder=(Join-Path $previous 'perturbed/0472-plus');f=11.39816091091422;wave=.5875618}
)
$jobs=@()
foreach($d in $definitions){
 $template=Get-Content (Join-Path $d.folder 'request.json') -Raw|ConvertFrom-Json
 $requestDir=Join-Path $PSScriptRoot ('requests/'+$d.id); New-Item -ItemType Directory -Path $requestDir | Out-Null
 $path=Join-Path $requestDir 'dee.json'; $template|ConvertTo-Json -Depth 30|Set-Content -LiteralPath $path -Encoding utf8NoBOM
 $jobs+=@{id=$d.id+'-dee';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$d.id+'-dee'))}
 foreach($type in @('Linear','Real','Imaginary')){
  $r=Get-Content (Join-Path $d.folder 'request.json') -Raw|ConvertFrom-Json
  $r.canonicalAnalysisKey='PSF'; $r.analysisType='FftPsf'
  $delta=($d.wave*.001/[Math]::Sqrt($r.pupilSampling))*$d.f*1000
  $r.imageDeltaMicrometers=$delta
  $r.zemaxSettings=[ordered]@{Normalize=$false;OutputSize="PsfS_$($r.imageSampling)x$($r.imageSampling)";SampleSize="PsfS_$($r.pupilSampling)x$($r.pupilSampling)";ImageDelta=$delta;Wavelength=$r.wavelength;Surface=-1;Rotation='CW0';Type=$type;Field=$r.field;UsePolarization=$false}
  $path=Join-Path $requestDir ($type+'.json');$r|ConvertTo-Json -Depth 30|Set-Content -LiteralPath $path -Encoding utf8NoBOM
  $jobs+=@{id=$d.id+'-'+$type;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$d.id+'-'+$type))}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
