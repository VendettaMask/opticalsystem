$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'threshold-sweep-v2'
New-Item -ItemType Directory -Path $out|Out-Null
$jobs=@()
foreach($def in @(@{id='0472-n64';folder='auto-scales-v2/0472-n64-fft-wfno'},@{id='0592-n64';folder='auto-scales-v2/0592-n64-fft-wfno'},@{id='0014-n64';folder='auto-scales-v2/0014-n64-fft-wfno'})){
 $base=Get-Content (Join-Path $PSScriptRoot ($def.folder+'.json')) -Raw|ConvertFrom-Json
 $delta=[double]$base.imageDeltaMicrometers
 foreach($change in @(-1e-10,-1e-12,-1e-14,0,1e-14,1e-12,1e-10)){
  $r=($base|ConvertTo-Json -Depth 30)|ConvertFrom-Json
  $value=$delta*(1+$change)
  if($change -eq 0){$value=[Math]::BitIncrement($delta)}
  $r.imageDeltaMicrometers=$value;$r.zemaxSettings.ImageDelta=$value
  $id=$def.id+'-'+($change.ToString('G17').Replace('-','m').Replace('.','p').Replace('+',''))
  $path=Join-Path $out ($id+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id;request=$path;output=(Join-Path $out $id)}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $out 'native-jobs.json') -Encoding utf8NoBOM
