$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$prior=Get-Content (Join-Path $repo 'docs/validation/MULTI_LENS_ENCIRCLED_ENERGY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$unchangedTests=@($prior.sourceFiles|Where-Object {$_.path -like 'tests/*.cs'})
foreach($source in $unchangedTests){if((Hash (Join-Path $repo $source.path)) -ne $source.sha256){throw "Previously verified test source changed: $($source.path)"}}
$release=Tests 'related-release-final.trx';$debug=Tests 'related-debug-final.trx'
foreach($run in @($release,$debug)){
 if($run.total -ne $run.passed -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Final main tests incomplete'}
 if(@($run.names|Where-Object {$_ -match '\.CumulativeEnergyBoundaryTests\.'}).Count -ne 49){throw 'Expected 49 new checks'}
 if(@($run.names|Where-Object {$_ -match '\.MultiLensEncircledEnergyTests\.'}).Count -ne 66){throw 'Prior 66 cases missing'}
 if(@($run.names|Where-Object {$_ -match '\.ZemaxImportTests\.'}).Count -ne 65){throw 'Prior import cases missing'}
}
if($release.total -ne 910 -or $debug.total -ne 197){throw 'Final test scope differs'}
foreach($name in $prior.verification.testRelease.names){if($name -cnotin $release.names){throw "Prior Release identity missing: $name"}}
foreach($name in $prior.verification.testDebug.names){if($name -cnotin $debug.names){throw "Prior Debug identity missing: $name"}}
foreach($name in $debug.names){if($name -cnotin $release.names){throw 'Debug test absent from Release'}}
$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx'
foreach($run in @($comparisonRelease,$comparisonDebug)){if($run.total -ne 5 -or $run.passed -ne 5 -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Comparison regressions incomplete'}}
$beforeTests=Tests 'boundary-before.trx'
if($beforeTests.total -ne 44 -or $beforeTests.failed -ne 10 -or $beforeTests.passed -ne 34 -or $beforeTests.skipped -ne 0){throw 'Before counterexample scope differs'}
$beforeHash=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeHash -ne '2e1c2a69ae58164f98b3c4d0903b11114592533d68d69898b9766c17e114fc33'){throw 'Before Core changed'}
$configurations=foreach($configuration in @('Release','Debug')){
 $log=Get-Content (Join-Path $PSScriptRoot ('build-'+$configuration.ToLowerInvariant()+'-final.log')) -Raw
 if(@($log -split "`n"|Where-Object {$_ -match ' -> '}).Count -ne 19 -or !$log.Contains('0 个警告') -or !$log.Contains('0 个错误')){throw 'Default solution build incomplete'}
 $paths=@("src/OpticalSystemDesign.Core/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tools/OpticalSystemDesign.ZemaxComparison/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll")
 $copies=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
 if(@($copies.sha256|Sort-Object -Unique).Count -ne 1){throw 'Default Core copies differ'}
 @{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies}
}
$before=Get-Content (Join-Path $repo 'artifacts/validation/dee-multi-lens-20261018/formal-v4/summary.json') -Raw|ConvertFrom-Json
$after=Get-Content (Join-Path $PSScriptRoot 'formal-final/summary.json') -Raw|ConvertFrom-Json
$extra=Get-Content (Join-Path $PSScriptRoot 'extra-final/summary.json') -Raw|ConvertFrom-Json
if($before.coreSha256 -ne $beforeHash -or $after.coreSha256 -ne $configurations[0].coreCopies[0].sha256 -or $extra.coreSha256 -ne $after.coreSha256){throw 'Formal Core identity differs'}
if($before.policySha256 -ne $after.policySha256 -or $after.policySha256 -ne $extra.policySha256 -or $after.policySha256 -ne (Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'))){throw 'Original tolerance policy changed'}
if($after.rows.Count -ne 48 -or @($after.rows|Where-Object conclusion -ne 'Pass').Count -ne 0 -or $after.excluded.Count -ne 0){throw 'Original 48-case matrix incomplete'}
if($extra.rows.Count -ne 6 -or @($extra.rows|Where-Object conclusion -ne 'Pass').Count -ne 0 -or $extra.excluded.Count -ne 1){throw 'Independent controls incomplete'}
if(@($before.rows|Where-Object conclusion -eq 'Pass').Count -ne 43 -or @($before.rows|Where-Object conclusion -eq 'Close').Count -ne 5){throw 'Wrong prior matrix baseline'}
foreach($row in $after.rows){
 $original=@($before.rows|Where-Object id -ceq $row.id)
 if($original.Count -ne 1 -or $row.sourceSha256 -ne $original[0].sourceSha256 -or $row.executedRequestSha256 -ne $original[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $original[0].nativeDataSha256){throw 'Frozen source/request/native reference changed'}
}
$archives=@{};foreach($p in $prior.preservedArchives.PSObject.Properties){$archives[$p.Name]=$p.Value}
$archives['validation/repairs/2026-10-18/multi-lens-dee-evidence.zip']='53967af666b04e0f1857a02a1fd3f77c979c048059dbcb68e7d529fc84cb9343'
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw "Frozen archive changed: $path"}}
$oldFixtures=@{};foreach($p in $prior.preservedNativeFixtures.PSObject.Properties){$oldFixtures[$p.Name]=$p.Value}
$oldFixtures['multi-lens-dee-zemax-2026-r1.zip']='bf561676bdda9655a719c2cd2604c591e9f9cfab1bd4e3b15f43d97f0f5f4677'
foreach($name in $oldFixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $oldFixtures[$name]){throw 'Frozen fixture changed'}}
$newFixtures=foreach($name in @('fft-cumulative-directional-zemax-2026-r1.zip','fft-cumulative-boundary-perturb-zemax-2026-r1.zip')){
 $path=Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name)
 $zip=[IO.Compression.ZipFile]::OpenRead($path)
 try{
  $reader=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open());try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
  foreach($entry in $manifest.entries){$stream=$zip.GetEntry($entry.path).Open();try{$actual=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($actual -ne $entry.sha256){throw 'New fixture payload hash mismatch'}}
  @{name=$name;sha256=Hash $path;cases=$manifest.cases.Count;excluded=$manifest.excluded;payloadEntries=$manifest.entries.Count}
 }finally{$zip.Dispose()}
}
$captures=@();$requestFailures=0;$unavailable=0;$usable=0
foreach($list in @('native-jobs.json','auto-scales/native-jobs.json','auto-scales-v2/native-jobs.json','threshold-sweep-v2/native-jobs.json','offner-range/native-jobs.json','offner-holdouts/native-jobs.json')){
 foreach($job in @(Get-Content (Join-Path $PSScriptRoot $list) -Raw|ConvertFrom-Json)){
  $request=Get-Content $job.request -Raw|ConvertFrom-Json
  $batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json
  $state='RequestError'
  if($batch.exitCode -ne 0){$requestFailures++}else{
   $environment=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
   if($environment.major -ne 26 -or $environment.minor -ne 1 -or $environment.opticStudioVersion -ne 260127 -or !$environment.validLicense){throw 'Native version/license mismatch'}
   if($request.adapter -eq 'ray-audit'){
    $data=Get-Content (Join-Path $job.output 'ray-audit.json') -Raw|ConvertFrom-Json
    foreach($surface in $data.surfaces){if($surface.rays.Count -ne $data.inputs.Count -or @($surface.rays|Where-Object error -ne 0).Count -ne 0){throw 'Ray audit incomplete'}}
    $state='Usable';$usable++
   }else{
    $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
    if($data.dataSeries.Count -eq 0 -and $data.dataGrids.Count -eq 0){$state='NativeUnavailable';$unavailable++}
    elseif($request.analysisType -eq 'DiffractionEncircledEnergy'){
     if($data.dataSeries.Count -ne 2){throw 'Native energy curve pair missing'}
     foreach($series in $data.dataSeries){if($series.x.Count -ne 401 -or $series.y.Count -ne 401){throw 'Native curve count differs'};foreach($row in $series.y){if($row.Count -ne 1 -or ![double]::IsFinite($row[0]) -or $row[0] -lt 0 -or $row[0] -gt 1){throw 'Invalid native energy fraction'}}}
     $state='Usable';$usable++
    }else{
     if($data.dataGrids.Count -ne 1){throw 'Native PSF grid missing'}
     $g=$data.dataGrids[0]
     if($g.nx -lt 1 -or $g.ny -lt 1 -or $g.values.Count -ne $g.ny -or $g.dx -le 0 -or $g.dy -le 0){throw 'Native PSF axes invalid'}
     foreach($row in $g.values){if($row.Count -ne $g.nx){throw 'Native grid row incomplete'};foreach($value in $row){if(![double]::IsFinite($value) -or ($request.zemaxSettings.Type -eq 'Linear' -and $value -lt 0)){throw 'Invalid native PSF sample'}}}
     $state='Usable';$usable++
    }
   }
  }
  $files=@(Get-ChildItem -LiteralPath $job.output -File|ForEach-Object {@{name=$_.Name;sha256=Hash $_.FullName;bytes=$_.Length}})
  $captures+=@{id=$job.id;group=$list;state=$state;exitCode=$batch.exitCode;directory=[IO.Path]::GetRelativePath($PSScriptRoot,$job.output).Replace('\','/');requestSha256=Hash $job.request;sourceSha256=Hash $request.input;files=$files}
 }
}
if($captures.Count -ne 98 -or $requestFailures -ne 10 -or $unavailable -ne 1 -or $usable -ne 87){throw 'Native diagnostic inventory differs'}
$sources=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
if($sources.Count -ne 35){throw 'Current changed source inventory differs'}
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log');if($LASTEXITCODE -ne 0){throw 'Whitespace check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='Relay 64/128 and Offner 64 pass original tolerances; original 48 cases and six valid independent controls pass'
 allCapturedMultiLensResidualsClosed=$true;remainingDistinctControls=@()
 constraints=@{originalTolerancesUnchanged=$true;allPrevious43FormalPassesPreserved=$true;original861ReleaseIdentitiesPreserved=$true;original148DebugIdentitiesPreserved=$true;unchangedPriorTestSources=$unchangedTests;independentCookeTessarExcluded=$true}
 beforeCoreSha256=$beforeHash;beforeTests=$beforeTests
 verification=@{testRelease=$release;testDebug=$debug;debugScope='Focused prior 148 plus 49 new cases';comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;configurations=$configurations;newMainTests=49;newNativeCurveTests=44;newRmsChecks=5;format=@{exitCode=0;includedCSharpFiles=35;log='format-verify.log'};gitDiffCheckExitCode=0}
 formalBefore=$before;formalAfter=$after;independentControls=$extra;nativeRepeats=(Get-Content (Join-Path $PSScriptRoot 'native-repeat-comparison.json') -Raw|ConvertFrom-Json)
 preservedArchives=$archives;preservedNativeFixtures=$oldFixtures;newFixtures=$newFixtures
 nativeCaptureSummary=@{attempts=98;usableCaptures=87;requestErrors=10;nativeUnavailable=1;independenceNote='Counts include repeated captures, sampling sweeps and auxiliary Huygens/complex FFT controls, not 87 independent lens certifications'}
 nativeCaptures=$captures;sourceFiles=$sources
 retainedFailureRecords=@('tests/energy-v2.trx','energy-v2.log','auto-scales/native.log','offner-holdouts/decenter-minus6/data.json','holdout-v1.log')
 boundaries=@{fullRepositorySuiteRun=$false;fullDebugSuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false;generalNativeBoundaryConventionCertified=$false}
}
$proof|ConvertTo-Json -Depth 50|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 50|Set-Content (Join-Path $repo 'docs/validation/FFT_CUMULATIVE_BOUNDARY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified Release 910, focused Debug 197, comparison 5 per configuration, 48+6 comparisons, 98 diagnostic attempts, preserved fixtures and archives.'
