using OpticalSystemDesign.Core.Domain;

namespace OpticalSystemDesign.Core.Analysis;

public static partial class DiffractionEngine
{
    internal static (Wavelength Wavelength, PsfResult Result)[] ComputeFftCumulativeEnergySpectrum(
        Optic optic, (double Hx, double Hy) field, IReadOnlyList<Wavelength> wavelengths,
        int pupilSampling, bool ignoreOpd)
    {
        var reference = optic.Wavelengths.FirstOrDefault(w => w.IsPrimary) ?? optic.Wavelengths[0];
        var longest = wavelengths.MaxBy(w => w.Nanometers)!;
        var scaleWave = wavelengths.Count == 1 ? reference : longest;
        // Work in the shared tracer's millimeters. The inverse normalized
        // frequency defines pupil coordinates directly; reconstructing them
        // through a rounded grid stretch changes circular boundary nodes.
        var referenceFNumber = WorkingFNumber(optic, field, scaleWave, optic.RayAimingEnabled);
        var pitchMillimeters = (longest.Micrometers * .001 / Math.Sqrt(pupilSampling)) * referenceFNumber;
        if (pupilSampling >= 128)
        {
            // Retain the established high-sampling interval convention. An
            // unconditional exact-square-root substitution changes four rim
            // nodes and regresses an already passing annular-pupil control.
            // Higher-sampling boundary parity remains explicitly uncertified.
            pitchMillimeters = longest.Micrometers * referenceFNumber * (pupilSampling - 2)
                / (2 * pupilSampling * Math.Sqrt(pupilSampling / 4d - 1)) * .001;
        }
        var pitch = pitchMillimeters * 1000;
        var sphere = WavefrontEngine.CreateChiefRayReferenceSphere(optic, field, reference, optic.RayAimingEnabled);
        return wavelengths.Select(wave =>
        {
            var fNumber = WorkingFNumber(optic, field, wave, optic.RayAimingEnabled);
            // The image pitch uses the system's RMS cone, while each pupil axis
            // uses its own mean marginal NA. Combining those axes before tracing
            // changes the aperture support for asymmetric cones.
            var axes = WorkingFNumbers(optic, field, wave, optic.RayAimingEnabled, zemaxDirectionalAverage: true);
            var stepX = CoordinateStep(axes.Sagittal);
            var stepY = CoordinateStep(axes.Tangential);
            var grid = new PupilGridSpecification(pupilSampling, true, true, stepX * (pupilSampling / 2d - 1))
            {
                ExplicitCoordinateStep = stepX,
                ExplicitCoordinateStepY = stepY
            };
            return (wave, ComputeFftPsfCore(
                optic, field, wave, pupilSampling, 2 * pupilSampling, false, true, 0,
                null, null, true, ignoreOpd, optic.RayAimingEnabled, reference,
                pitch, true, out _, sphere, grid));

            double CoordinateStep(double axisFNumber)
            {
                // Preserve a circular cone when the apparent axis difference is
                // only roundoff from taking and recombining square roots.
                if (Math.Abs(axisFNumber - fNumber) <= 1e-14 * fNumber) axisFNumber = fNumber;
                return 1 / (pupilSampling * pitchMillimeters / (wave.Micrometers * .001) / axisFNumber);
            }
        }).ToArray();
    }
}
