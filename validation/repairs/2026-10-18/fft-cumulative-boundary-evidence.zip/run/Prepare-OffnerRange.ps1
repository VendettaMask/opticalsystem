$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'offner-range';New-Item -ItemType Directory -Path $out|Out-Null
$template=Get-Content (Join-Path $PSScriptRoot 'auto-scales-v2/0592-n64-fft-wfno.json') -Raw|ConvertFrom-Json
$jobs=@()
foreach($shift in @(1e-9,1e-8,1e-6,2e-5,3.8e-5,3.9e-5,4e-5,4.02e-5,4.03e-5,4.04e-5,4.1e-5,5e-5,1e-4)){
 $r=($template|ConvertTo-Json -Depth 30)|ConvertFrom-Json
 $delta=$template.imageDeltaMicrometers*(1+$shift)
 $r.imageDeltaMicrometers=$delta;$r.zemaxSettings.ImageDelta=$delta
 $id='shift-'+$shift.ToString('G17').Replace('-','m').Replace('.','p').Replace('+','')
 $path=Join-Path $out ($id+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$id;request=$path;output=(Join-Path $out $id)}
}
$r=Get-Content (Join-Path $PSScriptRoot '../dee-multi-lens-20261018/boundary-request-0592-offner-relay-c1-primary-f1-w1-diffraction-encircled-energy.json') -Raw|ConvertFrom-Json
$r.rayAuditInputs=@(@{hx=0;hy=0;px=0;py=0;fieldIndex=0;pupilIndex=0},@{hx=0;hy=0;px=0;py=1;fieldIndex=0;pupilIndex=1},@{hx=0;hy=0;px=0;py=-1;fieldIndex=0;pupilIndex=2},@{hx=0;hy=0;px=1;py=0;fieldIndex=0;pupilIndex=3},@{hx=0;hy=0;px=-1;py=0;fieldIndex=0;pupilIndex=4})
$path=Join-Path $out 'offner-axes.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
$jobs+=@{id='offner-axes';request=$path;output=(Join-Path $out 'offner-axes')}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $out 'native-jobs.json') -Encoding utf8NoBOM
