$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$out=Join-Path $PSScriptRoot 'auto-scales-v2'
New-Item -ItemType Directory -Path $out | Out-Null
$jobs=@()
$map=@{'0014'=10.029697246753685;'0308'=5.021024982568069;'0360'=11.682840966966962;'0472'=11.398160910924126;'0592'=2.665643730133299;'0852'=2.7434589607196793}
$base=Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout'
foreach($code in @('0014','0308','0360','0472','0592','0852','relay64-minus','relay64-plus')){
 foreach($n in @($(if($code -in '0360','0472'){64,128}else{64}))){
  $original=if($code.StartsWith('relay64-')){Join-Path $PSScriptRoot ('requests/'+$code+'/dee.json')}else{Join-Path $base ($code+'-n'+$n+'/request.json')}
  $r=Get-Content $original -Raw|ConvertFrom-Json
  $r.canonicalAnalysisKey='Huygens PSF';$r.analysisType='HuygensPsf';$r.imageSampling=32;$r.imageDeltaMicrometers=0
  $r.zemaxSettings=[ordered]@{Normalize=$false;PupilSampleSize="S_$n`x$n";ImageSampleSize='S_32x32';ImageDelta=0;Wavelength=$r.wavelength;UseCentroid=$false;Configuration=1;Rotation='Rotate_0';Type='Linear';Field=$r.field;UsePolarization=$false}
  $id=$code+'-n'+$n+'-huygens-auto';$file=Join-Path $out ($id+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $file -Encoding utf8NoBOM
  $jobs+=@{id=$id;request=$file;output=(Join-Path $out $id)}
  if($map.ContainsKey($code)){
   $r=Get-Content $original -Raw|ConvertFrom-Json
   $source=Get-Content $r.input
   $waveLine=@($source|Where-Object {$_ -match "^WAVM $($r.wavelength) "})[0];$lambda=[double]($waveLine -split '\s+')[2]
   $delta=$lambda*$map[$code]/[Math]::Sqrt($n)
   $r.canonicalAnalysisKey='PSF';$r.analysisType='FftPsf';$r.imageDeltaMicrometers=$delta
   $r.zemaxSettings=[ordered]@{Normalize=$false;OutputSize="PsfS_$($r.imageSampling)x$($r.imageSampling)";SampleSize="PsfS_$n`x$n";ImageDelta=$delta;Wavelength=$r.wavelength;Surface=-1;Rotation='CW0';Type='Linear';Field=$r.field;UsePolarization=$false}
   $id=$code+'-n'+$n+'-fft-wfno';$file=Join-Path $out ($id+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $file -Encoding utf8NoBOM
   $jobs+=@{id=$id;request=$file;output=(Join-Path $out $id)}
  }
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content -LiteralPath (Join-Path $out 'native-jobs.json') -Encoding utf8NoBOM
