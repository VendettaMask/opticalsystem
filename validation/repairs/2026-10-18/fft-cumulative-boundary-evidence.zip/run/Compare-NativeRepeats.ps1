$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$old=Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout'
$previous=Join-Path $repo 'artifacts/validation/dee-multi-lens-20261018/perturbed'
$map=@{relay64=(Join-Path $old '0472-n64');relay128=(Join-Path $old '0472-n128');offner64=(Join-Path $old '0592-n64');annular128=(Join-Path $old '0360-n128');'relay64-minus'=(Join-Path $previous '0472-minus');'relay64-plus'=(Join-Path $previous '0472-plus')}
$rows=foreach($id in $map.Keys|Sort-Object){
 $before=Join-Path $map[$id] 'data.json';$after=Join-Path $PSScriptRoot ('native/'+$id+'-dee/data.json')
 $a=Get-Content $before -Raw|ConvertFrom-Json;$b=Get-Content $after -Raw|ConvertFrom-Json
 if($a.dataSeries.Count -ne 2 -or $b.dataSeries.Count -ne 2){throw 'Native repeat curves incomplete'}
 $maxX=0.;$maxY=0.;$count=0
 for($s=0;$s -lt 2;$s++){
  if($a.dataSeries[$s].x.Count -ne 401 -or $b.dataSeries[$s].x.Count -ne 401){throw 'Native repeat sampling differs'}
  for($i=0;$i -lt 401;$i++){$maxX=[Math]::Max($maxX,[Math]::Abs($a.dataSeries[$s].x[$i]-$b.dataSeries[$s].x[$i]));$maxY=[Math]::Max($maxY,[Math]::Abs($a.dataSeries[$s].y[$i][0]-$b.dataSeries[$s].y[$i][0]));$count++}
 }
 if($maxX -ne 0 -or $maxY -ne 0){throw 'Frozen native repeat changed'}
 @{id=$id;beforeSha256=(Get-FileHash $before).Hash.ToLowerInvariant();afterSha256=(Get-FileHash $after).Hash.ToLowerInvariant();samplePairs=$count;maximumXChange=$maxX;maximumYChange=$maxY}
}
ConvertTo-Json -InputObject @($rows) -Depth 8|Set-Content (Join-Path $PSScriptRoot 'native-repeat-comparison.json') -Encoding utf8NoBOM
'Six complete native repeated controls agree point for point.'
