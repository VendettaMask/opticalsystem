$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$out=Join-Path $PSScriptRoot 'offner-holdouts';New-Item -ItemType Directory -Path $out|Out-Null
$source=Get-Content (Join-Path $repo 'artifacts/zemax-standard-samples/20261015/full-matrix-v1/sources/offner-relay.zmx') -Raw
if([regex]::Matches($source,'(?m)^  PARM 2 -3\r?$').Count -ne 1){throw 'Unexpected coordinate break prescription'}
$jobs=@()
foreach($d in @(@{id='decenter-minus1p5';y='-1.5'},@{id='decenter-plus3';y='3'},@{id='decenter-minus6';y='-6'})){
 $lens=Join-Path $out ($d.id+'.zmx');[IO.File]::WriteAllText($lens,[regex]::Replace($source,'(?m)^  PARM 2 -3(?=\r?$)',('  PARM 2 '+$d.y)))
 $r=Get-Content (Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout/0592-n64/request.json') -Raw|ConvertFrom-Json
 $r.input=$lens;$path=Join-Path $out ($d.id+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$d.id;request=$path;output=(Join-Path $out $d.id)}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $out 'native-jobs.json') -Encoding utf8NoBOM
