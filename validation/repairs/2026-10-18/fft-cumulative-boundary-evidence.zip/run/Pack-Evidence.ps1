$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$target=Join-Path $repo 'validation/repairs/2026-10-18/fft-cumulative-boundary-evidence.zip'
if(Test-Path -LiteralPath $target){throw 'Never replace a frozen evidence archive'}
$payload=@{}
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -File -Recurse){
 $relative=[IO.Path]::GetRelativePath($PSScriptRoot,$file.FullName).Replace('\','/')
 if($relative -match '(^|/)(bin|obj)/' -or $relative -in 'manual-excerpts.txt','archive-validation.log','archive-result.json'){continue}
 if($relative -match '^(formal-v1|formal-v3|holdout-v1)/' -and $relative -notmatch '/summary\.json$'){continue}
 $payload['run/'+$relative]=$file.FullName
}
foreach($relative in Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')){$payload['source/'+$relative]=Join-Path $repo $relative}
foreach($relative in @('tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj','tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json','AGENTS.md')){$payload['source/'+$relative]=Join-Path $repo $relative}
foreach($name in @('multi-lens-dee-zemax-2026-r1.zip','fft-cumulative-directional-zemax-2026-r1.zip','fft-cumulative-boundary-perturb-zemax-2026-r1.zip')){$payload['fixtures/'+$name]=Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name)}
$payload['baseline/formal-before-summary.json']=Join-Path $repo 'artifacts/validation/dee-multi-lens-20261018/formal-v4/summary.json'
$payload['report/FFT_CUMULATIVE_BOUNDARY_REPAIR_2026-10-18.md']=Join-Path $repo 'docs/FFT_CUMULATIVE_BOUNDARY_REPAIR_2026-10-18.md'
$records=@()
$stream=[IO.File]::Open($target,[IO.FileMode]::CreateNew)
try{
 $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
 try{
  foreach($key in @($payload.Keys|Sort-Object)){
   $bytes=[IO.File]::ReadAllBytes($payload[$key]);$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($bytes))
   $entry=$zip.CreateEntry($key,[IO.Compression.CompressionLevel]::Optimal);$entryStream=$entry.Open();try{$entryStream.Write($bytes)}finally{$entryStream.Dispose()}
   $records+=@{path=$key;bytes=$bytes.Length;sha256=$hash}
  }
  $manifest=@{schemaVersion=1;scope='Final Relay 64/128 and Offner 64 FFT cumulative energy repair';entries=$records;excluded='Build intermediates, duplicate intermediate formal payloads, installed manual text excerpts and this packaging log'}|ConvertTo-Json -Depth 10
  $entry=$zip.CreateEntry('manifest.json',[IO.Compression.CompressionLevel]::Optimal);$entryStream=$entry.Open();try{$entryStream.Write([Text.Encoding]::UTF8.GetBytes($manifest))}finally{$entryStream.Dispose()}
 }finally{$zip.Dispose()}
}finally{$stream.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($target)
try{
 if($zip.Entries.Count -ne $records.Count+1){throw 'Archive entry inventory differs'}
 foreach($record in $records){$stream=$zip.GetEntry($record.path).Open();try{$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($hash -ne $record.sha256){throw 'Archive readback hash mismatch'}}
}finally{$zip.Dispose()}
$result=@{path='validation/repairs/2026-10-18/fft-cumulative-boundary-evidence.zip';sha256=(Get-FileHash -LiteralPath $target).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $target).Length;entries=$records.Count+1;payloadEntries=$records.Count;allPayloadHashesVerified=$true}
$result|ConvertTo-Json -Depth 8|Set-Content (Join-Path $PSScriptRoot 'archive-result.json') -Encoding utf8NoBOM
$ledger=Join-Path $repo 'docs/validation/FFT_CUMULATIVE_BOUNDARY_REPAIR_2026-10-18.json'
$proof=Get-Content (Join-Path $PSScriptRoot 'proof.json') -Raw|ConvertFrom-Json
$proof|Add-Member -NotePropertyName evidenceArchive -NotePropertyValue $result
$proof|ConvertTo-Json -Depth 50|Set-Content -LiteralPath $ledger -Encoding utf8NoBOM
$result|ConvertTo-Json
