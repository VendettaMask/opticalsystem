$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadJson([string]$relative){Get-Content (Join-Path $PSScriptRoot $relative) -Raw|ConvertFrom-Json}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/HIGH_SAMPLING_ENERGY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$unchangedTests=@($previous.sourceFiles|Where-Object {$_.path -like 'tests/*.cs'})
foreach($s in $unchangedTests){if((Hash (Join-Path $repo $s.path)) -ne $s.sha256){throw 'Previously verified test source changed'}}
$release=Tests 'related-release-final.trx';$debug=Tests 'related-debug-final.trx'
foreach($run in @($release,$debug)){
 if($run.passed -ne $run.total -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Final main tests incomplete'}
 if(@($run.names|Where-Object {$_ -match '\.FNumberPerturbationEnergyTests\.'}).Count -ne 10){throw 'Ten new precision checks missing'}
}
if($release.total -ne 946 -or $debug.total -ne 233){throw 'Final test scope differs'}
foreach($name in $previous.verification.testRelease.names){if($name -cnotin $release.names){throw 'Prior Release test missing'}}
foreach($name in $previous.verification.testDebug.names){if($name -cnotin $debug.names){throw 'Prior Debug test missing'}}
foreach($name in $debug.names){if($name -cnotin $release.names){throw 'Debug identity absent from Release'}}
$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx'
foreach($run in @($comparisonRelease,$comparisonDebug)){if($run.total -ne 5 -or $run.passed -ne 5 -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Comparison tests incomplete'}}
$beforeTests=Tests 'fnum-before.trx'
if($beforeTests.total -ne 10 -or $beforeTests.failed -ne 6 -or $beforeTests.passed -ne 4 -or $beforeTests.skipped -ne 0){throw 'Before counterexample differs'}
$beforeHash=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeHash -ne $previous.verification.configurations[0].coreCopies[0].sha256){throw 'Wrong before Core'}
$configurations=foreach($configuration in @('Release','Debug')){
 $log=Get-Content (Join-Path $PSScriptRoot ('build-'+$configuration.ToLowerInvariant()+'-final.log')) -Raw
 if(@($log -split "`n"|Where-Object {$_ -match ' -> '}).Count -ne 19 -or !$log.Contains('0 个警告') -or !$log.Contains('0 个错误')){throw 'Default solution build incomplete'}
 $paths=@("src/OpticalSystemDesign.Core/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tools/OpticalSystemDesign.ZemaxComparison/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll")
 $copies=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
 if(@($copies.sha256|Sort-Object -Unique).Count -ne 1 -or (Hash (Join-Path $PSScriptRoot ('Core.'+$configuration.ToLowerInvariant()+'-final.dll'))) -ne $copies[0].sha256){throw 'Default Core copies differ'}
 @{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies}
}
$after=ReadJson 'formal-final/summary.json';$extra=ReadJson 'extra-final/summary.json';$apo=ReadJson 'apochromat-final/summary.json';$prior=ReadJson 'prior-controls-final/summary.json';$new=ReadJson 'controls-final/summary.json';$newBefore=ReadJson 'controls-before/summary.json';$before=$previous.formalAfter
if($before.coreSha256 -ne $beforeHash -or $newBefore.coreSha256 -ne $beforeHash){throw 'Before comparison Core differs'}
foreach($s in @($after,$extra,$apo,$prior,$new)){
 if($s.coreSha256 -ne $configurations[0].coreCopies[0].sha256){throw 'Final comparison Core differs'}
 if($s.policySha256 -ne $before.policySha256 -or $s.policySha256 -ne (Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'))){throw 'Original tolerance policy changed'}
 if(@($s.rows|Where-Object conclusion -ne 'Pass').Count -ne 0){throw 'Formal control failed'}
}
if($after.rows.Count -ne 48 -or $after.excluded.Count -ne 0 -or $extra.rows.Count -ne 6 -or $extra.excluded.Count -ne 1 -or $apo.rows.Count -ne 5 -or $apo.excluded.Count -ne 2 -or $prior.rows.Count -ne 8 -or $prior.excluded.Count -ne 0 -or $new.rows.Count -ne 5 -or $new.excluded.Count -ne 0){throw 'Comparison inventory differs'}
foreach($pair in @(@($after,$before),@($extra,$previous.independentControls),@($apo,$previous.priorApochromatControls),@($prior,$previous.newControlsAfter),@($new,$newBefore))){foreach($row in $pair[0].rows){
 $original=@($pair[1].rows|Where-Object id -ceq $row.id)
 if($original.Count -ne 1 -or $row.sourceSha256 -ne $original[0].sourceSha256 -or $row.executedRequestSha256 -ne $original[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $original[0].nativeDataSha256){throw 'Source/request/native reference changed'}
}}
$oldControls=@(ReadJson 'old-numerical-controls.json')
if($oldControls.Count -ne 67 -or @($oldControls|Where-Object {$null -eq $_.afterWorstNrmse -or $_.afterWorstNrmse -gt $_.beforeWorstNrmse+1e-8}).Count -ne 0){throw 'Old numerical controls regressed'}
foreach($r in $new.rows){if(@($r.metrics|Where-Object {$_.nrmse -ge 1e-8}).Count -ne 0){throw 'New precision target not closed'}}
$archives=@{};foreach($p in $previous.preservedArchives.PSObject.Properties){$archives[$p.Name]=$p.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen evidence archive changed'}}
if($archives.Count -ne 15){throw 'Expected fifteen prior archives'}
$fixtures=@{};foreach($p in $previous.preservedNativeFixtures.PSObject.Properties){$fixtures[$p.Name]=$p.Value};foreach($f in $previous.newFixtures){$fixtures[$f.name]=$f.sha256}
foreach($name in $fixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $fixtures[$name]){throw 'Frozen native fixture changed'}}
if($fixtures.Count -ne 9){throw 'Expected nine prior native fixtures'}
$fixturePath=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-fnum-perturb-zemax-2026-r1.zip';$zip=[IO.Compression.ZipFile]::OpenRead($fixturePath)
try{
 $reader=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open());try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
 foreach($e in $manifest.entries){$stream=$zip.GetEntry($e.path).Open();try{$h=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($h -ne $e.sha256){throw 'New fixture payload changed'}}
 if($manifest.cases.Count -ne 5 -or $manifest.excluded.Count -ne 0){throw 'New fixture inventory differs'}
 $fixture=@{name=[IO.Path]::GetFileName($fixturePath);sha256=Hash $fixturePath;cases=5;excluded=@();payloadEntries=$manifest.entries.Count}
}finally{$zip.Dispose()}
$captures=@();$dee=0;$grids=0;$rays=0
foreach($list in @('native-jobs.json','fft-diagnostic/native-jobs.json')){foreach($job in @(ReadJson $list)){
 $request=Get-Content $job.request -Raw|ConvertFrom-Json;$batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json;if($batch.exitCode -ne 0){throw 'Native execution error'}
 $envData=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
 if($envData.major -ne 26 -or $envData.minor -ne 1 -or $envData.opticStudioVersion -ne 260127 -or !$envData.validLicense){throw 'Native version/license differs'}
 if($request.adapter -eq 'ray-audit'){
  $data=Get-Content (Join-Path $job.output 'ray-audit.json') -Raw|ConvertFrom-Json
  if($data.inputs.Count -ne 9 -or $data.launches.Count -ne 9 -or @($data.launches|Where-Object success -ne $true).Count -ne 0){throw 'Native launch audit incomplete'}
  foreach($surface in $data.surfaces){if($surface.rays.Count -ne 9 -or @($surface.rays|Where-Object error -ne 0).Count -ne 0){throw 'Native ray audit incomplete'}};$rays++
 }else{
  $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
  if($request.analysisType -eq 'DiffractionEncircledEnergy'){
   if($data.dataSeries.Count -ne 2){throw 'Native energy curve pair missing'}
   foreach($s in $data.dataSeries){if($s.x.Count -ne 401 -or $s.y.Count -ne 401){throw 'Native energy samples missing'};foreach($y in $s.y){if($y.Count -ne 1 -or ![double]::IsFinite($y[0]) -or $y[0] -lt 0 -or $y[0] -gt 1){throw 'Invalid native energy value'}}};$dee++
  }else{
   if($data.dataGrids.Count -ne 1){throw 'Native PSF grid missing'};$g=$data.dataGrids[0]
   if($g.nx -ne $request.imageSampling -or $g.ny -ne $request.imageSampling -or $g.values.Count -ne $g.ny -or $g.dx -le 0 -or $g.dy -le 0){throw 'PSF axes invalid'}
   foreach($y in $g.values){if($y.Count -ne $g.nx){throw 'PSF row incomplete'};foreach($v in $y){if(![double]::IsFinite($v) -or ($request.zemaxSettings.Type -eq 'Linear' -and $v -lt 0)){throw 'Invalid PSF value'}}};$grids++
  }
 }
 $files=@(Get-ChildItem -LiteralPath $job.output -File|ForEach-Object {@{name=$_.Name;bytes=$_.Length;sha256=Hash $_.FullName}})
 $captures+=@{id=$job.id;state='Usable';group=$list;requestSha256=Hash $job.request;sourceSha256=Hash $request.input;files=$files}
}}
if($captures.Count -ne 10 -or $dee -ne 5 -or $grids -ne 4 -or $rays -ne 1){throw 'Native inventory differs'}
$repeatReference='artifacts/validation/dee-perturb128-20261018/native/base-fnum-minus/data.json'
$a=ReadJson 'native/fnum-minus128/data.json';$b=Get-Content (Join-Path $repo $repeatReference) -Raw|ConvertFrom-Json
for($c=0;$c -lt 2;$c++){for($i=0;$i -lt 401;$i++){if($a.dataSeries[$c].x[$i] -ne $b.dataSeries[$c].x[$i] -or $a.dataSeries[$c].y[$i][0] -ne $b.dataSeries[$c].y[$i][0]){throw 'Native repeat differs'}}}
$supportBefore=ReadJson 'support-before.json';$supportAfter=ReadJson 'support-final.json';$nativeSupport=ReadJson 'native-inverted-pupil.json'
if($supportBefore.coreSha256 -ne $beforeHash -or $supportAfter.coreSha256 -ne $after.coreSha256){throw 'Support diagnosis uses a different Core'}
foreach($pair in @(@('fnum-minus64',193,197),@('fnum-minus128',401,405),@('fnum-minus256',793,797))){
 $a=$supportBefore.rows|Where-Object id -ceq $pair[0];$b=$supportAfter.rows|Where-Object id -ceq $pair[0]
 if(!$a.adjacentMoments -or !$b.adjacentMoments -or [Math]::Abs($a.count-$pair[1]) -gt 1e-8 -or [Math]::Abs($b.count-$pair[2]) -gt 1e-8){throw 'Target pupil support differs'}
 foreach($key in @('coneRms','tangentialMean','sagittalMean','rmsF','meanF')){if($a.$key -ne $b.$key){throw 'Optical cone scalars changed'}}
}
if($nativeSupport.count -ne 405 -or $nativeSupport.complexIntensityError -gt 1e-14){throw 'Native inverse FFT support differs'}
$sourceFiles=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}});if($sourceFiles.Count -ne 38){throw 'Current C# inventory differs'}
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log');if($LASTEXITCODE -ne 0){throw 'Whitespace check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='123456 FNUM=2.699999999999987 at 64/128/256 and two non-primary wavelength controls, original policy and all prior tests retained'
 beforeCoreSha256=$beforeHash;beforeTests=$beforeTests
 constraints=@{originalTolerancePolicyUnchanged=$true;all67PriorFormalPassesPreserved=$true;prior936ReleaseIdentitiesPreserved=$true;prior223FocusedDebugIdentitiesPreserved=$true;unchangedPriorTestSources=$unchangedTests;independentCookeTessarExcluded=$true}
 verification=@{testRelease=$release;testDebug=$debug;debugScope='Prior focused 223 plus ten new precision checks';comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;configurations=$configurations;newMainTests=10;format=@{includedCSharpFiles=38;exitCode=0;log='format-verify.log'};gitDiffCheckExitCode=0}
 formalBefore=$before;formalAfter=$after;independentControls=$extra;priorApochromatControls=$apo;priorHighSamplingControls=$prior;newControlsBefore=$newBefore;newControlsAfter=$new;oldNumericalControls=$oldControls
 supportProof=@{before=$supportBefore;after=$supportAfter;native=$nativeSupport;nativeRepeat=@{id='fnum-minus128';maximumPointDifference=0;reference=$repeatReference};note='Native complex FFT inversion is captured at n128; n64/n256 product support counts are energy-derived diagnostics backed by their captured DEE curves'}
 numericalLimitations=@{allNativeBoundaryResidualsZero=$false;capturedFNumberPerturbationClosed=$true;originalMatrixWorstNrmse=($after.rows.metrics|Measure-Object nrmse -Maximum).Maximum;samplingScope='Captured FNUM-minus settings certified at 64/128/256, non-primary wavelength controls at 128; no general all-lens/all-sampling boundary certification'}
 preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@($fixture)
 nativeCaptureSummary=@{attempts=10;usableCaptures=10;deeCaptures=5;psfCaptures=4;rayAudits=1;requestErrors=0;nativeUnavailable=0;note='Includes one repeat and auxiliary Huygens/complex FFT, not ten lens certifications'};nativeCaptures=$captures;sourceFiles=$sourceFiles
 retainedFailureRecords=@('tests/fnum-before.trx','tests-before.log')
 interruptedRuns=@(@{log='comparison-debug-unfiltered-interrupted.log';reason='Unfiltered comparator invocation interrupted; final Debug acceptance rerun with the same five test identities as Release';countsAsAcceptance=$false})
 boundaries=@{fullRepositorySuiteRun=$false;fullDebugSuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false;generalNativeBoundaryConventionCertified=$false}
}
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $repo 'docs/validation/FNUMBER_PERTURBATION_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified FNUM closure, 48+6+5+8+5 original-policy passes, 946/233 tests, and preserved sources/references/archives/fixtures.'
