using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-fnum128-20261018");
if(args.Length>1 && args[1]=="invert"){
 const string id="fnum-minus128";
 using var re=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic",id+"-Real/data.json")));
 using var im=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic",id+"-Imaginary/data.json")));
 using var li=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic",id+"-Linear/data.json")));
 var rg=re.RootElement.GetProperty("dataGrids")[0];var ig=im.RootElement.GetProperty("dataGrids")[0];var lg=li.RootElement.GetProperty("dataGrids")[0];int m=rg.GetProperty("nx").GetInt32();var pupil=new System.Numerics.Complex[m,m];double error=0;
 for(int y=0;y<m;y++)for(int x=0;x<m;x++){var v=new System.Numerics.Complex(rg.GetProperty("values")[y][x].GetDouble(),ig.GetProperty("values")[y][x].GetDouble());pupil[(y+1)%m,(x+1)%m]=v;error=Math.Max(error,Math.Abs(v.Magnitude*v.Magnitude-lg.GetProperty("values")[y][x].GetDouble()));}
 DiffractionEngine.FourierTransform2D(pupil,true);var max=pupil.Cast<System.Numerics.Complex>().Max(v=>v.Magnitude);var nodes=new List<object>();
 for(int y=0;y<m;y++)for(int x=0;x<m;x++)if(pupil[y,x].Magnitude>max*.5)nodes.Add(new{x=x<m/2?x:x-m,y=y<m/2?y:y-m,amplitude=pupil[y,x].Magnitude/max,phase=pupil[y,x].Phase});
 File.WriteAllText(Path.Combine(task,"native-inverted-pupil.json"),JsonSerializer.Serialize(new{id,count=nodes.Count,complexIntensityError=error,spacing=rg.GetProperty("dx").GetDouble(),nodes}));Console.WriteLine($"Native count {nodes.Count}, complex consistency {error:R}");return;
}
if(args.Length>1 && args[1]=="support"){
 var records=new List<object>();using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"dee-jobs.json")));
 foreach(var job in jobs.RootElement.EnumerateArray()){
  using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=request.RootElement;var id=job.GetProperty("id").GetString()!;var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=true;
  var wave=optic.Wavelengths[r.GetProperty("wavelength").GetInt32()-1];var n=r.GetProperty("pupilSampling").GetInt32();var method=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;var cone=((double Rms,double T,double S))method.Invoke(null,new object[]{optic,(0d,0d),wave})!;
  var psf=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),new[]{wave},n,true)[0].Result;
  records.Add(new{id,n,coneRms=cone.Rms,tangentialMean=cone.T,sagittalMean=cone.S,rmsF=.5/cone.Rms,meanF=.5/cone.T,adjacentMoments=cone.T==cone.S && Math.BitIncrement(cone.T)==cone.Rms,count=100d*4*n*n/psf.Values.Cast<double>().Sum(),spacing=psf.SampleSpacingMicrometers});
 }
 var proof=new{coreSha256=Convert.ToHexStringLower(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(DiffractionEngine).Assembly.Location))),rows=records};File.WriteAllText(Path.Combine(task,args[2]),JsonSerializer.Serialize(proof));return;
}
var coneMethod=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
var rows=new List<object>();
foreach(var relative in new[]{"numerical-residuals-20261018/holdout-jobs.json","numerical-residuals-20261018/old-ms-l7-jobs.json","dee-multi-lens-20261018/perturbed/native-jobs.json","dee-apochromat128-20261018/native-jobs.json","dee-perturb128-20261018/dee-jobs.json"}){
 using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(repo,"artifacts/validation",relative)));
 foreach(var job in jobs.RootElement.EnumerateArray()){
  using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=request.RootElement;var id=job.GetProperty("id").GetString()!;
  var wn=r.GetProperty("wavelength").GetInt32();var n=r.GetProperty("pupilSampling").GetInt32();if(wn==0)continue;
  var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");
  using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));
  optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
  var primary=optic.Wavelengths.First(w=>w.IsPrimary);var wave=optic.Wavelengths[wn-1];
  var scale=((double Rms,double T,double S))coneMethod.Invoke(null,new object[]{optic,(0d,0d),primary})!;var cone=((double Rms,double T,double S))coneMethod.Invoke(null,new object[]{optic,(0d,0d),wave})!;
  var fp=DiffractionEngine.WorkingFNumber(optic,(0,0),primary,optic.RayAimingEnabled);var f=DiffractionEngine.WorkingFNumber(optic,(0,0),wave,optic.RayAimingEnabled);
  var axes=DiffractionEngine.WorkingFNumbers(optic,(0,0),wave,optic.RayAimingEnabled,zemaxDirectionalAverage:true);
  var psf=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),new[]{wave},n,true)[0].Result;
  var variants=new List<object>();
  if(cone.T==cone.S && Math.BitIncrement(cone.T)==cone.Rms){
   var step=(scale.Rms/cone.Rms)/Math.Sqrt(n);
   var grid=new PupilGridSpecification(n,true,true,step*(n/2d-1)){ExplicitCoordinateStep=step};
   var count=0;for(int y=0;y<n;y++)for(int x=0;x<n;x++){var xx=grid.Coordinate(x);var yy=grid.YCoordinate(y);if(xx*xx+yy*yy<=1)count++;}
   variants.Add(new{canonical=true,count,step});
  }
  foreach(var snap in new[]{false,true}){
   var pitch=Math.Sqrt(1d/n)/(2*scale.Rms/wave.Micrometers);var auto=Math.Sqrt(n/32d);
   double Stretch(double na){
    if(snap && cone.T==cone.S && Math.BitIncrement(na)==cone.Rms)na=cone.Rms;
    var af=.5/na;
    if(n<128)return auto*(wave.Micrometers*af*(n-2)/(2*n*auto))/pitch;
    var dp=wave.Micrometers*f*(n-2)/(2*n*auto);return (auto*dp/pitch/f)*af;
   }
   var grid=new PupilGridSpecification(n,true,true,Stretch(cone.S)){StretchY=Stretch(cone.T)};
   var count=0;for(int y=0;y<n;y++)for(int x=0;x<n;x++){var xx=grid.Coordinate(x);var yy=grid.YCoordinate(y);if(xx*xx+yy*yy<=1)count++;}
   variants.Add(new{snap,count});
  }
  foreach(var pitchMode in Enumerable.Range(0,9))foreach(var axisMode in Enumerable.Range(0,2)){
   var l=wave.Micrometers;var auto=Math.Sqrt(n/32d);
   var normalizedRms=scale.T==scale.S && Math.BitIncrement(scale.T)==scale.Rms?scale.T:scale.Rms;
   var pitch=pitchMode switch{0=>Math.Sqrt(1d/n)/(2*scale.Rms/l),1=>Math.Sqrt(1d/n)/(1/(l*fp)),2=>Math.Sqrt(1d/n)*(l*fp),3=>l*fp/Math.Sqrt(n),4=>Math.Sqrt(1d/n)/(1/(l*(.5/scale.Rms))),5=>Math.Sqrt(1d/n)*(l*(.5/scale.Rms)),6=>Math.Sqrt(1d/n)/(2*(.5/(.5/scale.Rms))/l),7=>Math.Sqrt(1d/n)/(2*normalizedRms/l),_=>Math.Sqrt(1d/n)/(2*(.5/scale.Rms==.5/scale.T && scale.T==scale.S?scale.T:scale.Rms)/l)};
   var dp=l*f*(n-2)/(2*n*auto);var extent=auto*dp/pitch/f;
   var fx=axisMode==0?.5/cone.S:axes.Sagittal;var fy=axisMode==0?.5/cone.T:axes.Tangential;
   var grid=new PupilGridSpecification(n,true,true,extent*fx){StretchY=extent*fy};
   var count=0;for(int y=0;y<n;y++)for(int x=0;x<n;x++){var xx=grid.Coordinate(x);var yy=grid.YCoordinate(y);if(xx*xx+yy*yy<=1)count++;}
   variants.Add(new{pitchMode,axisMode,pitch,count,sx=grid.Stretch,sy=grid.StretchY});
  }
  rows.Add(new{id,n,lambda=wave.Micrometers,rms=cone.Rms,scaleRms=scale.Rms,t=cone.T,s=cone.S,f,fp,ft=axes.Tangential,fs=axes.Sagittal,currentCount=100d*4*n*n/psf.Values.Cast<double>().Sum(),variants});
 }
}
File.WriteAllText(Path.Combine(task,"legacy-fft-cones.json"),JsonSerializer.Serialize(rows));
