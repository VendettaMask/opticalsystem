$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$template=Join-Path $repo 'artifacts/validation/dee-perturb128-20261018/requests/base-fnum-minus/dee.json'
$jobs=@();$deeJobs=@()
foreach($id in @('fnum-minus128','fnum-minus64','fnum-minus256','fnum-minus-wave1','fnum-minus-wave3')){
 $r=Get-Content $template -Raw|ConvertFrom-Json
 if($id -eq 'fnum-minus64' -or $id -eq 'fnum-minus256'){
  $n=if($id -eq 'fnum-minus64'){64}else{256};$r.pupilSampling=$n;$r.imageSampling=2*$n;$r.workbenchSettings.PupilSampling="$n";$r.workbenchSettings.ImageSampling="$($n*2)";$r.zemaxSettings.SampleSize="S_$n`x$n"
 }
 if($id.Contains('wave')){$w=[int]$id.Substring($id.Length-1);$r.wavelength=$w;$r.workbenchSettings.WavelengthNumber="$w";$r.zemaxSettings.Wavelength=$w}
 $dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir|Out-Null
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $j=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))};$jobs+=$j;$deeJobs+=$j
 if($id -eq 'fnum-minus128'){
  $r.canonicalAnalysisKey='Huygens PSF';$r.analysisType='HuygensPsf';$r.imageSampling=32;$r.imageDeltaMicrometers=0
  $r.zemaxSettings=[ordered]@{Normalize=$false;PupilSampleSize='S_128x128';ImageSampleSize='S_32x32';ImageDelta=0;Wavelength=$r.wavelength;UseCentroid=$false;Configuration=1;Rotation='Rotate_0';Type='Linear';Field=1;UsePolarization=$false}
  $path=Join-Path $dir 'huygens.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-huygens';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-huygens'))}
  $r=Get-Content (Join-Path $dir 'dee.json') -Raw|ConvertFrom-Json
  $r.adapter='ray-audit';$r|Add-Member removeVignettingFactors $false;$r|Add-Member surfaceRecordLimit 10000
  $inputs=@(@{px=0;py=0},@{px=0;py=1},@{px=0;py=-1},@{px=1;py=0},@{px=-1;py=0});$a=1/[Math]::Sqrt(2)
  foreach($x in @(-$a,$a)){foreach($y in @(-$a,$a)){$inputs+=@{px=$x;py=$y}}}
  for($i=0;$i -lt $inputs.Count;$i++){$inputs[$i].hx=0;$inputs[$i].hy=0;$inputs[$i].fieldIndex=0;$inputs[$i].pupilIndex=$i}
  $r|Add-Member rayAuditInputs $inputs;$path=Join-Path $dir 'rays.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-rays';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-rays'))}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($deeJobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'dee-jobs.json') -Encoding utf8NoBOM
