using OpticalSystemDesign.Core.Domain;

namespace OpticalSystemDesign.Core.Analysis;

public static partial class DiffractionEngine
{
    internal static (Wavelength Wavelength, PsfResult Result)[] ComputeFftCumulativeEnergySpectrum(
        Optic optic, (double Hx, double Hy) field, IReadOnlyList<Wavelength> wavelengths,
        int pupilSampling, bool ignoreOpd)
    {
        var reference = optic.Wavelengths.FirstOrDefault(w => w.IsPrimary) ?? optic.Wavelengths[0];
        var longest = wavelengths.MaxBy(w => w.Nanometers)!;
        var scaleWave = wavelengths.Count == 1 ? reference : longest;
        // Monochromatic expanded grids use their own cutoff. Keep the captured
        // common-grid convention below for a true polychromatic mixture.
        if (pupilSampling > 32 && wavelengths.Count == 1)
        {
            var scaleCone = CumulativeEnergyCone(optic, field, scaleWave);
            var cones = wavelengths.Select(wave => (Wave: wave, Cone: CumulativeEnergyCone(optic, field, wave))).ToArray();
            if (scaleCone is { } scale && cones.All(item => item.Cone.HasValue))
            {
                // The inverse cutoff sets image pitch. Scale the documented
                // default FFT grid to that pitch before generating coordinates;
                // canceling its stretch algebraically changes boundary nodes.
                var cutoff = 2 * scale.Rms / longest.Micrometers;
                // Form the normalized frequency interval before converting it
                // through the cutoff. Moving the square root into a rounded
                // denominator can drop diagonal rim nodes on expanded grids.
                var imagePitch = Math.Sqrt(1d / pupilSampling) / cutoff;
                var automaticStretch = Math.Sqrt(pupilSampling / 32d);
                var referenceSphere = WavefrontEngine.CreateChiefRayReferenceSphere(optic, field, reference, optic.RayAimingEnabled);
                return cones.Select(item =>
                {
                    var cone = item.Cone!.Value;
                    PupilGridSpecification pupilGrid;
                    if (cone.TangentialMean == cone.SagittalMean
                        && cone.Rms == Math.BitIncrement(cone.TangentialMean))
                    {
                        // Adjacent rounded moments of the same circular cone
                        // must not independently rescale its cutoff and rim.
                        // Use the common RMS cone's Fourier coordinate interval;
                        // retain that interval through tracing and FFT indexing.
                        var step = (scale.Rms / cone.Rms) / Math.Sqrt(pupilSampling);
                        pupilGrid = new(pupilSampling, true, true, step * (pupilSampling / 2d - 1))
                        {
                            ExplicitCoordinateStep = step
                        };
                    }
                    else
                    {
                        var stretchX = PupilStretch(cone.SagittalMean);
                        var stretchY = PupilStretch(cone.TangentialMean);
                        pupilGrid = new(pupilSampling, true, true, stretchX) { StretchY = stretchY };
                    }
                    return (item.Wave, ComputeFftPsfCore(optic, field, item.Wave, pupilSampling,
                        2 * pupilSampling, false, true, 0, null, null, true, ignoreOpd,
                        optic.RayAimingEnabled, reference, imagePitch, true, out _, referenceSphere, pupilGrid));

                    double PupilStretch(double numericalAperture)
                    {
                        var axisFNumber = .5 / numericalAperture;
                        if (pupilSampling >= 128)
                        {
                            // High sampling retains the shared FFT's default
                            // extent before changing its directional F-number.
                            // Rebuilding that extent from the directional cone
                            // directly changes diagonal boundary nodes.
                            var fftFNumber = WorkingFNumber(optic, field, item.Wave, optic.RayAimingEnabled);
                            var defaultFftPitch = item.Wave.Micrometers * fftFNumber * (pupilSampling - 2)
                                / (2 * pupilSampling * automaticStretch);
                            var extentPerFNumber = automaticStretch * defaultFftPitch / imagePitch / fftFNumber;
                            return extentPerFNumber * axisFNumber;
                        }
                        var defaultPitch = item.Wave.Micrometers * axisFNumber * (pupilSampling - 2)
                            / (2 * pupilSampling * automaticStretch);
                        return automaticStretch * defaultPitch / imagePitch;
                    }
                }).ToArray();
            }
        }
        // Work in the shared tracer's millimeters. The inverse normalized
        // frequency defines pupil coordinates directly; reconstructing them
        // through a rounded grid stretch changes circular boundary nodes.
        var referenceFNumber = WorkingFNumber(optic, field, scaleWave, optic.RayAimingEnabled);
        var pitchMillimeters = (longest.Micrometers * .001 / Math.Sqrt(pupilSampling)) * referenceFNumber;
        if (pupilSampling >= 128)
        {
            // Preserve the common-grid and unavailable-full-cone conventions.
            // Expanded single-wavelength grids with a full cone use the
            // cutoff/default-grid scaling path above.
            pitchMillimeters = longest.Micrometers * referenceFNumber * (pupilSampling - 2)
                / (2 * pupilSampling * Math.Sqrt(pupilSampling / 4d - 1)) * .001;
        }
        var pitch = pitchMillimeters * 1000;
        var sphere = WavefrontEngine.CreateChiefRayReferenceSphere(optic, field, reference, optic.RayAimingEnabled);
        return wavelengths.Select(wave =>
        {
            var fNumber = WorkingFNumber(optic, field, wave, optic.RayAimingEnabled);
            // The image pitch uses the system's RMS cone, while each pupil axis
            // uses its own mean marginal NA. Combining those axes before tracing
            // changes the aperture support for asymmetric cones.
            var axes = WorkingFNumbers(optic, field, wave, optic.RayAimingEnabled, zemaxDirectionalAverage: true);
            var stepX = CoordinateStep(axes.Sagittal);
            var stepY = CoordinateStep(axes.Tangential);
            var grid = new PupilGridSpecification(pupilSampling, true, true, stepX * (pupilSampling / 2d - 1))
            {
                ExplicitCoordinateStep = stepX,
                ExplicitCoordinateStepY = stepY
            };
            return (wave, ComputeFftPsfCore(
                optic, field, wave, pupilSampling, 2 * pupilSampling, false, true, 0,
                null, null, true, ignoreOpd, optic.RayAimingEnabled, reference,
                pitch, true, out _, sphere, grid));

            double CoordinateStep(double axisFNumber)
            {
                // Preserve a circular cone when the apparent axis difference is
                // only roundoff from taking and recombining square roots.
                if (Math.Abs(axisFNumber - fNumber) <= 1e-14 * fNumber) axisFNumber = fNumber;
                return 1 / (pupilSampling * pitchMillimeters / (wave.Micrometers * .001) / axisFNumber);
            }
        }).ToArray();
    }

    private static (double Rms, double TangentialMean, double SagittalMean)? CumulativeEnergyCone(
        Optic optic, (double Hx, double Hy) field, Wavelength wavelength)
    {
        if (!TryWorkingPupilDirections(optic, field, wavelength, optic.RayAimingEnabled, 1, out var directions)) return null;
        var chief = directions[0];
        var index = optic.SurfaceGroup.Items[^1].MaterialAfter.RefractiveIndex(wavelength.Nanometers);
        var numericalApertures = directions.Skip(1).Select(direction =>
            index * optic.Backend.Current.Cross(chief, direction).Length / (chief.Length * direction.Length)).ToArray();
        if (numericalApertures.Any(value => !double.IsFinite(value) || value <= 0)) return null;
        var rms = CumulativeEnergyRootMeanSquare(numericalApertures);
        // Retain the existing working-F-number cap through the fallback path.
        if (!double.IsFinite(rms) || .5 / rms > 10000) return null;
        return (rms, (numericalApertures[0] + numericalApertures[1]) / 2,
            (numericalApertures[2] + numericalApertures[3]) / 2);
    }
}
