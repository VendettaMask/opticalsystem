using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);
var task=Path.Combine(repo,"artifacts/validation/dee-apochromat128-20261018");
if(args.Length>1 && args[1]=="support") {
 using var r=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"requests/original/dee.json")));
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.RootElement.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=false;
 var wave=optic.Wavelengths[3];var result=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),new[]{wave},128,true)[0].Result;
 var sum=result.Values.Cast<double>().Sum();var count=(100d*256*256)/sum;
 var proof=new{coreSha256=Convert.ToHexStringLower(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(DiffractionEngine).Assembly.Location))),count,idealPeakNormalization=100,sum,spacing=result.SampleSpacingMicrometers};
 File.WriteAllText(Path.Combine(task,args[2]),JsonSerializer.Serialize(proof));Console.WriteLine(JsonSerializer.Serialize(proof));return;
}
if(args.Length>1 && args[1]=="invert") {
 using var re=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic/Real/data.json")));
 using var im=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic/Imaginary/data.json")));
 using var li=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"fft-diagnostic/Linear/data.json")));
 var rg=re.RootElement.GetProperty("dataGrids")[0];var ig=im.RootElement.GetProperty("dataGrids")[0];var lg=li.RootElement.GetProperty("dataGrids")[0];
 int m=rg.GetProperty("nx").GetInt32();var pupil=new System.Numerics.Complex[m,m];double complexError=0;
 for(int y=0;y<m;y++)for(int x=0;x<m;x++){
  var v=new System.Numerics.Complex(rg.GetProperty("values")[y][x].GetDouble(),ig.GetProperty("values")[y][x].GetDouble());
  pupil[(y+1)%m,(x+1)%m]=v;complexError=Math.Max(complexError,Math.Abs(v.Magnitude*v.Magnitude-lg.GetProperty("values")[y][x].GetDouble()));
 }
 DiffractionEngine.FourierTransform2D(pupil,true);var max=pupil.Cast<System.Numerics.Complex>().Max(v=>v.Magnitude);
 var nodes=new List<object>();for(int y=0;y<m;y++)for(int x=0;x<m;x++)if(pupil[y,x].Magnitude>max*.5)nodes.Add(new{x=x<m/2?x:x-m,y=y<m/2?y:y-m,amplitude=pupil[y,x].Magnitude/max,phase=pupil[y,x].Phase});
 var record=new{count=nodes.Count,complexIntensityError=complexError,spacing=rg.GetProperty("dx").GetDouble(),nodes};
 File.WriteAllText(Path.Combine(task,"native-inverted-pupil.json"),JsonSerializer.Serialize(record));Console.WriteLine($"Native pupil nodes={nodes.Count}, complex intensity error={complexError:R}");return;
}
var prior=Path.Combine(repo,"artifacts/validation/numerical-residuals-20261018");
var boundary=Path.Combine(repo,"artifacts/validation/dee-boundary-20261018");
var method=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
var rows=new List<object>();
var directionRows=new List<object>();
var alternativeRows=new List<object>();
foreach(var list in new[]{Path.Combine(prior,"holdout-jobs.json"),Path.Combine(repo,"artifacts/validation/dee-multi-lens-20261018/perturbed/native-jobs.json"),Path.Combine(boundary,"offner-holdouts/native-jobs.json"),Path.Combine(task,"native-jobs.json")}) {
 using var doc=JsonDocument.Parse(File.ReadAllText(list));
 foreach(var job in doc.RootElement.EnumerateArray()) {
  using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=request.RootElement;
  if(r.GetProperty("wavelength").GetInt32()==0)continue;
  var id=job.GetProperty("id").GetString()!;if(id.Contains("minus6"))continue;
  var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");
  using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));
  optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
  var primary=optic.Wavelengths.First(w=>w.IsPrimary);var wave=optic.Wavelengths[r.GetProperty("wavelength").GetInt32()-1];var n=r.GetProperty("pupilSampling").GetInt32();
  var tryDirections=typeof(DiffractionEngine).GetMethod("TryWorkingPupilDirections",BindingFlags.Static|BindingFlags.NonPublic)!;
  object?[] directionArgs={optic,(0d,0d),primary,optic.RayAimingEnabled,1d,null};tryDirections.Invoke(null,directionArgs);
  directionRows.Add(new{id,n,lambda=wave.Micrometers,directions=directionArgs[5]});
  var dirs=(OpticalSystemDesign.Core.Backend.Vector3D[])directionArgs[5]!;
  foreach(var formula in Enumerable.Range(0,5)) {
   var nas=dirs.Skip(1).Select(d=>{
    var cross=optic.Backend.Current.Cross(dirs[0],d).Length;var dot=optic.Backend.Current.Dot(dirs[0],d);var norm=dirs[0].Length*d.Length;
    return formula switch{0=>cross/norm,1=>Math.Sin(Math.Acos(Math.Clamp(dot/norm,-1,1))),2=>Math.Sin(Math.Atan2(cross,dot)),3=>Math.Sin(Math.Asin(Math.Clamp(cross/norm,-1,1))),_=>Math.Sqrt(Math.Max(0,1-Math.Pow(dot/norm,2)))};
   }).ToArray();
   var rms=DiffractionEngine.CumulativeEnergyRootMeanSquare(nas);var p=1/((2*rms/wave.Micrometers)*Math.Sqrt(n));var auto=Math.Sqrt(n/32d);
   double Stretch(double a)=>auto*(wave.Micrometers*(.5/a)*(n-2)/(2*n*auto))/p;
   var grid=new PupilGridSpecification(n,true,true,Stretch((nas[2]+nas[3])/2)){StretchY=Stretch((nas[0]+nas[1])/2)};
   var count=0;for(int y=0;y<n;y++)for(int x=0;x<n;x++){var xx=grid.Coordinate(x);var yy=grid.YCoordinate(y);if(xx*xx+yy*yy<=1)count++;}
   alternativeRows.Add(new{id,n,formula,nas,rms,p,count});
  }
  var sc=((double Rms,double T,double S))method.Invoke(null,new object[]{optic,(0d,0d),primary})!;
  var cone=((double Rms,double T,double S))method.Invoke(null,new object[]{optic,(0d,0d),wave})!;
  foreach(var unit in new[]{1d,.001,1e-6}) {
   var lambda=wave.Micrometers*unit;var cutoff=2*sc.Rms/lambda;var pitch=1/(cutoff*Math.Sqrt(n));var auto=Math.Sqrt(n/32d);
   foreach(var v in Enumerable.Range(0,4)) {
    double Stretch(double na) {
     var f=.5/na;
     var dp=v switch {0=>lambda*f*(n-2)/(2*n*auto),1=>lambda*f*(n-2)/(2*n)/auto,2=>lambda*f*(n-2)/(2*n)*Math.Sqrt(32d/n),_=>lambda*f*((n-2)/(2d*n*auto))};
     return auto*dp/pitch;
    }
    var sx=Stretch(cone.S);var sy=Stretch(cone.T);var grid=new PupilGridSpecification(n,true,true,sx){StretchY=sy};
    var count=0;for(int y=0;y<n;y++)for(int x=0;x<n;x++){var xx=grid.Coordinate(x);var yy=grid.YCoordinate(y);if(xx*xx+yy*yy<=1)count++;}
    rows.Add(new{id,n,unit,v,lambda,cutoff,pitch=pitch/unit,na=sc.Rms,t=cone.T,s=cone.S,sx,sy,count,diag=grid.Coordinate(n/2+(n==128?8:4))});
    Console.WriteLine($"{id} n={n} unit={unit} v={v} count={count} sx={sx:R} sy={sy:R}");
   }
  }
 }
}
File.WriteAllText(Path.Combine(task,"scalar-grid-units.json"),JsonSerializer.Serialize(rows));
File.WriteAllText(Path.Combine(task,"marginal-directions.json"),JsonSerializer.Serialize(directionRows));
File.WriteAllText(Path.Combine(task,"na-formulas.json"),JsonSerializer.Serialize(alternativeRows));
