$ErrorActionPreference='Stop'
$dir=Join-Path $PSScriptRoot 'fft-diagnostic';New-Item -ItemType Directory -Path $dir|Out-Null
$jobs=@()
foreach($type in @('Linear','Real','Imaginary')){
 $r=Get-Content (Join-Path $PSScriptRoot 'requests/original/dee.json') -Raw|ConvertFrom-Json
 $delta=.4788303*10.029697246753685/[Math]::Sqrt(128)
 $r.canonicalAnalysisKey='PSF';$r.analysisType='FftPsf';$r.imageDeltaMicrometers=$delta
 $r.zemaxSettings=[ordered]@{Normalize=$false;OutputSize='PsfS_256x256';SampleSize='PsfS_128x128';ImageDelta=$delta;Wavelength=4;Surface=-1;Rotation='CW0';Type=$type;Field=1;UsePolarization=$false}
 $path=Join-Path $dir ($type+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$type;request=$path;output=(Join-Path $dir $type)}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $dir 'native-jobs.json') -Encoding utf8NoBOM
