$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/FFT_CUMULATIVE_BOUNDARY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$unchangedTests=@($previous.sourceFiles|Where-Object {$_.path -like 'tests/*.cs'})
foreach($source in $unchangedTests){if((Hash (Join-Path $repo $source.path)) -ne $source.sha256){throw 'A previously verified test source changed'}}
$release=Tests 'related-release-final.trx';$debug=Tests 'related-debug-final.trx'
foreach($run in @($release,$debug)){
 if($run.passed -ne $run.total -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Final main tests incomplete'}
 if(@($run.names|Where-Object {$_ -match '\.Apochromat128EnergyTests\.'}).Count -ne 10){throw 'Ten new native curve checks missing'}
}
if($release.total -ne 920 -or $debug.total -ne 207){throw 'Final test scope differs'}
foreach($name in $previous.verification.testRelease.names){if($name -cnotin $release.names){throw 'Prior Release test identity missing'}}
foreach($name in $previous.verification.testDebug.names){if($name -cnotin $debug.names){throw 'Prior focused Debug test identity missing'}}
foreach($name in $debug.names){if($name -cnotin $release.names){throw 'Debug identity absent from Release'}}
$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx'
foreach($run in @($comparisonRelease,$comparisonDebug)){if($run.total -ne 5 -or $run.passed -ne 5 -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Comparison regressions incomplete'}}
$beforeTests=Tests 'apochromat-before.trx'
if($beforeTests.total -ne 10 -or $beforeTests.failed -ne 2 -or $beforeTests.passed -ne 8 -or $beforeTests.skipped -ne 0){throw 'Before counterexample scope differs'}
$beforeHash=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeHash -ne $previous.verification.configurations[0].coreCopies[0].sha256){throw 'Before Core is not the previous final Core'}
$configurations=foreach($configuration in @('Release','Debug')){
 $log=Get-Content (Join-Path $PSScriptRoot ('build-'+$configuration.ToLowerInvariant()+'-final.log')) -Raw
 if(@($log -split "`n"|Where-Object {$_ -match ' -> '}).Count -ne 19 -or !$log.Contains('0 个警告') -or !$log.Contains('0 个错误')){throw 'Default solution build incomplete'}
 $paths=@("src/OpticalSystemDesign.Core/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tools/OpticalSystemDesign.ZemaxComparison/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll")
 $copies=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
 if(@($copies.sha256|Sort-Object -Unique).Count -ne 1){throw 'Default Core copies differ'}
 @{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies}
}
$after=Get-Content (Join-Path $PSScriptRoot 'formal-final/summary.json') -Raw|ConvertFrom-Json
$extra=Get-Content (Join-Path $PSScriptRoot 'extra-final/summary.json') -Raw|ConvertFrom-Json
$new=Get-Content (Join-Path $PSScriptRoot 'new-controls-final/summary.json') -Raw|ConvertFrom-Json
$before=Get-Content (Join-Path $repo 'artifacts/validation/dee-boundary-20261018/formal-final/summary.json') -Raw|ConvertFrom-Json
$newBefore=Get-Content (Join-Path $PSScriptRoot 'new-controls-before/summary.json') -Raw|ConvertFrom-Json
if($before.coreSha256 -ne $beforeHash -or $newBefore.coreSha256 -ne $beforeHash){throw 'Before formal Core differs'}
foreach($s in @($after,$extra,$new)){
 if($s.coreSha256 -ne $configurations[0].coreCopies[0].sha256){throw 'Final formal Core differs'}
 if($s.policySha256 -ne $before.policySha256 -or $s.policySha256 -ne (Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'))){throw 'Original tolerance policy changed'}
 if(@($s.rows|Where-Object conclusion -ne 'Pass').Count -ne 0){throw 'Formal control failed'}
}
if($after.rows.Count -ne 48 -or $after.excluded.Count -ne 0 -or $extra.rows.Count -ne 6 -or $extra.excluded.Count -ne 1 -or $new.rows.Count -ne 5 -or $new.excluded.Count -ne 2){throw 'Formal inventory differs'}
foreach($row in $after.rows){
 $original=@($before.rows|Where-Object id -ceq $row.id)
 if($original.Count -ne 1 -or $row.sourceSha256 -ne $original[0].sourceSha256 -or $row.executedRequestSha256 -ne $original[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $original[0].nativeDataSha256){throw 'Original source/request/native reference changed'}
}
foreach($row in $extra.rows){$original=@($previous.independentControls.rows|Where-Object id -ceq $row.id);if($original.Count -ne 1 -or $row.sourceSha256 -ne $original[0].sourceSha256 -or $row.executedRequestSha256 -ne $original[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $original[0].nativeDataSha256){throw 'Old independent control changed'}}
$archives=@{};foreach($p in $previous.preservedArchives.PSObject.Properties){$archives[$p.Name]=$p.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen evidence archive changed'}}
if($archives.Count -ne 13){throw 'Expected thirteen previous archives'}
$fixtures=@{};foreach($p in $previous.preservedNativeFixtures.PSObject.Properties){$fixtures[$p.Name]=$p.Value};foreach($f in $previous.newFixtures){$fixtures[$f.name]=$f.sha256}
foreach($name in $fixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $fixtures[$name]){throw 'Frozen native fixture changed'}}
if($fixtures.Count -ne 7){throw 'Expected seven previous fixtures'}
$newFixturePath=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-apochromat128-zemax-2026-r1.zip'
$zip=[IO.Compression.ZipFile]::OpenRead($newFixturePath)
try{
 $reader=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open());try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
 foreach($entry in $manifest.entries){$stream=$zip.GetEntry($entry.path).Open();try{$h=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($h -ne $entry.sha256){throw 'New fixture payload changed'}}
 if($manifest.cases.Count -ne 5 -or $manifest.excluded.Count -ne 2){throw 'New fixture inventory differs'}
 $fixture=@{name=[IO.Path]::GetFileName($newFixturePath);sha256=Hash $newFixturePath;cases=5;excluded=$manifest.excluded;payloadEntries=$manifest.entries.Count}
}finally{$zip.Dispose()}
$captures=@();$usable=0;$unavailable=0
foreach($list in @('native-jobs.json','fft-diagnostic/native-jobs.json')){foreach($job in @(Get-Content (Join-Path $PSScriptRoot $list) -Raw|ConvertFrom-Json)){
 $request=Get-Content $job.request -Raw|ConvertFrom-Json
 $batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json;if($batch.exitCode -ne 0){throw 'Native request execution error'}
 $envData=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
 if($envData.major -ne 26 -or $envData.minor -ne 1 -or $envData.opticStudioVersion -ne 260127 -or !$envData.validLicense){throw 'Native version/license differs'}
 $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
 if($data.dataSeries.Count -eq 0 -and $data.dataGrids.Count -eq 0){$state='NativeUnavailable';$unavailable++}
 elseif($request.analysisType -eq 'DiffractionEncircledEnergy'){
  if($data.dataSeries.Count -ne 2){throw 'Native curve pair missing'}
  foreach($series in $data.dataSeries){if($series.x.Count -ne 401 -or $series.y.Count -ne 401){throw 'Native energy samples missing'};foreach($y in $series.y){if($y.Count -ne 1 -or ![double]::IsFinite($y[0]) -or $y[0] -lt 0 -or $y[0] -gt 1){throw 'Invalid native energy'}}};$state='Usable';$usable++
 }else{
  if($data.dataGrids.Count -ne 1){throw 'Native FFT grid missing'};$g=$data.dataGrids[0]
  if($g.nx -ne 256 -or $g.ny -ne 256 -or $g.values.Count -ne 256 -or $g.dx -le 0 -or $g.dy -le 0){throw 'FFT axes invalid'}
  foreach($y in $g.values){if($y.Count -ne 256){throw 'FFT row incomplete'};foreach($v in $y){if(![double]::IsFinite($v) -or ($request.zemaxSettings.Type -eq 'Linear' -and $v -lt 0)){throw 'Invalid FFT value'}}};$state='Usable';$usable++
 }
 $files=@(Get-ChildItem -LiteralPath $job.output -File|ForEach-Object {@{name=$_.Name;bytes=$_.Length;sha256=Hash $_.FullName}})
 $captures+=@{id=$job.id;state=$state;group=$list;requestSha256=Hash $job.request;sourceSha256=Hash $request.input;files=$files}
}}
if($captures.Count -ne 10 -or $usable -ne 8 -or $unavailable -ne 2){throw 'New native inventory differs'}
$nativeRepeat=Get-Content (Join-Path $PSScriptRoot 'native/original/data.json') -Raw|ConvertFrom-Json
$nativeOriginal=Get-Content (Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout/0014-n128/data.json') -Raw|ConvertFrom-Json
for($s=0;$s -lt 2;$s++){for($i=0;$i -lt 401;$i++){if($nativeRepeat.dataSeries[$s].x[$i] -ne $nativeOriginal.dataSeries[$s].x[$i] -or $nativeRepeat.dataSeries[$s].y[$i][0] -ne $nativeOriginal.dataSeries[$s].y[$i][0]){throw 'Native repeat differs from frozen reference'}}}
$supportBefore=Get-Content (Join-Path $PSScriptRoot 'core-support-before.json') -Raw|ConvertFrom-Json;$supportAfter=Get-Content (Join-Path $PSScriptRoot 'core-support-final.json') -Raw|ConvertFrom-Json;$nativeSupport=Get-Content (Join-Path $PSScriptRoot 'native-inverted-pupil.json') -Raw|ConvertFrom-Json
if($supportBefore.coreSha256 -ne $beforeHash -or $supportAfter.coreSha256 -ne $after.coreSha256 -or [Math]::Abs($supportBefore.count-401) -gt 1e-8 -or [Math]::Abs($supportAfter.count-405) -gt 1e-8 -or $nativeSupport.count -ne 405 -or $nativeSupport.complexIntensityError -gt 1e-14){throw 'Pupil support proof differs'}
$sourceFiles=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
if($sourceFiles.Count -ne 36){throw 'Current C# inventory differs'}
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log');if($LASTEXITCODE -ne 0){throw 'Whitespace check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='Original Apochromat 128 primary-wavelength FFT encircled-energy capture repaired; all prior original-tolerance passes retained'
 beforeCoreSha256=$beforeHash;beforeTests=$beforeTests
 constraints=@{originalTolerancePolicyUnchanged=$true;original48FormalPassesPreserved=$true;prior910ReleaseIdentitiesPreserved=$true;prior197FocusedDebugIdentitiesPreserved=$true;unchangedPriorTestSources=$unchangedTests;independentCookeTessarExcluded=$true}
 verification=@{testRelease=$release;testDebug=$debug;debugScope='Prior focused 197 plus ten new native curve checks';comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;configurations=$configurations;newMainTests=10;format=@{includedCSharpFiles=36;exitCode=0;log='format-verify.log'};gitDiffCheckExitCode=0}
 formalBefore=$before;formalAfter=$after;independentControls=$extra;newControlsBefore=$newBefore;newControlsAfter=$new
 supportProof=@{before=$supportBefore;after=$supportAfter;native=$nativeSupport;nativeRepeatMaximumDifference=0}
 numericalLimitations=@{allNativeBoundaryResidualsZero=$false;originalMatrixRegression='123456 n128 now NRMSE 0.001229760653189097 ideal and 0.0008575022803685469 actual, still original-tolerance Pass';newHoldoutResidual='Apochromat n128 extremely small negative EPD perturbation remains near 0.00266313631 NRMSE';largerApertureControls='Both +/-5 percent native requests returned zero curves with low-sampling warnings; excluded'}
 preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@($fixture)
 nativeCaptureSummary=@{attempts=10;usableCaptures=8;usableDeeCaptures=5;usableComplexFftCaptures=3;requestErrors=0;nativeUnavailable=2;note='Counts include repeated original capture and auxiliary FFT, not independent lens certifications'};nativeCaptures=$captures;sourceFiles=$sourceFiles
 retainedFailureRecords=@('tests/apochromat-before.trx','tests-before.log','native/epd-minus5pct/data.json','native/epd-plus5pct/data.json')
 boundaries=@{fullRepositorySuiteRun=$false;fullDebugSuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false;generalNativeBoundaryConventionCertified=$false}
}
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $repo 'docs/validation/APOCHROMAT_128_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified original Apochromat repair, 48+6+5 valid comparisons, 920/207 tests, previous identities/sources/fixtures and default binaries.'
