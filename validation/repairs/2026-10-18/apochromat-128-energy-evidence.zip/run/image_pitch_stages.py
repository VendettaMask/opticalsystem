import json,math
from pathlib import Path
root=Path(__file__).parent
out=[]
for row in json.loads((root/'scalar-grid-units.json').read_text()):
    if row['unit']!=1 or row['v']!=0:continue
    n=row['n'];l=row['lambda'];r=row['na'];auto=math.sqrt(n/32);c=row['cutoff'];sn=math.sqrt(n)
    pitches=[1/(c*sn),(1/c)/sn,(1/sn)/c,(1/c)*(1/sn),math.sqrt(1/n)/c,math.sqrt(n)/(n*c),math.sqrt(1/(n*c*c)),1/math.sqrt(n*c*c),math.sqrt(1/(c*c))/sn,math.sqrt((1/c)*(1/c)/n)]
    counts=[]
    for pp in pitches:
        sx=auto*(l*(.5/row['s'])*(n-2)/(2*n*auto))/pp;sy=auto*(l*(.5/row['t'])*(n-2)/(2*n*auto))/pp
        count=sum((sx*((x-n/2)/(n/2-1)))**2+(sy*((y-n/2)/(n/2-1)))**2<=1 for x in range(n) for y in range(n))
        counts.append(count)
    out.append(dict(id=row['id'],counts=counts,pitches=pitches))
    print(row['id'],counts)
(root/'image-pitch-stages.json').write_text(json.dumps(out,indent=2))
