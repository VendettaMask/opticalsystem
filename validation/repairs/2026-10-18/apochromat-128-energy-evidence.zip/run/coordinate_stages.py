import json,math
from pathlib import Path
root=Path(__file__).parent
rows=json.loads((root/'scalar-grid-units.json').read_text())
out=[]
for row in rows:
    if row['unit']!=1 or row['v']!=0:continue
    n=row['n'];auto=math.sqrt(n/32);p=row['pitch'];l=row['lambda']
    def coord(k,a,v):
        q=(k-n/2)/(n/2-1);dp=l*(.5/a)*(n-2)/(2*n*auto)
        return [lambda:(auto*dp/p)*q,
                lambda:((auto*q)*dp)/p,
                lambda:((auto*q)/p)*dp,
                lambda:(auto*q)*(dp/p),
                lambda:(((q*dp)/p)*auto),
                lambda:((auto*dp)*q)/p,
                lambda:((k-n/2)*(auto*dp/(n/2-1)))/p,
                lambda:((k-n/2)*auto)*((dp/(n/2-1))/p),
                lambda:((k-n/2)*auto)*(dp/((n/2-1)*p)),
                lambda:(auto*(dp*.001)/(p*.001))*q,
                lambda:(auto*((dp*auto)*.001)/(p*.001)/auto)*q,
                lambda:((auto*dp)*.001/(p*.001))*q,
                lambda:(auto*(dp/1000)/(p/1000))*q,
                lambda:((auto*dp)/1000/(p/1000))*q][v]()
    counts=[]
    for v in range(14):
        xx=[coord(k,row['s'],v) for k in range(n)];yy=[coord(k,row['t'],v) for k in range(n)]
        counts.append(sum(x*x+y*y<=1 for x in xx for y in yy))
    out.append(dict(id=row['id'],counts=counts))
    print(row['id'],counts)
(root/'coordinate-stages.json').write_text(json.dumps(out,indent=2))
