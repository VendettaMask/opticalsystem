import json,math
from pathlib import Path
root=Path(__file__).parent
out=[]
for row in json.loads((root/'scalar-grid-units.json').read_text()):
    if row['unit']!=1 or row['v']!=0:continue
    n=row['n'];l=row['lambda'];r=row['na'];auto=math.sqrt(n/32)
    f=.5/r
    cutoffs=[2*r/l,2*(r/l),(2/l)*r,(1/l)*(2*r),1/(l*f),1/l/f,1/(l/(2*r)),2/(l/r)]
    counts=[]
    for c in cutoffs:
        pp=1/(c*math.sqrt(n))
        sx=auto*(l*(.5/row['s'])*(n-2)/(2*n*auto))/pp;sy=auto*(l*(.5/row['t'])*(n-2)/(2*n*auto))/pp
        count=sum((sx*((x-n/2)/(n/2-1)))**2+(sy*((y-n/2)/(n/2-1)))**2<=1 for x in range(n) for y in range(n))
        counts.append(count)
    out.append(dict(id=row['id'],counts=counts))
    print(row['id'],counts)
(root/'cutoff-stages.json').write_text(json.dumps(out,indent=2))
