$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$template=Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout/0014-n128/request.json'
$jobs=@()
foreach($id in @('original','epd-minus-small','epd-plus-small','epd-minus5pct','epd-plus5pct','wave1','wave8')){
 $dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir|Out-Null
 $r=Get-Content $template -Raw|ConvertFrom-Json
 if($id.StartsWith('epd-')){
  $epd=switch($id){'epd-minus-small'{'9.99999999999995'} 'epd-plus-small'{'10.000000000000052'} 'epd-minus5pct'{'9.5'} 'epd-plus5pct'{'10.5'}}
  $text=[IO.File]::ReadAllText($r.input)
  if([regex]::Matches($text,'(?m)^ENPD 10\s*$').Count -ne 1){throw 'Unexpected original aperture'}
  $source=Join-Path $dir 'aperture.zmx';[IO.File]::WriteAllText($source,[regex]::Replace($text,'(?m)^ENPD 10\s*$','ENPD '+$epd),[Text.UTF8Encoding]::new($false));$r.input=$source
 }
 if($id.StartsWith('wave')){$w=[int]$id.Substring(4);$r.wavelength=$w;$r.workbenchSettings.WavelengthNumber="$w";$r.zemaxSettings.Wavelength=$w}
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
