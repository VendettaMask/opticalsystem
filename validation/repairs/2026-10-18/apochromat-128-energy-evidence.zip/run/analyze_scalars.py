import json, math
from decimal import Decimal as D, getcontext
from pathlib import Path
getcontext().prec=100
root=Path(__file__).parent
rows=json.loads((root/'marginal-directions.json').read_text())
out=[]
for row in rows:
    dirs=[[D(d[k]) for k in ('X','Y','Z')] for d in row['directions']]
    chief=dirs[0]
    norm=lambda v:sum(x*x for x in v).sqrt()
    nas=[]
    for d in dirs[1:]:
        c=[chief[1]*d[2]-chief[2]*d[1],chief[2]*d[0]-chief[0]*d[2],chief[0]*d[1]-chief[1]*d[0]]
        nas.append(float(norm(c)/(norm(chief)*norm(d))))
    rms=float((sum(D(v)**2 for v in nas)/4).sqrt())
    t=(nas[0]+nas[1])/2;s=(nas[2]+nas[3])/2
    n=row['n'];l=row['lambda'];pitch=1/((2*rms/l)*math.sqrt(n));auto=math.sqrt(n/32)
    stretch=lambda a:auto*(l*(.5/a)*(n-2)/(2*n*auto))/pitch
    sx=stretch(s);sy=stretch(t)
    count=sum((sx*((x-n/2)/(n/2-1)))**2+(sy*((y-n/2)/(n/2-1)))**2<=1 for x in range(n) for y in range(n))
    result=dict(id=row['id'],nas=nas,rms=rms,t=t,s=s,sx=sx,sy=sy,count=count)
    out.append(result)
    pitch_variants=[pitch, l/(2*rms*math.sqrt(n)),l*(.5/rms)/math.sqrt(n),l/math.sqrt(n)*(.5/rms),float(D(l)/(2*D(rms)*D(n).sqrt())),float(D(l)/(2*D(rms)*D(math.sqrt(n))))]
    variants=[]
    for pp in pitch_variants:
        sx=auto*(l*(.5/s)*(n-2)/(2*n*auto))/pp;sy=auto*(l*(.5/t)*(n-2)/(2*n*auto))/pp
        ct=sum((sx*((x-n/2)/(n/2-1)))**2+(sy*((y-n/2)/(n/2-1)))**2<=1 for x in range(n) for y in range(n))
        variants.append(dict(pitch=pp,count=ct,sx=sx,sy=sy))
    result['pitches']=variants
    # Independently rounded scalar operations, without changing grid acceptance.
    pitch=pitch_variants[0]
    vv=[]
    for v in range(12):
        def stable_stretch(a):
            f=.5/a
            dp=l*f*(n-2)/(2*n*auto)
            if v>=8:
                dp=float(D(l)*(D('.5')/D(a))*D(n-2)/(2*D(n)*D(auto)))
                if v==8:return auto*dp/pitch
                if v==9:return float(D(auto)*D(dp)/D(pitch))
                if v==10:return float(D(l)*(D('.5')/D(a))*D(n-2)/(2*D(n)*D(pitch)))
                return float(D(auto)*D(l)*(D('.5')/D(a))*D(n-2)/(2*D(n)*D(auto)*D(pitch)))
            if v in (1,3,5,7):dp=float(D(l)*D(f)*D(n-2)/(2*D(n)*D(auto)))
            if v in (2,3):return float(D(auto)*D(dp)/D(pitch))
            if v in (4,5):return float(D(auto)*D(dp))/pitch
            if v in (6,7):return float(D(auto)*D(l)*D(f)*D(n-2)/(2*D(n)*D(auto)*D(pitch)))
            return auto*dp/pitch
        sx=stable_stretch(s);sy=stable_stretch(t)
        ct=sum((sx*((x-n/2)/(n/2-1)))**2+(sy*((y-n/2)/(n/2-1)))**2<=1 for x in range(n) for y in range(n))
        vv.append(dict(count=ct,sx=sx,sy=sy))
    result['precision']=vv
    print(row['id'],[v['count'] for v in vv])
(root/'correctly-rounded-na.json').write_text(json.dumps(out,indent=2))
