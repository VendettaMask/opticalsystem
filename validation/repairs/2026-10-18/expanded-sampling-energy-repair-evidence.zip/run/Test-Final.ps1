param([string]$Configuration='Release')
$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$prior=Join-Path $repo 'artifacts/validation/dee-relay-stop-branch-20261018'
$filterName=$Configuration+'-filter.txt'
$filter=([IO.File]::ReadAllText((Join-Path $prior $filterName))).Trim()+'|FullyQualifiedName~ExpandedSamplingEnergyTests'
[IO.File]::WriteAllText((Join-Path $PSScriptRoot ($Configuration+'-filter.txt')),$filter)
dotnet test (Join-Path $repo 'tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj') -c $Configuration --no-build --no-restore --filter $filter --logger ('trx;LogFileName='+$Configuration+'.trx') --results-directory (Join-Path $PSScriptRoot 'tests') *> (Join-Path $PSScriptRoot ('tests-'+$Configuration+'.log'))
if($LASTEXITCODE -ne 0){throw 'Product regressions failed'}
$filter=([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'comparison-filter.txt'))).Trim()
dotnet test (Join-Path $repo 'tests/OpticalSystemDesign.ZemaxComparison.Tests/OpticalSystemDesign.ZemaxComparison.Tests.csproj') -c $Configuration --no-build --no-restore --filter $filter --logger ('trx;LogFileName=comparison-'+$Configuration+'.trx') --results-directory (Join-Path $PSScriptRoot 'tests') *> (Join-Path $PSScriptRoot ('comparison-'+$Configuration+'.log'))
if($LASTEXITCODE -ne 0){throw 'Comparison regressions failed'}
Get-Content (Join-Path $PSScriptRoot ('tests-'+$Configuration+'.log')) -Tail 3
Get-Content (Join-Path $PSScriptRoot ('comparison-'+$Configuration+'.log')) -Tail 3
