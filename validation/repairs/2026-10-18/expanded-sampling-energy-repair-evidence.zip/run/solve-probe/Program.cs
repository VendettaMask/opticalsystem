using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core;
var task=Path.Combine(args[0],"artifacts/validation/dee-extended-precision-20261018");var rows=new List<object>();
using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"controls/native-jobs.json")));
foreach(var job in jobs.RootElement.EnumerateArray()){
 using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(request.RootElement.GetProperty("input").GetString()!),".zmx");var primary=optic.Wavelengths.First(w=>w.IsPrimary);
 if(job.GetProperty("id").GetString()!.StartsWith("doublet")){
  var inputText=File.ReadAllText(request.RootElement.GetProperty("input").GetString()!);var match=System.Text.RegularExpressions.Regex.Match(inputText,@"CURV\s+(\S+)\s+2\s+(\S+)");var storedCurvature=double.Parse(match.Groups[1].Value,System.Globalization.CultureInfo.InvariantCulture);var target=double.Parse(match.Groups[2].Value,System.Globalization.CultureInfo.InvariantCulture);var s=optic.SurfaceGroup.Items[3];var saved=s.Radius;
  s.Radius=1/storedCurvature;var current=optic.Paraxial.MarginalRay(primary.Micrometers).Slopes[3][0];s.Radius=0;var zero=optic.Paraxial.MarginalRay(primary.Micrometers).Slopes[3][0];s.Radius=1;var unit=optic.Paraxial.MarginalRay(primary.Micrometers).Slopes[3][0];s.Radius=saved;
  var response=unit-zero;Console.WriteLine(JsonSerializer.Serialize(new{method="incremental",id=job.GetProperty("id").GetString(),current,target,storedCurvature,direct=1/((target-zero)/response),delta=1/(storedCurvature+(target-current)/response),fma=1/Math.FusedMultiplyAdd(target-current,1/response,storedCurvature)}));
 }
 if(job.GetProperty("id").GetString()=="doublet-epd-minus" && args.Contains("snapshot")){
  foreach(var (label,sample) in new[]{("direct",optic),("snapshot",Optic.FromSnapshot(optic.ToSnapshot()))}){
   var c=(ValueTuple<double,double,double>)typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,new object[]{sample,(0d,0d),sample.Wavelengths[1]})!;
   var pitch=(double)typeof(DiffractionEngine).GetMethod("ExpandedCumulativeEnergyPitch",BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,new object[]{primary.Micrometers,c.Item1,512})!;
   var grid=(PupilGridSpecification)typeof(DiffractionEngine).GetMethod("ExpandedCumulativeEnergyGrid",BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,new object[]{sample,(0d,0d),sample.Wavelengths[1],512,pitch,c.Item2,c.Item3})!;
   var psf=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(sample,(0,0),new[]{sample.Wavelengths[1]},512,true)[0].Result;
   var curve=new DiffractionEncircledEnergyAnalysis(sample,512,1024,401,2,1,maximumDistanceMicrometers:5).GenerateData();
   using var data=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"data.json")));var expected=data.RootElement.GetProperty("dataSeries")[0].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();var error=Math.Sqrt(curve.PlotSeries[0].Points.Select((p,i)=>Math.Pow(p.Y-expected[i],2)).Average())/(expected.Max()-expected.Min());
   Console.WriteLine(JsonSerializer.Serialize(new{label,cone=new[]{c.Item1,c.Item2,c.Item3},pitch,grid.ExplicitCoordinateStep,psfCount=1024d*1024/psf.Values.Cast<double>().Sum(),error}));
  }
 }
 var surfaces=optic.SurfaceGroup.Items.Select((s,i)=>new{i,radius=s.Radius,nativeRadius=model.RootElement.GetProperty("surfaces")[i].GetProperty("Radius").ValueKind==JsonValueKind.Null?0:model.RootElement.GetProperty("surfaces")[i].GetProperty("Radius").GetDouble(),thickness=s.Thickness,nativeThickness=model.RootElement.GetProperty("surfaces")[i].GetProperty("Thickness").ValueKind==JsonValueKind.Null?double.PositiveInfinity:model.RootElement.GetProperty("surfaces")[i].GetProperty("Thickness").GetDouble()}).Where(s=>s.radius!=s.nativeRadius||s.thickness!=s.nativeThickness).ToArray();
 var marginal=optic.Paraxial.MarginalRay(primary.Micrometers);
 if(job.GetProperty("id").GetString()!.StartsWith("doublet")){var s=optic.SurfaceGroup.Items[3];var ni=s.MaterialBefore.RefractiveIndex(primary.Nanometers);var nt=s.MaterialAfter.RefractiveIndex(primary.Nanometers);var h=marginal.Heights[3][0];var u=marginal.Slopes[2][0];var target=-.100000001;Console.WriteLine(JsonSerializer.Serialize(new{ni,nt,h,u,variants=new[]{h*(nt-ni)/(ni*u-nt*target),h/((ni*u-nt*target)/(nt-ni)),1/((ni*u-nt*target)/(h*(nt-ni))),h*(nt/ni-1)/(u-nt/ni*target)}}));}
 var item=new{id=job.GetProperty("id").GetString(),power=optic.Paraxial.EstimateOpticalPower(),fNumber=optic.Paraxial.EstimateFNumber(),slopes=marginal.Slopes.Select(v=>v[0]),surfaces};rows.Add(item);Console.WriteLine(JsonSerializer.Serialize(item,new JsonSerializerOptions{NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals}));
}
File.WriteAllText(Path.Combine(task,args.Length>1?args[1]:"solved-geometry.json"),JsonSerializer.Serialize(rows,new JsonSerializerOptions{NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals}));
