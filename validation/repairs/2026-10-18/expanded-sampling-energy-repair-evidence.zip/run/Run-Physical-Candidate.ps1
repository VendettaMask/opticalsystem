$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$runner=Join-Path $PSScriptRoot 'old-physical-runner/Runner.dll'
Copy-Item (Join-Path $PSScriptRoot 'Core.physical-candidate.dll') (Join-Path $PSScriptRoot 'old-physical-runner/OpticalSystemDesign.Core.dll')
$specs=@(@('formal-physical-candidate',''),@('extra-physical-candidate','extra'),@('apochromat-physical-candidate','new'),@('high-sampling-physical-candidate','current'),@('fnum-physical-candidate','latest'),@('polychromatic-physical-candidate','poly'),@('polychromatic128-physical-candidate','poly128'),@('boundary128-physical-candidate','boundary128'),@('offner-physical-candidate','offner'),@('decenter-physical-candidate','decenter'),@('controls-physical-candidate','relay64w3'),@('aiming-physical-candidate','aiming'))
foreach($spec in $specs){
 $arguments=@($runner,$repo,(Join-Path $PSScriptRoot $spec[0]))
 if($spec[1]){$arguments+=@($spec[1])}
 dotnet @arguments *> (Join-Path $PSScriptRoot ($spec[0]+'.log'))
 if($LASTEXITCODE -ne 0){throw ('Formal failed: '+$spec[0])}
}


