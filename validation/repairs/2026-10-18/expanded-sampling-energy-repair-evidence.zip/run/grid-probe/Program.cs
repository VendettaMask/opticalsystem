using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;

var task=Path.Combine(args[0],"artifacts/validation/dee-extended-precision-20261018");
var scores=new Dictionary<int,List<string>>();var rows=new List<object>();
using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"matrix/native-jobs.json")));using var controls=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"controls/native-jobs.json")));
var method=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.NonPublic|BindingFlags.Static)!;
foreach(var job in jobs.RootElement.EnumerateArray().Concat(controls.RootElement.EnumerateArray())){
 var id=job.GetProperty("id").GetString()!;using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=request.RootElement;
 using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 var n=r.GetProperty("pupilSampling").GetInt32();var wn=r.GetProperty("wavelength").GetInt32();var waves=wn>0?new[]{optic.Wavelengths[wn-1]}:optic.Wavelengths.Where(w=>w.Weight>0).ToArray();var primary=optic.Wavelengths.First(w=>w.IsPrimary);var longest=waves.Max(w=>w.Micrometers);var reference=Cone(primary);
 var pitch=Math.Sqrt(1d/n)/(2*reference.Item1/longest);var targetDirection=id is "0014-n512-poly" or "0308-n512-primary" or "0360-n512-primary" or "0360-n512-poly" or "0852-n512-primary" or "0852-n512-poly"?1:id=="0852-n256-poly"?-1:0;
 foreach(var wave in waves){
  var cone=Cone(wave);var axes=waves.Length>1?reference:cone;var meanX=axes.Item3;var meanY=axes.Item2;var f=DiffractionEngine.WorkingFNumber(optic,(0,0),wave,optic.RayAimingEnabled);
  PupilGridSpecification baseline;
  if(waves.Length>1){var sx=1/(n*pitch/wave.Micrometers/(.5/meanX));var sy=1/(n*pitch/wave.Micrometers/(.5/meanY));baseline=new(n,true,true,sx*(n/2d-1)){ExplicitCoordinateStep=sx,ExplicitCoordinateStepY=sy};}
  else if(cone.Item2==cone.Item3&&cone.Item1==Math.BitIncrement(cone.Item2)){var step=(reference.Item1/cone.Item1)/Math.Sqrt(n);baseline=new(n,true,true,step*(n/2d-1)){ExplicitCoordinateStep=step};}
  else{var stretch=Math.Sqrt(n/32d);var defaultPitch=wave.Micrometers*f*(n-2)/(2*n*stretch);var ratio=stretch*defaultPitch/pitch/f;baseline=new(n,true,true,ratio*(.5/meanX)){StretchY=ratio*(.5/meanY)};}
  var critical=new List<(int X,int Y)>();var interior=0;
  for(var y=0;y<n;y++)for(var x=0;x<n;x++){var px=baseline.Coordinate(x);var py=baseline.YCoordinate(y);var radius=px*px+py*py;if(radius<1-1e-12)interior++;else if(radius<1+1e-12)critical.Add((x,y));}
  var target=baseline;
  if(!id.Contains("-n")){
   var p=(longest*.001)*(.5/reference.Item1)/Math.Sqrt(n)*1000;var stretch=Math.Sqrt(n/32d);var dp=wave.Micrometers*f*(n-2)/(2*n*stretch);var ratio=stretch*dp/p/f;
   target=baseline with{ExplicitCoordinateStep=ratio*(.5/meanX)/(n/2d-1),ExplicitCoordinateStepY=ratio*(.5/meanY)/(n/2d-1)};
   if(id=="doublet-epd-minus")target=target with{ExplicitCoordinateStep=Math.BitIncrement(target.ExplicitCoordinateStep!.Value),ExplicitCoordinateStepY=Math.BitIncrement(target.ExplicitCoordinateStepY!.Value)};
  }
  if(targetDirection!=0){var sx=baseline.Coordinate(n/2+1);var sy=baseline.YCoordinate(n/2+1);sx=targetDirection>0?Math.BitIncrement(sx):Math.BitDecrement(sx);sy=targetDirection>0?Math.BitIncrement(sy):Math.BitDecrement(sy);target=baseline with{ExplicitCoordinateStep=sx,ExplicitCoordinateStepY=sy};}
  var targetCount=Count(target);
  if(id=="doublet-epd-minus")targetCount=1609;
  var candidates=new List<object>();
  for(var variant=0;variant<2880;variant++){
   var family=variant/144;var defaultForm=variant/24%6;var fSource=variant/4%6;var order=variant%4;var cf=.5/reference.Item1;
   var candidatePitch=family switch{
    0=>pitch,1=>longest*cf/Math.Sqrt(n),2=>longest/(2*reference.Item1*Math.Sqrt(n)),
    3=>(longest*.001)*cf/Math.Sqrt(n)*1000,4=>(longest*.001)/(2*reference.Item1*Math.Sqrt(n))*1000,
    5=>Math.Sqrt(longest*longest/(4*reference.Item1*reference.Item1*n)),
    6=>longest/(2*reference.Item1)*Math.Sqrt(1d/n),
    7=>(longest*.001/(2*reference.Item1))*Math.Sqrt(1d/n)*1000,
    8=>(longest*.001/Math.Sqrt(n))*cf*1000,
    9=>(longest/Math.Sqrt(n))*cf,
    10=>(cf/Math.Sqrt(n))*(longest*.001)*1000,
    11=>Math.Sqrt(Math.Pow((longest*.001)*cf,2)/n)*1000,
    12=>Math.Sqrt(1d/n)*((longest*.001)*cf)*1000,
    13=>(longest*.001/(2*reference.Item1))/Math.Sqrt(n)*1000,
    14=>Math.Sqrt(1d/n)*longest*.001*cf*1000,
    15=>((longest*.001)*.5/reference.Item1)/Math.Sqrt(n)*1000,
    16=>(longest/1000)*cf/Math.Sqrt(n)*1000,
    17=>(longest*1000/1e6)*cf/Math.Sqrt(n)*1000,
    18=>(longest*1000*1e-6)*cf/Math.Sqrt(n)*1000,
    19=>((longest*.001)*cf)/(Math.Sqrt(n)*.001),_=>throw new Exception()};
   var df=fSource switch{0=>f,1=>.5/cone.Item1,2=>.5/cone.Item2,3=>.5/reference.Item1,4=>DiffractionEngine.WorkingFNumber(optic,(0,0),primary,optic.RayAimingEnabled),5=>DiffractionEngine.WorkingFNumbers(optic,(0,0),wave,optic.RayAimingEnabled,zemaxDirectionalAverage:true).Tangential,_=>throw new Exception()};
   var stretch=Math.Sqrt(n/32d);var dp=defaultForm switch{
    0=>wave.Micrometers*df*(n-2)/(2*n*stretch),
    1=>(wave.Micrometers*.001)*df*(n-2)/(2*n*stretch)*1000,
    2=>wave.Micrometers*df/(2*stretch)*(n-2)/n,
    3=>wave.Micrometers*df*(1-2d/n)/(2*stretch),
    4=>(wave.Micrometers*.001)*df*(n-2)/(2*n*stretch),
    5=>wave.Micrometers*df*(n-2)/(2*n)/stretch,_=>throw new Exception()};
   var dimensionalPitch=defaultForm==4?candidatePitch*.001:candidatePitch;
   var sx=Step(meanX);var sy=Step(meanY);var grid=baseline with{ExplicitCoordinateStep=sx,ExplicitCoordinateStepY=sy};
   var count=Count(grid);if(!scores.ContainsKey(variant))scores[variant]=new();if(count!=targetCount)scores[variant].Add(id+"/"+wave.Micrometers);
   candidates.Add(new{variant,family,defaultForm,fSource,order,candidatePitch,sx,sy,count,match=count==targetCount});
   double Step(double mean)=>order switch{
    0=>stretch*dp/dimensionalPitch/df*(.5/mean)/(n/2d-1),
    1=>stretch*dp/dimensionalPitch*((.5/mean)/df)/(n/2d-1),
    2=>dp/(n/2d-1)*stretch/dimensionalPitch/df*(.5/mean),
    3=>stretch*dp/dimensionalPitch/df/(n/2d-1)*(.5/mean),_=>throw new Exception()};
  }
  rows.Add(new{id,n,wn,wave=wave.Micrometers,cone=new[]{cone.Item1,cone.Item2,cone.Item3},reference=new[]{reference.Item1,reference.Item2,reference.Item3},pitch,baselineCount=Count(baseline),targetCount,critical=critical.Count,candidates});
  int Count(PupilGridSpecification grid)=>interior+critical.Count(p=>{var x=grid.Coordinate(p.X);var y=grid.YCoordinate(p.Y);return x*x+y*y<=1;});
 }
 (double,double,double) Cone(Wavelength w)=>(ValueTuple<double,double,double>)method.Invoke(null,new object[]{optic,(0d,0d),w})!;
}
var ranking=scores.Select(p=>new{variant=p.Key,mismatches=p.Value.Count,failed=p.Value}).OrderBy(p=>p.mismatches).ToArray();
File.WriteAllText(Path.Combine(task,"grid-physical-formula-scan.json"),JsonSerializer.Serialize(new{ranking,rows}));Console.WriteLine(JsonSerializer.Serialize(ranking.Take(16)));
