$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$target=Join-Path $repo 'validation/repairs/2026-10-18/expanded-sampling-energy-repair-evidence.zip'
if(Test-Path $target){throw 'Never overwrite a frozen archive'}
$proof=Get-Content (Join-Path $PSScriptRoot 'proof.json') -Raw|ConvertFrom-Json
$payload=@{}
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -File -Recurse){
 $relative=[IO.Path]::GetRelativePath($PSScriptRoot,$file.FullName).Replace('\','/')
 if($relative -match '(^|/)(bin|obj|runtimes)/' -or $relative -in 'archive-validation.log','archive-result.json','finalize.log','documentation-audit-final.json','documentation-audit-final.log'){continue}
 $top=$relative.Split('/')[0]
 if($top -match 'runner$' -and $relative -notmatch '\.(cs|csproj)$'){continue}
 $fullGroups=@('formal-final','extra-final','apochromat-final','high-sampling-final','fnum-final','polychromatic-final','polychromatic128-final','boundary128-final','offner-final','decenter-final','controls-final','aiming-final','matrix-before','matrix-circular','extended-controls-before','extended-controls-circular','matrix','controls','tests')
 if($relative.Contains('/') -and $top -notin $fullGroups -and $top -notmatch '(runner|probe)$' -and $relative -notmatch '/summary\.json$'){continue}
 $payload['run/'+$relative]=$file.FullName
}
foreach($source in $proof.sourceFiles){$payload['source/'+$source.path]=Join-Path $repo $source.path}
foreach($path in @('AGENTS.md','tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj','tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json','docs/CURRENT_STATUS.md','docs/NUMERICAL_PARITY.md','docs/OPEN_ISSUES_2026-10-08.md')){$payload['source/'+$path]=Join-Path $repo $path}
$report='docs/EXPANDED_SAMPLING_ENERGY_REPAIR_2026-10-18.md';$payload['report/EXPANDED_SAMPLING_ENERGY_REPAIR_2026-10-18.md']=Join-Path $repo $report
foreach($f in $proof.newFixtures){$payload['fixtures/'+[IO.Path]::GetFileName($f.path)]=Join-Path $repo $f.path}
$records=[Collections.Generic.List[object]]::new()
$stream=[IO.File]::Open($target,[IO.FileMode]::CreateNew)
try{
 $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
 try{
  foreach($key in @($payload.Keys|Sort-Object)){
   $bytes=[IO.File]::ReadAllBytes($payload[$key]);$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($bytes))
   $entry=$zip.CreateEntry($key,[IO.Compression.CompressionLevel]::Optimal);$s=$entry.Open();try{$s.Write($bytes)}finally{$s.Dispose()}
   $records.Add(@{path=$key;sha256=$hash;bytes=$bytes.Length})
  }
  $manifest=@{schemaVersion=1;scope='Six-lens 256/512 FFT cumulative energy and imported curvature solve repair; 30 new native captures, 135 old formal comparisons, unchanged 1e-8 energy guards';entries=$records.ToArray();exclusions='Build intermediates and copied runner runtimes; duplicate candidate formal payloads except summaries; packaging logs; prior frozen fixtures/archives preserved by hash in proof.json. Failed logs and candidate Core binaries retained.'}|ConvertTo-Json -Depth 10
  $entry=$zip.CreateEntry('manifest.json');$s=$entry.Open();try{$s.Write([Text.Encoding]::UTF8.GetBytes($manifest))}finally{$s.Dispose()}
 }finally{$zip.Dispose()}
}finally{$stream.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($target)
try{
 if($zip.Entries.Count -ne $records.Count+1){throw 'Archive inventory mismatch'}
 foreach($record in $records){$s=$zip.GetEntry($record.path).Open();try{$h=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($s))}finally{$s.Dispose()};if($h -ne $record.sha256){throw 'Archive readback hash mismatch'}}
}finally{$zip.Dispose()}
$result=@{path='validation/repairs/2026-10-18/expanded-sampling-energy-repair-evidence.zip';sha256=(Get-FileHash $target).Hash.ToLowerInvariant();bytes=(Get-Item $target).Length;entries=$records.Count+1;payloadEntries=$records.Count;allPayloadHashesVerified=$true}
$result|ConvertTo-Json -Depth 8|Set-Content (Join-Path $PSScriptRoot 'archive-result.json') -Encoding utf8NoBOM
$proof|Add-Member -NotePropertyName evidenceArchive -NotePropertyValue $result
$proof|ConvertTo-Json -Depth 80|Set-Content (Join-Path $repo 'docs/validation/EXPANDED_SAMPLING_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
$result|ConvertTo-Json

