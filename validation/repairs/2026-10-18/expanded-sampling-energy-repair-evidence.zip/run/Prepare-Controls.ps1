$ErrorActionPreference='Stop'
$run=Join-Path $PSScriptRoot 'controls';New-Item -ItemType Directory -Path $run|Out-Null
$specs=@(
 @('apo-epd-minus','0014-n512-poly','ENPD 10','ENPD 9.99999'),
 @('apo-epd-plus','0014-n512-poly','ENPD 10','ENPD 10.00001'),
 @('doublet-epd-minus','0308-n512-primary','ENPD 20','ENPD 19.99999'),
 @('doublet-epd-plus-poly','0308-n512-poly','ENPD 20','ENPD 20.00001'),
 @('base-fnum-minus','0852-n256-poly','FNUM 2.7000000000000002 0','FNUM 2.6999999900000002 0'),
 @('base-fnum-plus','0852-n256-poly','FNUM 2.7000000000000002 0','FNUM 2.7000000100000001 0'))
$jobs=@()
foreach($spec in $specs){
 $dir=Join-Path $run $spec[0];New-Item -ItemType Directory -Path $dir|Out-Null
 $r=Get-Content (Join-Path $PSScriptRoot ('matrix/'+$spec[1]+'.json')) -Raw|ConvertFrom-Json
 $source=[IO.File]::ReadAllText($r.input);if(!$source.Contains($spec[2])){throw 'Expected aperture line missing'}
 $inputPath=Join-Path $dir 'source.zmx';[IO.File]::WriteAllText($inputPath,$source.Replace($spec[2],$spec[3]))
 $r.input=$inputPath;$path=Join-Path $dir 'request.json';$r|ConvertTo-Json -Depth 25|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$spec[0];request=$path;output=(Join-Path $dir 'output')}
}
$jobs|ConvertTo-Json -Depth 8|Set-Content (Join-Path $run 'native-jobs.json') -Encoding utf8NoBOM
'Prepared six independent aperture controls.'
