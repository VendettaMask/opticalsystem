$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}
function Read([string]$path){Get-Content (Join-Path $PSScriptRoot $path) -Raw|ConvertFrom-Json}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object);sha256=Hash (Join-Path $PSScriptRoot ('tests/'+$name))}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/RELAY_STOP_BRANCH_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$previousRoot=Join-Path $repo 'artifacts/validation/dee-relay-stop-branch-20261018'
$beforeCore=Hash (Join-Path $PSScriptRoot 'Core.before.dll');$afterCore=Hash (Join-Path $PSScriptRoot 'Core.release-final.dll')
if($beforeCore -ne $previous.afterCoreSha256 -or $beforeCore -eq $afterCore){throw 'Wrong before/after Core'}
$changed=@('src/OpticalSystemDesign.Core/Analysis/DiffractionEngine.CumulativeEnergy.cs','src/OpticalSystemDesign.Core/FileIO/ZemaxZmxReader.cs')
$added=@('src/OpticalSystemDesign.Core/FileIO/ZemaxZmxReader.CurvatureSolves.cs','tests/OpticalSystemDesign.Tests/ExpandedSamplingEnergyTests.cs')
foreach($f in $previous.sourceFiles){if($f.path -notin $changed -and (Hash (Join-Path $repo $f.path)) -ne $f.sha256){throw ('Unrelated accumulated C# changed: '+$f.path)}}
$paths=@(@($previous.sourceFiles.path)+$added|Sort-Object -Unique)
if($paths.Count -ne 49){throw 'Wrong accumulated C# inventory'}
$sources=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
$paths|Set-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt') -Encoding utf8NoBOM
$groups=@{};$deltas=@();$identities=@();$count=0
foreach($group in $previous.allFormalGroups.PSObject.Properties){
 $now=Read ($group.Name+'/summary.json');$old=$group.Value;$groups[$group.Name]=$now
 if($now.rows.Count -ne $old.rows.Count -or $now.excluded.Count -ne $old.excluded.Count -or $now.policySha256 -ne $old.policySha256 -or $now.coreSha256 -ne $afterCore){throw 'Old formal inventory/policy/Core differs'}
 foreach($row in $now.rows){
  $match=@($old.rows|Where-Object id -ceq $row.id);if($match.Count -ne 1 -or $row.conclusion -ne 'Pass'){throw 'Old formal pass lost'}
  foreach($key in 'sourceSha256','executedRequestSha256','nativeDataSha256'){if($row.$key -ne $match[0].$key){throw 'Frozen old input changed'}}
  for($i=0;$i -lt $row.metrics.Count;$i++){
   $delta=$row.metrics[$i].nrmse-$match[0].metrics[$i].nrmse
   if($delta -gt 1e-8){throw ('Original NRMSE increase guard failed: '+$group.Name+'/'+$row.id+'/'+$i)}
   $deltas+=@{group=$group.Name;id=$row.id;series=$i;before=$match[0].metrics[$i].nrmse;after=$row.metrics[$i].nrmse;increase=$delta}
  }
  $relative=$group.Name+'/'+$row.id+'/normalized-zemax.json'
  if((Hash (Join-Path $PSScriptRoot $relative)) -ne (Hash (Join-Path $previousRoot $relative))){throw 'Normalized old native changed'}
  $relative=$group.Name+'/'+$row.id+'/normalized-workbench.json'
  $identities+=@{group=$group.Name;id=$row.id;inputHashesUnchanged=$true;normalizedNativeUnchanged=$true;workbenchUnchanged=((Hash (Join-Path $PSScriptRoot $relative)) -eq (Hash (Join-Path $previousRoot $relative)))}
  $count++
 }
}
if($count -ne 135){throw 'Expected 135 old formal instances'}
$expanded=@();$newCount=0
foreach($spec in @(@('matrix-circular','matrix-before',24),@('extended-controls-circular','extended-controls-before',6))){
 $now=Read ($spec[0]+'/summary.json');$old=Read ($spec[1]+'/summary.json');$groups[$spec[0]]=$now
 if($now.rows.Count -ne $spec[2] -or $now.excluded.Count -ne 0 -or $now.coreSha256 -ne $afterCore -or $old.coreSha256 -ne $beforeCore -or $now.policySha256 -ne $old.policySha256){throw 'New formal inventory/policy/Core differs'}
 foreach($row in $now.rows){
  $match=@($old.rows|Where-Object id -ceq $row.id);if($match.Count -ne 1 -or $row.conclusion -ne 'Pass' -or $row.metrics.Count -ne 2){throw 'New formal case incomplete'}
  foreach($key in 'sourceSha256','executedRequestSha256','nativeDataSha256'){if($row.$key -ne $match[0].$key){throw 'New counterfactual input changed'}}
  if(($row.metrics.nrmse|Measure-Object -Maximum).Maximum -ge 1e-8){throw 'Original 1e-8 energy guard failed'}
  $relative=$row.id+'/normalized-zemax.json'
  if((Hash (Join-Path $PSScriptRoot ($spec[0]+'/'+$relative))) -ne (Hash (Join-Path $PSScriptRoot ($spec[1]+'/'+$relative)))){throw 'New normalized native differs'}
  $expanded+=@{group=$spec[0];id=$row.id;before=$match[0].metrics;after=$row.metrics;inputHashesUnchanged=$true;normalizedNativeUnchanged=$true;strictGuard=1e-8;strictPass=$true}
  $newCount++
 }
}
if($newCount -ne 30){throw 'Expected 30 new native comparisons'}
$release=Tests 'Release.trx';$debug=Tests 'Debug.trx';$compRelease=Tests 'comparison-Release.trx';$compDebug=Tests 'comparison-Debug.trx';$newBefore=Tests 'new-before.trx'
foreach($spec in @(@($release,1148,$previous.verification.testRelease),@($debug,435,$previous.verification.testDebug),@($compRelease,5,$previous.verification.comparisonRelease),@($compDebug,5,$previous.verification.comparisonDebug))){
 $t=$spec[0];if($t.total -ne $spec[1] -or $t.passed -ne $spec[1] -or $t.failed -ne 0 -or $t.skipped -ne 0){throw 'Final tests incomplete'}
 foreach($name in $spec[2].names){if($name -cnotin $t.names){throw 'Old test identity lost'}}
}
if($newBefore.total -ne 64 -or $newBefore.failed -ne 26 -or $newBefore.passed -ne 38 -or $newBefore.skipped -ne 0){throw 'Before counterfactual proof incomplete'}
foreach($name in $newBefore.names){if($name -cnotin $release.names -or $name -cnotin $debug.names){throw 'New test identity missing after repair'}}
$configurations=@()
foreach($old in $previous.verification.configurations){
 $config=$old.configuration;$log=Join-Path $PSScriptRoot ('build-'+$config+'.log');$text=[IO.File]::ReadAllText($log)
 if(@([regex]::Matches($text,'(?m)^\s*[^\r\n]+ -> [^\r\n]+\.dll\r?$')).Count -ne 19 -or $text -notmatch '0 个警告' -or $text -notmatch '0 个错误'){throw 'Root build incomplete'}
 $expected=Hash (Join-Path $repo ('src/OpticalSystemDesign.Core/bin/'+$config+'/net10.0/OpticalSystemDesign.Core.dll'));$copies=@()
 foreach($copy in $old.coreCopies){$h=Hash (Join-Path $repo $copy.path);if($h -ne $expected){throw 'Default output Core mismatch'};$copies+=@{path=$copy.path;sha256=$h}}
 if($config -eq 'Release' -and $expected -ne $afterCore){throw 'Formal/test/build Core mismatch'}
 $configurations+=@{configuration=$config;projects=19;warnings=0;errors=0;coreCopies=$copies;logSha256=Hash $log}
}
$archives=@{};foreach($a in $previous.preservedArchives.PSObject.Properties){$archives[$a.Name]=$a.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen archive changed'}}
if($archives.Count -ne 25){throw 'Expected 25 preserved archives'}
$fixtures=@{};foreach($f in $previous.preservedNativeFixtures.PSObject.Properties){$fixtures[$f.Name]=$f.Value};foreach($f in $previous.newFixtures){$fixtures[[IO.Path]::GetFileName($f.path)]=$f.sha256}
foreach($name in $fixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $fixtures[$name]){throw 'Frozen native fixture changed'}}
if($fixtures.Count -ne 18){throw 'Expected 18 preserved native fixtures'}
$fixture=Read 'fixture-result.json';if((Hash (Join-Path $repo $fixture.path)) -ne $fixture.sha256 -or $fixture.cases -ne 30){throw 'New native fixture differs'}
$captures=@()
foreach($set in 'matrix','controls'){
 foreach($job in (Read ($set+'/native-jobs.json'))){
  $r=Get-Content $job.request -Raw|ConvertFrom-Json
  $s=Get-Content (Join-Path $job.output 'captured-settings.json') -Raw|ConvertFrom-Json
  $model=Get-Content (Join-Path $job.output 'model.json') -Raw|ConvertFrom-Json
  $env=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
  $batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json
  $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
  if(!$env.validLicense -or $env.opticStudioVersion -ne 260127 -or $batch.exitCode -ne 0 -or $model.units.LensUnits -ne 'Millimeters'){throw 'Native execution invalid'}
  if($s.properties.SampleSize -ne ('S_'+$r.pupilSampling+'x'+$r.pupilSampling) -or $r.imageSampling -ne 2*$r.pupilSampling -or $s.selectors.Wavelength -ne $r.wavelength -or $s.selectors.Field -ne 1 -or $s.properties.RadiusMaximum -ne 5 -or $s.properties.UsePolarization -or $s.properties.UseHuygensPSF -or $s.properties.Type -ne 'Encircled' -or $s.properties.ReferTo -ne 'Centroid'){throw 'Native readback settings differ'}
  if($model.fields[0].data.X -ne 0 -or $model.fields[0].data.Y -ne 0 -or $data.dataSeries.Count -ne 2 -or @($data.dataSeries|Where-Object {$_.y.Count -ne 401}).Count -ne 0){throw 'Native field or curves differ'}
  $captures+=@{set=$set;id=$job.id;sampling=$r.pupilSampling;wavelength=$r.wavelength;rayAiming=$model.rayAiming;aperture=$model.aperture;requestSha256=Hash $job.request;sourceSha256=Hash $r.input;dataSha256=Hash (Join-Path $job.output 'data.json');modelSha256=Hash (Join-Path $job.output 'model.json');capturedSettingsSha256=Hash (Join-Path $job.output 'captured-settings.json');environmentSha256=Hash (Join-Path $job.output 'environment.json');batchResultSha256=Hash (Join-Path $job.output 'batch-result.json');nativeVersion='2026 R1 build 260127';validLicense=$true;exitCode=0}
 }
}
if($captures.Count -ne 30){throw 'Native capture coverage incomplete'}
$geometry=Read 'solved-geometry-verified.json'
$geometryIdentity=Read 'geometry-core-identity.json'
if($geometryIdentity.probeCore -ne $afterCore -or $geometryIdentity.finalCore -ne $afterCore){throw 'Geometry probe Core differs'}
$beforeIdentity=Read 'before-test-identity.json'
if($beforeIdentity.beforeCoreSha256 -ne $beforeCore -or $beforeIdentity.candidateCoreSha256 -ne $afterCore -or !$beforeIdentity.candidateRestored){throw 'Counterfactual Core identity differs'}
foreach($spec in @(@('apo-epd-minus',5),@('apo-epd-plus',5),@('doublet-epd-minus',3),@('doublet-epd-plus-poly',3))){
 $row=@($geometry|Where-Object id -ceq $spec[0]);$surface=@($row[0].surfaces|Where-Object i -eq $spec[1])
 if($row.Count -ne 1 -or $surface.Count -ne 1 -or [Math]::Abs($surface[0].radius-$surface[0].nativeRadius) -ge 1e-10 -or [Math]::Abs($surface[0].thickness-$surface[0].nativeThickness) -ge 1e-10){throw 'Imported solve geometry guard failed'}
}
$target=@($groups['formal-final'].rows|Where-Object id -ceq '0472-n64-w3')[0]
if($target.metrics[1].nrmse -ge 1e-8){throw 'Original Relay target failed'}
$proof=@{date='2026-10-18';baseCommit=(git -C $repo rev-parse HEAD);scope='Six lenses at 256/512 selected/polychromatic FFT cumulative energy plus six independent aperture controls; imported curvature solve reconstruction';beforeCoreSha256=$beforeCore;afterCoreSha256=$afterCore;sourceFiles=$sources;productCodeChanged=@($changed)+@($added[0]);newTestSource=$added[1];target=$target;allFormalGroups=$groups;oldFormalValidCount=$count;newFormalValidCount=$newCount;formalValidCount=$count+$newCount;metricDeltas=$deltas;maximumOldNrmseIncrease=($deltas.increase|Measure-Object -Maximum).Maximum;priorComparisonIdentities=$identities;originalMatrixMaximumNrmse=($groups['formal-final'].rows.metrics.nrmse|Measure-Object -Maximum).Maximum;expandedComparisons=$expanded;maximumNewNrmse=($expanded.after.nrmse|Measure-Object -Maximum).Maximum;preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@($fixture);verification=@{testRelease=$release;testDebug=$debug;comparisonRelease=$compRelease;comparisonDebug=$compDebug;newTests=64;newBefore=$newBefore;beforeGuardIdentity=(Read 'before-test-identity.json');configurations=$configurations};nativeCaptures=$captures;nativeCaptureSummary=@{matrix=24;independentControls=6;totalNativeJobs=30;curves=60;pointsPerCurve=401;geometryGuards=4};solvedGeometry=$geometry;constraints=@{energyGuard=1e-8;geometryGuardMillimeters=1e-10;comparisonPolicyUnchanged=$true;oldInputHashesUnchanged=$true;physicalAperturesUnchanged=$true;nativeDataUsedAtRuntime=$false;lensIdentityUsedAtRuntime=$false;curveOrPhaseFitting=$false};boundaries=@('Selected on-axis captured settings at 256/512 only; no arbitrary sampling, field or prescription certification','Import-time curvature codes 2 and 11 for post-stop standard refractive surfaces; code 11 requires entrance pupil diameter; no live editor solve constraints','Native-private floating arithmetic inferred from independent controls, not a specification of private implementation','123456 request fieldDefinition descriptor remains Angle although its source FTYP is 3; actual source-defined field 1=(0,0) was used on both sides','Nonzero numerical differences remain below original guards; no installer, commit or push')}
$proof|ConvertTo-Json -Depth 80|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 80|Set-Content (Join-Path $repo 'docs/validation/EXPANDED_SAMPLING_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
@{formal=$proof.formalValidCount;newMaximum=$proof.maximumNewNrmse;oldIncrease=$proof.maximumOldNrmseIncrease;originalMatrix=$proof.originalMatrixMaximumNrmse;target=$target.metrics[1].nrmse;preservedArchives=$archives.Count;preservedFixtures=$fixtures.Count}|ConvertTo-Json
