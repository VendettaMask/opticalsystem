$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$runner=Join-Path $PSScriptRoot 'old-frequency-runner/Runner.dll'
Copy-Item (Join-Path $PSScriptRoot 'Core.frequency-candidate.dll') (Join-Path $PSScriptRoot 'old-frequency-runner/OpticalSystemDesign.Core.dll')
$specs=@(@('formal-frequency-candidate',''),@('extra-frequency-candidate','extra'),@('apochromat-frequency-candidate','new'),@('high-sampling-frequency-candidate','current'),@('fnum-frequency-candidate','latest'),@('polychromatic-frequency-candidate','poly'),@('polychromatic128-frequency-candidate','poly128'),@('boundary128-frequency-candidate','boundary128'),@('offner-frequency-candidate','offner'),@('decenter-frequency-candidate','decenter'),@('controls-frequency-candidate','relay64w3'),@('aiming-frequency-candidate','aiming'))
foreach($spec in $specs){
 $arguments=@($runner,$repo,(Join-Path $PSScriptRoot $spec[0]))
 if($spec[1]){$arguments+=@($spec[1])}
 dotnet @arguments *> (Join-Path $PSScriptRoot ($spec[0]+'.log'))
 if($LASTEXITCODE -ne 0){throw ('Formal failed: '+$spec[0])}
}


