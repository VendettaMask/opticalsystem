$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$runner=Join-Path $PSScriptRoot 'old-frequency-runner/Runner.dll'
Copy-Item (Join-Path $PSScriptRoot 'Core.frequency-candidate.dll') (Join-Path $PSScriptRoot 'old-frequency-runner/OpticalSystemDesign.Core.dll')
$specs=@(@('formal-frequency-candidate-v2',''),@('extra-frequency-candidate-v2','extra'),@('apochromat-frequency-candidate-v2','new'),@('high-sampling-frequency-candidate-v2','current'),@('fnum-frequency-candidate-v2','latest'),@('polychromatic-frequency-candidate-v2','poly'),@('polychromatic128-frequency-candidate-v2','poly128'),@('boundary128-frequency-candidate-v2','boundary128'),@('offner-frequency-candidate-v2','offner'),@('decenter-frequency-candidate-v2','decenter'),@('controls-frequency-candidate-v2','relay64w3'),@('aiming-frequency-candidate-v2','aiming'))
foreach($spec in $specs){
 $arguments=@($runner,$repo,(Join-Path $PSScriptRoot $spec[0]))
 if($spec[1]){$arguments+=@($spec[1])}
 dotnet @arguments *> (Join-Path $PSScriptRoot ($spec[0]+'.log'))
 if($LASTEXITCODE -ne 0){throw ('Formal failed: '+$spec[0])}
}


