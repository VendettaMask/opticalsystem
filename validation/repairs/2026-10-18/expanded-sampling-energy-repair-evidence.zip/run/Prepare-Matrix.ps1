$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$previous=Join-Path $repo 'artifacts/validation/dee-relay-stop-branch-20261018'
$summary=Get-Content (Join-Path $previous 'formal-final/summary.json') -Raw|ConvertFrom-Json
$base=Join-Path $repo 'artifacts/validation/dee-relay64w3-algorithm-20261018/controls-v2/original256.json'
$run=Join-Path $PSScriptRoot 'matrix';New-Item -ItemType Directory -Path $run|Out-Null
$jobs=@()
foreach($prefix in @('0014','0308','0360','0472','0592','0852')) {
 $row=@($summary.rows|Where-Object {$_.id.StartsWith($prefix+'-')})[0]
 $model=Get-Content (Join-Path $previous ('formal-final/'+$row.id+'/native/model.json')) -Raw|ConvertFrom-Json
 $primary=@($model.wavelengths|Where-Object {$_.data.IsPrimary})[0].number
 foreach($n in @(256,512)) {
  foreach($wave in @($primary,0)) {
   $id=$prefix+'-n'+$n+'-'+$(if($wave -eq 0){'poly'}else{'primary'})
   $r=Get-Content $base -Raw|ConvertFrom-Json
   $r.input=$row.source;$r.pupilSampling=$n;$r.imageSampling=2*$n;$r.wavelength=$wave
   $r.workbenchSettings.PupilSampling=[string]$n;$r.workbenchSettings.ImageSampling=[string](2*$n);$r.workbenchSettings.WavelengthNumber=[string]$wave
   $r.zemaxSettings.SampleSize='S_'+$n+'x'+$n;$r.zemaxSettings.HuygensSample=$r.zemaxSettings.SampleSize;$r.zemaxSettings.Wavelength=$wave
   $r.wavelengthScope=if($wave -eq 0){'All'}else{'Selected'};$r.wavelengthCount=$model.wavelengths.Count
   $r.primaryWavelengthMicrometers=@($model.wavelengths|Where-Object {$_.data.IsPrimary})[0].data.Wavelength
   $r.useRayAiming=$model.rayAiming.RayAiming -ne 'Off';$r.workbenchSettings.UseRayAiming=[string]$r.useRayAiming
   $r.surfaceCount=$model.surfaceCount;$r.fieldCount=$model.fields.Count;$r.definedFields=@($model.fields|ForEach-Object {,@($_.data.X,$_.data.Y)})
   $path=Join-Path $run ($id+'.json');$r|ConvertTo-Json -Depth 25|Set-Content $path -Encoding utf8NoBOM
   $jobs+=@{id=$id;request=$path;output=(Join-Path $run $id)}
  }
 }
}
$jobs|ConvertTo-Json -Depth 8|Set-Content (Join-Path $run 'native-jobs.json') -Encoding utf8NoBOM
'Prepared '+$jobs.Count+' high-sampling requests with synchronized nested settings.'
