$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$path=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-expanded-zemax-2026-r1.zip'
if(Test-Path $path){throw 'Never overwrite a frozen fixture'}
$payload=@{};$cases=@()
foreach($set in @('matrix','controls')){
 foreach($job in (Get-Content (Join-Path $PSScriptRoot "$set/native-jobs.json") -Raw|ConvertFrom-Json)){
  $r=Get-Content $job.request -Raw|ConvertFrom-Json;$id="$set/$($job.id)"
  $cases+=@{id=$id;set=$set;wavelength=$r.wavelength;sampling=$r.pupilSampling}
  $payload["$id/request.json"]=$job.request;$payload["$id/source.zmx"]=$r.input
  foreach($name in @('data.json','model.json','captured-settings.json','environment.json','batch-result.json')){$payload["$id/$name"]=Join-Path $job.output $name}
 }
}
$stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew);$records=@()
try{
 $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true)
 try{
  foreach($key in @($payload.Keys|Sort-Object)){
   $bytes=[IO.File]::ReadAllBytes($payload[$key]);$entry=$zip.CreateEntry($key,[IO.Compression.CompressionLevel]::Optimal);$s=$entry.Open();try{$s.Write($bytes)}finally{$s.Dispose()}
   $records+=@{path=$key;bytes=$bytes.Length;sha256=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($bytes))}
  }
  $manifest=@{schemaVersion=1;scope='Six standard lenses; 256/512 selected and polychromatic cumulative energy; six independent aperture controls; original 1e-8 precision guard';cases=$cases;entries=$records}|ConvertTo-Json -Depth 10
  $entry=$zip.CreateEntry('manifest.json');$s=$entry.Open();try{$s.Write([Text.Encoding]::UTF8.GetBytes($manifest))}finally{$s.Dispose()}
 }finally{$zip.Dispose()}
}finally{$stream.Dispose()}
$result=@{path='tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-expanded-zemax-2026-r1.zip';sha256=(Get-FileHash $path).Hash.ToLowerInvariant();bytes=(Get-Item $path).Length;cases=$cases.Count;payloadEntries=$records.Count}
$result|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'fixture-result.json') -Encoding utf8NoBOM
$result|ConvertTo-Json
