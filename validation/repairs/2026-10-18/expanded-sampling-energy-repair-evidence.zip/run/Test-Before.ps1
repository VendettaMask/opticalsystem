$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$core=Join-Path $repo 'tests/OpticalSystemDesign.Tests/bin/Release/net10.0/OpticalSystemDesign.Core.dll'
$candidate=[IO.File]::ReadAllBytes($core)
$candidateHash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($candidate))
$before=Join-Path $PSScriptRoot 'Core.before.dll'
try {
 Copy-Item $before $core
 dotnet test (Join-Path $repo 'tests/OpticalSystemDesign.Tests/OpticalSystemDesign.Tests.csproj') -c Release --no-build --no-restore --filter FullyQualifiedName~ExpandedSamplingEnergyTests --logger 'trx;LogFileName=new-before.trx' --results-directory (Join-Path $PSScriptRoot 'tests') *> (Join-Path $PSScriptRoot 'test-new-before.log')
 $exitCode=$LASTEXITCODE
 if($exitCode -eq 0){throw 'The frozen pre-repair Core unexpectedly passed the new regression'}
}finally{[IO.File]::WriteAllBytes($core,$candidate)}
if((Get-FileHash $core).Hash.ToLowerInvariant() -ne $candidateHash){throw 'Candidate Core restore failed'}
@{beforeCoreSha256=(Get-FileHash $before).Hash.ToLowerInvariant();candidateCoreSha256=$candidateHash;beforeExitCode=$exitCode;candidateRestored=$true}|ConvertTo-Json|Set-Content (Join-Path $PSScriptRoot 'before-test-identity.json') -Encoding utf8NoBOM
Get-Content (Join-Path $PSScriptRoot 'test-new-before.log') -Tail 3
