$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$runner=Join-Path $PSScriptRoot 'formal-runner/bin/Runner.dll'
Copy-Item (Join-Path $PSScriptRoot 'Core.candidate.dll') (Join-Path $PSScriptRoot 'formal-runner/bin/OpticalSystemDesign.Core.dll')
$specs=@(@('formal-candidate',''),@('extra-candidate','extra'),@('apochromat-candidate','new'),@('high-sampling-candidate','current'),@('fnum-candidate','latest'),@('polychromatic-candidate','poly'),@('polychromatic128-candidate','poly128'),@('boundary128-candidate','boundary128'),@('offner-candidate','offner'),@('decenter-candidate','decenter'),@('controls-candidate','relay64w3'),@('aiming-candidate','aiming'))
foreach($spec in $specs){
 $arguments=@($runner,$repo,(Join-Path $PSScriptRoot $spec[0]))
 if($spec[1]){$arguments+=@($spec[1])}
 dotnet @arguments *> (Join-Path $PSScriptRoot ($spec[0]+'.log'))
 if($LASTEXITCODE -ne 0){throw ('Formal failed: '+$spec[0])}
}


