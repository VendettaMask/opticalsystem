using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;

var repo=args[0];var task=Path.Combine(repo,"artifacts/validation/dee-extended-precision-20261018");
var id=args[1];var maxVariant=args.Length>2?int.Parse(args[2]):6;var ideal=args.Length<4||args[3]=="ideal";var firstVariant=args.Length>4?int.Parse(args[4]):0;
var control=!File.Exists(Path.Combine(task,"matrix",id+".json"));var requestPath=control?Path.Combine(task,"controls",id,"request.json"):Path.Combine(task,"matrix",id+".json");var capture=control?Path.Combine(task,"controls",id,"output"):Path.Combine(task,"matrix",id);
using var request=JsonDocument.Parse(File.ReadAllText(requestPath));var r=request.RootElement;
using var native=JsonDocument.Parse(File.ReadAllText(Path.Combine(capture,"data.json")));
using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(capture,"model.json")));
var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
var n=r.GetProperty("pupilSampling").GetInt32();var wn=r.GetProperty("wavelength").GetInt32();var waves=wn>0?new[]{optic.Wavelengths[wn-1]}:optic.Wavelengths.Where(w=>w.Weight>0).ToArray();var primary=optic.Wavelengths.First(w=>w.IsPrimary);var longest=waves.MaxBy(w=>w.Micrometers)!;
var flags=BindingFlags.Static|BindingFlags.NonPublic;var core=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",flags)!;var coneMethod=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",flags)!;var sphereMethod=typeof(DiffractionEngine).GetMethod("CumulativeEnergyReferenceSphere",flags)!;
var sphere=(WavefrontReferenceSphere)sphereMethod.Invoke(null,new object[]{optic,(0d,0d),primary})!;
var reference=Cone(primary);var pitch=Math.Sqrt(1d/n)/(2*reference.Item1/longest.Micrometers);var size=2*n;
var analysis=new DiffractionEncircledEnergyAnalysis(optic,n,size,401,wn,1,maximumDistanceMicrometers:5);
var build=typeof(DiffractionEncircledEnergyAnalysis).GetMethod("BuildCurve",BindingFlags.NonPublic|BindingFlags.Instance)!;
var expected=native.RootElement.GetProperty("dataSeries")[ideal?0:1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
var records=new List<object>();
for(var variant=firstVariant;variant<=maxVariant;variant++){
 var grids=new List<object>();var results=new List<PsfResult>();
 foreach(var w in waves){
  var cone=Cone(w);var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled);var stretch=Math.Sqrt(n/32d);PupilGridSpecification grid;
  if(waves.Length>1){var stepX=1/(n*pitch/w.Micrometers/(.5/reference.Item3));var stepY=1/(n*pitch/w.Micrometers/(.5/reference.Item2));grid=new(n,true,true,stepX*(n/2d-1)){ExplicitCoordinateStep=stepX,ExplicitCoordinateStepY=stepY};}
  else if(cone.Item2==cone.Item3&&cone.Item1==Math.BitIncrement(cone.Item2)){var step=(reference.Item1/cone.Item1)/Math.Sqrt(n);grid=new(n,true,true,step*(n/2d-1)){ExplicitCoordinateStep=step};}
  else {var defaultPitch=w.Micrometers*f*(n-2)/(2*n*stretch);var extentPerF=stretch*defaultPitch/pitch/f;grid=new(n,true,true,extentPerF*(.5/cone.Item3)){StretchY=extentPerF*(.5/cone.Item2)};}
  grid=grid with{UseCachedFftStopMap=true};
  if(variant is >=1 and <=3){var sx=grid.Coordinate(n/2+1);var sy=grid.YCoordinate(n/2+1);if(variant==2){sx=Math.BitDecrement(sx);sy=Math.BitDecrement(sy);}if(variant==3){sx=Math.BitIncrement(sx);sy=Math.BitIncrement(sy);}grid=grid with{ExplicitCoordinateStep=sx,ExplicitCoordinateStepY=sy};}
  if(variant==4){var step=w.Micrometers/longest.Micrometers/Math.Sqrt(n);grid=grid with{ExplicitCoordinateStep=step,ExplicitCoordinateStepY=step};}
  if(variant==5)grid=grid with{Stretch=Math.BitDecrement(grid.Stretch),StretchY=Math.BitDecrement(grid.StretchY??grid.Stretch),ExplicitCoordinateStep=grid.ExplicitCoordinateStep is {} a?Math.BitDecrement(a):null,ExplicitCoordinateStepY=grid.ExplicitCoordinateStepY is {} b?Math.BitDecrement(b):null};
  if(variant==6)grid=grid with{Stretch=Math.BitIncrement(grid.Stretch),StretchY=Math.BitIncrement(grid.StretchY??grid.Stretch),ExplicitCoordinateStep=grid.ExplicitCoordinateStep is {} a?Math.BitIncrement(a):null,ExplicitCoordinateStepY=grid.ExplicitCoordinateStepY is {} b?Math.BitIncrement(b):null};
  if(variant>=7){
   var axisX=waves.Length>1?reference.Item3:cone.Item3;var axisY=waves.Length>1?reference.Item2:cone.Item2;var rms=waves.Length>1?reference.Item1:cone.Item1;
   var sx=Step(axisX);var sy=Step(axisY);grid=grid with{ExplicitCoordinateStep=sx,ExplicitCoordinateStepY=sy};
   double Step(double mean)=>variant switch {
    7=>1/(n*pitch/w.Micrometers/(.5/mean)),
    8=>1/(n*(pitch*.001)/(w.Micrometers*.001)/(.5/mean)),
    9=>w.Micrometers/(n*pitch)*(.5/mean),
    10=>w.Micrometers/longest.Micrometers*(reference.Item1/mean)*Math.Sqrt(1d/n),
    11=>(w.Micrometers*.001)/(n*(pitch*.001))*(.5/mean),
    12=>1/(n*pitch*(1/w.Micrometers)/(.5/mean)),
    13=>1/(n*(pitch/w.Micrometers)/(.5/mean)),
    14=>1/(n*pitch/(w.Micrometers*(.5/mean))),
    15=>(.5/mean)/(n*pitch/w.Micrometers),
    _=>throw new Exception()
   };
  }
  var call=new object?[]{optic,(0d,0d),w,n,size,false,true,0d,null,null,true,ideal,optic.RayAimingEnabled,primary,pitch,true,null,sphere,grid};
  var psf=(PsfResult)core.Invoke(null,call)!;results.Add(psf);
  var samples=Enumerable.Range(0,n).SelectMany(y=>Enumerable.Range(0,n).Select(x=>(x:grid.Coordinate(x),y:grid.YCoordinate(y)))).Where(p=>p.x*p.x+p.y*p.y<=1).ToArray();
  grids.Add(new{wave=w.Micrometers,f,cone=new[]{cone.Item1,cone.Item2,cone.Item3},grid.Stretch,grid.StretchY,grid.ExplicitCoordinateStep,grid.ExplicitCoordinateStepY,count=samples.Length,edge=samples.Where(p=>Math.Abs(p.x*p.x+p.y*p.y-1)<1e-14).Select(p=>new[]{p.x,p.y}).ToArray()});
 }
 var waveScale=waves.Min(w=>w.Micrometers);var weightScale=waves.Max(w=>w.Weight);var weights=waves.Select(w=>w.Weight/weightScale*Math.Pow(waveScale/w.Micrometers,2)).ToArray();var tw=weights.Sum();
 var energies=new EnergySample[size*size];double sum=0,cx=0,cy=0;
 for(var y=0;y<size;y++)for(var x=0;x<size;x++){var p=results.Select((s,i)=>weights[i]*s.Values[(y+1)%size,(x+1)%size]).Sum()/tw;var xx=(x-size/2d+1)*pitch;var yy=(y-size/2d+1)*pitch;energies[y*size+x]=new(xx,yy,p);sum+=p;cx+=xx*p;cy+=yy*p;}
 var energyGrid=new FftCumulativeEnergyGrid(energies,(cx/sum,cy/sum),"encircled");var points=(IReadOnlyList<AnalysisPoint>)build.Invoke(analysis,new object[]{energyGrid,5d})!;
 var errors=points.Select((p,i)=>p.Y-expected[i]).ToArray();var nrmse=Math.Sqrt(errors.Average(v=>v*v))/(expected.Max()-expected.Min());var max=errors.Max(Math.Abs);
 records.Add(new{id,ideal,variant,pitch,nrmse,max,grids});Console.WriteLine(JsonSerializer.Serialize(new{id,ideal,variant,pitch,nrmse,max}));
}
File.WriteAllText(Path.Combine(task,id+"-"+(ideal?"ideal":"actual")+"-variants-"+firstVariant+".json"),JsonSerializer.Serialize(records));
(double,double,double) Cone(Wavelength w)=>(ValueTuple<double,double,double>)coneMethod.Invoke(null,new object[]{optic,(0d,0d),w})!;
