$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$prior=Join-Path $repo 'artifacts/validation/dee-offner128-20261018'
$original=Join-Path $repo 'artifacts/validation/dee-boundary-20261018/offner-holdouts/decenter-minus1p5.zmx'
$specs=@(@('minus1p5-64',-1.5,64),@('minus1p5-128',-1.5,128),@('minus1p5-256',-1.5,256),@('plus1p5-128',1.5,128),@('minus2p25-128',-2.25,128),@('minus1p75-128',-1.75,128))
$jobs=@();$dee=@();$rays=@()
foreach($spec in $specs){
 $id=$spec[0];$n=$spec[2];$dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir -Force|Out-Null
 $r=Get-Content (Join-Path $prior 'requests/decenter-minus1p5-128/dee.json') -Raw|ConvertFrom-Json
 if($spec[1] -ne -1.5){
  $text=[IO.File]::ReadAllText($original);$pattern='(?m)^(\s*PARM 2\s+)-1\.5\s*$'
  if([regex]::Matches($text,$pattern).Count -ne 1){throw 'Unexpected decenter source'}
  $source=Join-Path $dir 'source.zmx';[IO.File]::WriteAllText($source,[regex]::Replace($text,$pattern,('${1}'+[string]$spec[1])))
  $r.input=$source
 }
 $r.pupilSampling=$n;$r.imageSampling=2*$n;$r.workbenchSettings.PupilSampling=[string]$n;$r.workbenchSettings.ImageSampling=[string](2*$n);$r.zemaxSettings.SampleSize='S_'+$n+'x'+$n
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $job=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))};$jobs+=$job;$dee+=$job
 $ray=Get-Content (Join-Path $prior 'rays/decenter-minus1p5-128.json') -Raw|ConvertFrom-Json;$ray.input=$r.input
 $ray.rayAuditInputs=@($ray.rayAuditInputs|Select-Object -Last 5)
 $rayPath=Join-Path $dir 'rays.json';$ray|ConvertTo-Json -Depth 40|Set-Content $rayPath -Encoding utf8NoBOM
 $rays+=@{id=$id;request=$rayPath;output=(Join-Path $PSScriptRoot ('rays/'+$id))}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($dee) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'dee-jobs.json') -Encoding utf8NoBOM
New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot 'rays') -Force|Out-Null
Copy-Item (Join-Path $prior 'rays/source') (Join-Path $PSScriptRoot 'rays/source') -Recurse
Copy-Item (Join-Path $prior 'Run-NativeOpd.ps1') (Join-Path $PSScriptRoot 'Run-NativeOpd.ps1')
ConvertTo-Json -InputObject @($rays) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'rays/native-jobs.json') -Encoding utf8NoBOM
