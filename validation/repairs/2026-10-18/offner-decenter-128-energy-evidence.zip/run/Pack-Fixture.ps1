param([string]$CaseGroup='Directional',[string]$FixtureName='fft-cumulative-directional-zemax-2026-r1.zip',[string]$JobList='offner-holdouts/native-jobs.json')
$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$target=Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$FixtureName)
if(Test-Path -LiteralPath $target){throw 'Never replace a frozen fixture'}
$jobs=Get-Content (Join-Path $PSScriptRoot $JobList) -Raw|ConvertFrom-Json
$entries=@();$cases=@();$excluded=@();$payload=@{}
foreach($job in $jobs){
 $raw=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
 if($raw.dataSeries.Count -ne 2){$excluded+=@{id=$job.id;reason='Native reference has no usable pair of curves';messages=$raw.messages};continue}
 $request=Get-Content $job.request -Raw|ConvertFrom-Json
 $files=@(Get-ChildItem -LiteralPath $job.output -File|Where-Object {$_.Name -notin 'zemax.log','batch-result.json'})
 foreach($file in $files){$payload[$job.id+'/'+$file.Name]=[IO.File]::ReadAllBytes($file.FullName)}
 $payload[$job.id+'/request.json']=[IO.File]::ReadAllBytes($job.request)
 $payload[$job.id+'/source.zmx']=[IO.File]::ReadAllBytes($request.input)
 $cases+=@{id=$job.id;group=$CaseGroup;pupilSampling=$request.pupilSampling;wavelength=$request.wavelength;field=$request.field;seriesCount=2}
}
foreach($key in @($payload.Keys|Sort-Object)){$bytes=$payload[$key];$entries+=@{path=$key;bytes=$bytes.Length;sha256=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($bytes))}}
$manifest=@{schemaVersion=1;reference='Local Zemax OpticStudio 2026 R1';scope=$CaseGroup+' controls for FFT cumulative energy';cases=$cases;excluded=$excluded;entries=$entries}
$manifestJson=ConvertTo-Json $manifest -Depth 20
[IO.File]::WriteAllText((Join-Path $PSScriptRoot ($CaseGroup.ToLowerInvariant()+'-fixture-manifest.json')),$manifestJson)
$payload['manifest.json']=[Text.Encoding]::UTF8.GetBytes($manifestJson)
$stream=[IO.File]::Open($target,[IO.FileMode]::CreateNew)
try{$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$true);try{foreach($key in @($payload.Keys|Sort-Object)){$entry=$zip.CreateEntry($key,[IO.Compression.CompressionLevel]::Optimal);$entryStream=$entry.Open();try{$entryStream.Write($payload[$key])}finally{$entryStream.Dispose()}}}finally{$zip.Dispose()}}finally{$stream.Dispose()}
Get-FileHash -LiteralPath $target
