$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
& (Join-Path $PSScriptRoot 'Prepare-Proof.ps1') *> (Join-Path $PSScriptRoot 'proof-validation.log')
& (Join-Path $PSScriptRoot 'Pack-Evidence.ps1') *> (Join-Path $PSScriptRoot 'archive-validation.log')
$auditPath=Join-Path $PSScriptRoot 'documentation-audit-final.json'
& (Join-Path $repo 'scripts/verify-documentation.ps1') -RepositoryRoot $repo -OutputPath $auditPath -AuditDate 2026-10-18 -Strict *> (Join-Path $PSScriptRoot 'documentation-audit-final.log')
$audit=Get-Content $auditPath -Raw|ConvertFrom-Json
if($audit.Documents -ne 923 -or $audit.BrokenLinks.Count -ne 0 -or $audit.MarkdownFenceIssues.Count -ne 0 -or $audit.GuideRepeatedParagraphs.Count -ne 0){throw 'Documentation audit differs'}
$ledger=Join-Path $repo 'docs/validation/OFFNER_DECENTER_128_ENERGY_REPAIR_2026-10-18.json'
$proof=Get-Content $ledger -Raw|ConvertFrom-Json
$proof|Add-Member -NotePropertyName postArchiveDocumentationAudit -NotePropertyValue @{documents=$audit.Documents;brokenLinks=0;markdownFenceIssues=0;guideRepeatedParagraphGroups=0;sha256=(Get-FileHash $auditPath).Hash.ToLowerInvariant();path='artifacts/validation/dee-offner-decenter128-20261018/documentation-audit-final.json'}
$proof|ConvertTo-Json -Depth 60|Set-Content $ledger -Encoding utf8NoBOM
$archive=Join-Path $repo $proof.evidenceArchive.path
if((Get-FileHash $archive).Hash.ToLowerInvariant() -ne $proof.evidenceArchive.sha256){throw 'Final archive hash mismatch'}
$zip=[IO.Compression.ZipFile]::OpenRead($archive)
try{
 foreach($path in @('docs/CURRENT_STATUS.md','docs/NUMERICAL_PARITY.md','docs/OPEN_ISSUES_2026-10-08.md')){
  $stream=$zip.GetEntry('source/'+$path).Open();try{$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
  if($hash -ne (Get-FileHash (Join-Path $repo $path)).Hash.ToLowerInvariant()){throw 'Archived current documentation differs'}
 }
 $stream=$zip.GetEntry('report/OFFNER_DECENTER_128_ENERGY_REPAIR_2026-10-18.md').Open();try{$hash=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
 if($hash -ne (Get-FileHash (Join-Path $repo 'docs/OFFNER_DECENTER_128_ENERGY_REPAIR_2026-10-18.md')).Hash.ToLowerInvariant()){throw 'Archived report differs'}
}finally{$zip.Dispose()}
foreach($s in $proof.sourceFiles){if((Get-FileHash (Join-Path $repo $s.path)).Hash.ToLowerInvariant() -ne $s.sha256){throw 'Final source changed'}}
foreach($c in $proof.verification.configurations){foreach($copy in $c.coreCopies){if((Get-FileHash (Join-Path $repo $copy.path)).Hash.ToLowerInvariant() -ne $copy.sha256){throw 'Final default Core changed'}}}
git -C $repo diff --check;if($LASTEXITCODE -ne 0){throw 'Final diff check failed'}
'Final archive, current documents, source hashes and default Core copies verified.'
