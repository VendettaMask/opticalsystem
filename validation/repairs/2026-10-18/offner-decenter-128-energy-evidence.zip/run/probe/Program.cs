using System.Text.Json;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Rays;
var repo=args[0];var task=Path.Combine(repo,"artifacts/validation/dee-offner-decenter128-20261018");var output=new List<object>();
foreach(var id in new[]{"minus1p5-128","plus1p5-128","minus2p25-128","minus1p75-128"}) {
 using var req=JsonDocument.Parse(File.ReadAllText(Path.Combine(repo,$"artifacts/validation/dee-offner-decenter128-20261018/requests/{id}/dee.json")));
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(req.RootElement.GetProperty("input").GetString()!),".zmx");var w=optic.Wavelengths[0];var ss=optic.SurfaceGroup.Items;var frame=ss[^1].CoordinateSystem;
 var c=optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,0,0,w.Micrometers,false).Rays[0];var cz=optic.Paraxial.EstimateEntrancePupilLocation();var pupil=c.Origin+c.Direction*((cz-c.Origin.Z)/c.Direction.Z);var end=optic.SequentialRayTracer.TraceToSurface(c,ss.Count-1)!;var cp=frame.ToLocalPoint(end.Position);var cd=frame.ToLocalDirection(end.Direction);var rows=new List<object>();
 foreach(var h in new[]{1e-6*(pupil-c.Origin).Length,1e-4,1e-5})foreach(var axis in new[]{0,1}){
  var a=axis==0?new Vector3D(1,0,0):new Vector3D(0,1,0);var plus=Trace(h);var minus=Trace(-h);var pp=frame.ToLocalPoint(plus.Position);var pd=frame.ToLocalDirection(plus.Direction);var mp=frame.ToLocalPoint(minus.Position);var md=frame.ToLocalDirection(minus.Direction);
  double Pos(Vector3D p)=>axis==0?p.X:p.Y;double Slope(Vector3D d)=>(axis==0?d.X:d.Y)/d.Z;
  var one=-(Pos(pp)-Pos(cp))/(Slope(pd)-Slope(cd));var other=-(Pos(cp)-Pos(mp))/(Slope(cd)-Slope(md));var sym=-(Pos(pp)-Pos(mp))/(Slope(pd)-Slope(md));rows.Add(new{h,axis,plus=one,minus=other,symmetric=sym});
  RayTraceSample Trace(double offset){var origin=c.Origin+a*offset;var d=pupil-origin;return optic.SequentialRayTracer.TraceToSurface(new RealRay(origin,d/d.Length,w.Nanometers),ss.Count-1)!;}
 }
 var r=new{id,pupil,origin=c.Origin,cp,cd,rows};output.Add(r);Console.WriteLine(JsonSerializer.Serialize(r));
}
File.WriteAllText(Path.Combine(task,"pupil-neighbor-differences.json"),JsonSerializer.Serialize(output));
