$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadJson([string]$relative){Get-Content (Join-Path $PSScriptRoot $relative) -Raw|ConvertFrom-Json}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/OFFNER_128_ENERGY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$unchangedTests=@($previous.sourceFiles|Where-Object {$_.path -like 'tests/*.cs'})
foreach($s in $unchangedTests){if((Hash (Join-Path $repo $s.path)) -ne $s.sha256){throw 'Previously verified test source changed'}}
$release=Tests 'related-release-final.trx';$debug=Tests 'related-debug-final.trx'
foreach($run in @($release,$debug)){
 if($run.passed -ne $run.total -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Final main tests incomplete'}
 if(@($run.names|Where-Object {$_ -match '\.OffnerDecenter128EnergyTests\.'}).Count -ne 12){throw 'New twelve checks missing'}
}
if($release.total -ne 1040 -or $debug.total -ne 327){throw 'Final test scope differs'}
foreach($name in $previous.verification.testRelease.names){if($name -cnotin $release.names){throw 'Prior Release identity missing'}}
foreach($name in $previous.verification.testDebug.names){if($name -cnotin $debug.names){throw 'Prior Debug identity missing'}}
foreach($name in $debug.names){if($name -cnotin $release.names){throw 'Debug identity absent from Release'}}
$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx'
foreach($run in @($comparisonRelease,$comparisonDebug)){if($run.total -ne 5 -or $run.passed -ne 5 -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Comparison tests incomplete'}}
$beforeTests=Tests 'offner-decenter128-before.trx'
if($beforeTests.total -ne 12 -or $beforeTests.failed -ne 6 -or $beforeTests.passed -ne 6 -or $beforeTests.skipped -ne 0){throw 'Before counterexample differs'}
$beforeHash=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeHash -ne $previous.verification.configurations[0].coreCopies[0].sha256){throw 'Wrong prior Core'}
$execution=ReadJson 'before-test-execution.json';if($execution.executedCoreSha256 -ne $beforeHash){throw 'Counterexample Core differs'}
$configurations=foreach($configuration in @('Release','Debug')){
 $log=Get-Content (Join-Path $PSScriptRoot ('build-'+$configuration.ToLowerInvariant()+'-final.log')) -Raw
 if(@($log -split "`n"|Where-Object {$_ -match ' -> '}).Count -ne 19 -or !$log.Contains('0 个警告') -or !$log.Contains('0 个错误')){throw 'Default solution build incomplete'}
 $paths=@("src/OpticalSystemDesign.Core/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tools/OpticalSystemDesign.ZemaxComparison/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll")
 $copies=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
 if(@($copies.sha256|Sort-Object -Unique).Count -ne 1 -or (Hash (Join-Path $PSScriptRoot ('Core.'+$configuration.ToLowerInvariant()+'-final.dll'))) -ne $copies[0].sha256){throw 'Default Core copies differ'}
 @{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies}
}
$summaries=@{};$comparisons=@();$pointwise=@()
foreach($spec in @(@('formal-final',$previous.formalAfter,48,0),@('extra-final',$previous.independentControls,6,1),@('apochromat-final',$previous.priorApochromatControls,5,2),@('high-sampling-final',$previous.priorHighSamplingControls,8,0),@('fnum-final',$previous.priorFNumberControls,5,0),@('polychromatic-final',$previous.priorPolychromaticControls,15,0),@('polychromatic128-final',$previous.priorPolychromatic128Controls,12,0),@('boundary128-final',$previous.priorPolychromatic128BoundaryControls,8,0),@('offner-final',$previous.newControlsAfter,6,0))){
 $current=ReadJson ($spec[0]+'/summary.json');$summaries[$spec[0]]=$current
 if($current.rows.Count -ne $spec[2] -or $current.excluded.Count -ne $spec[3]){throw 'Old formal inventory differs'}
 foreach($row in $current.rows){
  $old=@($spec[1].rows|Where-Object id -ceq $row.id)
  if($old.Count -ne 1 -or $row.sourceSha256 -ne $old[0].sourceSha256 -or $row.executedRequestSha256 -ne $old[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $old[0].nativeDataSha256){throw 'Old source/request/reference changed'}
  $a=($row.metrics|Measure-Object nrmse -Maximum).Maximum;$b=($old[0].metrics|Measure-Object nrmse -Maximum).Maximum
  if($null -eq $a -or $null -eq $b -or $a -gt $b+1e-8){throw ('Old numerical regression: '+$row.id)}
  $comparisons+=@{group=$spec[0];id=$row.id;beforeWorstNrmse=$b;afterWorstNrmse=$a;increase=($a-$b)}
  $oldGroup=if($spec[0] -eq 'offner-final'){'controls-final'}else{$spec[0]}
  $oldPath=Join-Path $repo ('artifacts/validation/dee-offner128-20261018/'+$oldGroup+'/'+$row.id+'/normalized-workbench.json')
  $pointwise+=@{group=$spec[0];id=$row.id;normalizedBytesUnchanged=((Hash $oldPath) -eq (Hash (Join-Path $PSScriptRoot ($spec[0]+'/'+$row.id+'/normalized-workbench.json'))))}
 }
}
if($comparisons.Count -ne 113){throw 'Missing prior formal controls'}
$new=ReadJson 'controls-final/summary.json';$newBefore=ReadJson 'controls-before/summary.json';$summaries['controls-final']=$new
if($new.rows.Count -ne 6 -or $new.excluded.Count -ne 0 -or $newBefore.coreSha256 -ne $beforeHash){throw 'New controls differ'}
foreach($summary in $summaries.Values){
 if($summary.coreSha256 -ne $configurations[0].coreCopies[0].sha256){throw 'Final comparison Core differs'}
 if($summary.policySha256 -ne $previous.formalAfter.policySha256 -or $summary.policySha256 -ne (Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'))){throw 'Original tolerance changed'}
 if(@($summary.rows|Where-Object conclusion -ne 'Pass').Count -ne 0){throw 'Formal comparison failed'}
}
foreach($row in $new.rows){
 $old=@($newBefore.rows|Where-Object id -ceq $row.id)
 if($old.Count -ne 1 -or $row.sourceSha256 -ne $old[0].sourceSha256 -or $row.executedRequestSha256 -ne $old[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $old[0].nativeDataSha256){throw 'New comparison input changed'}
 if(@($row.metrics|Where-Object nrmse -ge 1e-8).Count -ne 0){throw 'New precision guard failed'}
}
$target=@($new.rows|Where-Object id -ceq 'minus1p5-128')[0]
if($target.metrics[1].nrmse -ge 1e-10){throw 'Target residual remains above diagnostic goal'}
$archives=@{};foreach($p in $previous.preservedArchives.PSObject.Properties){$archives[$p.Name]=$p.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen archive changed'}}
if($archives.Count -ne 20){throw 'Expected twenty prior archives'}
$fixtures=@{};foreach($p in $previous.preservedNativeFixtures.PSObject.Properties){$fixtures[$p.Name]=$p.Value};foreach($f in $previous.newFixtures){$fixtures[$f.name]=$f.sha256}
foreach($name in $fixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $fixtures[$name]){throw 'Frozen fixture changed'}}
if($fixtures.Count -ne 14){throw 'Expected fourteen prior fixtures'}
$fixturePath=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-offner-decenter128-zemax-2026-r1.zip';$zip=[IO.Compression.ZipFile]::OpenRead($fixturePath)
try{
 $reader=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open());try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
 foreach($entry in $manifest.entries){$stream=$zip.GetEntry($entry.path).Open();try{$h=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($h -ne $entry.sha256){throw 'New fixture payload changed'}}
 if($manifest.cases.Count -ne 6 -or $manifest.excluded.Count -ne 0){throw 'New fixture inventory differs'}
 $fixture=@{name=[IO.Path]::GetFileName($fixturePath);sha256=Hash $fixturePath;cases=6;excluded=@();payloadEntries=$manifest.entries.Count}
}finally{$zip.Dispose()}
$captures=@();$dee=0;$rays=0
foreach($list in @('native-jobs.json','rays/native-jobs.json')){foreach($job in @(ReadJson $list)){
 $request=Get-Content $job.request -Raw|ConvertFrom-Json;$batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json
 $environment=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
 if($batch.exitCode -ne 0 -or $environment.major -ne 26 -or $environment.minor -ne 1 -or $environment.opticStudioVersion -ne 260127 -or !$environment.validLicense){throw 'Native version/license or run differs'}
 if($request.adapter -eq 'ray-audit'){
  $data=Get-Content (Join-Path $job.output 'ray-audit.json') -Raw|ConvertFrom-Json
  if($data.inputs.Count -ne 5 -or @($data.launches|Where-Object success -ne $true).Count -ne 0 -or @($data.surfaces.rays|Where-Object error -ne 0).Count -ne 0 -or ![double]::IsFinite($data.exitPupilPosition)){throw 'Ray audit incomplete'};$rays++
 }else{
  $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
  if($data.dataSeries.Count -ne 2){throw 'Missing DEE curves'}
  foreach($s in $data.dataSeries){if($s.x.Count -ne 401 -or $s.y.Count -ne 401){throw 'Incomplete DEE curves'};foreach($y in $s.y){if($y.Count -ne 1 -or ![double]::IsFinite($y[0]) -or $y[0] -lt 0 -or $y[0] -gt 1){throw 'Invalid energy'}}};$dee++
 }
 $captures+=@{id=$job.id;request=$job.request;requestSha256=Hash $job.request;output=$job.output;inputSha256=Hash $request.input;environment=$environment;environmentSha256=Hash (Join-Path $job.output 'environment.json');dataSha256=Hash (Join-Path $job.output $(if($request.adapter -eq 'ray-audit'){'ray-audit.json'}else{'data.json'}))}
}}
if($dee -ne 6 -or $rays -ne 6){throw 'Native capture inventory differs'}
$repeated=Join-Path $PSScriptRoot 'native/minus1p5-128/data.json';$oldNative=Join-Path $repo 'artifacts/validation/dee-offner128-20261018/native/decenter-minus1p5-128/data.json'
if((Hash $repeated) -ne (Hash $oldNative)){throw 'Original target native repeat changed'}
$sources=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
if($sources.Count -ne 44){throw 'Changed C# inventory differs'}
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log');if($LASTEXITCODE -ne 0){throw 'Diff check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='Offner -1.5 mm decenter n128 residual closed with n64/256, mirrored +1.5 mm and two independent nearby decenters'
 beforeCoreSha256=$beforeHash;beforeTests=$beforeTests;beforeTestExecution=$execution
 constraints=@{originalTolerancePolicyUnchanged=$true;all113PriorFormalPassesPreserved=$true;noPriorNrmseIncreaseAbove1eMinus8=$true;prior1028ReleaseIdentitiesPreserved=$true;prior315FocusedDebugIdentitiesPreserved=$true;unchangedPriorTestSources=$unchangedTests;independentCookeTessarExcluded=$true}
 verification=@{testRelease=$release;testDebug=$debug;comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;configurations=$configurations;newMainTests=12;newPrecisionChecks=12;debugScope='Prior focused 315 plus twelve native-curve checks';format=@{includedCSharpFiles=44;exitCode=0;log='format-verify.log'};gitDiffCheckExitCode=0}
 formalBefore=$previous.formalAfter;formalAfter=$summaries['formal-final'];independentControls=$summaries['extra-final'];priorApochromatControls=$summaries['apochromat-final'];priorHighSamplingControls=$summaries['high-sampling-final'];priorFNumberControls=$summaries['fnum-final'];priorPolychromaticControls=$summaries['polychromatic-final'];priorPolychromatic128Controls=$summaries['polychromatic128-final'];priorPolychromatic128BoundaryControls=$summaries['boundary128-final'];priorOffnerControls=$summaries['offner-final'];newControlsBefore=$newBefore;newControlsAfter=$new;oldNumericalControls=$comparisons;unchangedPathControls=$pointwise
 supportProof=@{targetNativeRepeat=@{dataSha256=Hash $repeated;priorDataSha256=Hash $oldNative;exactBytesUnchanged=$true};finiteProbeDiagnosis=ReadJson 'pupil-neighbor-differences.json';note='Earlier task established physical-ray and complex-pupil support parity. New ray-audit captures supply native EXPP and geometric rays; experimental OPDMode.Current is retained but never used for phase or acceptance. Probe interval is the pre-existing one-microradian scale, not fitted to reference energy. Native internal finite-difference step is not publicly specified or claimed identical.'}
 numericalLimitations=@{allResidualsZero=$false;targetClosed=$true;target=$target;originalMatrixWorstNrmse=($summaries['formal-final'].rows.metrics|Measure-Object nrmse -Maximum).Maximum;largestPriorNrmseIncrease=($comparisons|Measure-Object increase -Maximum).Maximum;unchangedNormalizedFiles=@($pointwise|Where-Object normalizedBytesUnchanged).Count;samplingScope='Captured on-axis, single-wave finite folded Y-decenter systems only; no general rotated, tilted, off-axis or universal EXPP certification'}
 preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@($fixture);sourceFiles=$sources
 nativeCaptureSummary=@{attempts=12;usableCaptures=12;deeCaptures=6;rayAuditCaptures=6;requestErrors=0;nativeUnavailable=0};nativeCaptures=$captures
 retainedFailureRecords=@('tests/offner-decenter128-before.trx','tests-before.log','controls-before/summary.json','controls-candidate/summary.json');boundaries=@{fullRepositorySuiteRun=$false;fullDebugSuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false;generalNativeFoldedPupilConventionCertified=$false;nativeOpdCurrentUsedForAcceptance=$false}
 references=@('https://ansyshelp.ansys.com/public/Views/Secured/Zemax/v252/en/OpticStudio_User_Guide/OpticStudio_Help/topics/Exit_Pupil_Position.html','https://ansyshelp.ansys.com/public/Views/Secured/Zemax/v26102/en/OpticStudio_User_Guide/OpticStudio_Help/topics/Exit_Pupil.html')
}
$proof|ConvertTo-Json -Depth 65|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 65|Set-Content (Join-Path $repo 'docs/validation/OFFNER_DECENTER_128_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified target closure, all 113 prior formal passes, 1040/327 tests and preserved evidence.'
