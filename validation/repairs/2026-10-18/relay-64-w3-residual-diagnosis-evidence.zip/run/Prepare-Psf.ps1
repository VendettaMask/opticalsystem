$ErrorActionPreference='Stop'
$jobs=@();$dir=Join-Path $PSScriptRoot 'psf';New-Item -ItemType Directory -Path $dir|Out-Null
foreach($id in @('relay-n64-w1','relay-n64-w2','relay-n64-w3','relay-n128-w3')){
 $r=Get-Content (Join-Path $PSScriptRoot ('requests/'+$id+'/dee.json')) -Raw|ConvertFrom-Json
 $pitch=(Get-Content (Join-Path $PSScriptRoot ('native/'+$id+'-huygens/data.json')) -Raw|ConvertFrom-Json).dataGrids[0].dx
 $n=$r.pupilSampling;$r.canonicalAnalysisKey='PSF';$r.analysisType='FftPsf';$r.imageDeltaMicrometers=$pitch
 foreach($type in @('Linear','Real','Imaginary')){
  $r.zemaxSettings=[ordered]@{Normalize=$false;OutputSize=('PsfS_'+(2*$n)+'x'+(2*$n));SampleSize=('PsfS_'+$n+'x'+$n);ImageDelta=$pitch;Wavelength=$r.wavelength;Surface=-1;Rotation='CW0';Type=$type;Field=1;UsePolarization=$false}
  $path=Join-Path $dir ($id+'-'+$type+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-'+$type;request=$path;output=(Join-Path $dir ($id+'-'+$type))}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $dir 'native-jobs.json') -Encoding utf8NoBOM
