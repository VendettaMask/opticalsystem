$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$template=Join-Path $repo 'artifacts/validation/dee-multi-lens-20261018/spectral/0472-n64-w3/request.json'
$jobs=@();$dee=@()
foreach($spec in @(@(32,3),@(64,3),@(128,3),@(256,3),@(64,1),@(64,2))){
 $n=$spec[0];$w=$spec[1];$id='relay-n'+$n+'-w'+$w
 $dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir|Out-Null
 $r=Get-Content $template -Raw|ConvertFrom-Json;$r.pupilSampling=$n;$r.imageSampling=2*$n;$r.wavelength=$w
 $r.workbenchSettings.PupilSampling=[string]$n;$r.workbenchSettings.ImageSampling=[string](2*$n);$r.workbenchSettings.WavelengthNumber=[string]$w
 $r.zemaxSettings.SampleSize='S_'+$n+'x'+$n;$r.zemaxSettings.Wavelength=$w
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $job=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))};$jobs+=$job;$dee+=$job
 $r.canonicalAnalysisKey='Huygens PSF';$r.analysisType='HuygensPsf';$r.imageSampling=32;$r.imageDeltaMicrometers=0
 $r.zemaxSettings=[ordered]@{Normalize=$false;PupilSampleSize=('S_'+$n+'x'+$n);ImageSampleSize='S_32x32';ImageDelta=0;Wavelength=$w;UseCentroid=$false;Configuration=1;Rotation='Rotate_0';Type='Linear';Field=1;UsePolarization=$false}
 $path=Join-Path $dir 'huygens.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$id+'-huygens';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-huygens'))}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($dee) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'dee-jobs.json') -Encoding utf8NoBOM
