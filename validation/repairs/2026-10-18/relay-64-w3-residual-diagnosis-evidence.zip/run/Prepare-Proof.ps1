$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadJson([string]$relative){Get-Content (Join-Path $PSScriptRoot $relative) -Raw|ConvertFrom-Json}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/OFFNER_DECENTER_128_ENERGY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$beforeHash=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeHash -ne $previous.verification.configurations[0].coreCopies[0].sha256){throw 'Wrong prior Core'}
foreach($source in $previous.sourceFiles){if((Hash (Join-Path $repo $source.path)) -ne $source.sha256){throw ('Previously verified C# changed: '+$source.path)}}
if($previous.sourceFiles.Count -ne 44){throw 'Source inventory differs'}
foreach($configuration in $previous.verification.configurations){foreach($copy in $configuration.coreCopies){if((Hash (Join-Path $repo $copy.path)) -ne $copy.sha256){throw 'Default Core changed'}}}
$release=Tests 'related-release-final.trx';$debug=Tests 'related-debug-final.trx'
if($release.total -ne 1040 -or $debug.total -ne 327){throw 'Test inventory differs'}
foreach($pair in @(@($release,$previous.verification.testRelease),@($debug,$previous.verification.testDebug))){
 $current=$pair[0];$old=$pair[1]
 if($current.total -ne $current.passed -or $current.failed -ne 0 -or $current.skipped -ne 0 -or @($current.names).Count -ne @($old.names).Count){throw 'Tests incomplete'}
 foreach($name in $old.names){if($name -cnotin $current.names){throw 'Old test identity missing'}}
}
$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx'
foreach($r in @($comparisonRelease,$comparisonDebug)){if($r.total -ne 5 -or $r.passed -ne 5 -or $r.failed -ne 0 -or $r.skipped -ne 0){throw 'Comparator tests incomplete'}}
$summaries=@{};$identity=@()
foreach($spec in @(@('formal-final',$previous.formalAfter,48,0),@('extra-final',$previous.independentControls,6,1),@('apochromat-final',$previous.priorApochromatControls,5,2),@('high-sampling-final',$previous.priorHighSamplingControls,8,0),@('fnum-final',$previous.priorFNumberControls,5,0),@('polychromatic-final',$previous.priorPolychromaticControls,15,0),@('polychromatic128-final',$previous.priorPolychromatic128Controls,12,0),@('boundary128-final',$previous.priorPolychromatic128BoundaryControls,8,0),@('offner-final',$previous.priorOffnerControls,6,0),@('decenter-final',$previous.newControlsAfter,6,0))){
 $current=ReadJson ($spec[0]+'/summary.json');$summaries[$spec[0]]=$current
 if($current.rows.Count -ne $spec[2] -or $current.excluded.Count -ne $spec[3]){throw 'Old formal inventory differs'}
 foreach($row in $current.rows){
  $old=@($spec[1].rows|Where-Object id -ceq $row.id)
  if($old.Count -ne 1 -or $row.sourceSha256 -ne $old[0].sourceSha256 -or $row.executedRequestSha256 -ne $old[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $old[0].nativeDataSha256){throw 'Old comparison input changed'}
  $oldGroup=if($spec[0] -eq 'decenter-final'){'controls-final'}else{$spec[0]}
  $oldFile=Join-Path $repo ('artifacts/validation/dee-offner-decenter128-20261018/'+$oldGroup+'/'+$row.id+'/normalized-workbench.json')
  $newFile=Join-Path $PSScriptRoot ($spec[0]+'/'+$row.id+'/normalized-workbench.json')
  if((Hash $oldFile) -ne (Hash $newFile)){throw 'Old normalized curve bytes changed'}
  $identity+=@{group=$spec[0];id=$row.id;normalizedSha256=Hash $newFile;allInputHashesUnchanged=$true;normalizedBytesUnchanged=$true}
 }
}
if($identity.Count -ne 119){throw 'Missing prior formal comparisons'}
$fresh=ReadJson 'controls-final/summary.json';$summaries['controls-final']=$fresh
if($fresh.rows.Count -ne 6 -or $fresh.excluded.Count -ne 0){throw 'Fresh sampling controls incomplete'}
$policy=Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json')
foreach($summary in $summaries.Values){if($summary.coreSha256 -ne $beforeHash -or $summary.policySha256 -ne $policy -or $policy -ne $previous.formalAfter.policySha256 -or @($summary.rows|Where-Object conclusion -ne 'Pass').Count -ne 0){throw 'Core, policy or formal status changed'}}
$target=@($summaries['formal-final'].rows|Where-Object id -ceq '0472-n64-w3')[0]
if($target.metrics[1].nrmse -ne 1.0480732682054777e-8){throw 'Frozen target residual changed unexpectedly'}
$archives=@{};foreach($p in $previous.preservedArchives.PSObject.Properties){$archives[$p.Name]=$p.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen archive changed'}}
if($archives.Count -ne 21){throw 'Expected twenty-one prior archives'}
$fixtures=@{};foreach($p in $previous.preservedNativeFixtures.PSObject.Properties){$fixtures[$p.Name]=$p.Value};foreach($f in $previous.newFixtures){$fixtures[$f.name]=$f.sha256}
foreach($name in $fixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $fixtures[$name]){throw 'Frozen fixture changed'}}
if($fixtures.Count -ne 15){throw 'Expected fifteen prior fixtures'}
$captures=@();$overrides=@();$counts=@{dee=0;psf=0;rays=0}
foreach($list in @('native-jobs.json','psf/native-jobs.json','rays/native-jobs.json','cache-diagnostic/native-jobs.json','convergence-diagnostic/native-jobs.json','enhanced-diagnostic/native-jobs.json')){foreach($job in @(ReadJson $list)){
 $request=Get-Content $job.request -Raw|ConvertFrom-Json;$batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json
 $environment=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
 if($batch.exitCode -ne 0 -or $environment.major -ne 26 -or $environment.minor -ne 1 -or $environment.opticStudioVersion -ne 260127 -or !$environment.validLicense){throw 'Native capture failed or version/license differs'}
 $modelPath=Join-Path $job.output 'model.json';$model=Get-Content $modelPath -Raw|ConvertFrom-Json
 if($request.adapter -eq 'ray-audit'){
  $dataPath=Join-Path $job.output 'ray-audit.json';$data=Get-Content $dataPath -Raw|ConvertFrom-Json
  if($data.inputs.Count -notin @(5,193) -or @($data.launches|Where-Object success -ne $true).Count -ne 0 -or @($data.surfaces.rays|Where-Object error -ne 0).Count -ne 0){throw 'Ray audit incomplete'};$counts.rays++
 }else{
  $dataPath=Join-Path $job.output 'data.json';$data=Get-Content $dataPath -Raw|ConvertFrom-Json
  if($request.analysisType -eq 'DiffractionEncircledEnergy'){
   if($data.dataSeries.Count -ne 2){throw 'Missing DEE curves'};foreach($s in $data.dataSeries){if($s.x.Count -ne 401 -or $s.y.Count -ne 401){throw 'Incomplete DEE'};foreach($y in $s.y){if($y.Count -ne 1 -or ![double]::IsFinite($y[0]) -or $y[0] -lt 0 -or $y[0] -gt 1){throw 'Invalid energy'}}};$counts.dee++
  }else{
   if($data.dataGrids.Count -ne 1){throw 'Missing PSF'};$g=$data.dataGrids[0]
   if($g.nx -ne $request.imageSampling -or $g.ny -ne $request.imageSampling -or $g.values.Count -ne $g.ny -or $g.dx -le 0 -or $g.dy -le 0){throw 'Invalid PSF dimensions'}
   foreach($row in $g.values){if($row.Count -ne $g.nx){throw 'Incomplete PSF'};foreach($value in $row){if(![double]::IsFinite($value) -or ($value -lt 0 -and $request.zemaxSettings.Type -notin @('Real','Imaginary'))){throw 'Invalid PSF sample'}}};$counts.psf++
  }
 }
 $captures+=@{group=$list;id=$job.id;request=$job.request;requestSha256=Hash $job.request;output=$job.output;inputSha256=Hash $request.input;modelSha256=Hash $modelPath;environment=$environment;dataSha256=Hash $dataPath;rayAimingReadback=$model.rayAiming}
 if($list -like '*diagnostic/*'){$overrides+=@{group=$list;id=$job.id;nativeAcceptance=$false;standaloneCanonicalRequestDoesNotDescribeHostOverrides=$true;rayAimingReadback=$model.rayAiming;hostSourceIdentities=(Join-Path ([IO.Path]::GetDirectoryName((Join-Path $PSScriptRoot $list))) 'host/source-identities.json')}}
}}
if($captures.Count -ne 39 -or $counts.dee -ne 14 -or $counts.psf -ne 20 -or $counts.rays -ne 5){throw 'Native capture inventory differs'}
$overrides|ConvertTo-Json -Depth 20|Set-Content (Join-Path $PSScriptRoot 'diagnostic-overrides.json') -Encoding utf8NoBOM
$reference=Join-Path $repo 'artifacts/validation/dee-multi-lens-20261018/spectral/0472-n64-w3/data.json'
foreach($path in @('native/relay-n64-w3/data.json','cache-diagnostic/original-dee/data.json')){if((Hash (Join-Path $PSScriptRoot $path)) -ne (Hash $reference)){throw 'Original-setting native repeat changed'}}
$phase=@(ReadJson 'phase-diagnosis.json');$pupil=@($phase|Where-Object {$null -ne $_.nodes})
if($pupil.Count -ne 4 -or @($pupil|Where-Object {$_.supportMismatch -ne 0 -or $_.intensityError -gt 1e-14 -or $_.publicReconstructionError -ne 0 -or $_.nativePsfNrmse -gt 2e-11}).Count -ne 0){throw 'Native pupil/integrator isolation differs'}
$decimal=@($phase|Where-Object mode -eq 'decimal');if($decimal.Count -ne 3){throw 'Decimal diagnostic incomplete'}
$replay=@(ReadJson 'ray-replay.json');foreach($r in $replay){if(($r.rows.replayPointError|Measure-Object -Maximum).Maximum -gt 1e-12){throw 'Native launch transport replay differs'}}
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log');if($LASTEXITCODE -ne 0){throw 'Diff check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='Relay n64 selected wavelength 3 numerical diagnosis; target residual remains open; no product repair claimed'
 targetClosed=$false;target=$target;coreUnchanged=$true;beforeCoreSha256=$beforeHash;afterCoreSha256=Hash (Join-Path $repo 'src/OpticalSystemDesign.Core/bin/Release/net10.0/OpticalSystemDesign.Core.dll')
 constraints=@{originalTolerancePolicyUnchanged=$true;all119PriorFormalPassesPreserved=$true;all119NormalizedFilesByteIdentical=$true;productAndPriorTestSourcesUnchanged=$true;independentCookeTessarExcluded=$true;diagnosticOverridesNotAcceptance=$true}
 verification=@{testRelease=$release;testDebug=$debug;comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;newMainTests=0;defaultConfigurationsUnchanged=$previous.verification.configurations;rootSolutionBuiltThisTask=$false;diagnosticToolsBuilt=$true;gitDiffCheckExitCode=0}
 formalAfter=$summaries['formal-final'];priorComparisonIdentities=$identity;samplingAndWavelengthCaptures=$fresh;allFormalGroups=$summaries
 supportProof=@{nativePupils=$pupil;decimalAuxiliary=$decimal;rayReplay=$replay|ForEach-Object {@{id=$_.id;maximumOwnPointError=($_.rows.ownPointError|Measure-Object -Maximum).Maximum;maximumReplayPointError=($_.rows.replayPointError|Measure-Object -Maximum).Maximum;maximumLaunchDirectionError=($_.rows.launchDirectionError|Measure-Object -Maximum).Maximum}};allCandidateMetrics=@($phase|Where-Object {$null -eq $_.nodes});note='Decimal is independent diagnostic arithmetic using imported double prescription/index inputs, never product evaluation or external numerical authority. Cache/advanced/enhanced captures change settings and cannot replace original acceptance.'}
 nativeCaptureSummary=@{attempts=39;usableCaptures=39;deeCaptures=14;psfCaptures=20;rayAuditCaptures=5;requestErrors=0;nativeUnavailable=0};nativeCaptures=$captures;diagnosticOverrides=$overrides
 preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@();sourceFiles=$previous.sourceFiles
 retainedDiagnosticFailure='decimal-diagnostic-initial-failure.log';boundaries=@{numericalResidualResolved=$false;productCodeChanged=$false;newPrecisionClosureClaimed=$false;fullRepositorySuiteRun=$false;fullDebugSuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false}
 references=@('https://ansyshelp.ansys.com/public/Views/Secured/Zemax/v252/en/OpticStudio_User_Guide/OpticStudio_Help/topics/Ray_Aiming.html','https://optics.ansys.com/hc/en-us/articles/42661958377491-Introduction-to-Enhanced-Ray-Aiming-and-Ray-Aiming-Wizard')
}
$proof|ConvertTo-Json -Depth 65|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 65|Set-Content (Join-Path $repo 'docs/validation/RELAY_64_W3_RESIDUAL_DIAGNOSIS_2026-10-18.json') -Encoding utf8NoBOM
'Verified unchanged product, open target residual, 119 original comparisons, 1040/327 tests and 39 native captures.'
