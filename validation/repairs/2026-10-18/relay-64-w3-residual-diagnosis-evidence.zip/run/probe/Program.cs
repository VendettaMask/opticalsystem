using System.Numerics;
using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Rays;
var repo=args[0];var task=Path.Combine(repo,"artifacts/validation/dee-relay64w3-20261018");var rows=new List<object>();
var cm=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;
foreach(var id in new[]{"relay-n64-w1","relay-n64-w2","relay-n64-w3","relay-n128-w3"}){
 using var req=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"requests/{id}/dee.json")));var r=req.RootElement;var n=r.GetProperty("pupilSampling").GetInt32();var m=2*n;
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=true;var reference=optic.Wavelengths.First(w=>w.IsPrimary);var w=optic.Wavelengths[r.GetProperty("wavelength").GetInt32()-1];
 var cp=((double Rms,double T,double S))cm.Invoke(null,new object[]{optic,(0d,0d),reference})!;var cone=((double Rms,double T,double S))cm.Invoke(null,new object[]{optic,(0d,0d),w})!;var pitch=Math.Sqrt(1d/n)/(2*cp.Rms/w.Micrometers);var auto=Math.Sqrt(n/32d);
 var psf=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),new[]{w},n,false)[0].Result;
 var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,true);double Extent(double na)=>n>=128?auto*(w.Micrometers*f*(n-2)/(2*n*auto))/pitch/f*(.5/na):auto*(w.Micrometers*(.5/na)*(n-2)/(2*n*auto))/pitch;
 var grid=new PupilGridSpecification(n,true,true,Extent(cone.S)){StretchY=Extent(cone.T)};
 if(cone.T==cone.S&&cone.Rms==Math.BitIncrement(cone.T)){var step=(cp.Rms/cone.Rms)/Math.Sqrt(n);grid=new(n,true,true,step*(n/2d-1)){ExplicitCoordinateStep=step};}
 var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),reference,true);var wf=WavefrontEngine.GenerateChiefRayGrid(optic,(0,0),w,grid,true,reference,sphere);var direct=wf.Samples.ToDictionary(s=>(grid.ColumnIndex(s.NormalizedPupilX),grid.RowIndex(s.NormalizedPupilY)),s=>s);
 object?[] p={optic,(0d,0d),w,n,m,false,true,0d,null,null,true,false,true,reference,pitch,true,null,sphere,grid};var alternate=(PsfResult)compute.Invoke(null,p)!;var core=(Complex[,])p[16]!;
 var real=Read("Real");var imag=Read("Imaginary");var linear=Read("Linear");var native=new Complex[m,m];var intensityError=0d;
 for(var y=0;y<m;y++)for(var x=0;x<m;x++){native[y,x]=new(real[y,x],imag[y,x]);intensityError=Math.Max(intensityError,Math.Abs(native[y,x].Magnitude*native[y,x].Magnitude-linear[y,x]));}
 DiffractionEngine.FourierTransform2D(native,true);var maximum=native.Cast<Complex>().Max(v=>v.Magnitude);var nodes=new List<object>();var errors=new List<double>();var support=0;
 for(var y=0;y<n;y++)for(var x=0;x<n;x++){
  var ix=x-n/2;var iy=y-n/2;var value=native[(-iy+m)%m,(-ix+m)%m]*(((ix+iy)%2==0)?1:-1);var actual=core[y,x];var illuminated=value.Magnitude>maximum*.5;
  if(illuminated!=(actual.Magnitude>.5)){support++;continue;}if(!illuminated)continue;
  var raw=direct[(x,y)];var np=-value.Phase;var error=Math.Atan2(Math.Sin(actual.Phase-np),Math.Cos(actual.Phase-np));errors.Add(error);var rawError=Math.Atan2(Math.Sin(-2*Math.PI*raw.OpdWaves-np),Math.Cos(-2*Math.PI*raw.OpdWaves-np));
  nodes.Add(new{x=ix,y=iy,px=raw.NormalizedPupilX,py=raw.NormalizedPupilY,nativePhase=np,corePhase=actual.Phase,error,rawError,rawOpd=raw.OpdWaves});
 }
 using var dee=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"native/{id}/data.json")));var expected=dee.RootElement.GetProperty("dataSeries")[1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
 var result=new{id,n,pitch,cone=new{cone.Rms,cone.T,cone.S},cp=new{cp.Rms,cp.T,cp.S},sphere,grid,publicReconstructionError=psf.Values.Cast<double>().Zip(alternate.Values.Cast<double>(),(a,b)=>Math.Abs(a-b)).Max(),intensityError,supportMismatch=support,count=errors.Count,maxPhaseError=errors.Max(Math.Abs),actualNrmse=Metric(Curve(psf.Values),expected),nativePsfNrmse=Metric(Curve(linear),expected),nodes};rows.Add(result);Console.WriteLine(JsonSerializer.Serialize(new{id,result.count,result.supportMismatch,result.maxPhaseError,result.actualNrmse,result.nativePsfNrmse,result.publicReconstructionError}));
 foreach(var mode in new[]{"fourier-step","normalized-ratio","default-fft","directional-step","system-cone"}){
  var sx=1/(n*pitch/w.Micrometers/(.5/cone.S));var sy=1/(n*pitch/w.Micrometers/(.5/cone.T));
  if(mode=="normalized-ratio"){sx=Math.Sqrt(1d/n)*cp.Rms/cone.S;sy=Math.Sqrt(1d/n)*cp.Rms/cone.T;}
  if(mode=="default-fft"){sx=sy=auto*(w.Micrometers*f*(n-2)/(2*n*auto))/pitch/(n/2d-1);}
  if(mode=="directional-step"){var axes=DiffractionEngine.WorkingFNumbers(optic,(0,0),w,true,true);sx=1/(n*pitch/w.Micrometers/axes.Sagittal);sy=1/(n*pitch/w.Micrometers/axes.Tangential);}
  if(mode=="system-cone")sx=sy=Math.Sqrt(1d/n)*cp.Rms/cone.Rms;
  var gg=new PupilGridSpecification(n,true,true,sx*(n/2d-1)){ExplicitCoordinateStep=sx,ExplicitCoordinateStepY=sy};object?[] pp={optic,(0d,0d),w,n,m,false,true,0d,null,null,true,false,true,reference,pitch,true,null,sphere,gg};var candidate=(PsfResult)compute.Invoke(null,pp)!;var diag=new{id,mode,sx,sy,count=WavefrontEngine.GenerateChiefRayGrid(optic,(0,0),w,gg,true,reference,sphere).Samples.Count,nrmse=Metric(Curve(candidate.Values),expected)};rows.Add(diag);Console.WriteLine(JsonSerializer.Serialize(diag));
 }
 if(n==64){var dir=Path.Combine(task,"rays");Directory.CreateDirectory(dir);var q=System.Text.Json.Nodes.JsonNode.Parse(r.GetRawText())!;q["adapter"]="ray-audit";q["surfaceRecordLimit"]=10000;q["removeVignettingFactors"]=false;q["rayAuditInputs"]=JsonSerializer.SerializeToNode(wf.Samples.Select((s,i)=>new{hx=0d,hy=0d,px=s.NormalizedPupilX,py=s.NormalizedPupilY,fieldIndex=0,pupilIndex=i}));File.WriteAllText(Path.Combine(dir,id+".json"),q.ToJsonString());
  using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(dir,id+"/ray-audit.json")));var launches=audit.RootElement.GetProperty("launches");var origin=optic.SurfaceGroup.Items[0].CoordinateSystem;
  foreach(var comparisonMode in new[]{"convergence","enhanced"}){using var alternateReference=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"{comparisonMode}-diagnostic/{id}/data.json")));var high=alternateReference.RootElement.GetProperty("dataSeries")[1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();var altRow=new{id,mode="native-"+comparisonMode,coreVersusHigh=Metric(Curve(psf.Values),high),nativeOriginalVersusHigh=Metric(expected,high)};rows.Add(altRow);Console.WriteLine(JsonSerializer.Serialize(altRow));}
  var im=typeof(WavefrontEngine).GetMethod("ImageToReferenceSphere",BindingFlags.Static|BindingFlags.NonPublic)!;
  double ImagePath(RayTraceSample ray,double radius)=>(double)im.Invoke(null,new object[]{ray,sphere.CenterX,sphere.CenterY,sphere.CenterZ,radius,1d})!;
  var chief=optic.SequentialRayTracer.TraceToSurface(optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,0,0,w.Micrometers,true).Rays[0],optic.SurfaceGroup.Items.Count-1)!;
  var chiefRay=optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,0,0,w.Micrometers,true).Rays[0];
  var chiefHistory=optic.SequentialRayTracer.Trace(new RealRayBundle(new[]{chiefRay})).RayHistories.Single();
  var precise=new DecimalMeridional(optic,w,sphere);
  foreach(var mode in new[]{"prepared","reordered","replay","replay-reordered","native-radius","stable-sphere","segmented","geometric","local-sag","polish","polish-local-sag","decimal"}){
   var radius=mode=="native-radius"?Math.Abs(audit.RootElement.GetProperty("exitPupilPosition").GetDouble()):sphere.Radius;var ci=ImagePath(chief,radius);
   var modified=wf with{Samples=wf.Samples.Select((s,i)=>{
    var launch=launches[i];var ray=mode.StartsWith("replay")?new RealRay(origin.ToGlobalPoint(Vector(launch,"x","y","z")),origin.ToGlobalDirection(Vector(launch,"l","m","n")),w.Nanometers):optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,s.NormalizedPupilX,s.NormalizedPupilY,w.Micrometers,true).Rays[0];
    if(mode.StartsWith("polish")){
     var stop=optic.SurfaceGroup.Items.ToList().FindIndex(sf=>sf.IsStop);var frame=optic.SurfaceGroup.Items[stop].CoordinateSystem;var pm=optic.SequentialRayTracer.RayGenerator.GetType().GetMethod("ParaxialStopTarget",BindingFlags.Instance|BindingFlags.NonPublic)!;var target=((double X,double Y))pm.Invoke(optic.SequentialRayTracer.RayGenerator,new object[]{s.NormalizedPupilX,s.NormalizedPupilY,stop})!;
     for(var iteration=0;iteration<3;iteration++){
      var ux=ray.Direction.X/ray.Direction.Z;var uy=ray.Direction.Y/ray.Direction.Z;const double h=1e-6;var p0=Sample(ux,uy);var p1=Sample(ux+h,uy);var p2=Sample(ux,uy+h);var ex=target.X-p0.X;var ey=target.Y-p0.Y;if(double.Hypot(ex,ey)<2e-15)break;var a=(p1.X-p0.X)/h;var b=(p2.X-p0.X)/h;var c=(p1.Y-p0.Y)/h;var d=(p2.Y-p0.Y)/h;var determinant=a*d-b*c;var dx=(d*ex-b*ey)/determinant;var dy=(a*ey-c*ex)/determinant;var nd=new Vector3D(ux+dx,uy+dy,1);ray=new RealRay(ray.Origin,nd/nd.Length,w.Nanometers);
      Vector3D Sample(double x,double y){var dd=new Vector3D(x,y,1);return frame.ToLocalPoint(optic.SequentialRayTracer.TraceToSurface(new RealRay(ray.Origin,dd/dd.Length,w.Nanometers),stop)!.Position);}
     }
    }
    var final=optic.SequentialRayTracer.TraceToSurface(ray,optic.SurfaceGroup.Items.Count-1)!;var imagePath=ImagePath(final,radius);
    var opd=mode=="prepared"?s.OpdWaves:(mode=="stable-sphere"?chief.CumulativeOpticalPathLength-final.CumulativeOpticalPathLength+Delta(final)-Delta(chief):mode.EndsWith("reordered")?chief.CumulativeOpticalPathLength-final.CumulativeOpticalPathLength-(ci-imagePath):(chief.CumulativeOpticalPathLength-ci)-(final.CumulativeOpticalPathLength-imagePath))/(w.Micrometers*.001);
    if(mode is "segmented" or "geometric" or "local-sag" or "polish-local-sag"){
     var history=optic.SequentialRayTracer.Trace(new RealRayBundle(new[]{ray})).RayHistories.Single();var difference=0d;var lastChief=chiefRay.Origin;var last=ray.Origin;
     var vertex=chiefRay.Origin;var previousChief=Vector3D.Zero;var previousRay=Vector3D.Zero;
     for(var k=0;k<history.Count;k++){
      if(mode=="segmented")difference+=chiefHistory[k].SegmentOpticalPathLength-history[k].SegmentOpticalPathLength;
      else if(mode is "local-sag" or "polish-local-sag"){
       var surface=optic.SurfaceGroup.Items[k];var frame=surface.CoordinateSystem;var cl=frame.ToLocalPoint(chiefHistory[k].Position);var rl=frame.ToLocalPoint(history[k].Position);
       cl=cl with{Z=surface.Geometry.Sag(cl.X,cl.Y)};rl=rl with{Z=surface.Geometry.Sag(rl.X,rl.Y)};
       var cv=frame.ToGlobalDirection(cl);var rv=frame.ToGlobalDirection(rl);var aLocal=cv-previousChief;var bLocal=rv-previousRay;var vertexDelta=frame.Origin-vertex;var a=vertexDelta+aLocal;var b=vertexDelta+bLocal;var delta=aLocal-bLocal;var sum=vertexDelta*2+aLocal+bLocal;var denominator=a.Length+b.Length;
       difference+=denominator==0?0:(history[k].RefractiveIndexBefore??1)*optic.Backend.Current.Dot(delta,sum)/denominator;
       vertex=frame.Origin;previousChief=cv;previousRay=rv;
      }
      else{var a=chiefHistory[k].Position-lastChief;var b=history[k].Position-last;var index=history[k].SegmentLength==0?1:history[k].SegmentOpticalPathLength/history[k].SegmentLength;var delta=a-b;var sum=a+b;var denominator=a.Length+b.Length;difference+=denominator==0?0:index*optic.Backend.Current.Dot(delta,sum)/denominator;lastChief=chiefHistory[k].Position;last=history[k].Position;}
     }
     opd=(difference+Delta(final)-Delta(chief))/(w.Micrometers*.001);
    }
    double Delta(RayTraceSample rt){var p=rt.Position-new Vector3D(sphere.CenterX,sphere.CenterY,sphere.CenterZ);var d=rt.Direction/rt.Direction.Length;var dot=optic.Backend.Current.Dot(p,d);var cross=optic.Backend.Current.Cross(p,d);var q=cross.Length*cross.Length;return dot-q/(radius+Math.Sqrt(radius*radius-q));}
    if(mode=="decimal")opd=precise.Opd(s.NormalizedPupilX,s.NormalizedPupilY);
    return s with{OpdWaves=opd,Intensity=s.Intensity>0?s.LaunchIntensity??s.Intensity:0};
   }).ToArray()};
   object?[] pp={optic,(0d,0d),w,n,m,false,true,0d,modified,null,true,false,true,reference,0d,true,null,sphere,grid};var candidate=(PsfResult)compute.Invoke(null,pp)!;
   var diag=new{id,mode,nrmse=Metric(Curve(candidate.Values),expected),coreDifferenceNrmse=Metric(Curve(candidate.Values),Curve(psf.Values)),maxOpdDifferenceWaves=modified.Samples.Zip(wf.Samples,(a,b)=>Math.Abs(a.OpdWaves-b.OpdWaves)).Max()};rows.Add(diag);Console.WriteLine(JsonSerializer.Serialize(diag));
  }
 }
 double[,] Read(string type){using var d=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"psf/{id}-{type}/data.json")));var v=d.RootElement.GetProperty("dataGrids")[0].GetProperty("values");var a=new double[m,m];for(var y=0;y<m;y++)for(var x=0;x<m;x++)a[(y+1)%m,(x+1)%m]=v[y][x].GetDouble();return a;}
 double[] Curve(double[,] a){var samples=Enumerable.Range(0,m).SelectMany(y=>Enumerable.Range(0,m).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,a[(y+1)%m,(x+1)%m]))).ToArray();var total=samples.Sum(s=>s.Weight);var c=(samples.Sum(s=>s.X*s.Weight)/total,samples.Sum(s=>s.Y*s.Weight)/total);var eg=new FftCumulativeEnergyGrid(samples,c,"encircled");var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var e=axis.Select(eg.Fraction).ToArray();e[0]=0;e[1]=e[2]/4;var values=MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,e,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());var previous=0d;return values.Select(v=>previous=Math.Clamp(Math.Max(previous,v),0,1)).ToArray();}
}
File.WriteAllText(Path.Combine(task,"phase-diagnosis.json"),JsonSerializer.Serialize(rows));
static double Metric(double[] a,double[] b)=>Math.Sqrt(a.Zip(b,(x,y)=>(x-y)*(x-y)).Average())/(b.Max()-b.Min());
static Vector3D Vector(JsonElement e,string a,string b,string c)=>new(e.GetProperty(a).GetDouble(),e.GetProperty(b).GetDouble(),e.GetProperty(c).GetDouble());
