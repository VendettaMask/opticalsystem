using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var root=Path.Combine(args[0],"artifacts/validation/dee-poly128-20261018");const int n=128,m=256;
var cm=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;
using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"dee-jobs.json")));var rows=new List<object>();
foreach(var job in jobs.RootElement.EnumerateArray()){
 using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=request.RootElement;
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 var waves=optic.Wavelengths.ToArray();var reference=waves.First(w=>w.IsPrimary);var longest=waves.MaxBy(w=>w.Micrometers)!;
 var cp=((double Rms,double T,double S))cm.Invoke(null,new object[]{optic,(0d,0d),reference})!;
 var pitch=Math.Sqrt(1d/n)/(2*cp.Rms/longest.Micrometers);var automatic=Math.Sqrt(n/32d);var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),reference,optic.RayAimingEnabled);
 using var expected=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"data.json")));
 foreach(var ideal in new[]{true,false}){
  var spectrum=waves.Select(w=>{
   var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled);var dp=w.Micrometers*f*(n-2)/(2*n*automatic);var perF=automatic*dp/pitch/f;
   var sx=perF*(.5/cp.S);var sy=perF*(.5/cp.T);var grid=new PupilGridSpecification(n,true,true,sx){ExplicitCoordinateStep=sx/(n/2d-1),ExplicitCoordinateStepY=sy/(n/2d-1)};
   return (PsfResult)compute.Invoke(null,new object?[]{optic,(0d,0d),w,n,m,false,true,0d,null,null,true,ideal,optic.RayAimingEnabled,reference,pitch,true,null,sphere,grid})!;
  }).ToArray();
  var samples=Enumerable.Range(0,m).SelectMany(y=>Enumerable.Range(0,m).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,spectrum.Select((p,i)=>waves[i].Weight/Math.Pow(waves[i].Micrometers,2)*p.Values[(y+1)%m,(x+1)%m]).Sum()))).ToArray();var total=samples.Sum(s=>s.Weight);var grid=new FftCumulativeEnergyGrid(samples,(samples.Sum(s=>s.X*s.Weight)/total,samples.Sum(s=>s.Y*s.Weight)/total),"encircled");
  var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(grid.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;var yy=MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());var previous=0d;yy=yy.Select(v=>previous=Math.Clamp(Math.Max(previous,v),0,1)).ToArray();var referenceValues=expected.RootElement.GetProperty("dataSeries")[ideal?0:1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
  var nrmse=Math.Sqrt(yy.Zip(referenceValues,(a,b)=>(a-b)*(a-b)).Average())/(referenceValues.Max()-referenceValues.Min());
  rows.Add(new{id=job.GetProperty("id").GetString(),ideal,pitch,nrmse,counts=ideal?spectrum.Select(p=>100d*m*m/p.Values.Cast<double>().Sum()).ToArray():null});
 }
}
File.WriteAllText(Path.Combine(root,"cross-lens-diagnosis.json"),JsonSerializer.Serialize(rows));Console.WriteLine(JsonSerializer.Serialize(rows));
