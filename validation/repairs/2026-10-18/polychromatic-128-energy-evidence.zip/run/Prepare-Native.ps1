$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$jobs=@();$dee=@()
foreach($code in @('0014','0308','0472','0852')){
 $template=Join-Path $repo ('artifacts/validation/numerical-residuals-20261018/holdout/'+$code+'-all-waves/request.json')
 $r=Get-Content $template -Raw|ConvertFrom-Json
 $r.pupilSampling=128;$r.imageSampling=256;$r.workbenchSettings.PupilSampling='128';$r.workbenchSettings.ImageSampling='256';$r.zemaxSettings.SampleSize='S_128x128'
 $id=$code+'-poly128';$dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir|Out-Null
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $job=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))};$jobs+=$job;$dee+=$job
 if($code -eq '0014'){
  $r.canonicalAnalysisKey='Huygens PSF';$r.analysisType='HuygensPsf';$r.imageSampling=32;$r.imageDeltaMicrometers=0
  $r.zemaxSettings=[ordered]@{Normalize=$false;PupilSampleSize='S_128x128';ImageSampleSize='S_32x32';ImageDelta=0;Wavelength=0;UseCentroid=$false;Configuration=1;Rotation='Rotate_0';Type='Linear';Field=1;UsePolarization=$false}
  $path=Join-Path $dir 'huygens.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-huygens';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-huygens'))}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($dee) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'dee-jobs.json') -Encoding utf8NoBOM
