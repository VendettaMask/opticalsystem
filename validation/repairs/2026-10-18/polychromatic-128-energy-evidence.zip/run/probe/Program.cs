using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-poly128-20261018");
const int n=128,m=256;
using var request=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"requests/0014-poly128/dee.json")));
var optic=OpticalFormatCatalog.Import(File.ReadAllText(request.RootElement.GetProperty("input").GetString()!),".zmx");
var waves=optic.Wavelengths.ToArray();var primary=waves.First(w=>w.IsPrimary);var longest=waves.MaxBy(w=>w.Micrometers)!;
var fp=DiffractionEngine.WorkingFNumber(optic,(0,0),primary);var cm=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
var cp=((double Rms,double T,double S))cm.Invoke(null,new object[]{optic,(0d,0d),primary})!;
var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;
var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),primary,false);
using var hu=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"native/0014-poly128-huygens/data.json")));
var nativePitch=hu.RootElement.GetProperty("dataGrids")[0].GetProperty("dx").GetDouble();
var nativeGrids=Enumerable.Range(1,8).Select(w=>ReadGrid(Path.Combine(task,$"isolation/w{w}/fft/data.json"))).ToArray();
var nativePoly=ReadGrid(Path.Combine(task,"isolation/poly-fft/data.json"));
var nativeReference=ReadCurves(Path.Combine(task,"native/0014-poly128/data.json"));
var nativeRows=new List<object>();
nativeRows.Add(new{id="poly",nrmse=Metric(Curve(new[]{nativePoly},new[]{1d},nativePitch),nativeReference[1])});
for(var i=0;i<8;i++){
 var expected=ReadCurves(Path.Combine(task,$"isolation/w{i+1}/dee/data.json"));
 nativeRows.Add(new{id=$"wave{i+1}",nrmse=Metric(Curve(new[]{nativeGrids[i]},new[]{1d},nativePitch),expected[1]),count=m*(double)m/nativeGrids[i].Cast<double>().Sum(),peak=nativeGrids[i].Cast<double>().Max()});
}
var weights=waves.Select(w=>w.Weight/(w.Micrometers*w.Micrometers)).ToArray();var wsum=weights.Sum();var mixtureError=0d;
for(var y=0;y<m;y++)for(var x=0;x<m;x++)mixtureError=Math.Max(mixtureError,Math.Abs(nativeGrids.Select((a,i)=>a[y,x]*weights[i]).Sum()/wsum-nativePoly[y,x]));
var rows=new List<object>();
var centerDiagnostics=new List<object>();
foreach(var offset in new[]{"centroid","zero","symmetricEdges","trimEdges"}){
 var yy=Curve(new[]{nativePoly},new[]{1d},nativePitch,offset);
 var errors=yy.Zip(nativeReference[1],(a,b)=>a-b).ToArray();
 centerDiagnostics.Add(new{offset,nrmse=Metric(yy,nativeReference[1]),worstIndex=Enumerable.Range(0,401).MaxBy(i=>Math.Abs(errors[i])),errors=Enumerable.Range(0,401).Where(i=>i<12||i%20==0).Select(i=>new{i,x=5d*i/400,error=errors[i]}).ToArray()});
}
foreach(var mode in new[]{"current","lowConvention","referenceCone","referenceConeExplicit","nativePitchLow","nativePitchCone","nativePitchCommonF"})foreach(var ideal in new[]{true,false}){
 var pitch=mode.StartsWith("nativePitch")?nativePitch:longest.Micrometers*fp/Math.Sqrt(n);
 if(mode.StartsWith("referenceCone"))pitch=Math.Sqrt(1d/n)/(2*cp.Rms/longest.Micrometers);
 var spectrum=mode=="current"?DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),waves,n,ideal):waves.Select(w=>{
  var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w);var automatic=Math.Sqrt(n/32d);
  var extent=automatic*(w.Micrometers*fp*(n-2)/(2*n*automatic))/pitch;
  if(mode.StartsWith("referenceCone")||mode=="nativePitchCone")extent=(automatic*(w.Micrometers*f*(n-2)/(2*n*automatic))/pitch/f)*(.5/cp.Rms);
  if(mode=="nativePitchCommonF")extent=(w.Micrometers*(.5/cp.Rms)*(n-2))/(2*n*pitch);
  var grid=mode is "referenceCone" or "nativePitchCone"?new PupilGridSpecification(n,true,true,extent):new PupilGridSpecification(n,true,true,extent){ExplicitCoordinateStep=extent/(n/2d-1)};
  var psf=(PsfResult)compute.Invoke(null,new object?[]{optic,(0d,0d),w,n,m,false,true,0d,null,null,true,ideal,false,primary,pitch,true,null,sphere,grid})!;
  return (Wavelength:w,Result:psf with{SampleSpacingMicrometers=pitch});
 }).ToArray();
 pitch=spectrum[0].Result.SampleSpacingMicrometers;
 var componentRows=new List<object>();for(var i=0;i<8;i++){
  var value=spectrum[i].Result.Values;var maximum=0d;for(var y=0;y<m;y++)for(var x=0;x<m;x++)maximum=Math.Max(maximum,Math.Abs(value[y,x]/100-nativeGrids[i][y,x]));
  var expected=ReadCurves(Path.Combine(task,$"isolation/w{i+1}/dee/data.json"));
  componentRows.Add(new{wave=i+1,nrmse=Metric(Curve(new[]{value},new[]{1d},pitch),expected[ideal?0:1]),maxPsfError=maximum,idealCount=ideal?100d*m*m/value.Cast<double>().Sum():0});
 }
 rows.Add(new{mode,ideal,pitch,nrmse=Metric(Curve(spectrum.Select(s=>s.Result.Values).ToArray(),weights,pitch),nativeReference[ideal?0:1]),components=componentRows});
}
var result=new{coreSha256=Convert.ToHexStringLower(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(DiffractionEngine).Assembly.Location))),nativePitch,fp,exactF=.5/cp.Rms,mixtureError,nativeRows,rows,centerDiagnostics};
File.WriteAllText(Path.Combine(task,"high-sampling-diagnosis.json"),JsonSerializer.Serialize(result));
Console.WriteLine(JsonSerializer.Serialize(new{nativePitch,mixtureError,nativeRows,rows=rows.Select(r=>r)}));
static double[,] ReadGrid(string path){using var d=JsonDocument.Parse(File.ReadAllText(path));var values=d.RootElement.GetProperty("dataGrids")[0].GetProperty("values");var a=new double[m,m];for(var y=0;y<m;y++)for(var x=0;x<m;x++)a[(y+1)%m,(x+1)%m]=values[y][x].GetDouble();return a;}
static double[][] ReadCurves(string path){using var d=JsonDocument.Parse(File.ReadAllText(path));return d.RootElement.GetProperty("dataSeries").EnumerateArray().Select(s=>s.GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray()).ToArray();}
static double Metric(double[] values,double[] reference)=>Math.Sqrt(values.Zip(reference,(a,b)=>(a-b)*(a-b)).Average())/(reference.Max()-reference.Min());
static double[] Curve(double[][,] psfs,double[] weights,double pitch,string centerMode="centroid"){
 var samples=Enumerable.Range(0,m).SelectMany(y=>Enumerable.Range(0,m).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,psfs.Select((s,i)=>weights[i]*s[(y+1)%m,(x+1)%m]).Sum()))).ToArray();
 if(centerMode=="symmetricEdges")samples=samples.Select(s=>s with{Weight=s.Weight*(s.X==n*pitch?.5:1)*(s.Y==n*pitch?.5:1)}).ToArray();
 if(centerMode=="trimEdges")samples=samples.Where(s=>s.X<n*pitch&&s.Y<n*pitch).ToArray();
 var total=samples.Sum(s=>s.Weight);var center=centerMode=="zero"?(0d,0d):(samples.Sum(s=>s.X*s.Weight)/total,samples.Sum(s=>s.Y*s.Weight)/total);
 var grid=new FftCumulativeEnergyGrid(samples,center,"encircled");var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(grid.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;
 var values=MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());
 var previous=0d;return values.Select(v=>previous=Math.Clamp(Math.Max(previous,v),0,1)).ToArray();}
