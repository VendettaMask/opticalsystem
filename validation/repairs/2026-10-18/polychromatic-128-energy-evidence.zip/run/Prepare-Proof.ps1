$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadJson([string]$relative){Get-Content (Join-Path $PSScriptRoot $relative) -Raw|ConvertFrom-Json}
function Tests([string]$name){
 [xml]$xml=Get-Content (Join-Path $PSScriptRoot ('tests/'+$name)) -Raw
 $ns=[Xml.XmlNamespaceManager]::new($xml.NameTable);$ns.AddNamespace('t','http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
 $c=$xml.SelectSingleNode('//t:ResultSummary/t:Counters',$ns)
 @{total=[int]$c.total;passed=[int]$c.passed;failed=[int]$c.failed;skipped=[int]$c.notExecuted;names=@($xml.SelectNodes('//t:Results/t:UnitTestResult',$ns)|ForEach-Object testName|Sort-Object)}
}
$previous=Get-Content (Join-Path $repo 'docs/validation/POLYCHROMATIC_ENERGY_REPAIR_2026-10-18.json') -Raw|ConvertFrom-Json
$unchangedTests=@($previous.sourceFiles|Where-Object {$_.path -like 'tests/*.cs'})
foreach($s in $unchangedTests){if((Hash (Join-Path $repo $s.path)) -ne $s.sha256){throw 'Previously verified test source changed'}}
$release=Tests 'related-release-final.trx';$debug=Tests 'related-debug-final.trx'
foreach($run in @($release,$debug)){
 if($run.passed -ne $run.total -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Final main tests incomplete'}
 if(@($run.names|Where-Object {$_ -match '\.HighSamplingPolychromaticEnergyTests\.'}).Count -ne 24){throw 'Twenty-four new checks missing'}
}
if($release.total -ne 1000 -or $debug.total -ne 287){throw 'Final test scope differs'}
foreach($name in $previous.verification.testRelease.names){if($name -cnotin $release.names){throw 'Prior Release test missing'}}
foreach($name in $previous.verification.testDebug.names){if($name -cnotin $debug.names){throw 'Prior Debug test missing'}}
foreach($name in $debug.names){if($name -cnotin $release.names){throw 'Debug identity absent from Release'}}
$comparisonRelease=Tests 'comparison-release-final.trx';$comparisonDebug=Tests 'comparison-debug-final.trx'
foreach($run in @($comparisonRelease,$comparisonDebug)){if($run.total -ne 5 -or $run.passed -ne 5 -or $run.failed -ne 0 -or $run.skipped -ne 0){throw 'Comparison tests incomplete'}}
$beforeTests=Tests 'poly128-before.trx'
if($beforeTests.total -ne 24 -or $beforeTests.failed -ne 20 -or $beforeTests.passed -ne 4 -or $beforeTests.skipped -ne 0){throw 'Before counterexample differs'}
$beforeHash=Hash (Join-Path $PSScriptRoot 'Core.before.dll')
if($beforeHash -ne $previous.verification.configurations[0].coreCopies[0].sha256){throw 'Wrong before Core'}
$configurations=foreach($configuration in @('Release','Debug')){
 $log=Get-Content (Join-Path $PSScriptRoot ('build-'+$configuration.ToLowerInvariant()+'-final.log')) -Raw
 if(@($log -split "`n"|Where-Object {$_ -match ' -> '}).Count -ne 19 -or !$log.Contains('0 个警告') -or !$log.Contains('0 个错误')){throw 'Default solution build incomplete'}
 $paths=@("src/OpticalSystemDesign.Core/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","src/OpticalSystemDesign.App/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll","tools/OpticalSystemDesign.ZemaxComparison/bin/$configuration/net10.0/OpticalSystemDesign.Core.dll")
 $copies=@($paths|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
 if(@($copies.sha256|Sort-Object -Unique).Count -ne 1 -or (Hash (Join-Path $PSScriptRoot ('Core.'+$configuration.ToLowerInvariant()+'-final.dll'))) -ne $copies[0].sha256){throw 'Default Core copies differ'}
 @{configuration=$configuration;projects=19;warnings=0;errors=0;coreCopies=$copies}
}

$summaries=@{};$comparisons=@()
foreach($spec in @(@('formal-final',$previous.formalAfter,48,0),@('extra-final',$previous.independentControls,6,1),@('apochromat-final',$previous.priorApochromatControls,5,2),@('high-sampling-final',$previous.priorHighSamplingControls,8,0),@('fnum-final',$previous.priorFNumberControls,5,0),@('polychromatic-final',$previous.newControlsAfter,15,0))){
 $current=ReadJson ($spec[0]+'/summary.json');$summaries[$spec[0]]=$current
 if($current.rows.Count -ne $spec[2] -or $current.excluded.Count -ne $spec[3]){throw 'Old comparison inventory differs'}
 foreach($row in $current.rows){
  $old=@($spec[1].rows|Where-Object id -ceq $row.id)
  if($old.Count -ne 1 -or $row.sourceSha256 -ne $old[0].sourceSha256 -or $row.executedRequestSha256 -ne $old[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $old[0].nativeDataSha256){throw 'Old source/request/reference changed'}
  $a=($row.metrics|Measure-Object nrmse -Maximum).Maximum;$b=($old[0].metrics|Measure-Object nrmse -Maximum).Maximum
  if($null -eq $a -or $null -eq $b -or $a -gt $b+1e-8){throw ('Old numerical regression: '+$row.id)}
  $comparisons+=@{group=$spec[0];id=$row.id;beforeWorstNrmse=$b;afterWorstNrmse=$a}
 }
}
$after=$summaries['formal-final'];$new=ReadJson 'controls-final/summary.json';$newBefore=ReadJson 'controls-before/summary.json'
$unchangedPaths=@(ReadJson 'unchanged-path-controls.json')
if($unchangedPaths.Count -ne 86 -or @($unchangedPaths|Where-Object maximumPointDifference -ne 0).Count -ne 0){throw 'Unaffected prior curves changed'}
if($new.rows.Count -ne 12 -or $new.excluded.Count -ne 0 -or $newBefore.coreSha256 -ne $beforeHash){throw 'New controls differ'}
$summaries['controls-final']=$new
foreach($summary in $summaries.Values){
 if($summary.coreSha256 -ne $configurations[0].coreCopies[0].sha256){throw 'Final comparison Core differs'}
 if($summary.policySha256 -ne $previous.formalAfter.policySha256 -or $summary.policySha256 -ne (Hash (Join-Path $repo 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'))){throw 'Original policy changed'}
 if(@($summary.rows|Where-Object conclusion -ne 'Pass').Count -ne 0){throw 'Comparison failed'}
}
foreach($row in $new.rows){
 $old=@($newBefore.rows|Where-Object id -ceq $row.id)
 if($old.Count -ne 1 -or $row.sourceSha256 -ne $old[0].sourceSha256 -or $row.executedRequestSha256 -ne $old[0].executedRequestSha256 -or $row.nativeDataSha256 -ne $old[0].nativeDataSha256){throw 'New comparison input changed'}
 if($row.id -notin @('0472-poly128','0852-poly128') -and @($row.metrics|Where-Object nrmse -ge 1e-8).Count -ne 0){throw 'New precision target not closed'}
}
$archives=@{};foreach($p in $previous.preservedArchives.PSObject.Properties){$archives[$p.Name]=$p.Value};$archives[$previous.evidenceArchive.path]=$previous.evidenceArchive.sha256
foreach($path in $archives.Keys){if((Hash (Join-Path $repo $path)) -ne $archives[$path]){throw 'Frozen archive changed'}}
if($archives.Count -ne 17){throw 'Expected seventeen prior archives'}
$fixtures=@{};foreach($p in $previous.preservedNativeFixtures.PSObject.Properties){$fixtures[$p.Name]=$p.Value};foreach($f in $previous.newFixtures){$fixtures[$f.name]=$f.sha256}
foreach($name in $fixtures.Keys){if((Hash (Join-Path $repo ('tests/OpticalSystemDesign.Tests/Fixtures/'+$name))) -ne $fixtures[$name]){throw 'Frozen fixture changed'}}
if($fixtures.Count -ne 11){throw 'Expected eleven prior native fixtures'}
$fixturePath=Join-Path $repo 'tests/OpticalSystemDesign.Tests/Fixtures/fft-cumulative-polychromatic128-zemax-2026-r1.zip';$zip=[IO.Compression.ZipFile]::OpenRead($fixturePath)
try{
 $reader=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open());try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
 foreach($entry in $manifest.entries){$stream=$zip.GetEntry($entry.path).Open();try{$h=[Convert]::ToHexStringLower([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($h -ne $entry.sha256){throw 'New fixture payload changed'}}
 if($manifest.cases.Count -ne 12 -or $manifest.excluded.Count -ne 0){throw 'New fixture inventory differs'}
 $fixture=@{name=[IO.Path]::GetFileName($fixturePath);sha256=Hash $fixturePath;cases=12;excluded=@();payloadEntries=$manifest.entries.Count}
}finally{$zip.Dispose()}
$captures=@();$dee=0;$psf=0
foreach($list in @('native-jobs.json','isolation/native-jobs.json')){foreach($job in @(ReadJson $list)){
 $request=Get-Content $job.request -Raw|ConvertFrom-Json;$batch=Get-Content (Join-Path $job.output 'batch-result.json') -Raw|ConvertFrom-Json
 $envData=Get-Content (Join-Path $job.output 'environment.json') -Raw|ConvertFrom-Json
 if($batch.exitCode -ne 0 -or $envData.major -ne 26 -or $envData.minor -ne 1 -or $envData.opticStudioVersion -ne 260127 -or !$envData.validLicense){throw 'Native run/version/license differs'}
 $data=Get-Content (Join-Path $job.output 'data.json') -Raw|ConvertFrom-Json
 if($request.analysisType -eq 'DiffractionEncircledEnergy'){
  if($data.dataSeries.Count -ne 2){throw 'Missing DEE curves'}
  foreach($s in $data.dataSeries){if($s.x.Count -ne 401 -or $s.y.Count -ne 401){throw 'Incomplete DEE curves'};foreach($y in $s.y){if($y.Count -ne 1 -or ![double]::IsFinite($y[0]) -or $y[0] -lt 0 -or $y[0] -gt 1){throw 'Invalid DEE energy'}}};$dee++
 }else{
  if($data.dataGrids.Count -ne 1){throw 'Missing PSF grid'};$g=$data.dataGrids[0]
  if($g.nx -ne $request.imageSampling -or $g.ny -ne $request.imageSampling -or $g.values.Count -ne $g.ny -or $g.dx -le 0 -or $g.dy -le 0){throw 'Invalid PSF dimensions'}
  foreach($row in $g.values){if($row.Count -ne $g.nx){throw 'Incomplete PSF row'};foreach($value in $row){if(![double]::IsFinite($value) -or $value -lt 0){throw 'Invalid PSF intensity'}}};$psf++
 }
 $files=@(Get-ChildItem -LiteralPath $job.output -File|ForEach-Object {@{name=$_.Name;bytes=$_.Length;sha256=Hash $_.FullName}})
 $captures+=@{id=$job.id;state='Usable';group=$list;requestSha256=Hash $job.request;sourceSha256=Hash $request.input;files=$files}
}}
if($captures.Count -ne 22 -or $dee -ne 12 -or $psf -ne 10){throw 'Native inventory differs'}
$repeat='artifacts/validation/dee-polychromatic-20261018/native/apo-poly128/data.json'
$a=ReadJson 'native/0014-poly128/data.json';$b=Get-Content (Join-Path $repo $repeat) -Raw|ConvertFrom-Json
for($c=0;$c -lt 2;$c++){for($i=0;$i -lt 401;$i++){if($a.dataSeries[$c].x[$i] -ne $b.dataSeries[$c].x[$i] -or $a.dataSeries[$c].y[$i][0] -ne $b.dataSeries[$c].y[$i][0]){throw 'Native repeat differs'}}}
$nativeProof=ReadJson 'high-sampling-diagnosis.json'
if($nativeProof.coreSha256 -ne $beforeHash -or $nativeProof.nativeRows[0].nrmse -gt 1e-12 -or $nativeProof.mixtureError -gt 1e-14){throw 'Native decomposition proof differs'}
$sources=@(Get-Content (Join-Path $PSScriptRoot 'changed-csharp-files.txt')|ForEach-Object {@{path=$_;sha256=Hash (Join-Path $repo $_)}})
if($sources.Count -ne 40){throw 'C# source inventory differs'}
git -C $repo diff --check > (Join-Path $PSScriptRoot 'git-diff-check.log');if($LASTEXITCODE -ne 0){throw 'Diff check failed'}
$proof=@{
 date='2026-10-18';recordedUtc=[DateTime]::UtcNow.ToString('o');baseCommit=(git -C $repo rev-parse HEAD)
 scope='Apochromat original n128 polychromatic residual closed, eight spectral isolations and independent n128 lens controls; original tolerances and regressions retained'
 beforeCoreSha256=$beforeHash;beforeTests=$beforeTests
 constraints=@{originalTolerancePolicyUnchanged=$true;all87PriorFormalPassesPreserved=$true;noPriorNrmseIncreaseAbove1eMinus8=$true;prior976ReleaseIdentitiesPreserved=$true;prior263FocusedDebugIdentitiesPreserved=$true;unchangedPriorTestSources=$unchangedTests;independentCookeTessarExcluded=$true}
 verification=@{testRelease=$release;testDebug=$debug;comparisonRelease=$comparisonRelease;comparisonDebug=$comparisonDebug;configurations=$configurations;newMainTests=24;newPrecisionChecks=20;newIndependentToleranceChecks=4;debugScope='Prior focused 263 plus twenty-four new checks';format=@{includedCSharpFiles=40;exitCode=0;log='format-verify.log'};gitDiffCheckExitCode=0}
 formalBefore=$previous.formalAfter;formalAfter=$after;independentControls=$summaries['extra-final'];priorApochromatControls=$summaries['apochromat-final'];priorHighSamplingControls=$summaries['high-sampling-final'];priorFNumberControls=$summaries['fnum-final'];priorPolychromaticControls=$summaries['polychromatic-final'];newControlsBefore=$newBefore;newControlsAfter=$new;oldNumericalControls=$comparisons;unchangedPathControls=$unchangedPaths
 supportProof=@{nativeSpectralDecomposition=$nativeProof;nativeRepeat=@{id='0014-poly128';maximumPointDifference=0;reference=$repeat};crossLensDiagnosisSha256=Hash (Join-Path $PSScriptRoot 'cross-lens-diagnosis.json');note='The initial diagnostic omitted the existing monotone output envelope; corrected diagnostics leave the product integrator unchanged'}
 numericalLimitations=@{allResidualsZero=$false;originalApochromat128PolychromaticControlClosed=$true;originalMatrixWorstNrmse=($after.rows.metrics|Measure-Object nrmse -Maximum).Maximum;samplingScope='Captured n128 Apochromat/Double Gauss spectra and Apochromat isolations close below 1e-8; new Relay/123456 n128 controls retain nonzero original-tolerance Pass residuals; higher polychromatic sampling not certified'}
 preservedArchives=$archives;preservedNativeFixtures=$fixtures;newFixtures=@($fixture);sourceFiles=$sources
 nativeCaptureSummary=@{attempts=22;usableCaptures=22;deeCaptures=12;psfCaptures=10;requestErrors=0;nativeUnavailable=0;note='Includes repeats, eight single-weight isolations, auxiliary Huygens and FFT; not twenty-two independent lenses'};nativeCaptures=$captures
 retainedFailureRecords=@('tests/poly128-before.trx','tests-before.log');retainedDiagnosticCorrections=@('initial-diagnosis.json','diagnostic-without-monotonic-output.json')
 boundaries=@{fullRepositorySuiteRun=$false;fullDebugSuiteRun=$false;installerRebuilt=$false;committed=$false;pushed=$false;generalNativePolychromaticConventionCertified=$false}
}
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $PSScriptRoot 'proof.json') -Encoding utf8NoBOM
$proof|ConvertTo-Json -Depth 60|Set-Content (Join-Path $repo 'docs/validation/POLYCHROMATIC_128_ENERGY_REPAIR_2026-10-18.json') -Encoding utf8NoBOM
'Verified Apochromat n128 polychromatic closure, 87 prior plus 12 current formal passes, 1000/287 tests and preserved original evidence.'



