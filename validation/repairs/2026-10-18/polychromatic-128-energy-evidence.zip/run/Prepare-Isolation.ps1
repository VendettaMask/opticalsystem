$ErrorActionPreference='Stop'
$dir=Join-Path $PSScriptRoot 'isolation';New-Item -ItemType Directory -Path $dir|Out-Null
$template=Get-Content (Join-Path $PSScriptRoot 'requests/0014-poly128/dee.json') -Raw|ConvertFrom-Json
$text=[IO.File]::ReadAllText($template.input)
$delta=(Get-Content (Join-Path $PSScriptRoot 'native/0014-poly128-huygens/data.json') -Raw|ConvertFrom-Json).dataGrids[0].dx
$jobs=@();$dee=@()
foreach($w in @(1..8)){
 $case=Join-Path $dir ('w'+$w);New-Item -ItemType Directory -Path $case|Out-Null
 $source=Join-Path $case 'source.zmx';$updated=$text
 foreach($k in @(1..8)){
  $pattern='(?m)^(WAVM '+$k+' [^\s]+) [^\s\r\n]+[ \t]*\r?$'
  if([regex]::Matches($updated,$pattern).Count -ne 1){throw 'Expected one active wavelength weight'}
  $weight=if($k -eq $w){'1'}else{'0'}
  $updated=[regex]::Replace($updated,$pattern,'${1} '+$weight)
 }
 [IO.File]::WriteAllText($source,$updated,[Text.UTF8Encoding]::new($false))
 $r=Get-Content (Join-Path $PSScriptRoot 'requests/0014-poly128/dee.json') -Raw|ConvertFrom-Json;$r.input=$source
 $path=Join-Path $case 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $job=@{id='isolate-w'+$w;request=$path;output=(Join-Path $case 'dee')};$jobs+=$job;$dee+=$job
 $r.canonicalAnalysisKey='PSF';$r.analysisType='FftPsf';$r.imageDeltaMicrometers=$delta
 $r.zemaxSettings=[ordered]@{Normalize=$false;OutputSize='PsfS_256x256';SampleSize='PsfS_128x128';ImageDelta=$delta;Wavelength=0;Surface=-1;Rotation='CW0';Type='Linear';Field=1;UsePolarization=$false}
 $path=Join-Path $case 'fft.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id='fft-isolate-w'+$w;request=$path;output=(Join-Path $case 'fft')}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $dir 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($dee) -Depth 10|Set-Content (Join-Path $dir 'dee-jobs.json') -Encoding utf8NoBOM

