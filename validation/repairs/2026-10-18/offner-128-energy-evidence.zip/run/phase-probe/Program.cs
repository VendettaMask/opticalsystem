using System.Numerics;
using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-offner128-20261018");const int n=128,m=256;
var cm=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;var rows=new List<object>();
foreach(var id in new[]{"offner128","decenter-minus1p5-128","decenter-plus3-128"}){
 using var request=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"requests/{id}/dee.json")));var optic=OpticalFormatCatalog.Import(File.ReadAllText(request.RootElement.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=false;var w=optic.Wavelengths[0];
 var cone=((double Rms,double T,double S))cm.Invoke(null,new object[]{optic,(0d,0d),w})!;var pitch=Math.Sqrt(1d/n)/(2*cone.Rms/w.Micrometers);var automatic=Math.Sqrt(n/32d);var f=DiffractionEngine.WorkingFNumber(optic,(0,0),w,false);var dp=w.Micrometers*f*(n-2)/(2*n*automatic);var perF=automatic*dp/pitch/f;var sx=perF*(.5/cone.S);var sy=perF*(.5/cone.T);var grid=new PupilGridSpecification(n,true,true,sx){StretchY=sy};var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),w,false);
 object?[] parameters={optic,(0d,0d),w,n,m,false,true,0d,null,null,true,false,false,w,pitch,true,null,sphere,grid};var psf=(PsfResult)compute.Invoke(null,parameters)!;var core=(Complex[,])parameters[16]!;
 var wf=WavefrontEngine.GenerateChiefRayGrid(optic,(0,0),w,grid,false,w,sphere);var direct=wf.Samples.ToDictionary(s=>(grid.ColumnIndex(s.NormalizedPupilX),grid.RowIndex(s.NormalizedPupilY)),s=>s);
 var real=ReadGrid(Path.Combine(task,$"psf/{id}-Real/data.json"));var imaginary=ReadGrid(Path.Combine(task,$"psf/{id}-Imaginary/data.json"));var linear=ReadGrid(Path.Combine(task,$"psf/{id}-Linear/data.json"));var native=new Complex[m,m];var intensityError=0d;
 for(var y=0;y<m;y++)for(var x=0;x<m;x++){native[y,x]=new Complex(real[y,x],imaginary[y,x]);intensityError=Math.Max(intensityError,Math.Abs(native[y,x].Magnitude*native[y,x].Magnitude-linear[y,x]));}
 DiffractionEngine.FourierTransform2D(native,true);var maximum=native.Cast<Complex>().Max(v=>v.Magnitude);var nodes=new List<Node>();var supportMismatch=0;var leak=0d;
 for(var y=0;y<n;y++)for(var x=0;x<n;x++){
  var ix=x-n/2;var iy=y-n/2;var value=native[(-iy+m)%m,(-ix+m)%m]*(((ix+iy)%2==0)?1:-1);var actual=core[y,x];var illuminated=value.Magnitude>maximum*.5;
  if(illuminated!=(actual.Magnitude>.5)){supportMismatch++;continue;}if(!illuminated){leak=Math.Max(leak,value.Magnitude/maximum);continue;}
  var raw=direct[(x,y)];var nativePhase=-value.Phase;var error=Math.Atan2(Math.Sin(actual.Phase-nativePhase),Math.Cos(actual.Phase-nativePhase));var rawError=Math.Atan2(Math.Sin(-2*Math.PI*raw.OpdWaves-nativePhase),Math.Cos(-2*Math.PI*raw.OpdWaves-nativePhase));
  var ray=optic.SequentialRayTracer.TraceToSurface(optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,raw.NormalizedPupilX,raw.NormalizedPupilY,w.Micrometers,false).Rays[0],optic.SurfaceGroup.Items.Count-1)!;
  var relative=ray.Position-new OpticalSystemDesign.Core.Backend.Vector3D(sphere.CenterX,sphere.CenterY,sphere.CenterZ);var cross=optic.Backend.Current.Cross(ray.Direction,relative);var perpendicular=cross.Length*cross.Length/(ray.Direction.Length*ray.Direction.Length);
  var oldSag=perpendicular/(sphere.Radius+Math.Sqrt(sphere.Radius*sphere.Radius-perpendicular));var targetSag=oldSag-w.Micrometers*.001*(-nativePhase/(2*Math.PI)-raw.OpdWaves);var inferredRadius=(perpendicular+targetSag*targetSag)/(2*targetSag);
  nodes.Add(new Node(ix,iy,grid.Coordinate(x),grid.YCoordinate(y),nativePhase,actual.Phase,error,rawError,raw.OpdWaves,inferredRadius));
 }
 var summary=new{id,pitch,radius=sphere.Radius,intensityError,supportMismatch,count=nodes.Count,leak,maxPhaseError=nodes.Max(v=>Math.Abs(v.Error)),oddMax=nodes.Where(v=>(v.X+v.Y)%2!=0).Max(v=>Math.Abs(v.Error)),evenMax=nodes.Where(v=>(v.X+v.Y)%2==0).Max(v=>Math.Abs(v.Error)),maxRawError=nodes.Max(v=>Math.Abs(v.RawError)),nodes};rows.Add(summary);
 if(id!="decenter-plus3-128"){
  var folder=Path.Combine(task,"rays");Directory.CreateDirectory(folder);
  var inputs=wf.Samples.Select((s,i)=>new{hx=0d,hy=0d,px=s.NormalizedPupilX,py=s.NormalizedPupilY,fieldIndex=0,pupilIndex=i}).ToList();
  foreach(var p in new[]{(0d,0d),(0d,1d),(0d,-1d),(1d,0d),(-1d,0d)})inputs.Add(new{hx=0d,hy=0d,px=p.Item1,py=p.Item2,fieldIndex=1,pupilIndex=inputs.Count});
  var q=System.Text.Json.Nodes.JsonNode.Parse(request.RootElement.GetRawText())!;q["adapter"]="ray-audit";q["surfaceRecordLimit"]=10000;q["removeVignettingFactors"]=false;q["rayAuditInputs"]=JsonSerializer.SerializeToNode(inputs);
  File.WriteAllText(Path.Combine(folder,id+".json"),q.ToJsonString());
 }
 Console.WriteLine(JsonSerializer.Serialize(new{id,summary.intensityError,summary.supportMismatch,summary.count,summary.leak,summary.maxPhaseError,summary.oddMax,summary.evenMax,summary.maxRawError,axes=nodes.Where(v=>v.X==0||v.Y==0).ToArray()}));
}
File.WriteAllText(Path.Combine(task,"phase-diagnosis.json"),JsonSerializer.Serialize(rows));
static double[,] ReadGrid(string path){using var d=JsonDocument.Parse(File.ReadAllText(path));var v=d.RootElement.GetProperty("dataGrids")[0].GetProperty("values");var a=new double[m,m];for(var y=0;y<m;y++)for(var x=0;x<m;x++)a[(y+1)%m,(x+1)%m]=v[y][x].GetDouble();return a;}
record Node(int X,int Y,double Px,double Py,double NativePhase,double CorePhase,double Error,double RawError,double RawOpd,double InferredRadius);
