$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'psf';New-Item -ItemType Directory -Path $out|Out-Null
$jobs=@()
foreach($id in @('offner32','offner128','offner256','decenter-minus1p5-128','decenter-plus3-128')){
 $r=Get-Content (Join-Path $PSScriptRoot ('requests/'+$id+'/dee.json')) -Raw|ConvertFrom-Json
 $n=$r.pupilSampling;$delta=(Get-Content (Join-Path $PSScriptRoot ('native/'+$id+'-huygens/data.json')) -Raw|ConvertFrom-Json).dataGrids[0].dx
 $r.canonicalAnalysisKey='PSF';$r.analysisType='FftPsf';$r.imageDeltaMicrometers=$delta
 $types=if($n -eq 128){@('Linear','Real','Imaginary')}else{@('Linear')}
 foreach($type in $types){
  $r.zemaxSettings=[ordered]@{Normalize=$false;OutputSize=('PsfS_'+(2*$n)+'x'+(2*$n));SampleSize=('PsfS_'+$n+'x'+$n);ImageDelta=$delta;Wavelength=1;Surface=-1;Rotation='CW0';Type=$type;Field=1;UsePolarization=$false}
  $path=Join-Path $out ($id+'-'+$type+'.json');$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
  $jobs+=@{id=$id+'-'+$type;request=$path;output=(Join-Path $out ($id+'-'+$type))}
 }
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $out 'native-jobs.json') -Encoding utf8NoBOM
