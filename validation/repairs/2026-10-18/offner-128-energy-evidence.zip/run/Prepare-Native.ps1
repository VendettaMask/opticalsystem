$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$template=Join-Path $repo 'artifacts/validation/numerical-residuals-20261018/holdout/0592-n128/request.json'
$specs=@(@('offner32',32,$template),@('offner64',64,$template),@('offner128',128,$template),@('offner256',256,$template),@('decenter-minus1p5-128',128,(Join-Path $repo 'artifacts/validation/dee-boundary-20261018/offner-holdouts/decenter-minus1p5.json')),@('decenter-plus3-128',128,(Join-Path $repo 'artifacts/validation/dee-boundary-20261018/offner-holdouts/decenter-plus3.json')))
$jobs=@();$dee=@()
foreach($spec in $specs){
 $id=$spec[0];$n=$spec[1];$r=Get-Content $spec[2] -Raw|ConvertFrom-Json
 $r.pupilSampling=$n;$r.imageSampling=2*$n;$r.workbenchSettings.PupilSampling=[string]$n;$r.workbenchSettings.ImageSampling=[string](2*$n);$r.zemaxSettings.SampleSize='S_'+$n+'x'+$n
 $dir=Join-Path $PSScriptRoot ('requests/'+$id);New-Item -ItemType Directory -Path $dir|Out-Null
 $path=Join-Path $dir 'dee.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $job=@{id=$id;request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id))};$jobs+=$job;$dee+=$job
 $r.canonicalAnalysisKey='Huygens PSF';$r.analysisType='HuygensPsf';$r.imageSampling=32;$r.imageDeltaMicrometers=0
 $r.zemaxSettings=[ordered]@{Normalize=$false;PupilSampleSize=('S_'+$n+'x'+$n);ImageSampleSize='S_32x32';ImageDelta=0;Wavelength=1;UseCentroid=$false;Configuration=1;Rotation='Rotate_0';Type='Linear';Field=1;UsePolarization=$false}
 $path=Join-Path $dir 'huygens.json';$r|ConvertTo-Json -Depth 30|Set-Content $path -Encoding utf8NoBOM
 $jobs+=@{id=$id+'-huygens';request=$path;output=(Join-Path $PSScriptRoot ('native/'+$id+'-huygens'))}
}
ConvertTo-Json -InputObject @($jobs) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'native-jobs.json') -Encoding utf8NoBOM
ConvertTo-Json -InputObject @($dee) -Depth 10|Set-Content (Join-Path $PSScriptRoot 'dee-jobs.json') -Encoding utf8NoBOM
