using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Rays;
var task=Path.Combine(args[0],"artifacts/validation/dee-offner128-20261018");var output=new List<object>();
foreach(var id in new[]{"offner128","decenter-minus1p5-128"}){
 using var request=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"requests/{id}/dee.json")));var optic=OpticalFormatCatalog.Import(File.ReadAllText(request.RootElement.GetProperty("input").GetString()!),".zmx");optic.RayAimingEnabled=false;var w=optic.Wavelengths[0];
 using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"rays/{id}/ray-audit.json")));var native=audit.RootElement.GetProperty("surfaces").EnumerateArray().Last().GetProperty("rays");var inputs=audit.RootElement.GetProperty("inputs");var launches=audit.RootElement.GetProperty("launches");var origin=optic.SurfaceGroup.Items[0].CoordinateSystem;var image=optic.SurfaceGroup.Items[^1].CoordinateSystem;var rows=new List<object>();
 for(var i=0;i<inputs.GetArrayLength();i++){
  var p=inputs[i];var px=p.GetProperty("px").GetDouble();var py=p.GetProperty("py").GetDouble();var launch=launches[i];var own=optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,px,py,w.Micrometers,false).Rays[0];var ownFinal=optic.SequentialRayTracer.TraceToSurface(own,optic.SurfaceGroup.Items.Count-1);if(ownFinal==null)continue;
  var nativeP=Vector(launch,"x","y","z");var nativeD=Vector(launch,"l","m","n");var replay=new RealRay(origin.ToGlobalPoint(nativeP),origin.ToGlobalDirection(nativeD),w.Nanometers);var end=optic.SequentialRayTracer.TraceToSurface(replay,optic.SurfaceGroup.Items.Count-1)!;
  var op=image.ToLocalPoint(ownFinal.Position);var od=image.ToLocalDirection(ownFinal.Direction);var rp=image.ToLocalPoint(end.Position);var rd=image.ToLocalDirection(end.Direction);var np=Vector(native[i],"x","y","z");var nd=Vector(native[i],"l","m","n");var sign=optic.SurfaceGroup.Items.Count(surface=>surface.IsReflective)%2==0?1:-1;var physicalNativeDirection=nd*sign;
  rows.Add(new{i,px,py,launchPositionError=(origin.ToLocalPoint(own.Origin)-nativeP).Length,launchDirectionError=(origin.ToLocalDirection(own.Direction)-nativeD).Length,ownLocal=op,ownDir=od,replayLocal=rp,replayDir=rd,nativeLocal=np,nativeDir=nd,ownPointError=(op-np).Length,replayPointError=(rp-np).Length,ownDirectionError=(od-physicalNativeDirection).Length,replayDirectionError=(rd-physicalNativeDirection).Length,ownPath=ownFinal.CumulativeOpticalPathLength,replayPath=end.CumulativeOpticalPathLength});
 }
 var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),w,false);output.Add(new{id,frame=image,paraxialExit=optic.Paraxial.EstimateExitPupilLocation(),sphere,rows});
}
File.WriteAllText(Path.Combine(task,"ray-replay.json"),JsonSerializer.Serialize(output));
static Vector3D Vector(JsonElement e,string a,string b,string c)=>new(e.GetProperty(a).GetDouble(),e.GetProperty(b).GetDouble(),e.GetProperty(c).GetDouble());
