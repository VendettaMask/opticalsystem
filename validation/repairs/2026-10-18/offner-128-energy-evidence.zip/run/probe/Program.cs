using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;
var repo=Path.GetFullPath(args[0]);var task=Path.Combine(repo,"artifacts/validation/dee-offner128-20261018");
var cm=typeof(DiffractionEngine).GetMethod("CumulativeEnergyCone",BindingFlags.Static|BindingFlags.NonPublic)!;
var compute=typeof(DiffractionEngine).GetMethod("ComputeFftPsfCore",BindingFlags.Static|BindingFlags.NonPublic)!;
using var jobs=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,"dee-jobs.json")));var rows=new List<object>();
foreach(var job in jobs.RootElement.EnumerateArray()){
 var id=job.GetProperty("id").GetString()!;using var request=JsonDocument.Parse(File.ReadAllText(job.GetProperty("request").GetString()!));var r=request.RootElement;
 var optic=OpticalFormatCatalog.Import(File.ReadAllText(r.GetProperty("input").GetString()!),".zmx");using var model=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"model.json")));optic.RayAimingEnabled=model.RootElement.GetProperty("rayAiming").GetProperty("RayAiming").GetString()!="Off";
 var w=optic.Wavelengths[0];var cp=((double Rms,double T,double S))cm.Invoke(null,new object[]{optic,(0d,0d),w})!;
 var n=r.GetProperty("pupilSampling").GetInt32();var correctPitch=n>32?Math.Sqrt(1d/n)/(2*cp.Rms/w.Micrometers):(w.Micrometers*.001/Math.Sqrt(n))*DiffractionEngine.WorkingFNumber(optic,(0,0),w,optic.RayAimingEnabled)*1000;
 using var native=JsonDocument.Parse(File.ReadAllText(Path.Combine(job.GetProperty("output").GetString()!,"data.json")));using var hu=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"native/{id}-huygens/data.json")));var nativePitch=hu.RootElement.GetProperty("dataGrids")[0].GetProperty("dx").GetDouble();
 foreach(var ideal in new[]{true,false}){
  var psf=DiffractionEngine.ComputeFftCumulativeEnergySpectrum(optic,(0,0),new[]{w},n,ideal)[0].Result;var reference=native.RootElement.GetProperty("dataSeries")[ideal?0:1].GetProperty("y").EnumerateArray().Select(v=>v[0].GetDouble()).ToArray();
  var current=Curve(psf.Values,psf.SampleSpacingMicrometers,n);var corrected=Curve(psf.Values,correctPitch,n);
  var row=new{id,n,ideal,currentPitch=psf.SampleSpacingMicrometers,correctPitch,nativePitch,rmsNA=cp.Rms,tNA=cp.T,sNA=cp.S,ratio=psf.SampleSpacingMicrometers/correctPitch,before=Metric(current,reference),after=Metric(corrected,reference),idealCount=ideal?100d*4*n*n/psf.Values.Cast<double>().Sum():0};rows.Add(row);Console.WriteLine(JsonSerializer.Serialize(row));
  if(!ideal){
   var psfPath=Path.Combine(task,$"psf/{id}-Linear/data.json");
   if(File.Exists(psfPath)){using var d=JsonDocument.Parse(File.ReadAllText(psfPath));var v=d.RootElement.GetProperty("dataGrids")[0].GetProperty("values");var a=new double[2*n,2*n];for(var y=0;y<2*n;y++)for(var x=0;x<2*n;x++)a[(y+1)%(2*n),(x+1)%(2*n)]=v[y][x].GetDouble();var nativeRow=new{id,mode="native-fft",nrmse=Metric(Curve(a,nativePitch,n),reference)};rows.Add(nativeRow);Console.WriteLine(JsonSerializer.Serialize(nativeRow));}
   var sphere=WavefrontEngine.CreateChiefRayReferenceSphere(optic,(0,0),w,optic.RayAimingEnabled);var axes=DiffractionEngine.WorkingFNumbers(optic,(0,0),w,optic.RayAimingEnabled,false,true);
   foreach(var mode in new[]{"directMean","axisRms","systemRms","sagittalBoth","tangentialBoth","swapMean"}){
    var fx=mode=="axisRms"?axes.Sagittal:mode=="systemRms"?.5/cp.Rms:mode is "tangentialBoth" or "swapMean"?.5/cp.T:.5/cp.S;
    var fy=mode=="axisRms"?axes.Tangential:mode=="systemRms"?.5/cp.Rms:mode is "sagittalBoth" or "swapMean"?.5/cp.S:.5/cp.T;
    var stepx=1/(n*correctPitch/w.Micrometers/fx);var stepy=1/(n*correctPitch/w.Micrometers/fy);
    var grid=new PupilGridSpecification(n,true,true,stepx*(n/2d-1)){ExplicitCoordinateStep=stepx,ExplicitCoordinateStepY=stepy};
    var candidate=(PsfResult)compute.Invoke(null,new object?[]{optic,(0d,0d),w,n,2*n,false,true,0d,null,null,true,false,optic.RayAimingEnabled,w,correctPitch,true,null,sphere,grid})!;
    var candidateRow=new{id,mode,nrmse=Metric(Curve(candidate.Values,correctPitch,n),reference)};rows.Add(candidateRow);Console.WriteLine(JsonSerializer.Serialize(candidateRow));
   }
   if(n==128){
    var originalGrid=new PupilGridSpecification(n,true,true,psf.PupilGridStretch){StretchY=(w.Micrometers*(.5/cp.T)*(n-2))/(2*n*correctPitch)};
    var rayId=id=="decenter-plus3-128"?"offner128":id;using var audit=JsonDocument.Parse(File.ReadAllText(Path.Combine(task,$"rays/{rayId}/ray-audit.json")));var exit=audit.RootElement.GetProperty("exitPupilPosition").GetDouble();
    var geo=ExitPupilGeometryEngine.Compute(optic,(0,0),w,new[]{(0d,0d),(.1,0d)});var imageFrame=optic.SurfaceGroup.Items[^1].CoordinateSystem;var chief=optic.SequentialRayTracer.TraceToSurface(optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,0,0,w.Micrometers,false).Rays[0],optic.SurfaceGroup.Items.Count-1)!;
    var tangentialCandidate=double.NaN;foreach(var h in new[]{1e-2,1e-3,1e-4}){var plus=optic.SequentialRayTracer.TraceToSurface(optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,h,0,0,w.Micrometers,false).Rays[0],optic.SurfaceGroup.Items.Count-1)!;var minus=optic.SequentialRayTracer.TraceToSurface(optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,-h,0,0,w.Micrometers,false).Rays[0],optic.SurfaceGroup.Items.Count-1)!;var pc=imageFrame.ToLocalPoint(plus.Position);var mc=imageFrame.ToLocalPoint(minus.Position);var pd=imageFrame.ToLocalDirection(plus.Direction);var md=imageFrame.ToLocalDirection(minus.Direction);var dz=-(pc.Y-mc.Y)/(pd.Y/pd.Z-md.Y/md.Z);var rr=new{id,mode="fieldParabasal",h,exit=dz*Math.Sign(chief.Direction.Z),radius=dz/(-chief.Direction.Z)};rows.Add(rr);Console.WriteLine(JsonSerializer.Serialize(rr)); tangentialCandidate=rr.radius;}var stopIndex=optic.SurfaceGroup.Items.ToList().FindIndex(surface=>surface.IsStop);using var stopTrace=optic.SequentialRayTracer.Trace(optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,0,0,w.Micrometers,true),OpticalSystemDesign.Core.Raytrace.TraceRequest.Selected(new[]{stopIndex,optic.SurfaceGroup.Items.Count-1}));stopTrace.TryGetSample(0,stopIndex,out var hit);var stopHit=hit.ToRayTraceSample();
    var unit=stopHit.Direction/stopHit.Direction.Length;var a=optic.Backend.Current.Cross(unit,new OpticalSystemDesign.Core.Backend.Vector3D(0,1,0));a/=a.Length;var b=optic.Backend.Current.Cross(unit,a);var tangential=double.NaN;
    foreach(var axis in new[]{a,b}){
     var lines=new List<(OpticalSystemDesign.Core.Backend.Vector3D P,OpticalSystemDesign.Core.Backend.Vector3D D)>();
     foreach(var epsilon in new[]{0d,1e-4,-1e-4}){var dir=unit+axis*epsilon;dir/=dir.Length;var ray=new OpticalSystemDesign.Core.Rays.RealRay(stopHit.Position,dir,w.Nanometers);var end=optic.SequentialRayTracer.TracePupilGeometryProbe(ray,stopIndex+1,optic.SurfaceGroup.Items[stopIndex].MaterialBefore)!;lines.Add((end.Position,end.Direction));}
     var plus=lines[1];var minus=lines[2];var pc=imageFrame.ToLocalPoint(plus.P);var mc=imageFrame.ToLocalPoint(minus.P);var pd=imageFrame.ToLocalDirection(plus.D);var md=imageFrame.ToLocalDirection(minus.D);var deltaSlope=axis==a?pd.X/pd.Z-md.X/md.Z:pd.Y/pd.Z-md.Y/md.Z;var dz=-(axis==a?pc.X-mc.X:pc.Y-mc.Y)/deltaSlope;var point=plus.P+plus.D*(dz/pd.Z);var fit=(Point:point,Residual:0d);var local=imageFrame.ToLocalPoint(fit.Point);var sign=chief.Direction.Z;var axial=(local.Z*sign);var rr=new{id,mode=axis==a?"parabasalSagittal":"parabasalTangential",point=fit.Point,local=local.Z,axial,radius=axial/Math.Abs(chief.Direction.Z),fit.Residual};rows.Add(rr);Console.WriteLine(JsonSerializer.Serialize(rr));if(axis==b)tangential=axial/Math.Abs(chief.Direction.Z);
    }
    foreach(var candidate in new[]{("nativeR",Math.Abs(exit)),("nativeAxial",Math.Sqrt(exit*exit+Math.Pow(imageFrame.ToLocalPoint(chief.Position).Y,2))),("geometric",(chief.Position-geo.Center).Length)}){
     var s=sphere with{Radius=candidate.Item2};var p=(PsfResult)compute.Invoke(null,new object?[]{optic,(0d,0d),w,n,2*n,false,true,0d,null,null,true,false,optic.RayAimingEnabled,w,correctPitch,true,null,s,originalGrid})!;
     var rr=new{id,mode=candidate.Item1,radius=candidate.Item2,geometricCenter=geo.Center,nrmse=Metric(Curve(p.Values,correctPitch,n),reference)};rows.Add(rr);Console.WriteLine(JsonSerializer.Serialize(rr));
    }
    var wavefront=WavefrontEngine.GenerateChiefRayGrid(optic,(0,0),w,originalGrid,false,w,sphere);
    var center=new OpticalSystemDesign.Core.Backend.Vector3D(sphere.CenterX,sphere.CenterY,sphere.CenterZ);
    foreach(var radius in new[]{-Math.Abs(exit)/Math.Abs(chief.Direction.Z),tangentialCandidate}){
    var flipped=wavefront with{Samples=wavefront.Samples.Select(sample=>{
     var ray=optic.SequentialRayTracer.TraceToSurface(optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0,0,sample.NormalizedPupilX,sample.NormalizedPupilY,w.Micrometers,false).Rays[0],optic.SurfaceGroup.Items.Count-1);if(ray==null)return sample;
     var cross=optic.Backend.Current.Cross(ray.Direction,ray.Position-center);var perpendicular=cross.Length*cross.Length/(ray.Direction.Length*ray.Direction.Length);var correction=perpendicular/(sphere.Radius+Math.Sqrt(sphere.Radius*sphere.Radius-perpendicular))-Math.Sign(radius)*perpendicular/(Math.Abs(radius)+Math.Sqrt(radius*radius-perpendicular));
     return sample with{OpdWaves=sample.OpdWaves+correction/(w.Micrometers*.001)};
    }).ToArray()};
    var flipPsf=(PsfResult)compute.Invoke(null,new object?[]{optic,(0d,0d),w,n,2*n,false,true,0d,flipped,null,true,false,false,w,0d,true,null,sphere,originalGrid})!;
    var flipRow=new{id,mode="oppositeSphereSide",radius,nrmse=Metric(Curve(flipPsf.Values,correctPitch,n),reference)};rows.Add(flipRow);Console.WriteLine(JsonSerializer.Serialize(flipRow));
    }
   }
  }
 }
}
File.WriteAllText(Path.Combine(task,"pitch-diagnosis.json"),JsonSerializer.Serialize(new{coreSha256=Convert.ToHexStringLower(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(DiffractionEngine).Assembly.Location))),rows}));
static double Metric(double[] actual,double[] reference)=>Math.Sqrt(actual.Zip(reference,(a,b)=>(a-b)*(a-b)).Average())/(reference.Max()-reference.Min());
static double[] Curve(double[,] psf,double pitch,int n){
 var m=2*n;var samples=Enumerable.Range(0,m).SelectMany(y=>Enumerable.Range(0,m).Select(x=>new EnergySample((x-n+1)*pitch,(y-n+1)*pitch,psf[(y+1)%m,(x+1)%m]))).ToArray();var total=samples.Sum(s=>s.Weight);var center=(samples.Sum(s=>s.X*s.Weight)/total,samples.Sum(s=>s.Y*s.Weight)/total);var grid=new FftCumulativeEnergyGrid(samples,center,"encircled");var axis=Enumerable.Range(0,n).Select(i=>5d*i/(n-1)).ToArray();var energy=axis.Select(grid.Fraction).ToArray();energy[0]=0;energy[1]=energy[2]/4;var values=MtfThroughFocusAnalysis.CubicSplineInterpolate(axis,energy,Enumerable.Range(0,401).Select(i=>5d*i/400).ToArray());var previous=0d;return values.Select(v=>previous=Math.Clamp(Math.Max(previous,v),0,1)).ToArray();
}
