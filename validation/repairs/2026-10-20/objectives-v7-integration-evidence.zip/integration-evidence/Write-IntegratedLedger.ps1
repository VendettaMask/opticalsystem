param([switch]$IncludeArchive)
$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$repository=(Resolve-Path -LiteralPath (Join-Path $taskRoot '../../..')).Path
Set-Location -LiteralPath $repository
function Identity([string]$Path) {
    $file=Get-Item -LiteralPath $Path
    [ordered]@{path=[IO.Path]::GetRelativePath($repository,$file.FullName).Replace('\','/');bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
}
function Test-Scope([string]$Name,[string]$Path,[int]$Expected,[string]$Scope) {
    [xml]$xml=Get-Content -LiteralPath $Path -Raw
    $counters=$xml.SelectSingleNode('//*[local-name()="Counters"]')
    $summary=$xml.SelectSingleNode('//*[local-name()="ResultSummary"]')
    $times=$xml.SelectSingleNode('//*[local-name()="Times"]')
    if ([int]$counters.passed -ne $Expected -or [int]$counters.total -ne $Expected -or [int]$counters.failed -ne 0 -or [int]$counters.notExecuted -ne 0 -or $summary.outcome -ne 'Completed') {throw "Incomplete/failed accepted scope: $Name"}
    [ordered]@{name=$Name;scope=$Scope;passed=$Expected;failed=0;skipped=0;outcome='Completed';started=[string]$times.start;finished=[string]$times.finish;evidence=(Identity $Path)}
}
$run=Join-Path $taskRoot 'final-v7-intersection-fallback'
$report=Join-Path $taskRoot 'report-final-v7'
$summary=Get-Content -LiteralPath (Join-Path $report 'summary.json') -Raw | ConvertFrom-Json
$originalGuard=Get-Content -LiteralPath (Join-Path $report 'previous-pass-preservation.json') -Raw | ConvertFrom-Json
$v4Guard=Get-Content -LiteralPath (Join-Path $report 'v4-pass-preservation.json') -Raw | ConvertFrom-Json
if ($summary.sourceLenses -ne 19 -or $summary.analysisRequests -ne 638 -or $summary.rayCounts.Pass -ne 74 -or $originalGuard.preservedPass -ne 391 -or $v4Guard.preservedPass -ne 562 -or $originalGuard.regressions.Count -ne 0 -or $v4Guard.regressions.Count -ne 0) {throw 'Accepted matrix/pass-preservation scope mismatch.'}
$fixed=Get-Content -LiteralPath (Join-Path $taskRoot 'intersection-v3-fixed-runner.json') -Raw | ConvertFrom-Json
$coreSha='cf3647652213542dae90d0ed1c16b9df5290e740a0b204f1b4a6e0a9f40a6b2c'
if ($fixed.coreSha256 -cne $coreSha) {throw 'Unexpected accepted computation identity.'}
foreach ($source in $fixed.sourceFiles) {if ((Identity $source.path).sha256 -cne $source.sha256) {throw "Source changed after fixed computation: $($source.path)"}}
if ((Identity 'src/OpticalSystemDesign.Core/bin/Release/net10.0/OpticalSystemDesign.Core.dll').sha256 -cne $coreSha) {throw 'Default Release is not the accepted Core.'}
$peerRoot='artifacts/petzval-repair/2026-10-20'
$tests=@(
    (Test-Scope 'legacy-energy-and-material' (Join-Path $taskRoot 'tests/intersection-v3-legacy-116.trx') 116 'Original FftCumulative, MultiLensEncircledEnergy, PolychromaticCumulativeEnergy and material controls; no changed original assertion.'),
    (Test-Scope 'roots-and-five-energy-classes' (Join-Path $peerRoot 'tests/v3-roots-energy-targeted.trx') 146 'Near-planar root guards and five previously affected energy classes; fixed v3 main copy.'),
    (Test-Scope 'initial-structure-regression-repair' (Join-Path $peerRoot 'tests/v3-initial-targeted.trx') 4 'Both previously failing methods and adjacent data cases in the default built-in Engine; not all 308 contracts.'),
    (Test-Scope 'petzval-native' (Join-Path $peerRoot 'tests/v3-petzval-native.trx') 2 'Original relative-illumination and RMS-vs-field native settings and policy.'),
    (Test-Scope 'coating-complete' (Join-Path $taskRoot 'tests/coating-intersection-v3.trx') 54 'Complete coating test project with the accepted shared Core.'),
    (Test-Scope 'roots-debug' (Join-Path $peerRoot 'tests/v3-debug-roots.trx') 14 'Default Debug source, fixed copy; targeted root contracts only.'),
    (Test-Scope 'petzval-debug' (Join-Path $peerRoot 'tests/v3-debug-petzval.trx') 2 'Default Debug source, fixed copy; original native Petzval controls.'),
    (Test-Scope 'scalar-hardware-fallback' (Join-Path $peerRoot 'tests/v3-scalar-fallback.trx') 17 'Release fixed copy with hardware intrinsics disabled; overlaps standard root controls, do not sum.')
)
$testNames=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($file in @((Join-Path $taskRoot 'tests/intersection-v3-legacy-116.trx'),(Join-Path $peerRoot 'tests/v3-roots-energy-targeted.trx'))) {
    [xml]$xml=Get-Content -LiteralPath $file -Raw
    foreach ($case in $xml.SelectNodes('//*[local-name()="UnitTestResult"]')) {if (-not $testNames.Add($case.testName)) {throw 'Unexpected overlap in the 262 main controls.'}}
}
if ($testNames.Count -ne 262) {throw 'Unexpected main precision control coverage.'}
$rows=@(Import-Csv -LiteralPath (Join-Path $report 'analysis-matrix.csv'))
$sourcePaths=@(& git diff --name-only -- '*.cs' '*.csproj' '*.ps1' '*.json')+@(& git ls-files --others --exclude-standard -- '*.cs' '*.csproj' '*.ps1' '*.json')
$currentSources=@($sourcePaths | Sort-Object -Unique | Where-Object {$_ -notmatch '^(docs|validation)/'} | ForEach-Object {Identity $_})
$sealed=Get-Content -LiteralPath 'docs/validation/OBJECTIVES_COMPARISON_REPAIR_2026-10-20.json' -Raw | ConvertFrom-Json -AsHashtable
if ($sealed.Contains('sealedV4')) {$v4=$sealed.sealedV4} else {$v4=$sealed; $v4.Remove('postSealIntegration')}
$archive=if($IncludeArchive){
    $record=Get-Content -LiteralPath (Join-Path $report 'integration-archive.json') -Raw | ConvertFrom-Json
    $actual=Identity $record.path
    if($actual.sha256 -cne $record.sha256 -or -not $record.verifiedReadbackIncludingInheritedPayloads){throw 'Accepted integration archive mismatch.'}
    [ordered]@{evidence=$actual;baseArchive=$record.baseArchive;bothArchivesRequired=$true;logicalPayloadFiles=$record.logicalPayloadFiles;inheritedPayloadFiles=$record.inheritedPayloadFiles;freshPayloadFiles=$record.freshPayloadFiles;allFreshAndInheritedPayloadReadbackVerified=$true;finalExternalLedgerIncludedInOwnArchive=$false}
}else{$null}
$ledger=[ordered]@{
    schemaVersion=2
    date='2026-10-20'
    timezone='Asia/Shanghai'
    status='locally-verified-with-three-open-energy-differences'
    sourceCommit=(& git rev-parse HEAD)
    sourceDirty=$true
    scope=$summary.scope
    coreSha256=$coreSha
    fixedComputation=(Identity (Join-Path $taskRoot 'intersection-v3-fixed-runner.json'))
    defaultReleaseMatchesFixedCore=$true
    matrix=[ordered]@{lenses=19;analyses=638;counts=$summary.analysisCounts;error=0;rayGroups=74;rayPass=74;physicalSurfaceComparisons=$summary.physicalSurfaceComparisons;comparedValues=$summary.comparedValues;originalPass=391;originalPassPreserved=391;previousV4Pass=562;previousV4PassPreserved=562;regressions=0;summary=(Identity (Join-Path $report 'summary.json'));originalGuard=(Identity (Join-Path $report 'previous-pass-preservation.json'));v4Guard=(Identity (Join-Path $report 'v4-pass-preservation.json'))}
    remainingNumericalControls=@($rows | Where-Object Conclusion -in @('Difference','Close') | Select-Object Lens,Configuration,Scope,Analysis,Conclusion,Field,Wavelength,PupilSampling,WorstNRMSE,MaximumAbsolute,Reason)
    nativeReference=[ordered]@{authority='Licensed local OpticStudio 2026 R1';sourceLensesSaved=$false;successfulSameInputSameSettingsRawCapturesReused=749;oneUnavailableCaseReattempted=$true;typedUnavailable='NativeInvalidResult: 200-degree FFT PSF cross section';nativeJobs=750;completedAttempts=750;nativeValid=749;nativeUnavailable=1;unavailableCountedAsPrecisionPass=$false;reuse=(Identity (Join-Path $run 'native-reuse.json'))}
    originalAssets=[ordered]@{originalZmxAndEmbeddedMatches=19;stagedZmxAndZosUnchanged=38;frozenAssets=2668;frozenAggregateSha256='3a5fde98e1c881700f00be1c62d6ab4ff6f4feacc90454046ed787e80bf28c10';comparisonPolicySha256='30c27e7976710867d0edc6dd4099edac54ca9e070245dea679b3afdd88fd28f5';tolerancesChanged=$false;frozenReferencesChanged=$false}
    verification=[ordered]@{acceptedTestScopes=$tests;mainSelectedUniqueCases=262;existingAssertionsChanged=$false;fullMainRerunAfterV4=$false;fullInitialContractsRerunAfterR2=$false;userPreference='Do not repeat the complete test suite; validate affected numerical controls, known regressions and every requested lens.';earlierFullMain6271CertifiesOnlySealedV4=$true;initialLongSurveysNotRun=12;crossPlatformNotRun=$true;installerNotRebuilt=$true;rootBuilds=[ordered]@{configurations=@('Debug','Release');projectsPerConfiguration=19;warnings=0;errors=0;defaultOutputs=$true;releaseLog=(Identity (Join-Path $peerRoot 'build-v3-release.log'));debugLog=(Identity (Join-Path $peerRoot 'build-v3-debug.log'))};frozenReadback=(Identity (Join-Path $taskRoot 'final-identities/frozen-v7.json'));originalSourceReadback=(Identity (Join-Path $taskRoot 'final-identities/original-examples-v7.json'))}
    integratedPetzvalRepair=[ordered]@{sharedWorkspaceCollaborationExplicitlyAuthorized=$true;peerThreadTitle='调整结构数量设置位置';ordinaryAcceptedIntersectionsPreserved=$true;stableRootsOnlyWhenBothOriginalRootsFailExplicitSagValidation=$true;linearBranchesAndResidualLimitsUnchanged=$true;standardRootNewControls=14;initialEngineSha256='127f5fb0b79028151e2f0f703fcaaa64fa5b8895766f4176e06899e58f0c3487';fixedModuleSource='Default root solution Release build, not prototype';fixedPeerManifest=(Identity (Join-Path $peerRoot 'frozen-v3/manifest.json'));r1BroadRootCandidateRejected=$true;r2ErrorBoundCandidateRejected=$true;r2InitialContracts=[ordered]@{total=308;passed=306;failed=2;evidence=(Identity (Join-Path $taskRoot 'tests/initial-intersection-contracts.trx'))};failedAssertionsNotWeakened=$true}
    importedMaterialInputs=$v4.importedMaterialInputs
    repairs=$v4.repairs+@('Recover lost near-planar intersections only after the original explicit-sag tests reject both ordinary roots; retain successful-root bit patterns and original optimization/energy guards.')
    currentSourceFiles=$currentSources
    sealedV4=$v4
    archive=$archive
    delivery=[ordered]@{pushedByThisTask=$false;committedByThisTask=$false;installedPackageUpdated=$false;sourceAndDefaultBuildOnly=$true}
}
$ledger | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath 'docs/validation/OBJECTIVES_COMPARISON_REPAIR_2026-10-20.json' -Encoding utf8
$tests | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $taskRoot 'accepted-integration-test-scopes.json') -Encoding utf8
Write-Output 'Integrated Objectives ledger written with exact test scopes and retained rejected candidates.'
