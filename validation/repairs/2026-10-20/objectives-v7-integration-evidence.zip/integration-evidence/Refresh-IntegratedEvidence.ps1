$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$repository=(Resolve-Path -LiteralPath (Join-Path $taskRoot '../../..')).Path
Set-Location -LiteralPath $repository
$evidence=Join-Path $taskRoot 'integration-corroboration-v3'
if(Test-Path -LiteralPath $evidence){throw 'Use a fresh final integration evidence snapshot.'}
[IO.Directory]::CreateDirectory($evidence)|Out-Null
function Copy-EvidenceTree([string]$From,[string]$To){
    $sourceRoot=(Resolve-Path -LiteralPath $From).Path
    foreach($sourceFile in Get-ChildItem -LiteralPath $sourceRoot -File -Recurse){
        $relative=[IO.Path]::GetRelativePath($sourceRoot,$sourceFile.FullName)
        if($relative -match '(^|[\\/])(bin|obj|host|runtimes)([\\/]|$)' -or $sourceFile.Extension -notin @('.cs','.csproj','.ps1','.md','.json','.txt','.csv','.log','.trx','.zmx','.zos','.cfg','.xml')){continue}
        $target=Join-Path $To $relative
        [IO.Directory]::CreateDirectory((Split-Path -Parent $target))|Out-Null
        [IO.File]::Copy($sourceFile.FullName,$target,$true)
    }
}
Copy-EvidenceTree (Join-Path $taskRoot 'tests') (Join-Path $evidence 'tests')
Copy-EvidenceTree (Join-Path $taskRoot 'final-identities') (Join-Path $evidence 'final-identities')
Copy-EvidenceTree (Join-Path $taskRoot 'report-final-v6-intersection') (Join-Path $evidence 'rejected-r2-directory-report')
Copy-EvidenceTree (Join-Path $taskRoot 'intersection-candidate-controls-v2') (Join-Path $evidence 'rejected-r1-selected-controls')
foreach($file in Get-ChildItem -LiteralPath $taskRoot -File){if($file.Extension -in @('.log','.json','.ps1')){[IO.File]::Copy($file.FullName,(Join-Path $evidence $file.Name),$true)}}
$peerRoot=Join-Path $repository 'artifacts/petzval-repair/2026-10-20'
Copy-EvidenceTree (Join-Path $peerRoot 'tests') (Join-Path $evidence 'peer-tests')
foreach($file in Get-ChildItem -LiteralPath $peerRoot -File){if($file.Extension -in @('.log','.json','.ps1')){[IO.File]::Copy($file.FullName,(Join-Path $evidence ('petzval-'+$file.Name)),$true)}}
$manifestTarget=Join-Path $evidence 'petzval-fixed-v3-manifest.json'
[IO.File]::Copy((Join-Path $peerRoot 'frozen-v3/manifest.json'),$manifestTarget,$true)
Copy-EvidenceTree 'validation/zemax/2026-r1/objectives-2026-10-20' (Join-Path $evidence 'portable-objectives')
Copy-EvidenceTree 'validation/repairs/2026-10-20/petzval-illumination-rms' (Join-Path $evidence 'portable-petzval')
$changed=@(& git diff --name-only)+@(& git ls-files --others --exclude-standard)
foreach($relative in $changed | Sort-Object -Unique){
    if($relative -match '^validation/' -or [IO.Path]::GetExtension($relative) -notin @('.cs','.csproj','.ps1','.md','.json')){continue}
    $target=Join-Path (Join-Path $evidence 'source-current') $relative
    [IO.Directory]::CreateDirectory((Split-Path -Parent $target))|Out-Null
    [IO.File]::Copy((Join-Path $repository $relative),$target,$true)
}
$patchPath=Join-Path $evidence 'working-tree.patch'
& git diff --binary "--output=$patchPath"
if($LASTEXITCODE -ne 0){throw 'Final source patch generation failed.'}
@'
# Final integrated Objectives evidence

The enclosing delta ZIP and the sealed V4 base ZIP jointly reconstruct every logical payload of the final V7 run. The manifest names each exact base entry or fresh ZIP entry and its bytes/SHA-256. No native reference, tolerance or original prescription was replaced.

Rejected R1/R2 controls and R2's completed 638-analysis report remain distinctly labelled; the R2 initial-structure run was 306/308, not a pass. Intermediate raw matrix directories remain locally under artifacts. This package carries the rejected selected controls, failure logs, all retained test results and their summaries, rather than claiming every rejected run is a final result.

Final source snapshots include prior authorized workspace changes. The external final ledger supplies the sealed archive identity and final documentation check, avoiding a self-hash cycle. The previous complete 6271-case main run certifies V4 only. Final v3 uses targeted regression at the user's request, including both observed initial-structure failures and the unchanged energy controls. Proprietary APIs, executables and build outputs are excluded.
'@|Set-Content -LiteralPath (Join-Path $evidence 'README.md') -Encoding utf8
'Final integration evidence snapshot refreshed.'
