param([string]$RepositoryRoot, [string]$CalculationDirectory)
$ErrorActionPreference = 'Stop'
$repository = [IO.Path]::GetFullPath($RepositoryRoot)
$calculation = [IO.Path]::GetFullPath($CalculationDirectory)
$nativePath = Join-Path $repository 'artifacts/petzval-repair/2026-10-20/before-v1/native-rays/native/ray-audit.json'
$histories = Get-Content (Join-Path $calculation 'gaussian-histories.json') -Raw | ConvertFrom-Json
$native = Get-Content $nativePath -Raw | ConvertFrom-Json
$model = Get-Content (Join-Path (Split-Path $nativePath) 'model.json') -Raw | ConvertFrom-Json
$vertices = @{}
$vertex = 0.0
foreach ($surface in $model.surfaces | Where-Object { $_.SurfaceNumber -ge 1 }) {
    $vertices[[int]$surface.SurfaceNumber] = $vertex
    $vertex += $surface.Thickness
}
$maximumCoordinate = 0.0
$maximumDirection = 0.0
$records = 0
$errors = 0
$vignettes = 0
$notAtImage = 0
foreach ($surface in $native.surfaces) {
    for ($field = 0; $field -lt $histories.Count; $field++) {
        for ($pupil = 0; $pupil -lt $histories[$field].rays.Count; $pupil++) {
            $index = $field * 72 + $pupil
            $n = $surface.rays[$index]
            if ($n.number -ne $index + 1) { throw 'Native ray order mismatch' }
            $sample = @($histories[$field].rays[$pupil].samples | Where-Object surfaceNumber -eq $surface.surface)
            if ($sample.Count -ne 1) { throw 'Missing or duplicate scalar sample' }
            $s = $sample[0]
            $local = @{x=$s.position.x; y=$s.position.y; z=$s.position.z-$vertices[[int]$surface.surface]}
            foreach ($axis in @('x','y','z')) {
                $maximumCoordinate = [Math]::Max($maximumCoordinate, [Math]::Abs($local.$axis-$n.$axis))
            }
            foreach ($pair in @(@('x','l'), @('y','m'), @('z','n'))) {
                $maximumDirection = [Math]::Max($maximumDirection, [Math]::Abs($s.direction.($pair[0])-$n.($pair[1])))
            }
            if ($n.error) { $errors++ }
            if ($n.vignette) { $vignettes++ }
            $records++
        }
    }
}
foreach ($field in $histories) {
    foreach ($ray in $field.rays) {
        if ($ray.samples[-1].surfaceNumber -ne 9 -or $ray.samples[-1].vignetted) { $notAtImage++ }
    }
}
$result = [ordered]@{
    fields=$histories.Count; rays=1152; physicalSurfaceRecords=$records
    maximumCoordinateMillimeters=$maximumCoordinate; maximumDirection=$maximumDirection
    nativeErrors=$errors; nativeVignettes=$vignettes; allExpectedRaysReachedImage=($notAtImage -eq 0)
    originalUnchangedRayCoordinateLimit='1e-6 + 1e-6*abs(reference) mm'
    originalUnchangedRayDirectionLimit='1e-8 + 1e-6*abs(reference)'
    coordinateConvention='Scalar world positions converted to captured local surface coordinates using the centered Petzval vertex offsets'
    nativeCapture=$nativePath; nativeCaptureSha256=(Get-FileHash $nativePath -Algorithm SHA256).Hash.ToLowerInvariant()
    coreSha256='cf3647652213542dae90d0ed1c16b9df5290e740a0b204f1b4a6e0a9f40a6b2c'
}
$result | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $calculation 'gaussian-native-summary.json') -Encoding utf8NoBOM
if ($records -ne 10368 -or $notAtImage -or $errors -or $vignettes -or $maximumCoordinate -gt 1e-6 -or $maximumDirection -gt 1e-8) {
    throw 'Native ray audit exceeds unchanged absolute limits'
}
$result | ConvertTo-Json -Depth 3
