# Final integrated Objectives evidence

The enclosing delta ZIP and the sealed V4 base ZIP jointly reconstruct every logical payload of the final V7 run. The manifest names each exact base entry or fresh ZIP entry and its bytes/SHA-256. No native reference, tolerance or original prescription was replaced.

Rejected R1/R2 controls and R2's completed 638-analysis report remain distinctly labelled; the R2 initial-structure run was 306/308, not a pass. Intermediate raw matrix directories remain locally under artifacts. This package carries the rejected selected controls, failure logs, all retained test results and their summaries, rather than claiming every rejected run is a final result.

Final source snapshots include prior authorized workspace changes. The external final ledger supplies the sealed archive identity and final documentation check, avoiding a self-hash cycle. The previous complete 6271-case main run certifies V4 only. Final v3 uses targeted regression at the user's request, including both observed initial-structure failures and the unchanged energy controls. Proprietary APIs, executables and build outputs are excluded.
