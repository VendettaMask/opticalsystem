param([string]$SourceCommit='45cce15b2949ce66168341bbfab22c00a3a1e60e', [long]$RunId=40255818669)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$api=Join-Path (Split-Path -Parent $root) 'cloud-release-2026-10-26/github-task-api.ps1'
$release=(& $api -Route 'releases/tags/v1.0.4-test.20261019').Data
$before=Get-Content -LiteralPath (Join-Path $root 'release-before.json') -Raw | ConvertFrom-Json
$name="OpticalSystemDesign-1.0.4-win-x64-UnsignedTest-Setup-$($SourceCommit.Substring(0,8)).exe"
$installers=@($release.assets | Where-Object name -CEQ $name)
if($installers.Count -ne 1 -or $release.draft -or -not $release.prerelease){throw 'Expected published test installer is missing.'}
$installer=$installers[0]
$oldMac=@($before.assets | Where-Object name -Like '*.dmg')[0]
$mac=@($release.assets | Where-Object name -CEQ $oldMac.name)
if($mac.Count -ne 1 -or $mac[0].id -ne $oldMac.id -or $mac[0].size -ne $oldMac.size -or $mac[0].digest -cne $oldMac.digest){throw 'Preserved Mac attachment changed.'}
if(@($release.assets | Where-Object name -Like '*.exe').Count -ne 1){throw 'Windows installer is ambiguous.'}
$oldMacDetail=@($before.body -split '\r?\n' | Where-Object {$_.StartsWith("- $($oldMac.name) |",[StringComparison]::Ordinal)})
if($oldMacDetail.Count -ne 1 -or -not $release.body.Contains($oldMacDetail[0])){throw 'Preserved Mac source detail changed.'}
$markers=[regex]::Matches($release.body,'(?s)<!-- optical-system-design-ota-v1\s+([A-Za-z0-9+/=]+)\.([A-Za-z0-9+/=]+)\s+-->')
if($markers.Count -ne 1){throw 'Expected one signed Windows update envelope.'}
$bytes=[Convert]::FromBase64String($markers[0].Groups[1].Value)
$signature=[Convert]::FromBase64String($markers[0].Groups[2].Value)
$rsa=[Security.Cryptography.RSA]::Create()
try {
    $rsa.ImportFromPem((Get-Content -LiteralPath 'src/OpticalSystemDesign.App/Assets/Updates/ota-public-key.pem' -Raw))
    if($rsa.KeySize -ne 4096 -or -not $rsa.VerifyData($bytes,$signature,[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pss)){throw 'Published update signature failed.'}
} finally {$rsa.Dispose()}
$payload=[Text.Encoding]::UTF8.GetString($bytes)|ConvertFrom-Json
if($payload.Format -ne 2 -or $payload.Repository -cne 'VendettaMask/opticalsystem' -or $payload.ProductAppId -cne 'OpticalSystemDesign-8D387EA8-F349-447F-B5D3-B58E27F46D4A' -or $payload.Version -cne '1.0.4' -or $payload.Tag -cne 'v1.0.4-test.20261019' -or $payload.Runtime -cne 'win-x64' -or $payload.Name -cne $name -or $payload.SourceCommit -cne $SourceCommit -or $payload.BuildSequence -ne $RunId -or $payload.Size -ne $installer.size -or $installer.digest -cne "sha256:$($payload.Sha256)" -or $payload.ReleaseId -cnotmatch '^1\.0\.4-win-x64-[0-9a-f]{12}$'){throw 'Published source, signature or attachment identity differs.'}
$expectedUrl="https://github.com/VendettaMask/opticalsystem/releases/download/v1.0.4-test.20261019/$name"
if($installer.browser_download_url -cne $expectedUrl -or -not $release.name.EndsWith($SourceCommit.Substring(0,8))){throw 'Release name or URL differs.'}
$release|ConvertTo-Json -Depth 16|Set-Content -LiteralPath (Join-Path $root 'release-after.json') -Encoding utf8
$result=[ordered]@{VerifiedUtc=[DateTimeOffset]::UtcNow.ToString('o');WorkflowRunId=$RunId;SourceCommit=$SourceCommit;Name=$name;Size=[long]$installer.size;Sha256=$payload.Sha256;ReleaseId=$payload.ReleaseId;BuildSequence=[long]$payload.BuildSequence;SignatureVerified=$true;MacAssetPreserved=$true;MacSourceDetailPreserved=$true;ReleaseUrl=$release.html_url;DownloadUrl=$expectedUrl;LocalInstallerExecuted=$false}
$result|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $root 'published-verification.json') -Encoding utf8
$result|ConvertTo-Json -Depth 5
