$ErrorActionPreference = 'Stop'
$verifyRoot = (Get-Location).Path
$verifyWork = '.tmp/local-revalidation-20261019'
$verifyOriginal = "$verifyWork/original"
$verifyResults = "$verifyWork/results"
$verifySync = Get-Content docs/validation/SOURCE_SYNC_2026-10-18.json -Raw | ConvertFrom-Json
$verifySourceCommit = (git rev-parse HEAD).Trim()
if ($verifySourceCommit -ne '33f6ac99a78c05160bfabd9e12be720650679ba1') { throw 'Source revision changed during verification.' }

function Hash-Text([string]$Value) {
    [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($Value))).ToLowerInvariant()
}
function Hash-File([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }

$verifyInputs = [Collections.Generic.List[object]]::new()
foreach ($verifyGroup in @('FrozenNativeFixtures', 'FrozenArchives', 'VerifiedCSharpFiles')) {
    $verifyExceptions = [Collections.Generic.List[object]]::new()
    $verifyEntries = @($verifySync.$verifyGroup)
    foreach ($verifyEntry in $verifyEntries) {
        $verifyActual = Hash-File $verifyEntry.path
        if ($verifyActual -eq $verifyEntry.sha256) { continue }
        if ($verifyGroup -ne 'VerifiedCSharpFiles' -or $verifyEntry.path -ne 'tests/OpticalSystemDesign.Tests/FiniteFftAimingEnergyTests.cs') {
            throw "Unresolved input integrity mismatch: $($verifyEntry.path)"
        }
        $verifyZip = [IO.Compression.ZipFile]::OpenRead((Join-Path $verifyRoot 'validation/repairs/2026-10-18/expanded-sampling-energy-repair-evidence.zip'))
        try {
            $verifyReader = [IO.StreamReader]::new($verifyZip.GetEntry('source/tests/OpticalSystemDesign.Tests/FiniteFftAimingEnergyTests.cs').Open())
            try { $verifyArchivedText = $verifyReader.ReadToEnd() } finally { $verifyReader.Dispose() }
        } finally { $verifyZip.Dispose() }
        $verifyRecordedText = $verifyArchivedText.TrimEnd([char[]]"`r`n") + "`r`n"
        $verifyCurrentText = [IO.File]::ReadAllText((Join-Path $verifyRoot $verifyEntry.path))
        if ((Hash-Text $verifyRecordedText) -ne $verifyEntry.sha256) { throw 'Cannot reconstruct recorded post-format byte identity.' }
        if ($verifyRecordedText.Replace("`r`n", "`n") -cne $verifyCurrentText) { throw 'Source differs beyond Git line-ending normalization.' }
        $verifyGitBlob = (git rev-parse "HEAD:$($verifyEntry.path)").Trim()
        $verifyWorkBlob = (git hash-object -- $verifyEntry.path).Trim()
        if ($verifyGitBlob -ne $verifyWorkBlob) { throw 'Test source differs from the committed blob.' }
        $verifyExceptions.Add([ordered]@{
            Path = $verifyEntry.path
            RecordedPostFormatSha256 = $verifyEntry.sha256
            CurrentGitCheckoutSha256 = $verifyActual
            ArchivedPreFormatSha256 = Hash-Text $verifyArchivedText
            RecordedPostFormatHashReconstructedFromArchive = $true
            Difference = 'Only Git CRLF-to-LF checkout normalization; exact source matches after line-ending conversion'
            TestStatementsAndAssertionsChanged = $false
            MatchesCommittedGitBlob = $true
        })
    }
    $verifyInputs.Add([ordered]@{
        Group = $verifyGroup
        Checked = $verifyEntries.Count
        ExactByteMatches = $verifyEntries.Count - $verifyExceptions.Count
        ExplainedLineEndingExceptions = $verifyExceptions.ToArray()
        UnresolvedMismatches = 0
    })
}
$verifyInputs | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$verifyWork/input-integrity.json" -Encoding utf8NoBOM

$verifyBinaries = [Collections.Generic.List[object]]::new()
foreach ($verifyConfig in @('Debug', 'Release')) {
    $verifyCore = "src/OpticalSystemDesign.Core/bin/$verifyConfig/net10.0/OpticalSystemDesign.Core.dll"
    $verifyHash = Hash-File $verifyCore
    $verifyCopies = @(
        "src/OpticalSystemDesign.App/bin/$verifyConfig/net10.0/OpticalSystemDesign.Core.dll",
        "tests/OpticalSystemDesign.Tests/bin/$verifyConfig/net10.0/OpticalSystemDesign.Core.dll",
        "tests/OpticalSystemDesign.ZemaxComparison.Tests/bin/$verifyConfig/net10.0/OpticalSystemDesign.Core.dll",
        "tools/OpticalSystemDesign.ZemaxComparison/bin/$verifyConfig/net10.0/OpticalSystemDesign.Core.dll")
    foreach ($verifyCopy in $verifyCopies) {
        if ((Hash-File $verifyCopy) -ne $verifyHash) { throw "Default Core copy mismatch: $verifyCopy" }
    }
    $verifyBinaries.Add([ordered]@{
        Configuration = $verifyConfig
        CoreSha256 = $verifyHash
        MatchingDefaultCoreCopies = $verifyCopies
        AppExeSha256 = Hash-File "src/OpticalSystemDesign.App/bin/$verifyConfig/net10.0/OpticalSystemDesign.App.exe"
        AppDllSha256 = Hash-File "src/OpticalSystemDesign.App/bin/$verifyConfig/net10.0/OpticalSystemDesign.App.dll"
    })
}

$verifyTests = [Collections.Generic.List[object]]::new()
foreach ($verifySpec in @(
    @{ File = 'main-release.trx'; Original = 'Release.trx'; Total = 1148; Scope = 'Main related Release' },
    @{ File = 'main-debug.trx'; Original = 'Debug.trx'; Total = 435; Scope = 'Main focused Debug' },
    @{ File = 'comparison-release.trx'; Original = 'comparison-Release.trx'; Total = 5; Scope = 'Comparison Release' },
    @{ File = 'comparison-debug.trx'; Original = 'comparison-Debug.trx'; Total = 5; Scope = 'Comparison Debug' })) {
    [xml]$verifyTrx = Get-Content -LiteralPath "$verifyResults/$($verifySpec.File)" -Raw
    [xml]$verifyPriorTrx = Get-Content -LiteralPath "$verifyOriginal/$($verifySpec.Original)" -Raw
    $verifyRows = @($verifyTrx.SelectNodes('//*[local-name()="UnitTestResult"]'))
    $verifyPriorRows = @($verifyPriorTrx.SelectNodes('//*[local-name()="UnitTestResult"]'))
    $verifyCounters = $verifyTrx.SelectSingleNode('//*[local-name()="Counters"]')
    $verifyTimes = $verifyTrx.SelectSingleNode('//*[local-name()="Times"]')
    $verifyNameDiff = @(Compare-Object ($verifyPriorRows.testName | Sort-Object) ($verifyRows.testName | Sort-Object))
    if ($verifyNameDiff.Count -ne 0) { throw "Test selection differs from the frozen run: $($verifySpec.Scope)" }
    if ($verifyRows.Count -ne $verifySpec.Total -or [int]$verifyCounters.passed -ne $verifySpec.Total -or @($verifyRows | Where-Object outcome -ne 'Passed').Count -ne 0) {
        throw "Test run is incomplete or failed: $($verifySpec.Scope)"
    }
    $verifyTests.Add([ordered]@{
        Scope = $verifySpec.Scope
        Total = [int]$verifyCounters.total
        Passed = [int]$verifyCounters.passed
        Failed = [int]$verifyCounters.failed
        Skipped = [int]$verifyCounters.notExecuted
        Seconds = ([datetimeoffset]$verifyTimes.finish - [datetimeoffset]$verifyTimes.start).TotalSeconds
        TestNamesExactlyMatchFrozenRun = $true
        TestNameSetSha256 = Hash-Text (($verifyRows.testName | Sort-Object) -join "`n")
        TrxSha256 = Hash-File "$verifyResults/$($verifySpec.File)"
        OriginalTrxSha256 = Hash-File "$verifyOriginal/$($verifySpec.Original)"
    })
}

$verifyArchiveRelative = 'validation/rechecks/2026-10-19/local-build-and-regression-evidence.zip'
$verifyArchivePath = Join-Path $verifyRoot $verifyArchiveRelative
if (Test-Path -LiteralPath $verifyArchivePath) { throw 'Do not overwrite an existing verification archive.' }
[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($verifyArchivePath))
$verifyArchiveFiles = [ordered]@{
    'builds/build-debug.binlog' = "$verifyWork/build-debug.binlog"
    'builds/build-release.binlog' = "$verifyWork/build-release.binlog"
    'inputs/input-integrity.json' = "$verifyWork/input-integrity.json"
    'verification/CollectVerification.ps1' = "$verifyWork/CollectVerification.ps1"
}
foreach ($verifyFile in Get-ChildItem -LiteralPath $verifyResults -File -Filter '*.trx') { $verifyArchiveFiles["results/$($verifyFile.Name)"] = $verifyFile.FullName }
foreach ($verifyFile in Get-ChildItem -LiteralPath $verifyOriginal -File) { $verifyArchiveFiles["original/$($verifyFile.Name)"] = $verifyFile.FullName }
$verifyZip = [IO.Compression.ZipFile]::Open($verifyArchivePath, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($verifyPair in $verifyArchiveFiles.GetEnumerator()) {
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($verifyZip, [IO.Path]::GetFullPath($verifyPair.Value), $verifyPair.Key, [IO.Compression.CompressionLevel]::Optimal)
    }
} finally { $verifyZip.Dispose() }
$verifyZip = [IO.Compression.ZipFile]::OpenRead($verifyArchivePath)
try {
    if ($verifyZip.Entries.Count -ne $verifyArchiveFiles.Count) { throw 'Archive entry count mismatch.' }
    foreach ($verifyEntry in $verifyZip.Entries) {
        $verifyStream = $verifyEntry.Open()
        try { $verifyReadHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($verifyStream)).ToLowerInvariant() }
        finally { $verifyStream.Dispose() }
        if ($verifyReadHash -ne (Hash-File $verifyArchiveFiles[$verifyEntry.FullName])) { throw "Archive readback mismatch: $($verifyEntry.FullName)" }
    }
} finally { $verifyZip.Dispose() }
$verifyReport = [ordered]@{
    Date = '2026-10-19'
    SourceCommit = $verifySourceCommit
    Scope = 'Local default Debug/Release root builds and exact replay of the incoming latest related/focused test selections'
    Sdk = (dotnet --version).Trim()
    Builds = @(
        @{ Configuration = 'Debug'; Projects = 19; Warnings = 0; Errors = 0; Seconds = 51.08; BinlogSha256 = Hash-File "$verifyWork/build-debug.binlog" },
        @{ Configuration = 'Release'; Projects = 19; Warnings = 0; Errors = 0; Seconds = 43.30; BinlogSha256 = Hash-File "$verifyWork/build-release.binlog" })
    Tests = $verifyTests.ToArray()
    CountsOverlapAndMustNotBeAdded = $true
    SourceAndFrozenInputIntegrity = $verifyInputs.ToArray()
    InitialRawSourceHashAudit = '48/49 exact source byte matches; the one mismatch is fully reconstructed from the frozen pre-format archive and explained by Git CRLF-to-LF checkout normalization. No frozen ledger or source was edited to hide it.'
    DefaultOutputs = $verifyBinaries.ToArray()
    Evidence = [ordered]@{
        Path = $verifyArchiveRelative
        Entries = $verifyArchiveFiles.Count
        Bytes = (Get-Item -LiteralPath $verifyArchivePath).Length
        Sha256 = Hash-File $verifyArchivePath
        EveryEntryReadbackSha256MatchesOriginal = $true
    }
    FullSuiteRerun = $false
    NewNativeCapture = $false
    DesktopManuallyLaunched = $false
    ProductOrTestSourceChanged = $false
    ReferencesOrTolerancesChanged = $false
    InstallerRebuilt = $false
    CommittedOrPushed = $false
    DocumentationCheck = 'Pending final documentation check after recording these results'
}
$verifyReport | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath docs/validation/LOCAL_BUILD_REVALIDATION_2026-10-19.json -Encoding utf8NoBOM
$verifyReport | Select-Object Date, SourceCommit, Sdk, Builds, Tests, Evidence | ConvertTo-Json -Depth 6
