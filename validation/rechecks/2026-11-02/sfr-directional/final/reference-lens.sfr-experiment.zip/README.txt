Relative linear irradiance; monochrome local isoplanatic traced-pupil Fourier PSF; full square pixels. No CFA, ADC, noise, ISP or gamma.
SFR uses floating-point pixel arrays, not the 8-bit PNG preview. ROI coordinates refer to the original sensor.
Model: MonochromeLocalFourierEdge/3. Version 3 integrates pupil cells and includes independent full-pupil MTF. Versions 1/2 are view-only.
Optical and pixel-integrated MTF are direct Fourier sections of the same finite PSF along the fitted edge normal.
Full-pupil MTF is independently computed by pupil autocorrelation, without the finite PSF window. Both pixel references include the square pixel exactly once.
Sampling checks double one axis at a time; incomplete checks are not passes. Numerical convergence is not ISO certification.
