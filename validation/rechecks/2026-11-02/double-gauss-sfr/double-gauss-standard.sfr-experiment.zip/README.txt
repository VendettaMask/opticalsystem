Relative linear irradiance; monochrome local isoplanatic traced-pupil Fourier PSF; full square pixels. No CFA, ADC, noise, ISP or gamma.
SFR uses floating-point pixel arrays, not the 8-bit PNG preview. ROI coordinates refer to the original sensor.
Model: MonochromeLocalFourierEdge/2. Version 2 checks unwrapped pupil phase and integrates projected PSF shifts analytically; version 1 is view-only.
Optical and pixel-integrated MTF are direct Fourier sections of the same finite PSF along the fitted edge normal.
Sampling checks double one axis at a time; incomplete checks are not passes. Numerical convergence is not ISO certification.
