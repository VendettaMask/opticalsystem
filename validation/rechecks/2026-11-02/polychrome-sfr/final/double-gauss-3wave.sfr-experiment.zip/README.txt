Relative linear irradiance; local isoplanatic traced-pupil Fourier PSF; full square pixels. No CFA, ADC, noise, ISP or gamma.
SFR uses floating-point pixel arrays, not the 8-bit PNG preview. ROI coordinates refer to the original sensor.
Model: PolychromeLocalFourierEdge/1. Monochrome versions 1/2 are view-only; monochrome 3 and polychrome 1 support frozen replay.
Optical and pixel-integrated MTF are direct Fourier sections of the same finite PSF along the fitted edge normal.
Full-pupil MTF is independently computed by pupil autocorrelation, without the finite PSF window. Both pixel references include the square pixel exactly once.
Polychrome mode freezes the lens wavelength rows and relative image-energy weights; zero weights are excluded, all-zero weights rejected.
All bands share the lens primary-wavelength chief reference. Mix linear PSF intensities before crop normalization; mix complex OTFs before magnitude. No extra QE or photon weighting.
Sampling checks double one axis at a time; incomplete checks are not passes. Numerical convergence is not ISO certification.
