using System.Reflection;
using Avalonia;
using Avalonia.Platform;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using Avalonia.Skia;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.Application.Contracts;
using SkiaSharp;
using System.Diagnostics;
using System.Text.Json;
using OpticalSystemDesign.Application.Services;

internal static class Program
{
 [STAThread]
 public static void Main()
 {
  Environment.SetEnvironmentVariable("OPTICAL_SYSTEM_DESIGN_SETTINGS_DIRECTORY",Path.Combine(AppContext.BaseDirectory,"profile"));
  using var application=WorkbenchApplication.Create();
  application.Documents.OpenAsync(Path.GetFullPath("src/OpticalSystemDesign.App/Assets/SequentialExamples/Afocal/Beam Expander.ZMX")).GetAwaiter().GetResult();
  var result=application.Analyses.RunAsync(new(Guid.NewGuid(),1,"Interferogram",new Dictionary<string,string>{{"Sampling","512 x 512"},{"ShowAs","灰度"},{"XTilt","3"},{"YTilt","-1"}}){UseGpuAcceleration=false}).GetAwaiter().GetResult();
  var points=result.View.Series.First().Points.Where(p=>p.Value.HasValue && double.IsFinite(p.Value.Value)).ToArray();
  AppBuilder.Configure<Application>().UsePlatformDetect().SetupWithoutStarting();
  var locator=typeof(AvaloniaLocator).GetProperty("Current",BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)!.GetValue(null)!;
  var graphics=(IPlatformGraphics?)locator.GetType().GetMethod("GetService",new[]{typeof(Type)})!.Invoke(locator,new object[]{typeof(IPlatformGraphics)});
  Console.WriteLine("Graphics="+graphics?.GetType().FullName);
  if(graphics is null) throw new InvalidOperationException("GPU is unavailable");
  var platform=(IPlatformRenderInterface)locator.GetType().GetMethod("GetService",new[]{typeof(Type)})!.Invoke(locator,new object[]{typeof(IPlatformRenderInterface)})!;
  using var gpu=graphics.UsesSharedContext?graphics.GetSharedContext():graphics.CreateContext();
  using var current=gpu.EnsureCurrent();
  using var backend=(IPlatformRenderInterfaceContext)typeof(IPlatformRenderInterface).GetMethod("CreateBackendContext",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)!.Invoke(platform,new object[]{gpu})!;
  var xs=points.Select(p=>p.X).Distinct().Order().ToArray();var ys=points.Select(p=>p.Y).Distinct().Order().ToArray();
  var values=new double[ys.Length,xs.Length]; int valid=points.Length;
  for(int y=0;y<ys.Length;y++)for(int x=0;x<xs.Length;x++)values[y,x]=double.NaN;
  var xIndex=xs.Select((v,i)=>(v,i)).ToDictionary(p=>p.v,p=>p.i);var yIndex=ys.Select((v,i)=>(v,i)).ToDictionary(p=>p.v,p=>p.i);
  foreach(var p in points)values[yIndex[p.Y],xIndex[p.X]]=p.Value!.Value;
  using var target=(IDrawingContextLayerImpl)typeof(IPlatformRenderInterfaceContext).GetMethod("CreateOffscreenRenderTarget",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)!.Invoke(backend,new object[]{new PixelSize(1200,900),new Vector(96,96),true})!;
  var ctor=typeof(ImmediateDrawingContext).GetConstructors(BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).First(c=>c.GetParameters().Length>0 && c.GetParameters()[0].ParameterType==typeof(IDrawingContextImpl));
  Console.WriteLine("Drawing constructor="+ctor);
  using var operation=new ScalarMapRasterOperation(xs,ys,values,new Rect(30,30,1140,840),xs[1]-xs[0],ys[1]-ys[0],0,1,AnalysisColorMap.InverseGray,EdgeMode.Unspecified);
  var process=Process.GetCurrentProcess();
  for(int frame=0;frame<20;frame++)
  {
   var watch=Stopwatch.StartNew();
   var drawing=typeof(IDrawingContextLayerImpl).GetMethod("CreateDrawingContext",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)!.Invoke(target,null)!;
   using(var dc=(ImmediateDrawingContext)ctor.Invoke(ctor.GetParameters().Select(p=>p.ParameterType==typeof(IDrawingContextImpl)?drawing:p.HasDefaultValue?p.DefaultValue:p.ParameterType==typeof(bool)?true:Activator.CreateInstance(p.ParameterType)).ToArray()))
   {
    dc.FillRectangle(new ImmutableSolidColorBrush(Colors.White),new Rect(0,0,1200,900));
    var scale=frame<10?1d:frame%2==0?.875:1d;
    using var transform=dc.PushPreTransform(Matrix.CreateScale(scale,scale));
    using var opacity=dc.PushOpacity(frame<10?.85:frame%3==0?1:.85,new Rect(0,0,1200,900));
    operation.Render(dc);
    var feature=dc.TryGetFeature<ISkiaSharpApiLeaseFeature>()!;
    using var lease=feature.Lease();
    if(lease.GrContext is null) throw new InvalidOperationException("This is not a GPU surface");
    lease.GrContext.Flush();
    using var pixels=new SKBitmap(1200,900);
    if(!lease.SkSurface!.ReadPixels(pixels.Info,pixels.GetPixels(),pixels.RowBytes,0,0)) throw new Exception("GPU readback failed");
    if(frame==19)
    {
     using var stream=File.Create(Path.Combine(AppContext.BaseDirectory,"gpu-frame.png"));
     using var image=SKImage.FromBitmap(pixels);using var png=image.Encode(SKEncodedImageFormat.Png,100);png.SaveTo(stream);
    }
   }
   process.Refresh();
   Console.WriteLine(JsonSerializer.Serialize(new{frame,valid,milliseconds=watch.Elapsed.TotalMilliseconds,privateBytes=process.PrivateMemorySize64,workingSet=process.WorkingSet64,gcBytes=GC.GetGCMemoryInfo().HeapSizeBytes}));
  }
 }
}
