using System.Diagnostics;
using System.Reflection;
using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using OpticalSystemDesign.App.Panels;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.Application.Contracts;
using OpticalSystemDesign.Application.Services;
using OpticalSystemDesign.Tests;

var directory = Path.GetFullPath(args[0]);
Directory.CreateDirectory(directory);
Environment.SetEnvironmentVariable("OPTICAL_SYSTEM_DESIGN_SETTINGS_DIRECTORY", Path.Combine(directory, "profile"));
var sampling = int.Parse(args[1]);
var mode = args[2] switch { "gray" => "灰度", "color" => "伪彩色", "contour" => "等高线", _ => args[2] };
var tabIndex = args.Length > 3 ? int.Parse(args[3]) : 0;
using var application = WorkbenchApplication.Create();
await application.Documents.OpenAsync(Path.GetFullPath("src/OpticalSystemDesign.App/Assets/SequentialExamples/Afocal/Beam Expander.ZMX"));
var watch = Stopwatch.StartNew();
var settings = new Dictionary<string, string> { ["Sampling"] = $"{sampling} x {sampling}", ["ShowAs"] = mode, ["XTilt"] = "3", ["YTilt"] = "-1" };
if (args.Length > 4) settings["ContourFormat"] = args[4];
var result = await application.Analyses.RunAsync(new(Guid.NewGuid(), 1, "Interferogram", settings) { UseGpuAcceleration = false });
Checkpoint("compute");
using var session = SafeHeadlessUnitTestSession.StartNew(typeof(ProbeApplication));
Checkpoint("headless_setup");
await session.Dispatch(() =>
{
    var tabs = (TabControl)typeof(AnalysisPanel).GetMethod("BuildResultContent", BindingFlags.Static | BindingFlags.NonPublic)!
        .Invoke(null, [result.View, result.SourceDocument, new DateTimeOffset(2026, 11, 27, 14, 0, 0, TimeSpan.FromHours(8)), null])!;
    tabs.SelectedIndex = tabIndex;
    Checkpoint("result_controls");
    var window = new Window { Width = 1200, Height = 900, Content = tabs };
    try
    {
        window.Show();
        Checkpoint("window_show");
        window.UpdateLayout();
        Checkpoint("layout");
        Dispatcher.UIThread.RunJobs();
        Checkpoint("dispatcher_jobs");
        AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        Checkpoint("first_frame");
        using var image = new RenderTargetBitmap(new PixelSize(1200, 900), new Vector(96, 96));
        image.Render(window);
        Checkpoint("bitmap_render");
        image.Save(Path.Combine(directory, "frame.png"), PngBitmapEncoderOptions.Default);
        Checkpoint("png_save");
        for (var index = 0; index < 3; index++)
        {
            image.Render(window);
            Checkpoint("repeat_frame_" + index);
        }
        if (args.Contains("churn", StringComparer.Ordinal))
        {
            var sizes = new[] { new Size(600, 400), new Size(1600, 900), new Size(800, 500), new Size(320, 240), new Size(1463, 866), new Size(1200, 900) };
            for (var index = 0; index < 18; index++)
            {
                var size = sizes[index % sizes.Length];
                window.Width = size.Width;
                window.Height = size.Height;
                if (index % 3 == 0)
                {
                    var replacement = (TabControl)typeof(AnalysisPanel).GetMethod("BuildResultContent", BindingFlags.Static | BindingFlags.NonPublic)!
                        .Invoke(null, [result.View, result.SourceDocument, new DateTimeOffset(2026, 11, 27, 14, 0, 0, TimeSpan.FromHours(8)), null])!;
                    replacement.SelectedIndex = index % 2;
                    window.Content = replacement;
                }
                window.UpdateLayout();
                Dispatcher.UIThread.RunJobs();
                AvaloniaHeadlessPlatform.ForceRenderTimerTick();
                image.Render(window);
                Checkpoint("resize_refresh_" + index);
            }
            GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
            Checkpoint("after_collection");
        }
    }
    finally { window.Close(); }
}, CancellationToken.None);

void Checkpoint(string stage)
{
    var record = JsonSerializer.Serialize(new { stage, milliseconds = watch.Elapsed.TotalMilliseconds,
        managedBytes = GC.GetTotalMemory(false), allocatedBytes = GC.GetTotalAllocatedBytes(false),
        sampling, mode, tabIndex, points = resultCount(), pid = Environment.ProcessId });
    Console.WriteLine(record);
    File.AppendAllText(Path.Combine(directory, "timing.jsonl"), record + Environment.NewLine);
    watch.Restart();
}
int resultCount() => result is null ? 0 : result.View.Series.FirstOrDefault()?.Points.Count ?? 0;

public sealed class ProbeApplication
{
    public static AppBuilder BuildAvaloniaApp() => AppBuilder.Configure<OpticalSystemDesign.App.App>()
        .UseSkia().UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false });
}
