using System.Text.Json;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Visualization;

var path = Path.GetFullPath("src/OpticalSystemDesign.App/Assets/SequentialExamples/Zoom systems/Zoom lens.zmx");
var optic = new ZemaxZmxImporter().ImportConfigurationSet(File.ReadAllText(path)).Configurations[0];
var options = new LayoutBuildOptions(RayCount: 0);
var before = new Layout2DBuilder(optic).Build3D(options: options);
var selected = before.LensElements[0].FrontSurfaceNumber;
foreach (var surface in optic.SurfaceGroup.Items)
    surface.CoordinateSystem = surface.CoordinateSystem with
    { Origin = surface.CoordinateSystem.Origin + new Vector3D(10, 0, 0) };
var after = new Layout2DBuilder(optic).Build3D(options: options);
static double CenterX(IReadOnlyList<Layout3DPoint> rim) => rim.Take(rim.Count - 1).Average(p => p.X);
var data = new
{
    Scope = "Read-only geometry diagnostic; imported Zoom, all surface frames translated +10 mm along global X, rays disabled. No Zemax numerical certification.",
    SurfaceNumber = selected,
    TranslationMillimeters = 10,
    Before = new
    {
        SurfaceRimCenterX = CenterX(before.Surfaces.Single(s => s.SurfaceNumber == selected).Rim),
        LensMeshRimCenterX = CenterX(before.LensElements[0].FrontRim)
    },
    After = new
    {
        SurfaceRimCenterX = CenterX(after.Surfaces.Single(s => s.SurfaceNumber == selected).Rim),
        LensMeshRimCenterX = CenterX(after.LensElements[0].FrontRim)
    }
};
var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
Console.WriteLine(json);
File.WriteAllText("artifacts/validation/viewer3d-audit-2026-10-22/translation-probe.json", json);
