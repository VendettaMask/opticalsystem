using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Web.Script.Serialization;
using System.Collections.Generic;
using ZOSAPI;
using ZOSAPI.Editors.MFE;
using ZOSAPI.SystemData;

internal static class Probe
{
    [STAThread]
    private static void Main(string[] args)
    {
        AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e)
        {
            var path = Path.Combine(args[0], new AssemblyName(e.Name).Name + ".dll");
            return File.Exists(path) ? Assembly.LoadFrom(path) : null;
        };
        Run(args);
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void Run(string[] args)
    {
        if (!ZOSAPI_NetHelper.ZOSAPI_Initializer.Initialize(args[0])) throw new InvalidOperationException("ZOSAPI initialization failed");
        var app = new ZOSAPI_Connection().CreateNewApplication();
        try
        {
            if (!app.IsValidLicenseForAPI || app.ZOSMajorVersion != 26 || app.ZOSMinorVersion != 1)
                throw new InvalidOperationException("A licensed OpticStudio 2026 R1 application is required");
            var system = app.PrimarySystem;
            var output = args[1];
            var list = new List<object>();
            foreach (var input in new[] { args[2], args[3], args[4], args[5] })
            {
                var id = Path.GetFileNameWithoutExtension(input);
                system.LoadFile(input, false);
                var initial = system.SystemData.Advanced.FNumMethod;
                foreach (FNumberComputationType method in Enum.GetValues(typeof(FNumberComputationType)))
                {
                    system.LoadFile(input, false);
                    system.SystemData.Advanced.FNumMethod = method;
                    var path = Path.Combine(output, id + "--" + method + ".zmx");
                    system.SaveAs(path);
                    system.LoadFile(path, false);
                    list.Add(new { id = id, input = input, file = path, initial = initial.ToString(), method = system.SystemData.Advanced.FNumMethod.ToString(),
                        efl = Operand(system, MeritOperandType.EFFL, 1), wfno = Operand(system, MeritOperandType.WFNO, 0),
                        expp = Operand(system, MeritOperandType.EXPP, 0), expd = Operand(system, MeritOperandType.EXPD, 0),
                        afocal = system.SystemData.Aperture.AFocalImageSpace });
                }
            }
            system.LoadFile(args[5], false);
            system.SystemData.Aperture.AFocalImageSpace = true;
            system.SaveAs(Path.Combine(output, "etalon-angular-control.zmx"));
            File.WriteAllText(Path.Combine(output, "readback.json"), new JavaScriptSerializer().Serialize(list));
        }
        finally { app.CloseApplication(); }
    }

    private static double Operand(IOpticalSystem system, MeritOperandType kind, int wave)
    {
        return system.MFE.GetOperandValue(kind, 0, wave, 0, 0, 0, 0, 0, 0);
    }
}

