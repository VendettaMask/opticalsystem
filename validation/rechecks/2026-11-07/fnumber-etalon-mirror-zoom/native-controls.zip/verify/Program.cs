using System.Globalization;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Workbench;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Configuration;

var root = args[0];
var rows = JsonFiles.Read<JsonElement>(Path.Combine(root, "study-final", "rows.json")).EnumerateArray().ToArray();
var output = Path.Combine(root, "supplement");
var nativeRoot = Path.Combine(root, "native");
var scopedPolicy = ComparisonConfiguration.Load("validation/zemax/2026-r1/afocal-repair-2026-10-24/captures/scoped-policy.json");
var mirrorNativeOnly = args.Contains("--mirror-native-only");
foreach (var index in args.Skip(1).Where(a => !a.StartsWith("--")).Select(int.Parse))
{
    var row = rows.Single(item => item.GetProperty("index").GetInt32() == index);
    var baseJob = JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
    var original = baseJob.Request;
    var entry = AnalysisComparisonRegistry.Get(original.CanonicalAnalysisKey);
    var config = row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
    var dir = Path.Combine(output, index.ToString(CultureInfo.InvariantCulture));
    Directory.CreateDirectory(dir);
    var items = new List<object>();
    var native = new Dictionary<string, NumericResult>();
    var local = new Dictionary<string, NumericResult>();
    var report = Path.Combine(row.GetProperty("legacyPath").GetString()!, "native", "data.json");
    var frozen = ResultNormalizer.Zemax(report, entry, original);
    foreach (var folder in Directory.GetDirectories(nativeRoot).Where(path => Path.GetFileName(path).StartsWith(index + "-")).Order())
    {
        var id = Path.GetFileName(folder);
        if (!File.Exists(Path.Combine(folder, "captured-settings.json"))) continue;
        var nreq = JsonFiles.Read<JsonElement>(Path.Combine(nativeRoot, "requests", id + ".json"));
        var n = nreq.GetProperty("pupilSampling").GetInt32();
        var angular = id.Contains("-angular", StringComparison.Ordinal);
        var curve = original.CanonicalAnalysisKey == "FFT PSF Cross Section";
        var nativeOnly = mirrorNativeOnly || (index is 2203 or 2212) && !angular;
        var nativeMode = id.Contains("-PupilSizePosition-", StringComparison.Ordinal) || id.Contains("-TracingRays-", StringComparison.Ordinal);
        var settings = new Dictionary<string, string>(original.WorkbenchSettings);
        var size = n.ToString(CultureInfo.InvariantCulture);
        foreach (var key in new[] { "Sampling", "PupilSampling", "NumRays" })
            if (settings.ContainsKey(key)) settings[key] = size;
        if (curve && settings.ContainsKey("ImageSampling")) settings["ImageSampling"] = size;
        var req = original with { PupilSampling = n, ImageSampling = nreq.GetProperty("imageSampling").GetInt32(),
            WorkbenchSettings = settings, ImageSpaceAfocal = angular, NativeAfocalAngleUnit = angular ? "Milliradian" : null };
        var readback = JsonFiles.Read<JsonElement>(Path.Combine(folder, "captured-settings.json"));
        var diagnostic = JsonFiles.Read<JsonElement>(Path.Combine(folder, "result-diagnostics.json"));
        if (diagnostic.GetProperty("messages").GetArrayLength() != 0)
        {
            items.Add(new { id, stage = "native", error = diagnostic.GetProperty("messages").GetRawText() });
            continue;
        }
        try
        {
            native[id] = ResultNormalizer.Zemax(Path.Combine(folder,"data.json"), entry, req);
            items.Add(new { id, stage = "native-readback", settings = readback.GetProperty("properties"), selectors = readback.GetProperty("selectors") });
        }
        catch (Exception ex) { items.Add(new { id, stage = "native", error = ex.Message }); }
        if (nativeOnly) continue;
        var runDir = Path.Combine(dir, id);
        Directory.CreateDirectory(runDir);
        try
        {
            var job = baseJob with { Request = req, OutputDirectory = runDir };
            if (nativeMode || angular)
            {
                var variants = await WorkbenchExecutor.Import(nreq.GetProperty("input").GetString()!);
                var optic = variants.Configurations[original.Configuration - 1];
                if (angular != optic.ImageSpaceAfocal || (id.Contains("-PupilSizePosition-") != optic.UseExitPupilFNumber))
                    throw new InvalidDataException("Imported mode differs from the native control.");
                var snap = Path.Combine(runDir, "optic.json");
                JsonFiles.Write(snap, optic.ToSnapshot());
                job = job with { SnapshotPath = snap };
            }
            WorkbenchExecutor.Execute(job);
            var dataPath = Path.Combine(runDir,"data.json");
            var raw = JsonFiles.Read<JsonElement>(dataPath);
            if (raw.GetProperty("outcome").GetString() != "Success")
                throw new InvalidDataException(raw.GetProperty("outcomeReason").GetString());
            local[id] = ResultNormalizer.Workbench(dataPath, entry, req);
            var values = raw.GetProperty("values");
            if (values.TryGetProperty("WorkingFNumber", out var f)) items.Add(new { id, stage = "core-scale", value = f,
                pitch = values.TryGetProperty("ImageDeltaMicrometers", out var pitch) ? pitch : default });
            if (native.TryGetValue(id, out var nativeData)) Compare(id + "-same-sampling", local[id], nativeData, req);
        }
        catch (Exception ex) { items.Add(new { id, stage = "core", error = ex.Message }); Console.WriteLine($"{id} Core: {ex.Message}"); }
    }
    if (index is 2766 or 2769 or 2770 or 2773 or 2858)
    {
        var anchor = $"{index}-32";
        Compare("native-recapture-original", native[anchor], frozen, original);
        if (mirrorNativeOnly)
            foreach (var edge in new[] { "smaller", "larger" })
                Compare("mce-" + edge + "-vs-frozen", native[$"{index}-mce-{edge}-32"], frozen, original);
        foreach (var n in new[] {64, 128, 256, 512, 1024, 2048})
        {
            var a = $"{index}-{n/2}"; var b = $"{index}-{n}";
            if (native.ContainsKey(a) && native.ContainsKey(b))
                Compare($"native-{n/2}-{n}", native[b], native[a], original, original.CanonicalAnalysisKey == "FFT PSF Cross Section");
            if (local.TryGetValue(a, out var lower) && local.TryGetValue(b, out var upper))
                Compare($"core-{n/2}-{n}", upper, lower, original, original.CanonicalAnalysisKey == "FFT PSF Cross Section");
        }
    }
    if (index == 559)
    {
        Compare("core-pupil-512-vs-native-1024", local["559-PupilSizePosition-512"], native["559-PupilSizePosition-1024"], original, true);
        Compare("native-pupil-512-1024", native["559-PupilSizePosition-512"], native["559-PupilSizePosition-1024"], original, true);
    }
    if (index == 2203)
    {
        var request = original with { ImageSpaceAfocal = true, NativeAfocalAngleUnit = "Milliradian" };
        Compare("focal-native-64-256", native["2203-focal-256"], native["2203-focal-64"], original);
        Compare("angular-native-128-256", native["2203-angular-256"], native["2203-angular-128"], request);
        var angular = native["2203-angular-256"];
        const double cutoffCyclesPerMilliradian = 10 / .9999;
        var ideal = angular with { Series = angular.Series.Select(s => s with { Y = s.X.Select(f =>
        {
            var q = Math.Clamp(Math.Abs(f) / cutoffCyclesPerMilliradian, 0, 1);
            return 2 / Math.PI * (Math.Acos(q) - q * Math.Sqrt(1 - q * q));
        }).ToArray() }).ToList() };
        Compare("angular-circular-pupil-analytic", ideal, angular, request);
    }
    JsonFiles.Write(Path.Combine(dir,mirrorNativeOnly ? "native-only.json" : "results.json"), items);
    void Compare(string id, NumericResult candidate, NumericResult reference, CanonicalAnalysisRequest req, bool fixedWindow = false)
    {
        if (fixedWindow) { candidate = Clip(candidate); reference = Clip(reference); }
        var applied = config;
        if (req.ImageSpaceAfocal && scopedPolicy.Analyses.GetValueOrDefault(req.CanonicalAnalysisKey)?.AfocalQuantities is { } afocal)
            applied = config with { AfocalQuantities = afocal };
        var run = new AnalysisRun { Key = req.CanonicalAnalysisKey, Directory = id, Request = req };
        ComparisonRunner.Compare(run, entry, applied, candidate, reference, dir);
        Console.WriteLine($"{index} {id} {run.Conclusion} " + string.Join(" ", run.Metrics.Select(m => $"{m.Id}:{m.Nrmse:G6}/{m.MaxAbsolute:G6}/{m.Coverage:G4}")));
        items.Add(new { id, run.Conclusion, run.Reason, run.Metrics, fixedWindow });
    }
    NumericResult Clip(NumericResult data) => data with { Series = data.Series.Select(series =>
    {
        var frozenAxis = frozen.Series.Single(s => s.Id == series.Id).X;
        var minimum = frozenAxis.Min(); var maximum = frozenAxis.Max();
        var points = series.X.Zip(series.Y).OrderBy(p => p.First).ToArray();
        if (points[0].First > minimum || points[^1].First < maximum)
            throw new InvalidDataException("Refined profile does not cover the frozen physical interval.");
        var trimmed = points.Where(p => p.First > minimum && p.First < maximum)
            .Prepend((First: minimum, Second: Interpolate(minimum))).Append((First: maximum, Second: Interpolate(maximum))).ToArray();
        return series with { X = trimmed.Select(p => p.First).ToArray(), Y = trimmed.Select(p => p.Second).ToArray() };
        double Interpolate(double x)
        {
            var hi = Array.FindIndex(points, p => p.First >= x);
            if (points[hi].First == x) return points[hi].Second;
            var (a, b) = (points[hi-1],points[hi]);
            return a.Second + (x-a.First)*(b.Second-a.Second)/(b.First-a.First);
        }
    }).ToList() };
}

