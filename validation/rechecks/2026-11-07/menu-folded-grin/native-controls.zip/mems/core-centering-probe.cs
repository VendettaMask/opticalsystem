using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Serialization;
using OpticalSystemDesign.ZemaxComparison;
var optic=Optic.FromSnapshot(JsonFiles.Read<OpticSnapshot>(args[0]));
var wave=optic.Wavelengths[0]; var field=(0d,0d);
var compute=typeof(DiffractionEngine).GetMethod("ComputeFocusedHuygensPsf",BindingFlags.NonPublic|BindingFlags.Static)!;
var all=new List<object>();
foreach(var n in new[]{32,64,128})
{
 var centroid=DiffractionEngine.HuygensGeometricCenterOffset(optic,field,[wave],wave,n,false);
 foreach(var useCentroid in new[]{false,true})
 foreach(var spherical in new[]{false,true})
 {
  var result=(PsfResult)compute.Invoke(null,new object?[]{optic,field,wave,n,32,.00025,false,wave,useCentroid?centroid:null,spherical,false,null})!;
  var vals=result.Values.Cast<double>().Select(x=>x/100).ToArray();
  var mtf=DiffractionEngine.ComputePsfMtfAtFrequencies(result,[50]);
  all.Add(new{n,useCentroid,spherical,cx=centroid.X,cy=centroid.Y,mtfT=mtf.Tangential[0],mtfS=mtf.Sagittal[0],vals});
 }
}
Console.WriteLine(JsonSerializer.Serialize(all));
