import math,re,json,sys
from pathlib import Path
root=Path(sys.argv[1]);base=root/'reflective-grin-native'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def real_rows(path):
    text=path.read_text(encoding='utf-16')
    rows={}
    for line in text.splitlines():
        m=re.match(r'^\s*([1-6])\s+(\S.*)',line)
        if m and (s:=int(m.group(1))) not in rows:
            fields=m.group(2).split()
            if len(fields)>=11:
                try:rows[s]=[float(v) for v in fields[:11]]
                except ValueError:pass
    return rows
wave=.55
k=.4785+.007157/wave**2+.0003749/wave**4
data={}
for step in ('0.1','0.01','0.001'):
    items=[]
    for folder in sorted(base.glob(f'ray-{step}-*')):
        s=real_rows(folder/'data.txt')
        x,y,z=s[3][:3]
        x2,y2,z2=s[4][:3]
        ratio=1-.5*k*k*(x*x+y*y)
        pred=math.degrees(math.asin(ratio*math.sin(math.radians(s[3][9]))))
        error=abs(pred-s[4][9])
        assert error<2e-7
        assert math.dist((x,y,z),(x2,y2,z2))<1e-9
        req=load(base/'requests'/f'{folder.name}.json')['zemaxSettings']
        items.append(dict(pupil=[req['Px'],req['Py']],relativeIndex=ratio,mirrorIncidenceDegrees=s[3][9],
            returnBoundaryIncidenceDegrees=s[4][9],predictedReturnBoundaryIncidenceDegrees=pred,absoluteErrorDegrees=error))
    assert len(items)==3
    eff=load(base/f'first-order-{step}'/'model-controls.json')
    scalars={row['input']['code']:row['value'] for row in eff['rows']}
    data[step]={'boundaryControls':items,'firstOrder':scalars}
print([(s,v['firstOrder']['EFFL'],max(x['absoluteErrorDegrees'] for x in v['boundaryControls'])) for s,v in data.items()])
(root/'reflective-grin.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
