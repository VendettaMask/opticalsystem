import json,math,sys
from pathlib import Path
root,study=map(Path,sys.argv[1:])
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
batch=root/'native-arcs'
series={}
for s in read(batch/'stations.json'):
    p=batch/s['id']
    environment=read(p/'environment.json')
    values=read(p/'model-controls.json')['rows']
    bywave={(r['input']['int2'],r['input']['code']):r['value'] for r in values}
    for wave in sorted({key[0] for key in bywave}):
        x,y,z,l,m,n=(bywave[wave,k] for k in ('REAX','REAY','REAZ','REAA','REAB','REAC'))
        assert abs(z)<1e-10 and n>0 and abs(l*l+m*m+n*n-1)<1e-10
        series.setdefault((s['case'],s['step'],wave),[]).append((s['z'],x,y,l,m,n))
def arc(series,stride):
    return sum(math.dist(a[:3],b[:3]) for a,b in zip(series[::stride],series[stride::stride]))
results={}
for index,case,wave in ((520,'selfoc',2),(537,'selfoc',1),(541,'selfoc',2),(545,'selfoc',3),(826,'interconnect',1),(843,'interconnect',1)):
    fine=series[case,.0005,wave]; coarse=series[case,.001,wave]
    core=next(row for row in read(study/'analyses'/f'{index:04}'/'data.json')['values']['RealRayData'] if row[0]==2)[11]
    coarseError=max(math.dist(a[:3],b[:3]) for a,b in zip(coarse,fine[::8]))
    chords={32//s:arc(fine,s) for s in (4,2,1)}
    reference=(4*chords[32]-chords[16])/3
    preceding=(4*chords[16]-chords[8])/3
    gate=1e-6+1e-6*abs(reference)
    passed=max(abs(reference-preceding),abs(core-reference),coarseError)<gate; print(index,reference,preceding,coarseError,core,gate)
    results[index]=dict(lens=case,wavelengthNumber=wave,normalizedHx=0,normalizedHy=0,normalizedPx=0,normalizedPy=.8,
        coreArcMm=core,nativeExtrapolatedArcMm=reference,nativeChordSumsMm=chords,
        absCoreErrorMm=abs(core-reference),extrapolationDeltaMm=abs(reference-preceding),
        sharedDepthMaximumInterceptErrorMm=coarseError,coordinateToleranceMm=gate,independentArcConclusion='Pass' if passed else 'Difference',builtInReportStillMissing=True)
print('\n'.join(f"{i} {r['coreArcMm']:.10f} {r['nativeExtrapolatedArcMm']:.10f} error={r['absCoreErrorMm']:.3g}" for i,r in results.items()))
(root/'arcs.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')



