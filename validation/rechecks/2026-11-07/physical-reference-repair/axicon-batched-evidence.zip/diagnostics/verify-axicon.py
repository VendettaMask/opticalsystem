import hashlib
import json
import math
import pathlib
import re
import zipfile
import sys

root = pathlib.Path(sys.argv[1])
base = pathlib.Path('artifacts/validation/pq1107/full')
refs = pathlib.Path('validation/rechecks/2026-11-07')
previous = refs/'residual-reference-followup'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
row = load(base/'rows.json')[949]
policy = row['settings']['quantities']['Irradiance']
wb = lambda p: load(p)['plotSeries'][0]['points']
core = wb(base/'analyses/0950/data.json')
assert core == wb(root/'n32/wb/data.json')
rows = []
with zipfile.ZipFile(refs/'dense-huygens-conic/numeric-controls.zip') as earlier:
    for sampling in (1024,2048,4096):
        folder = f'native/950-{sampling}'
        if sampling==4096:
            native_report = (previous/folder/'data.txt').read_bytes()
            native_readback = (previous/folder/'captured-settings.json').read_bytes()
        else:
            native_report = earlier.read(folder+'/data.txt')
            native_readback = earlier.read(folder+'/captured-settings.json')
        capture = json.loads(native_readback)
        directory = root/f'n{sampling}'/'wb'
        job = load(directory.parent/'request.json')
        settings = job['request']['zemaxSettings']
        assert all(capture['properties'][k] == settings[k] for k in capture['properties'])
        assert capture['selectors']=={'Field':job['request']['field'],'Wavelength':job['request']['wavelength']}
        assert capture['properties']['PupilSampleSize']==f'S_{sampling}x{sampling}'
        text = native_report.decode('utf-16')
        pattern = r'^\s*(\d+)\s+([+-]?\d+\.\d+)\s+([+-]?\d+\.\d+)\s*$'
        parsed = [(int(i),float(x),float(y)) for i,x,y in re.findall(pattern,text,re.MULTILINE)]
        assert len(parsed)==33 and [i for i,*_ in parsed]==list(range(33))
        native = {x:y for _,x,y in parsed}
        analysis = load(directory/'data.json')
        measured = analysis['plotSeries'][0]
        assert measured['xUnit']=='Micrometer' and measured['yQuantity']=='Irradiance'
        values = analysis['values']
        assert analysis['outcome']=='Success' and values['PupilSampling']==sampling
        assert values['GridSize']==32 and values['PixelPitchMicrometers']==.25
        assert values['ImageExtentMicrometers']==8 and values['CenterReference']=='Chief ray'
        assert values['UsePolarization']==values['Normalized']==False
        actual = {p['x']:p['y'] for p in measured['points']}
        assert len(actual)==32 and actual.keys()<=native.keys()
        differences = {x:abs(y-native[x]) for x,y in actual.items()}
        assert min(actual)==-4 and max(actual)==3.75 and max(native)==4
        assert all(differences[x]<=policy['absolute']+policy['relative']*abs(native[x]) for x in actual)
        coverage = (max(actual)-min(actual))/(max(native)-min(native))
        assert coverage>=policy['minimumCoverage'] and max(differences.values())<.5e-6
        control = load(previous/f'axicon-line-{sampling}.json')
        old = dict(zip(control['x'],control['y']))
        pairs = list(zip(sorted(old.items()), sorted(actual.items()), strict=True))
        assert all(abs(x-z)<1e-12 for (x,_),(z,_) in pairs)
        same_phase_math = max(abs(a-b) for (_,a),(_,b) in pairs)
        assert same_phase_math<1e-13
        provenance = load(directory/'provenance.json')
        rows.append(dict(pupilSampling=sampling, imageSampling=32, imageDeltaMicrometers=.25,
            requestFingerprint=provenance['requestFingerprint'], snapshotSha256=provenance['snapshotSha256'],
            applicationAndCoreSha256=provenance['codeFingerprint'], coreOutputSha256=sha((directory/'data.json').read_bytes()),
            nativeReportSha256=sha(native_report),nativeSettingsSha256=sha(native_readback),
            nativeReportSource=previous.as_posix()+'/'+folder+'/data.txt' if sampling==4096 else
                (refs/'dense-huygens-conic/numeric-controls.zip').as_posix()+'::'+folder+'/data.txt',
            nativeTextDecimals=6, comparedPoints=len(differences), nativePoints=len(native), physicalCoverage=coverage,
            maximumAbsoluteNativeError=max(differences.values()), absolutePointGatePass=True,
            maximumAbsoluteDifferenceFromIndependentFiniteSum=same_phase_math,
            corePeakStrehl=values['PeakStrehlRatio'], coreCenterStrehl=values['StrehlRatio'],
            coreCentroidXMicrometers=values['CentroidXMicrometers'],coreCentroidYMicrometers=values['CentroidYMicrometers'],
            nativeTextPeak=max(native.values()),work=values['SummationChecks']))
result=dict(frozenIndex=950, frozenSettingsPreserved=True, original32PublishedPointsEqual=True, threshold=policy,
    nativeReferencePolicy='Original capture reused, six-decimal text, common physical range only',
    samplingConvergenceEstablished=False, rows=rows)
(root/'axicon-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print([(r['pupilSampling'],r['maximumAbsoluteNativeError'],r['maximumAbsoluteDifferenceFromIndependentFiniteSum']) for r in rows])


