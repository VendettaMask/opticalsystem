using System.Globalization;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var root = args[0];
var prior = args[1];
var rows = JsonFiles.Read<JsonElement>(Path.Combine(root, "study-final", "rows.json")).EnumerateArray().ToArray();
var supplement = Path.Combine(root, "supplement");
var nativeRoot = Path.Combine(root, "native");
var scopedPolicy = ComparisonConfiguration.Load("validation/zemax/2026-r1/afocal-repair-2026-10-24/captures/scoped-policy.json");
var indices = args.Length > 2 ? new[] { int.Parse(args[2], CultureInfo.InvariantCulture) } : new[] {1082, 2745, 2754, 608, 698, 2208, 2216, 2220, 2770};
foreach (var index in indices)
{
    var row = rows.Single(item => item.GetProperty("index").GetInt32() == index);
    var job = JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
    var original = job.Request;
    var entry = AnalysisComparisonRegistry.Get(original.CanonicalAnalysisKey);
    var config = row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
    var dir = Path.Combine(supplement, index.ToString(CultureInfo.InvariantCulture));
    Directory.CreateDirectory(dir);
    var items = new List<object>();
    var native = new Dictionary<string, (NumericResult Data, CanonicalAnalysisRequest Request)>();
    var local = new Dictionary<string, NumericResult>();
    var frozen = ResultNormalizer.Zemax(Path.Combine(row.GetProperty("legacyPath").GetString()!, "native", "data.json"), entry, original);
    foreach (var folder in Directory.GetDirectories(nativeRoot).Where(path => Path.GetFileName(path).StartsWith(index + "-")).Order())
    {
        var id = Path.GetFileName(folder);
        var readbackPath = Path.Combine(folder, "captured-settings.json");
        if (!File.Exists(readbackPath)) continue;
        var nreq = JsonFiles.Read<JsonElement>(Path.Combine(nativeRoot, "requests", id + ".json"));
        var n = nreq.GetProperty("pupilSampling").GetInt32();
        var angular = id.Contains("-angular-", StringComparison.Ordinal) || id.Contains("-afocal-", StringComparison.Ordinal);
        var modeEquivalent = id.EndsWith("-mode0") || id.EndsWith("-mode3");
        var nativeOnly = index is 1082 or 2754 or 2770 || index == 2208 && (!angular || n > 512);
        var settings = new Dictionary<string, string>(original.WorkbenchSettings);
        var size = n.ToString(CultureInfo.InvariantCulture);
        foreach (var key in new[] { "Sampling", "PupilSampling", "NumRays" })
            if (settings.ContainsKey(key)) settings[key] = size;
        if (settings.ContainsKey("NumberOfRays")) settings["NumberOfRays"] = nreq.GetProperty("rayCount").GetInt32().ToString(CultureInfo.InvariantCulture);
        var req = original with { PupilSampling = n, RayCount = nreq.GetProperty("rayCount").GetInt32(),
            ImageSampling = nreq.GetProperty("imageSampling").GetInt32(), WorkbenchSettings = settings,
            ImageSpaceAfocal = angular, NativeAfocalAngleUnit = angular ? "Milliradian" : null };
        var readback = JsonFiles.Read<JsonElement>(readbackPath);
        var diagnostic = JsonFiles.Read<JsonElement>(Path.Combine(folder, "result-diagnostics.json"));
        if (diagnostic.GetProperty("messages").GetArrayLength() != 0)
        {
            items.Add(new { id, stage = "native", error = diagnostic.GetProperty("messages").GetRawText() });
            continue;
        }
        try
        {
            native[id] = (ResultNormalizer.Zemax(Path.Combine(folder, "data.json"), entry, req), req);
            items.Add(new { id, stage = "native-readback", settings = readback.GetProperty("properties"), selectors = readback.GetProperty("selectors") });
        }
        catch (Exception e) { items.Add(new { id, stage = "native", error = e.Message }); Console.WriteLine($"{id} Native: {e.Message}"); }
        if (nativeOnly) continue;
        var runDir = Path.Combine(dir, id);
        Directory.CreateDirectory(runDir);
        try
        {
            var localJob = job with { Request = req, OutputDirectory = runDir };
            var path = nreq.GetProperty("input").GetString()!;
            if (!modeEquivalent && (angular || id.Contains("-absolute-") || index == 2745 && !id.Contains("-actual-")))
            {
                var optics = await WorkbenchExecutor.Import(path);
                var snap = Path.Combine(runDir, "optic.json");
                JsonFiles.Write(snap, optics.Configurations[original.Configuration - 1].ToSnapshot());
                localJob = localJob with { SnapshotPath = snap };
            }
            WorkbenchExecutor.Execute(localJob);
            var pathData = Path.Combine(runDir, "data.json");
            var actual = JsonFiles.Read<JsonElement>(pathData);
            if (actual.GetProperty("outcome").GetString() != "Success")
                throw new InvalidDataException(actual.GetProperty("outcomeReason").GetString());
            local[id] = ResultNormalizer.Workbench(pathData, entry, req);
            if (native.TryGetValue(id, out var z)) Compare(id + "-core-vs-native", local[id], z.Data, req);
        }
        catch (Exception e) { items.Add(new { id, stage = "core", error = e.Message }); Console.WriteLine($"{id} Core: {e.Message}"); }
    }
    if (index is 1082 or 2754) Compare("native-recapture-vs-frozen", native[$"{index}-recapture"].Data, frozen, original);
    if (index == 2745)
    {
        CompareNative("actual-64", "actual-128"); CompareNative("actual-128", "actual-256");
    }
    if (index is 608 or 698)
    {
        CompareNative("mode0", "mode3"); CompareNative("focal-20", "focal-80");
    }
    if (index == 2208)
    {
        CompareNative("focal-32", "focal-128"); CompareNative("angular-128", "angular-256"); CompareNative("angular-256", "angular-512"); CompareNative("angular-512", "angular-1024");
        if (local.TryGetValue("2208-angular-512", out var dense) && native.TryGetValue("2208-angular-1024", out var reference))
            Compare("core-512-vs-native-1024", dense, reference.Data, reference.Request);
    }
    if (index == 2770 && native.TryGetValue("2770-4096", out var high))
    {
        var previous = ResultNormalizer.Zemax(Path.Combine(prior, "native", "2770-2048", "data.json"), entry, high.Request);
        Compare("native-2048-4096", high.Data, previous, high.Request);
    }
    JsonFiles.Write(Path.Combine(dir, "results.json"), items);

    void CompareNative(string a, string b)
    {
        if (native.TryGetValue($"{index}-{a}", out var one) && native.TryGetValue($"{index}-{b}", out var two))
            Compare($"native-{a}-vs-{b}", two.Data, one.Data, two.Request);
    }
    void Compare(string id, NumericResult candidate, NumericResult reference, CanonicalAnalysisRequest req)
    {
        var policy = config;
        if (req.ImageSpaceAfocal && scopedPolicy.Analyses.GetValueOrDefault(req.CanonicalAnalysisKey)?.AfocalQuantities is { } afocal)
            policy = config with { AfocalQuantities = afocal };
        var run = new AnalysisRun { Key = req.CanonicalAnalysisKey, Directory = id, Request = req };
        ComparisonRunner.Compare(run, entry, policy, candidate, reference, dir);
        Console.WriteLine($"{index} {id} {run.Conclusion} " + string.Join(" ", run.Metrics.Select(m => $"{m.Id}:{m.Nrmse:G6}/{m.MaxAbsolute:G6}/{m.Coverage:G4}")));
        items.Add(new { id, run.Conclusion, run.Reason, run.Metrics });
    }
}
