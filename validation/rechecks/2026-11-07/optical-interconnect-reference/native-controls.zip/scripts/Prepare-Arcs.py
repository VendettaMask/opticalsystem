import hashlib,json,re,sys
from pathlib import Path
root,first=map(Path,sys.argv[1:])
repo=Path('artifacts/zemax-sequential-corpus/20261021/full-v1')
path=repo/'sources/Interconnects/Optical interconnect.ZMX'
original=path.read_text(encoding='utf-16')
template=json.loads((first/'requests/original.json').read_text(encoding='utf-8-sig'))
exit_sag=-.0038851685822
jobs=[];manifest=[]
def cut(src,exit,gradient,length):
    pattern=rf'(?m)(^SURF {gradient}\s*$[\s\S]*?^  DISZ )[\d.eE+\-]+'
    src,count=re.subn(pattern,lambda m:m[1]+format(length,'.17g'),src)
    assert count==1
    return re.split(rf'(?m)^SURF {exit}\s*$',src,maxsplit=1)[0]+f'SURF {exit}\n  TYPE STANDARD\n  CURV 0\n  DISZ 0\n  DIAM 2 0 0 0 1 ""\n'
def add(leg,step,k):
    name=f'{leg}-{step}-{k:02d}'
    source=original.replace('PARM 1 1.00E-01',f'PARM 1 {step}')
    fraction=k/32
    if leg=='forward':
        if k==0: surface,z=2,0.
        elif k==32: surface,z=3,2.6
        else:
            surface,z=3,(2.6+exit_sag)*fraction
            source=cut(source,surface,2,z)
    else:
        if k==0: surface,z=4,0.
        elif k==32: surface,z=5,-2.6
        else:
            surface,z=5,exit_sag+(-2.6-exit_sag)*fraction
            source=cut(source,surface,4,z)
    model=root/(name+'.ZMX');model.write_text(source,encoding='utf-16')
    def operand(code,s):return dict(code=code,int1=s,int2=1,data1=0,data2=1,data3=0,data4=.8,data5=0,data6=0)
    q=dict(template,input=str(model),inputSha256=hashlib.sha256(model.read_bytes()).hexdigest(),
        modelOperands=[operand(c,s) for s in sorted({2,surface}) for c in ('REAX','REAY','REAZ','REAB')])
    request=root/'requests'/(name+'.json');request.write_text(json.dumps(q),encoding='utf-8')
    jobs.append(dict(id=name,request=str(request),output=str(root/name)))
    manifest.append(dict(id=name,leg=leg,step=step,k=k,surface=surface,vertexZ=z))
for leg in ('forward','backward'):
    for step,points in ((.001,range(0,33,4)),(.0005,range(33))):
        for k in points:add(leg,step,k)
(root/'jobs.json').write_text(json.dumps(jobs),encoding='utf-8')
(root/'stations.json').write_text(json.dumps(manifest),encoding='utf-8')
