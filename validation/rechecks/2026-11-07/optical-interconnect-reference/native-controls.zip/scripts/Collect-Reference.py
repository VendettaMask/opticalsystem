import json,math,sys
from pathlib import Path
root=Path(sys.argv[1]); folder=root/'native-first-order'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def get(path,key):
    rows=read(path/'model-controls.json')['rows']
    return {key(r['input']):r['value'] for r in rows}
source=read(root/'scope-axial/results.json')
metric=next(m for r in source if r['index']==847 for m in r['metrics'] if m['id']=='EffectiveFocalLength')
core=metric['extra']['workbench']
gate=1e-8+1e-6*abs(core)
original={}
for step in ('frozen','fine'):
    rays=get(folder/f'original-rays-{step}',lambda r:(r['code'],r['int1'],r['data2']))
    points=[]
    for hy in sorted({k[2] for k in rays}):
        y=rays['REAY',2,hy]; output=rays['REAB',6,hy]
        angle=rays['REAB',1,hy]
        assert abs(y-.2*hy)<1e-12 and abs(angle)<1.1e-9
        points.append(dict(hy=hy,entranceHeightMm=y,incomingDirectionCosine=angle,outputDirectionCosine=output,focalLengthMm=y/abs(output)))
    def extrap(a,b):
        return (b['entranceHeightMm']**2*a['focalLengthMm']-a['entranceHeightMm']**2*b['focalLengthMm'])/(b['entranceHeightMm']**2-a['entranceHeightMm']**2)
    v=extrap(points[0],points[1]); next_=extrap(points[1],points[2])
    assert abs(v-core)<=gate and abs(v-next_)<=gate
    original[step]=dict(points=points,extrapolatedFocalLengthMm=v,absoluteErrorMm=abs(v-core),adjacentHeightExtrapolationDeltaMm=abs(v-next_))
assert abs(original['frozen']['extrapolatedFocalLengthMm']-original['fine']['extrapolatedFocalLengthMm'])<=gate
collimated={}
for f in sorted(f for f in folder.glob('collimated-*') if f.is_dir()):
    v=get(f,lambda r:(r['code'],r['int1'],r['data4']))
    q={str(x):v['REAY',2,x]/abs(v['REAB',6,x]) for x in (.001,.01,.1,.5,1.)}
    collimated[f.name.removeprefix('collimated-')]=dict(reportedEffectiveFocalLengthMm=v['EFFL',0,0],independentFocalLengthMmByNormalizedPupil=q)
clean=collimated['0.002']['independentFocalLengthMmByNormalizedPupil']['0.001']
assert abs(clean-core)<=gate and abs(clean-original['fine']['extrapolatedFocalLengthMm'])<=gate
finite={}
for f in sorted(f for f in folder.glob('finite-na-*') if f.is_dir()):
    v=get(f,lambda r:(r['code'],r['int1']))
    finite[f.name.removeprefix('finite-na-')]=v['EFFL',0]
data=dict(index=847,frozenReportMm=metric['extra']['zemax'],coreMm=core,originalToleranceMm=gate,originalNearAxisControls=original,
    collimatedControls=collimated,finiteNumericalApertureReportedEflMm=finite,convergenceChecked='Pass',frozenVerdict='Difference')
(root/'first-order.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(core,original['frozen']['extrapolatedFocalLengthMm'],original['fine']['extrapolatedFocalLengthMm'],clean,gate)
f=root/'native-field'; rows=[read(f/n/'data.json')['dataSeries'][0] for n in ('original','two-fields-1','two-fields-2')]
selectors=[read(f/n/'captured-settings.json')['selectors'] for n in ('original','two-fields-1','two-fields-2')]
assert [x['ReferenceField'] for x in selectors]==[1,1,2] and all(r['x']==rows[0]['x'] and r['y']==rows[0]['y'] for r in rows)
(root/'field-reference.json').write_text(json.dumps(dict(readback=selectors,sampleCount=len(rows[0]['x']),allFiveColumnsIdentical=True,maximumReportedDistortionPercent=rows[0]['y'][-1][-1]),indent=2)+'\n',encoding='utf-8')

