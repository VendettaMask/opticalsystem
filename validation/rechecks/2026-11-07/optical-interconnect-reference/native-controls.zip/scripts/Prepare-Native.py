import hashlib,json,re,sys
from pathlib import Path
root,prior=map(Path,sys.argv[1:])
base=Path('artifacts/zemax-sequential-corpus/20261021/full-v1')
original=(base/'sources/Interconnects/Optical interconnect.ZMX').read_text(encoding='utf-16')
template=json.loads((prior/'reflective-grin-native/requests/first-order-0.001.json').read_text(encoding='utf-8-sig'))
jobs=[]
def surface_edit(src,n,pat,value):
    span=re.search(r'(?m)^SURF '+str(n)+r'\s*$[\s\S]*?(?=^SURF |\Z)',src)
    assert span
    body,count=re.subn(pat,value,span[0],flags=re.M)
    assert count==1,(n,pat,span[0][:100])
    return src[:span.start()]+body+src[span.end():]
def add(name,source,queries):
    file=root/(name+'.ZMX');file.write_text(source,encoding='utf-16')
    p=root/'requests'/(name+'.json')
    obj=dict(template,input=str(file),inputSha256=hashlib.sha256(file.read_bytes()).hexdigest(),modelOperands=queries)
    p.write_text(json.dumps(obj),encoding='utf-8')
    jobs.append(dict(id=name,request=str(p),output=str(root/name)))
def operand(code,s=0,py=0,hy=0):return dict(code=code,int1=s,int2=1,data1=0,data2=hy,data3=0,data4=py,data5=0,data6=0)
basic=[operand(c) for c in ('EFFL','EXPD','EXPP')]+[operand('INDX',i) for i in range(1,6)]
fine=original.replace('PARM 1 1.00E-01','PARM 1 0.001')
add('original',fine,basic)
for na in (.002,.02,.1,.2,.4):
    p=re.sub(r'^OBNA .*$',f'OBNA {na} 0',fine,flags=re.M)
    add(f'finite-na-{na}',p,basic)
ax=surface_edit(fine,0,r'^  DISZ [^\n]+','  DISZ INFINITY')
ax=surface_edit(ax,1,r'^  DISZ [^\n]+','  DISZ 0')
ax=re.sub(r'^FTYP 1 (.*)$',r'FTYP 0 \1',ax,flags=re.M)
ax=re.sub(r'^YFLN .+$','YFLN 0',ax,flags=re.M)
for diameter in (.002,.02,.1,.2,.4,.5,1.,2.):
    lens=re.sub(r'^OBNA .+$',f'ENPD {diameter}',ax,flags=re.M)
    add(f'collimated-{diameter}',lens,basic+[operand(c,s,py) for py in (.001,.01,.1,.5,1)
        for s in (2,3,4,5,6) for c in ('REAY','REAB','REAC','PARY','PATY')])
(root/'jobs.json').write_text(json.dumps(jobs),encoding='utf-8')
