using System.Globalization;
using System.Text.Json;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Workbench;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Configuration;
var root=args[0];var study=Path.Combine(root,"study-resumed-wide");
var rows=JsonFiles.Read<JsonElement>(Path.Combine(study,"rows.json")).EnumerateArray().ToArray();
var entries=new List<object>();
foreach(var index in new[]{1989,2679})
{
 var row=rows.Single(r=>r.GetProperty("index").GetInt32()==index);
 var job=JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
 var config=row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
 var entry=AnalysisComparisonRegistry.Get(job.Request.CanonicalAnalysisKey);
 var native=new Dictionary<int,NumericResult>();var local=new Dictionary<int,NumericResult>();
 var output=Path.Combine(root,"mtf-refinement",index.ToString());
 foreach(var n in new[]{128,256,512,1024})
 {
  var settings=new Dictionary<string,string>(job.Request.WorkbenchSettings) {["Sampling"]=n.ToString(CultureInfo.InvariantCulture)};
  var req=job.Request with {PupilSampling=n,ImageSampling=n,WorkbenchSettings=settings};
  var nativePath=Path.Combine(root,"native-mtf-convergence",$"{index}-{n}","data.json");
  try{native[n]=ResultNormalizer.Zemax(nativePath,entry,req);}catch(Exception e){entries.Add(new{index,n,stage="native",error=e.Message});}
  if(n<=512)
  {
   var folder=Path.Combine(output,n.ToString());Directory.CreateDirectory(folder);
   try{
    WorkbenchExecutor.Execute(job with {Request=req,OutputDirectory=folder});
    local[n]=ResultNormalizer.Workbench(Path.Combine(folder,"data.json"),entry,req);
   }catch(Exception e){entries.Add(new{index,n,stage="core",error=e.Message});}
  }
  if(native.ContainsKey(n)&&native.ContainsKey(n/2)) Compare($"native-{n/2}-{n}",native[n],native[n/2],req);
  if(native.ContainsKey(n)&&local.ContainsKey(n)) Compare($"same-sampling-{n}",local[n],native[n],req);
  if(n==1024&&native.ContainsKey(n)&&local.ContainsKey(512)) Compare("core-512-vs-native-1024",local[512],native[1024],req);
 }
 void Compare(string id,NumericResult candidate,NumericResult reference,CanonicalAnalysisRequest req)
 {
  var run=new AnalysisRun {Key=entry.CanonicalAnalysisKey,Directory=id,Request=req};
  ComparisonRunner.Compare(run,entry,config,candidate,reference,output);
  Console.WriteLine($"{index} {id} {run.Conclusion} "+string.Join(" ",run.Metrics.Select(m=>$"{m.Id} {m.Nrmse:G5} {m.MaxAbsolute:G5}")));
  entries.Add(new{index,id,run.Conclusion,run.Metrics});
 }
}
JsonFiles.Write(Path.Combine(root,"mtf-refinement","results.json"),entries);
