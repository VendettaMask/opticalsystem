using System.Globalization;
using System.Text.Json;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Workbench;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Configuration;
var root=args[0];var study=Path.Combine(root,"study-axial");
var row=JsonFiles.Read<JsonElement>(Path.Combine(study,"rows.json")).EnumerateArray().Single(r=>r.GetProperty("index").GetInt32()==860);
var job=JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
var config=row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
var entry=AnalysisComparisonRegistry.Get(job.Request.CanonicalAnalysisKey);
var nativeResults=new Dictionary<(int,string),NumericResult>();
var all=new List<object>();
foreach(var n in new[]{32,64,128,256,512})
{
 var settings=new Dictionary<string,string>(job.Request.WorkbenchSettings);
 foreach(var key in new[]{"Sampling","PupilSampling","NumRays"}) settings[key]=n.ToString(CultureInfo.InvariantCulture);
 settings["ImageSampling"]=(2*n).ToString(CultureInfo.InvariantCulture);
 var req=job.Request with { PupilSampling=n,ImageSampling=2*n,WorkbenchSettings=settings };
 var folder=Path.Combine(root,"energy-refinement",n.ToString());
 WorkbenchExecutor.Execute(job with{ Request=req,OutputDirectory=folder });
 var data=Path.Combine(folder,"data.json");
 var w=ResultNormalizer.Workbench(data,entry,req);
 foreach(var step in new[]{"frozen","fine"})
 {
  var path=Path.Combine(root,"native-energy",step+"-"+n,"data.json");
  var z=ResultNormalizer.Zemax(path,entry,req);
  nativeResults.Add((n,step),z);
  Compare($"core-vs-{step}-{n}",w,z,req);
 }
 Compare($"native-step-{n}",nativeResults[(n,"fine")],nativeResults[(n,"frozen")],req);
 if(n>32)
  foreach(var step in new[]{"frozen","fine"})
   Compare($"native-sampling-{step}-{n}",nativeResults[(n,step)],nativeResults[(n/2,step)],req);
}
JsonFiles.Write(Path.Combine(root,"energy-refinement","results.json"),all);
void Compare(string id,NumericResult candidate,NumericResult reference,CanonicalAnalysisRequest req)
{
 var run=new AnalysisRun { Key=entry.CanonicalAnalysisKey,Directory=id,Request=req };
 ComparisonRunner.Compare(run,entry,config,candidate,reference,Path.Combine(root,"energy-refinement"));
 Console.WriteLine($"{id} {run.Conclusion} "+string.Join(" ",run.Metrics.Select(m=>$"{m.Id} {m.Nrmse:G5} {m.MaxAbsolute:G5}")));
 all.Add(new{id,run.Conclusion,run.Metrics});
}
