import csv,hashlib,json,math,sys
from pathlib import Path
root=Path(sys.argv[1])
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
arc=root/'native-arcs'; groups={}
for st in read(arc/'stations.json'):
    d=arc/st['id']; v={(r['input']['code'],r['input']['int1']):r['value'] for r in read(d/'model-controls.json')['rows']}
    assert abs(v['REAY',2]-.2)<1e-9 and abs(v['REAB',2]-.103263193488929)<1e-10
    s=st['surface']; pt=(v['REAX',s],v['REAY',s],st['vertexZ']+v['REAZ',s])
    groups.setdefault((st['leg'],st['step']),[]).append(pt)
def chords(points,stride):return math.fsum(math.dist(a,b) for a,b in zip(points[::stride],points[stride::stride]))
def extrap(points,stride):return (4*chords(points,stride)-chords(points,2*stride))/3
scope=root/'scope-axial'
controls={}
for leg,s in (('forward',3),('backward',5)):
    coarse=groups[leg,.001]; fine=groups[leg,.0005]; sample=max(math.dist(a,b) for a,b in zip(coarse,fine[::4],strict=True))
    match=extrap(fine,1); prev=extrap(fine,2); old=extrap(coarse,1)
    gate=1e-6+1e-6*abs(match)
    lens={}
    for i in (848,865):
        length=next(row[11] for row in read(scope/'analyses'/f'{i:04}'/'data.json')['values']['RealRayData'] if row[0]==s)
        error=abs(length-match)
        assert error<=gate
        lens[i]=dict(coreLengthMm=length,absoluteErrorMm=error,verdict='Pass')
    assert abs(match-prev)<=gate and sample<=gate and abs(old-extrap(fine,4))<=gate
    controls[leg]=dict(surface=s,nativeExtrapolatedMm=match,nativeChordsMm={str(32//n):chords(fine,n) for n in (4,2,1)},
        nativeChordConvergenceMm=abs(match-prev),maxIntegrationInterceptDeltaMm=sample,
        nativeCoarseVsFineSameChordCountMm=abs(old-extrap(fine,4)),gateMm=gate,requests=lens)
print(controls)
(root/'arcs.json').write_text(json.dumps(controls,indent=2)+'\n',encoding='utf-8')
