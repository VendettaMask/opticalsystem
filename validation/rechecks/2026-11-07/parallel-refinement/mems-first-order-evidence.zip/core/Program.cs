using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Raytrace;
using OpticalSystemDesign.Core.Serialization;
using OpticalSystemDesign.Core.Services;
using OpticalSystemDesign.ZemaxComparison;

var optic = Optic.FromSnapshot(JsonFiles.Read<OpticSnapshot>(args[0]));
var request = JsonFiles.Read<JsonElement>(args[1]);
var samples = request.GetProperty("pointInputs").EnumerateArray().Select(p => new PupilSample(p.GetProperty("px").GetDouble(), p.GetProperty("py").GetDouble(), 1)).ToArray();
var surfaces = optic.SurfaceGroup.Items.Skip(1).Select(surface => new
{
    Surface = surface.Number,
    Geometry = surface.Geometry.Kind,
    Rays = samples.Select(p => RayBundleMetrics.Trace(optic, surface.Number, 1, 0, 0, [p],
        includeSurfaceTransmission: false, allowEmpty: true)).ToArray()
}).ToArray();
JsonFiles.Write(args[2], new { Surfaces = surfaces });
