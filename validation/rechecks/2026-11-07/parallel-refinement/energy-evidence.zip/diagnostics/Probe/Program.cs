using System.Text.Json;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var root = Path.GetFullPath(args[0]);
var baseline = JsonFiles.Read<JsonElement[]>(args[1]);
var output = new List<object>();
foreach (var index in new[] { 108, 368, 712, 742, 2142, 2728, 2750 })
{
    var row = baseline[index - 1];
    var config = row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
    var entry = AnalysisComparisonRegistry.Get(row.GetProperty("key").GetString()!);
    var captures = new List<(int Sampling, WorkbenchJob Job, NumericResult Workbench, NumericResult Native)>();
    foreach (var n in new[] { 64, 128, 256, 512 })
    {
        var directory = Path.Combine(root, $"{index}-{n}");
        var job = JsonFiles.Read<WorkbenchJob>(Path.Combine(directory, "wreq.json"));
        var request = job.Request;
        var wbPath = Path.Combine(job.OutputDirectory, "data.json");
        var nativePath = Path.Combine(directory, "native", "data.json");
        try
        {
            var wb = ResultNormalizer.Workbench(wbPath, entry, request);
            var native = ResultNormalizer.Zemax(nativePath, entry, request, wbPath);
            captures.Add((n, job, wb, native));
            Evaluate($"{n}-cross-tool", request, wb, native);
        }
        catch (Exception ex)
        {
            output.Add(new { index, scope = $"{n}-cross-tool", error = ex.Message });
        }
    }
    foreach (var (previous, current) in captures.Zip(captures.Skip(1)))
    {
        if (previous.Sampling * 2 != current.Sampling) continue;
        var transition = $"{previous.Sampling}-{current.Sampling}";
        Evaluate(transition + "-native-convergence", current.Job.Request, previous.Native, current.Native);
        Evaluate(transition + "-workbench-convergence", current.Job.Request, previous.Workbench, current.Workbench);
    }

    void Evaluate(string scope, CanonicalAnalysisRequest request, NumericResult a, NumericResult b)
    {
        var run = new AnalysisRun { Key = entry.CanonicalAnalysisKey, Directory = scope, Request = request };
        ComparisonRunner.Compare(run, entry, config, a, b, Path.Combine(root, "compare", index.ToString()));
        output.Add(new { index, scope, requestFingerprint = request.Fingerprint, run.Conclusion, run.Metrics, run.Reason });
        Console.WriteLine($"{index} {scope} {run.Conclusion}");
    }
}
JsonFiles.Write(Path.Combine(root, "conclusions.json"), output);

