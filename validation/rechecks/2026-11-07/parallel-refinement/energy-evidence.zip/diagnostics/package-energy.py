import hashlib
import json
import pathlib
import zipfile

root = pathlib.Path('artifacts/validation/pq1107')
previous = pathlib.Path('artifacts/validation/pp1107/final-study')
report = pathlib.Path('validation/rechecks/2026-11-07/parallel-refinement')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
rows = load(previous/'rows.json')
old = load(previous/'results.json')
metrics = load(root/'e/conclusions.json')
rim = {r['index']:r for r in load(root/'e/32-rim-diagnosis.json')}
readbacks = load(root/'e/readback-verification.json')
required = ('256-cross-tool','512-cross-tool','256-512-native-convergence','256-512-workbench-convergence')
indices = sorted(rim)
assert len(metrics)==70 and len(readbacks)==28
summary = []
for i in indices:
    reports = [r for r in metrics if r['index']==i]
    gates = {r['scope']:r['conclusion'] for r in reports}
    assert all(s in gates for s in required)
    summary.append(dict(index=i,lens=rows[i-1]['lens'],configuration=rows[i-1]['configuration'],frozenVerdict=old[i-1]['conclusion'],frozenMaximumAbsolute=max(m['maxAbsolute'] for m in old[i-1]['metrics']),rimNodes=dict(native=rim[i]['nativeNodes'],workbench=rim[i]['workbenchNodes']),supplementalVerdict='Pass' if all(gates[s]=='Pass' for s in required) else 'Open',gates=gates,maxAbsolute512=max(m['maxAbsolute'] for r in reports if r['scope']=='512-cross-tool' for m in r['metrics']),maxNrmse512=max(m['nrmse'] for r in reports if r['scope']=='512-cross-tool' for m in r['metrics']),readbacks=[q for q in readbacks if q['index']==i]))
archive_path = report/'energy-evidence.zip'
entries = []
by_hash = {}
frozen_authority = load(root/'full/reference-integrity.json')
frozen_members = {record['path']:record for record in frozen_authority['files']}
legacy = pathlib.Path(load(root/'full/identity.json')['prior'])

def add(z, path, name):
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    authority = by_hash.get(digest)
    entry = dict(path=name,bytes=len(data),sha256=digest)
    if authority is None:
        z.writestr(name,data)
        by_hash[digest] = name
    else:
        entry['sameArchiveMember'] = authority
    entries.append(entry)

def link_frozen(path, name):
    member = 'run/'+path.relative_to(legacy).as_posix()
    record = frozen_members[member]
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['sha256']
    entries.append(dict(path=name,bytes=record['bytes'],sha256=record['sha256'],frozenArchiveMember=member))
with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in ('energy-mask.py','energy-readback.py','package-energy.py'):
        add(z,root/name,'diagnostics/'+name)
    for name in ('Program.cs','Probe.csproj'):
        add(z,root/'Probe'/name,'diagnostics/Probe/'+name)
    for name in ('conclusions.json','32-rim-diagnosis.json','readback-verification.json'):
        add(z,root/'e'/name,name)
    for stage in ('e','e2'):
        for name in ('native-jobs.json','native.log','host/source-identities.json'):
            add(z,root/stage/name,stage+'/'+name)
    for i in indices:
        frozen = pathlib.Path(rows[i-1]['legacyPath'])/'native'
        for name in ('captured-settings.json','data.json','model.json'):
            link_frozen(frozen/name,f'{i}-32/native/{name}')
        for name in ('data.json','provenance.json'):
            add(z,previous/'analyses'/f'{i:04d}'/name,f'{i}-32/wb/{name}')
        for s in (64,128,256,512):
            for name in ('nreq.json','wreq.json','native/batch-result.json','native/captured-settings.json','native/data.json','native/data.txt','native/model.json','wb/data.json','wb/provenance.json'):
                folder=f'{i}-{s}'
                add(z,root/'e'/folder/name,folder+'/'+name)
    z.writestr('manifest.json',json.dumps(dict(frozenArchive='validation/repairs/2026-10-21/sequential-corpus-full-evidence.zip',frozenArchiveSha256=frozen_authority['archiveSha256'],files=entries),indent=2,ensure_ascii=False)+'\n')
archive_hash=hashlib.sha256(archive_path.read_bytes()).hexdigest()
with zipfile.ZipFile(archive_path) as z, zipfile.ZipFile(frozen_authority['archive']) as source:
    for r in entries:
        if 'frozenArchiveMember' in r:
            data = source.read(r['frozenArchiveMember'])
        else:
            data = z.read(r.get('sameArchiveMember',r['path']))
        assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
(report/'energy-refinement.json').write_text(json.dumps(dict(coreSha256=readbacks[0]['coreSha256'],archiveSha256=archive_hash,nativeCaptures=len(readbacks),referenceDefinition='5 micrometers, centroid, monochromatic, FFT, ideal and actual curves',requests=summary),indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(f'Energy archive {len(entries)} entries, {archive_path.stat().st_size} bytes, {sum(r["supplementalVerdict"]=="Pass" for r in summary)} supplemental passes')

