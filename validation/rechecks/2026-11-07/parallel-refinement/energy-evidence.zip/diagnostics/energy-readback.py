import hashlib
import json
import pathlib

root = pathlib.Path('artifacts/validation/pq1107')
previous = pathlib.Path('artifacts/validation/pp1107/final-study')
rows = json.loads((previous/'rows.json').read_text(encoding='utf-8-sig'))
final_core = hashlib.sha256((root/'bin/OpticalSystemDesign.Core.dll').read_bytes()).hexdigest()
records = []
for index in (108,368,712,742,2142,2728,2750):
    frozen = pathlib.Path(rows[index-1]['legacyPath'])/'native'
    original = json.loads((frozen/'captured-settings.json').read_text(encoding='utf-8-sig'))
    model = json.loads((frozen/'model.json').read_text(encoding='utf-8-sig'))
    advanced = json.loads((root/'e'/f'{index}-64/native/model.json').read_text(encoding='utf-8-sig'))['advanced']
    for sampling in (64,128,256,512):
        level = root/'e'/f'{index}-{sampling}'
        raw = level/'native'
        native = json.loads((raw/'captured-settings.json').read_text(encoding='utf-8-sig'))
        result = json.loads((raw/'data.json').read_text(encoding='utf-8-sig'))
        workbench = json.loads((level/'wb/data.json').read_text(encoding='utf-8-sig'))
        provenance = json.loads((level/'wb/provenance.json').read_text(encoding='utf-8-sig'))
        assert native['selectors'] == original['selectors'], (index,sampling,'selectors')
        assert native['properties'] == {**original['properties'], 'SampleSize':f'S_{sampling}x{sampling}'}, (index,sampling,'settings')
        current_model = json.loads((raw/'model.json').read_text(encoding='utf-8-sig'))
        assert current_model.pop('advanced') == advanced and current_model == model, (index,sampling,'prescription')
        assert len(result['dataSeries']) == 2 and not result['messages'], (index,sampling,'native messages')
        assert workbench['values']['PupilSampling'] == sampling and workbench['values']['EffectiveImageSampling'] == 2*sampling
        assert not workbench['outcomeReason'] and provenance['codeFingerprint'].endswith(final_core)
        assert len(workbench['plotSeries']) == 2
        for series, wb in zip(result['dataSeries'], workbench['plotSeries']):
            assert len(series['x']) == len(wb['points']) == 401
            assert max(abs(x-point['x']) for x, point in zip(series['x'],wb['points'])) < 1e-10
        assert abs(result['dataSeries'][0]['x'][-1] - 5) < 1e-10
        records.append(dict(index=index, sampling=sampling, nativeRequestSource=hashlib.sha256(pathlib.Path(native['request']['input']).read_bytes()).hexdigest(), frozenNativeModel=hashlib.sha256((frozen/'model.json').read_bytes()).hexdigest(), nativeReadbackMatches=True, coordinateCount=401, maximumRadiusMicrometers=5, requestFingerprint=provenance['requestFingerprint'], coreSha256=final_core))
(root/'e/readback-verification.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
print(f'{len(records)} readback contracts verified')

