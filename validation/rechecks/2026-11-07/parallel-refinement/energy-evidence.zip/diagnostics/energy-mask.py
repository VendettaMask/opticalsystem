import pathlib,json, numpy as np
from scipy.interpolate import CubicSpline
from scipy.optimize import minimize_scalar
root=pathlib.Path('artifacts/validation/pp1107/final-study')
rows=json.loads((root/'rows.json').read_text(encoding='utf-8-sig'))
records=[]
indices=[108,368,712,742,2142,2728,2750]
for index in indices:
    r=rows[index-1]
    native=json.loads((pathlib.Path(r['legacyPath'])/'native/data.json').read_text(encoding='utf-8-sig'))['dataSeries']
    ours=json.loads((root/f'analyses/{index:04d}/data.json').read_text(encoding='utf-8-sig'))['plotSeries']
    x=np.array(native[0]['x']); orig=x[-1]
    pairs=[np.array(native[0]['y'])[:,0], np.array([p['y'] for p in ours[0]['points']])]
    print(index,r['lens'],r['settings']['field'],r['settings']['wavelength'])
    variants=[]
    for sign in (False,True):
        yy,xx=np.indices((64,64)); pupil=(xx-32)**2+(yy-32)**2
        mask=pupil<=32 if sign else pupil<32
        psf=np.abs(np.fft.fftshift(np.fft.fft2(mask)))**2
        psf=np.roll(psf,(-1,-1),axis=(0,1)); power=psf.sum(); midx=((xx-31)*psf).sum()/power; midy=((yy-31)*psf).sum()/power
        distances=np.hypot(xx-31-midx,yy-31-midy)
        knots=np.linspace(0,orig,32)
        def curve(pitch):
            frac=np.clip(knots[:,None,None]/pitch-distances+.5,0,1)
            energy=np.einsum('ijk,jk->i',frac,psf)/power; energy[0]=0; energy[1]=energy[2]/4
            return np.maximum.accumulate(np.clip(CubicSpline(knots,energy,bc_type='natural')(x),0,1))
        a=[]
        for y in pairs:
            k=np.searchsorted(y,.3); initial=x[min(k,len(x)-1)]/4
            f=minimize_scalar(lambda p:np.mean((curve(p)-y)**2),bounds=(initial*.5,initial*2),method='bounded',options={'xatol':1e-14}); a.append((f.x,np.max(np.abs(curve(f.x)-y)),np.sqrt(f.fun)))
        variants.append(dict(nodes=int(mask.sum()), native=dict(pitch=float(a[0][0]), maxAbsolute=float(a[0][1]), rms=float(a[0][2])), workbench=dict(pitch=float(a[1][0]), maxAbsolute=float(a[1][1]), rms=float(a[1][2]))))
    best_native=min(variants, key=lambda q:q['native']['maxAbsolute'])
    best_workbench=min(variants, key=lambda q:q['workbench']['maxAbsolute'])
    assert best_native['nodes'] != best_workbench['nodes'] and max(best_native['native']['maxAbsolute'], best_workbench['workbench']['maxAbsolute']) < 1e-8
    assert abs(best_native['native']['pitch']-best_workbench['workbench']['pitch']) < 5e-9
    records.append(dict(index=index,nativeNodes=best_native['nodes'],workbenchNodes=best_workbench['nodes'],variants=variants))
pathlib.Path('artifacts/validation/pq1107/e/32-rim-diagnosis.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')


