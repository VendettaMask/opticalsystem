import json,sys
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
b=Path(sys.argv[1])
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def vec(j):return np.array([j[k] for k in ['x','y','z']])
d=load(b/'444.json'); wf=d['wavefront']; s=[q for q in wf['samples'] if q['intensity']>0]
p=np.array([[q[k] for k in ['pupilX','pupilY','pupilZ']] for q in s]); v=np.array([vec(q['imageDirection']) for q in s])
opd=np.array([-q['opdWaves'] for q in s]); lam=d['wavelength']*.001; R=wf['radius']; center=vec(d['frame']['center']); tx=vec(d['frame']['tangentX']); ty=vec(d['frame']['tangentY']); u=np.sqrt([q['launchIntensity'] for q in s])
for case in sorted((b/'native').glob('444-n*')):
 j=load(case/'data.json')
 g=j['dataGrids'][0]; z=np.array(g['values']).flatten()
 x,y=np.meshgrid(g['minX']+np.arange(g['nx'])*g['dx'],g['minY']+np.arange(g['ny'])*g['dy']); x=x.flatten(); y=y.flatten()
 point=center+x[:,None]*tx*1e-3+y[:,None]*ty*1e-3
 shift=(p[:,2]-d['imageZ']-d['pupilDistance'])/v[:,2]; pp=p-shift[:,None]*v
 signed=np.sign(((point[:,None]-pp)*v).sum(axis=-1))
 dist=np.linalg.norm(point[:,None]-pp,axis=-1)
 cand={
  'linear':np.abs(np.exp(2j*np.pi*(opd+((point[:,None]-p)*v).sum(axis=-1)/lam))@u)**2/u.sum()**2,
  'sphere':np.abs((np.exp(2j*np.pi*(opd+(dist-shift)/lam))*(abs(d['pupilDistance'])/dist))@u)**2/u.sum()**2,
  'signed-sphere':np.abs((np.exp(2j*np.pi*(opd+(signed*dist-shift)/lam))*(abs(d['pupilDistance'])/dist))@u)**2/u.sum()**2}
 print(case.name,g['dx'],z.max(),z.sum(),load(case/'result-diagnostics.json'))
 for model,c0 in cand.items():
  pred=lambda h: c0*(np.sinc(x/h[0])*np.sinc(y/h[0]))**2
  err=lambda h:pred(h)-z
  est=least_squares(err,[50],bounds=(4,1000),gtol=1e-14).x
  print(model,est,np.linalg.norm(err(est))/np.linalg.norm(z),max(abs(err(est))))
