using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Serialization;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var root = args[0];
var prior = args[1];
var output = Path.Combine(root, "refined-spectrometer");
Directory.CreateDirectory(output);
var row = JsonFiles.Read<JsonElement>(Path.Combine(prior, "study-final", "rows.json"))[443];
var job = JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
var entry = AnalysisComparisonRegistry.Get(job.Request.CanonicalAnalysisKey);
var policy = row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
var optic = Optic.FromSnapshot(JsonFiles.Read<OpticSnapshot>(job.SnapshotPath));
var method = typeof(DiffractionEngine).GetMethod("ComputeFocusedHuygensPsf", BindingFlags.Static | BindingFlags.NonPublic)!;
var result = new List<object>();
var native = new Dictionary<int, NumericResult>();
var planar = new Dictionary<int, NumericResult>();
foreach (var n in new[] { 32, 64, 128, 256, 512, 1024 })
{
    var folder = Path.Combine(root, "native", $"444-n{n}-d0.25");
    var path = Path.Combine(folder, "data.json");
    if (!File.Exists(path)) continue;
    var request = job.Request with { PupilSampling = n };
    var nativeSettings = JsonFiles.Read<JsonElement>(Path.Combine(folder, "captured-settings.json"));
    var selectors = nativeSettings.GetProperty("selectors");
    if (selectors.GetProperty("Wavelength").GetInt32() != 2 || selectors.GetProperty("Field").GetInt32() != 1
        || nativeSettings.GetProperty("properties").GetProperty("PupilSampleSize").GetString() != $"S_{n}x{n}")
        throw new InvalidDataException("Native settings differ from requested focal scope.");
    native[n] = ResultNormalizer.Zemax(path, entry, request);
    if (native.TryGetValue(n / 2, out var zPrevious)) Compare($"native-{n/2}-vs-{n}", native[n], zPrevious, request);
    try
    {
        var grid = native[n].Grids.Single();
        var wave = optic.Wavelengths[1];
        var values = (PsfResult)method.Invoke(null, [optic, (0d, 0d), wave, n, 32, .00025,
            false, wave, null, false, false, null])!;
        var candidate = new NumericResult();
        candidate.Grids.Add(grid with { Z = Enumerable.Range(0, 32)
            .Select(y => Enumerable.Range(0, 32).Select(x => (double?)(values.Values[y, x] / 100)).ToArray()).ToArray() });
        planar[n] = candidate;
        Compare($"core-forced-planar-{n}-vs-native-{n}", candidate, native[n], request);
        if (planar.TryGetValue(n / 2, out var coarse))
        {
            Compare($"core-forced-planar-{n/2}-vs-{n}", candidate, coarse, request);
            Compare($"core-forced-planar-{n/2}-vs-native-{n}", coarse, native[n], request);
        }
    }
    catch (Exception e) { result.Add(new { n, stage = "core-forced-planar", error = e.ToString() }); }
    JsonFiles.Write(Path.Combine(output, "results.json"), result);
}

void Compare(string id, NumericResult candidate, NumericResult reference, CanonicalAnalysisRequest request)
{
    var run = new AnalysisRun { Key = request.CanonicalAnalysisKey, Directory = id, Request = request };
    ComparisonRunner.Compare(run, entry, policy, candidate, reference, output);
    Console.WriteLine($"{id} {run.Conclusion} " + string.Join(" ", run.Metrics.Select(m => $"{m.Id}:{m.Nrmse:G7}/{m.MaxAbsolute:G7}/{m.Coverage:G4}")));
    result.Add(new { id, run.Conclusion, run.Reason, run.Metrics });
}
