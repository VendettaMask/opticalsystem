using System.Globalization;
using System.Text.Json;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var root = args[0];
var prior = args[1];
var output = Path.Combine(root, "refined-energy");
Directory.CreateDirectory(output);
var row = JsonFiles.Read<JsonElement>(Path.Combine(prior, "study-final", "rows.json"))[2277];
var job = JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
var entry = AnalysisComparisonRegistry.Get(job.Request.CanonicalAnalysisKey);
var policy = row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
var result = new List<object>();
var native = new Dictionary<int, NumericResult>();
var workbench = new Dictionary<int, NumericResult>();
var requests = new Dictionary<int, CanonicalAnalysisRequest>();
var frozenPath = Path.Combine(row.GetProperty("legacyPath").GetString()!, "native", "data.json");
foreach (var n in new[] {32, 64, 128, 256, 512, 1024})
{
    var nativePath = n == 32 ? frozenPath : Path.Combine(root, "native", "2278-selected-s" + n, "data.json");
    if (!File.Exists(nativePath)) continue;
    var dir = Path.Combine(output, n.ToString(CultureInfo.InvariantCulture));
    Directory.CreateDirectory(dir);
    var request = job.Request with { PupilSampling = n, ImageSampling = 2 * n, WorkbenchSettings = new(job.Request.WorkbenchSettings)
    {
        ["PupilSampling"] = n.ToString(CultureInfo.InvariantCulture),
        ["Sampling"] = n.ToString(CultureInfo.InvariantCulture),
        ["ImageSampling"] = (2 * n).ToString(CultureInfo.InvariantCulture)
    }};
    if (n != 32)
    {
        var settings = JsonFiles.Read<JsonElement>(Path.Combine(Path.GetDirectoryName(nativePath)!, "captured-settings.json"));
        var selector = settings.GetProperty("selectors");
        if (selector.GetProperty("Wavelength").GetInt32() != 2 || selector.GetProperty("Field").GetInt32() != 1
            || settings.GetProperty("properties").GetProperty("SampleSize").GetString() != $"S_{n}x{n}")
            throw new InvalidDataException("Native energy sampling or selector does not match the request.");
    }
    requests[n] = request;
    try { native[n] = ResultNormalizer.Zemax(nativePath, entry, request); }
    catch (Exception e) { result.Add(new { n, stage = "native", error = e.Message }); continue; }
    try
    {
        if (n <= 512 || args.Length > 2)
        {
            WorkbenchExecutor.Execute(job with { Request = request, OutputDirectory = dir });
            workbench[n] = ResultNormalizer.Workbench(Path.Combine(dir, "data.json"), entry, request);
            Compare($"core-{n}-vs-native-{n}", workbench[n], native[n], request);
        }
    }
    catch (Exception e) { result.Add(new { n, stage = "core", error = e.Message }); }
    if (native.TryGetValue(n / 2, out var previous))
        Compare($"native-{n/2}-vs-{n}", native[n], previous, request);
    if (workbench.TryGetValue(n / 2, out var coarse) && workbench.TryGetValue(n, out var fine))
        Compare($"core-{n/2}-vs-{n}", fine, coarse, request);
    if (workbench.TryGetValue(n / 2, out coarse))
        Compare($"core-{n/2}-vs-native-{n}", coarse, native[n], request);
    JsonFiles.Write(Path.Combine(output, "results.json"), result);
}

void Compare(string id, NumericResult candidate, NumericResult reference, CanonicalAnalysisRequest request)
{
    var run = new AnalysisRun { Key = request.CanonicalAnalysisKey, Directory = id, Request = request };
    ComparisonRunner.Compare(run, entry, policy, candidate, reference, output);
    Console.WriteLine($"{id} {run.Conclusion} " + string.Join(" ", run.Metrics.Select(m => $"{m.Id}:{m.Nrmse:G7}/{m.MaxAbsolute:G7}/{m.Coverage:G4}")));
    result.Add(new { id, run.Conclusion, run.Reason, run.Metrics });
}
