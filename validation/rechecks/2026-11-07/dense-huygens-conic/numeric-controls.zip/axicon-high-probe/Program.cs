using System.Globalization;
using OpticalSystemDesign.Core.Services;
using System.Text.Json;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var root = args[0];
var rows = JsonFiles.Read<JsonElement>(Path.Combine(args[1], "study-auto-plane", "rows.json"));
var records = new List<object>();
var output = Path.Combine(root, "axicon-refinement-final");
Directory.CreateDirectory(output);
foreach (var index in new[] {950, 951})
{
    var row = rows[index - 1];
    var job = JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
    var entry = AnalysisComparisonRegistry.Get(job.Request.CanonicalAnalysisKey);
    var policy = row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
    var native = new Dictionary<int, NumericResult>();
    var actual = new Dictionary<int, NumericResult>();
    foreach (var n in index == 950 ? new[] {128, 256, 512, 1024, 2048} : new[] {64, 128, 256, 512})
    {
        var dir = Path.Combine(output, $"{index}-{n}");
        Directory.CreateDirectory(dir);
        var source = Path.Combine(args[2], "native", $"{index}-{n}");
        var path = Path.Combine(source, "data.json");
        var nText = n.ToString(CultureInfo.InvariantCulture);
        var request = job.Request with { PupilSampling = n,
            WorkbenchSettings = new(job.Request.WorkbenchSettings) { ["PupilSampling"] = nText, ["Sampling"] = nText, ["NumRays"] = nText }
        };
        if (File.Exists(path))
        {
            try
            {
                var readback = JsonFiles.Read<JsonElement>(Path.Combine(source, "captured-settings.json"));
                var selectors = readback.GetProperty("selectors");
                if (selectors.GetProperty("Field").GetInt32() != job.Request.Field || selectors.GetProperty("Wavelength").GetInt32() != job.Request.Wavelength
                    || readback.GetProperty("properties").GetProperty(index == 950 ? "PupilSampleSize" : "SampleSize").GetString() != $"S_{n}x{n}")
                    throw new InvalidDataException("Native capture has unexpected sampling or selectors.");
                native[n] = ResultNormalizer.Zemax(path, entry, request);
            }
            catch (Exception e) { records.Add(new { index, n, stage = "native", error = e.ToString() }); }
        }
        else records.Add(new { index, n, stage = "native", error = "No usable captured result." });
        try
        {
            using var cancel = new CancellationTokenSource(TimeSpan.FromSeconds(120));
            using var scope = ComputationCancellation.Push(cancel.Token);
            WorkbenchExecutor.Execute(job with { Request = request, OutputDirectory = dir });
            actual[n] = ResultNormalizer.Workbench(Path.Combine(dir, "data.json"), entry, request);
        }
        catch (Exception e) { records.Add(new { index, n, stage = "core", error = e.ToString() }); }
        if (native.TryGetValue(n, out var z))
        {
            if (actual.TryGetValue(n, out var w)) Compare($"core-{n}-vs-native-{n}", w, z);
            if (native.TryGetValue(n / 2, out var zPrev)) Compare($"native-{n/2}-vs-{n}", z, zPrev);
            if (actual.TryGetValue(n / 2, out var wPrev)) Compare($"core-{n/2}-vs-native-{n}", wPrev, z);
        }
        if (actual.TryGetValue(n, out var wCurrent) && actual.TryGetValue(n / 2, out var wPrevious))
            Compare($"core-{n/2}-vs-{n}", wCurrent, wPrevious);
        JsonFiles.Write(Path.Combine(output, "results.json"), records);
        Console.WriteLine($"Done {index} {n} " + (actual.ContainsKey(n) ? "valid" : "failed"));

        void Compare(string id, NumericResult candidate, NumericResult reference)
        {
            var run = new AnalysisRun { Key = request.CanonicalAnalysisKey, Directory = index + "-" + id, Request = request };
            ComparisonRunner.Compare(run, entry, policy, candidate, reference, output);
            Console.WriteLine($"{index} {id} {run.Conclusion} " + string.Join(" ", run.Metrics.Select(m => $"{m.Id}:{m.Nrmse:G7}/{m.MaxAbsolute:G7}/{m.Coverage:G4}")));
            records.Add(new { index, id, run.Conclusion, run.Reason, run.Metrics });
        }
    }
}



