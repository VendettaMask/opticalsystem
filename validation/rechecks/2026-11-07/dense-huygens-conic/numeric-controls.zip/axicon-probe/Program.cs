using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Serialization;
using OpticalSystemDesign.Core.Raytrace;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Workbench;
var row = JsonFiles.Read<JsonElement>(Path.Combine(args[0], "study-auto-plane", "rows.json"))[950];
var job = JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
var optic = Optic.FromSnapshot(JsonFiles.Read<OpticSnapshot>(job.SnapshotPath));
var wave = optic.Wavelengths[job.Request.Wavelength - 1];
var rays = new List<object>();
foreach (var x in new[] { 0, 1e-14, 1e-12, 1e-10, 1e-9, 1e-8, 1e-6, .001, .01, .1, 1.0 })
{
    var bundle = optic.SequentialRayTracer.RayGenerator.GenerateGeneric(0, 0, x, 0, wave.Micrometers, optic.RayAimingEnabled);
    var ray = bundle.Rays[0];
    var first = optic.SequentialRayTracer.DiagnoseFirstFailure(ray);
    var trace = optic.SequentialRayTracer.Trace(bundle).RayHistories[0].ToArray();
    var last = trace.Last();
    var final = optic.SequentialRayTracer.TraceFinalSamples(bundle).Single();
    Console.WriteLine($"{x:R} launch {ray.Origin.X:R} -> {last.SurfaceNumber} {last.Position.X:R} final {final?.Position.X:R} {first}");
    using var scalarResult = optic.SequentialRayTracer.Trace(bundle, TraceRequest.FinalOnly() with { UseBatchedBackend = false });
    var scalar = scalarResult.TryGetSample(0, optic.SurfaceGroup.Items.Count - 1, out var sample)
        ? sample.ToRayTraceSample() : null;
    rays.Add(new { x, ray, first, trace, final, scalar });
}
JsonFiles.Write(Path.Combine(args[1], "axicon-local-rays.json"), rays);
