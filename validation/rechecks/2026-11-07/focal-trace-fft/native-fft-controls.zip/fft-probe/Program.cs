using System.Globalization;
using System.Text.Json;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Workbench;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Configuration;

var root = args[0];
var rows = JsonFiles.Read<JsonElement>(Path.Combine(args[1], "rows.json")).EnumerateArray().ToArray();
foreach (var index in args.Skip(2).Select(int.Parse))
{
    var row = rows.Single(item => item.GetProperty("index").GetInt32() == index);
    var job = JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
    var config = row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
    var entry = AnalysisComparisonRegistry.Get(job.Request.CanonicalAnalysisKey);
    var output = Path.Combine(root, "fft-refinement", index.ToString(CultureInfo.InvariantCulture));
    Directory.CreateDirectory(output);
    var native = new Dictionary<int, NumericResult>();
    var local = new Dictionary<int, NumericResult>();
    var profile = job.Request.CanonicalAnalysisKey == "FFT PSF Cross Section";
    var frozen = profile ? ResultNormalizer.Zemax(Path.Combine(row.GetProperty("legacyPath").GetString()!,
        "native", "data.json"), entry, job.Request) : null;
    var entries = new List<object>();
    foreach (var n in new[] {128, 256, 512, 1024, 2048, 4096})
    {
        if (n > 1024 && !Directory.Exists(Path.Combine(root, "native-fft", $"{index}-{n}"))) continue;
        var settings = new Dictionary<string, string>(job.Request.WorkbenchSettings);
        var size = n.ToString(CultureInfo.InvariantCulture);
        var fixedImage = job.Request.CanonicalAnalysisKey == "PSF";
        foreach (var key in new[] { "Sampling", "PupilSampling", "NumRays" })
            if (settings.ContainsKey(key)) settings[key] = size;
        if (!fixedImage && settings.ContainsKey("ImageSampling")) settings["ImageSampling"] = size;
        var request = job.Request with { PupilSampling = n,
            ImageSampling = fixedImage ? job.Request.ImageSampling : n, WorkbenchSettings = settings };
        var path = Path.Combine(root, "native-fft", $"{index}-{n}");
        try
        {
            var nativeRequest = JsonFiles.Read<JsonElement>(Path.Combine(root, "native-fft", "requests", $"{index}-{n}.json"));
            var readback = JsonFiles.Read<JsonElement>(Path.Combine(path, "captured-settings.json"));
            var props = readback.GetProperty("properties");
            const string sizeKey = "SampleSize";
            if (fixedImage && (props.GetProperty("OutputSize").GetString() != $"PsfS_{request.ImageSampling}x{request.ImageSampling}"
                || props.GetProperty("ImageDelta").GetDouble() != request.ImageDeltaMicrometers))
                throw new InvalidDataException("Native PSF output size or image pitch changed");
            var sample = props.GetProperty(sizeKey).GetString();
            if (sample is null || !sample.EndsWith($"_{n}x{n}", StringComparison.Ordinal))
                throw new InvalidDataException($"Unexpected native sampling {sizeKey}={sample}");
            var selectors = readback.GetProperty("selectors");
            foreach (var (nativeKey, key) in new[] { ("Field", "field"), ("Wavelength", "wavelength") })
                if (selectors.GetProperty(nativeKey).GetInt32() != nativeRequest.GetProperty(key).GetInt32())
                    throw new InvalidDataException($"Unexpected native {nativeKey}");
            var diag = JsonFiles.Read<JsonElement>(Path.Combine(path, "result-diagnostics.json"));
            if (diag.GetProperty("messages").GetArrayLength() != 0)
                throw new InvalidDataException(diag.GetProperty("messages").GetRawText());
            native[n] = ResultNormalizer.Zemax(Path.Combine(path, "data.json"), entry, request);
            entries.Add(new { index, n, stage = "native-readback", props, selectors });
        }
        catch (Exception ex) { RecordError(n, "native", ex); }
        if (n <= 2048 && (n <= 1024 || index is 2569 or 2813 or 2835))
        {
            var folder = Path.Combine(output, size);
            Directory.CreateDirectory(folder);
            try
            {
                if (!File.Exists(Path.Combine(folder, "data.json")))
                    WorkbenchExecutor.Execute(job with { Request = request, OutputDirectory = folder });
                local[n] = ResultNormalizer.Workbench(Path.Combine(folder, "data.json"), entry, request);
            }
            catch (Exception ex) { RecordError(n, "core", ex); }
        }
        if (native.TryGetValue(n, out var z) && native.TryGetValue(n / 2, out var previousZ))
            Compare($"native-{n / 2}-{n}", z, previousZ, request);
        if (local.TryGetValue(n, out var w) && local.TryGetValue(n / 2, out var previousW))
            Compare($"core-{n / 2}-{n}", w, previousW, request);
        if (native.ContainsKey(n) && local.ContainsKey(n))
        {
            Compare($"same-sampling-{n}", local[n], native[n], request);
            if (index == 559)
            {
                var stored = JsonFiles.Read<JsonElement>(Path.Combine(output, size, "data.json"));
                var fNumber = stored.GetProperty("values").GetProperty("WorkingFNumber").GetDouble();
                // Independent pupil geometry from this preserved model: 1000 mm
                // from image to exit pupil, diameter 5 mm. Diagnostic only.
                var referenceScale = 1000.0 / 5;
                var projected = local[n] with { Series = local[n].Series.Select(series => series with
                    { X = series.X.Select(x => x * referenceScale / fNumber).ToArray() }).ToList() };
                CompareOnDomain($"exit-pupil-projection-{n}", projected, native[n], request);
                entries.Add(new { index, n, stage = "exit-pupil-projection", fNumber, referenceScale });
            }
        }
        if (n >= 1024 && native.ContainsKey(n) && local.ContainsKey(n / 2))
            Compare($"core-{n / 2}-vs-native-{n}", local[n / 2], native[n], request);
    }
    JsonFiles.Write(Path.Combine(output, "results.json"), entries);
    void RecordError(int n, string stage, Exception ex)
    {
        Console.WriteLine($"{index} {n} {stage}: {ex.Message}");
        entries.Add(new { index, n, stage, error = ex.Message });
    }
    void Compare(string id, NumericResult candidate, NumericResult reference, CanonicalAnalysisRequest request)
    {
        CompareOnDomain(id, candidate, reference, request);
        if (profile && frozen?.Series.Count > 0 && (id.StartsWith("native-") || id.StartsWith("core-")))
        {
            try { CompareOnDomain(id + "-frozen-window", Window(candidate), Window(reference), request); }
            catch (InvalidDataException ex) { Console.WriteLine($"{index} {id} fixed window: {ex.Message}"); }
        }
    }
    NumericResult Window(NumericResult data) => data with { Series = data.Series.Select(curve =>
    {
        var domain = frozen!.Series.Single(item => item.Id == curve.Id);
        var minimum = domain.X.Min(); var maximum = domain.X.Max();
        var points = curve.X.Zip(curve.Y).OrderBy(point => point.First).ToArray();
        if (points.Length < 2 || points[0].First > minimum || points[^1].First < maximum)
            throw new InvalidDataException($"Requested fixed domain [{minimum:G8}, {maximum:G8}] is not covered");
        var clipped = points.Where(point => point.First > minimum && point.First < maximum)
            .Prepend((First: minimum, Second: Interpolate(minimum))).Append((First: maximum, Second: Interpolate(maximum))).ToArray();
        return curve with { X = clipped.Select(p => p.First).ToArray(), Y = clipped.Select(p => p.Second).ToArray() };
        double Interpolate(double x)
        {
            var upper = Array.FindIndex(points, p => p.First >= x);
            if (points[upper].First == x) return points[upper].Second;
            var (a, b) = (points[upper - 1], points[upper]);
            return a.Second + (x - a.First) * (b.Second - a.Second) / (b.First - a.First);
        }
    }).ToList() };
    void CompareOnDomain(string id, NumericResult candidate, NumericResult reference, CanonicalAnalysisRequest request)
    {
        var run = new AnalysisRun { Key = entry.CanonicalAnalysisKey, Directory = id, Request = request };
        ComparisonRunner.Compare(run, entry, config, candidate, reference, output);
        Console.WriteLine($"{index} {id} {run.Conclusion} " + string.Join(" ", run.Metrics.Select(metric => $"{metric.Id} {metric.Nrmse:G5} {metric.MaxAbsolute:G5}")));
        entries.Add(new { index, id, run.Conclusion, run.Metrics, range = reference.Series.Select(series => new { series.Id, minimum = series.X.Min(), maximum = series.X.Max(), unit = series.XAxis.Unit }) });
    }
}
