using System.Numerics;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Analysis;

public static partial class DiffractionEngine
{
    internal static void ValidateCroppedFft(int pupilSize, int transformSize, int outputSize)
    {
        AnalysisResourceLimits.ValidateFftGrid(pupilSize, AnalysisResourceLimits.RoundUpPowerOfTwo(pupilSize, nameof(pupilSize)));
        if (transformSize < pupilSize || transformSize > 2 * AnalysisResourceLimits.MaximumFftGridSize
            || (transformSize & (transformSize - 1)) != 0 || outputSize < 2 || outputSize > transformSize
            || (long)pupilSize * pupilSize + (long)pupilSize * outputSize + (long)outputSize * outputSize
                > AnalysisResourceLimits.MaximumAggregateGridCells)
            throw new ArgumentOutOfRangeException(nameof(transformSize), "Cropped Fourier transform exceeds its bounded source, intermediate or output allocation.");
    }

    // A separable transform evaluates only the requested physical frequencies.
    // The largest 2-D arrays are the original pupil and pupilSize*outputSize;
    // the zero-padded transformSize² array is never allocated. This is the same
    // discrete Fourier transform, without a cropped-window renormalization.
    internal static Complex[,] FourierTransformCropped(Complex[,] pupil, int transformSize, int outputSize, bool nativeCenteredOutput)
    {
        var pupilSize = pupil.GetLength(0);
        if (pupil.GetLength(1) != pupilSize) throw new ArgumentException("A square pupil is required", nameof(pupil));
        ValidateCroppedFft(pupilSize, transformSize, outputSize);
        var center = nativeCenteredOutput ? (outputSize - 1) / 2 : outputSize / 2;
        var frequencies = Enumerable.Range(0, outputSize).Select(i => (i - center + transformSize) % transformSize).ToArray();
        var offset = (transformSize - pupilSize) / 2;
        var intermediate = new Complex[pupilSize, outputSize];
        var buffer = new Complex[transformSize];
        for (var row = 0; row < pupilSize; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            Array.Clear(buffer);
            var illuminated = false;
            for (var column = 0; column < pupilSize; column++)
            {
                buffer[offset + column] = pupil[row, column];
                illuminated |= pupil[row, column] != Complex.Zero;
            }
            if (!illuminated) continue;
            Fft(buffer);
            for (var column = 0; column < outputSize; column++) intermediate[row, column] = buffer[frequencies[column]];
        }
        var result = new Complex[outputSize, outputSize];
        for (var column = 0; column < outputSize; column++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            Array.Clear(buffer);
            for (var row = 0; row < pupilSize; row++) buffer[offset + row] = intermediate[row, column];
            Fft(buffer);
            for (var row = 0; row < outputSize; row++) result[row, column] = buffer[frequencies[row]];
        }
        return result;
    }
}
