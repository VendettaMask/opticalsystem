using System.Collections.Concurrent;
using System.Diagnostics;

namespace OpticalSystemDesign.InitialStructure.Engine;

public sealed record SearchPerformanceSample(string Name, long Calls, TimeSpan Elapsed);

/// <summary>Opt-in inclusive timing only; never changes search decisions, budgets or result identities.</summary>
public sealed class SearchPerformanceMeasurement : IDisposable
{
    private static readonly AsyncLocal<SearchPerformanceMeasurement?> Current = new();
    private readonly SearchPerformanceMeasurement? _previous;
    private readonly ConcurrentDictionary<string, Counter> _counters = new(StringComparer.Ordinal);
    private int _disposed;
    private sealed class Counter { internal long Calls; internal long Ticks; }

    private SearchPerformanceMeasurement() { _previous = Current.Value; Current.Value = this; }
    public static SearchPerformanceMeasurement Begin() => new();
    public IReadOnlyList<SearchPerformanceSample> Snapshot() => _counters.OrderBy(item => item.Key, StringComparer.Ordinal)
        .Select(item => new SearchPerformanceSample(item.Key, Interlocked.Read(ref item.Value.Calls),
            TimeSpan.FromSeconds((double)Interlocked.Read(ref item.Value.Ticks) / Stopwatch.Frequency))).ToArray();

    internal static Region Measure(string name) => Current.Value is { } frame ? new(frame, name) : default;
    internal readonly struct Region : IDisposable
    {
        private readonly SearchPerformanceMeasurement? _owner;
        private readonly string? _name;
        private readonly long _start;
        internal Region(SearchPerformanceMeasurement owner, string name) { _owner = owner; _name = name; _start = Stopwatch.GetTimestamp(); }
        public void Dispose()
        {
            if (_owner is null) return;
            var counter = _owner._counters.GetOrAdd(_name!, static _ => new());
            Interlocked.Increment(ref counter.Calls); Interlocked.Add(ref counter.Ticks, Stopwatch.GetTimestamp() - _start);
        }
    }
    public void Dispose() { if (Interlocked.Exchange(ref _disposed, 1) == 0) Current.Value = _previous; }
}
