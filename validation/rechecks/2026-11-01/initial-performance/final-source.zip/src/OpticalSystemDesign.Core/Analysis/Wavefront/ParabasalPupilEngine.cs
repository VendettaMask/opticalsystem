using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Rays;
using OpticalSystemDesign.Core.Raytrace;

namespace OpticalSystemDesign.Core.Analysis;

public sealed record ParabasalPupilResult(double ImageAxialDistanceMillimeters, double DiameterMillimeters,
    Vector3D ConjugatePosition, double ProbeStep);

/// <summary>Images the actual central stop pencil in one image-space meridian using shared geometric tracing.</summary>
public static class ParabasalPupilEngine
{
    public static ParabasalPupilResult Compute(Optic optic, Wavelength wavelength, bool useX = false, double probeStep = 1e-4)
    {
        if (!double.IsFinite(probeStep) || probeStep is < 1e-6 or > .01) throw new ArgumentOutOfRangeException(nameof(probeStep));
        var surfaces = optic.SurfaceGroup.Items;
        var stopIndex = surfaces.ToList().FindIndex(s => s.IsStop);
        if (stopIndex < 1 || stopIndex >= surfaces.Count - 1)
            throw new AnalysisDataUnavailableException("Parabasal pupil", "a physical stop before the image is required");
        var tracer = optic.SequentialRayTracer;
        var chiefBundle = tracer.RayGenerator.GenerateGeneric(0, 0, 0, 0, wavelength.Micrometers, optic.RayAimingEnabled);
        using var traced = tracer.Trace(chiefBundle, TraceRequest.Selected([stopIndex, surfaces.Count - 1]));
        if (!traced.TryGetSample(0, stopIndex, out var stopHit) || !traced.TryGetSample(0, surfaces.Count - 1, out var chief)
            || stopHit.Vignetted || chief.Vignetted)
            throw new AnalysisDataUnavailableException("Parabasal pupil", "the central ray is blocked");
        var material = ExitPupilGeometryEngine.PencilMaterial(surfaces[stopIndex], stopHit);
        var frame = surfaces[^1].CoordinateSystem;
        var perturbation = surfaces[stopIndex].CoordinateSystem.ToGlobalDirection(useX ? new(1, 0, 0) : new(0, 1, 0));
        var ends = new List<RayTraceSample>();
        foreach (var sign in new[] { -1, 1 })
        {
            var ray = new RealRay(stopHit.Position, stopHit.Direction + perturbation * (sign * probeStep), wavelength.Nanometers);
            ends.Add(tracer.TracePupilGeometryProbe(ray, stopIndex + 1, material)
                ?? throw new AnalysisDataUnavailableException("Parabasal pupil", "the central direction pencil failed"));
        }
        double Height(Vector3D p) => useX ? frame.ToLocalPoint(p).X : frame.ToLocalPoint(p).Y;
        double Slope(Vector3D d)
        {
            var local = frame.ToLocalDirection(d);
            if (Math.Abs(local.Z) <= 1e-12) throw new AnalysisDataUnavailableException("Parabasal pupil", "a probe is parallel to the image plane");
            return (useX ? local.X : local.Y) / local.Z;
        }
        var slopeDifference = Slope(ends[1].Direction) - Slope(ends[0].Direction);
        if (Math.Abs(slopeDifference) <= 1e-15)
            throw new AnalysisDataUnavailableException("Parabasal pupil", "the exit pupil is at infinity");
        var distance = -(Height(ends[1].Position) - Height(ends[0].Position)) / slopeDifference;
        var pupilEnds = new List<double>();
        foreach (var sign in new[] { -1, 1 })
        {
            var bundle = tracer.RayGenerator.GenerateGeneric(0, 0, useX ? sign * probeStep : 0,
                useX ? 0 : sign * probeStep, wavelength.Micrometers, optic.RayAimingEnabled);
            var end = tracer.TraceFinalSamples(bundle).Single()
                ?? throw new AnalysisDataUnavailableException("Parabasal pupil", "the central height pencil failed");
            pupilEnds.Add(Height(end.Position) + distance * Slope(end.Direction));
        }
        var diameter = Math.Abs(pupilEnds[1] - pupilEnds[0]) / probeStep;
        var localChief = frame.ToLocalDirection(chief.Direction);
        var position = chief.Position + chief.Direction * (distance / localChief.Z);
        if (!double.IsFinite(distance) || !double.IsFinite(diameter) || diameter <= 0)
            throw new AnalysisDataUnavailableException("Parabasal pupil", "the pupil conjugate is not finite");
        return new(distance, diameter, position, probeStep);
    }
}
