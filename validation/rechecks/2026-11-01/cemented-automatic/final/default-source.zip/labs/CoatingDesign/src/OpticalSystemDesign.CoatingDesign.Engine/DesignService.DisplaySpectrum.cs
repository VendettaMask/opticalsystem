using OpticalSystemDesign.Core.Coatings;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.CoatingDesign.Engine;

public sealed record PolarizedDisplaySpectrum(ThinFilmSample[] Average, ThinFilmSample[] S, ThinFilmSample[] P);

public sealed partial class DesignService
{
    /// <summary>Read-only display sampling on the exact certified grid. Does not change targets or acceptance.</summary>
    public PolarizedDisplaySpectrum EvaluateDisplayPolarizations(Experiment input, CancellationToken token = default)
    {
        using var scope = ComputationCancellation.Push(token);
        token.ThrowIfCancellationRequested();
        var d = input.Snapshot();
        if (d.Result is not { } result || !d.MatchesFingerprint(result.Fingerprint))
            throw new ArgumentException("请先计算当前输入的光谱，再查看平均 / s / p 曲线。");
        var grid = result.Spectrum.Select(p => p.WavelengthNanometers).ToArray();
        if (grid.Length < 3 || grid.Length > ThinFilmSpectrum.MaximumSamples)
            throw new ArgumentException("显示采样数量无效。");
        for (var i = 0; i < grid.Length; i++)
            if (!double.IsFinite(grid[i]) || grid[i] < d.Target.MinimumNm || grid[i] > d.Target.MaximumNm || i > 0 && grid[i] <= grid[i - 1])
                throw new ArgumentException("显示采样必须在已计算波段内严格递增。");
        var solver = Solver(d, Materials(d));
        ThinFilmSample[] Sample(ThinFilmPolarization polarization) =>
            ThinFilmSpectrum.Sample(solver, grid, d.Target.AngleDegrees, polarization);
        // Unpolarized power and its stable log(T) are computed only by the shared Core.
        return new(Sample(ThinFilmPolarization.Unpolarized), Sample(ThinFilmPolarization.S), Sample(ThinFilmPolarization.P));
    }
}
