using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Templates;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Styling;
using Avalonia.Threading;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.App.ViewModels;
using OpticalSystemDesign.Application.Contracts;

namespace OpticalSystemDesign.App.Panels;

public sealed partial class LensEditorPanel : UserControl, IDisposable, IDisplaySettingsAware
{
    private const string NumericColumnTag = "numeric";

    private readonly IPrescriptionService _prescription;
    private readonly IWorkspaceEventStream _events;
    private readonly SurfaceSelectionService _surfaceSelection;
    private readonly DataGrid _grid;
    private readonly ComboBox _geometryPicker = new() { MinWidth = 130 };
    private readonly ComboBox _aperturePicker = new() { MinWidth = 110 };
    private readonly NumericUpDown _gratingOrder = Number(72, -100, 100, 1, 1);
    private readonly NumericUpDown _gratingPeriod = Number(94, 0.000001m, 1_000_000, 0.1m, 1);
    private readonly NumericUpDown _gratingAngle = Number(88, -360, 360, 1, 0);
    private readonly NumericUpDown _thinLensFocalLength = Number(92, -1_000_000, 1_000_000, 1, 50);
    private readonly CheckBox _infiniteGratingPeriod = new() { Content = "∞", VerticalAlignment = VerticalAlignment.Center };
    private readonly CheckBox _infiniteThinLensFocalLength = new() { Content = "∞", VerticalAlignment = VerticalAlignment.Center };
    private readonly Button _applyComponentsButton;
    private readonly TextBlock _componentSummary = new()
    {
        MinWidth = 160,
        MaxWidth = 260,
        TextWrapping = TextWrapping.Wrap,
        VerticalAlignment = VerticalAlignment.Center
    };
    private bool _disposed;

    public LensEditorPanel(
        IPrescriptionService prescription,
        IWorkspaceEventStream events,
        SurfaceSelectionService surfaceSelection,
        IMultiConfigurationService? configurations = null)
    {
        _prescription = prescription;
        _events = events;
        _surfaceSelection = surfaceSelection;
        _configurations = configurations;
        _grid = CreateGrid();
        var options = prescription.GetOptions();
        _geometryPicker.ItemsSource = options.GeometryKinds.Select(SurfaceEditorRow.SurfaceTypeForGeometry).Distinct().ToArray();
        _aperturePicker.ItemsSource = options.PhysicalApertureKinds;
        _infiniteGratingPeriod.IsCheckedChanged += (_, _) =>
            _gratingPeriod.IsEnabled = _infiniteGratingPeriod.IsChecked != true;
        _infiniteThinLensFocalLength.IsCheckedChanged += (_, _) =>
            _thinLensFocalLength.IsEnabled = _infiniteThinLensFocalLength.IsChecked != true;

        ConfigureSurfaceContextMenu();
        _applyComponentsButton = CommandButton("check", "应用", 72);
        _applyComponentsButton.Click += (_, _) => ApplySelectedComponents();

        var componentSection = BuildSurfacePropertiesSection();
        var root = new DockPanel();
        root.Bind(DockPanel.MarginProperty, new Avalonia.Markup.Xaml.MarkupExtensions.DynamicResourceExtension(ThemeLayoutResources.LensEditorContentMargin));
        root.BindThemeResource(Panel.BackgroundProperty, ThemeResourceBindings.Surface);
        DockPanel.SetDock(componentSection, Avalonia.Controls.Dock.Top);
        root.Children.Add(componentSection);
        root.Children.Add(_grid);
        Content = root;

        _grid.SelectionChanged += (_, _) => LoadComponentSelection();
        _events.Changed += OnWorkspaceChanged;
        Refresh();
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        ClearSurfaceContext();
        CloseRadiusSolve();
        CloseThicknessSolve();
        CloseSemiDiameterSolve();
        _events.Changed -= OnWorkspaceChanged;
    }

    public void RefreshDisplaySettings() => Refresh();

    private DataGrid CreateGrid()
    {
        var grid = new DataGrid
        {
            Name = "LensSurfaceGrid",
            AutoGenerateColumns = false,
            CanUserReorderColumns = true,
            CanUserResizeColumns = true,
            GridLinesVisibility = DataGridGridLinesVisibility.All,
            HeadersVisibility = DataGridHeadersVisibility.Column,
            IsReadOnly = false,
            BorderThickness = new Avalonia.Thickness(1, 0, 1, 1),
            RowHeight = UiDensity.CompactTableRowHeight,
            ColumnHeaderHeight = UiDensity.TableHeaderHeight,
            FrozenColumnCount = 2
        };
        grid.BindThemeResource(DataGrid.RowBackgroundProperty, ThemeResourceBindings.Surface);
        grid.BindThemeResource(DataGrid.BorderBrushProperty, ThemeResourceBindings.Border);
        grid.Styles.Add(new Style(selector => selector.OfType<DataGridColumnHeader>())
        {
            Setters =
            {
                new Setter(TemplatedControl.FontWeightProperty, FontWeight.Bold),
                new Setter(DataGridColumnHeader.HorizontalContentAlignmentProperty, HorizontalAlignment.Center),
                new Setter(DataGridColumnHeader.VerticalContentAlignmentProperty, VerticalAlignment.Center)
            }
        });
        grid.Styles.Add(new Style(selector => selector
            .OfType<DataGridRow>()
            .Class("glass-material-row"))
        {
            Setters =
            {
                new Setter(
                    DataGridRow.BackgroundProperty,
                    new Avalonia.Markup.Xaml.MarkupExtensions.DynamicResourceExtension(
                        ThemeResourceBindings.RibbonTabHover))
            }
        });
        grid.LoadingRow += (_, eventArgs) =>
        {
            if (eventArgs.Row.DataContext is SurfaceEditorRow row)
            {
                ApplyMaterialRowClass(eventArgs.Row, row);
            }
        };
        grid.Columns.Add(Column("#", nameof(SurfaceEditorRow.Number), 44, true, HorizontalAlignment.Center));
        grid.Columns.Add(SurfaceTypeColumn());
        grid.Columns.Add(Column("标注", nameof(SurfaceEditorRow.Label), 88));
        grid.Columns.Add(RadiusColumn());
        grid.Columns.Add(ThicknessColumn());
        var materialColumn = Column("材料", nameof(SurfaceEditorRow.MaterialDisplay), 122,
            alignment: HorizontalAlignment.Right);
        grid.Columns.Add(materialColumn);
        grid.Columns.Add(Column("膜层", nameof(SurfaceEditorRow.Coating), 92));
        grid.Columns.Add(SemiDiameterColumn());
        var chipZoneColumn = NumericColumn("延伸区", nameof(SurfaceEditorRow.ExtensionZoneDisplay), 102);
        chipZoneColumn.SortMemberPath = nameof(SurfaceEditorRow.ExtensionZone);
        grid.Columns.Add(chipZoneColumn);
        var mechanicalSemiDiameterColumn = NumericColumn(
            "机械半直径", nameof(SurfaceEditorRow.MechanicalSemiDiameterDisplay), 132, true);
        mechanicalSemiDiameterColumn.SortMemberPath = nameof(SurfaceEditorRow.MechanicalSemiDiameter);
        grid.Columns.Add(mechanicalSemiDiameterColumn);
        grid.Columns.Add(NumericColumn("圆锥系数", nameof(SurfaceEditorRow.Conic), 100));
        var thermalExpansionColumn = new DataGridTemplateColumn
        {
            Header = NumericHeader("TCE x 1E-6"),
            Tag = NumericColumnTag,
            Width = new DataGridLength(112),
            CellTemplate = new FuncDataTemplate<SurfaceEditorRow>((row, _) =>
            {
                if (row is null) return new Grid();
                var editor = CreateNumericEditor(row.ThermalExpansionDisplay, text =>
                {
                    row.ThermalExpansionDisplay = text;
                    _prescription.UpdateSurface(row.ToDto());
                });
                return new Grid { Name = "ThermalExpansionCell", Children = { editor } };
            })
        };
        if (thermalExpansionColumn.Header is Control thermalExpansionHeader)
        {
            const string help = "表面/隔圈热膨胀系数，单位 10⁻⁶/°C，可为负。未提供表示源文件没有已验证数据；玻璃目录系数使用 GTCE。此属性尚不驱动温度膨胀追迹。";
            ToolTip.SetTip(thermalExpansionHeader, help);
            AutomationProperties.SetHelpText(thermalExpansionHeader, help);
        }
        grid.Columns.Add(thermalExpansionColumn);
        grid.PreparingCellForEdit += (_, eventArgs) =>
        {
            if ((Equals(eventArgs.Column.Tag, NumericColumnTag)
                    || ReferenceEquals(eventArgs.Column, materialColumn))
                && eventArgs.EditingElement is TextBox editor)
            {
                editor.TextAlignment = TextAlignment.Right;
                editor.HorizontalContentAlignment = HorizontalAlignment.Right;
            }
        };
        grid.CellEditEnded += (_, eventArgs) =>
        {
            if (eventArgs.EditAction == DataGridEditAction.Commit
                && eventArgs.Row.DataContext is SurfaceEditorRow row)
            {
                ApplyMaterialRowClass(eventArgs.Row, row);
                _prescription.UpdateSurface(row.ToDto());
            }
        };
        return grid;
    }

    private void OnWorkspaceChanged(object? sender, WorkspaceChangedEventArgs args)
    {
        Dispatcher.UIThread.Post(() =>
        {
            if (args.FileSwitched) _configurationMessage.IsVisible = false;
            Refresh(preserveSelection: !args.FileSwitched);
        });
    }

    private void Refresh(bool preserveSelection = true)
    {
        if (_disposed)
        {
            return;
        }

        if (_surfaceContextRevision != _events.Revision)
        {
            ClearSurfaceContext();
        }
        if (_radiusSolveRevision != _events.Revision) CloseRadiusSolve();
        if (_thicknessSolveRevision != _events.Revision) CloseThicknessSolve();
        if (_semiDiameterSolveRevision != _events.Revision) CloseSemiDiameterSolve();

        var selectedNumber = preserveSelection
            ? (_grid.SelectedItem as SurfaceEditorRow)?.Number
            : null;
        var surfaces = _prescription.GetSurfaces();
        var lastSurfaceNumber = surfaces.Count == 0 ? -1 : surfaces.Max(surface => surface.Number);
        var rows = surfaces
            .Select(surface => new SurfaceEditorRow(surface, surface.Number == lastSurfaceNumber))
            .ToArray();
        _grid.ItemsSource = rows;
        _grid.SelectedItem = rows.FirstOrDefault(row => row.Number == selectedNumber)
            ?? rows.ElementAtOrDefault(Math.Min(1, Math.Max(0, rows.Length - 1)));
        LoadComponentSelection();
        RefreshConfigurationNavigation();
    }

    private void LoadComponentSelection()
    {
        UpdateSurfacePropertiesHeader();
        if (_grid.SelectedItem is not SurfaceEditorRow row)
        {
            _componentSummary.Text = "未选择表面";
            _propertyBody.IsEnabled = false;
            _applyComponentsButton.IsEnabled = false;
            _surfaceSelection.Select(null);
            return;
        }

        _surfaceSelection.Select(row.Number);
        _propertyBody.IsEnabled = true;

        _geometryPicker.ItemsSource = _prescription.GetOptions().GeometryKinds
            .Select(SurfaceEditorRow.SurfaceTypeForGeometry)
            .Append(row.SurfaceType)
            .Distinct()
            .ToArray();
        _geometryPicker.SelectedItem = row.SurfaceType;
        _aperturePicker.SelectedItem = row.ApertureKind;
        _gratingOrder.Value = row.GratingOrder;
        _infiniteGratingPeriod.IsChecked = double.IsPositiveInfinity(row.GratingPeriodMicrometers);
        if (double.IsFinite(row.GratingPeriodMicrometers))
        {
            _gratingPeriod.Value = (decimal)Math.Clamp(row.GratingPeriodMicrometers, 0.000001, 1_000_000);
        }

        _gratingAngle.Value = (decimal)row.GrooveOrientationAngleDegrees;
        _infiniteThinLensFocalLength.IsChecked = double.IsInfinity(row.ThinLensFocalLength);
        if (double.IsFinite(row.ThinLensFocalLength))
        {
            _thinLensFocalLength.Value = (decimal)Math.Clamp(row.ThinLensFocalLength, -1_000_000, 1_000_000);
        }

        _componentSummary.Text = $"表面 {row.Number}: {row.SurfaceType}";
        var canEditComponents = row.GeometryComputable;
        _geometryPicker.IsEnabled = canEditComponents;
        _aperturePicker.IsEnabled = canEditComponents;
        _gratingOrder.IsEnabled = canEditComponents;
        _gratingPeriod.IsEnabled = canEditComponents && _infiniteGratingPeriod.IsChecked != true;
        _infiniteGratingPeriod.IsEnabled = canEditComponents;
        _gratingAngle.IsEnabled = canEditComponents;
        _thinLensFocalLength.IsEnabled = canEditComponents && _infiniteThinLensFocalLength.IsChecked != true;
        _infiniteThinLensFocalLength.IsEnabled = canEditComponents;
        _applyComponentsButton.IsEnabled = canEditComponents;
        LoadSurfaceProperties(row);
        if (!canEditComponents)
        {
            _componentSummary.Text += "（只读：暂不支持计算/编辑该 Zemax 面型）";
        }
    }

    private void ApplySelectedComponents()
    {
        if (_grid.SelectedItem is not SurfaceEditorRow row)
        {
            return;
        }

        if (!row.GeometryComputable)
        {
            _componentSummary.Text = $"表面 {row.Number}: {row.SurfaceType}（只读：暂不支持计算/编辑该 Zemax 面型）";
            return;
        }

        try
        {
            _prescription.UpdateSurfaceComponents(row.Number, new SurfaceComponentUpdateDto(
            _geometryPicker.SelectedItem as string ?? row.SurfaceType,
            _aperturePicker.SelectedItem as string ?? row.ApertureKind,
            (int)(_gratingOrder.Value ?? row.GratingOrder),
            _infiniteGratingPeriod.IsChecked == true
                ? double.PositiveInfinity
                : (double)(_gratingPeriod.Value ?? 1),
            (double)(_gratingAngle.Value ?? 0),
            _infiniteThinLensFocalLength.IsChecked == true
                ? Math.CopySign(double.PositiveInfinity, (double)(_thinLensFocalLength.Value ?? 1))
                : (double)(_thinLensFocalLength.Value ?? 50),
            _stopSurface.IsChecked == true,
            _surfaceCoating.Text));
        }
        catch (Exception exception) when (exception is ArgumentException or InvalidOperationException or NotSupportedException)
        {
            _componentSummary.Text = $"未应用：{exception.Message}";
        }
    }

    private static DataGridTextColumn Column(string header, string property, double width, bool readOnly = false,
        HorizontalAlignment alignment = HorizontalAlignment.Left) => new()
        {
            Header = header,
            Binding = new Binding(property),
            IsReadOnly = readOnly,
            Width = new DataGridLength(width),
            CellTheme = alignment == HorizontalAlignment.Left ? null : CellAlignmentTheme(alignment)
        };

    private static DataGridTextColumn NumericColumn(
        string header,
        string property,
        double width,
        bool readOnly = false) => new()
        {
            Header = NumericHeader(header),
            Binding = new Binding(property),
            IsReadOnly = readOnly,
            Width = new DataGridLength(width),
            Tag = NumericColumnTag,
            CellTheme = NumericCellTheme()
        };

    private static ControlTheme NumericCellTheme()
    {
        var theme = CellAlignmentTheme(HorizontalAlignment.Right);
        theme.Setters.Add(new Setter(DataGridCell.FontFamilyProperty,
            new Avalonia.Markup.Xaml.MarkupExtensions.DynamicResourceExtension(ProductFonts.NumericResource)));
        return theme;
    }

    private static ControlTheme CellAlignmentTheme(HorizontalAlignment alignment) => new(typeof(DataGridCell))
    {
        // Preserve Fluent's current-cell, focus and validation layers when aligning content.
        BasedOn = global::Avalonia.Application.Current?.FindResource(typeof(DataGridCell)) as ControlTheme,
        Setters = { new Setter(DataGridCell.HorizontalContentAlignmentProperty, alignment) }
    };

    private DataGridTemplateColumn RadiusColumn() => new()
    {
        Header = NumericHeader("曲率半径"),
        Tag = NumericColumnTag,
        Width = new DataGridLength(136),
        CellTemplate = new FuncDataTemplate<SurfaceEditorRow>((row, _) => CreateRadiusCell(row))
    };

    private DataGridTemplateColumn ThicknessColumn() => new()
    {
        Header = NumericHeader("厚度"),
        Tag = NumericColumnTag,
        Width = new DataGridLength(96),
        CellTemplate = new FuncDataTemplate<SurfaceEditorRow>((row, _) => CreateThicknessCell(row))
    };

    private DataGridTemplateColumn SemiDiameterColumn() => new()
    {
        Header = NumericHeader("净口径"),
        Tag = NumericColumnTag,
        Width = new DataGridLength(106),
        CellTemplate = new FuncDataTemplate<SurfaceEditorRow>((row, _) => CreateSemiDiameterCell(row))
    };

    private static TextBox CreateNumericEditor(string value, Action<string> commit)
    {
        var editor = new TextBox
        {
            Classes = { ProductFonts.NumericClass },
            Text = value,
            Background = Brushes.Transparent,
            BorderThickness = new Avalonia.Thickness(0),
            Padding = new Avalonia.Thickness(8, 0),
            VerticalContentAlignment = VerticalAlignment.Center,
            HorizontalContentAlignment = HorizontalAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            TextAlignment = TextAlignment.Right
        };
        // Dense cells use a validation border and tooltip without an extra message row.
        editor.Styles.Add(new Style(selector => selector.OfType<TextBox>().Template().OfType<DataValidationErrors>())
        {
            Setters =
            {
                new Setter(DataValidationErrors.ErrorTemplateProperty,
                    new FuncDataTemplate<object>((_, _) => new Panel { IsVisible = false }))
            }
        });
        var committedText = value;
        void SetError(Exception? error)
        {
            DataValidationErrors.SetErrors(editor, error is null ? null : new[] { error.Message });
            editor.BorderThickness = new Avalonia.Thickness(error is null ? 0 : 1);
            ToolTip.SetTip(editor, error?.Message);
            Avalonia.Automation.AutomationProperties.SetHelpText(editor, error?.Message);
        }
        editor.LostFocus += (_, _) =>
        {
            var text = editor.Text ?? string.Empty;
            if (text == committedText)
            {
                SetError(null);
                return;
            }
            try
            {
                commit(text);
                committedText = text;
                SetError(null);
            }
            catch (Exception error) when (error is FormatException or ArgumentException or InvalidOperationException)
            {
                SetError(error);
            }
        };
        editor.KeyDown += (_, args) =>
        {
            if (args.Key != Avalonia.Input.Key.Escape) return;
            editor.Text = committedText;
            SetError(null);
            args.Handled = true;
        };
        return editor;
    }

    private static TextBlock NumericHeader(string text) => new()
    {
        Text = text,
        HorizontalAlignment = HorizontalAlignment.Center,
        TextAlignment = TextAlignment.Center
    };

    private static DataGridTemplateColumn SurfaceTypeColumn() => new()
    {
        Header = "表面类型",
        IsReadOnly = true,
        Width = new DataGridLength(180),
        CellTheme = CellAlignmentTheme(HorizontalAlignment.Stretch),
        CellTemplate = new FuncDataTemplate<SurfaceEditorRow>((row, _) =>
        {
            var content = new Grid
            {
                ColumnDefinitions = new ColumnDefinitions("Auto,*")
            };
            var role = new TextBlock
            {
                Margin = new Avalonia.Thickness(8, 0),
                HorizontalAlignment = HorizontalAlignment.Left,
                TextAlignment = TextAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center
            };
            var type = new TextBlock
            {
                Margin = new Avalonia.Thickness(8, 0),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                TextAlignment = TextAlignment.Right,
                TextTrimming = TextTrimming.CharacterEllipsis,
                VerticalAlignment = VerticalAlignment.Center
            };
            role.Bind(TextBlock.TextProperty, new Binding(nameof(SurfaceEditorRow.SurfaceRole)));
            role.Bind(IsVisibleProperty, new Binding(nameof(SurfaceEditorRow.ShowSurfaceRole)));
            type.Bind(TextBlock.TextProperty, new Binding(nameof(SurfaceEditorRow.SurfaceType)));
            type.Bind(ToolTip.TipProperty, new Binding(nameof(SurfaceEditorRow.SurfaceType)));
            Grid.SetColumn(type, 1);
            content.Children.Add(role);
            content.Children.Add(type);
            return content;
        }, supportsRecycling: true)
    };

    private static bool HasOpticalMaterial(SurfaceEditorRow row) =>
        row.HasOpticalMaterial;

    private static void ApplyMaterialRowClass(DataGridRow dataGridRow, SurfaceEditorRow row) =>
        dataGridRow.Classes.Set("glass-material-row", row.HasOpticalMaterial);

    private static NumericUpDown Number(double width, decimal minimum, decimal maximum, decimal increment, decimal value) => new()
    {
        Width = width,
        Minimum = minimum,
        Maximum = maximum,
        Increment = increment,
        Value = value,
        ShowButtonSpinner = false
    };

    private static TextBlock Label(string text) => new()
    {
        Text = text,
        VerticalAlignment = VerticalAlignment.Center,
        Margin = new Avalonia.Thickness(7, 0, 4, 0)
    };

    private static Button CommandButton(string iconName, string text, double minWidth) => new()
    {
        Content = new LocalIconLabel(iconName, text),
        MinWidth = minWidth
    };
}
