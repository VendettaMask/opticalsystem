using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using Avalonia.Threading;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Manufacturing;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.App.Theming;
using OpticalSystemDesign.Application.Contracts;
using OpticalSystemDesign.Application.Formatting;
using OpticalSystemDesign.Application.Services;

namespace OpticalSystemDesign.App;

public sealed partial class MainWindow
{
    private async void OnWindowKeyDown(object? sender, KeyEventArgs args)
    {
        var commandModifier = args.KeyModifiers.HasFlag(KeyModifiers.Control)
            || args.KeyModifiers.HasFlag(KeyModifiers.Meta);
        if (_commandSearch.TryHandleShortcut(args)) return;
        else if ((args.Key == Key.K || args.Key == Key.Q) && commandModifier)
        {
            args.Handled = true;
            try
            {
                await ShowCommandPaletteAsync();
            }
            catch (Exception exception)
            {
                if (!_closed)
                {
                    _statusText.Text = $"命令面板打开失败：{exception.Message}";
                }
            }
        }
        else if (args.Key == Key.S && commandModifier)
        {
            args.Handled = true;
            try
            {
                await SaveProjectAsync();
            }
            catch (Exception exception)
            {
                if (!_closed)
                {
                    _statusText.Text = $"保存项目失败：{exception.Message}";
                }
            }
        }
    }

    private void RefreshStatus()
    {
        var snapshot = _application.Documents.GetSnapshot();
        UpdateHistoryButtons(_undoButton, _redoButton, snapshot.CanUndo, snapshot.CanRedo);
        var dirtyMarker = snapshot.IsDirty ? " *" : string.Empty;
        var modeName = _application.Modes.CurrentMode == OpticalWorkbenchMode.NonSequential
            ? UiLocalization.Text("非序列模式")
            : UiLocalization.Text("顺序模式");
        Title = $"{snapshot.Name}{dirtyMarker} - {modeName} - Optical System Design";
        _statusText.Text = $"{modeName}   |   {UiLocalization.Text(snapshot.Status)}   |   "
            + $"{UiLocalization.Count(snapshot.SurfaceCount, "表面")}   |   "
            + $"{UiLocalization.Count(snapshot.FieldCount, "视场")}   |   "
            + UiLocalization.Count(snapshot.WavelengthCount, "波长");
        ToolTip.SetTip(_statusText, _statusText.Text);
        _eflText.Text = $"EFFL: {FormatMetric(snapshot.EffectiveFocalLength)}";
        _fNumberText.Text = $"F/#: {FormatMetric(snapshot.FNumber)}";
        _apertureText.Text = $"APER: {NumericDisplayFormatter.Format(snapshot.ApertureValue)}";
        _trackText.Text = $"TOTR: {FormatMetric(snapshot.TotalTrack)}";
    }

    private async Task SwitchDocumentAsync(Action createDocument)
    {
        if (!await ConfirmUnsavedChangesAsync("新建光学系统"))
        {
            return;
        }

        await _panels.SaveCurrentSessionAsync();
        createDocument();
    }

    private void OnWorkspaceChanged(object? sender, WorkspaceChangedEventArgs args)
    {
        Dispatcher.UIThread.Post(RefreshStatus);
        if (args.FileSwitched) Dispatcher.UIThread.Post(() => OnRecoveryTick(null, EventArgs.Empty));
    }

    private void OnWorkspaceStatusChanged(object? sender, EventArgs args)
    {
        Dispatcher.UIThread.Post(RefreshStatus);
        Dispatcher.UIThread.Post(() =>
        {
            if (!_closed && !_application.Documents.GetRecoveryState().IsDirty)
                OnRecoveryTick(null, EventArgs.Empty);
        });
    }

    private void OnWorkspacePersistenceFailed(object? sender, WorkspacePersistenceFailedEventArgs args)
    {
        Dispatcher.UIThread.Post(() =>
            _statusText.Text = $"工作区自动保存失败：{args.Exception.Message}");
    }

    private static string FormatMetric(double value)
    {
        return NumericDisplayFormatter.Format(value);
    }

    private void ConfigureDisplaySettings()
    {
        _settings.NormalizeDisplaySettings();
        NumericDisplayFormatter.Configure(new NumericDisplayOptions(
            _settings.DecimalPlaces,
            _settings.UpperScientificExponent,
            _settings.LowerScientificExponent));
        DisplayTypography.Configure(_settings);
    }

    private async Task ShowDisplaySettingsAsync()
    {
        var dialog = new DisplaySettingsWindow(_settings);
        if (!await dialog.ShowDialog<bool>(this))
        {
            return;
        }

        var previousFontSize = DisplayTypography.FontSize;
        ConfigureDisplaySettings();
        ApplyTheme(save: false);
        DisplayTypography.ApplyRecursively(this, previousFontSize);
        _laboratories?.ApplyDisplaySettings(previousFontSize);
        _panels.ApplyDisplaySettings(previousFontSize);
        RefreshStatus();
        InvalidateVisual();
    }

    private void ApplyTheme(bool save = true)
    {
        ((App)Avalonia.Application.Current!).ApplyTheme(_settings.Theme);
        if (save && !_settings.TrySave(out var errorMessage))
        {
            _statusText.Text = $"主题已应用；设置未保存：{errorMessage}";
        }
    }

    private static IBrush ThemeBrush(Control control, string key) =>
        control.TryFindResource(key, control.ActualThemeVariant, out var value)
        && value is IBrush brush
            ? brush
            : Brushes.Transparent;

    private async Task ResetLayout()
    {
        if (!await ConfirmUnsavedToleranceChangesAsync("重置工作区布局"))
        {
            return;
        }

        Width = 1440;
        Height = 900;
        _panels.ResetLayout();
        SaveLayout();
    }

    private Task SaveLayoutSlot(int slot)
    {
        return _panels.SaveLayoutSlotAsync(slot);
    }

    private async Task LoadLayoutSlot(int slot)
    {
        if (!await ConfirmUnsavedToleranceChangesAsync($"加载布局槽位 {slot}"))
        {
            return;
        }

        await _panels.LoadLayoutSlotAsync(slot);
        SaveLayout();
    }

    private async Task RestoreDefaultLayoutAsync()
    {
        if (!await ConfirmUnsavedToleranceChangesAsync("载入已保存的默认布局"))
        {
            return;
        }

        await _panels.RestoreDefaultLayoutAsync();
        SaveLayout();
    }

    private Task<bool> ConfirmUnsavedToleranceChangesAsync(string operationDescription)
    {
        return UnsavedChangesGuard.CanContinueAsync(
            _panels.HasUnsavedToleranceChanges,
            () => new UnsavedChangesWindow(operationDescription)
                .ShowDialog<UnsavedChangesChoice>(this),
            () => _panels.SaveUnsavedToleranceChangesAsync(this));
    }

    private async Task ShowCommandPaletteAsync()
    {
        await new CommandPaletteWindow(_actions).ShowDialog(this);
    }

    private void SaveLayout()
    {
        _settings.WindowWidth = Math.Max(MinWidth, Width);
        _settings.WindowHeight = Math.Max(MinHeight, Height);
        _settings.ApplyLayout(_panels.CaptureLayout());
        if (!_settings.TrySave(out var errorMessage))
        {
            _statusText.Text = $"布局未保存：{errorMessage}";
        }
    }

    private MenuItem MenuItem(AppAction action)
    {
        var item = new MenuItem { Header = action.Text };
        item.Click += async (_, _) => await _actions.ExecuteAsync(action);
        return item;
    }

    private async void OnActionExecutionFailed(object? sender, ActionExecutionFailedEventArgs args)
    {
        if (_closed || _closeInProgress)
        {
            return;
        }

        var dialog = new Window
        {
            Title = "操作失败",
            Width = 560,
            Height = 260,
            MinWidth = 420,
            MinHeight = 220,
            WindowStartupLocation = WindowStartupLocation.CenterOwner
        };
        var closeButton = new Button
        {
            Content = "关闭",
            MinWidth = 88,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        closeButton.Click += (_, _) => dialog.Close();
        dialog.Content = new StackPanel
        {
            Margin = new Thickness(20),
            Spacing = 12,
            Children =
            {
                new TextBlock
                {
                    Text = args.Action.Text,
                    FontWeight = FontWeight.SemiBold
                },
                new TextBox
                {
                    Text = args.Exception.Message,
                    IsReadOnly = true,
                    AcceptsReturn = true,
                    TextWrapping = TextWrapping.Wrap,
                    MinHeight = 120
                },
                closeButton
            }
        };
        try
        {
            await dialog.ShowDialog(this);
        }
        catch (Exception exception)
        {
            if (!_closed)
            {
                _statusText.Text = $"操作失败：{args.Exception.Message}；错误窗口未能显示：{exception.Message}";
            }
        }
    }
}
