using System.Globalization;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Shapes;
using Avalonia.Layout;
using Avalonia.LogicalTree;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.Core.FileIO;

namespace OpticalSystemDesign.App.Laboratories.CoatingDesign;

public sealed partial class MainWindow
{
    private readonly List<(CoatingQuantity Quantity, ToggleButton Button)> _curveButtons = [];
    private readonly TextBlock _plotStatus = new() { TextWrapping = TextWrapping.Wrap };
    private Button? _plotPng, _plotRefresh;

    private Control BuildSpectrumToolbar()
    {
        var commands = new WrapPanel();
        foreach (var quantity in Enum.GetValues<CoatingQuantity>())
        {
            var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 2 };
            row.Children.Add(new Ellipse { Fill = SpectrumPlot.CurveBrush(quantity), Width = 8, Height = 8, Margin = new Thickness(2, 0, 4, 0), VerticalAlignment = VerticalAlignment.Center });
            row.Children.Add(new TextBlock { Text = quantity.ToString(), FontWeight = FontWeight.Bold, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 4, 0) });
            foreach (var polarization in Enum.GetValues<CoatingCurvePolarization>())
            {
                var label = polarization == CoatingCurvePolarization.Average ? "平均" : polarization == CoatingCurvePolarization.S ? "s" : "p";
                var button = new ToggleButton { Content = label, IsChecked = polarization == CoatingCurvePolarization.Average };
                button.Classes.Add("coating-curve");
                AutomationProperties.SetName(button, $"{quantity} {label}");
                ToolTip.SetTip(button, polarization == CoatingCurvePolarization.Average ? "平均 = (s + p) / 2；不是波段平均" : polarization == CoatingCurvePolarization.S ? "s 偏振 · 虚线" : "p 偏振 · 点线");
                button.Tag = ToolTip.GetTip(button);
                button.IsCheckedChanged += (_, _) => _plot.SetCurveVisible(quantity, polarization, button.IsChecked == true);
                row.Children.Add(button); _curveButtons.Add((quantity, button));
            }
            var group = new Border { Child = row, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(6), Padding = new Thickness(5, 2), Margin = new Thickness(0, 0, 6, 4) };
            group.BindThemeResource(Border.BackgroundProperty, ThemeResourceBindings.SubtleSurface);
            group.BindThemeResource(Border.BorderBrushProperty, ThemeResourceBindings.Border);
            commands.Children.Add(group);
        }
        var targets = new ToggleButton { Content = ToolContent("target", "目标"), IsChecked = true };
        targets.Classes.Add("coating-plot-tool"); AutomationProperties.SetName(targets, "显示目标线");
        ToolTip.SetTip(targets, "显示原设计目标，不改变验收偏振");
        targets.IsCheckedChanged += (_, _) => _plot.SetTargets(targets.IsChecked == true);
        commands.Children.Add(targets);
        var edit = PlotButton("编辑设计目标", "pencil", async () => await Guard(() => ShowSettingsAsync(0)), "编辑");
        commands.Children.Add(edit);
        var settings = new DropDownButton { Content = ToolContent("settings", "设置"), Flyout = PlotSettingsFlyout() };
        settings.Classes.Add("coating-plot-tool"); AutomationProperties.SetName(settings, "光谱图设置");
        ToolTip.SetTip(settings, "光谱显示范围、网格与纵轴设置"); commands.Children.Add(settings);

        var tools = new WrapPanel();
        _plotPng = PlotButton("保存光谱 PNG", "camera", () => TrackOperation(ExportSpectrumPngAsync));
        var widthMenu = new MenuFlyout();
        foreach (var (name, scale) in new[] { ("细", 1d), ("标准", 1.5), ("粗", 2d) })
        {
            var item = new MenuItem { Header = UiLocalization.Text(name), Tag = name, ToggleType = MenuItemToggleType.Radio, IsChecked = scale == 1.5 };
            item.Click += (_, _) => { _plot.SetCurveWidth(scale); foreach (var choice in widthMenu.Items.OfType<MenuItem>()) choice.IsChecked = ReferenceEquals(choice, item); };
            widthMenu.Items.Add(item);
        }
        widthMenu.Opening += (_, _) => { foreach (var item in widthMenu.Items.OfType<MenuItem>()) item.Header = UiLocalization.Text((string)item.Tag!); };
        var lineWidth = new DropDownButton { Content = "线宽", Flyout = widthMenu };
        lineWidth.Classes.Add("coating-plot-tool"); AutomationProperties.SetName(lineWidth, "光谱线宽");
        ToolTip.SetTip(lineWidth, "曲线线宽：细、标准、粗");
        tools.Children.Add(new StackPanel { Orientation = Orientation.Horizontal, Children = { _plotPng, lineWidth } });
        _plotRefresh = PlotButton("刷新光谱", "refresh-cw", () => TrackOperation(() => RunAsync("evaluate")));
        tools.Children.Add(_plotRefresh);
        tools.Children.Add(PlotButton("重置光谱视图", "maximize", () => { _plot.ResetView(); return Task.CompletedTask; }));
        var header = new StackPanel { Spacing = 2, Children = { commands, tools } };
        var curveStyle = new Style(s => s.OfType<ToggleButton>().Class("coating-curve"));
        curveStyle.Setters.Add(new Setter(PaddingProperty, new Thickness(5, 2)));
        curveStyle.Setters.Add(new Setter(MinHeightProperty, 24d));
        curveStyle.Setters.Add(new Setter(BorderThicknessProperty, new Thickness(0)));
        curveStyle.Setters.Add(new Setter(CornerRadiusProperty, new CornerRadius(4)));
        header.Styles.Add(curveStyle);
        var uncheckedStyle = new Style(s => s.OfType<ToggleButton>().Class("coating-curve").Not(x => x.Class(":checked")));
        uncheckedStyle.Setters.Add(new Setter(BackgroundProperty, Brushes.Transparent));
        uncheckedStyle.Setters.Add(new Setter(ForegroundProperty, new DynamicResourceExtension(ThemeResourceBindings.TextMuted)));
        header.Styles.Add(uncheckedStyle);
        var checkedStyle = new Style(s => s.OfType<ToggleButton>().Class("coating-curve").Class(":checked"));
        checkedStyle.Setters.Add(new Setter(BackgroundProperty, new DynamicResourceExtension(ThemeResourceBindings.SelectionBackground)));
        checkedStyle.Setters.Add(new Setter(ForegroundProperty, new DynamicResourceExtension(ThemeResourceBindings.TextPrimary)));
        header.Styles.Add(checkedStyle);
        var toolStyle = new Style(s => s.Is<Button>().Class("coating-plot-tool"));
        toolStyle.Setters.Add(new Setter(MinHeightProperty, 28d));
        toolStyle.Setters.Add(new Setter(PaddingProperty, new Thickness(7, 4)));
        toolStyle.Setters.Add(new Setter(MarginProperty, new Thickness(0, 0, 4, 4)));
        header.Styles.Add(toolStyle);
        _plotStatus.BindThemeResource(TextBlock.ForegroundProperty, ThemeResourceBindings.TextMuted);
        _plotStatus.FontSize = DisplayTypography.Caption;
        _plot.StateChanged += (_, _) => UpdatePlotState();
        UpdatePlotState();
        return header;
    }

    private Button PlotButton(string name, string icon, Func<Task> action, string? text = null)
    {
        var button = new Button { Content = text is null ? ToolContent(icon, "") : ToolContent(icon, text) };
        button.Classes.Add("coating-plot-tool"); AutomationProperties.SetName(button, name); ToolTip.SetTip(button, name);
        button.Click += async (_, _) => await Guard(action); return button;
    }
    private void UpdatePlotState()
    {
        foreach (var (quantity, button) in _curveButtons)
        {
            button.IsEnabled = !_plot.OpticalDensity || quantity == CoatingQuantity.T;
            ToolTip.SetTip(button, button.IsEnabled ? button.Tag : "OD 只显示透射曲线，R/A 选择会保留。");
            AutomationProperties.SetHelpText(button, button.IsEnabled ? "" : "OD 只显示透射曲线，R/A 选择会保留。");
        }
        if (_plotPng is not null)
        {
            _plotPng.IsEnabled = _plot.HasData && !_plot.IsPreparing;
            ToolTip.SetTip(_plotPng, _plotPng.IsEnabled ? "保存光谱 PNG" : "请先计算当前输入的平均 / s / p 光谱");
            AutomationProperties.SetHelpText(_plotPng, _plotPng.IsEnabled ? "" : "请先计算当前输入的平均 / s / p 光谱");
        }
        if (_plotRefresh is not null) _plotRefresh.IsEnabled = !_busy;
        var polarization = _session.Current.Target.Polarization.ToString();
        if (polarization == "Unpolarized") polarization = UiLocalization.Text("平均");
        _plotStatus.Text = _plot.DisplayError ?? (_plot.IsPreparing ? UiLocalization.Text("正在计算平均 / s / p 显示光谱…")
            : $"{UiLocalization.Text("结果")} · {_plot.SampleCount:N0} {UiLocalization.Text("点")}    {_session.Current.Target.AngleDegrees:G5}° · {UiLocalization.Text("验收偏振")}：{polarization}    "
                + (_plot.OpticalDensity ? "OD ≤ 12（图形）" : "s — —   p · · ·"));
        ToolTip.SetTip(_plotStatus, "显示光谱沿用原复验网格；其它偏振未作独立收敛认证。验收仍采用原设计偏振。");
    }
    private Flyout PlotSettingsFlyout()
    {
        var rangeEditors = new TextBox[4];
        var mode = new ComboBox { ItemsSource = new[] { "R / T / A (%)", "截止深度 OD" }, SelectedIndex = 0, HorizontalAlignment = HorizontalAlignment.Stretch };
        AutomationProperties.SetName(mode, "光谱纵轴");
        var grid = new CheckBox { Content = "网格", IsChecked = true };
        AutomationProperties.SetName(grid, "光谱网格");
        var error = new TextBlock { TextWrapping = TextWrapping.Wrap };
        error.BindThemeResource(TextBlock.ForegroundProperty, ThemeResourceBindings.TextError);
        var panel = new StackPanel { Width = 280, Spacing = 10 };
        panel.Children.Add(new TextBlock { Text = "图表设置", Tag = "图表设置", FontWeight = FontWeight.SemiBold });
        panel.Children.Add(mode); panel.Children.Add(grid);
        foreach (var (label, index) in new[] { ("波长下限 (nm)", 0), ("波长上限 (nm)", 1), ("纵轴下限", 2), ("纵轴上限", 3) })
        {
            var box = rangeEditors[index] = new TextBox(); AutomationProperties.SetName(box, "光谱" + label);
            var row = new Grid { ColumnDefinitions = new("130,*"), ColumnSpacing = 10 };
            row.Children.Add(new TextBlock { Text = label, Tag = label, VerticalAlignment = VerticalAlignment.Center });
            Grid.SetColumn(box, 1); row.Children.Add(box); panel.Children.Add(row);
        }
        panel.Children.Add(new TextBlock { Text = "仅调整显示范围；扩展波段请编辑设计目标并复验。", Tag = "仅调整显示范围；扩展波段请编辑设计目标并复验。", TextWrapping = TextWrapping.Wrap });
        panel.Children.Add(error);
        var apply = new Button { Content = UiLocalization.Text("应用"), HorizontalAlignment = HorizontalAlignment.Right };
        AutomationProperties.SetName(apply, "应用光谱设置"); panel.Children.Add(apply);
        var flyout = new Flyout { Content = panel };
        void Values()
        {
            var r = _plot.Range;
            var values = new[] { r.MinimumNm, r.MaximumNm, r.MinimumY, r.MaximumY };
            for (var i = 0; i < values.Length; i++) rangeEditors[i].Text = values[i].ToString("G17", CultureInfo.CurrentCulture);
        }
        mode.SelectionChanged += (_, _) => { _plot.SetOpticalDensity(mode.SelectedIndex == 1); Values(); };
        grid.IsCheckedChanged += (_, _) => _plot.SetGrid(grid.IsChecked == true);
        flyout.Opening += (_, _) =>
        {
            error.Text = "";
            foreach (var label in panel.GetLogicalDescendants().OfType<TextBlock>().Where(t => t.Tag is string)) label.Text = UiLocalization.Text((string)label.Tag!);
            grid.Content = UiLocalization.Text("网格"); apply.Content = UiLocalization.Text("应用");
            mode.SelectedIndex = _plot.OpticalDensity ? 1 : 0; grid.IsChecked = _plot.ShowGrid; Values();
        };
        apply.Click += (_, _) =>
        {
            try
            {
                var values = rangeEditors.Select(b => double.TryParse(b.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out var v) ? v : double.NaN).ToArray();
                _plot.ApplyRange(new(values[0], values[1], values[2], values[3])); flyout.Hide();
            }
            catch (ArgumentException exception) { error.Text = UiLocalization.Text(exception.Message); }
        };
        return flyout;
    }
    private async Task ExportSpectrumPngAsync()
    {
        var bytes = _plot.CapturePng(); // Freeze the current view before the picker.
        string? path;
        if (_dialogs is not null) { var directory = await _dialogs.ExportDirectory(); path = directory is null ? null : System.IO.Path.Combine(directory, "coating-spectrum.png"); }
        else
        {
            var file = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            { Title = "保存光谱 PNG", SuggestedFileName = "coating-spectrum.png", DefaultExtension = "png", FileTypeChoices = [new FilePickerFileType("PNG") { Patterns = ["*.png"] }] });
            path = file?.TryGetLocalPath();
        }
        if (path is null) return;
        await BoundedFile.WriteAllBytesAtomicAsync(path, bytes, BoundedFile.MaximumImageDataBytes, "镀膜光谱 PNG");
        _status.Text = "光谱图已保存：" + path;
    }
}
