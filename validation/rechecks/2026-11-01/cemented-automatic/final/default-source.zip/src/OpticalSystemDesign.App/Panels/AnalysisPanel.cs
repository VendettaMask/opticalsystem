using System.Globalization;
using System.Reflection;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Data;
using Avalonia.Input.Platform;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using Avalonia.VisualTree;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.Application.Contracts;
using OpticalSystemDesign.Application.Formatting;

namespace OpticalSystemDesign.App.Panels;

public sealed partial class AnalysisPanel : UserControl, IDisposable, IDisplaySettingsAware
{
    private readonly IAnalysisService _analyses;
    private readonly IVisualizationService _visualization;
    private readonly IOpticalDocumentService _documents;
    private readonly IWorkspaceEventStream _events;
    private readonly AppSettings _appSettings;
    private readonly Dictionary<string, Control> _parameterControls = new();
    private readonly StackPanel _parameterPanel = new()
    {
        VerticalAlignment = VerticalAlignment.Top,
        HorizontalAlignment = HorizontalAlignment.Left
    };
    private readonly ContentControl _resultHost = new();
    private readonly OperationStatusBar _operationStatus = new();
    private readonly Button _syncButton;
    private readonly Button _exportImageButton;
    private readonly DropDownButton _curveWidthButton;
    private readonly Border _settingsHost;
    private readonly CheckBox _parameterAutoApply = new()
    {
        Content = "自动应用",
        IsChecked = true,
        VerticalAlignment = VerticalAlignment.Center
    };
    private readonly DispatcherTimer _automaticRefreshTimer = new()
    {
        Interval = TimeSpan.FromMilliseconds(180)
    };
    private CancellationTokenSource? _runCancellation;
    private AnalysisViewDto? _view;
    private long? _displayedSourceRevision;
    private Dictionary<string, string> _settings;
    private int _generation;
    private bool _locked;
    private bool _isRunning;
    private bool _initialRunRequested;
    private bool _disposed;

    public AnalysisPanel(
        IAnalysisService analyses,
        IVisualizationService visualization,
        IOpticalDocumentService documents,
        IWorkspaceEventStream events,
        AppSettings appSettings,
        string analysisName,
        Guid? instanceId = null,
        IReadOnlyDictionary<string, string>? initialSettings = null)
    {
        _analyses = analyses;
        _visualization = visualization;
        _documents = documents;
        _events = events;
        _appSettings = appSettings;
        AnalysisName = analysisName;
        AnalysisKey = analyses.CanonicalKey(analysisName);
        InstanceId = instanceId ?? Guid.NewGuid();
        _settings = analyses.MergeSettings(
            analysisName,
            initialSettings ?? SavedAnalysisSettings());
        _automaticRefreshTimer.Tick += OnAutomaticRefreshTimerTick;

        _syncButton = IconButton("refresh-cw", "同步当前设置并重新运行");
        _syncButton.Click += async (_, _) => await RunAsync();
        var copyButton = CommandButton("clipboard-copy", "复制文本", 96);
        copyButton.Click += async (_, _) => await CopyReportAsync();
        var exportButton = CommandButton("upload", "导出文本", 96);
        exportButton.Click += async (_, _) => await ExportReportAsync();
        _exportImageButton = IconButton("camera", "导出图片（PNG）");
        _exportImageButton.Name = "ExportAnalysisImage";
        _exportImageButton.IsVisible = false;
        _exportImageButton.Click += async (_, _) => await ExportImageAsync();
        _curveWidthButton = CreateCurveWidthButton();

        var settingsButton = SettingsPanelChrome.CreateToggleButton();
        _settingsHost = new Border
        {
            IsVisible = false,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Top,
            Margin = new Thickness(12, 0, 12, 0),
            Padding = new Thickness(12, 10),
            Child = new ScrollViewer
            {
                HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled,
                VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto,
                Content = _parameterPanel
            }
        };
        SettingsPanelChrome.ApplyCardStyle(_settingsHost);
        settingsButton.Click += (_, _) =>
        {
            _settingsHost.IsVisible = !_settingsHost.IsVisible;
        };

        var commands = new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            Children =
            {
                settingsButton,
                _syncButton,
                copyButton,
                exportButton,
                _exportImageButton,
                _curveWidthButton,
                _operationStatus
            }
        };
        _syncButton.Margin = new Thickness(2, 0, 0, 0);
        copyButton.Margin = new Thickness(2, 0, 0, 0);
        exportButton.Margin = new Thickness(2, 0, 2, 0);
        _exportImageButton.Margin = new Thickness(2, 0, 2, 0);
        _curveWidthButton.Margin = new Thickness(2, 0, 8, 0);

        var toolbar = new StackPanel
        {
            Margin = new Thickness(12, 10, 12, 8),
            Children = { commands }
        };
        var overlay = new Grid
        {
            ClipToBounds = true,
            Children =
            {
                _resultHost,
                _settingsHost
            }
        };
        var root = new DockPanel();
        DockPanel.SetDock(toolbar, Avalonia.Controls.Dock.Top);
        root.Children.Add(toolbar);
        root.Children.Add(overlay);
        Content = root;

        RebuildParameterPanel();
        _events.Changed += OnWorkspaceChanged;
        AttachedToVisualTree += OnAttachedToVisualTree;
    }

    public Guid InstanceId { get; }

    public string AnalysisName { get; }

    public string AnalysisKey { get; }

    public IReadOnlyDictionary<string, string> Settings => _settings;

    public bool IsLocked
    {
        get => _locked;
        set
        {
            _locked = value;
            if (_isRunning)
            {
                return;
            }

            if (_view is not null && _displayedSourceRevision != _events.Revision)
            {
                _operationStatus.MarkStale(value
                    ? "已锁定：结果已过期，请解锁后同步"
                    : "结果已过期，请同步");
            }
            else if (value)
            {
                _operationStatus.MarkIdle("已锁定：保留当前结果");
            }
            else if (_view is null)
            {
                _operationStatus.MarkIdle("尚未运行");
            }
            else
            {
                _operationStatus.MarkSynced("已同步");
            }
        }
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        _generation++;
        _automaticRefreshTimer.Stop();
        _automaticRefreshTimer.Tick -= OnAutomaticRefreshTimerTick;
        _events.Changed -= OnWorkspaceChanged;
        AttachedToVisualTree -= OnAttachedToVisualTree;
        _runCancellation?.Cancel();
        _runCancellation?.Dispose();
        _operationStatus.Dispose();
    }

    public void RefreshDisplaySettings()
    {
        _ = RunAsync();
    }

    internal async Task<bool> RunForGuiCaptureAsync()
    {
        _parameterAutoApply.IsChecked = false;
        _automaticRefreshTimer.Stop();
        _initialRunRequested = true;
        await RunAsync();
        return _view is not null;
    }

    private async Task RunAsync()
    {
        if (_disposed)
        {
            return;
        }

        string? settingsPersistenceWarning;
        try
        {
            _settings = CaptureParameterSettings();
            settingsPersistenceWarning = SaveAnalysisSettings();
        }
        catch (Exception exception)
        {
            _operationStatus.MarkFailed($"分析设置无效：{exception.Message}");
            return;
        }

        _runCancellation?.Cancel();
        _runCancellation?.Dispose();
        _runCancellation = new CancellationTokenSource();
        var cancellationToken = _runCancellation.Token;
        var generation = ++_generation;
        _isRunning = true;
        UpdateImageExportButton();
        _syncButton.IsEnabled = true;
        _operationStatus.Start("正在计算…", () => _runCancellation?.Cancel());

        try
        {
            var result = await _analyses.RunAsync(
                new AnalysisRequestDto(InstanceId, generation, AnalysisKey, _settings),
                cancellationToken);
            var cardinalScene = result.ReferenceScene ?? (IsCardinalPointsView(result.View)
                ? await _visualization.BuildSceneAsync(
                    new VisualizationRequestDto(
                        SceneDimension.TwoDimensional,
                        IncludeAllWavelengths: false,
                        RayCount: 3,
                        LowerPupil: -1,
                        UpperPupil: 1,
                        MarginalAndChiefOnly: true),
                    cancellationToken)
                : null);
            if (_disposed
                || cancellationToken.IsCancellationRequested
                || result.InstanceId != InstanceId
                || result.Generation != _generation)
            {
                return;
            }

            await Dispatcher.UIThread.InvokeAsync(() =>
            {
                if (result.SourceRevision != _events.Revision)
                {
                    _operationStatus.MarkStale("结果已过期，请同步");
                    return;
                }

                if (_displayedSourceRevision is long displayedRevision
                    && displayedRevision != result.SourceRevision)
                {
                    ResetInteractiveViewState(_resultHost.Content as Control);
                }

                PresentResult(
                    result.View,
                    result.SourceDocument ?? _documents.GetSnapshot(),
                    DateTimeOffset.Now,
                    cardinalScene);
                _displayedSourceRevision = result.SourceRevision;
                if (_locked)
                {
                    _operationStatus.MarkIdle("已锁定：保留当前结果");
                }
                else
                {
                    _operationStatus.MarkSynced(settingsPersistenceWarning is null
                        ? "已同步"
                        : $"已同步；设置未保存：{settingsPersistenceWarning}");
                }
            });
        }
        catch (OperationCanceledException)
        {
            if (!_disposed && generation == _generation)
            {
                await Dispatcher.UIThread.InvokeAsync(() =>
                {
                    _operationStatus.MarkStale("已取消，请同步");
                });
            }
        }
        catch (Exception exception)
        {
            if (_disposed || generation != _generation)
            {
                return;
            }

            await Dispatcher.UIThread.InvokeAsync(() =>
            {
                _view = null;
                _displayedSourceRevision = null;
                _resultHost.Content = BuildAnalysisErrorContent(exception.Message);
                UpdateImageExportButton();
                _operationStatus.MarkFailed($"分析失败：{exception.Message}");
            });
        }
        finally
        {
            if (!_disposed && generation == _generation)
            {
                await Dispatcher.UIThread.InvokeAsync(() =>
                {
                    _isRunning = false;
                    _syncButton.IsEnabled = true;
                    UpdateImageExportButton();
                });
            }
        }
    }

    private void OnAttachedToVisualTree(object? sender, VisualTreeAttachmentEventArgs args)
    {
        if (_initialRunRequested || _disposed)
        {
            return;
        }

        _initialRunRequested = true;
        _ = RunAsync();
    }

    private void OnWorkspaceChanged(object? sender, WorkspaceChangedEventArgs args)
    {
        if (args.FileSwitched)
        {
            _runCancellation?.Cancel();
        }

        Dispatcher.UIThread.Post(() =>
        {
            if (_disposed)
            {
                return;
            }

            if (_displayedSourceRevision is long displayedRevision
                && displayedRevision != args.Revision)
            {
                ResetInteractiveViewState(_resultHost.Content as Control);
            }

            if (args.FileSwitched)
            {
                _automaticRefreshTimer.Stop();
                _view = null;
                _displayedSourceRevision = null;
                _resultHost.Content = null;
                UpdateImageExportButton();
                RefreshConfigurationParameters();
                _operationStatus.MarkStale("文件已切换，请同步");
                return;
            }

            if (args.Category is WorkspaceChangeCategory.Configuration or WorkspaceChangeCategory.Field
                or WorkspaceChangeCategory.Wavelength or WorkspaceChangeCategory.SystemSettings)
                RefreshConfigurationParameters();

            if (_locked)
            {
                if (_view is not null && _displayedSourceRevision != _events.Revision)
                {
                    _operationStatus.MarkStale("已锁定：结果已过期，请解锁后同步");
                }
                return;
            }

            if (args.Category is WorkspaceChangeCategory.SystemSettings
                or WorkspaceChangeCategory.Field
                or WorkspaceChangeCategory.Wavelength
                or WorkspaceChangeCategory.Configuration)
            {
                _operationStatus.MarkStale("系统设置已变化，正在自动刷新…");
                _automaticRefreshTimer.Stop();
                _automaticRefreshTimer.Start();
            }
            else if (_view is not null)
            {
                _operationStatus.MarkStale("结果已过期，请同步");
            }
        });
    }

    internal static int ResetInteractiveViewState(Control? root)
    {
        if (root is null)
        {
            return 0;
        }

        var resetCount = 0;
        foreach (var control in root.GetVisualDescendants().OfType<Control>().Prepend(root))
        {
            switch (control)
            {
                case AnalysisPlotControl plot:
                    plot.ResetView();
                    resetCount++;
                    break;
                case WavefrontSurfaceControl surface:
                    surface.ResetView();
                    resetCount++;
                    break;
                case OpticSceneControl scene:
                    scene.ResetView();
                    resetCount++;
                    break;
            }
        }

        return resetCount;
    }

    private async void OnAutomaticRefreshTimerTick(object? sender, EventArgs args)
    {
        _automaticRefreshTimer.Stop();
        if (!_disposed && !_locked)
        {
            await RunAsync();
        }
    }

}
