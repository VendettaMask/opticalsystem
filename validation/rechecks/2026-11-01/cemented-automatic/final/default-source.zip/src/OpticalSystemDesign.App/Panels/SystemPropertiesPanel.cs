using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Templates;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Media;
using Avalonia.Styling;
using Avalonia.Threading;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.App.Theming;
using OpticalSystemDesign.Application.Contracts;
using OpticalSystemDesign.Application.Formatting;

namespace OpticalSystemDesign.App.Panels;

public sealed partial class SystemPropertiesPanel : UserControl, IDisposable, IDisplaySettingsAware
{
    private readonly IPrescriptionService _prescription;
    private readonly IMaterialCatalogService _materials;
    private readonly IWorkspaceEventStream _events;
    private readonly StackPanel _fieldsHost = new() { Spacing = 5 };
    private readonly StackPanel _wavelengthsHost = new() { Spacing = 5 };
    private readonly HashSet<int> _expandedFields = new();
    private readonly HashSet<int> _expandedWavelengths = new();
    private readonly ComboBox _backendPicker = new();
    private readonly ComboBox _apertureKindPicker = new();
    private readonly ComboBox _fieldDefinitionPicker = new();
    private readonly CheckBox _objectSpaceTelecentric = new()
    {
        Content = "物方远心",
        VerticalAlignment = VerticalAlignment.Center
    };
    private readonly CheckBox _imageSpaceAfocal = new()
    {
        Content = "像方无焦",
        VerticalAlignment = VerticalAlignment.Center
    };
    private readonly ComboBox _apodizationPicker = new();
    private readonly TextBlock _firstApodizationLabel = ParameterLabel("σ");
    private readonly TextBlock _secondApodizationLabel = ParameterLabel("p");
    private readonly NumericUpDown _firstApodizationParameter = ParameterInput(1m);
    private readonly NumericUpDown _secondApodizationParameter = ParameterInput(1m);
    private readonly DispatcherTimer _systemUpdateTimer = new() { Interval = TimeSpan.FromMilliseconds(120) };
    private readonly DispatcherTimer _environmentUpdateTimer = new() { Interval = TimeSpan.FromMilliseconds(120) };
    private readonly CheckBox _matchRefractiveIndexData = new()
    {
        Content = "折射率数据与环境匹配",
        IsChecked = true
    };
    private readonly NumericUpDown _temperatureCelsius = NumberInput(20.0, -273.15, 10_000, 0.1);
    private readonly NumericUpDown _pressureAtmospheres = NumberInput(1.0, 0.0001, 10_000, 0.1);
    private readonly ListBox _currentGlassCatalogs = new()
    {
        Height = 130,
        HorizontalAlignment = HorizontalAlignment.Stretch
    };
    private readonly ListBox _availableGlassCatalogs = new()
    {
        Height = 210,
        HorizontalAlignment = HorizontalAlignment.Stretch
    };
    private readonly Button _addGlassCatalog = CommandButton("arrow-up", "加入当前", 108);
    private readonly Button _removeGlassCatalog = CommandButton("arrow-down", "移出当前", 108);
    private readonly Button _moveGlassCatalogUp = CommandButton("chevron-up", "优先级上移", 118);
    private readonly Button _moveGlassCatalogDown = CommandButton("chevron-down", "优先级下移", 118);
    private Grid? _apodizationParameterRow;
    private bool _refreshing;
    private bool _applyingLocalChange;
    private readonly NumericUpDown _apertureValue = new()
    {
        Minimum = 0.001m,
        Maximum = 1_000_000m,
        Increment = 1m,
        Value = 14m,
        Width = 110
    };

    private bool _disposed;

    public SystemPropertiesPanel(
        IPrescriptionService prescription,
        IMaterialCatalogService materials,
        IWorkspaceEventStream events)
    {
        _prescription = prescription;
        _materials = materials;
        _events = events;
        SettingsPanelChrome.ApplyInputStyles(this);
        _systemUpdateTimer.Tick += OnSystemUpdateTimerTick;
        _environmentUpdateTimer.Tick += OnEnvironmentUpdateTimerTick;
        ConfigurePickers();
        ConfigureEnvironmentControls();
        ConfigureGlassCatalogControls();

        var addField = CommandButton("plus", "添加视场", 96);
        addField.Click += (_, _) => _prescription.AddField();
        var addWavelength = CommandButton("plus", "添加波长", 112);
        addWavelength.Click += (_, _) => _prescription.AddWavelength();

        var sections = new StackPanel
        {
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Children =
            {
                Section("系统孔径", "aperture", BuildApertureSection(), expanded: true),
                Section("视场", "focus", BuildFieldSection(addField), expanded: true),
                Section("波长", "activity", BuildWavelengthSection(addWavelength)),
                Section("偏振", "disc-2", BuildPolarizationSection()),
                Section("材料库", "database", BuildMaterialLibrarySection()),
                Section("环境", "settings", BuildEnvironmentSection()),
                Section("高级", "sliders-horizontal", BuildAdvancedSection())
            }
        };
        sections.Classes.Add("system-property-sections");
        sections.Bind(StackPanel.MarginProperty, new DynamicResourceExtension(ThemeLayoutResources.SystemSectionsMargin));
        sections.Bind(StackPanel.SpacingProperty, new DynamicResourceExtension(ThemeLayoutResources.SystemSectionSpacing));
        var scrollViewer = new ScrollViewer
        {
            HorizontalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled,
            // Hide the rail without disabling wheel, keyboard or focus scrolling.
            VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Hidden,
            Content = sections
        };
        scrollViewer.BindThemeResource(ScrollViewer.BackgroundProperty, ThemeResourceBindings.Sidebar);
        Content = scrollViewer;

        _events.Changed += OnWorkspaceChanged;
        Refresh();
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        _systemUpdateTimer.Stop();
        _systemUpdateTimer.Tick -= OnSystemUpdateTimerTick;
        _environmentUpdateTimer.Stop();
        _environmentUpdateTimer.Tick -= OnEnvironmentUpdateTimerTick;
        _events.Changed -= OnWorkspaceChanged;
    }

    public void RefreshDisplaySettings() => Refresh();

    private void ConfigureEnvironmentControls()
    {
        _matchRefractiveIndexData.IsCheckedChanged += (_, _) => ScheduleEnvironmentUpdate();
        _temperatureCelsius.ValueChanged += (_, _) => ScheduleEnvironmentUpdate();
        _pressureAtmospheres.ValueChanged += (_, _) => ScheduleEnvironmentUpdate();
    }

    private void ConfigurePickers()
    {
        var options = _prescription.GetOptions();
        _backendPicker.ItemsSource = options.Backends;
        _backendPicker.SelectionChanged += (_, _) => ScheduleSystemUpdate();
        _apertureKindPicker.ItemsSource = options.ApertureKinds;
        _apertureKindPicker.SelectionChanged += (_, _) =>
        {
            UpdateApertureValueState();
            ScheduleSystemUpdate();
        };
        _apertureValue.ValueChanged += (_, _) => ScheduleSystemUpdate();
        _fieldDefinitionPicker.ItemsSource = options.FieldDefinitions;
        _fieldDefinitionPicker.SelectionChanged += (_, _) =>
        {
            _objectSpaceTelecentric.IsEnabled = _fieldDefinitionPicker.SelectedIndex != 0;
            RebuildFieldCards();
            if (!_objectSpaceTelecentric.IsEnabled)
            {
                _objectSpaceTelecentric.IsChecked = false;
            }

            ScheduleSystemUpdate();
        };
        _objectSpaceTelecentric.IsCheckedChanged += (_, _) => ScheduleSystemUpdate();
        _imageSpaceAfocal.IsCheckedChanged += (_, _) => ScheduleSystemUpdate();
        _apodizationPicker.ItemsSource = options.ApodizationKinds;
        // Display the three Zemax names without conflating their persisted keys with legacy models.
        _apodizationPicker.ItemTemplate = new FuncDataTemplate<string>((kind, _) => new TextBlock
        {
            Text = kind switch
            {
                "均匀（Zemax）" => "均匀",
                "高斯（Zemax）" => "高斯",
                "余弦立方（Zemax）" => "余弦立方",
                _ => kind
            }
        });
        _apodizationPicker.SelectionChanged += (_, _) =>
        {
            if (!_refreshing)
            {
                ToolTip.SetTip(_apodizationPicker, null);
                ConfigureApodizationParameters(_apodizationPicker.SelectedItem as string, useDefaults: true);
            }

            ScheduleSystemUpdate();
        };
        _firstApodizationParameter.ValueChanged += (_, _) => ScheduleSystemUpdate();
        _secondApodizationParameter.ValueChanged += (_, _) => ScheduleSystemUpdate();
    }

    private Control BuildApertureSection()
    {
        _apertureValue.Width = double.NaN;
        _apertureValue.HorizontalAlignment = HorizontalAlignment.Stretch;
        _apertureKindPicker.HorizontalAlignment = HorizontalAlignment.Stretch;
        _apodizationPicker.HorizontalAlignment = HorizontalAlignment.Stretch;

        var apodizationParameters = new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            Children =
            {
                _firstApodizationLabel,
                _firstApodizationParameter,
                _secondApodizationLabel,
                _secondApodizationParameter
            }
        };

        var form = Form(
            ("孔径类型", _apertureKindPicker),
            ("孔径值", _apertureValue),
            ("光瞳切趾", _apodizationPicker));
        _apodizationParameterRow = LabeledRow("切趾参数", apodizationParameters);
        form.Children.Add(_apodizationParameterRow);
        return form;
    }

    private Control BuildFieldSection(Button addField)
    {
        _fieldDefinitionPicker.HorizontalAlignment = HorizontalAlignment.Stretch;
        return new StackPanel
        {
            Spacing = 10,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Children =
            {
                Form(
                    ("视场类型", _fieldDefinitionPicker),
                    (string.Empty, _objectSpaceTelecentric),
                    (string.Empty, _imageSpaceAfocal)),
                BuildHeader("视场数据", addField),
                _fieldsHost
            }
        };
    }

    private Control BuildWavelengthSection(Button addWavelength)
    {
        return new StackPanel
        {
            Spacing = 10,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Children =
            {
                BuildHeader("波长数据", addWavelength),
                _wavelengthsHost
            }
        };
    }

    private Control BuildMaterialLibrarySection()
    {
        var currentActions = new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            Margin = new Thickness(0, 0, 0, 4),
            Children =
            {
                _moveGlassCatalogUp,
                _moveGlassCatalogDown,
                _removeGlassCatalog
            }
        };
        var availableActions = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Left,
            Margin = new Thickness(0, 0, 0, 4),
            Children = { _addGlassCatalog }
        };
        return new StackPanel
        {
            Spacing = 10,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Children =
            {
                MaterialLibraryHeader("当前玻璃库"),
                _currentGlassCatalogs,
                currentActions,
                MaterialLibraryHeader("可用玻璃库"),
                _availableGlassCatalogs,
                availableActions,
                MutedText("当前列表按从上到下的顺序解析未指定厂商的玻璃名称；至少保留一个目录。", DisplayTypography.RibbonText)
            }
        };
    }

    private void ConfigureGlassCatalogControls()
    {
        ConfigureGlassCatalogList(_currentGlassCatalogs);
        ConfigureGlassCatalogList(_availableGlassCatalogs);
        ToolTip.SetTip(_addGlassCatalog, "将选中的可用玻璃库加入当前系统。");
        ToolTip.SetTip(_removeGlassCatalog, "将选中的当前玻璃库移回可用列表。");
        ToolTip.SetTip(_moveGlassCatalogUp, "提高当前玻璃库的同名玻璃解析优先级。");
        ToolTip.SetTip(_moveGlassCatalogDown, "降低当前玻璃库的同名玻璃解析优先级。");
        _availableGlassCatalogs.SelectionChanged += (_, _) => UpdateGlassCatalogButtonStates();
        _currentGlassCatalogs.SelectionChanged += (_, _) => UpdateGlassCatalogButtonStates();
        _addGlassCatalog.Click += (_, _) => AddSelectedGlassCatalog();
        _removeGlassCatalog.Click += (_, _) => RemoveSelectedGlassCatalog();
        _moveGlassCatalogUp.Click += (_, _) => MoveSelectedGlassCatalog(-1);
        _moveGlassCatalogDown.Click += (_, _) => MoveSelectedGlassCatalog(1);
    }

    private static void ConfigureGlassCatalogList(ListBox listBox)
    {
        ScrollViewer.SetHorizontalScrollBarVisibility(listBox, Avalonia.Controls.Primitives.ScrollBarVisibility.Disabled);
        // Keep wheel/keyboard scrolling without a scrollbar covering the catalog cards.
        ScrollViewer.SetVerticalScrollBarVisibility(listBox, Avalonia.Controls.Primitives.ScrollBarVisibility.Hidden);
        listBox.ItemTemplate = new FuncDataTemplate<string>((catalog, _) => new TextBlock
        {
            Text = catalog ?? string.Empty,
            FontSize = DisplayTypography.BodySmall,
            FontWeight = FontWeight.SemiBold,
            TextTrimming = TextTrimming.CharacterEllipsis,
            VerticalAlignment = VerticalAlignment.Center
        });
        listBox.Background = Brushes.Transparent;
        listBox.BorderBrush = Brushes.Transparent;
        listBox.BorderThickness = new Thickness(0);
        listBox.Styles.Add(new Style(selector => selector.OfType<ListBoxItem>())
        {
            Setters =
            {
                new Setter(ListBoxItem.MinHeightProperty, 42d),
                new Setter(ListBoxItem.MarginProperty, new Thickness(0, 0, 0, 6)),
                new Setter(ListBoxItem.PaddingProperty, new Thickness(12, 8)),
                new Setter(ListBoxItem.BorderThicknessProperty, new Thickness(1)),
                new Setter(
                    ListBoxItem.CornerRadiusProperty,
                    new DynamicResourceExtension(ThemeChromeResources.CornerRadius(ThemeChromeRole.SurfaceCard))),
                new Setter(
                    ListBoxItem.BackgroundProperty,
                    new DynamicResourceExtension(ThemeResourceBindings.Surface)),
                new Setter(
                    ListBoxItem.BorderBrushProperty,
                    new DynamicResourceExtension(ThemeResourceBindings.Border)),
                new Setter(
                    ListBoxItem.ForegroundProperty,
                    new DynamicResourceExtension(ThemeResourceBindings.TextPrimary))
            }
        });
        listBox.Styles.Add(new Style(selector => selector
            .OfType<ListBoxItem>()
            .Class(":pointerover"))
        {
            Setters =
            {
                new Setter(
                    ListBoxItem.BackgroundProperty,
                    new DynamicResourceExtension(ThemeResourceBindings.Hover)),
                new Setter(
                    ListBoxItem.BorderBrushProperty,
                    new DynamicResourceExtension(ThemeResourceBindings.HoverBorder))
            }
        });
        listBox.Styles.Add(new Style(selector => selector
            .OfType<ListBoxItem>()
            .Class(":selected"))
        {
            Setters =
            {
                new Setter(
                    ListBoxItem.BackgroundProperty,
                    new DynamicResourceExtension(ThemeResourceBindings.SelectionBackground)),
                new Setter(
                    ListBoxItem.BorderBrushProperty,
                    new DynamicResourceExtension(ThemeResourceBindings.SelectionBackground)),
                new Setter(
                    ListBoxItem.ForegroundProperty,
                    new DynamicResourceExtension(ThemeResourceBindings.SelectionForeground))
            }
        });
    }

    private void AddSelectedGlassCatalog()
    {
        if (_availableGlassCatalogs.SelectedItem is not string selected)
        {
            return;
        }

        var current = _prescription.GetGlassCatalogs();
        ApplyLocalChange(() => _prescription.UpdateGlassCatalogs(
            current.Append(selected).Distinct(StringComparer.OrdinalIgnoreCase).ToArray()));
        RefreshGlassCatalogs(selected);
    }

    private void RemoveSelectedGlassCatalog()
    {
        if (_currentGlassCatalogs.SelectedItem is not string selected)
        {
            return;
        }

        var current = _prescription.GetGlassCatalogs();
        if (current.Count <= 1)
        {
            return;
        }

        ApplyLocalChange(() => _prescription.UpdateGlassCatalogs(
            current.Where(name => !name.Equals(selected, StringComparison.OrdinalIgnoreCase)).ToArray()));
        RefreshGlassCatalogs();
        _availableGlassCatalogs.SelectedItem = selected;
    }

    private void MoveSelectedGlassCatalog(int offset)
    {
        if (_currentGlassCatalogs.SelectedItem is not string selected)
        {
            return;
        }

        var current = _prescription.GetGlassCatalogs().ToList();
        var index = current.FindIndex(name =>
            name.Equals(selected, StringComparison.OrdinalIgnoreCase));
        var target = index + offset;
        if (index < 0 || target < 0 || target >= current.Count)
        {
            return;
        }

        (current[index], current[target]) = (current[target], current[index]);
        ApplyLocalChange(() => _prescription.UpdateGlassCatalogs(current));
        RefreshGlassCatalogs(selected);
    }

    private void RefreshGlassCatalogs(string? selectCurrent = null)
    {
        var current = _prescription.GetGlassCatalogs();
        var currentNames = current.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var available = _materials.GetCatalogNames()
            .Where(name => !currentNames.Contains(name))
            .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
            .ToArray();
        _currentGlassCatalogs.ItemsSource = current.ToArray();
        _availableGlassCatalogs.ItemsSource = available;
        _currentGlassCatalogs.SelectedItem = selectCurrent;
        UpdateGlassCatalogButtonStates();
    }

    private void UpdateGlassCatalogButtonStates()
    {
        _addGlassCatalog.IsEnabled = _availableGlassCatalogs.SelectedItem is string;
        _removeGlassCatalog.IsEnabled = _currentGlassCatalogs.SelectedItem is string
            && _prescription.GetGlassCatalogs().Count > 1;
        var current = _prescription.GetGlassCatalogs();
        var selectedIndex = _currentGlassCatalogs.SelectedItem is string selected
            ? current.ToList().FindIndex(name =>
                name.Equals(selected, StringComparison.OrdinalIgnoreCase))
            : -1;
        _moveGlassCatalogUp.IsEnabled = selectedIndex > 0;
        _moveGlassCatalogDown.IsEnabled = selectedIndex >= 0
            && selectedIndex < current.Count - 1;
    }

    private Control BuildAdvancedSection()
    {
        _backendPicker.HorizontalAlignment = HorizontalAlignment.Stretch;
        return Form(("计算后端", _backendPicker));
    }

    private static StackPanel Form(params (string Label, Control Input)[] rows)
    {
        var panel = new StackPanel
        {
            Spacing = 8,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        foreach (var row in rows)
        {
            if (string.IsNullOrWhiteSpace(row.Label))
            {
                panel.Children.Add(row.Input);
                continue;
            }

            panel.Children.Add(LabeledRow(row.Label, row.Input));
        }

        return panel;
    }

    private static Grid LabeledRow(string label, Control input)
    {
        input.HorizontalAlignment = HorizontalAlignment.Stretch;
        var text = new TextBlock
        {
            Text = label,
            FontSize = DisplayTypography.BodySmall,
            TextWrapping = TextWrapping.Wrap,
            VerticalAlignment = VerticalAlignment.Center
        };
        text.Bind(TextBlock.FontWeightProperty, new DynamicResourceExtension(ThemeLayoutResources.SystemLabelFontWeight));
        ToolTip.SetTip(text, label);
        var row = new Grid
        {
            ColumnDefinitions = new ColumnDefinitions("70,*"),
            ColumnSpacing = 6,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Children = { text, input }
        };
        Grid.SetColumn(input, 1);
        return row;
    }

    private static TextBlock MaterialLibraryHeader(string title) => new()
    {
        Text = title,
        FontSize = DisplayTypography.BodySmall,
        FontWeight = FontWeight.SemiBold
    };

    private static Control Section(string title, string iconName, Control content, bool expanded = false)
    {
        var arrow = new LocalIcon
        {
            IconName = "chevron-right",
            Width = 18,
            Height = 18,
            VerticalAlignment = VerticalAlignment.Center
        };
        var titleText = new TextBlock
        {
            Text = title,
            FontSize = DisplayTypography.BodySmall,
            FontWeight = FontWeight.SemiBold,
            VerticalAlignment = VerticalAlignment.Center
        };
        var sectionIcon = new LocalIcon { IconName = iconName, Width = 18, Height = 18, VerticalAlignment = VerticalAlignment.Center };
        sectionIcon.BindThemeResource(LocalIcon.StrokeProperty, ThemeResourceBindings.TextAccent);
        sectionIcon.Classes.Add("system-section-icon");
        Grid.SetColumn(sectionIcon, 1);
        Grid.SetColumn(titleText, 2);
        var headerContent = new Grid
        {
            ColumnDefinitions = new ColumnDefinitions("18,18,*"),
            ColumnSpacing = 6,
            Children = { arrow, sectionIcon, titleText }
        };
        var contentHost = new Border
        {
            BorderThickness = new Avalonia.Thickness(0),
            Padding = new Avalonia.Thickness(8, 8, 8, 12),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Child = content
        };
        contentHost.BindThemeResource(Border.BackgroundProperty, ThemeResourceBindings.Surface);
        var header = new Button
        {
            Height = 35,
            Padding = new Avalonia.Thickness(10, 0),
            BorderBrush = Brushes.Transparent,
            BorderThickness = new Avalonia.Thickness(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            Content = headerContent
        };
        header.Bind(Button.CornerRadiusProperty, new DynamicResourceExtension(
            ThemeChromeResources.CornerRadius(ThemeChromeRole.SurfaceCard)));
        header.Classes.Add("system-property-card-header");
        header.Classes.Add("system-section-header");
        titleText.Classes.Add("emphasis-label");
        arrow.Classes.Add("emphasis-arrow");
        var section = new Border
        {
            ClipToBounds = true,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Child = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Children = { header, contentHost }
            }
        };
        section.Classes.Add("system-property-card");
        section.Classes.Add("system-property-section");
        // Theme styles supply section chrome; nested field cards keep their own outline.
        section.BindThemeResource(Border.BackgroundProperty, ThemeResourceBindings.Surface);

        var isExpanded = expanded;
        var isHovered = false;

        void UpdateVisuals()
        {
            var emphasized = isExpanded || isHovered;
            section.Classes.Set("theme-emphasized", emphasized);
            header.Classes.Set("theme-emphasized", emphasized);
            arrow.Classes.Set("theme-emphasized", emphasized);
            titleText.Classes.Set("theme-emphasized", emphasized);
        }

        void SetExpanded(bool value)
        {
            isExpanded = value;
            contentHost.IsVisible = value;
            arrow.IconName = value ? "chevron-down" : "chevron-right";
            UpdateVisuals();
        }

        SetExpanded(isExpanded);
        header.PointerEntered += (_, _) =>
        {
            isHovered = true;
            UpdateVisuals();
        };
        header.PointerExited += (_, _) =>
        {
            isHovered = false;
            UpdateVisuals();
        };
        header.Click += (_, _) =>
        {
            isExpanded = !isExpanded;
            SetExpanded(isExpanded);
        };
        return section;
    }

    private static WrapPanel BuildHeader(string title, params Button[] buttons)
    {
        var header = new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            ItemSpacing = 8,
            LineSpacing = 4,
            Margin = new Avalonia.Thickness(0, 0, 0, 6)
        };
        header.Children.Add(new TextBlock
        {
            Text = title,
            FontWeight = FontWeight.SemiBold,
            VerticalAlignment = VerticalAlignment.Center
        });
        foreach (var button in buttons)
        {
            header.Children.Add(button);
        }

        return header;
    }

    private void RebuildFieldCards()
    {
        _fieldsHost.Children.Clear();
        var unit = _fieldDefinitionPicker.SelectedIndex == 0 ? "deg" : "mm";
        foreach (var field in _prescription.GetFields())
        {
            _fieldsHost.Children.Add(CreateFieldCard(field, unit));
        }
    }

    private Control CreateFieldCard(FieldRowDto field, string unit)
    {
        TextBlock? summaryDisplay = null;
        var label = new TextBox { Text = field.Label };
        var x = NumberInput(field.X, -1_000_000, 1_000_000, 0.1);
        var y = NumberInput(field.Y, -1_000_000, 1_000_000, 0.1);
        var vignetteX = NumberInput(field.VignetteFactorX, -1, 1, 0.05);
        var vignetteY = NumberInput(field.VignetteFactorY, -1, 1, 0.05);
        var decenterX = NumberInput(field.VignetteDecenterX, -1_000_000, 1_000_000, 0.05);
        var decenterY = NumberInput(field.VignetteDecenterY, -1_000_000, 1_000_000, 0.05);
        var vignetteAngle = NumberInput(field.VignetteAngleDegrees, -1_000_000, 1_000_000, 1);
        var weight = NumberInput(field.Weight, 0, 1_000_000, 0.1);

        void Commit()
        {
            if (_refreshing || _disposed)
            {
                return;
            }

            var nextX = DecimalValue(x, field.X);
            var nextY = DecimalValue(y, field.Y);
            var nextWeight = DecimalValue(weight, field.Weight);
            if (summaryDisplay is not null)
            {
                summaryDisplay.Text = $"X {NumericDisplayFormatter.Format(nextX)} · " +
                    $"Y {NumericDisplayFormatter.Format(nextY)} · 权重 {NumericDisplayFormatter.Format(nextWeight)}";
            }

            ApplyLocalChange(() => _prescription.UpdateField(new FieldRowDto(
                field.Index,
                label.Text ?? string.Empty,
                nextX,
                nextY,
                DecimalValue(vignetteX, field.VignetteFactorX),
                DecimalValue(vignetteY, field.VignetteFactorY),
                nextWeight,
                DecimalValue(decenterX, field.VignetteDecenterX),
                DecimalValue(decenterY, field.VignetteDecenterY),
                DecimalValue(vignetteAngle, field.VignetteAngleDegrees))));
        }

        label.LostFocus += (_, _) => Commit();
        x.ValueChanged += (_, _) => Commit();
        y.ValueChanged += (_, _) => Commit();
        vignetteX.ValueChanged += (_, _) => Commit();
        vignetteY.ValueChanged += (_, _) => Commit();
        decenterX.ValueChanged += (_, _) => Commit();
        decenterY.ValueChanged += (_, _) => Commit();
        vignetteAngle.ValueChanged += (_, _) => Commit();
        weight.ValueChanged += (_, _) => Commit();
        var delete = CommandButton("trash-2", "删除此视场", 96);
        delete.Click += (_, _) => _prescription.RemoveField(field.Index);
        var content = Form(
            ("标签", label),
            ($"X ({unit})", x),
            ($"Y ({unit})", y),
            ("X 渐晕", vignetteX),
            ("Y 渐晕", vignetteY),
            ("X 瞳孔偏移", decenterX),
            ("Y 瞳孔偏移", decenterY),
            ("瞳孔旋转 (°)", vignetteAngle),
            ("权重", weight),
            (string.Empty, delete));
        var card = EditorCard(
            field.Index,
            $"视场 {field.Index + 1}",
            $"X {NumericDisplayFormatter.Format(field.X)} · Y {NumericDisplayFormatter.Format(field.Y)} · " +
                $"权重 {NumericDisplayFormatter.Format(field.Weight)}",
            content,
            _expandedFields,
            isField: true);
        summaryDisplay = card.Summary;
        return card.Card;
    }

    private void RebuildWavelengthCards()
    {
        _wavelengthsHost.Children.Clear();
        foreach (var wavelength in _prescription.GetWavelengths())
        {
            _wavelengthsHost.Children.Add(CreateWavelengthCard(wavelength));
        }
    }

    private Control CreateWavelengthCard(WavelengthRowDto wavelength)
    {
        TextBlock? summaryDisplay = null;
        var label = new TextBox { Text = wavelength.Label };
        var nanometers = NumberInput(wavelength.Nanometers, 0.001, 1_000_000, 1);
        var weight = NumberInput(wavelength.Weight, 0, 1_000_000, 0.1);
        var primary = new CheckBox { Content = "主波长", IsChecked = wavelength.IsPrimary };

        void Commit()
        {
            if (_refreshing || _disposed)
            {
                return;
            }

            var nextNanometers = DecimalValue(nanometers, wavelength.Nanometers);
            var nextWeight = DecimalValue(weight, wavelength.Weight);
            if (summaryDisplay is not null)
            {
                summaryDisplay.Text = $"{NumericDisplayFormatter.Format(nextNanometers / 1000)} μm · " +
                    $"权重 {NumericDisplayFormatter.Format(nextWeight)}"
                    + (primary.IsChecked == true ? " · 主波长" : string.Empty);
            }

            ApplyLocalChange(() => _prescription.UpdateWavelength(new WavelengthRowDto(
                wavelength.Index,
                label.Text ?? string.Empty,
                nextNanometers,
                nextWeight,
                primary.IsChecked == true)));
        }

        label.LostFocus += (_, _) => Commit();
        nanometers.ValueChanged += (_, _) => Commit();
        weight.ValueChanged += (_, _) => Commit();
        primary.IsCheckedChanged += (_, _) => Commit();
        var delete = CommandButton("trash-2", "删除此波长", 104);
        delete.Click += (_, _) => _prescription.RemoveWavelength(wavelength.Index);
        var content = Form(
            ("标签", label),
            ("波长 (nm)", nanometers),
            ("权重", weight),
            (string.Empty, primary),
            (string.Empty, delete));
        var card = EditorCard(
            wavelength.Index,
            $"波长 {wavelength.Index + 1}",
            $"{NumericDisplayFormatter.Format(wavelength.Nanometers / 1000)} μm · " +
                $"权重 {NumericDisplayFormatter.Format(wavelength.Weight)}"
                + (wavelength.IsPrimary ? " · 主波长" : string.Empty),
            content,
            _expandedWavelengths);
        summaryDisplay = card.Summary;
        return card.Card;
    }

    private static NumericUpDown NumberInput(double value, double minimum, double maximum, double increment)
    {
        return new NumericUpDown
        {
            Minimum = (decimal)minimum,
            Maximum = (decimal)maximum,
            Increment = (decimal)increment,
            Value = (decimal)Math.Clamp(value, minimum, maximum),
            ShowButtonSpinner = false,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
    }

    private Control BuildEnvironmentSection()
    {
        _temperatureCelsius.HorizontalAlignment = HorizontalAlignment.Stretch;
        _pressureAtmospheres.HorizontalAlignment = HorizontalAlignment.Stretch;
        return new StackPanel
        {
            Spacing = 10,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Children =
            {
                _matchRefractiveIndexData,
                Form(
                    ("温度 (°C)", _temperatureCelsius),
                    ("压力 (ATM)", _pressureAtmospheres)),
                MutedText("当前仅保存环境参数，暂不启用温度补偿计算。", DisplayTypography.RibbonText)
            }
        };
    }

    private static (Control Card, TextBlock Summary) EditorCard(
        int index,
        string title,
        string summary,
        Control content,
        HashSet<int> expandedItems,
        bool isField = false)
    {
        var arrow = new LocalIcon { IconName = "chevron-right", Width = 16, Height = 16 };
        var titleText = new TextBlock
        {
            Text = title,
            FontSize = DisplayTypography.BodySmall,
            FontWeight = FontWeight.SemiBold,
            VerticalAlignment = VerticalAlignment.Center
        };
        var summaryText = new TextBlock
        {
            Text = summary,
            FontSize = DisplayTypography.Micro,
            TextTrimming = TextTrimming.CharacterEllipsis,
            VerticalAlignment = VerticalAlignment.Center
        };
        summaryText.BindThemeResource(TextBlock.ForegroundProperty, ThemeResourceBindings.MutedText);
        Grid.SetColumn(titleText, 1);
        Grid.SetColumn(summaryText, 2);
        var headerContent = new Grid
        {
            ColumnDefinitions = new ColumnDefinitions("18,Auto,*"),
            ColumnSpacing = 6,
            Children = { arrow, titleText, summaryText }
        };
        var contentHost = new Border
        {
            Padding = new Thickness(8, 8, 8, 12),
            Child = content
        };
        contentHost.BindThemeResource(Border.BackgroundProperty, ThemeResourceBindings.Surface);
        var header = new Button
        {
            Height = 42,
            Padding = new Thickness(10, 0),
            BorderBrush = Brushes.Transparent,
            BorderThickness = new Thickness(1),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            Content = headerContent
        };
        var card = new Border
        {
            ClipToBounds = true,
            BorderThickness = new Thickness(1),
            Child = new StackPanel { Children = { header, contentHost } }
        };
        header.Classes.Add("system-property-card-header");
        if (isField)
        {
            header.Classes.Add("field-editor-header");
            titleText.Classes.Add("emphasis-label");
            arrow.Classes.Add("emphasis-arrow");
        }
        card.Classes.Add("system-property-card");
        ThemeChrome.Apply(card, ThemeChromeRole.SurfaceCard, borderBrush: false);
        card.BindThemeResource(Border.BackgroundProperty, ThemeResourceBindings.Surface);
        var isHovered = false;

        void UpdateVisuals(bool expanded)
        {
            var emphasized = expanded || isHovered;
            header.Classes.Set("theme-emphasized", emphasized);
            card.Classes.Set("theme-emphasized", emphasized);
            arrow.Classes.Set("theme-emphasized", emphasized);
            titleText.Classes.Set("theme-emphasized", emphasized);
        }

        void SetExpanded(bool expanded)
        {
            contentHost.IsVisible = expanded;
            if (isField) header.Classes.Set("field-editor-expanded", expanded);
            arrow.IconName = expanded ? "chevron-down" : "chevron-right";
            if (expanded)
            {
                expandedItems.Add(index);
            }
            else
            {
                expandedItems.Remove(index);
            }

            UpdateVisuals(expanded);
        }

        SetExpanded(expandedItems.Contains(index));
        header.PointerEntered += (_, _) =>
        {
            isHovered = true;
            UpdateVisuals(contentHost.IsVisible);
        };
        header.PointerExited += (_, _) =>
        {
            isHovered = false;
            UpdateVisuals(contentHost.IsVisible);
        };
        header.Click += (_, _) => SetExpanded(!contentHost.IsVisible);
        return (card, summaryText);
    }

    private static TextBlock MutedText(string text, double fontSize)
    {
        var block = new TextBlock
        {
            Text = text,
            FontSize = fontSize,
            TextWrapping = TextWrapping.Wrap
        };
        block.BindThemeResource(TextBlock.ForegroundProperty, ThemeResourceBindings.MutedText);
        return block;
    }

    private void Refresh()
    {
        if (_disposed)
        {
            return;
        }

        _refreshing = true;
        var options = _prescription.GetOptions();
        var settings = _prescription.GetSystemSettings();
        var environment = _prescription.GetEnvironmentSettings();
        _backendPicker.ItemsSource = options.Backends;
        _backendPicker.SelectedItem = settings.Backend;
        _apertureKindPicker.SelectedItem = settings.ApertureKind;
        _apertureValue.Value = (decimal)settings.ApertureValue;
        UpdateApertureValueState();
        _fieldDefinitionPicker.SelectedItem = settings.FieldDefinition;
        _objectSpaceTelecentric.IsEnabled = _fieldDefinitionPicker.SelectedIndex != 0;
        _objectSpaceTelecentric.IsChecked = settings.ObjectSpaceTelecentric;
        _imageSpaceAfocal.IsChecked = settings.ImageSpaceAfocal;
        RefreshPolarization();
        SetApodizationControls(
            settings.ApodizationKind,
            settings.FirstApodizationParameter,
            settings.SecondApodizationParameter);
        _matchRefractiveIndexData.IsChecked = environment.MatchRefractiveIndexData;
        _temperatureCelsius.Value = (decimal)environment.TemperatureCelsius;
        _pressureAtmospheres.Value = (decimal)environment.PressureAtmospheres;
        RefreshGlassCatalogs();
        RebuildFieldCards();
        RebuildWavelengthCards();
        _refreshing = false;
    }

    private void UpdateApertureValueState()
    {
        _apertureValue.IsEnabled = !string.Equals(
            _apertureKindPicker.SelectedItem as string,
            "按光阑面尺寸浮动",
            StringComparison.Ordinal);
    }

    private void ApplySystemControls()
    {
        var current = _prescription.GetSystemSettings();
        var backendName = _backendPicker.SelectedItem as string ?? current.Backend;
        var apertureKind = _apertureKindPicker.SelectedItem as string
            ?? current.ApertureKind;
        var value = _apertureValue.Value.HasValue
            ? decimal.ToDouble(_apertureValue.Value.Value)
            : current.ApertureValue;
        var selectedApodization = _apodizationPicker.SelectedItem as string;
        // A legacy model is not a selectable option. Keep it intact when another system setting changes.
        var apodizationKind = selectedApodization ?? current.ApodizationKind;
        var fieldDefinition = _fieldDefinitionPicker.SelectedItem as string ?? "角度";
        var firstApodizationParameter = selectedApodization is null
            ? current.FirstApodizationParameter
            : DecimalValue(_firstApodizationParameter, current.FirstApodizationParameter);
        var secondApodizationParameter = selectedApodization is null
            ? current.SecondApodizationParameter
            : DecimalValue(_secondApodizationParameter, current.SecondApodizationParameter);

        ApplyLocalChange(() => _prescription.UpdateSystemSettings(new SystemSettingsDto(
            backendName,
            apertureKind,
            value,
            fieldDefinition,
            _objectSpaceTelecentric.IsChecked == true,
            apodizationKind,
            firstApodizationParameter,
            secondApodizationParameter,
            _imageSpaceAfocal.IsChecked == true)));
    }

    private void ApplyLocalChange(Action action)
    {
        _applyingLocalChange = true;
        try
        {
            action();
        }
        finally
        {
            _applyingLocalChange = false;
        }
    }

    private void ScheduleSystemUpdate()
    {
        if (_disposed || _refreshing)
        {
            return;
        }

        _systemUpdateTimer.Stop();
        _systemUpdateTimer.Start();
    }

    private void OnSystemUpdateTimerTick(object? sender, EventArgs args)
    {
        _systemUpdateTimer.Stop();
        if (!_disposed && !_refreshing)
        {
            ApplySystemControls();
        }
    }

    private void ScheduleEnvironmentUpdate()
    {
        if (_disposed || _refreshing)
        {
            return;
        }

        _environmentUpdateTimer.Stop();
        _environmentUpdateTimer.Start();
    }

    private void OnEnvironmentUpdateTimerTick(object? sender, EventArgs args)
    {
        _environmentUpdateTimer.Stop();
        if (!_disposed && !_refreshing)
        {
            ApplyEnvironmentControls();
        }
    }

    private void ApplyEnvironmentControls()
    {
        var current = _prescription.GetEnvironmentSettings();
        var temperature = _temperatureCelsius.Value.HasValue
            ? decimal.ToDouble(_temperatureCelsius.Value.Value)
            : current.TemperatureCelsius;
        var pressure = _pressureAtmospheres.Value.HasValue
            ? decimal.ToDouble(_pressureAtmospheres.Value.Value)
            : current.PressureAtmospheres;

        ApplyLocalChange(() => _prescription.UpdateEnvironmentSettings(new EnvironmentSettingsDto(
            _matchRefractiveIndexData.IsChecked == true,
            temperature,
            pressure)));
    }

    private void SetApodizationControls(string kind, double first, double second)
    {
        var selectable = _apodizationPicker.Items.Contains(kind);
        _apodizationPicker.SelectedItem = selectable ? kind : null;
        var uniform = kind is "无" or "均匀";
        _apodizationPicker.PlaceholderText = uniform ? "均匀" : "旧版设置（保留）";
        ToolTip.SetTip(_apodizationPicker, selectable || uniform
            ? null
            : $"旧工程切趾：{kind}。保留现有设置；选择新类型后才替换。");
        ConfigureApodizationParameters(selectable ? kind : null, useDefaults: false);
        _firstApodizationParameter.Value = (decimal)first;
        _secondApodizationParameter.Value = (decimal)second;
    }

    private void ConfigureApodizationParameters(string? kind, bool useDefaults)
    {
        var configuration = kind switch
        {
            "均匀（Zemax）" => ("因子", string.Empty, 0.0, 1.0),
            "高斯（Zemax）" => ("因子", string.Empty, 1.0, 1.0),
            "余弦立方（Zemax）" => ("因子", string.Empty, 0.0, 1.0),
            _ => (string.Empty, string.Empty, 1.0, 1.0)
        };
        var firstVisible = configuration.Item1.Length > 0;
        var secondVisible = configuration.Item2.Length > 0;
        _firstApodizationLabel.Text = configuration.Item1;
        _secondApodizationLabel.Text = configuration.Item2;
        _firstApodizationLabel.IsVisible = firstVisible;
        _firstApodizationParameter.IsVisible = firstVisible;
        _secondApodizationLabel.IsVisible = secondVisible;
        _secondApodizationParameter.IsVisible = secondVisible;
        if (_apodizationParameterRow is not null)
        {
            _apodizationParameterRow.IsVisible = firstVisible;
        }
        if (useDefaults)
        {
            _firstApodizationParameter.Value = (decimal)configuration.Item3;
            _secondApodizationParameter.Value = (decimal)configuration.Item4;
        }
    }

    private static TextBlock ParameterLabel(string text)
    {
        return new TextBlock
        {
            Text = text,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Avalonia.Thickness(6, 0, 2, 0)
        };
    }

    private static NumericUpDown ParameterInput(decimal value)
    {
        return new NumericUpDown
        {
            Minimum = 0m,
            Maximum = 1_000_000m,
            Increment = 0.1m,
            Value = value,
            Width = 78,
            ShowButtonSpinner = false
        };
    }

    private void OnWorkspaceChanged(object? sender, WorkspaceChangedEventArgs args)
    {
        if (_applyingLocalChange)
        {
            return;
        }

        Dispatcher.UIThread.Post(Refresh);
    }

    private static double DecimalValue(NumericUpDown input, double fallback)
    {
        return input.Value.HasValue ? decimal.ToDouble(input.Value.Value) : fallback;
    }

    private static Button CommandButton(string iconName, string text, double minWidth) => new()
    {
        Content = new LocalIconLabel(iconName, text),
        MinWidth = minWidth
    };
}
