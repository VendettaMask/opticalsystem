using Avalonia;
using Avalonia.Automation;
using Avalonia.Automation.Peers;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Immutable;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.Application.Contracts;
using Layout2DLensEdge = OpticalSystemDesign.Application.Contracts.SceneLensEdge2Dto;
using Layout2DLensElement = OpticalSystemDesign.Application.Contracts.SceneLensElement2Dto;
using Layout2DPoint = OpticalSystemDesign.Application.Contracts.ScenePoint2Dto;
using Layout2DRayPath = OpticalSystemDesign.Application.Contracts.SceneRay2Dto;
using Layout2DScene = OpticalSystemDesign.Application.Contracts.Scene2Dto;
using Layout2DSurfaceCurve = OpticalSystemDesign.Application.Contracts.SceneSurface2Dto;
using Layout3DLensElement = OpticalSystemDesign.Application.Contracts.SceneLensElement3Dto;
using Layout3DPoint = OpticalSystemDesign.Application.Contracts.ScenePoint3Dto;
using Layout3DRayPath = OpticalSystemDesign.Application.Contracts.SceneRay3Dto;
using Layout3DScene = OpticalSystemDesign.Application.Contracts.Scene3Dto;
using Layout3DSurfacePrimitive = OpticalSystemDesign.Application.Contracts.SceneSurface3Dto;

namespace OpticalSystemDesign.App.Controls;

public enum OpticSceneViewMode
{
    TwoDimensional,
    ThreeDimensional
}

public enum OpticSceneRenderMode
{
    Solid,
    Wireframe,
    Transparent
}

public enum OpticSceneRayColorMode
{
    Field,
    Wavelength
}

public enum OpticSceneVisualStyle
{
    OpticalLayout,
    SolidModel
}

public enum OpticSceneViewPreset
{
    Isometric,
    Front,
    Back,
    Left,
    Right,
    Top,
    Bottom
}

public enum OpticSceneAnnotationPlacement2D
{
    Auto,
    Above,
    Below
}

public sealed record OpticSceneAnnotation2D(
    double Z,
    string Label,
    Color Color,
    OpticSceneAnnotationPlacement2D Placement = OpticSceneAnnotationPlacement2D.Auto);

internal sealed record GlassMaterialLegendEntry(string Material, Color Color);
internal sealed record OrientationAxisProjection(string Label, Color Color, Vector Direction, double Depth);

public sealed class OpticSceneControl : Control, IInteractiveCanvasAutomationSource
{
    // Static drawing resources are shared by controls on different UI dispatchers.
    // Keep them immutable so a later window/session cannot inherit thread-owned media.
    private static readonly IImmutableBrush SolidModelBackgroundBrush = new LinearGradientBrush
    {
        StartPoint = RelativePoint.TopLeft,
        EndPoint = RelativePoint.BottomRight,
        GradientStops =
        {
            new GradientStop(Color.FromRgb(18, 22, 27), 0),
            new GradientStop(Color.FromRgb(38, 46, 55), 0.58),
            new GradientStop(Color.FromRgb(16, 20, 25), 1)
        }
    }.ToImmutable();
    private static readonly IImmutableBrush LensFillBrush = new ImmutableSolidColorBrush(Color.FromArgb(104, 105, 151, 185));
    private static readonly ImmutablePen ReferencePlanePen = new(new ImmutableSolidColorBrush(Color.FromRgb(34, 48, 58)), 2.6);
    private static readonly ImmutablePen AxisPen = new(new ImmutableSolidColorBrush(Color.FromArgb(115, 134, 146, 166)), 0.8, new ImmutableDashStyle(DashStyle.Dash.Dashes, DashStyle.Dash.Offset));
    private static readonly ImmutablePen StopPen = new(new ImmutableSolidColorBrush(Color.FromRgb(33, 96, 144)), 3);
    private static readonly ImmutablePen ApertureStopPen = new(new ImmutableSolidColorBrush(Color.FromRgb(31, 31, 33)), 2);
    private static readonly ImmutablePen TwoDLensOutlinePen = new(new ImmutableSolidColorBrush(Colors.Black), 2);
    private static readonly ImmutablePen SelectedSurfaceHaloPen = new(new ImmutableSolidColorBrush(Color.FromArgb(105, 255, 193, 62)), 7);
    private static readonly ImmutablePen SelectedSurfacePen = new(new ImmutableSolidColorBrush(Color.FromRgb(232, 126, 25)), 3.2);
    private static readonly ImmutablePen VignettedRayPen = new(new ImmutableSolidColorBrush(Color.FromRgb(188, 74, 60)), 1.2);
    private static readonly ImmutablePen ThreeDWirePen = new(new ImmutableSolidColorBrush(Color.FromRgb(71, 93, 128)), 1.15);
    private static readonly ImmutablePen ThreeDLensEdgePen = new(new ImmutableSolidColorBrush(Color.FromRgb(24, 58, 142)), 1.7);
    private static readonly ImmutablePen ThreeDLensHighlightPen = new(new ImmutableSolidColorBrush(Color.FromArgb(155, 128, 174, 245)), 0.9);
    private static readonly ImmutablePen SolidLensEdgePen = new(new ImmutableSolidColorBrush(Color.FromArgb(150, 170, 207, 218)), 1.05);
    private static readonly ImmutablePen SolidLensHighlightPen = new(new ImmutableSolidColorBrush(Color.FromArgb(205, 235, 250, 252)), 1.15);
    private static readonly ImmutablePen SolidLensMeridianPen = new(new ImmutableSolidColorBrush(Color.FromArgb(72, 177, 222, 235)), 0.75);
    private static readonly ImmutablePen SolidAxisPen = new(new ImmutableSolidColorBrush(Color.FromArgb(75, 154, 174, 190)), 0.8, new ImmutableDashStyle(DashStyle.Dash.Dashes, DashStyle.Dash.Offset));
    private static readonly ImmutablePen SolidReferencePlanePen = new(new ImmutableSolidColorBrush(Color.FromArgb(140, 188, 202, 215)), 1.7);
    private static readonly IImmutableBrush SolidImageSurfaceBrush = new ImmutableSolidColorBrush(Color.FromArgb(42, 188, 202, 215));
    private static readonly ImmutablePen SolidImageSurfacePen = new(new ImmutableSolidColorBrush(Color.FromArgb(205, 188, 202, 215)), 1.3,
        new ImmutableDashStyle(DashStyle.Dash.Dashes, DashStyle.Dash.Offset));
    private static readonly ImmutablePen TargetPen = new(new ImmutableSolidColorBrush(Color.FromRgb(104, 119, 139)), 1.1);
    private static readonly ImmutablePen DetectorObjectPen = new(new ImmutableSolidColorBrush(Color.FromRgb(25, 117, 166)), 1.5);
    private static readonly ImmutablePen NonSequentialGeometryPen = new(new ImmutableSolidColorBrush(Color.FromArgb(62, 75, 89, 102)), 0.4);
    private static readonly IImmutableBrush DetectorObjectBrush = new ImmutableSolidColorBrush(Color.FromArgb(58, 60, 169, 211));
    private static readonly IImmutableBrush NonSequentialGlassBrush = new ImmutableSolidColorBrush(Color.FromArgb(58, 85, 169, 202));
    private static readonly IImmutableBrush NonSequentialMechanicalBrush = new ImmutableSolidColorBrush(Color.FromArgb(82, 116, 126, 136));
    private static readonly IImmutableBrush SelectedSurfaceFaceBrush = new ImmutableSolidColorBrush(Color.FromArgb(205, 255, 176, 46));
    private static readonly IImmutableBrush SolidLensCutBrush = new ImmutableSolidColorBrush(Color.FromArgb(156, 83, 155, 174));
    private static readonly IImmutableBrush ThreeDLensCutBrush = new ImmutableSolidColorBrush(Color.FromArgb(170, 225, 139, 48));
    private static readonly Color[] RayColors =
    {
        Color.FromRgb(220, 55, 48),
        Color.FromRgb(36, 156, 86),
        Color.FromRgb(34, 111, 202),
        Color.FromRgb(232, 137, 29),
        Color.FromRgb(197, 57, 157),
        Color.FromRgb(15, 158, 177),
        Color.FromRgb(164, 174, 25)
    };

    // Identification colors, independent of ray colors and physical glass transmission.
    private static readonly Color[] GlassColors =
    {
        Color.FromRgb(64, 174, 163), Color.FromRgb(116, 153, 222),
        Color.FromRgb(213, 169, 91), Color.FromRgb(174, 139, 205),
        Color.FromRgb(216, 132, 143), Color.FromRgb(139, 181, 112),
        Color.FromRgb(94, 176, 204), Color.FromRgb(197, 145, 186)
    };

    private Scene3Dto? _materialColorScene;
    private IReadOnlyList<GlassMaterialLegendEntry> _glassMaterials = [];
    private Dictionary<string, Color> _glassColors = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<int, Color> _glassSurfaceColors = new();

    internal IReadOnlyList<GlassMaterialLegendEntry> GlassMaterials
    {
        get
        {
            var scene = VisualStyle == OpticSceneVisualStyle.SolidModel ? Scene?.ThreeDimensional : null;
            if (ReferenceEquals(scene, _materialColorScene)) return _glassMaterials;
            _materialColorScene = scene;
            var names = (scene?.LensElements.Select(element => element.Material.Trim()) ?? [])
                .Where(name => name.Length > 0 && !name.Equals("Air", StringComparison.OrdinalIgnoreCase))
                .Distinct(StringComparer.OrdinalIgnoreCase).Order(StringComparer.OrdinalIgnoreCase).ToArray();
            var used = new HashSet<Color>();
            var entries = new List<GlassMaterialLegendEntry>();
            var generated = 0;
            foreach (var name in names)
            {
                var color = entries.Count < GlassColors.Length ? GlassColors[entries.Count]
                    : new HsvColor(1, (generated++ * 137.507764 + 24) % 360, 0.48, 0.82).ToRgb();
                while (!used.Add(color))
                    color = new HsvColor(1, (generated++ * 137.507764 + 24) % 360, 0.48, 0.82).ToRgb();
                entries.Add(new(name, color));
            }
            _glassMaterials = entries;
            _glassColors = entries.ToDictionary(entry => entry.Material, entry => entry.Color, StringComparer.OrdinalIgnoreCase);
            _glassSurfaceColors.Clear();
            foreach (var element in scene?.LensElements ?? [])
            {
                if (!_glassColors.TryGetValue(element.Material.Trim(), out var color)) continue;
                _glassSurfaceColors.TryAdd(element.FrontSurfaceNumber, color);
                _glassSurfaceColors.TryAdd(element.BackSurfaceNumber, color);
            }
            return _glassMaterials;
        }
    }

    internal Color? GlassColorFor(string material)
    {
        _ = GlassMaterials;
        return _glassColors.TryGetValue(material.Trim(), out var color) ? color : null;
    }

    private readonly SceneViewport _viewport = new();
    private OpticSceneViewMode _viewMode;
    private OpticSceneRenderMode _renderMode = OpticSceneRenderMode.Wireframe;
    private double _yaw = -0.72;
    private double _pitch = 0.38;
    private bool _dragging;
    private bool _rotating;
    private Point _lastPointer;
    private bool _showRays = true;
    private bool _cutawayEnabled;
    private bool _showRayArrows;
    private bool _showScaleBar = true;
    private double _verticalStretch = 1;
    private double _rayLineWidth = 1.25;
    private OpticSceneRayColorMode _rayColorMode;
    private OpticSceneVisualStyle _visualStyle;
    private int? _highlightedSurfaceNumber;

    public OpticSceneControl()
    {
        Focusable = true;
        InteractiveCanvasFocus.Attach(this);
        ClipToBounds = true;
        AutomationProperties.SetName(this, "光学系统视图");
        AutomationProperties.SetHelpText(
            this,
            "使用加号或减号缩放，按 Home 重置。二维视图用方向键平移；三维视图用方向键旋转，按住 Shift 平移。");
    }


    private IBrush ThemeBrush(string key, IBrush fallback) =>
        this.TryFindResource(key, ActualThemeVariant, out var value) && value is IBrush brush
            ? brush
            : fallback;

    private Color ThemeColor(string key, Color fallback)
    {
        return this.TryFindResource(key, ActualThemeVariant, out var value)
            && value is ISolidColorBrush brush
                ? brush.Color
                : fallback;
    }

    private Pen ThemePen(string key, IPen fallback) => new(
        ThemeBrush(key, fallback.Brush ?? Brushes.Black),
        fallback.Thickness,
        fallback.DashStyle,
        fallback.LineCap,
        fallback.LineJoin,
        fallback.MiterLimit);

    private IBrush SceneBackgroundBrush(bool threeDimensional, bool solidModel)
    {
        if (solidModel)
        {
            return SolidModelBackgroundBrush;
        }

        var primary = ThemeColor(ThemeResourceBindings.SceneBackground, Color.FromRgb(250, 252, 254));
        if (!threeDimensional)
        {
            return new SolidColorBrush(primary);
        }

        var secondary = ThemeColor(ThemeResourceBindings.SceneBackgroundAlt, Color.FromRgb(229, 235, 243));
        return new LinearGradientBrush
        {
            StartPoint = RelativePoint.TopLeft,
            EndPoint = RelativePoint.BottomRight,
            GradientStops =
            {
                new GradientStop(primary, 0),
                new GradientStop(secondary, 1)
            }
        };
    }

    public SceneDto? Scene { get; set; }

    public IReadOnlyList<OpticSceneAnnotation2D> Annotations2D { get; set; } =
        Array.Empty<OpticSceneAnnotation2D>();

    public int? HighlightedSurfaceNumber
    {
        get => _highlightedSurfaceNumber;
        set
        {
            if (_highlightedSurfaceNumber != value)
            {
                _highlightedSurfaceNumber = value;
                InvalidateVisual();
            }
        }
    }

    public OpticSceneViewMode ViewMode
    {
        get => _viewMode;
        set
        {
            if (_viewMode != value)
            {
                _viewMode = value;
                InvalidateVisual();
            }
        }
    }

    public bool ShowRays
    {
        get => _showRays;
        set
        {
            if (_showRays != value)
            {
                _showRays = value;
                InvalidateVisual();
            }
        }
    }

    public OpticSceneRenderMode RenderMode
    {
        get => _renderMode;
        set
        {
            if (_renderMode != value)
            {
                _renderMode = value;
                InvalidateVisual();
            }
        }
    }

    public bool ShowRayArrows
    {
        get => _showRayArrows;
        set
        {
            if (_showRayArrows != value)
            {
                _showRayArrows = value;
                InvalidateVisual();
            }
        }
    }

    public OpticSceneVisualStyle VisualStyle
    {
        get => _visualStyle;
        set
        {
            if (_visualStyle != value)
            {
                _visualStyle = value;
                InvalidateVisual();
            }
        }
    }

    public bool CutawayEnabled
    {
        get => _cutawayEnabled;
        set
        {
            if (_cutawayEnabled != value)
            {
                _cutawayEnabled = value;
                InvalidateVisual();
            }
        }
    }

    public bool ShowScaleBar
    {
        get => _showScaleBar;
        set
        {
            if (_showScaleBar != value)
            {
                _showScaleBar = value;
                InvalidateVisual();
            }
        }
    }

    public double VerticalStretch
    {
        get => _verticalStretch;
        set
        {
            var normalized = Math.Clamp(value, 0.1, 10);
            if (Math.Abs(_verticalStretch - normalized) > 1e-12)
            {
                _verticalStretch = normalized;
                InvalidateVisual();
            }
        }
    }

    public double RayLineWidth
    {
        get => _rayLineWidth;
        set
        {
            var normalized = Math.Clamp(value, 0.5, 4);
            if (Math.Abs(_rayLineWidth - normalized) > 1e-12)
            {
                _rayLineWidth = normalized;
                InvalidateVisual();
            }
        }
    }

    public OpticSceneRayColorMode RayColorMode
    {
        get => _rayColorMode;
        set
        {
            if (_rayColorMode != value)
            {
                _rayColorMode = value;
                InvalidateVisual();
            }
        }
    }

    public void ResetView()
    {
        SetViewPreset(OpticSceneViewPreset.Isometric);
    }

    internal event EventHandler? ViewOrientationChanged;

    internal OpticSceneViewPreset? ActiveViewPreset
    {
        get
        {
            foreach (var preset in Enum.GetValues<OpticSceneViewPreset>())
            {
                var (yaw, pitch) = PresetAngles(preset);
                if (Math.Abs(Math.IEEERemainder(_yaw - yaw, Math.PI * 2)) < 1e-6
                    && Math.Abs(_pitch - pitch) < 1e-6) return preset;
            }
            return null;
        }
    }

    protected override AutomationPeer OnCreateAutomationPeer() =>
        new InteractiveCanvasAutomationPeer(this);

    string IInteractiveCanvasAutomationSource.AutomationValue
    {
        get
        {
            if (ViewMode == OpticSceneViewMode.ThreeDimensional && Scene?.ThreeDimensional is { } scene3)
            {
                return $"三维光学系统；{scene3.Surfaces.Count} 个表面，{scene3.LensElements.Count} 个镜片，"
                    + $"{scene3.Rays.Count} 条光线；Z 范围 {scene3.ZMin:G6} 到 {scene3.ZMax:G6}。";
            }
            if (Scene?.TwoDimensional is { } scene2)
            {
                return $"二维光学系统；{scene2.Surfaces.Count} 个表面，{scene2.LensElements.Count} 个镜片，"
                    + $"{scene2.Rays.Count} 条光线；Z 范围 {scene2.ZMin:G6} 到 {scene2.ZMax:G6}。";
            }
            return "光学系统视图；没有可用场景。";
        }
    }

    void IInteractiveCanvasAutomationSource.InvokeAutomationAction() => ResetView();

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (!InteractiveCanvasKeyboard.TryGetCommand(e.Key, out var command))
        {
            return;
        }

        switch (command)
        {
            case InteractiveCanvasCommand.Reset:
                ResetView();
                break;
            case InteractiveCanvasCommand.ZoomIn:
                ZoomAtCenter(1.25);
                break;
            case InteractiveCanvasCommand.ZoomOut:
                ZoomAtCenter(0.8);
                break;
            default:
                NavigateWithKeyboard(command, e.KeyModifiers.HasFlag(KeyModifiers.Shift));
                break;
        }

        e.Handled = true;
    }

    private void NavigateWithKeyboard(InteractiveCanvasCommand command, bool pan)
    {
        var x = command switch
        {
            InteractiveCanvasCommand.Left => -1,
            InteractiveCanvasCommand.Right => 1,
            _ => 0
        };
        var y = command switch
        {
            InteractiveCanvasCommand.Up => -1,
            InteractiveCanvasCommand.Down => 1,
            _ => 0
        };
        if (ViewMode == OpticSceneViewMode.ThreeDimensional && !pan)
        {
            _yaw += x * 0.08;
            _pitch = Math.Clamp(_pitch + (y * 0.08), -1.25, 1.25);
            ViewOrientationChanged?.Invoke(this, EventArgs.Empty);
        }
        else
        {
            _viewport.PanBy(new Vector(x * 24, y * 24));
        }

        InvalidateVisual();
    }

    private void ZoomAtCenter(double factor)
    {
        _viewport.ZoomAt(
            factor,
            new Point(Bounds.Width / 2, Bounds.Height / 2),
            Bounds.Size);
        InvalidateVisual();
    }

    public void FitView()
    {
        _viewport.Reset();
        InvalidateVisual();
    }

    public void SetViewPreset(OpticSceneViewPreset preset)
    {
        (_yaw, _pitch) = PresetAngles(preset);
        _viewport.Reset();
        ViewOrientationChanged?.Invoke(this, EventArgs.Empty);
        InvalidateVisual();
    }

    private static (double Yaw, double Pitch) PresetAngles(OpticSceneViewPreset preset) => preset switch
    {
        OpticSceneViewPreset.Front => (0, 0),
        OpticSceneViewPreset.Back => (Math.PI, 0),
        OpticSceneViewPreset.Left => (-Math.PI / 2.0, 0),
        OpticSceneViewPreset.Right => (Math.PI / 2.0, 0),
        OpticSceneViewPreset.Top => (0, (Math.PI / 2.0) - 0.01),
        OpticSceneViewPreset.Bottom => (0, (-Math.PI / 2.0) + 0.01),
        _ => (-0.72, 0.38)
    };

    protected override void OnPointerPressed(PointerPressedEventArgs e)
    {
        base.OnPointerPressed(e);
        var point = e.GetCurrentPoint(this);
        if (!point.Properties.IsLeftButtonPressed)
        {
            return;
        }

        Focus();
        _dragging = true;
        _rotating = ViewMode == OpticSceneViewMode.ThreeDimensional
            && !e.KeyModifiers.HasFlag(KeyModifiers.Shift);
        _lastPointer = point.Position;
        e.Pointer.Capture(this);
        e.Handled = true;
    }

    protected override void OnPointerMoved(PointerEventArgs e)
    {
        base.OnPointerMoved(e);
        if (!_dragging)
        {
            return;
        }

        var position = e.GetPosition(this);
        var delta = position - _lastPointer;
        _lastPointer = position;
        if (_rotating)
        {
            _yaw += delta.X * 0.01;
            _pitch = Math.Clamp(_pitch + (delta.Y * 0.01), -1.25, 1.25);
            ViewOrientationChanged?.Invoke(this, EventArgs.Empty);
        }
        else
        {
            _viewport.PanBy(delta);
        }

        InvalidateVisual();
        e.Handled = true;
    }

    protected override void OnPointerReleased(PointerReleasedEventArgs e)
    {
        base.OnPointerReleased(e);
        if (!_dragging)
        {
            return;
        }

        _dragging = false;
        e.Pointer.Capture(null);
        e.Handled = true;
    }

    protected override void OnPointerWheelChanged(PointerWheelEventArgs e)
    {
        base.OnPointerWheelChanged(e);
        _viewport.ZoomAt(Math.Pow(1.15, e.Delta.Y), e.GetPosition(this), Bounds.Size);
        InvalidateVisual();
        e.Handled = true;
    }

    public override void Render(DrawingContext context)
    {
        base.Render(context);
        RenderContent(context, includeFocus: true);
    }

    internal void RenderImageContent(DrawingContext context) => RenderContent(context, includeFocus: false);

    private void RenderContent(DrawingContext context, bool includeFocus)
    {
        context.DrawRectangle(
            SceneBackgroundBrush(
                ViewMode == OpticSceneViewMode.ThreeDimensional,
                VisualStyle == OpticSceneVisualStyle.SolidModel),
            null,
            Bounds);
        if (Scene is null)
        {
            if (includeFocus) InteractiveCanvasFocus.Draw(context, this);
            return;
        }

        if (ViewMode == OpticSceneViewMode.ThreeDimensional)
        {
            if (Scene.ThreeDimensional is not null)
            {
                Draw3D(context, Scene.ThreeDimensional);
            }

            if (includeFocus) InteractiveCanvasFocus.Draw(context, this);
            return;
        }

        if (Scene.TwoDimensional is not null)
        {
            Draw2D(context, Scene.TwoDimensional);
        }

        if (includeFocus) InteractiveCanvasFocus.Draw(context, this);
    }

    private void Draw2D(DrawingContext context, Layout2DScene scene)
    {
        const double horizontalPadding = 28.0;
        var autoAnnotationCount = Annotations2D.Count(annotation =>
            annotation.Placement == OpticSceneAnnotationPlacement2D.Auto);
        var aboveAnnotationCount = Annotations2D.Count(annotation =>
                                       annotation.Placement == OpticSceneAnnotationPlacement2D.Above)
                                   + ((autoAnnotationCount + 1) / 2);
        var belowAnnotationCount = Annotations2D.Count(annotation =>
                                       annotation.Placement == OpticSceneAnnotationPlacement2D.Below)
                                   + (autoAnnotationCount / 2);
        var annotationPadding = CalculateAnnotationPadding(
            Bounds.Height,
            aboveAnnotationCount,
            belowAnnotationCount);
        var width = Math.Max(1, Bounds.Width - (horizontalPadding * 2));
        var height = Math.Max(1, Bounds.Height - annotationPadding.Top - annotationPadding.Bottom);
        var centerX = horizontalPadding + (width / 2.0);
        var centerY = annotationPadding.Top + (height / 2.0);
        var annotationMinimum = Annotations2D.Select(annotation => annotation.Z).DefaultIfEmpty(scene.ZMin).Min();
        var annotationMaximum = Annotations2D.Select(annotation => annotation.Z).DefaultIfEmpty(scene.ZMax).Max();
        var zMinimum = Math.Min(scene.ZMin, annotationMinimum);
        var zMaximum = Math.Max(scene.ZMax, annotationMaximum);
        var rawZSpan = Math.Max(1, zMaximum - zMinimum);
        var zMargin = rawZSpan * 0.06;
        zMinimum -= zMargin;
        zMaximum += zMargin;
        var zSpan = Math.Max(1, zMaximum - zMinimum);
        var aperture = Math.Max(1, scene.YExtent);
        var scale = 0.94 * Math.Min(width / zSpan, height / (aperture * 2.0 * VerticalStretch));
        var zCenter = zMinimum + (zSpan / 2.0);

        double MapZ(double z) => _viewport.Apply(
            new Point(centerX + ((z - zCenter) * scale), centerY),
            Bounds.Size).X;
        double MapY(double y) => _viewport.Apply(
            new Point(centerX, centerY - (y * scale * VerticalStretch)),
            Bounds.Size).Y;

        context.DrawLine(
            ThemePen(ThemeResourceBindings.SceneAxis, AxisPen),
            new Point(MapZ(zMinimum), MapY(0)),
            new Point(MapZ(zMaximum), MapY(0)));

        DrawLensElements(context, scene.LensElements, MapZ, MapY);
        if (ShowRays)
        {
            DrawRays(context, scene.Rays, MapZ, MapY);
        }
        DrawLensEdges(context, scene.LensEdges, MapZ, MapY);
        DrawSurfaces(context, scene.Surfaces, MapZ, MapY, HighlightedSurfaceNumber);
        DrawAnnotations2D(context, Annotations2D, aperture, Bounds, MapZ, MapY);
        if (ShowScaleBar)
        {
            DrawScaleBar(context, scale * _viewport.Zoom);
        }
    }

    private static void DrawAnnotations2D(
        DrawingContext context,
        IReadOnlyList<OpticSceneAnnotation2D> annotations,
        double aperture,
        Rect bounds,
        Func<double, double> mapZ,
        Func<double, double> mapY)
    {
        var grouped = annotations
            .GroupBy(annotation => (Z: Math.Round(annotation.Z, 8), annotation.Placement))
            .Select(group => new
            {
                Z = group.First().Z,
                Label = string.Join(" / ", group.Select(annotation => annotation.Label)),
                Color = group.First().Color,
                Placement = group.Key.Placement
            })
            .OrderBy(annotation => annotation.Z)
            .ToArray();

        var prepared = grouped
            .Select((annotation, index) =>
            {
                var brush = new SolidColorBrush(annotation.Color);
                var label = new FormattedText(
                    annotation.Label,
                    System.Globalization.CultureInfo.CurrentCulture,
                    FlowDirection.LeftToRight,
                    OpticalSystemDesign.App.Services.DisplayTypography.Typeface(FontWeight.SemiBold),
                    DisplayTypography.CompactBody,
                    brush);
                var x = mapZ(annotation.Z);
                var labelX = Math.Clamp(
                    x - (label.Width / 2),
                    8,
                    Math.Max(8, bounds.Width - label.Width - 8));
                var above = annotation.Placement switch
                {
                    OpticSceneAnnotationPlacement2D.Above => true,
                    OpticSceneAnnotationPlacement2D.Below => false,
                    _ => index % 2 == 0
                };
                return new
                {
                    Annotation = annotation,
                    Brush = brush,
                    Label = label,
                    X = x,
                    LabelX = labelX,
                    Above = above,
                    Lane = 0
                };
            })
            .ToArray();

        foreach (var side in new[] { true, false })
        {
            var labels = prepared
                .Select((item, index) => (Item: item, Index: index))
                .Where(candidate => candidate.Item.Above == side)
                .ToArray();
            var lanes = AssignAnnotationLanes(labels
                .Select(candidate => (
                    Left: candidate.Item.LabelX,
                    Right: candidate.Item.LabelX + candidate.Item.Label.Width))
                .ToArray());
            for (var index = 0; index < labels.Length; index++)
            {
                prepared[labels[index].Index] = prepared[labels[index].Index] with
                {
                    Lane = lanes[index]
                };
            }
        }

        var top = mapY(aperture * 1.02);
        var bottom = mapY(-aperture * 1.02);
        var upperEdge = Math.Min(top, bottom);
        var lowerEdge = Math.Max(top, bottom);
        var maximumLabelHeight = prepared.Select(item => item.Label.Height).DefaultIfEmpty(14).Max();
        var laneStep = maximumLabelHeight + 5;
        var maximumAboveLane = prepared
            .Where(item => item.Above)
            .Select(item => item.Lane)
            .DefaultIfEmpty(0)
            .Max();
        var maximumBelowLane = prepared
            .Where(item => !item.Above)
            .Select(item => item.Lane)
            .DefaultIfEmpty(0)
            .Max();
        var aboveLaneZeroY = Math.Max(
            upperEdge - maximumLabelHeight - 7,
            6 + (maximumAboveLane * laneStep));
        var belowLaneZeroY = Math.Min(
            lowerEdge + 7,
            bounds.Height - maximumLabelHeight - 6 - (maximumBelowLane * laneStep));
        foreach (var item in prepared)
        {
            var pen = new Pen(item.Brush, 1.5, DashStyle.Dash);
            context.DrawLine(pen, new Point(item.X, top), new Point(item.X, bottom));

            var labelY = item.Above
                ? aboveLaneZeroY - (item.Lane * laneStep)
                : belowLaneZeroY + (item.Lane * laneStep);
            labelY = Math.Clamp(labelY, 6, Math.Max(6, bounds.Height - item.Label.Height - 6));
            var labelCenterX = item.LabelX + (item.Label.Width / 2);
            var labelEdgeY = item.Above ? labelY + item.Label.Height + 2 : labelY - 2;
            var planeEdgeY = item.Above ? upperEdge : lowerEdge;
            context.DrawLine(
                new Pen(item.Brush, 0.8),
                new Point(item.X, planeEdgeY),
                new Point(labelCenterX, labelEdgeY));
            context.DrawText(item.Label, new Point(item.LabelX, labelY));
        }
    }

    internal static (double Top, double Bottom) CalculateAnnotationPadding(
        double availableHeight,
        int aboveLabelCount,
        int belowLabelCount)
    {
        const double basePadding = 28;
        const double estimatedLaneHeight = 19;
        var maximumBand = Math.Max(basePadding, availableHeight * 0.32);
        var top = Math.Min(
            maximumBand,
            basePadding + (Math.Max(0, aboveLabelCount) * estimatedLaneHeight));
        var bottom = Math.Min(
            maximumBand,
            basePadding + (Math.Max(0, belowLabelCount) * estimatedLaneHeight));
        return (top, bottom);
    }

    internal static int[] AssignAnnotationLanes(
        IReadOnlyList<(double Left, double Right)> intervals,
        double minimumGap = 8)
    {
        var lanes = new int[intervals.Count];
        var laneRightEdges = new List<double>();
        foreach (var candidate in intervals
                     .Select((interval, index) => (interval, index))
                     .OrderBy(candidate => candidate.interval.Left))
        {
            var lane = 0;
            while (lane < laneRightEdges.Count
                   && candidate.interval.Left < laneRightEdges[lane] + minimumGap)
            {
                lane++;
            }

            if (lane == laneRightEdges.Count)
            {
                laneRightEdges.Add(candidate.interval.Right);
            }
            else
            {
                laneRightEdges[lane] = candidate.interval.Right;
            }

            lanes[candidate.index] = lane;
        }

        return lanes;
    }

    private void Draw3D(DrawingContext context, Layout3DScene scene)
    {
        var padding = 34.0;
        var width = Math.Max(1, Bounds.Width - (padding * 2));
        var height = Math.Max(1, Bounds.Height - (padding * 2));
        var centerX = padding + (width / 2.0);
        var centerY = padding + (height / 2.0);
        var zSpan = Math.Max(1, scene.ZMax - scene.ZMin);
        var projectedWidth = zSpan + (scene.XExtent * 1.4);
        var projectedHeight = (scene.YExtent * 2.0 * VerticalStretch) + (scene.XExtent * 1.4);
        var scale = 0.88 * Math.Min(width / Math.Max(1, projectedWidth), height / Math.Max(1, projectedHeight));
        var zCenter = scene.ZMin + (zSpan / 2.0);

        Point Project(Layout3DPoint point)
        {
            var projected = ProjectDirectionToView(new Layout3DPoint(point.X, point.Y * VerticalStretch, point.Z - zCenter));
            return _viewport.Apply(
                new Point(centerX + (projected.X * scale), centerY + (projected.Y * scale)),
                Bounds.Size);
        }

        double Depth(Layout3DPoint point)
        {
            var z = point.Z - zCenter;
            var depth = (-z * Math.Sin(_yaw)) + (point.X * Math.Cos(_yaw));
            return (point.Y * Math.Sin(_pitch)) + (depth * Math.Cos(_pitch));
        }

        var solidModelStyle = VisualStyle == OpticSceneVisualStyle.SolidModel;

        context.DrawLine(
            solidModelStyle ? SolidAxisPen : AxisPen,
            Project(new Layout3DPoint(0, 0, scene.ZMin)),
            Project(new Layout3DPoint(0, 0, scene.ZMax)));

        if (solidModelStyle)
        {
            // Display the actual image surface as a ghost reference, behind the
            // traced rays and glass. It is neither a lens body nor cutaway geometry.
            foreach (var surface in scene.Surfaces.Where(surface => surface.IsImageSurface
                         && surface.RenderRole == SceneSurfaceRenderRole.OpticalSurface))
            {
                foreach (var face in SurfaceFacesForRendering(surface, cutawayEnabled: false)
                             .OrderBy(face => face.Average(Depth)))
                    DrawProjectedPolygon(context, SolidImageSurfaceBrush, face, Project);
                DrawPolyline3D(context, SolidImageSurfacePen, surface.Rim, Project);
            }
        }

        if (solidModelStyle && ShowRays)
        {
            Draw3DRays(context, scene.Rays, Project, CutawayEnabled);
        }

        if (RenderMode != OpticSceneRenderMode.Wireframe)
        {
            Draw3DSolidLensElements(
                context,
                scene.LensElements,
                scene.Surfaces,
                Project,
                Depth,
                CutawayEnabled,
                solidModelStyle,
                RenderMode == OpticSceneRenderMode.Transparent,
                HighlightedSurfaceNumber,
                _yaw,
                _pitch);
        }

        Draw3DLensElements(
            context,
            scene.LensElements,
            Project,
            RenderMode == OpticSceneRenderMode.Wireframe,
            CutawayEnabled,
            solidModelStyle,
            HighlightedSurfaceNumber);
        var elementSurfaceNumbers = scene.LensElements
            .SelectMany(element => new[] { element.FrontSurfaceNumber, element.BackSurfaceNumber })
            .ToHashSet();
        var surfacesToDraw = RenderMode != OpticSceneRenderMode.Wireframe
            ? scene.Surfaces.Where(surface => !elementSurfaceNumbers.Contains(surface.SurfaceNumber)).ToArray()
            : scene.Surfaces;
        var objectSurfaces = surfacesToDraw
            .Where(surface => surface.RenderRole != SceneSurfaceRenderRole.OpticalSurface)
            .ToArray();
        Draw3DNonSequentialObjects(
            context,
            objectSurfaces,
            Project,
            Depth,
            RenderMode,
            CutawayEnabled,
            HighlightedSurfaceNumber);
        Draw3DSurfaces(
            context,
            surfacesToDraw.Where(surface => surface.RenderRole == SceneSurfaceRenderRole.OpticalSurface).ToArray(),
            Project,
            showMeridians: !solidModelStyle,
            CutawayEnabled,
            solidModelStyle,
            HighlightedSurfaceNumber);
        if (!solidModelStyle && ShowRays)
        {
            Draw3DRays(context, scene.Rays, Project, CutawayEnabled);
        }

        if (!solidModelStyle)
        {
            DrawObjectTarget(context, Project(new Layout3DPoint(0, 0, scene.ZMin)));
        }
        DrawOrientationGizmo(context);
        if (ShowScaleBar)
        {
            DrawScaleBar(context, scale * _viewport.Zoom, solidModelStyle);
        }
    }

    private static void Draw3DNonSequentialObjects(
        DrawingContext context,
        IReadOnlyList<Layout3DSurfacePrimitive> surfaces,
        Func<Layout3DPoint, Point> project,
        Func<Layout3DPoint, double> depth,
        OpticSceneRenderMode renderMode,
        bool cutawayEnabled,
        int? highlightedSurfaceNumber)
    {
        var faces = surfaces.SelectMany(surface => surface.Faces.Select(face => new ObjectProjectedFace(
                cutawayEnabled ? ClipPolygonToCutaway(face.Points) : face.Points,
                face.Points.Count == 0 ? 0 : face.Points.Average(depth),
                surface)))
            .Where(face => face.Points.Count >= 3)
            .OrderBy(face => face.Depth)
            .ToArray();
        foreach (var face in faces)
        {
            var highlighted = face.Surface.SurfaceNumber == highlightedSurfaceNumber;
            DrawProjectedPolygon(
                context,
                renderMode == OpticSceneRenderMode.Wireframe
                    ? Brushes.Transparent
                    : highlighted
                        ? SelectedSurfaceFaceBrush
                        : NonSequentialObjectBrush(face.Surface),
                face.Points,
                project,
                highlighted ? SelectedSurfacePen : NonSequentialOutlinePen(face.Surface));
        }
    }

    private static IBrush NonSequentialObjectBrush(Layout3DSurfacePrimitive surface) => surface.RenderRole switch
    {
        SceneSurfaceRenderRole.Source => new SolidColorBrush(WithAlpha(NonSequentialSourceColor(surface.DisplayWavelengthNanometers), 78)),
        SceneSurfaceRenderRole.Detector => DetectorObjectBrush,
        _ when surface.Material.Equals("Air", StringComparison.OrdinalIgnoreCase) => NonSequentialMechanicalBrush,
        _ => NonSequentialGlassBrush
    };

    private static IPen NonSequentialOutlinePen(Layout3DSurfacePrimitive surface) => surface.RenderRole switch
    {
        SceneSurfaceRenderRole.Source when surface.Faces.Count > 8 =>
            new Pen(new SolidColorBrush(WithAlpha(NonSequentialSourceColor(surface.DisplayWavelengthNanometers), 68)), 0.4),
        SceneSurfaceRenderRole.Source =>
            new Pen(new SolidColorBrush(NonSequentialSourceColor(surface.DisplayWavelengthNanometers)), 1.5),
        SceneSurfaceRenderRole.Detector => DetectorObjectPen,
        _ => NonSequentialGeometryPen
    };

    internal static Color NonSequentialSourceColor(double? wavelengthNanometers) =>
        wavelengthNanometers is double wavelength
        && double.IsFinite(wavelength)
        && wavelength > 0
            ? SpectralColorMap.FromNanometers(wavelength)
            : Color.FromRgb(244, 155, 55);

    private static Color WithAlpha(Color color, byte alpha) =>
        Color.FromArgb(alpha, color.R, color.G, color.B);

    private void DrawSurfaces(
        DrawingContext context,
        IReadOnlyList<Layout2DSurfaceCurve> surfaces,
        Func<double, double> mapZ,
        Func<double, double> mapY,
        int? highlightedSurfaceNumber)
    {
        foreach (var surface in surfaces)
        {
            if (surface.IsStandaloneStop)
            {
                DrawApertureStop(context, surface, mapZ, mapY, ThemePen(ThemeResourceBindings.SceneApertureStop, ApertureStopPen));
                continue;
            }

            var pen = SurfacePenFor(surface);
            DrawPolyline(context, pen, surface.Points, mapZ, mapY);
        }

        var highlighted = surfaces.FirstOrDefault(surface => surface.SurfaceNumber == highlightedSurfaceNumber);
        if (highlighted is null)
        {
            return;
        }

        if (highlighted.IsStandaloneStop)
        {
            DrawApertureStop(context, highlighted, mapZ, mapY, SelectedSurfaceHaloPen);
            DrawApertureStop(context, highlighted, mapZ, mapY, SelectedSurfacePen);
            return;
        }

        DrawPolyline(context, SelectedSurfaceHaloPen, highlighted.Points, mapZ, mapY);
        DrawPolyline(context, SelectedSurfacePen, highlighted.Points, mapZ, mapY);
    }

    private static void DrawApertureStop(
        DrawingContext context,
        Layout2DSurfaceCurve surface,
        Func<double, double> mapZ,
        Func<double, double> mapY,
        IPen pen)
    {
        if (surface.Points.Count == 0)
        {
            return;
        }

        var center = surface.Points.MinBy(point => Math.Abs(point.Y))!;
        var upper = surface.Points.MaxBy(point => point.Y)!;
        var lower = surface.Points.MinBy(point => point.Y)!;
        var x = mapZ(center.Z);
        var upperY = Math.Min(mapY(upper.Y), mapY(lower.Y));
        var lowerY = Math.Max(mapY(upper.Y), mapY(lower.Y));
        var apertureHeight = Math.Max(1, lowerY - upperY);
        var bladeLength = Math.Clamp(apertureHeight * 0.14, 11, 30);
        const double capHalfWidth = 5;

        context.DrawLine(
            pen,
            new Point(x, upperY),
            new Point(x, upperY - bladeLength));
        context.DrawLine(
            pen,
            new Point(x - capHalfWidth, upperY),
            new Point(x + capHalfWidth, upperY));
        context.DrawLine(
            pen,
            new Point(x, lowerY),
            new Point(x, lowerY + bladeLength));
        context.DrawLine(
            pen,
            new Point(x - capHalfWidth, lowerY),
            new Point(x + capHalfWidth, lowerY));
    }

    private void DrawLensElements(
        DrawingContext context,
        IReadOnlyList<Layout2DLensElement> elements,
        Func<double, double> mapZ,
        Func<double, double> mapY)
    {
        foreach (var element in elements)
        {
            DrawFilledPolygon(context, ThemeBrush(ThemeResourceBindings.SceneLensFill, LensFillBrush), TwoDLensOutlinePen, element.Boundary, mapZ, mapY);
        }
    }

    private static void DrawLensEdges(
        DrawingContext context,
        IReadOnlyList<Layout2DLensEdge> edges,
        Func<double, double> mapZ,
        Func<double, double> mapY)
    {
        foreach (var edge in edges)
        {
            context.DrawLine(
                TwoDLensOutlinePen,
                new Point(mapZ(edge.Start.Z), mapY(edge.Start.Y)),
                new Point(mapZ(edge.End.Z), mapY(edge.End.Y)));
        }
    }

    private void DrawRays(
        DrawingContext context,
        IReadOnlyList<Layout2DRayPath> rays,
        Func<double, double> mapZ,
        Func<double, double> mapY)
    {
        var referenceIntensity = rays.Select(ray => ray.FinalIntensity).DefaultIfEmpty(1).Max();
        foreach (var path in rays)
        {
            var pen = RayPenFor(
                path.FieldIndex,
                path.WavelengthNanometers,
                path.Vignetted,
                RayLineWidth,
                RayOpacityFor(path.FinalIntensity, referenceIntensity));
            foreach (var segment in path.Segments)
            {
                var oriented = OrientSegment(segment);
                var points = new[]
                {
                    new Point(mapZ(oriented.Start.Z), mapY(oriented.Start.Y)),
                    new Point(mapZ(oriented.End.Z), mapY(oriented.End.Y))
                };
                context.DrawLine(pen, points[0], points[1]);
                if (ShowRayArrows)
                {
                    DrawArrow(context, pen, points);
                }
            }
        }
    }

    private void Draw3DLensElements(
        DrawingContext context,
        IReadOnlyList<Layout3DLensElement> elements,
        Func<Layout3DPoint, Point> project,
        bool showConnectors,
        bool cutawayEnabled,
        bool solidModelStyle,
        int? highlightedSurfaceNumber)
    {
        foreach (var element in elements)
        {
            var color = GlassColorFor(element.Material);
            var edgePen = color is { } tint ? new Pen(new SolidColorBrush(tint), solidModelStyle ? 1.2 : 1.7)
                : (IPen)(solidModelStyle ? SolidLensEdgePen : ThreeDLensEdgePen);
            DrawElementRim(
                context,
                element.FrontRim,
                element.FrontSurfaceNumber,
                highlightedSurfaceNumber,
                edgePen,
                project,
                cutawayEnabled);
            DrawElementRim(
                context,
                element.BackRim,
                element.BackSurfaceNumber,
                highlightedSurfaceNumber,
                edgePen,
                project,
                cutawayEnabled);
            if (element.FrontSurfaceNumber != highlightedSurfaceNumber)
            {
                DrawPolyline3D(
                    context,
                    color is { } highlight ? new Pen(new SolidColorBrush(WithAlpha(highlight, 180)), 0.9)
                        : solidModelStyle ? SolidLensHighlightPen : ThreeDLensHighlightPen,
                    element.FrontRim,
                    project,
                    cutawayEnabled);
            }

            if (!showConnectors)
            {
                continue;
            }

            var count = Math.Min(element.FrontRim.Count, element.BackRim.Count);
            if (count <= 1)
            {
                continue;
            }

            var quarter = Math.Max(1, (count - 1) / 4);
            for (var index = 0; index < count - 1; index += quarter)
            {
                DrawSegment3D(
                    context,
                    color is { } wire ? new Pen(new SolidColorBrush(WithAlpha(wire, 150)), 0.85)
                        : solidModelStyle ? SolidLensMeridianPen : ThreeDWirePen,
                    element.FrontRim[index],
                    element.BackRim[index],
                    project,
                    cutawayEnabled);
            }
        }
    }

    private static void DrawElementRim(
        DrawingContext context,
        IReadOnlyList<Layout3DPoint> rim,
        int surfaceNumber,
        int? highlightedSurfaceNumber,
        IPen edgePen,
        Func<Layout3DPoint, Point> project,
        bool cutawayEnabled)
    {
        if (surfaceNumber == highlightedSurfaceNumber)
        {
            DrawPolyline3D(context, SelectedSurfaceHaloPen, rim, project, cutawayEnabled);
            DrawPolyline3D(context, SelectedSurfacePen, rim, project, cutawayEnabled);
            return;
        }

        DrawPolyline3D(context, edgePen, rim, project, cutawayEnabled);
    }

    private void Draw3DSolidLensElements(
        DrawingContext context,
        IReadOnlyList<Layout3DLensElement> elements,
        IReadOnlyList<Layout3DSurfacePrimitive> surfaces,
        Func<Layout3DPoint, Point> project,
        Func<Layout3DPoint, double> depth,
        bool cutawayEnabled,
        bool solidModelStyle,
        bool transparent,
        int? highlightedSurfaceNumber,
        double yaw,
        double pitch)
    {
        var faces = new List<ProjectedFace>();
        var viewDirection = ViewDirection(yaw, pitch);
        var surfacesByNumber = surfaces.ToDictionary(surface => surface.SurfaceNumber);
        var glassBySurface = elements
            .Select(element => new
            {
                Element = element,
                Parameters = new GlassRenderParameters(element.RefractiveIndex,
                    ElementThickness(element, surfacesByNumber), null)
            })
            .SelectMany(item => new[]
            {
                new KeyValuePair<int, GlassRenderParameters>(item.Element.FrontSurfaceNumber, item.Parameters),
                new KeyValuePair<int, GlassRenderParameters>(item.Element.BackSurfaceNumber, item.Parameters)
            })
            .GroupBy(item => item.Key)
            .ToDictionary(group => group.Key, group => group.First().Value);
        var renderedSurfaceNumbers = new HashSet<int>();
        foreach (var element in elements)
        {
            var glass = glassBySurface.GetValueOrDefault(element.FrontSurfaceNumber,
                new GlassRenderParameters(element.RefractiveIndex, 4, null))
                with
            { Tint = GlassColorFor(element.Material) };
            if (renderedSurfaceNumbers.Add(element.FrontSurfaceNumber))
            {
                AddElementSurfaceFaces(
                    faces,
                    element.FrontFaces,
                    element.FrontSurfaceNumber,
                    highlightedSurfaceNumber,
                    glass,
                    viewDirection,
                    cutawayEnabled,
                    transparent,
                    depth);
            }

            if (renderedSurfaceNumbers.Add(element.BackSurfaceNumber))
            {
                AddElementSurfaceFaces(
                    faces,
                    element.BackFaces,
                    element.BackSurfaceNumber,
                    highlightedSurfaceNumber,
                    glass,
                    viewDirection,
                    cutawayEnabled,
                    transparent,
                    depth);
            }
        }

        foreach (var element in elements)
        {
            var glass = glassBySurface.GetValueOrDefault(element.FrontSurfaceNumber,
                new GlassRenderParameters(element.RefractiveIndex, 4, null))
                with
            { Tint = GlassColorFor(element.Material) };
            var count = Math.Min(element.FrontRim.Count, element.BackRim.Count) - 1;
            for (var index = 0; index < count; index++)
            {
                IReadOnlyList<Layout3DPoint> sideFace = new[]
                {
                    element.FrontRim[index],
                    element.FrontRim[index + 1],
                    element.BackRim[index + 1],
                    element.BackRim[index]
                };
                AddProjectedFace(
                    faces,
                    cutawayEnabled ? ClipPolygonToCutaway(sideFace) : sideFace,
                    GlassFaceBrush(
                        sideFace,
                        viewDirection,
                        glass.RefractiveIndex,
                        glass.ThicknessMillimeters,
                        isSideWall: true,
                        transparent,
                        glass.Tint),
                    depth);
            }
        }

        if (cutawayEnabled)
        {
            foreach (var element in elements)
            {
                foreach (var cap in CutawayCapsForRendering(element))
                    AddProjectedFace(faces, cap,
                        GlassColorFor(element.Material) is { } tint
                            ? new SolidColorBrush(WithAlpha(tint, 170))
                            : solidModelStyle ? SolidLensCutBrush : ThreeDLensCutBrush, depth);
            }
        }

        foreach (var face in faces.OrderBy(face => face.Depth))
        {
            DrawProjectedPolygon(context, face.Fill, face.Points, project);
        }
    }

    internal static IReadOnlyList<IReadOnlyList<Layout3DPoint>> CutawayCapsForRendering(Layout3DLensElement element)
    {
        const double tolerance = 1e-7;
        static bool Near(Layout3DPoint a, Layout3DPoint b) =>
            Math.Abs(a.Y - b.Y) <= tolerance && Math.Abs(a.Z - b.Z) <= tolerance;
        var polygons = element.FrontFaces.Concat(element.BackFaces).Select(face => face.Points).ToList();
        for (var index = 0; index + 1 < Math.Min(element.FrontRim.Count, element.BackRim.Count); index++)
            polygons.Add(new[] { element.FrontRim[index], element.FrontRim[index + 1],
                element.BackRim[index + 1], element.BackRim[index] });
        var vertices = polygons.SelectMany(points => points).ToArray();
        if (!vertices.Any(point => point.X < -tolerance) || !vertices.Any(point => point.X > tolerance))
            return Array.Empty<IReadOnlyList<Layout3DPoint>>();

        var segments = new List<(Layout3DPoint A, Layout3DPoint B)>();
        foreach (var polygon in polygons)
        {
            var hits = new List<Layout3DPoint>();
            for (var index = 0; index < polygon.Count; index++)
            {
                var start = polygon[index];
                var end = polygon[(index + 1) % polygon.Count];
                Layout3DPoint? hit = Math.Abs(start.X) <= tolerance ? new(0, start.Y, start.Z)
                    : start.X * end.X < 0 ? CutawayIntersection(start, end) : null;
                if (hit is not null && !hits.Any(point => Near(point, hit))) hits.Add(hit);
            }
            if (hits.Count != 2 || Near(hits[0], hits[1])) continue;
            if (!segments.Any(segment => (Near(segment.A, hits[0]) && Near(segment.B, hits[1]))
                || (Near(segment.B, hits[0]) && Near(segment.A, hits[1]))))
                segments.Add((hits[0], hits[1]));
        }

        // Stitch the actual mesh/plane intersections. A local meridian is not
        // the global cut plane for a decentered or tilted element.
        var caps = new List<IReadOnlyList<Layout3DPoint>>();
        while (segments.Count > 0)
        {
            var first = segments[^1];
            segments.RemoveAt(segments.Count - 1);
            var contour = new List<Layout3DPoint> { first.A, first.B };
            while (!Near(contour[0], contour[^1]))
            {
                var next = segments.FindIndex(segment => Near(segment.A, contour[^1]) || Near(segment.B, contour[^1]));
                if (next < 0) break;
                var segment = segments[next];
                segments.RemoveAt(next);
                contour.Add(Near(segment.A, contour[^1]) ? segment.B : segment.A);
            }
            if (contour.Count >= 4 && Near(contour[0], contour[^1]))
            {
                contour.RemoveAt(contour.Count - 1);
                caps.Add(contour);
            }
        }
        return caps;
    }

    private static void AddElementSurfaceFaces(
        ICollection<ProjectedFace> projectedFaces,
        IReadOnlyList<SceneSurfaceFace3Dto> surfaceFaces,
        int surfaceNumber,
        int? highlightedSurfaceNumber,
        GlassRenderParameters glass,
        Layout3DPoint viewDirection,
        bool cutawayEnabled,
        bool transparent,
        Func<Layout3DPoint, double> depth)
    {
        foreach (var face in surfaceFaces)
        {
            var points = cutawayEnabled ? ClipPolygonToCutaway(face.Points) : face.Points;
            AddProjectedFace(
                projectedFaces,
                points,
                surfaceNumber == highlightedSurfaceNumber
                    ? SelectedSurfaceFaceBrush
                    : GlassFaceBrush(
                        points,
                        viewDirection,
                        glass.RefractiveIndex,
                        glass.ThicknessMillimeters,
                        isSideWall: false,
                        transparent,
                        glass.Tint),
                depth);
        }
    }

    private static IBrush GlassFaceBrush(
        IReadOnlyList<Layout3DPoint> points,
        Layout3DPoint viewDirection,
        double refractiveIndex,
        double thicknessMillimeters,
        bool isSideWall,
        bool transparent,
        Color? materialColor)
    {
        if (!double.IsFinite(refractiveIndex))
            return ThreeDLensCutBrush;
        var normal = PolygonNormal(points);
        var facing = Math.Abs(Dot(normal, viewDirection));
        var keyLightDirection = Normalize(new Layout3DPoint(-0.38, -0.64, 0.67));
        var rimLightDirection = Normalize(new Layout3DPoint(0.72, -0.12, -0.68));
        var sample = DielectricGlassMaterial.Sample(
            refractiveIndex,
            facing,
            Math.Abs(Dot(normal, keyLightDirection)),
            Math.Abs(Dot(normal, rimLightDirection)),
            thicknessMillimeters,
            isSideWall);
        if (!transparent)
        {
            return new SolidColorBrush(TintGlass(sample.Color, materialColor));
        }

        var highlight = Math.Clamp((sample.Reflectance * 1.8) + (facing * 0.14), 0, 0.42);
        var alpha = isSideWall
            ? 116 + (highlight * 90)
            : 54 + (highlight * 110);
        var shade = isSideWall ? 0.72 : 0.9;
        return new SolidColorBrush(TintGlass(Color.FromArgb(
            (byte)Math.Clamp(Math.Round(alpha), 28, 166),
            (byte)Math.Clamp(Math.Round((55 + (highlight * 120)) * shade), 0, 255),
            (byte)Math.Clamp(Math.Round((126 + (highlight * 105)) * shade), 0, 255),
            (byte)Math.Clamp(Math.Round((190 + (highlight * 65)) * shade), 0, 255)), materialColor));
    }

    private static Color TintGlass(Color shaded, Color? materialColor) => materialColor is { } tint
        ? Color.FromArgb(shaded.A, (byte)Math.Round(shaded.R * 0.25 + tint.R * 0.75),
            (byte)Math.Round(shaded.G * 0.25 + tint.G * 0.75), (byte)Math.Round(shaded.B * 0.25 + tint.B * 0.75))
        : shaded;

    internal static IReadOnlyList<IReadOnlyList<Layout3DPoint>> SurfaceFacesForRendering(
        Layout3DSurfacePrimitive surface,
        bool cutawayEnabled)
    {
        return surface.Faces
            .Select(face => cutawayEnabled ? ClipPolygonToCutaway(face.Points) : face.Points)
            .Where(points => points.Count >= 3)
            .ToArray();
    }

    private static double ElementThickness(
        Layout3DLensElement element,
        IReadOnlyDictionary<int, Layout3DSurfacePrimitive> surfacesByNumber)
    {
        if (surfacesByNumber.TryGetValue(element.FrontSurfaceNumber, out var front) &&
            surfacesByNumber.TryGetValue(element.BackSurfaceNumber, out var back) &&
            TrySurfaceCenter(front, out var frontCenter) &&
            TrySurfaceCenter(back, out var backCenter))
        {
            return Math.Max(0.1, Math.Sqrt(LengthSquared(Subtract(backCenter, frontCenter))));
        }

        var count = Math.Min(element.FrontRim.Count, element.BackRim.Count);
        if (count == 0)
        {
            return 4;
        }

        return Math.Max(
            0.1,
            Enumerable.Range(0, count)
                .Average(index => Math.Sqrt(LengthSquared(Subtract(
                    element.BackRim[index],
                    element.FrontRim[index])))));
    }

    private static bool TrySurfaceCenter(Layout3DSurfacePrimitive surface, out Layout3DPoint center)
    {
        var firstFace = surface.Faces.FirstOrDefault(face => face.Points.Count > 0);
        if (firstFace is not null)
        {
            center = firstFace.Points[0];
            return true;
        }

        center = new Layout3DPoint(0, 0, 0);
        return false;
    }

    private static Layout3DPoint ViewDirection(double yaw, double pitch) => Normalize(new Layout3DPoint(
        Math.Cos(yaw) * Math.Cos(pitch),
        Math.Sin(pitch),
        -Math.Sin(yaw) * Math.Cos(pitch)));

    private static Layout3DPoint PolygonNormal(IReadOnlyList<Layout3DPoint> points)
    {
        if (points.Count < 3)
        {
            return new Layout3DPoint(0, 0, 1);
        }

        for (var index = 2; index < points.Count; index++)
        {
            var first = Subtract(points[1], points[0]);
            var second = Subtract(points[index], points[0]);
            var normal = Cross(first, second);
            if (LengthSquared(normal) > 1e-18)
            {
                return Normalize(normal);
            }
        }

        return new Layout3DPoint(0, 0, 1);
    }

    private static Layout3DPoint Subtract(Layout3DPoint left, Layout3DPoint right) => new(
        left.X - right.X,
        left.Y - right.Y,
        left.Z - right.Z);

    private static Layout3DPoint Cross(Layout3DPoint left, Layout3DPoint right) => new(
        (left.Y * right.Z) - (left.Z * right.Y),
        (left.Z * right.X) - (left.X * right.Z),
        (left.X * right.Y) - (left.Y * right.X));

    private static double Dot(Layout3DPoint left, Layout3DPoint right) =>
        (left.X * right.X) + (left.Y * right.Y) + (left.Z * right.Z);

    private static double LengthSquared(Layout3DPoint value) => Dot(value, value);

    private static Layout3DPoint Normalize(Layout3DPoint value)
    {
        var length = Math.Sqrt(LengthSquared(value));
        return length <= 1e-12
            ? new Layout3DPoint(0, 0, 1)
            : new Layout3DPoint(value.X / length, value.Y / length, value.Z / length);
    }

    private void Draw3DSurfaces(
        DrawingContext context,
        IReadOnlyList<Layout3DSurfacePrimitive> surfaces,
        Func<Layout3DPoint, Point> project,
        bool showMeridians,
        bool cutawayEnabled,
        bool solidModelStyle,
        int? highlightedSurfaceNumber)
    {
        if (!solidModelStyle)
        {
            foreach (var surface in surfaces.Where(surface => surface.SurfaceNumber != highlightedSurfaceNumber))
            {
                _ = GlassMaterials;
                var materialPen = !surface.IsReferencePlane && !surface.IsStandaloneStop
                    && _glassSurfaceColors.TryGetValue(surface.SurfaceNumber, out var tint)
                        ? new Pen(new SolidColorBrush(tint), 1.15) : null;
                Draw3DSurface(context, surface, project, showMeridians, cutawayEnabled, solidModelStyle, materialPen);
            }
        }

        var highlighted = surfaces.FirstOrDefault(surface => surface.SurfaceNumber == highlightedSurfaceNumber);
        if (highlighted is not null)
        {
            Draw3DSurface(context, highlighted, project, showMeridians, cutawayEnabled, solidModelStyle, SelectedSurfaceHaloPen);
            Draw3DSurface(context, highlighted, project, showMeridians, cutawayEnabled, solidModelStyle, SelectedSurfacePen);
        }
    }

    private static void Draw3DSurface(
        DrawingContext context,
        Layout3DSurfacePrimitive surface,
        Func<Layout3DPoint, Point> project,
        bool showMeridians,
        bool cutawayEnabled,
        bool solidModelStyle,
        IPen? overridePen)
    {
        var pen = overridePen ?? (surface.IsStandaloneStop
            ? StopPen
            : surface.IsReferencePlane
                ? solidModelStyle ? SolidReferencePlanePen : ReferencePlanePen
                : solidModelStyle
                    ? SolidLensEdgePen
                    : ThreeDWirePen);
        var clipSurface = cutawayEnabled && !surface.IsReferencePlane;
        DrawPolyline3D(context, pen, surface.Rim, project, clipSurface);
        if (showMeridians && !surface.IsReferencePlane)
        {
            var meridianPen = overridePen ?? (solidModelStyle ? SolidLensMeridianPen : ThreeDWirePen);
            DrawPolyline3D(context, meridianPen, surface.MeridianY, project);
            DrawPolyline3D(context, meridianPen, surface.MeridianX, project, clipSurface);
        }
    }

    private void Draw3DRays(
        DrawingContext context,
        IReadOnlyList<Layout3DRayPath> rays,
        Func<Layout3DPoint, Point> project,
        bool clipToCutaway)
    {
        var referenceIntensity = rays.Select(ray => ray.FinalIntensity).DefaultIfEmpty(1).Max();
        foreach (var ray in rays)
        {
            var pen = RayPenFor(
                ray.FieldIndex,
                ray.WavelengthNanometers,
                ray.Vignetted,
                RayLineWidth,
                RayOpacityFor(ray.FinalIntensity, referenceIntensity));
            foreach (var segment in ray.Segments)
            {
                var oriented = OrientSegment(segment);
                IReadOnlyList<Layout3DPoint> segmentPoints = new[]
                {
                    oriented.Start,
                    oriented.End
                };
                var visiblePaths = clipToCutaway
                    ? ClipPolylineToCutaway(segmentPoints)
                    : new[] { segmentPoints };
                foreach (var path in visiblePaths)
                {
                    DrawPolyline3D(context, pen, path, project);
                    if (ShowRayArrows)
                    {
                        DrawArrow(context, pen, path.Select(project).ToArray());
                    }
                }
            }
        }
    }

    internal static (ScenePoint2Dto Start, ScenePoint2Dto End) OrientSegment(
        SceneRaySegment2Dto segment)
    {
        var deltaZ = segment.End.Z - segment.Start.Z;
        var deltaY = segment.End.Y - segment.Start.Y;
        var dot = (deltaZ * segment.Direction.Z) + (deltaY * segment.Direction.Y);
        return dot >= 0
            ? (segment.Start, segment.End)
            : (segment.End, segment.Start);
    }

    internal static (ScenePoint3Dto Start, ScenePoint3Dto End) OrientSegment(
        SceneRaySegment3Dto segment)
    {
        var deltaX = segment.End.X - segment.Start.X;
        var deltaY = segment.End.Y - segment.Start.Y;
        var deltaZ = segment.End.Z - segment.Start.Z;
        var dot = (deltaX * segment.Direction.X)
            + (deltaY * segment.Direction.Y)
            + (deltaZ * segment.Direction.Z);
        return dot >= 0
            ? (segment.Start, segment.End)
            : (segment.End, segment.Start);
    }

    private void DrawObjectTarget(DrawingContext context, Point center)
    {
        var targetPen = ThemePen(ThemeResourceBindings.SceneTarget, TargetPen);
        context.DrawEllipse(null, targetPen, center, 8, 8);
        context.DrawLine(targetPen, center + new Vector(-13, 0), center + new Vector(13, 0));
        context.DrawLine(targetPen, center + new Vector(0, -13), center + new Vector(0, 13));
    }

    // The scene and its orientation indicator use the same camera rotation.
    // Directions exclude camera pan/zoom, scene centering and display Y stretch.
    internal Vector ProjectDirectionToView(Layout3DPoint direction)
    {
        var screenX = direction.Z * Math.Cos(_yaw) + direction.X * Math.Sin(_yaw);
        var depth = -direction.Z * Math.Sin(_yaw) + direction.X * Math.Cos(_yaw);
        var screenY = direction.Y * Math.Cos(_pitch) - depth * Math.Sin(_pitch);
        return new Vector(screenX, -screenY);
    }

    internal IReadOnlyList<OrientationAxisProjection> OrientationAxesForRendering()
    {
        var viewDirection = ViewDirection(_yaw, _pitch);
        return new[]
        {
            (Label: "X", Color: Color.FromRgb(210, 60, 52), Direction: new Layout3DPoint(1, 0, 0)),
            (Label: "Y", Color: Color.FromRgb(43, 154, 82), Direction: new Layout3DPoint(0, 1, 0)),
            (Label: "Z", Color: Color.FromRgb(38, 102, 196), Direction: new Layout3DPoint(0, 0, 1))
        }.Select(axis => new OrientationAxisProjection(axis.Label, axis.Color,
            ProjectDirectionToView(axis.Direction), Dot(axis.Direction, viewDirection))).ToArray();
    }

    private void DrawOrientationGizmo(DrawingContext context)
    {
        var axes = OrientationAxesForRendering().OrderBy(axis => axis.Depth).ToArray();
        var origin = new Point(48, Math.Max(48, Bounds.Height - 48));
        DrawAxes(origin, 26);

        void DrawAxes(Point center, double length)
        {
            var labelBounds = new List<Rect>();
            foreach (var axis in axes)
            {
                var brush = new SolidColorBrush(axis.Color);
                var end = center + axis.Direction * length;
                context.DrawLine(new Pen(brush, 2.2), center, end);

                var text = new FormattedText(axis.Label, System.Globalization.CultureInfo.CurrentCulture,
                    FlowDirection.LeftToRight, DisplayTypography.Typeface(), DisplayTypography.Scale(11), brush);
                var direction = axis.Direction.Length > 0.1 ? axis.Direction / axis.Direction.Length
                    : axis.Label switch { "X" => new Vector(-0.7, 0.7), "Y" => new Vector(-0.7, -0.7), _ => new Vector(0.7, 0.7) };
                var labelCenter = center + direction * Math.Max(18, axis.Direction.Length * length + 10);
                var position = labelCenter - new Vector(text.Width / 2, text.Height / 2);
                var bounds = new Rect(position, new Size(text.Width, text.Height));
                // At edge-on angles two axes can project onto the same line.
                // Separate their letters while retaining the true axis endpoints.
                for (var attempt = 0; attempt < 4 && labelBounds.Any(other => other.Inflate(2).Intersects(bounds)); attempt++)
                {
                    position += new Vector(0, attempt % 2 == 0 ? -text.Height : text.Height * 2);
                    bounds = new Rect(position, bounds.Size);
                }
                position = new Point(Math.Clamp(position.X, 2, Math.Max(2, Bounds.Width - text.Width - 2)),
                    Math.Clamp(position.Y, 2, Math.Max(2, Bounds.Height - text.Height - 2)));
                bounds = new Rect(position, bounds.Size);
                labelBounds.Add(bounds);
                context.DrawText(text, position);
            }
            context.DrawEllipse(ThemeBrush(ThemeResourceBindings.SceneOrientationFill, Brushes.White),
                new Pen(ThemeBrush(ThemeResourceBindings.SceneOrientationBorder, Brushes.Gray), 1), center, 4, 4);
        }
    }

    private IPen SurfacePenFor(Layout2DSurfaceCurve surface)
    {
        return surface.IsReferencePlane
            ? ThemePen(ThemeResourceBindings.SceneReference, ReferencePlanePen)
            : TwoDLensOutlinePen;
    }

    private Pen RayPenFor(
        int fieldIndex,
        double wavelengthNanometers,
        bool vignetted,
        double thickness,
        double opacity)
    {
        if (vignetted)
        {
            return new Pen(VignettedRayPen.Brush, thickness);
        }

        var color = RayColorMode == OpticSceneRayColorMode.Wavelength
            ? SpectralColorMap.FromNanometers(wavelengthNanometers)
            : RayColors[Math.Abs(fieldIndex) % RayColors.Length];
        return new Pen(new SolidColorBrush(color, opacity), thickness);
    }

    internal static double RayOpacityFor(double intensity, double referenceIntensity) =>
        double.IsFinite(intensity) && double.IsFinite(referenceIntensity) && referenceIntensity > 0
            ? Math.Clamp(intensity / referenceIntensity, 0, 1)
            : 1;

    private void DrawScaleBar(DrawingContext context, double pixelsPerUnit, bool darkBackground = false)
    {
        if (!double.IsFinite(pixelsPerUnit) || pixelsPerUnit <= 1e-9)
        {
            return;
        }

        var units = NiceScaleLength(120 / pixelsPerUnit);
        var width = units * pixelsPerUnit;
        var centerX = Bounds.Width / 2.0;
        var y = Math.Max(24, Bounds.Height - 24);
        var left = new Point(centerX - (width / 2.0), y);
        var right = new Point(centerX + (width / 2.0), y);
        IPen pen = darkBackground ? SolidAxisPen : ThemePen(ThemeResourceBindings.SceneAxis, AxisPen);
        context.DrawLine(pen, left, right);
        context.DrawLine(pen, left + new Vector(0, -5), left + new Vector(0, 5));
        context.DrawLine(pen, right + new Vector(0, -5), right + new Vector(0, 5));
        var label = new FormattedText(
            $"{OpticalSystemDesign.Application.Formatting.NumericDisplayFormatter.Format(units)} mm",
            System.Globalization.CultureInfo.CurrentCulture,
            FlowDirection.LeftToRight,
            DisplayTypography.Typeface(),
            VisualStyle == OpticSceneVisualStyle.OpticalLayout ? DisplayTypography.CompactBody : 12,
            darkBackground ? ThemeBrush(ThemeResourceBindings.TextOnAccent, Brushes.White) : ThemeBrush(ThemeResourceBindings.PlotText, Brushes.Black));
        context.DrawText(label, new Point(centerX - (label.Width / 2.0), y - 21));
    }

    private static double NiceScaleLength(double target)
    {
        var exponent = Math.Pow(10, Math.Floor(Math.Log10(Math.Max(target, 1e-9))));
        var normalized = target / exponent;
        var factor = normalized switch
        {
            < 1.5 => 1,
            < 3.5 => 2,
            < 7.5 => 5,
            _ => 10
        };
        return factor * exponent;
    }

    private static void DrawArrow(DrawingContext context, IPen pen, IReadOnlyList<Point> points)
    {
        if (points.Count < 2)
        {
            return;
        }

        var segmentIndex = Math.Max(1, points.Count / 2);
        var start = points[segmentIndex - 1];
        var end = points[segmentIndex];
        var direction = end - start;
        var length = Math.Sqrt((direction.X * direction.X) + (direction.Y * direction.Y));
        if (length < 8)
        {
            return;
        }

        var unit = direction / length;
        var normal = new Vector(-unit.Y, unit.X);
        var tip = start + (direction * 0.58);
        var basePoint = tip - (unit * 8);
        context.DrawLine(pen, tip, basePoint + (normal * 4));
        context.DrawLine(pen, tip, basePoint - (normal * 4));
    }

    private static void DrawFilledPolygon(
        DrawingContext context,
        IBrush fill,
        IPen outline,
        IReadOnlyList<Layout2DPoint> points,
        Func<double, double> mapZ,
        Func<double, double> mapY)
    {
        if (points.Count < 3)
        {
            return;
        }

        var geometry = new StreamGeometry();
        using (var stream = geometry.Open())
        {
            stream.BeginFigure(new Point(mapZ(points[0].Z), mapY(points[0].Y)), true);
            for (var index = 1; index < points.Count; index++)
            {
                stream.LineTo(new Point(mapZ(points[index].Z), mapY(points[index].Y)));
            }

            stream.EndFigure(true);
        }

        context.DrawGeometry(fill, outline, geometry);
    }

    private static void DrawPolyline(
        DrawingContext context,
        IPen pen,
        IReadOnlyList<Layout2DPoint> points,
        Func<double, double> mapZ,
        Func<double, double> mapY)
    {
        for (var index = 1; index < points.Count; index++)
        {
            var previous = points[index - 1];
            var current = points[index];
            context.DrawLine(
                pen,
                new Point(mapZ(previous.Z), mapY(previous.Y)),
                new Point(mapZ(current.Z), mapY(current.Y)));
        }
    }

    private static void DrawPolyline3D(
        DrawingContext context,
        IPen pen,
        IReadOnlyList<Layout3DPoint> points,
        Func<Layout3DPoint, Point> project,
        bool clipToCutaway = false)
    {
        for (var index = 1; index < points.Count; index++)
        {
            DrawSegment3D(
                context,
                pen,
                points[index - 1],
                points[index],
                project,
                clipToCutaway);
        }
    }

    private static void DrawSegment3D(
        DrawingContext context,
        IPen pen,
        Layout3DPoint start,
        Layout3DPoint end,
        Func<Layout3DPoint, Point> project,
        bool clipToCutaway)
    {
        if (!clipToCutaway)
        {
            context.DrawLine(pen, project(start), project(end));
            return;
        }

        var startInside = IsInsideCutaway(start);
        var endInside = IsInsideCutaway(end);
        if (!startInside && !endInside)
        {
            return;
        }

        if (startInside && endInside)
        {
            context.DrawLine(pen, project(start), project(end));
            return;
        }

        var intersection = CutawayIntersection(start, end);
        context.DrawLine(
            pen,
            project(startInside ? start : intersection),
            project(endInside ? end : intersection));
    }

    private static IReadOnlyList<Layout3DPoint> ClipPolygonToCutaway(IReadOnlyList<Layout3DPoint> points)
    {
        if (points.Count == 0)
        {
            return points;
        }

        var clipped = new List<Layout3DPoint>(points.Count + 2);
        var previous = points[^1];
        var previousInside = IsInsideCutaway(previous);
        foreach (var current in points)
        {
            var currentInside = IsInsideCutaway(current);
            if (currentInside != previousInside)
            {
                clipped.Add(CutawayIntersection(previous, current));
            }

            if (currentInside)
            {
                clipped.Add(current);
            }

            previous = current;
            previousInside = currentInside;
        }

        return clipped;
    }

    internal static IReadOnlyList<IReadOnlyList<Layout3DPoint>> ClipPolylineToCutaway(
        IReadOnlyList<Layout3DPoint> points)
    {
        if (points.Count < 2)
        {
            return Array.Empty<IReadOnlyList<Layout3DPoint>>();
        }

        var paths = new List<IReadOnlyList<Layout3DPoint>>();
        List<Layout3DPoint>? currentPath = null;

        for (var index = 1; index < points.Count; index++)
        {
            var start = points[index - 1];
            var end = points[index];
            var startInside = IsInsideCutaway(start);
            var endInside = IsInsideCutaway(end);

            if (startInside && endInside)
            {
                currentPath ??= new List<Layout3DPoint> { start };
                currentPath.Add(end);
                continue;
            }

            if (startInside)
            {
                currentPath ??= new List<Layout3DPoint> { start };
                currentPath.Add(CutawayIntersection(start, end));
                paths.Add(currentPath);
                currentPath = null;
                continue;
            }

            if (endInside)
            {
                currentPath = new List<Layout3DPoint>
                {
                    CutawayIntersection(start, end),
                    end
                };
            }
        }

        if (currentPath is { Count: >= 2 })
        {
            paths.Add(currentPath);
        }

        return paths;
    }

    private static bool IsInsideCutaway(Layout3DPoint point) => point.X <= 1e-9;

    private static Layout3DPoint CutawayIntersection(Layout3DPoint start, Layout3DPoint end)
    {
        var deltaX = end.X - start.X;
        if (Math.Abs(deltaX) < 1e-12)
        {
            return new Layout3DPoint(0, start.Y, start.Z);
        }

        var ratio = -start.X / deltaX;
        return new Layout3DPoint(
            0,
            start.Y + ((end.Y - start.Y) * ratio),
            start.Z + ((end.Z - start.Z) * ratio));
    }

    private static void AddProjectedFace(
        ICollection<ProjectedFace> faces,
        IReadOnlyList<Layout3DPoint> points,
        IBrush fill,
        Func<Layout3DPoint, double> depth)
    {
        if (points.Count < 3)
        {
            return;
        }

        faces.Add(new ProjectedFace(points, points.Average(depth), fill));
    }

    private static void DrawProjectedPolygon(
        DrawingContext context,
        IBrush fill,
        IReadOnlyList<Layout3DPoint> points,
        Func<Layout3DPoint, Point> project,
        IPen? outline = null)
    {
        if (points.Count < 3)
        {
            return;
        }

        var geometry = new StreamGeometry();
        using (var stream = geometry.Open())
        {
            stream.BeginFigure(project(points[0]), true);
            for (var index = 1; index < points.Count; index++)
            {
                stream.LineTo(project(points[index]));
            }

            stream.EndFigure(true);
        }

        context.DrawGeometry(fill, outline, geometry);
    }

    private sealed record ProjectedFace(
        IReadOnlyList<Layout3DPoint> Points,
        double Depth,
        IBrush Fill);

    private sealed record ObjectProjectedFace(
        IReadOnlyList<Layout3DPoint> Points,
        double Depth,
        Layout3DSurfacePrimitive Surface);

    private readonly record struct GlassRenderParameters(
        double RefractiveIndex,
        double ThicknessMillimeters,
        Color? Tint);
}
