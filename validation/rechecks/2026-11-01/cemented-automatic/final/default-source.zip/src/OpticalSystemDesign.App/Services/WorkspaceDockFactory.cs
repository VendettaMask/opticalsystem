using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Layout;
using Avalonia.Media;
using Dock.Avalonia.Controls;
using Dock.Model.Controls;
using Dock.Model.Core;
using Dock.Model.Mvvm;
using Dock.Model.Mvvm.Controls;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Manufacturing;
using OpticalSystemDesign.App.Panels;
using OpticalSystemDesign.Application.Contracts;
using OpticalSystemDesign.Application.Services;
using Orientation = Dock.Model.Core.Orientation;

namespace OpticalSystemDesign.App.Services;

public sealed class WorkspaceDockFactory : Factory
{
    public const string RootId = "workspace:root";
    public const string MainLayoutId = "workspace:main";
    public const string ToolDockId = "workspace:tools";
    public const string SystemToolId = "tool:system-options";
    public const string DocumentDockId = "workspace:documents";
    private const string DocumentDockGroup = "workspace:document-area";
    private const string ToolDockGroup = "workspace:tool-area";
    public const string LensDocumentId = "document:lens-editor";
    public const string Viewer2DDocumentId = "document:viewer-2d";
    public const string NonSequentialObjectDocumentId = "document:non-sequential-object-editor";
    public const string NonSequentialDetectorViewerDocumentId = "document:non-sequential-detector-viewer";

    private readonly IWorkbenchApplication _application;
    private readonly AppSettings _settings;
    private readonly Func<string, Task<bool>>? _openProjectAsync;
    private readonly Func<IReadOnlyList<AppAction>> _userGuideActions;
    private readonly SurfaceSelectionService _surfaceSelection = new();
    private readonly Dictionary<string, WorkspaceDocumentDescriptor> _descriptors = new(StringComparer.Ordinal);
    private string? _restoredActiveDocumentId;
    private readonly Dictionary<string, Control> _content = new(StringComparer.Ordinal);

    public WorkspaceDockFactory(
        IWorkbenchApplication application,
        AppSettings settings,
        Func<string, Task<bool>>? openProjectAsync = null,
        Func<IReadOnlyList<AppAction>>? userGuideActions = null)
    {
        _application = application;
        _settings = settings;
        _openProjectAsync = openProjectAsync;
        _userGuideActions = userGuideActions ?? (() => Array.Empty<AppAction>());
        HostWindowLocator = new Dictionary<string, Func<IHostWindow?>>
        {
            [nameof(IDockWindow)] = () => new HostWindow()
        };
    }

    public event EventHandler? LayoutChanged;

    public IRootDock? RootLayout { get; private set; }

    public IDocumentDock? PrimaryDocumentDock { get; private set; }

    public IReadOnlyCollection<WorkspaceDocumentDescriptor> Descriptors => _descriptors.Values;

    public bool HasUnsavedToleranceChanges => TolerancingPanels()
        .Any(panel => panel.HasUnsavedChanges);

    public async Task<bool> SaveUnsavedToleranceChangesAsync(TopLevel owner)
    {
        foreach (var panel in TolerancingPanels().Where(panel => panel.HasUnsavedChanges))
        {
            if (!await panel.TrySaveChangesAsync(owner))
            {
                return false;
            }
        }

        return true;
    }

    public void ApplyDisplaySettings(double previousFontSize)
    {
        foreach (var control in _content.Values)
        {
            DisplayTypography.ApplyRecursively(control, previousFontSize);

            if (control is IDisplaySettingsAware aware)
            {
                aware.RefreshDisplaySettings();
            }

            control.InvalidateVisual();
        }
    }

    public override IDocumentDock CreateDocumentDock()
    {
        return new DocumentDock
        {
            DockGroup = DocumentDockGroup,
            IsCollapsable = false,
            CanCreateDocument = false,
            EnableWindowDrag = true,
            CloseButtonShowMode = DocumentCloseButtonShowMode.Always
        };
    }

    public override void SplitToDock(IDock dock, IDockable dockable, DockOperation operation)
    {
        if (dock is not IDocumentDock || dockable is not IDocumentDock split
            || operation is not (DockOperation.Left or DockOperation.Right or DockOperation.Top or DockOperation.Bottom)
            || dock.Owner is not IDock { VisibleDockables: { } children } owner
            || !children.Contains(dock))
        {
            base.SplitToDock(dock, dockable, operation);
            return;
        }

        // Dock copies the source group's ID when creating a split. Groups must
        // remain distinct when the layout is serialized and explicitly restored.
        if (RootLayout is not null && EnumerateDockables(RootLayout)
            .Any(item => !ReferenceEquals(item, split) && item.Id == split.Id))
            split.Id = DocumentDockId + ":" + Guid.NewGuid().ToString("N");
        split.IsCollapsable = true;

        // Keep document splits inside the target's rectangle. Dock's default
        // same-orientation flattening can rebalance the constrained sidebar and
        // make a half-width preview become a third-width document after dropping.
        // Reuse its native split layout, splitter, ownership and docking events.
        var index = children.IndexOf(dock);
        var layout = CreateSplitLayout(dock, split, operation);
        var wasDefault = ReferenceEquals(owner.DefaultDockable, dock);
        RemoveVisibleDockableAt(owner, index);
        OnDockableRemoved(split);
        OnDockableUndocked(split, operation);
        InsertVisibleDockable(owner, index, layout);
        OnDockableAdded(split);
        owner.ActiveDockable = layout;
        if (wasDefault) owner.DefaultDockable = layout;
        InitDockable(layout, owner);
        OnDockableDocked(split, operation);
    }

    public override IRootDock CreateLayout()
    {
        _descriptors.Clear();
        _restoredActiveDocumentId = null;
        DisposeContent();
        var primaryDescriptor = _application.Modes.CurrentMode == OpticalWorkbenchMode.NonSequential
            ? new WorkspaceDocumentDescriptor(
                NonSequentialObjectDocumentId,
                WorkspaceDocumentTypes.NonSequentialObjectEditor,
                "非序列对象数据")
            : new WorkspaceDocumentDescriptor(
                LensDocumentId,
                WorkspaceDocumentTypes.LensEditor,
                "镜头数据");
        _descriptors[primaryDescriptor.Id] = primaryDescriptor;
        var primaryDocument = CreateDocument(primaryDescriptor);
        var documentDock = (DocumentDock)CreateDocumentDock();
        documentDock.Id = DocumentDockId;
        documentDock.Title = "文档";
        documentDock.VisibleDockables = CreateList<IDockable>(primaryDocument);
        if (_application.Modes.CurrentMode == OpticalWorkbenchMode.Sequential)
        {
            var viewerDescriptor = new WorkspaceDocumentDescriptor(
                Viewer2DDocumentId,
                WorkspaceDocumentTypes.Viewer2D,
                "二维视图");
            _descriptors[viewerDescriptor.Id] = viewerDescriptor;
            documentDock.VisibleDockables.Add(CreateDocument(viewerDescriptor));
        }
        documentDock.ActiveDockable = primaryDocument;

        var systemContent = CreateSystemToolContent();
        _content[SystemToolId] = systemContent;
        var systemTool = new Tool
        {
            Id = SystemToolId,
            DockGroup = ToolDockGroup,
            Title = _application.Modes.CurrentMode == OpticalWorkbenchMode.NonSequential
                ? "非序列设置"
                : "系统选项",
            CanClose = false,
            CanFloat = true,
            CanPin = true,
            Context = systemContent
        };
        var initialWidth = _settings.LeftPaneWidth > 0
            ? Math.Clamp(_settings.LeftPaneWidth, UiDensity.SystemOptionsMinimumWidth, UiDensity.SystemOptionsMaximumWidth)
            : UiDensity.SystemOptionsPreferredWidth;
        var toolDock = new ToolDock
        {
            Id = ToolDockId,
            DockGroup = ToolDockGroup,
            Title = "系统选项",
            Alignment = Alignment.Left,
            Proportion = initialWidth / 1440.0,
            GripMode = GripMode.Visible,
            AutoHide = false,
            IsCollapsable = true,
            VisibleDockables = CreateList<IDockable>(systemTool),
            ActiveDockable = systemTool
        };
        var mainLayout = new ProportionalDock
        {
            Id = MainLayoutId,
            Title = "工作区",
            Orientation = Orientation.Horizontal,
            VisibleDockables = CreateList<IDockable>(
                toolDock,
                new ProportionalDockSplitter(),
                documentDock),
            ActiveDockable = documentDock
        };
        var root = new RootDock
        {
            Id = RootId,
            DockGroup = ToolDockGroup,
            Title = "Optical System Design",
            IsCollapsable = false,
            VisibleDockables = CreateList<IDockable>(mainLayout),
            DefaultDockable = mainLayout,
            ActiveDockable = mainLayout,
            LeftPinnedDockables = CreateList<IDockable>(),
            RightPinnedDockables = CreateList<IDockable>(),
            TopPinnedDockables = CreateList<IDockable>(),
            BottomPinnedDockables = CreateList<IDockable>()
        };
        RootLayout = root;
        PrimaryDocumentDock = documentDock;
        return root;
    }

    public override void InitLayout(IDockable layout)
    {
        ConsolidateSinglePageDocuments(layout, WorkspaceDocumentTypes.MaterialLibrary, "材料库", "document:material-library");
        ConsolidateSinglePageDocuments(layout, WorkspaceDocumentTypes.OpticalDrawing, "光学制图", "document:optical-drawing");
        ContextLocator = EnumerateDockables(layout)
            .Where(dockable => !string.IsNullOrWhiteSpace(dockable.Id))
            .GroupBy(dockable => dockable.Id, StringComparer.Ordinal)
            .ToDictionary(
                group => group.Key,
                group => new Func<object?>(() => ResolveContent(group.Key)),
                StringComparer.Ordinal);
        DockableLocator = new Dictionary<string, Func<IDockable?>>
        {
            [RootId] = () => RootLayout,
            [DocumentDockId] = () => PrimaryDocumentDock
        };
        base.InitLayout(layout);
        RootLayout = layout as IRootDock ?? FindRoot(layout);
        var mainDockables = EnumerateMainDockables(layout).ToArray();
        PrimaryDocumentDock = mainDockables.OfType<IDocumentDock>()
            .FirstOrDefault(dock => dock.Id == DocumentDockId)
            ?? mainDockables.OfType<IDocumentDock>().FirstOrDefault();
        foreach (var dockable in EnumerateDockables(layout))
        {
            // Give restored pages the same boundary as new ones. Native group
            // validation suppresses root-wide targets (whose preview includes
            // the sidebar) and prevents documents from docking onto tools.
            if (dockable is (IDocument and not ITool) or IDocumentDock)
                dockable.DockGroup = DocumentDockGroup;
            if (dockable.Id is RootId or ToolDockId or SystemToolId)
                dockable.DockGroup = ToolDockGroup;
            // Apply to restored layouts as well as newly created ones. The table can
            // scroll horizontally; the system editors need a usable sidebar width.
            if (dockable.Id is SystemToolId or ToolDockId)
                dockable.MinWidth = UiDensity.SystemOptionsMinimumWidth;
            if (dockable.Id == ToolDockId)
                dockable.MaxWidth = UiDensity.SystemOptionsMaximumWidth;
            if (dockable.Id == SystemToolId || _descriptors.ContainsKey(dockable.Id))
            {
                if (dockable is Document && _descriptors.TryGetValue(dockable.Id, out var descriptor)
                    && descriptor.TypeId is WorkspaceDocumentTypes.Analysis or WorkspaceDocumentTypes.OpticalDrawing)
                    dockable.Title = descriptor.Title;
                dockable.Context = ResolveContent(dockable.Id);
            }
        }
    }

    public void RegisterDescriptors(IEnumerable<WorkspaceDocumentDescriptor> descriptors, string? activeDocumentId = null)
    {
        _descriptors.Clear();
        _restoredActiveDocumentId = activeDocumentId;
        foreach (var descriptor in descriptors)
        {
            _descriptors[descriptor.Id] = NormalizeDocumentDescriptor(descriptor);
        }

        var primaryId = _application.Modes.CurrentMode == OpticalWorkbenchMode.NonSequential
            ? NonSequentialObjectDocumentId
            : LensDocumentId;
        if (!_descriptors.ContainsKey(primaryId))
        {
            _descriptors[primaryId] = _application.Modes.CurrentMode == OpticalWorkbenchMode.NonSequential
                ? new WorkspaceDocumentDescriptor(
                    NonSequentialObjectDocumentId,
                    WorkspaceDocumentTypes.NonSequentialObjectEditor,
                    "非序列对象数据")
                : new WorkspaceDocumentDescriptor(
                    LensDocumentId,
                    WorkspaceDocumentTypes.LensEditor,
                    "镜头数据");
        }
    }

    public Document OpenDocument(WorkspaceDocumentDescriptor descriptor)
    {
        descriptor = NormalizeDocumentDescriptor(descriptor);
        var existing = RootLayout is null
            ? null
            : EnumerateDockables(RootLayout).OfType<Document>()
                .FirstOrDefault(document => document.Id == descriptor.Id
                    || (descriptor.TypeId is WorkspaceDocumentTypes.MaterialLibrary or WorkspaceDocumentTypes.OpticalDrawing
                        && Descriptor(document.Id)?.TypeId == descriptor.TypeId));
        if (existing is not null)
        {
            if (descriptor.TypeId == WorkspaceDocumentTypes.OpticalDrawing
                && existing.Owner is IRootDock hiddenRoot && hiddenRoot.HiddenDockables?.Contains(existing) == true)
            {
                var restoredDock = ActiveDocumentDock() ?? PrimaryDocumentDock
                    ?? throw new InvalidOperationException("工作区中没有文档停靠区域。");
                hiddenRoot.HiddenDockables.Remove(existing);
                AddDockable(restoredDock, existing);
                RaiseLayoutChanged();
            }
            if (existing.Id == descriptor.Id && descriptor.TypeId != WorkspaceDocumentTypes.OpticalDrawing)
            {
                _descriptors[descriptor.Id] = descriptor;
                if (descriptor.TypeId == WorkspaceDocumentTypes.Analysis) existing.Title = descriptor.Title;
            }

            SetActiveDockable(existing);
            if (existing.Owner is IDock owner)
            {
                SetFocusedDockable(owner, existing);
            }

            ActivateWindow(existing);
            return existing;
        }

        _descriptors[descriptor.Id] = descriptor;
        var document = CreateDocument(descriptor);
        var target = ActiveDocumentDock() ?? PrimaryDocumentDock
            ?? throw new InvalidOperationException("工作区中没有文档停靠区域。");
        AddDockable(target, document);
        SetActiveDockable(document);
        SetFocusedDockable(target, document);
        RaiseLayoutChanged();
        return document;
    }

    private static WorkspaceDocumentDescriptor NormalizeMaterialLibrary(WorkspaceDocumentDescriptor descriptor) =>
        descriptor.TypeId is WorkspaceDocumentTypes.MaterialLibrary or WorkspaceDocumentTypes.GlassCatalog
            ? descriptor with { TypeId = WorkspaceDocumentTypes.MaterialLibrary, Title = "材料库" }
            : descriptor;

    private WorkspaceDocumentDescriptor NormalizeDocumentDescriptor(WorkspaceDocumentDescriptor descriptor)
    {
        descriptor = NormalizeMaterialLibrary(descriptor);
        if (descriptor.TypeId == WorkspaceDocumentTypes.OpticalDrawing)
        {
            // Saved pages retain their dock IDs and standard; all use the same drawing editor.
            var settings = descriptor.Settings is null
                ? new Dictionary<string, string>()
                : new Dictionary<string, string>(descriptor.Settings);
            var standard = !settings.ContainsKey("standard") && descriptor.Id == "document:optical-drawing-gb-1991"
                ? OpticalDrawingStandard.GbT13323_1991
                : OpticalDrawingStandardFrom(settings);
            settings["standard"] = standard.ToString();
            return descriptor with { Title = "光学制图", Settings = settings };
        }
        if (descriptor.TypeId != WorkspaceDocumentTypes.Analysis) return descriptor;
        var canonical = _application.Analyses.CanonicalKey(descriptor.AnalysisName ?? descriptor.Title);
        var displayName = WorkbenchAnalysisCatalog.DisplayName(canonical);
        if (_application.Analyses.CanonicalKey(descriptor.Title) == canonical)
            return descriptor with { Title = displayName };
        // Normalize built-in clone captions from saved layouts without rewriting
        // user-supplied titles or the analysis identity/settings.
        if (descriptor.Title.StartsWith(canonical + "（副本）", StringComparison.Ordinal))
        {
            var suffix = descriptor.Title[canonical.Length..];
            if (suffix.Replace("（副本）", string.Empty, StringComparison.Ordinal).Length == 0)
                return descriptor with { Title = displayName + suffix };
        }
        return descriptor;
    }

    private void ConsolidateSinglePageDocuments(IDockable layout, string typeId, string title, string preferredId)
    {
        var dockables = EnumerateDockables(layout).ToArray();
        var libraries = dockables.OfType<Document>()
            .Where(document => Descriptor(document.Id)?.TypeId == typeId)
            .OrderByDescending(document => typeId == WorkspaceDocumentTypes.OpticalDrawing
                && document.Id == _restoredActiveDocumentId)
            .ThenByDescending(document => typeId == WorkspaceDocumentTypes.OpticalDrawing
                && document.Owner is IDock owner && ReferenceEquals(owner.ActiveDockable, document))
            .ThenByDescending(document => document.Id == preferredId)
            .ToArray();
        if (libraries.Length == 0)
        {
            return;
        }

        // Preserve the retained page's saved position and ID, including legacy-only layouts.
        libraries[0].Title = title;
        var duplicateIds = libraries.Skip(1).Select(document => document.Id).ToHashSet(StringComparer.Ordinal);
        if (duplicateIds.Count == 0)
        {
            return;
        }

        foreach (var dockable in dockables)
        {
            if (dockable is IDock dock)
            {
                RemoveDuplicates(dock.VisibleDockables);
            }

            if (dockable is IRootDock root)
            {
                RemoveDuplicates(root.HiddenDockables);
                RemoveDuplicates(root.LeftPinnedDockables);
                RemoveDuplicates(root.RightPinnedDockables);
                RemoveDuplicates(root.TopPinnedDockables);
                RemoveDuplicates(root.BottomPinnedDockables);
            }
        }

        foreach (var id in duplicateIds)
        {
            _descriptors.Remove(id);
        }

        if (layout is IRootDock rootLayout)
        {
            WorkspaceDockLayoutSerializer.NormalizeDockRelations(rootLayout);
            WorkspaceDockLayoutSerializer.RemoveEmptyFloatingWindows(rootLayout);
        }

        void RemoveDuplicates(IList<IDockable>? collection)
        {
            if (collection is null) return;
            for (var index = collection.Count - 1; index >= 0; index--)
            {
                if (duplicateIds.Contains(collection[index].Id)) collection.RemoveAt(index);
            }
        }
    }

    public WorkspaceDocumentDescriptor? Descriptor(string id)
    {
        return _descriptors.TryGetValue(id, out var descriptor) ? descriptor : null;
    }

    public T? DocumentContent<T>(string id)
        where T : Control => ResolveContent(id) as T;

    public void RefreshDocumentContent(string id)
    {
        if (!_content.TryGetValue(id, out var control))
        {
            return;
        }

        switch (control)
        {
            case ToleranceTextDocumentPanel textDocument:
                textDocument.Refresh();
                break;
            case ToleranceChartDocumentPanel chartDocument:
                chartDocument.Refresh();
                break;
        }
    }

    public void UpdateDescriptor(WorkspaceDocumentDescriptor descriptor)
    {
        _descriptors[descriptor.Id] = descriptor;
    }

    public void ApplyLock(string id, bool locked)
    {
        if (_content.TryGetValue(id, out var control))
        {
            SetLocked(control, locked);
        }
    }

    public IReadOnlyList<WorkspaceDocumentDescriptor> SnapshotDescriptors()
    {
        return _descriptors.Values.Select(descriptor =>
        {
            if (!_content.TryGetValue(descriptor.Id, out var control))
            {
                return descriptor;
            }

            return control switch
            {
                AnalysisPanel analysis => descriptor with
                {
                    AnalysisName = analysis.AnalysisName,
                    InstanceId = analysis.InstanceId,
                    Settings = new Dictionary<string, string>(analysis.Settings),
                    IsLocked = analysis.IsLocked
                },
                ViewerPanel viewer => descriptor with { IsLocked = viewer.IsLocked },
                OpticalDrawingPanel drawing => descriptor with
                {
                    Settings = new Dictionary<string, string>(descriptor.Settings ?? new Dictionary<string, string>())
                    {
                        ["standard"] = drawing.DrawingStandard.ToString()
                    }
                },
                _ => descriptor
            };
        }).ToArray();
    }

    public override bool OnDockableClosing(IDockable? dockable)
    {
        if (dockable?.Id is LensDocumentId or NonSequentialObjectDocumentId)
        {
            return false;
        }

        return base.OnDockableClosing(dockable);
    }

    public override void OnDockableClosed(IDockable? dockable)
    {
        if (dockable is not null)
        {
            if (_content.TryGetValue(dockable.Id, out var control)
                && control is not TolerancingPanel { HasUnsavedChanges: true })
            {
                _content.Remove(dockable.Id);
                if (control is IDisposable disposable)
                {
                    disposable.Dispose();
                }
            }

            _descriptors.Remove(dockable.Id);
        }

        base.OnDockableClosed(dockable);
        RepairEmptyPrimaryDocumentDock();
        RaiseLayoutChanged();
    }

    public override void OnDockableMoved(IDockable? dockable)
    {
        base.OnDockableMoved(dockable);
        RaiseLayoutChanged();
    }

    public override void OnDockableDocked(IDockable? dockable, DockOperation operation)
    {
        // A split's temporary document group is not attached until SplitToDock
        // finishes; do not promote it while the native move is still in flight.
        var target = dockable as IDocumentDock ?? dockable?.Owner as IDocumentDock;
        if (RootLayout is not null && target is not null
            && EnumerateMainDockables(RootLayout).Any(item => ReferenceEquals(item, target)))
            RepairEmptyPrimaryDocumentDock();
        base.OnDockableDocked(dockable, operation);
        RaiseLayoutChanged();
    }

    private void RepairEmptyPrimaryDocumentDock()
    {
        if (RootLayout is null || PrimaryDocumentDock is not { VisibleDockables.Count: 0 } empty) return;
        var groups = EnumerateMainDockables(RootLayout).OfType<IDocumentDock>()
            .Where(group => group.VisibleDockables is { Count: > 0 }).ToArray();
        var replacement = groups.FirstOrDefault(group => group.VisibleDockables!.Any(item =>
            item.Id is LensDocumentId or NonSequentialObjectDocumentId)) ?? groups.FirstOrDefault();
        // Retain the empty main drop area when all pages are floating elsewhere.
        if (replacement is null) return;
        empty.IsCollapsable = true;
        CollapseDock(empty);
        replacement.Id = DocumentDockId;
        replacement.IsCollapsable = false;
        PrimaryDocumentDock = replacement;
    }

    public override void OnDockableUndocked(IDockable? dockable, DockOperation operation)
    {
        base.OnDockableUndocked(dockable, operation);
        RaiseLayoutChanged();
    }

    public override void OnWindowAdded(IDockWindow? window)
    {
        base.OnWindowAdded(window);
        RaiseLayoutChanged();
    }

    public override void OnWindowRemoved(IDockWindow? window)
    {
        base.OnWindowRemoved(window);
        RaiseLayoutChanged();
    }

    public IReadOnlyList<Document> OpenDocuments()
    {
        return RootLayout is null
            ? Array.Empty<Document>()
            : EnumerateDockables(RootLayout).OfType<Document>().ToArray();
    }

    public void DisposeContent()
    {
        foreach (var disposable in _content.Values.OfType<IDisposable>())
        {
            disposable.Dispose();
        }

        _content.Clear();
    }

    internal Action<bool> BeginContentReplacement()
    {
        var previous = _content.ToArray();
        _content.Clear();
        var completed = false;
        return commit =>
        {
            if (completed) return;
            completed = true;
            if (commit)
            {
                foreach (var item in previous.Select(pair => pair.Value).OfType<IDisposable>()) DisposeRetired(item);
            }
            else
            {
                foreach (var item in _content.Values.OfType<IDisposable>()) DisposeRetired(item);
                _content.Clear();
                foreach (var (key, value) in previous) _content[key] = value;
            }
        };

        static void DisposeRetired(IDisposable item)
        {
            try { item.Dispose(); }
            catch (Exception error) { System.Diagnostics.Trace.TraceWarning($"Retired workspace content cleanup failed: {error}"); }
        }
    }

    private Document CreateDocument(WorkspaceDocumentDescriptor descriptor)
    {
        return new Document
        {
            Id = descriptor.Id,
            DockGroup = DocumentDockGroup,
            Title = descriptor.Title,
            CanClose = descriptor.TypeId is not WorkspaceDocumentTypes.LensEditor
                and not WorkspaceDocumentTypes.NonSequentialObjectEditor,
            CanFloat = true,
            CanDrag = true,
            CanDrop = true,
            Context = ResolveContent(descriptor.Id)
        };
    }

    private Control ResolveContent(string id)
    {
        if (_content.TryGetValue(id, out var existing))
        {
            return existing;
        }

        if (id == SystemToolId)
        {
            return _content[id] = CreateSystemToolContent();
        }

        if (!_descriptors.TryGetValue(id, out var descriptor))
        {
            var unavailable = new TextBlock
            {
                Text = "此页面类型不可用，已从会话中跳过。",
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            unavailable.BindThemeResource(TextBlock.ForegroundProperty, ThemeResourceBindings.MutedText);
            return unavailable;
        }

        Control control = descriptor.TypeId switch
        {
            WorkspaceDocumentTypes.LensEditor => new LensEditorPanel(
                _application.Prescription,
                _application.Events,
                _surfaceSelection,
                _application.MultiConfiguration),
            WorkspaceDocumentTypes.NonSequentialObjectEditor => new NonSequentialObjectEditorPanel(
                _application.NonSequential,
                _application.Events),
            WorkspaceDocumentTypes.Viewer2D => new ViewerPanel(
                _application.Visualization,
                _application.Events,
                _surfaceSelection,
                SceneDimension.TwoDimensional,
                modes: _application.Modes,
                nonSequentialAnalysis: _application.NonSequentialAnalysis),
            WorkspaceDocumentTypes.Viewer3D => new ViewerPanel(
                _application.Visualization,
                _application.Events,
                _surfaceSelection,
                SceneDimension.ThreeDimensional,
                modes: _application.Modes,
                nonSequentialAnalysis: _application.NonSequentialAnalysis),
            WorkspaceDocumentTypes.NonSequentialDetectorViewer => new NonSequentialDetectorViewerPanel(
                _application.NonSequential,
                _application.NonSequentialAnalysis),
            WorkspaceDocumentTypes.SolidModel => new ViewerPanel(
                _application.Visualization,
                _application.Events,
                _surfaceSelection,
                SceneDimension.ThreeDimensional,
                ViewerPresentationMode.SolidModel,
                _application.Modes,
                _application.NonSequentialAnalysis),
            WorkspaceDocumentTypes.MaterialLibrary => new MaterialLibraryPanel(_application.Materials),
            WorkspaceDocumentTypes.LensLibrary => new LensLibraryPanel(
                _application.Lenses,
                OpenLensLibraryProjectAsync),
            WorkspaceDocumentTypes.StockLensCatalog => new CommercialLensCatalogPanel(
                _application.Lenses,
                OpenLensLibraryProjectAsync),
            WorkspaceDocumentTypes.StockLensMatching => new StockLensMatchingPanel(
                _application.Documents,
                _application.Lenses,
                _application.Events),
            WorkspaceDocumentTypes.MaterialAnalysis => new MaterialAnalysisPanel(
                _application.Materials,
                MaterialAnalysisKindFrom(descriptor.Settings)),
            WorkspaceDocumentTypes.Manufacturability => new ManufacturabilityPanel(
                _application.Prescription,
                _application.Events),
            WorkspaceDocumentTypes.OpticalDrawing => new OpticalDrawingPanel(
                _application.Prescription,
                _application.Materials,
                _application.Events,
                _application.Visualization,
                OpticalDrawingStandardFrom(descriptor.Settings)),
            WorkspaceDocumentTypes.Optimization => new OptimizationPanel(_application.Prescription, _application.Optimization, _application.Events),
            WorkspaceDocumentTypes.Tolerancing => new TolerancingPanel(
                _application.Documents,
                _application.Prescription,
                _application.Tolerancing,
                _application.Events),
            WorkspaceDocumentTypes.ToleranceReport => new ToleranceTextDocumentPanel(
                "公差报告",
                "tolerance-report.txt",
                () => TolerancingEditor().BuildToleranceReportText()),
            WorkspaceDocumentTypes.ToleranceHistogram => new ToleranceChartDocumentPanel(
                () => TolerancingEditor().BuildHistogramChartView()),
            WorkspaceDocumentTypes.ToleranceYield => new ToleranceChartDocumentPanel(
                () => TolerancingEditor().BuildYieldChartView()),
            WorkspaceDocumentTypes.UserGuide => new UserGuidePanel(_userGuideActions()),
            WorkspaceDocumentTypes.OperandHelp => new OperandHelpPanel(_application.Optimization),
            WorkspaceDocumentTypes.MultiConfiguration => new MultiConfigurationPanel(_application.Prescription, _application.MultiConfiguration, _application.Events),
            WorkspaceDocumentTypes.Analysis => new AnalysisPanel(
                _application.Analyses,
                _application.Visualization,
                _application.Documents,
                _application.Events,
                _settings,
                descriptor.AnalysisName ?? descriptor.Title,
                descriptor.InstanceId,
                descriptor.Settings),
            _ => throw new InvalidDataException(
                $"Unsupported workspace document type '{descriptor.TypeId}'.")
        };
        SetLocked(control, descriptor.IsLocked);
        if (control is TemplatedControl templated)
        {
            DisplayTypography.Apply(templated);
        }
        _content[id] = control;
        if (control is OpticalDrawingPanel drawing)
        {
            drawing.DrawingStandardChanged += (_, _) =>
            {
                if (!_descriptors.TryGetValue(id, out var current)) return;
                _descriptors[id] = current with
                {
                    Settings = new Dictionary<string, string>(current.Settings ?? new Dictionary<string, string>())
                    {
                        ["standard"] = drawing.DrawingStandard.ToString()
                    }
                };
                RaiseLayoutChanged();
            };
        }
        return control;
    }

    private TolerancingPanel TolerancingEditor()
    {
        const string id = "document:tolerancing";
        if (!_descriptors.ContainsKey(id))
        {
            _descriptors[id] = new WorkspaceDocumentDescriptor(
                id,
                WorkspaceDocumentTypes.Tolerancing,
                "公差数据编辑器");
        }

        return ResolveContent(id) as TolerancingPanel
            ?? throw new InvalidOperationException("公差数据编辑器不可用。");
    }

    private static MaterialAnalysisKind MaterialAnalysisKindFrom(
        IReadOnlyDictionary<string, string>? settings)
    {
        return settings is not null
            && settings.TryGetValue("MaterialAnalysisKind", out var value)
            && Enum.TryParse<MaterialAnalysisKind>(value, ignoreCase: true, out var kind)
                ? kind
                : MaterialAnalysisKind.GlassMap;
    }

    internal async Task OpenLensLibraryProjectAsync(string path)
    {
        if (_openProjectAsync is null)
        {
            throw new InvalidOperationException(
                "Opening a lens-library project requires the host unsaved-changes workflow.");
        }

        if (!await _openProjectAsync(path))
        {
            return;
        }

        OpenDocument(new WorkspaceDocumentDescriptor(
            LensDocumentId,
            WorkspaceDocumentTypes.LensEditor,
            "镜头数据"));
    }

    private IEnumerable<TolerancingPanel> TolerancingPanels() => _content.Values
        .OfType<TolerancingPanel>()
        .Distinct();

    private Control CreateSystemToolContent()
    {
        if (_application.Modes.CurrentMode == OpticalWorkbenchMode.NonSequential)
        {
            var nonSequentialPanel = new NonSequentialModePanel(
                _application.NonSequential,
                _application.Events);
            DisplayTypography.Apply(nonSequentialPanel);
            return nonSequentialPanel;
        }

        var panel = new SystemPropertiesPanel(
            _application.Prescription,
            _application.Materials,
            _application.Events);
        DisplayTypography.Apply(panel);
        return panel;
    }

    private IDocumentDock? ActiveDocumentDock()
    {
        if (RootLayout?.ActiveDockable is IDocumentDock direct)
        {
            return direct;
        }

        var activeDocument = OpenDocuments().FirstOrDefault(document => document.IsActive);
        return activeDocument?.Owner as IDocumentDock;
    }

    private void RaiseLayoutChanged() => LayoutChanged?.Invoke(this, EventArgs.Empty);

    private static void SetLocked(Control control, bool value)
    {
        switch (control)
        {
            case AnalysisPanel analysis:
                analysis.IsLocked = value;
                break;
            case ViewerPanel viewer:
                viewer.IsLocked = value;
                break;
        }
    }

    public static IEnumerable<IDockable> EnumerateDockables(IDockable root)
    {
        return EnumerateDockables(root, new HashSet<IDockable>());
    }

    private static IEnumerable<IDockable> EnumerateMainDockables(IDockable root)
    {
        return EnumerateMainDockables(root, new HashSet<IDockable>());
    }

    private static IEnumerable<IDockable> EnumerateMainDockables(
        IDockable dockable,
        HashSet<IDockable> seen)
    {
        if (!seen.Add(dockable))
        {
            yield break;
        }

        yield return dockable;
        if (dockable is not IDock dock || dock.VisibleDockables is null)
        {
            yield break;
        }

        foreach (var child in dock.VisibleDockables)
        {
            foreach (var descendant in EnumerateMainDockables(child, seen))
            {
                yield return descendant;
            }
        }
    }

    private static IEnumerable<IDockable> EnumerateDockables(IDockable dockable, HashSet<IDockable> seen)
    {
        if (!seen.Add(dockable))
        {
            yield break;
        }

        yield return dockable;
        if (dockable is IRootDock root)
        {
            foreach (var collection in new[]
                     {
                         root.HiddenDockables,
                         root.LeftPinnedDockables,
                         root.RightPinnedDockables,
                         root.TopPinnedDockables,
                         root.BottomPinnedDockables
                     })
            {
                if (collection is null)
                {
                    continue;
                }

                foreach (var child in collection)
                {
                    foreach (var descendant in EnumerateDockables(child, seen))
                    {
                        yield return descendant;
                    }
                }
            }

            if (root.PinnedDock is not null)
            {
                foreach (var descendant in EnumerateDockables(root.PinnedDock, seen))
                {
                    yield return descendant;
                }
            }

            if (root.Windows is not null)
            {
                foreach (var window in root.Windows)
                {
                    if (window.Layout is null)
                    {
                        continue;
                    }

                    foreach (var child in EnumerateDockables(window.Layout, seen))
                    {
                        yield return child;
                    }
                }
            }
        }

        if (dockable is not IDock dock)
        {
            yield break;
        }

        if (dock.VisibleDockables is not null)
        {
            foreach (var child in dock.VisibleDockables)
            {
                foreach (var descendant in EnumerateDockables(child, seen))
                {
                    yield return descendant;
                }
            }
        }

        foreach (var related in new[]
                 {
                     dock.ActiveDockable,
                     dock.DefaultDockable,
                     dock.FocusedDockable
                 })
        {
            if (related is null)
            {
                continue;
            }

            foreach (var descendant in EnumerateDockables(related, seen))
            {
                yield return descendant;
            }
        }
    }

    private static OpticalDrawingStandard OpticalDrawingStandardFrom(
        IReadOnlyDictionary<string, string>? settings)
    {
        if (settings is null || !settings.TryGetValue("standard", out var value))
        {
            return OpticalDrawingStandard.Iso10110;
        }

        if (Enum.TryParse<OpticalDrawingStandard>(value, out var standard)
            && Enum.IsDefined(standard))
        {
            return standard;
        }

        return value switch
        {
            "GB/T 13323—1991" or "GB/T 13323-1991" => OpticalDrawingStandard.GbT13323_1991,
            _ => OpticalDrawingStandard.Iso10110
        };
    }

}
