using System.Collections.ObjectModel;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Controls.Templates;
using Avalonia.Data;
using Avalonia.Layout;
using Avalonia.Markup.Xaml.MarkupExtensions;
using Avalonia.Media;
using Avalonia.Styling;
using Avalonia.Threading;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.App.Theming;
using OpticalSystemDesign.App.ViewModels;
using OpticalSystemDesign.Application.Contracts;
using OpticalSystemDesign.Application.Formatting;

namespace OpticalSystemDesign.App.Panels;

public sealed class OptimizationPanel : UserControl, IDisposable, IDisplaySettingsAware
{
    private readonly IPrescriptionService _prescription;
    private readonly IOptimizationService _optimization;
    private readonly IWorkspaceEventStream _events;
    private readonly ObservableCollection<MeritOperandEditorRow> _rows = new();
    private readonly DataGrid _grid;
    private readonly string[] _operandCodes;
    private readonly IReadOnlyDictionary<string, MeritOperandTypeDto> _operandTypes;
    private readonly DataGridColumn[] _parameterColumns = new DataGridColumn[8];
    private readonly ComboBox _optimizerPicker = new() { MinWidth = 165, SelectedIndex = 0 };
    private readonly NumericUpDown _iterationsInput = new()
    {
        Minimum = 1,
        Maximum = 1000,
        Increment = 10,
        Value = 30,
        Width = 88,
        ShowButtonSpinner = false
    };
    private readonly TextBlock _summary = new()
    {
        VerticalAlignment = VerticalAlignment.Center
    };
    private readonly TextBlock _variables = new()
    {
        VerticalAlignment = VerticalAlignment.Center
    };
    private readonly OperationStatusBar _operationStatus = new();
    private readonly TextBlock _result = new()
    {
        TextWrapping = TextWrapping.Wrap,
        Margin = new Avalonia.Thickness(8, 4)
    };
    private CancellationTokenSource? _runCancellation;
    private int _generation;
    private bool _refreshing;
    private bool _disposed;

    public OptimizationPanel(
        IPrescriptionService prescription,
        IOptimizationService optimization,
        IWorkspaceEventStream events)
    {
        _prescription = prescription;
        _optimization = optimization;
        _events = events;
        var operandTypes = optimization.GetMeritOperandTypes();
        _operandCodes = operandTypes.Select(type => type.Code).ToArray();
        _operandTypes = operandTypes.ToDictionary(type => type.Code, StringComparer.OrdinalIgnoreCase);
        _optimizerPicker.ItemsSource = optimization.OptimizerNames;
        _grid = CreateGrid();

        var addButton = CommandButton("plus", "添加");
        addButton.Click += (_, _) => AddOperand();
        var removeButton = CommandButton("trash-2", "删除");
        removeButton.Click += (_, _) => RemoveSelected();
        var upButton = CommandButton("arrow-up", "上移");
        upButton.Click += (_, _) => MoveSelected(-1);
        var downButton = CommandButton("arrow-down", "下移");
        downButton.Click += (_, _) => MoveSelected(1);
        var wizardButton = CommandButton("sparkles", "优化向导");
        wizardButton.Click += async (_, _) => await ShowWizardAsync();
        var refreshButton = CommandButton("refresh-cw", "重新计算");
        refreshButton.Click += (_, _) => Refresh();
        var runButton = CommandButton("play", "执行优化");
        runButton.Classes.Add("accent");
        runButton.Click += async (_, _) => await RunAsync();

        var editToolbar = new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            Children =
            {
                addButton,
                removeButton,
                upButton,
                downButton,
                Separator(),
                wizardButton,
                refreshButton
            }
        };
        var runToolbar = new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            Children =
            {
                new TextBlock { Text = "算法", VerticalAlignment = VerticalAlignment.Center },
                _optimizerPicker,
                new TextBlock { Text = "迭代", VerticalAlignment = VerticalAlignment.Center },
                _iterationsInput,
                runButton,
                _variables,
                _operationStatus
            }
        };
        var toolbar = new StackPanel
        {
            Spacing = 6,
            Children = { editToolbar, runToolbar, _summary }
        };
        var commandBar = new Border
        {
            BorderThickness = new Avalonia.Thickness(0, 0, 0, 1),
            Padding = new Avalonia.Thickness(10, 6),
            Child = toolbar
        };
        var resultBorder = new Border
        {
            BorderThickness = new Avalonia.Thickness(0, 1, 0, 0),
            Child = _result
        };
        _summary.BindThemeResource(TextBlock.ForegroundProperty, ThemeResourceBindings.MutedText);
        _variables.BindThemeResource(TextBlock.ForegroundProperty, ThemeResourceBindings.MutedText);
        commandBar.BindThemeResource(Border.BackgroundProperty, ThemeResourceBindings.Surface);
        commandBar.BindThemeResource(Border.BorderBrushProperty, ThemeResourceBindings.Border);
        resultBorder.BindThemeResource(Border.BackgroundProperty, ThemeResourceBindings.Surface);
        resultBorder.BindThemeResource(Border.BorderBrushProperty, ThemeResourceBindings.Border);
        var root = new DockPanel();
        root.BindThemeResource(Panel.BackgroundProperty, ThemeResourceBindings.Workspace);
        DockPanel.SetDock(commandBar, Avalonia.Controls.Dock.Top);
        DockPanel.SetDock(resultBorder, Avalonia.Controls.Dock.Bottom);
        root.Children.Add(commandBar);
        root.Children.Add(resultBorder);
        root.Children.Add(_grid);
        Content = root;

        _events.Changed += OnWorkspaceChanged;
        Refresh();
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        _generation++;
        _events.Changed -= OnWorkspaceChanged;
        _runCancellation?.Cancel();
        _runCancellation?.Dispose();
        _operationStatus.Dispose();
    }

    public void RefreshDisplaySettings() => Refresh();

    private DataGrid CreateGrid()
    {
        var grid = new DataGrid
        {
            ItemsSource = _rows,
            AutoGenerateColumns = false,
            CanUserReorderColumns = true,
            CanUserResizeColumns = true,
            GridLinesVisibility = DataGridGridLinesVisibility.All,
            HeadersVisibility = DataGridHeadersVisibility.Column,
            SelectionMode = DataGridSelectionMode.Extended,
            IsReadOnly = false,
            RowHeight = UiDensity.CompactTableRowHeight,
            ColumnHeaderHeight = UiDensity.TableHeaderHeight,
            FrozenColumnCount = 2,
            BorderThickness = new Avalonia.Thickness(1),
            RowBackground = new SolidColorBrush(MeritOperandRowPalette.Resolve(null))
        };
        grid.BindThemeResource(DataGrid.BorderBrushProperty, ThemeResourceBindings.Border);
        grid.Styles.Add(new Style(selector => selector
            .OfType<DataGridRow>()
            .Class("merit-color-row")
            .Class(":selected"))
        {
            Setters =
            {
                new Setter(
                    DataGridRow.BorderBrushProperty,
                    new DynamicResourceExtension("AccentFillColorDefaultBrush"))
            }
        });
        grid.LoadingRow += (_, args) => ApplyRowAppearance(args.Row);
        grid.Columns.Add(TextColumn("#", nameof(MeritOperandEditorRow.Index), 44, true));
        grid.Columns.Add(TypeColumn());
        for (var index = 0; index < _parameterColumns.Length; index++)
        {
            _parameterColumns[index] = ParameterColumn(index);
            grid.Columns.Add(_parameterColumns[index]);
        }
        grid.Columns.Add(TextColumn("目标", nameof(MeritOperandEditorRow.Target), 88));
        grid.Columns.Add(TextColumn("权重", nameof(MeritOperandEditorRow.Weight), 82));
        grid.Columns.Add(TextColumn("当前值", nameof(MeritOperandEditorRow.ValueDisplay), 104, true));
        grid.Columns.Add(TextColumn("贡献", nameof(MeritOperandEditorRow.ContributionDisplay), 104, true));
        grid.Columns.Add(TextColumn("注释", nameof(MeritOperandEditorRow.Comment), 260));
        grid.Columns.Add(TextColumn("状态", nameof(MeritOperandEditorRow.Error), 200, true));
        grid.CellEditEnded += (_, args) =>
        {
            if (args.EditAction == DataGridEditAction.Commit)
            {
                PersistRows();
            }
        };
        grid.SelectionChanged += (_, _) =>
            UpdateParameterHeaders(grid.SelectedItem as MeritOperandEditorRow);
        return grid;
    }

    private DataGridTemplateColumn TypeColumn() => new()
    {
        Header = "类型",
        Width = new DataGridLength(92),
        CellTemplate = new FuncDataTemplate<MeritOperandEditorRow>((row, _) =>
        {
            var picker = new ComboBox
            {
                ItemsSource = _operandCodes,
                SelectedItem = row?.Type,
                HorizontalContentAlignment = HorizontalAlignment.Left
            };
            picker.SelectionChanged += (_, _) =>
            {
                if (row is null || picker.SelectedItem is not string type || row.Type == type)
                {
                    return;
                }

                row.Type = type;
                row.Enabled = !row.IsBlank;
                row.ApplyTypeMetadata(_operandTypes.GetValueOrDefault(type));
                UpdateParameterHeaders(row);
                PersistRows();
            };
            return picker;
        })
    };

    private void OnWorkspaceChanged(object? sender, WorkspaceChangedEventArgs args)
    {
        Dispatcher.UIThread.Post(() =>
        {
            if (!_disposed)
            {
                Refresh();
            }
        });
    }

    private void Refresh()
    {
        if (_disposed || _refreshing)
        {
            return;
        }

        _refreshing = true;
        try
        {
            var selectedIndex = (_grid.SelectedItem as MeritOperandEditorRow)?.Index ?? -1;
            var data = _optimization.GetMeritFunction();
            _rows.Clear();
            foreach (var operand in data)
            {
                _rows.Add(new MeritOperandEditorRow(
                    operand,
                    _operandTypes.GetValueOrDefault(operand.Type)));
            }

            _grid.SelectedItem = _rows.FirstOrDefault(row => row.Index == selectedIndex);
            var activeRows = _rows.Where(row => row.Enabled && !row.IsBlank).ToArray();
            var merit = activeRows
                .Where(row => double.IsFinite(row.Contribution))
                .Sum(row => row.Contribution);
            var errors = activeRows.Count(row => !string.IsNullOrWhiteSpace(row.Error));
            _summary.Text = _rows.Count == 0
                ? "评价函数为空。可添加操作数，或生成默认 RMS 点列/波前评价函数。"
                : $"操作数：{activeRows.Length}　评价函数：{NumericDisplayFormatter.Format(merit)}"
                  + (errors > 0 ? $"　错误：{errors}" : string.Empty);
            UpdateVariableSummary();
            if (_optimizerPicker.SelectedItem is null && _optimization.OptimizerNames.Count > 0)
            {
                _optimizerPicker.SelectedIndex = 0;
            }
        }
        finally
        {
            _refreshing = false;
        }
    }

    private void AddOperand()
    {
        _rows.Add(new MeritOperandEditorRow(new MeritOperandRowDto(
            _rows.Count + 1,
            true,
            "RSCE",
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            string.Empty), _operandTypes.GetValueOrDefault("RSCE")));
        _grid.SelectedItem = _rows[^1];
        PersistRows();
    }

    private async Task ShowWizardAsync()
    {
        if (TopLevel.GetTopLevel(this) is not Window owner)
        {
            return;
        }

        await new OptimizationWizardWindow(_prescription, _optimization).ShowDialog<bool>(owner);
    }

    private void RemoveSelected()
    {
        var selected = _grid.SelectedItems.Cast<MeritOperandEditorRow>().ToArray();
        if (selected.Length == 0 && _grid.SelectedItem is MeritOperandEditorRow row)
        {
            selected = new[] { row };
        }

        foreach (var operand in selected)
        {
            _rows.Remove(operand);
        }

        PersistRows();
    }

    private void MoveSelected(int offset)
    {
        if (_grid.SelectedItem is not MeritOperandEditorRow row)
        {
            return;
        }

        var currentIndex = _rows.IndexOf(row);
        var nextIndex = Math.Clamp(currentIndex + offset, 0, _rows.Count - 1);
        if (currentIndex == nextIndex)
        {
            return;
        }

        _rows.Move(currentIndex, nextIndex);
        _grid.SelectedItem = row;
        PersistRows();
    }

    private void PersistRows()
    {
        if (_refreshing || _disposed)
        {
            return;
        }

        for (var index = 0; index < _rows.Count; index++)
        {
            _rows[index].Index = index + 1;
        }

        _optimization.SetMeritFunction(_rows.Select(row => row.ToDto()).ToArray());
    }

    private async Task RunAsync()
    {
        if (SelectedVariables().Count == 0)
        {
            _operationStatus.MarkFailed("缺少可优化变量");
            _result.Text = "请先设置优化变量（表面、物理膜层或多配置单元格）。";
            return;
        }

        if (_rows.All(row => !row.Enabled || row.IsBlank))
        {
            _operationStatus.MarkFailed("缺少启用的评价函数操作数");
            _result.Text = "请先添加至少一个启用的评价函数操作数。";
            return;
        }

        _runCancellation?.Cancel();
        _runCancellation?.Dispose();
        _runCancellation = new CancellationTokenSource();
        var cancellationToken = _runCancellation.Token;
        var generation = ++_generation;
        var optimizer = _optimizerPicker.SelectedItem as string
            ?? _optimization.OptimizerNames.FirstOrDefault()
            ?? "Damped Least Squares";
        var iterations = _iterationsInput.Value.HasValue
            ? decimal.ToInt32(_iterationsInput.Value.Value)
            : 80;
        _result.Text = "正在根据当前评价函数优化…";
        _operationStatus.Start("正在优化…", () => _runCancellation?.Cancel());

        try
        {
            var result = await _optimization.OptimizeVariablesAsync(
                optimizer,
                iterations,
                cancellationToken);
            if (_disposed || cancellationToken.IsCancellationRequested || generation != _generation)
            {
                return;
            }

            _result.Text =
                $"{result.Message}　评价函数：{NumericDisplayFormatter.Format(result.InitialMerit)} → {NumericDisplayFormatter.Format(result.FinalMerit)}　" +
                $"迭代：{result.Iterations}　函数评价：{result.FunctionEvaluations}　停止原因：{result.StopReason}";
            _operationStatus.MarkSynced("优化完成");
            Refresh();
        }
        catch (OperationCanceledException)
        {
            if (!_disposed && generation == _generation)
            {
                _operationStatus.MarkStale("优化已取消");
            }
        }
        catch (Exception exception)
        {
            if (!_disposed && generation == _generation)
            {
                _operationStatus.MarkFailed($"优化失败：{exception.Message}");
                _result.Text = $"优化失败：{exception.Message}";
            }
        }
    }

    private void UpdateVariableSummary()
    {
        var selectedVariables = SelectedVariables();
        _variables.Text = selectedVariables.Count == 0
            ? "未设置变量"
            : $"变量 {selectedVariables.Count} 个";
    }

    private IReadOnlyList<string> SelectedVariables() => _optimization.GetMarkedVariables().Select(variable => variable.Name).ToArray();

    private static DataGridTextColumn TextColumn(string header, string property, double width, bool readOnly = false) => new()
    {
        Header = header,
        Binding = new Binding(property) { Mode = readOnly ? BindingMode.OneWay : BindingMode.TwoWay },
        Width = new DataGridLength(width),
        IsReadOnly = readOnly
    };

    private static DataGridTemplateColumn ParameterColumn(int parameterIndex)
    {
        var property = $"Parameter{parameterIndex + 1}";
        return new DataGridTemplateColumn
        {
            Header = $"参数 {parameterIndex + 1}",
            Width = new DataGridLength(88),
            CellTemplate = new FuncDataTemplate<MeritOperandEditorRow>((row, _) =>
            {
                var value = new TextBlock
                {
                    VerticalAlignment = VerticalAlignment.Center,
                    TextAlignment = TextAlignment.Right
                };
                value.Bind(TextBlock.TextProperty, new Binding(property));
                if (row is not null)
                {
                    ToolTip.SetTip(value, row.ParameterLabel(parameterIndex));
                }

                return value;
            }),
            CellEditingTemplate = new FuncDataTemplate<MeritOperandEditorRow>((row, _) =>
            {
                var editor = new TextBox
                {
                    HorizontalContentAlignment = HorizontalAlignment.Right,
                    IsReadOnly = row is null || !row.IsParameterEditable(parameterIndex)
                };
                editor.Bind(TextBox.TextProperty, new Binding(property) { Mode = BindingMode.TwoWay });
                if (row is not null)
                {
                    ToolTip.SetTip(editor, row.ParameterLabel(parameterIndex));
                }

                return editor;
            })
        };
    }

    private void UpdateParameterHeaders(MeritOperandEditorRow? row)
    {
        for (var index = 0; index < _parameterColumns.Length; index++)
        {
            var label = row?.ParameterLabel(index) ?? $"参数 {index + 1}";
            _parameterColumns[index].Header = string.IsNullOrWhiteSpace(label) ? "—" : label;
            _parameterColumns[index].IsVisible = row is null ? index < 7
                : !string.IsNullOrWhiteSpace(label) && (row.IsParameterEditable(index)
                    || !label.Equals("Unused", StringComparison.OrdinalIgnoreCase));
        }
    }

    private static Button CommandButton(string iconName, string text) => new()
    {
        Content = new LocalIconLabel(iconName, text),
        MinWidth = 74
    };

    private static Separator Separator()
    {
        var separator = new Separator
        {
            Width = 1,
            Height = 28,
            Margin = new Avalonia.Thickness(4, 0)
        };
        separator.BindThemeResource(Avalonia.Controls.Separator.BackgroundProperty, ThemeResourceBindings.Border);
        return separator;
    }

    private static void ApplyRowAppearance(DataGridRow row)
    {
        if (row.DataContext is not MeritOperandEditorRow operand)
        {
            return;
        }

        row.Classes.Set("merit-color-row", true);
        var visual = MeritOperandRowPalette.ResolveVisual(
            operand.Type,
            !string.IsNullOrWhiteSpace(operand.Error),
            ThemeRegistry.IsDarkVisual(row.ActualThemeVariant));
        row.Background = new SolidColorBrush(visual.Background);
        row.Foreground = new SolidColorBrush(visual.Foreground);
    }
}
