using System.IO.Compression;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Metrics;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

if (args.Length is < 3 or > 4)
    throw new ArgumentException("Usage: CompareFftReferenceDrift <repo> <formal-root or -> <output.json> [fixed-root]");
var repo = Path.GetFullPath(args[0]);
var formal = args[1] == "-" ? null : Path.GetFullPath(args[1]);
var output = Path.GetFullPath(args[2]);
var fixedRoot = args.Length == 4 ? Path.GetFullPath(args[3]) : null;
var proof = Path.Combine(repo, "validation/rechecks/2026-11-07");
var prior = Path.Combine(repo, "artifacts/validation/focal-fft-domain-20261108/full/analyses");
var frozenPath = Path.Combine(repo, "validation/repairs/2026-10-21/sequential-corpus-full-evidence.zip");
var scratch = Path.Combine(Path.GetDirectoryName(output)!, "comparator-native-inputs");
Directory.CreateDirectory(scratch);
const string frozenHash = "1dc562461d4e39ac9bf54f3c2309a0bb81fdeccfb092554cd8e9c14aa80760ad";
Require(HashFile(frozenPath) == frozenHash, "Frozen archive hash changed");
using var frozen = ZipFile.OpenRead(frozenPath);
var phase = JsonFiles.Read<JsonElement>(Path.Combine(proof, "fft-phase-refinement/results.json"));
var policyBytes = ReadMember(frozen, "run/comparison-settings.json");
var policyHash = JsonFiles.Hash(policyBytes);
Require(policyHash == Text(phase, "policySha256"), "Policy hash changed");
var policy = JsonSerializer.Deserialize<ComparisonConfiguration>(policyBytes, JsonFiles.Options)!;
var previous = Path.Combine(repo, "validation/rechecks/2026-11-08/fft-default-phase-recovery");
var previousSummary = JsonFiles.Read<JsonElement>(Path.Combine(previous, "summary.json"));
var previousLegacy = Path.Combine(previous, "frozen-low-native-comparison.json");
Require(HashFile(previousLegacy) == Text(previousSummary.GetProperty("reportFileHashes"), "frozen-low-native-comparison.json"),
    "Prior direct comparison changed");
var scope = JsonFiles.Read<JsonElement>(previousLegacy).EnumerateArray()
    .Where(row => Text(row, "conclusion") == "Difference").ToDictionary(row => Int(row, "index"));
Require(scope.Count == 16, "Expected the 16 previous direct differences");
var results = new List<object>();
var passed = 0;
var pending = 0;
var failed = 0;
var rows = phase.GetProperty("rows").EnumerateArray().ToArray();
Require(rows.Length == 20 && rows.Select(row => Int(row, "index")).Distinct().Count() == 20, "Reference cohort changed");
foreach (var row in rows.Where(row => scope.ContainsKey(Int(row, "index"))))
{
    var index = Int(row, "index");
    var id = index.ToString("D4");
    var key = Text(row, "key");
    try
    {
        var baseline = JsonFiles.Read<WorkbenchJob>(Path.Combine(prior, id, "request.json"));
        var request = baseline.Request;
        Require(request.Fingerprint == Text(row, "originalRequestFingerprint") && key == request.CanonicalAnalysisKey,
            "Baseline request identity mismatch");
        Require(Int(row, "originalPupil") == request.PupilSampling && Text(row, "frozenConclusion") == "Error", "Baseline is not the original phase error");
        var entry = AnalysisComparisonRegistry.Get(key);
        var tolerances = policy.Analyses[key].Quantities;
        var raw = row.GetProperty("native").EnumerateArray().ToArray();
        Require(raw.Length == 2 && Int(raw[0], "sampling") < Int(raw[1], "sampling"), "Expected two ordered native densities");
        var legacyEntry = frozen.Entries.Single(item => item.FullName.StartsWith($"run/analyses/{id}-", StringComparison.Ordinal)
            && item.FullName.EndsWith("/native/data.json", StringComparison.Ordinal));
        using var legacyReadback = JsonDocument.Parse(ReadMember(frozen,
            legacyEntry.FullName[..(legacyEntry.FullName.LastIndexOf('/') + 1)] + "captured-settings.json"));
        Require(Text(legacyReadback.RootElement.GetProperty("properties"), "SampleSize").EndsWith($"_{request.PupilSampling}x{request.PupilSampling}", StringComparison.Ordinal),
            "Legacy native readback is not the original pupil density");
        var native = raw.Select(tier => ExtractTier(tier, request, row, repo, proof, Path.Combine(scratch, id), entry, legacyReadback.RootElement)).ToArray();
        var baselineAxes = row.GetProperty("frozenNativeDomainCoverage").EnumerateArray().ToArray();
        var domain = key == "PSF" ? native[1].Numeric : new NumericResult
        {
            Series = native[1].Numeric.Series.Select(curve =>
            {
                var axis = baselineAxes.Single(item => Text(item, "id") == curve.Id);
                var min = axis.GetProperty("coreMinimum").GetDouble();
                var max = axis.GetProperty("coreMaximum").GetDouble();
                var count = Int(axis, "originalCount");
                return curve with { X = Enumerable.Range(0, count).Select(i => min + (max - min) * i / (count - 1)).ToArray() };
            }).ToList()
        };
        var convergence = CompareAtDomain(native[0].Numeric, native[1].Numeric, domain, tolerances);
        Require(convergence.All(metric => metric.Conclusion == Conclusion.Pass && metric.Coverage == 1)
            && Text(row.GetProperty("nativeConvergence"), "conclusion") == "Pass", "Native pair fails convergence on the original domain");

        var originalData = ReadMember(frozen, legacyEntry.FullName);
        Require(JsonFiles.Hash(originalData) == Text(row, "originalNativeDomainSha256"), "Original native data identity changed");
        object[] endpoints = [];
        if (key == "FFT PSF Cross Section")
        {
            var originalPath = Path.Combine(scratch, id, "original", "data.json");
            Directory.CreateDirectory(Path.GetDirectoryName(originalPath)!);
            File.WriteAllBytes(originalPath, originalData);
            var oldText = ReadMember(frozen, Path.ChangeExtension(legacyEntry.FullName, ".txt"));
            File.WriteAllBytes(Path.ChangeExtension(originalPath, ".txt"), oldText);
            var old = ResultNormalizer.Zemax(originalPath, entry, request with { NativeLensUnit = null });
            endpoints = EndpointAudit(domain, old, native[1].Numeric, baselineAxes, tolerances, JsonFiles.Hash(oldText));
        }

        var runPath = formal is null ? null : Path.Combine(formal, id);
        var dataPath = runPath is null ? null : Path.Combine(runPath, "data.json");
        if (dataPath is null || !File.Exists(dataPath))
        {
            if (formal is not null) pending++;
            results.Add(new { index, key, state = formal is null ? "ReferencesVerified" : "Pending", native = native.Select(t => t.Receipt), convergence, endpoints });
            continue;
        }

        var jobPath = Path.Combine(runPath!, "request.json");
        var provenancePath = Path.Combine(runPath!, "provenance.json");
        var job = JsonFiles.Read<WorkbenchJob>(jobPath);
        var provenance = JsonFiles.Read<JsonElement>(provenancePath);
        Require(job.Request.Fingerprint == request.Fingerprint && Text(provenance, "requestFingerprint") == request.Fingerprint,
            "Formal default request differs from the original canonical request");
        Require(Text(provenance, "snapshotSha256") == HashFile(baseline.SnapshotPath)
            && Text(provenance, "snapshotSha256") == HashFile(job.SnapshotPath), "Formal prescription differs from the baseline snapshot");
        var product = JsonFiles.Read<AnalysisData>(dataPath);
        Require(product.Outcome == AnalysisOutcome.Success, $"Formal Workbench outcome {product.Outcome}: {product.OutcomeReason}");
        var certificate = (JsonElement)product.Values["FourierSamplingValidation"];
        var requestedPhase = (JsonElement)product.Values["RequestedPupilPhaseSampling"];
        CheckCertificate(certificate, requestedPhase, request, row);
        var actual = ResultNormalizer.Workbench(dataPath, entry, request);
        VerifyDomain(actual, domain, request);
        var legacyPath = Path.Combine(repo, "artifacts/zemax-sequential-corpus/20261021/full-v1", legacyEntry.FullName["run/".Length..]);
        var legacyFolder = Path.GetDirectoryName(legacyPath)!;
        var legacyPayloads = new List<object>();
        foreach (var name in new[] { "data.json", "data.txt", "captured-settings.json", "model.json", "unit-normalization.json" })
        {
            var path = Path.Combine(legacyFolder, name);
            if (!File.Exists(path)) continue;
            var relative = legacyEntry.FullName[..(legacyEntry.FullName.LastIndexOf('/') + 1)] + name;
            var digest = HashFile(path);
            Require(digest == JsonFiles.Hash(ReadMember(frozen, relative)), "Legacy native payload differs: " + relative);
            legacyPayloads.Add(new { member = relative, sha256 = digest });
        }
        var oldNative = ResultNormalizer.Zemax(legacyPath, entry, request, dataPath);
        object? coordinateScale = null;
        if (request.NativeLensUnit == "CM")
        {
            // These older captures identify the centimeter source but lack a
            // ScaleByUnits sidecar. Check image scale independently of irradiance.
            var snapshot = JsonFiles.Read<JsonElement>(job.SnapshotPath);
            var wavelengthMicrometers = snapshot.GetProperty("wavelengths")[request.Wavelength - 1]
                .GetProperty("nanometers").GetDouble() * .001;
            var workingFNumber = ((JsonElement)product.Values["WorkingFNumber"]).GetDouble();
            var axis = oldNative.Series.Single();
            var legacyEstimate = (axis.X.Max() - axis.X.Min()) / (wavelengthMicrometers * (request.PupilSampling - 2));
            var highEstimates = native.Select((tier, i) =>
            {
                var n = Int(raw[i], "sampling");
                var x = tier.Numeric.Series.Single().X;
                var spacing = (x.Max() - x.Min()) / (x.Length - 1);
                return spacing / (wavelengthMicrometers * Math.Sqrt(2d / n) * (n - 2) / n);
            }).ToArray();
            Require(highEstimates.Append(legacyEstimate).All(f => Math.Abs(f / workingFNumber - 1) < 1e-6),
                "Legacy centimeter-source coordinates do not match the independently checked physical image scale");
            coordinateScale = new { wavelengthMicrometers, workingFNumber, legacyEstimate, highEstimates };
        }
        var direct = DirectMetrics(actual, oldNative, tolerances);
        Require(direct.Max(metric => metric.Conclusion) == Conclusion.Difference, "Did not reproduce the legacy direct difference");
        var common = CommonProductDomain(actual, oldNative);
        var oldOnProductNodesToFirst = CompareAtDomain(oldNative, native[0].Numeric, common, tolerances);
        var oldOnProductNodesToFine = CompareAtDomain(oldNative, native[1].Numeric, common, tolerances);
        Require(oldOnProductNodesToFirst.Any(metric => metric.Conclusion == Conclusion.Difference)
            && oldOnProductNodesToFine.Any(metric => metric.Conclusion == Conclusion.Difference),
            "Legacy reference does not fail both independent tiers on the common product coordinates");
        var oldNodesToFirst = CompareAtDomain(oldNative, native[0].Numeric, oldNative, tolerances);
        var oldNodesToFine = CompareAtDomain(oldNative, native[1].Numeric, oldNative, tolerances);
        Require(oldNodesToFirst.Any(metric => metric.Conclusion == Conclusion.Difference)
            && oldNodesToFine.Any(metric => metric.Conclusion == Conclusion.Difference),
            "Legacy reference does not fail both tiers on its own published coordinates");
        var latestComparison = CompareAtDomain(actual, native[1].Numeric, actual, tolerances);
        var firstComparison = CompareAtDomain(actual, native[0].Numeric, actual, tolerances);
        var latestConvergence = CompareAtDomain(native[0].Numeric, native[1].Numeric, actual, tolerances);
        Require(latestConvergence.All(metric => metric.Conclusion == Conclusion.Pass && metric.Coverage == 1), "Native pair failed on the exact formal coordinates");
        var conclusion = latestComparison.Concat(firstComparison)
            .All(metric => metric.Conclusion == Conclusion.Pass && metric.Coverage == 1);
        if (conclusion) passed++; else failed++;
        object? fixedOutcome = null;
        if (fixedRoot is not null)
        {
            var fixedPath = Path.Combine(fixedRoot, id);
            var fixedData = Path.Combine(fixedPath, "data.json");
            var fixedJob = Path.Combine(fixedPath, "request.json");
            if (File.Exists(fixedData))
            {
                var data = JsonFiles.Read<AnalysisData>(fixedData);
                var fixedRequest = JsonFiles.Read<WorkbenchJob>(fixedJob).Request;
                var settings = new Dictionary<string, string>(fixedRequest.WorkbenchSettings);
                Require(settings.Remove("FourierSamplingMode", out var mode) && mode == "Fixed"
                    && (fixedRequest with { WorkbenchSettings = settings }).Fingerprint == request.Fingerprint,
                    "Explicit Fixed changed another setting");
                Require(data.Outcome == AnalysisOutcome.Unavailable && !data.Values.ContainsKey("FourierSamplingValidation")
                    && JsonElement.DeepEquals((JsonElement)data.Values["PupilPhaseSampling"], requestedPhase),
                    "Explicit Fixed did not retain the original phase rejection");
                fixedOutcome = new { outcome = data.Outcome, reason = data.OutcomeReason, dataSha256 = HashFile(fixedData),
                    requestSha256 = HashFile(fixedJob), requestFingerprint = fixedRequest.Fingerprint };
            }
        }
        results.Add(new
        {
            index, key, state = conclusion ? "Pass" : "Open", frozenVerdict = "Error", requestFingerprint = request.Fingerprint,
            requestSha256 = HashFile(jobPath), dataSha256 = HashFile(dataPath), provenance, fixedOutcome,
            phaseCertificate = certificate, requestedPhase,
            native = native.Select(t => t.Receipt), originalDomainCoverage = 1,
            nativeConvergence = latestConvergence, versusNativeLow = firstComparison, versusNativeHigh = latestComparison, endpoints,
            legacy = new
            {
                conclusion = Conclusion.Difference, metrics = direct, payloads = legacyPayloads, coordinateScale,
                commonProductNodes = common.Series.Select(curve => new
                {
                    curve.Id, included = curve.X.Length, original = actual.Series.Single(c => c.Id == curve.Id).X.Length,
                    minimum = curve.X[0], maximum = curve.X[^1], unit = curve.XAxis.Unit
                }),
                oldOnProductNodesToFirst, oldOnProductNodesToFine, oldNodesToFirst, oldNodesToFine
            }
        });
        Console.WriteLine($"{id} {key}: {(conclusion ? "Pass" : "Open")}, worst NRMSE {latestComparison.Max(metric => metric.Nrmse):R}");
    }
    catch (Exception error) when (error is InvalidDataException or IOException or ArgumentException or InvalidOperationException)
    {
        failed++;
        results.Add(new { index, key, state = "VerificationFailed", error = error.ToString() });
        Console.Error.WriteLine($"{id} {key}: {error.Message}");
    }
}
JsonFiles.Write(output, new { frozenArchiveSha256 = frozenHash, policySha256 = policyHash, rows = results, passed, pending, failed });
return failed > 0 || formal is not null && (pending > 0 || passed != scope.Count) ? 2 : 0;

static (NumericResult Numeric, object Receipt) ExtractTier(JsonElement tier, CanonicalAnalysisRequest request,
    JsonElement row, string repo, string proof, string scratch, AnalysisComparisonEntry entry, JsonElement legacyReadback)
{
    var n = Int(tier, "sampling");
    var archivePath = Path.Combine(proof, Text(tier, "archive"));
    using var archive = ZipFile.OpenRead(archivePath);
    var dataMember = Text(tier, "dataEntry");
    var settingsMember = Text(tier, "readbackEntry");
    var data = ReadMember(archive, dataMember);
    var settings = ReadMember(archive, settingsMember);
    Require(JsonFiles.Hash(data) == Text(tier, "dataSha256") && JsonFiles.Hash(settings) == Text(tier, "readbackSha256"), "Archived reference bytes changed");
    using var readback = JsonDocument.Parse(settings);
    var read = readback.RootElement;
    var nativeRequest = read.GetProperty("request");
    var selection = read.GetProperty("selectors");
    var lens = Text(row, "lens");
    Require(Int(nativeRequest, "pupilSampling") == n && Int(nativeRequest, "configuration") == request.Configuration
        && Int(selection, "Field") == request.Field && Int(selection, "Wavelength") == request.Wavelength,
        "Native physical selectors changed");
    var sourceHash = HashFile(Path.Combine(repo, "src/OpticalSystemDesign.App/Assets/SequentialExamples", lens));
    var capturedSourceHash = nativeRequest.TryGetProperty("inputSha256", out var sourceProperty) ? sourceProperty.GetString() : null;
    var sourceBinding = "SameSourceBytes";
    var index = Int(row, "index");
    if (index == 559)
    {
        // OpticStudio saved the same native PupilSizePosition mode explicitly.
        // The archived comparison documents the mode on the original lens.
        const string control = "controls/Example 1, A singlet eyepiece--PupilSizePosition.zmx";
        Require(capturedSourceHash == "1a876ccafd525d167ae5648a76048164bf03959a3f956492061fbdebe82c5f48"
            && JsonFiles.Hash(ReadMember(archive, control)) == capturedSourceHash, "Eyepiece mode control has changed");
        const string frozenSource = "8b9d3cb3c43ae2356462247afa6e3a5b84d4fc5626aa435d04bfa5f9c2db3bc9";
        using var controlReadback = JsonDocument.Parse(ReadMember(archive, "controls/readback.json"));
        var pupilMode = controlReadback.RootElement[1];
        Require(sourceHash == frozenSource && Text(pupilMode, "initial") == "PupilSizePosition"
            && Text(pupilMode, "method") == "PupilSizePosition"
            && Math.Abs(pupilMode.GetProperty("wfno").GetDouble() - 200) < .001
            && Text(pupilMode, "input").Replace('\\', '/').EndsWith("/" + lens, StringComparison.Ordinal)
            && Text(pupilMode, "file").EndsWith("Example 1, A singlet eyepiece--PupilSizePosition.zmx", StringComparison.Ordinal),
            "Eyepiece saved control did not prove the original native pupil mode");
        sourceBinding = "SameNativePupilSizePositionSavedControl";
    }
    else if (index is 1989 or 2679 && capturedSourceHash is null)
    {
        Require(Text(nativeRequest, "input").Replace('\\', '/').EndsWith("/full-v1/sources/" + lens, StringComparison.Ordinal),
            "Legacy native capture source path does not name the frozen prescription");
        var rawReport = ReadMember(archive, Path.ChangeExtension(dataMember, ".txt"));
        using var reader = new StreamReader(new MemoryStream(rawReport));
        var header = reader.ReadToEnd().Replace('\\', '/');
        Require(header.Contains("/sources/" + lens, StringComparison.Ordinal)
            && header.Contains("面: 像面", StringComparison.Ordinal)
            && header.Contains("空间频率:周期/mm.", StringComparison.Ordinal)
            && header.Contains("视场：0.00 (度)", StringComparison.Ordinal)
            && header.Contains(index == 1989 ? "0.5870 μm的数据。" : "0.5500 μm的数据。", StringComparison.Ordinal),
            "Legacy MTF text does not bind source, selectors and physical frequency units");
        sourceBinding = "LegacyFrozenSourcePathAndNativeMtfHeader";
    }
    else Require(capturedSourceHash == sourceHash, "Native reference source differs from the menu prescription");
    var properties = read.GetProperty("properties");
    var oldProperties = legacyReadback.GetProperty("properties");
    Require(JsonElement.DeepEquals(selection, legacyReadback.GetProperty("selectors"))
        && properties.EnumerateObject().Count() == oldProperties.EnumerateObject().Count()
        && properties.EnumerateObject().Where(property => property.Name != "SampleSize")
            .All(property => oldProperties.TryGetProperty(property.Name, out var prior) && JsonElement.DeepEquals(prior, property.Value)),
        "A native selector or setting other than pupil sampling changed");
    var sampleSize = Text(properties, "SampleSize");
    Require(sampleSize.EndsWith($"_{n}x{n}", StringComparison.Ordinal)
        && !properties.GetProperty("UsePolarization").GetBoolean(), "Native sampling or polarization changed");
    switch (request.CanonicalAnalysisKey)
    {
        case "PSF":
            Require(properties.GetProperty("ImageDelta").GetDouble() == request.ImageDeltaMicrometers
                && Text(properties, "OutputSize").EndsWith($"_{request.ImageSampling}x{request.ImageSampling}", StringComparison.Ordinal)
                && Text(properties, "Type") == "Linear" && !properties.GetProperty("Normalize").GetBoolean(), "Native PSF readout changed");
            break;
        case "MTF":
            Require(properties.GetProperty("MaximumFrequency").GetDouble() == request.MaximumFrequency
                && Text(properties, "Type") == "Modulation" && !properties.GetProperty("ShowDiffractionLimit").GetBoolean(), "Native MTF readout changed");
            break;
        default:
            Require(Text(properties, "Type") == "X_Linear" && Int(properties, "RowCol") == 0
                && properties.GetProperty("PlotScale").GetDouble() == 0 && !properties.GetProperty("Normalize").GetBoolean(), "Native X section readout changed");
            break;
    }
    var directory = Path.Combine(scratch, n.ToString());
    Directory.CreateDirectory(directory);
    var dataPath = Path.Combine(directory, "data.json");
    File.WriteAllBytes(dataPath, data);
    File.WriteAllBytes(Path.Combine(directory, "captured-settings.json"), settings);
    string? textSha = null;
    var textMember = Path.ChangeExtension(dataMember, ".txt");
    if (archive.GetEntry(textMember) is not null)
    {
        var report = ReadMember(archive, textMember);
        File.WriteAllBytes(Path.ChangeExtension(dataPath, ".txt"), report);
        textSha = JsonFiles.Hash(report);
        if (request.NativeLensUnit == "CM")
        {
            using var reader = new StreamReader(new MemoryStream(report));
            var header = reader.ReadToEnd();
            Require(header.Contains($"结构 {request.Configuration} 的 5", StringComparison.Ordinal)
                && header.Contains($"光瞳网格尺寸: {n} by {n}", StringComparison.Ordinal)
                && header.Contains("X 部分, 中心行", StringComparison.Ordinal),
                "Legacy centimeter-source profile text does not prove its configuration, sampling and axis");
        }
    }
    // Historical captures lack the model/scale sidecars for the IN/CM sources.
    // Read the native physical display coordinates already certified in the
    // prior pair receipt; this is not a new lens unit conversion.
    if (request.NativeLensUnit is not null)
        Require((request.NativeLensUnit, lens) is ("CM", "Zoom systems/Mirror zoom.zmx") or
            ("IN", "Objectives/Wide angle lens 200 degree field.zmx")
            && Text(nativeRequest, "nativeLensUnit") == request.NativeLensUnit, "Unexpected legacy native unit");
    var numeric = ResultNormalizer.Zemax(dataPath, entry, request with { PupilSampling = n, NativeLensUnit = null });
    return (numeric, new { sampling = n, archive = Text(tier, "archive"), archiveSha256 = HashFile(archivePath),
        dataMember, dataSha256 = JsonFiles.Hash(data), settingsMember, readbackSha256 = JsonFiles.Hash(settings), textSha256 = textSha, selectorsAndOtherPropertiesMatch = true,
        sourceSha256 = sourceHash, capturedSourceHash, sourceBinding, legacyNativeLensUnit = request.NativeLensUnit });
}

static void CheckCertificate(JsonElement certificate, JsonElement requestedPhase, CanonicalAnalysisRequest request, JsonElement row)
{
    Require(certificate.GetProperty("validated").GetBoolean() && Text(certificate, "mode") == "Adaptive"
        && Int(certificate, "requestedPupilSampling") == request.PupilSampling, "Default output lacks a certificate for the original density");
    Require(Text(requestedPhase, "status") == "UndersampledPhase" && Text(requestedPhase, "criterion") == "LocalUnwrappedPupilPhaseStep/v1"
        && requestedPhase.GetProperty("maximumStepWaves").GetDouble() > .5
        && Math.Abs(requestedPhase.GetProperty("maximumStepWaves").GetDouble() - row.GetProperty("originalPhaseMaximumWaves").GetDouble()) < 5e-6,
        "Original fixed phase warning was not retained");
    var steps = certificate.GetProperty("steps").EnumerateArray().ToArray();
    var lower = steps[^2];
    var upper = steps[^1];
    Require(Int(steps[0], "pupilSampling") == request.PupilSampling && !steps[0].GetProperty("phaseResolved").GetBoolean()
        && lower.GetProperty("phaseResolved").GetBoolean() && upper.GetProperty("phaseResolved").GetBoolean()
        && Int(lower, "pupilSampling") < Int(upper, "pupilSampling") && Int(upper, "pupilSampling") == Int(certificate, "returnedPupilSampling"),
        "The final two tiers do not establish separate resolved pupil densities");
    Require(certificate.GetProperty("relativeRmsAccuracy").GetDouble() == .001
        && (upper.GetProperty("relativeRmsChange").GetDouble() <= .001
            || upper.GetProperty("maximumAbsoluteChange").GetDouble() <= certificate.GetProperty("absoluteAccuracy").GetDouble()),
        "The reported tiers failed the original refinement target");
}

static void VerifyDomain(NumericResult actual, NumericResult domain, CanonicalAnalysisRequest request)
{
    Require(actual.Series.Count == domain.Series.Count && actual.Grids.Count == domain.Grids.Count, "Formal output domain shape changed");
    if (request.CanonicalAnalysisKey == "PSF")
    {
        var grid = actual.Grids.Single();
        var expected = domain.Grids.Single();
        Require(grid.X.Length == request.ImageSampling && grid.Y.Length == request.ImageSampling
            && SameAxis(grid.X, expected.X) && SameAxis(grid.Y, expected.Y), "Fixed PSF physical grid changed");
        return;
    }
    foreach (var axis in domain.Series)
    {
        var curve = actual.Series.Single(item => item.Id == axis.Id);
        Require(SameAxis(curve.X, axis.X), $"Original {curve.Id} physical knots changed");
    }
}

static bool SameAxis(double[] candidate, double[] expected) => candidate.Length == expected.Length
    && candidate.Zip(expected).All(pair => Math.Abs(pair.First - pair.Second) <= 1e-10 * Math.Max(1, Math.Abs(pair.Second)));

static ComparisonMetric[] DirectMetrics(NumericResult product, NumericResult legacy, IReadOnlyDictionary<string, Tolerances> tolerances)
{
    var curves = legacy.Series.Select(axis => ComparisonMetrics.Calculate(axis.Id, axis.YAxis.Unit,
        ComparisonMetrics.Align(product.Series.Single(c => c.Id == axis.Id), axis, []), tolerances[axis.YAxis.Quantity]));
    var grids = legacy.Grids.Select(grid => ComparisonMetrics.Calculate(grid.Id, grid.ValueAxis.Unit,
        ComparisonMetrics.Align(product.Grids.Single(g => g.Id == grid.Id), grid, []), tolerances[grid.ValueAxis.Quantity]));
    return curves.Concat(grids).ToArray();
}

static NumericResult CommonProductDomain(NumericResult product, NumericResult legacy)
{
    return product with
    {
        Series = product.Series.Select(curve =>
        {
            var old = PhysicalNormalization.Convert(legacy.Series.Single(item => item.Id == curve.Id), curve.XAxis, curve.YAxis, []);
            var lower = old.X.Min();
            var upper = old.X.Max();
            var indices = Enumerable.Range(0, curve.X.Length).Where(i => curve.X[i] >= lower && curve.X[i] <= upper).ToArray();
            Require(indices.Length > 1, "No common physical curve coordinates");
            return curve with { X = indices.Select(i => curve.X[i]).ToArray(), Y = indices.Select(i => curve.Y[i]).ToArray() };
        }).ToList()
    };
}

static ComparisonMetric[] CompareAtDomain(NumericResult left, NumericResult right, NumericResult domain,
    IReadOnlyDictionary<string, Tolerances> tolerances)
{
    var result = new List<ComparisonMetric>();
    foreach (var expected in domain.Grids)
    {
        var a = left.Grids.Single(grid => grid.Id == expected.Id);
        var b = right.Grids.Single(grid => grid.Id == expected.Id);
        var values = ComparisonMetrics.Align(a, b, []);
        Require(values.X.Length == expected.X.Length * expected.Y.Length && values.Coverage == 1, "PSF contains an incomplete mask");
        result.Add(ComparisonMetrics.Calculate(expected.Id, expected.ValueAxis.Unit, values, tolerances[expected.ValueAxis.Quantity]));
    }
    foreach (var expected in domain.Series)
    {
        var a = At(left, expected, expected.X);
        var b = At(right, expected, expected.X);
        result.Add(ComparisonMetrics.Calculate(expected.Id, expected.YAxis.Unit, new(expected.X, null, a, b, 1), tolerances[expected.YAxis.Quantity]));
    }
    Require(result.Count > 0, "Comparison contains no physical quantities");
    return result.ToArray();
}

static object[] EndpointAudit(NumericResult domain, NumericResult old, NumericResult fine,
    JsonElement[] baselineAxes, IReadOnlyDictionary<string, Tolerances> tolerances, string textHash)
{
    return domain.Series.Select(axis =>
    {
        var original = old.Series.Single(curve => curve.Id == axis.Id);
        var prior = baselineAxes.Single(row => Text(row, "id") == axis.Id);
        var covered = original.X.Count(value => value >= axis.X[0] && value <= axis.X[^1]);
        Require(covered == Int(prior, "coveredCount") && original.X.Length == Int(prior, "originalCount"), "Old native endpoint coverage differs from prior receipt");
        var endpointX = new[] { original.X[0], original.X[^1] };
        var available = At(fine, axis, endpointX);
        return (object)new { axis.Id, frozenNativeTextSha256 = textHash, originalCount = original.X.Length, coveredCount = covered,
            nativeMinimum = endpointX[0], nativeMaximum = endpointX[1], coreMinimum = axis.X[0], coreMaximum = axis.X[^1],
            leftOutsideCore = Math.Max(0, axis.X[0] - endpointX[0]), rightOutsideCore = Math.Max(0, endpointX[1] - axis.X[^1]),
            highTierAtOldEndpoints = available, oldNativeEndpointIrradiance = new[] { original.Y[0], original.Y[^1] },
            endpointUnit = axis.XAxis.Unit, comparisonGate = tolerances[axis.YAxis.Quantity] };
    }).ToArray();
}

static double[] At(NumericResult source, Series1DResult domain, double[] target)
{
    var curve = PhysicalNormalization.Convert(source.Series.Single(item => item.Id == domain.Id), domain.XAxis, domain.YAxis, []);
    var (x, y) = PhysicalNormalization.Sort(curve.X, curve.Y);
    return target.Select(t => PhysicalNormalization.Interpolate(x, y, t)).ToArray();
}

static string Text(JsonElement value, string name) => value.GetProperty(name).GetString()!;
static int Int(JsonElement value, string name) => value.GetProperty(name).GetInt32();
static void Require(bool condition, string reason) { if (!condition) throw new InvalidDataException(reason); }
static string HashFile(string path)
{
    using var stream = File.OpenRead(path);
    return Convert.ToHexStringLower(System.Security.Cryptography.SHA256.HashData(stream));
}
static byte[] ReadMember(ZipArchive archive, string member)
{
    using var input = (archive.GetEntry(member) ?? throw new FileNotFoundException(member)).Open();
    using var buffer = new MemoryStream();
    input.CopyTo(buffer);
    return buffer.ToArray();
}
