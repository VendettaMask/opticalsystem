import collections, csv, hashlib, json, pathlib
from zipfile import ZipFile, ZIP_DEFLATED
repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/fft-low-reference-20261108"
previous = repo / "validation/rechecks/2026-11-08/fft-default-phase-recovery"
report = repo / "validation/rechecks/2026-11-08/fft-low-reference-disposition"
report.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def sha(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

proof = read(root / "proof.json")
prior = {row["index"]: row for row in read(previous / "frozen-low-native-comparison.json") if row["conclusion"] == "Difference"}
prior_refined = {row["index"]: row for row in read(previous / "converged-native-comparison.json")["rows"]}
prior_summary = read(previous / "summary.json")
assert sha(previous / "frozen-low-native-comparison.json") == prior_summary["reportFileHashes"]["frozen-low-native-comparison.json"]
assert sha(previous / "converged-native-comparison.json") == prior_summary["reportFileHashes"]["converged-native-comparison.json"]
assert (proof["passed"], proof["failed"], proof["pending"]) == (16, 0, 0)
assert {r["index"] for r in proof["rows"]} == set(prior)
assert proof["policySha256"] == prior_summary["policySha256"]
ledger = []
archive = report / "formal-replay.zip"
with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=9) as pack:
    for row in proof["rows"]:
        index = row["index"]
        old = prior[index]
        legacy = row["legacy"]
        assert row["state"] == "Pass" and row["frozenVerdict"] == "Error"
        assert row["requestFingerprint"] == old["requestFingerprint"] == prior_refined[index]["requestFingerprint"]
        assert row["provenance"]["codeFingerprint"] == prior_summary["applicationSha256"] + ":" + prior_summary["coreSha256"]
        assert row["originalDomainCoverage"] == 1 and legacy["conclusion"] == "Difference"
        assert len(row["native"]) == 2 and all(t["selectorsAndOtherPropertiesMatch"] for t in row["native"])
        archived = {m["id"]: m for m in old["metrics"]}
        for m in legacy["metrics"]:
            old_metric = archived[m["id"]]
            assert m["conclusion"] == old_metric["conclusion"] and m["count"] == old_metric["count"]
            assert abs(m["nrmse"] - old_metric["nrmse"]) <= 1e-12
        for key in ("nativeConvergence", "versusNativeLow", "versusNativeHigh"):
            assert all(m["conclusion"] == "Pass" and m["coverage"] == 1 for m in row[key])
        for key in ("oldOnProductNodesToFirst", "oldOnProductNodesToFine", "oldNodesToFirst", "oldNodesToFine"):
            assert any(m["conclusion"] == "Difference" for m in legacy[key])
        key = f"{index:04d}"
        fresh = root / "formal" / key
        assert sha(fresh / "data.json") == row["dataSha256"]
        assert read(fresh / "execution.json")["exitCode"] == 0
        for name in ("request.json", "data.json", "provenance.json", "execution.json"):
            pack.write(fresh / name, f"formal/{key}/{name}")
        endpoints = next(iter(row.get("endpoints") or []), {})
        common = legacy["commonProductNodes"]
        ledger.append({
            "index": index, "analysis": row["key"], "originalFrozenVerdict": row["frozenVerdict"],
            "legacyLowDirectVerdict": legacy["conclusion"], "legacyToBothHigherTiers": "Difference",
            "highTierConvergence": "Pass", "currentAcceptance": row["state"],
            "legacyPupilSampling": row["phaseCertificate"]["requestedPupilSampling"],
            "nativeCoarseSampling": row["native"][0]["sampling"], "nativeFineSampling": row["native"][1]["sampling"],
            "workbenchSampling": row["phaseCertificate"]["returnedPupilSampling"],
            "legacyToFineOnPublishedNodesNrmse": max(m["nrmse"] for m in legacy["oldNodesToFine"]),
            "legacyToFineOnCommonProductNodesNrmse": max(m["nrmse"] for m in legacy["oldOnProductNodesToFine"]),
            "nativeTierConvergenceNrmse": max(m["nrmse"] for m in row["nativeConvergence"]),
            "workbenchToFineNrmse": max(m["nrmse"] for m in row["versusNativeHigh"]),
            "legacyNodesInsideCore": endpoints.get("coveredCount"),
            "coreNodesInsideLegacy": common[0]["included"] if endpoints else None,
            "acceptedDomainCoverage": row["originalDomainCoverage"],
            "freshOutputByteIdentical": row["dataSha256"] == prior_refined[index]["dataSha256"],
        })
    for name in ("Program.cs", "CompareFftReferenceDrift.csproj"):
        pack.write(root / "comparator" / name, "replay/comparator/" + name)
    pack.write(root / "Run-Formal.py", "replay/Run-Formal.py")
    pack.write(root / "seal.py", "replay/seal.py")

(report / "three-way-comparison.json").write_bytes((root / "proof.json").read_bytes())
with (report / "by-request.csv").open("w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=list(ledger[0]))
    writer.writeheader()
    writer.writerows(ledger)
old_common = [row["legacyToFineOnCommonProductNodesNrmse"] for row in ledger]
summary = {"scope": "16 legacy-low FFT differences", "replayed": len(ledger), "accepted": proof["passed"],
           "currentAcceptanceDifferences": 0, "legacyDirectDifferences": len(ledger), "legacyToEachHigherTierDifferences": len(ledger),
           "nativePairsConverged": len(ledger), "checkedNativeTierSettings": 2 * len(ledger),
           "analysisCounts": dict(collections.Counter(row["analysis"] for row in ledger)),
           "byteIdenticalWithPreviousDefault": sum(row["freshOutputByteIdentical"] for row in ledger),
           "worstWorkbenchToFineNrmse": max(row["workbenchToFineNrmse"] for row in ledger),
           "worstNativePairNrmse": max(row["nativeTierConvergenceNrmse"] for row in ledger),
           "legacyToFineCommonProductNodesNrmseRange": [min(old_common), max(old_common)],
           "oldProfileWithEndpointsOutsideCore": [row["index"] for row in ledger if row["legacyNodesInsideCore"] == 199],
           "coreProfileWithEndpointsOutsideOld": [row["index"] for row in ledger if row["coreNodesInsideLegacy"] == 199],
           "coreSha256": prior_summary["coreSha256"], "applicationSha256": prior_summary["applicationSha256"],
           "policySha256": proof["policySha256"], "frozenArchiveSha256": proof["frozenArchiveSha256"],
           "reportFileHashes": {name: sha(report / name) for name in
                                ("formal-replay.zip", "by-request.csv", "three-way-comparison.json")}}
write(report / "summary.json", summary)
print(json.dumps(summary, indent=2))

