"""Read a complete native PSF without allocating an oversampled full image."""
from dataclasses import dataclass
import json, re, sys
from pathlib import Path

import numpy as np
from scipy.fft import fft, fftshift, fftfreq
from scipy.signal import CZT
from scipy.integrate import cumulative_simpson
from scipy.ndimage import map_coordinates
from scipy.special import j0, j1

from ReadNativePsf import read

@dataclass
class Grid:
    values: np.ndarray
    dx: float
    dy: float
    min_x: float
    min_y: float
    name: str

    @classmethod
    def load(cls, path):
        m=read(path/'psf-grid.json')
        if (path/'grid.npy').is_file():
            v=np.load(path/'grid.npy',mmap_mode='r')
            orient=m['textReadout']
            v=v[::orient['ySign'],::orient['xSign']]
        else:
            v=np.memmap(path/'grid-f64le.bin',dtype='<f8',mode='r',shape=(m['ny'],m['nx']))
        header='\n'.join(m['header'])
        size=re.search(r'(?:像方网格尺寸|Image(?:\s+space)?\s+grid\s+size)\s*:\s*(\d+)\s*(?:by|x|×)\s*(\d+)',header,re.I)
        if size:
            expected=tuple(map(int,size.groups()))
        elif (path/'captured-settings.json').is_file():
            captured=read(path/'captured-settings.json')
            request=captured['request']
            n=2*request['pupilSampling']
            if captured['properties']['OutputSize']!=f'PsfS_{n}x{n}':
                raise ValueError('A complete native output size must be read back.')
            expected=(n,n)
        else:
            raise ValueError(f'{path.name} lacks a complete grid identity')
        if expected!=tuple(reversed(v.shape)):
            raise ValueError(f'{path.name} is a crop or has inconsistent full dimensions')
        return cls(v,m['dx'],m['dy'],m['minX'],m['minY'],path.name)

    def axis(self, i):
        return self.min_x+self.dx*np.arange(self.values.shape[1]) if i==1 else self.min_y+self.dy*np.arange(self.values.shape[0])

    def check(self, x, y):
        for axis,points,delta in [(1,x,self.dx),(0,y,self.dy)]:
            a=self.axis(axis)
            if points[0]<a[0]-delta/2-1e-9 or points[-1]>a[-1]+delta/2+1e-9:
                raise ValueError(f'{self.name} does not cover physical interval {points[0],points[-1]}')

    def profiles(self, x, y=0.):
        self.check(x,[y])
        iy=(y-self.min_y)/self.dy
        if abs(iy-round(iy))>1e-9:raise ValueError('Require exact native row')
        return bandlimited(self.values[round(iy),:],self.min_x,self.dx,x,0)

    def whole(self):
        x,y=self.axis(1),self.axis(0)
        sx=self.values.sum(axis=0)
        sy=self.values.sum(axis=1)
        mass=float(sx.sum())
        cx=centroid(sx,self.min_x,self.dx)
        cy=centroid(sy,self.min_y,self.dy)
        edge=float((sx[:4].sum()+sx[-4:].sum()+sy[:4].sum()+sy[-4:].sum())/mass)
        return dict(cx=cx,cy=cy,discreteX=float(x@sx/mass),discreteY=float(y@sy/mass),sum=mass,
                    total=mass*self.dx*self.dy,edge4FractionUpperBound=edge,window=[float(x[0]),float(x[-1]),float(y[0]),float(y[-1])])

    def window(self, x, y, rows_per_block=32):
        self.check(x,y)
        if len(x)*self.values.shape[0]+len(x)*len(y)>8_388_608:
            raise ValueError('Bounded readout would exceed the allocation budget')
        rows=np.empty((self.values.shape[0],len(x)))
        for start in range(0,len(rows),rows_per_block):
            stop=min(start+rows_per_block,len(rows))
            rows[start:stop]=bandlimited(self.values[start:stop],self.min_x,self.dx,x,1)
        return bandlimited(rows,self.min_y,self.dy,y,0)

def bandlimited(values, first, pitch, coordinate, axis):
    """Evaluate the complete Fourier series on a uniform physical axis."""
    n=values.shape[axis]
    coordinate=np.asarray(coordinate)
    t=(coordinate-first)/(n*pitch)
    dt=t[1]-t[0] if len(t)>1 else 0.
    if not np.allclose(t,t[0]+dt*np.arange(len(t)),rtol=1e-9,atol=1e-12):
        raise ValueError('Uniform evaluation axis required')
    z=np.exp(2j*np.pi*dt)
    a=np.exp(-2j*np.pi*t[0])
    spectrum=fftshift(fft(values,axis=axis),axes=axis)/n
    output=CZT(n,m=len(t),w=z,a=a)(spectrum,axis=axis)
    shape=[1]*values.ndim
    shape[axis]=len(t)
    return np.real(output*np.exp(-2j*np.pi*(n//2)*t).reshape(shape))

def centroid(marginal, first, delta):
    """Continuous first moment on the complete cell-centered FFT period."""
    n=len(marginal)
    harmonics=fftfreq(n)*n
    k=harmonics[1:]
    a=fft(marginal)[1:]/marginal.sum()
    correction=np.real(np.sum(a*np.exp(-1j*np.pi*k/n)/(2j*np.pi*k/n)))
    return float(first+delta*((n-1)/2+correction))

def energy(grid, metrics, radius, oversampling, angles, radial_intervals):
    # A small Fourier window around the independently calculated centroid.
    # Normalize by the entire native FFT period, including all out-of-window flux.
    delta=min(grid.dx,grid.dy)/oversampling
    count=int(np.ceil(radius/delta))+4
    q=np.arange(-count,count+1)*delta
    x=metrics['cx']+q
    y=metrics['cy']+q
    window=grid.window(x,y)
    t=np.arange(angles)*2*np.pi/angles
    r=np.linspace(0,radius,radial_intervals+1)
    xx=count+np.cos(t)[:,None]*r/delta
    yy=count+np.sin(t)[:,None]*r/delta
    v=map_coordinates(window,(yy,xx),order=3,mode='nearest')
    radial=2*np.pi*r*v.mean(axis=0)
    enclosed=cumulative_simpson(radial,x=r,initial=0)/metrics['total']
    if np.any(np.diff(enclosed)<-1e-9) or enclosed.min()<-1e-9 or enclosed.max()>1+1e-9:
        raise ValueError('Nonphysical cumulative energy')
    return r,enclosed

def profile_file(path):
    output=[]
    for line in path.read_text(encoding='utf-16').splitlines():
        m=re.fullmatch(r'\s*\d+\s+([+\-\d.]+)\s+([+\-\d.Ee]+)\s*',line)
        if m:output.append(tuple(map(float,m.groups())))
    if not output:raise ValueError(f'Native profile is absent {path}')
    return np.array(output)

def curve_metrics(a,b,absolute,relative,nrmse_limit,close_limit):
    a=np.asarray(a)
    b=np.asarray(b)
    if a.ndim!=1 or a.shape!=b.shape or not a.size or not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('Comparison requires matching finite vectors')
    errors=abs(a-b)
    rms=float(np.sqrt(np.mean(errors*errors))/max(absolute,np.max(abs(b))))
    pointwise=bool(np.all(errors<=absolute+relative*abs(b)))
    return dict(count=len(a),coverage=1,maxAbsolute=float(errors.max()),nrmse=rms,pointwise=pointwise,
                verdict='Pass' if pointwise or rms<=nrmse_limit else ('Close' if rms<=close_limit else 'Difference'))

def interpolate_axis_samples(x):
    fine=np.linspace(x[0],x[-1],len(x))
    if np.max(abs(fine-x))>8e-6:raise ValueError('Native coordinate precision does not support a uniform axis')
    return fine

def main(root,repo):
    out=root/'readout';out.mkdir(exist_ok=True)
    captured=root/'native-full'
    base=repo/'artifacts/validation'
    full={p.name:Grid.load(p) for p in captured.iterdir() if (p/'psf-grid.json').exists()}
    historical={p.name:Grid.load(p) for p in (root/'historical').iterdir() if (p/'psf-grid.json').exists()}
    controls={q.name:Grid.load(q) for q in (root/'controls').iterdir() if (q/'psf-grid.json').exists()}
    refinement={q.name:Grid.load(q) for q in (root/'refinement').iterdir() if (q/'psf-grid.json').exists()}
    fine={q.name:Grid.load(q) for q in (root/'refinement-fine').iterdir() if (q/'psf-grid.json').exists()}
    grids=full|historical|controls|refinement|fine
    profile_gate=(1e-5,.002,.003,.01)
    energy_gate=(1e-5,.002,.003,.01)
    profiles={}
    encircled={}
    records={}
    profile_pairs={}
    energy_pairs={}
    native_profile=profile_file(root/'native/control-native-profile/data.txt')
    x_ctl=interpolate_axis_samples(native_profile[:,0])
    x_grid=np.linspace(-317.37639,317.37639,32769)
    for g in grids.values():
        is_control=g.name.startswith(('control','defocus'))
        metrics=g.whole()
        x=x_ctl if is_control else x_grid
        try:
            p=g.profiles(x)
            profiles[g.name]=p
        except ValueError as e:
            metrics['profileCoverage']=str(e)
        if g.name=='control-default-256':
            # The direct control used the same native default pupil and output interpolation.
            profile_pairs['matched-control']=curve_metrics(profiles[g.name],native_profile[:,1],*profile_gate)
        coarse_pitch,fine_pitch=(8,16) if is_control else (4,8)
        rc,coarse=energy(g,metrics,5,coarse_pitch,256,1000)
        r,e=energy(g,metrics,5,fine_pitch,512,2000)
        metrics['energyQuadrature']=curve_metrics(coarse,np.interp(rc,r,e),*energy_gate)
        metrics['energyAt5']=float(e[-1])
        encircled[g.name]=e
        records[g.name]=metrics
        print(g.name,metrics,flush=True)
    pair_names=[('control-full-256','control-full-512'),('grid-full-512','grid-full-512-step0.0025'),
        ('grid-full-512','grid-full-512-step0.001'),('grid-full-512-step0.0025','grid-full-512-step0.001'),
        ('grid-full-512-step0.001','grid-495-2048-step.005'),
        ('grid-495-1024-step.001','grid-full-512-step0.001'),
        ('grid-full-512','grid-495-2048-step.005'),('grid-full-512-step0.0025','grid-495-2048-step.005'),
        ('grid-full-512','grid-full-1024'),('grid-495-1024-step.005','grid-495-1024-step.001'),
        ('grid-495-1024-step.005','grid-495-2048-step.005'),('grid-full-1024','grid-495-2048-step.005')]
    for a,b in pair_names:
        if a in encircled and b in encircled:energy_pairs[a+'~'+b]=curve_metrics(encircled[a],encircled[b],*energy_gate)
        if a in profiles and b in profiles:profile_pairs[a+'~'+b]=curve_metrics(profiles[a],profiles[b],*profile_gate)
    direct=profile_file(base/'incomparable-grid-pending-native-refinement-20261101/job-profile-8192-step.001/profile-8192-step.001/data.txt')
    x_direct=interpolate_axis_samples(direct[:,0])
    for name in ('grid-full-1024','grid-495-2048-step.005'):
        if name in grids:
            g=grids[name]
            try:p=g.profiles(x_direct)
            except ValueError:continue
            profile_pairs[name+'~native-cross-8192']=curve_metrics(p,direct[:,1],*profile_gate)
    for s in ('512','1024','2048'):
        path=(root/'native/control-native-energy' if s=='512' else captured/('control-native-energy-'+s))/'data.json'
        if not path.is_file():continue
        d=read(path)
        if len(d['dataSeries'])!=2:continue
        actual=d['dataSeries'][1]
        rr=np.array(actual['x'])
        ref=np.array(actual['y']).reshape(-1)
        for name in ('control-full-256','control-full-512'):
            if name in encircled:
                energy_pairs[name+'~native-energy-'+s]=curve_metrics(np.interp(rr,r,encircled[name]),ref,*energy_gate)
    for level in (1024,2048):
        file=root/'controls'/f'defocus-energy-{level}'/'data.json'
        if file.is_file():
            direct=read(file)['dataSeries']
            if len(direct)==2:
                y=np.array(direct[1]['y']).reshape(-1)
                for name in ('defocus-full-256','defocus-full-512'):
                    if name in encircled:
                        energy_pairs[name+f'~native-defocus-{level}']=curve_metrics(np.interp(direct[1]['x'],r,encircled[name]),y,*energy_gate)
    profile_names=list(profiles)
    np.savez_compressed(out/'curves.npz',radius=r,profile_axis_control=x_ctl,profile_axis_grid=x_grid,
        **{'profile-'+n:profiles[n] for n in profile_names},**{'energy-'+n:e for n,e in encircled.items()})
    result=dict(grids=records,profileComparisons=profile_pairs,energyComparisons=energy_pairs)
    (out/'comparisons.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(profileComparisons=profile_pairs,energyComparisons=energy_pairs),indent=2))

if __name__=='__main__':
    main(*map(Path,sys.argv[1:]))




