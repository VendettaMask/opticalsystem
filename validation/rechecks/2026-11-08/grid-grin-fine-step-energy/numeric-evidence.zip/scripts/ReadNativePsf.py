from pathlib import Path
import hashlib, json, re, sys
import numpy as np

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def sha(p):
    with open(p,'rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def convert(source, out):
    source=Path(source); out=Path(out)
    out.mkdir(parents=True,exist_ok=True)
    output=out/'grid.npy'
    with open(source, encoding='utf-16') as stream:
        header=[next(stream).strip() for _ in range(18)]
        match=re.search(r'像方网格尺寸:\s*(\d+)\s+by\s+(\d+)','\n'.join(header))
        nx,ny=map(int,match.groups())
        if not (nx==ny and 32<=nx<=4096):raise ValueError((nx,ny))
        match=re.search(r'中心点是:\s*行\s+(\d+)\s*,\s*列\s+(\d+)','\n'.join(header))
        cy,cx=(int(x)-1 for x in match.groups())
        delta=float(re.search(r'数据间隔是\s*([\d.]+)\s*µm','\n'.join(header)).group(1))
        crop=read(source.with_name('data.json'))['dataGrids'][0]
        if not np.isclose(delta,crop['dx'],rtol=0,atol=.0005):raise ValueError('Native header and API delta differ')
        pitch=float(crop['dx'])
        arr=np.lib.format.open_memmap(output,mode='w+',dtype='<f8',shape=(ny,nx))
        for row in range(ny):
            values=np.fromstring(next(stream),sep=' ')
            if values.size!=nx or not np.isfinite(values).all() or values.min()<0:raise ValueError(f'Native PSF invalid row {row}')
            arr[row,:]=values
        if any(line.strip() for line in stream):raise ValueError('Unexpected trailing native PSF content')
    # The displayed text matrix is top-to-bottom. Verify its explicit center
    # and orientation against the same capture's double precision API crop.
    target=np.asarray(crop['values'])
    x0=round(cx+crop['minX']/pitch)
    y0=round(cy-crop['minY']/pitch)
    matches=[]
    for dy in (-1,0,1):
        for dx in (-1,0,1):
            for ysign in (-1,1):
                for xsign in (-1,1):
                    ystart=round((cy + (crop['minY']/pitch)*ysign))+dy
                    xstart=round((cx + (crop['minX']/pitch)*xsign))+dx
                    yy=ystart+ysign*np.arange(target.shape[0])
                    xx=xstart+xsign*np.arange(target.shape[1])
                    data=arr[np.ix_(yy,xx)]
                    err=np.max(abs(data-target))
                    if np.allclose(data,target,atol=1e-12,rtol=5.01e-5):
                        matches.append(dict(dx=dx,dy=dy,xSign=xsign,ySign=ysign,maxAbsolute=float(err)))
    if len(matches)!=1: raise ValueError(f'Expected unique native text coordinate alignment: {matches}')
    m=matches[0]
    # Retain unflipped storage and describe the ascending physical view.
    cx += m['dx']; cy += m['dy']
    if m['xSign']<0: cx=nx-1-cx
    if m['ySign']<0: cy=ny-1-cy
    outmeta=dict(nx=nx,ny=ny,dx=pitch,dy=pitch,minX=-cx*pitch,minY=-cy*pitch,source=str(source),
                 sourceSha256=sha(source),arraySha256=sha(output),apiCropMaxAbsolute=m['maxAbsolute'],
                 textReadout=m,header=header,storage='npy; apply textReadout signs before interpreting min axes')
    (out/'psf-grid.json').write_text(json.dumps(outmeta,indent=2)+'\n')
    print(source.name,nx,ny,outmeta['minX'],outmeta['minY'],m,flush=True)

if __name__=='__main__':
    repo,study=map(Path,sys.argv[1:])
    baseline=repo/'artifacts/validation/incomparable-grid-native-current-runner-20261101'
    for name in ('grid-495-1024-step.005','grid-495-1024-step.001','grid-495-2048-step.005'):
        convert(baseline/('job-'+name)/name/'data.txt',study/'historical'/name)
