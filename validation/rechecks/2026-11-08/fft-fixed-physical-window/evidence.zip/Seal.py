import collections
import hashlib
import json
import pathlib
import shutil
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

root = pathlib.Path("artifacts/validation/fft-fixed-window-repair-20261108")
report = pathlib.Path("validation/rechecks/2026-11-08/fft-fixed-physical-window")
test = root / "fixed-window-focused-final.trx"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

counters = ET.parse(test).getroot().find(".//{*}Counters").attrib
assert int(counters["passed"]) > 2 and counters["failed"] == "0"
assert digest(root / "bin-final/OpticalSystemDesign.Core.dll") == digest(
    pathlib.Path("tests/OpticalSystemDesign.Tests/bin/Release/net10.0/OpticalSystemDesign.Core.dll"))
verification = read(root / "verification.json")
adjacent = read(root / "adjacent-replay.json")
assert collections.Counter(row["outcome"] for row in adjacent) == {"Identical": 62, "Repaired": 2}
assert {row["index"] for row in adjacent if row["outcome"] == "Repaired"} == {555, 2499}
assert len(verification["results"]) == 2 and all(r["metrics"]["conclusion"] == "Pass" for r in verification["results"])
verification["focusedTests"] = {"passed": int(counters["passed"]), "failed": int(counters["failed"]), "trxSha256": digest(test)}
verification["adjacentReplay"] = {"fixedPsfRequests": 64, "repaired": 2, "byteIdentical": 62,
                                  "receiptSha256": digest(root / "adjacent-replay.json")}
phase_dir = root / "singlet-32-phase-control"
phase = read(phase_dir / "data.json")
assert phase["outcome"] == "Unavailable"
assert phase["values"]["PupilPhaseSampling"]["status"] == "UndersampledPhase"
assert phase["values"]["PupilPhaseSampling"]["maximumStepWaves"] > .5
verification["undersamplingControl"] = {"index": 555, "pupilSampling": 32, "outcome": phase["outcome"],
                                         "phase": phase["values"]["PupilPhaseSampling"]}
receipt = report / "verification.json"
receipt.write_text(json.dumps(verification, indent=2) + "\n", encoding="utf-8")

members = {name: root / name for name in (
    "Run.py", "Verify.py", "Replay-Adjacent.py", "Seal.py", "555-independent-reference.npy", "2499-independent-reference.npy",
    "singlet-reference/reference-results.json", "gregorian-reference.json", "adjacent-replay.json", "fixed-window-focused-final.trx")}
members["verification.json"] = receipt
for case in (555, 2499):
    for stage in ("before", "after"):
        folder = root / stage / str(case)
        for name in ("request.json", "execution.json", "data.json", "provenance.json"):
            path = folder / name
            if path.exists():
                members[path.relative_to(root).as_posix()] = path
for name in ("request.json", "data.json", "provenance.json"):
    path = phase_dir / name
    members[path.relative_to(root).as_posix()] = path
files = {name: digest(path) for name, path in sorted(members.items())}
archive_path = report / "evidence.zip"
with ZipFile(archive_path, "w", compression=ZIP_DEFLATED) as archive:
    for member, path in sorted(members.items()):
        archive.write(path, member)
    archive.writestr("manifest.json", json.dumps(files, indent=2) + "\n")
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name, sha in files.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == sha
print(verification["focusedTests"], len(files) + 1, digest(archive_path))

