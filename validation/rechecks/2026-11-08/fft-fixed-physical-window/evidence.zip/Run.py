import concurrent.futures
import hashlib
import json
import pathlib
import subprocess

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/fft-fixed-window-repair-20261108"
prior = repo / "artifacts/validation/menu-427-incomparable-20261108"

def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def run(plan):
    case, stage, worker_dir = plan
    target = root / stage / str(case)
    target.mkdir(parents=True, exist_ok=True)
    original = prior / "formal-fixed" / f"{case:04d}" / "request.json"
    request_path = target / "request.json"
    request = read(original)
    request["outputDirectory"] = str(target)
    assert request["request"]["workbenchSettings"]["FourierSamplingMode"] == "Fixed"
    assert request["request"]["workbenchSettings"]["Sampling"] == "64"
    write(request_path, request)
    worker = worker_dir / "OpticalSystemDesign.ZemaxComparison.dll"
    result = subprocess.run(["dotnet", str(worker), "--workbench-worker", str(request_path)],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60, check=False)
    log = result.stdout.decode("utf-8", errors="replace")
    write(target / "execution.json", {"index": case, "stage": stage, "exitCode": result.returncode,
        "originalRequestSha256": sha(original), "requestSha256": sha(request_path),
        "snapshotSha256": sha(pathlib.Path(request["snapshotPath"])), "workerSha256": sha(worker),
        "coreSha256": sha(worker_dir / "OpticalSystemDesign.Core.dll"),
        "appSha256": sha(worker_dir / "OpticalSystemDesign.Application.dll"), "output": log})
    if stage == "before":
        assert result.returncode == 3 and "insufficient pupil samples for two-dimensional diffraction" in log
    else:
        assert result.returncode == 0, log
        raw = read(target / "data.json")
        assert raw["outcome"] == "Success", raw.get("outcomeReason")
        assert raw["values"]["PhysicalFourierWindow"] and raw["values"]["PupilSampling"] == 64
        assert "FourierSamplingValidation" not in raw["values"]
    print(case, stage, result.returncode, flush=True)

with concurrent.futures.ThreadPoolExecutor(2) as executor:
    list(executor.map(run, [(case, stage, directory) for case in (555, 2499)
                          for stage, directory in [("before", prior / "bin-current"), ("after", root / "bin-final")]]))

