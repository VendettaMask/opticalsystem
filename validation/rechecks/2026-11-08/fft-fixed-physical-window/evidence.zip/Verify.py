import hashlib
import json
import pathlib
import runpy
import sys
from zipfile import ZipFile

import numpy as np

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/fft-fixed-window-repair-20261108"
prior = repo / "validation/rechecks/2026-11-08"
frozen_archive = repo / "validation/repairs/2026-10-21/sequential-corpus-full-evidence.zip"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

with frozen_archive.open("rb") as handle:
    archive_hash = hashlib.file_digest(handle, "sha256").hexdigest()
assert archive_hash == "1dc562461d4e39ac9bf54f3c2309a0bb81fdeccfb092554cd8e9c14aa80760ad"

with ZipFile(frozen_archive) as archive:
    manifest = {entry["path"]: entry["sha256"] for entry in json.loads(archive.read("payload-manifest.json"))}
    policy = archive.read("run/comparison-settings.json")
    tolerance = json.loads(policy)["analyses"]["PSF"]["quantities"]["Irradiance"]
    native_dir = repo / "artifacts/zemax-sequential-corpus/20261021/full-v1"
    for request, files in {
        "0554": ("data.json", "captured-settings.json"),
        "0555": ("captured-settings.json",),
        "0550": ("model.json",),
    }.items():
        folder = next((native_dir / "analyses").glob(f"{request}-*")) / "native"
        for file in files:
            source = folder / file
            member = "run/" + source.relative_to(native_dir).as_posix()
            assert sha(source.read_bytes()) == sha(archive.read(member)) == manifest[member]

singlet_dir = root / "singlet-reference"
singlet_dir.mkdir(exist_ok=True)
singlet_script = prior / "singlet-physical-fft/reference.py"
sys.argv = [str(singlet_script), str(singlet_dir)]
singlet = runpy.run_path(str(singlet_script), run_name="__main__")
assert all(singlet["results"][name]["verdict"] == "Pass"
           for name in ("pupilReferenceConvergence", "quadratureConvergence"))
gregorian_script = prior / "gregorian-fft-psf-reference/GregorianReference.py"
sys.argv = [str(gregorian_script), str(repo), str(root / "gregorian-reference.json")]
gregorian = runpy.run_path(str(gregorian_script), run_name="__main__")
assert gregorian["report"]["independentQuadratureConvergence"]["conclusion"] == "Pass"

def compare(candidate, reference):
    err = np.abs(candidate - reference)
    assert np.all(np.isfinite(err))
    nrmse = float(np.sqrt(np.mean(err ** 2)) / max(np.max(np.abs(reference)), tolerance["absolute"]))
    pointwise = bool(np.all(err <= tolerance["absolute"] + tolerance["relative"] * np.abs(reference)))
    return {"count": int(err.size), "coverage": 1, "maximumAbsolute": float(err.max()),
            "nrmse": nrmse, "pointwise": pointwise,
            "conclusion": "Pass" if pointwise or nrmse <= tolerance["nrmse"] else "OutsidePassGate"}

results = []
for index, reference, script, proof in (
    (555, singlet["fine"], singlet_script, singlet_dir / "reference-results.json"),
    (2499, gregorian["fine"], gregorian_script, root / "gregorian-reference.json"),
):
    before = root / "before" / str(index)
    after = root / "after" / str(index)
    old = read(before / "execution.json")
    new = read(after / "execution.json")
    original = read(before / "request.json")
    replay = read(after / "request.json")
    original.pop("outputDirectory")
    replay.pop("outputDirectory")
    assert original == replay and old["snapshotSha256"] == new["snapshotSha256"]
    assert old["exitCode"] == 3 and new["exitCode"] == 0 and old["coreSha256"] != new["coreSha256"]
    with ZipFile(frozen_archive) as archive:
        member = next(path for path in manifest if path.startswith(f"run/analyses/{index:04d}-")
                      and path.endswith("/workbench/request.json"))
        stored_bytes = archive.read(member)
        assert sha(stored_bytes) == manifest[member]
    actual_request = replay["request"]
    historical_request = json.loads(stored_bytes)["request"]
    settings = {key: value for key, value in actual_request["workbenchSettings"].items() if key != "FourierSamplingMode"}
    assert {**actual_request, "workbenchSettings": settings} == historical_request
    assert actual_request["workbenchSettings"]["FourierSamplingMode"] == "Fixed"
    assert actual_request["pupilSampling"] == 64
    payload = read(after / "data.json")
    provenance = read(after / "provenance.json")
    values = payload["values"]
    assert provenance["snapshotSha256"] == new["snapshotSha256"]
    assert provenance["codeFingerprint"] == f'{new["appSha256"]}:{new["coreSha256"]}'
    assert payload["outcome"] == "Success" and values["PupilSampling"] == 64
    assert values["PhysicalFourierWindow"] and values["PupilGridStretch"] == [1]
    assert values["UseRayAiming"] == [actual_request["useRayAiming"]]
    assert values["ImageDeltaMicrometers"] == .25 and values["DisplaySize"] == 128
    assert "FourierSamplingValidation" not in values
    series, = payload["seriesList"]
    assert series["xUnit"] == series["yUnit"] == "Micrometer"
    assert series["valueQuantity"] == "Irradiance" and series["valueUnit"] == "Dimensionless"
    points = np.array([[point[k] for k in ("x", "y", "value")] for point in series["points"]]).reshape(128, 128, 3)
    axis = np.arange(-63, 65) * .25
    x, y = np.meshgrid(axis, axis)
    assert np.array_equal(points[:, :, 0], x) and np.array_equal(points[:, :, 1], y)
    metrics = compare(points[:, :, 2], reference)
    assert metrics["conclusion"] == "Pass", (index, metrics)
    np.save(root / f"{index}-independent-reference.npy", reference, allow_pickle=False)
    results.append({"index": index, "frozenVerdict": "Incomparable", "frozenRequestSha256": sha(stored_bytes),
                    "originalFixedWorkerExit": old["exitCode"], "currentFixedWorkerExit": new["exitCode"],
                    "pupilSampling": values["PupilSampling"], "physicalWindow": [128, 128], "pitchMicrometers": .25,
                    "axisMicrometers": [-15.75, 16.0], "provenance": provenance,
                    "workbenchDataSha256": sha((after / "data.json").read_bytes()),
                    "referenceScript": script.relative_to(repo).as_posix(), "referenceScriptSha256": sha(script.read_bytes()),
                    "referenceProofSha256": sha(proof.read_bytes()), "metrics": metrics})
    print(index, metrics, flush=True)
dump(root / "verification.json", {"frozenArchiveSha256": archive_hash, "policySha256": sha(policy),
          "policy": {**tolerance, "minimumCoverage": .95}, "results": results})
