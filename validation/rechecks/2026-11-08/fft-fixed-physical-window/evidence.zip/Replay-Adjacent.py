import concurrent.futures
import hashlib
import json
import pathlib
import subprocess

repo = pathlib.Path.cwd()
prior = repo / "artifacts/validation/menu-427-incomparable-20261108"
root = repo / "artifacts/validation/fft-fixed-window-repair-20261108"
worker = root / "bin-final/OpticalSystemDesign.ZemaxComparison.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

rows = [row for row in read(prior / "cohort.json") if row["key"] == "PSF" and row["job"]]

def replay(row):
    index = row["index"]
    reference = prior / "formal-fixed" / f"{index:04d}"
    original_request = read(reference / "request.json")
    previous = read(reference / "execution.json")
    if index in (555, 2499):
        target = root / "after" / str(index)
        execution = read(target / "execution.json")
        assert execution["exitCode"] == 0 and previous["exitCode"] == 3
        current_request = read(target / "request.json")
        assert current_request["request"] == original_request["request"]
        return {"index": index, "beforeExit": previous["exitCode"], "afterExit": execution["exitCode"],
                "currentDataSha256": sha(target / "data.json"), "outcome": "Repaired"}
    target = root / "adjacent" / f"{index:04d}"
    target.mkdir(parents=True, exist_ok=True)
    original_request["outputDirectory"] = str(target)
    request = target / "request.json"
    request.write_text(json.dumps(original_request, ensure_ascii=False, indent=2), encoding="utf-8")
    result = subprocess.run(["dotnet", str(worker), "--workbench-worker", str(request)], timeout=180,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    assert result.returncode == previous["exitCode"] == 0, (index, result.stdout.decode("utf-8", errors="replace"))
    before = sha(reference / "data.json")
    after = sha(target / "data.json")
    assert before == after, (index, before, after)
    return {"index": index, "beforeExit": previous["exitCode"], "afterExit": result.returncode,
            "priorDataSha256": before, "currentDataSha256": after, "outcome": "Identical"}

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    checks = list(executor.map(replay, rows))
print(len(checks), "fixed PSF cases;", sum(r["outcome"] == "Identical" for r in checks), "byte-identical")
(root / "adjacent-replay.json").write_text(json.dumps(checks, indent=2) + "\n", encoding="utf-8")

