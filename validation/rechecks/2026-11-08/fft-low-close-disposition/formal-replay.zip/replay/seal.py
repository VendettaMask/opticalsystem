import collections, csv, hashlib, json, pathlib
from zipfile import ZIP_DEFLATED, ZipFile

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/fft-low-close-20261108"
reports = repo / "validation/rechecks/2026-11-08"
previous = reports / "fft-default-phase-recovery"
differences = reports / "fft-low-reference-disposition"
report = reports / "fft-low-close-disposition"
report.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

def verified(folder, summary, name):
    path = folder / name
    assert digest(path) == summary["reportFileHashes"][name]
    return read(path)

proof = read(root / "proof.json")
base = read(previous / "summary.json")
earlier = read(differences / "summary.json")
prior = {r["index"]: r for r in verified(previous, base, "frozen-low-native-comparison.json")}
refined = {r["index"]: r for r in verified(previous, base, "converged-native-comparison.json")["rows"]}
diff_rows = {r["index"]: r for r in verified(differences, earlier, "three-way-comparison.json")["rows"]}
scope = {i for i, row in prior.items() if row["conclusion"] == "Close"}
assert scope == {789, 835, 2853} == {row["index"] for row in proof["rows"]}
assert (proof["passed"], proof["failed"], proof["pending"]) == (3, 0, 0)
assert proof["policySha256"] == base["policySha256"] == earlier["policySha256"]
assert proof["frozenArchiveSha256"] == earlier["frozenArchiveSha256"]
legacy_tally = collections.Counter(row["conclusion"] for row in prior.values())
assert legacy_tally == {"Pass": 1, "Close": 3, "Difference": 16}
assert len(diff_rows) == earlier["accepted"] == 16 and all(row["state"] == "Pass" for row in diff_rows.values())
pass_ids = {i for i, row in prior.items() if row["conclusion"] == "Pass"}
assert pass_ids == {831}
assert set(prior) == set(refined) == scope | set(diff_rows) | pass_ids and len(prior) == 20
assert all(row["state"] == "Pass" for row in refined.values())

archive = report / "formal-replay.zip"
ledger = []
with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=9) as bundle:
    for row in proof["rows"]:
        index = row["index"]
        assert row["state"] == "Pass" and row["originalDomainCoverage"] == 1
        assert row["frozenVerdict"] == "Error"
        assert row["requestFingerprint"] == prior[index]["requestFingerprint"] == refined[index]["requestFingerprint"]
        assert row["provenance"]["codeFingerprint"] == base["applicationSha256"] + ":" + base["coreSha256"]
        assert len(row["native"]) == 2 and all(t["selectorsAndOtherPropertiesMatch"] for t in row["native"])
        legacy = row["legacy"]
        assert legacy["conclusion"] == "Close"
        old_metrics = {m["id"]: m for m in prior[index]["metrics"]}
        for metric in legacy["metrics"]:
            old = old_metrics[metric["id"]]
            assert metric["conclusion"] == old["conclusion"] and metric["count"] == old["count"]
            assert abs(metric["nrmse"] - old["nrmse"]) <= 1e-12
        for channel in ("nativeConvergence", "versusNativeLow", "versusNativeHigh"):
            assert all(m["conclusion"] == "Pass" and m["coverage"] == 1 for m in row[channel])
        for channel in ("oldOnProductNodesToFirst", "oldOnProductNodesToFine", "oldNodesToFirst", "oldNodesToFine"):
            assert all(m["conclusion"] == "Close" for m in legacy[channel])
        name = f"{index:04d}"
        run = root / "formal" / name
        assert digest(run / "data.json") == row["dataSha256"]
        assert read(run / "execution.json")["exitCode"] == 0
        for filename in ("request.json", "data.json", "provenance.json", "execution.json"):
            bundle.write(run / filename, f"formal/{name}/{filename}")
        endpoint = next(iter(row.get("endpoints") or []), {})
        ledger.append({
            "index": index, "analysis": row["key"], "historicalFixedVerdict": row["frozenVerdict"],
            "legacyLowDirectVerdict": "Close", "legacyToBothRefinedVerdict": "Close",
            "nativePairConvergence": "Pass", "currentAcceptance": row["state"],
            "legacyPupilSampling": row["phaseCertificate"]["requestedPupilSampling"],
            "coarseNativeSampling": row["native"][0]["sampling"], "fineNativeSampling": row["native"][1]["sampling"],
            "workbenchSampling": row["phaseCertificate"]["returnedPupilSampling"],
            "legacyDirectWorstNrmse": max(m["nrmse"] for m in legacy["metrics"]),
            "legacyToFineOnCommonProductNodesWorstNrmse": max(m["nrmse"] for m in legacy["oldOnProductNodesToFine"]),
            "nativePairWorstNrmse": max(m["nrmse"] for m in row["nativeConvergence"]),
            "workbenchToFineWorstNrmse": max(m["nrmse"] for m in row["versusNativeHigh"]),
            "oldNativeNodesInsideCore": endpoint.get("coveredCount"),
            "acceptedDomainCoverage": row["originalDomainCoverage"],
            "sameDefaultDataSha256": row["dataSha256"] == refined[index]["dataSha256"],
        })
    for name in ("Program.cs", "CompareFftClose.csproj"):
        bundle.write(root / "comparator" / name, "replay/comparator/" + name)
    for name in ("Run-Formal.py", "seal.py"):
        bundle.write(root / name, "replay/" + name)

(report / "three-way-comparison.json").write_bytes((root / "proof.json").read_bytes())
with (report / "by-request.csv").open("w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=list(ledger[0]))
    writer.writeheader()
    writer.writerows(ledger)
summary = {
    "replayed": len(ledger), "accepted": proof["passed"], "currentClose": 0,
    "legacyCloseRetained": len(scope), "checkedNativeTierSettings": 2 * len(scope),
    "byteIdenticalWithPreviousDefault": sum(row["sameDefaultDataSha256"] for row in ledger),
    "worstWorkbenchToFineNrmse": max(row["workbenchToFineWorstNrmse"] for row in ledger),
    "worstNativePairNrmse": max(row["nativePairWorstNrmse"] for row in ledger),
    "originalTwentyCurrentAcceptance": {"Pass": len(prior), "Close": 0, "Difference": 0, "Error": 0},
    "originalTwentyFrozenLowDirect": dict(legacy_tally),
    "originalTwentyComponents": {"latestCloseFollowup": sorted(scope), "earlierDifferences": sorted(diff_rows), "originalLowPass": sorted(pass_ids)},
    "applicationSha256": base["applicationSha256"], "coreSha256": base["coreSha256"],
    "policySha256": proof["policySha256"], "frozenArchiveSha256": proof["frozenArchiveSha256"],
    "reportFileHashes": {name: digest(report / name) for name in
                         ("formal-replay.zip", "by-request.csv", "three-way-comparison.json")},
}
write(report / "summary.json", summary)
print(json.dumps(summary, indent=2))

