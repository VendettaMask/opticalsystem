import concurrent.futures, csv, hashlib, json, pathlib, subprocess, sys, time

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/fft-low-close-20261108"
baseline = repo / "artifacts/validation/focal-fft-domain-20261108/full/analyses"
worker = repo / "tools/OpticalSystemDesign.ZemaxComparison/bin/Release/net10.0/OpticalSystemDesign.ZemaxComparison.dll"
prior = repo / "validation/rechecks/2026-11-08/fft-default-phase-recovery/by-request.csv"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, item):
    path.write_text(json.dumps(item, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

with prior.open(encoding="utf-8-sig", newline="") as file:
    cases = [(int(row["index"]), row["analysis"]) for row in csv.DictReader(file) if row["comparisonWithFrozenLowNative"] == "Close"]

def run(case):
    index, name = case
    identifier = f"{index:04d}"
    original = baseline / identifier / "request.json"
    for mode in ("formal",):
        source = read(original)
        directory = root / mode / identifier
        directory.mkdir(parents=True, exist_ok=False)
        source["outputDirectory"] = str(directory)
        settings = source["request"]["workbenchSettings"]
        assert "FourierSamplingMode" not in settings
        if mode == "fixed":
            settings["FourierSamplingMode"] = "Fixed"
        request = directory / "request.json"
        write(request, source)
        start = time.monotonic()
        complete = subprocess.run(["dotnet", str(worker), "--workbench-worker", str(request)],
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                                  errors="replace", timeout=900)
        write(directory / "execution.json",
              {"index": index, "mode": mode, "seconds": time.monotonic() - start, "exitCode": complete.returncode,
               "sourceRequestSha256": digest(original), "workerAssemblySha256": digest(worker),
               "output": complete.stdout})
        if complete.returncode:
            raise RuntimeError((identifier, mode, complete.stdout))
        result = read(directory / "data.json")
        values = result["values"]
        report = values.get("FourierSamplingValidation", {})
        print(index, mode, result["outcome"], report.get("returnedPupilSampling"), flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for _ in pool.map(run, cases):
        pass

