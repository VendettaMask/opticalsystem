import hashlib
import json
import pathlib
import shutil
import subprocess
from zipfile import ZipFile

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-427-incomparable-20261108"
baseline = repo / "artifacts/validation/focal-fft-domain-20261108/full"
native_root = repo / "artifacts/zemax-sequential-corpus/20261021/full-v1"
archive = repo / "validation/repairs/2026-10-21/sequential-corpus-full-evidence.zip"
prior = repo / "validation/rechecks/2026-11-08/parallel-focal-fft-applicability"
bin_dir = root / "bin-current"
scope = root / "frozen-compare"
scope.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def sha(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

old_summary = read(prior / "summary.json")
assert sha(archive) == old_summary["nativeReference"]["archiveSha256"]
identity = read(baseline / "identity.json")
assert sha(pathlib.Path(identity["policy"])) == sha(native_root / "comparison-settings.json") == old_summary["policySha256"]
with ZipFile(archive) as evidence:
    manifest = {r["path"]: r for r in json.loads(evidence.read("payload-manifest.json"))}

assemblies = ["OpticalSystemDesign.Core.dll", "OpticalSystemDesign.Application.dll",
              "OpticalSystemDesign.ZemaxComparison.dll", "ExampleAccuracy20261031.dll"]
hashes = {name: sha(bin_dir / name) for name in assemblies}
identity.update(coreSha256=hashes[assemblies[0]], freshSourceImport=False, requests=427, eligible=307,
                assemblies=[{"path": str(bin_dir / name), "sha256": value} for name, value in hashes.items()])
write(scope / "identity.json", identity)
shutil.copyfile(baseline / "models.json", scope / "models.json")
rows = read(root / "cohort.json")
receipts = []
for row in rows:
    index = row["index"]
    relative = f"{index:04d}"
    native = pathlib.Path(row["legacyPath"]) / "native"
    files = {}
    for path in sorted(native.iterdir()) if native.is_dir() else []:
        if not path.is_file() or path.suffix.lower() in {".png", ".svg", ".jpg", ".jpeg", ".pdf"}:
            continue
        name = "run/" + path.relative_to(native_root).as_posix()
        record = manifest[name]
        assert (record["sha256"], record["bytes"]) == (sha(path), path.stat().st_size), name
        files[name] = record["sha256"]
    receipt = {"index": index, "frozenNativeFiles": files, "canonicalJob": bool(row["job"])}
    receipts.append(receipt)
    if not row["job"]:
        continue
    source = root / "formal-fixed" / relative
    original = pathlib.Path(row["job"])
    actual = read(source / "request.json")
    job = read(original)
    fixed = row["key"] in {"PSF", "MTF", "FFT PSF Cross Section"}
    if fixed:
        assert actual["request"]["workbenchSettings"].pop("FourierSamplingMode") == "Fixed"
    assert actual["request"] == job["request"]
    snapshot = sha(pathlib.Path(job["snapshotPath"]))
    assert snapshot == sha(pathlib.Path(actual["snapshotPath"]))
    execution = read(source / "execution.json")
    assert execution["originalRequestSha256"] == sha(original)
    assert execution["workerSha256"] == hashes[assemblies[2]]
    receipt.update(originalRequestSha256=sha(original), executionRequestSha256=sha(source / "request.json"),
                   explicitHistoricalFixedMode=fixed, snapshotSha256=snapshot, exitCode=execution["exitCode"])
    destination = scope / "analyses" / relative
    destination.mkdir(parents=True, exist_ok=True)
    execution["error"] = execution["output"] if execution["exitCode"] else None
    write(destination / "execution.json", execution)
    if not execution["exitCode"]:
        provenance = read(source / "provenance.json")
        assert provenance["snapshotSha256"] == snapshot
        assert provenance["codeFingerprint"] == f"{hashes[assemblies[1]]}:{hashes[assemblies[0]]}"
        receipt.update(workbenchOutcome=read(source / "data.json")["outcome"],
                       dataSha256=sha(source / "data.json"), provenance=provenance)
        shutil.copyfile(source / "data.json", destination / "data.json")
    assert any(name.endswith("/batch-result.json") for name in files), index

assert len(receipts) == 427 and sum(row["canonicalJob"] for row in receipts) == 307
write(scope / "replay-receipt.json", receipts)
write(scope / "rows.json", rows)
subprocess.run(["dotnet", str(bin_dir / assemblies[3]), "compare", str(repo), str(scope)], check=True)
summary = read(scope / "summary.json")
summary["freshSourceImport"] = False
summary["frozenSettingsMode"] = "Replay imported snapshots, explicitly select historical fixed pupil mode for FFT PSF, MTF and cross sections"
write(scope / "summary.json", summary)
print("Verified original native files", sum(len(row["frozenNativeFiles"]) for row in receipts))
