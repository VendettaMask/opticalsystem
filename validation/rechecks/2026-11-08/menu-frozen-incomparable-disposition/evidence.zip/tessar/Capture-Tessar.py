import hashlib,json,os,pathlib,shutil,subprocess,time
repo=pathlib.Path.cwd()
root=repo/"artifacts/validation/menu-427-incomparable-20261108/tessar"
native=repo/"artifacts/zemax-sequential-corpus/20261021/full-v1"
definitions={i:next((native/"analyses").glob(f"{i}-*"))/"native"/"request.json" for i in (1927,1934)}
old={i:json.loads(p.read_text(encoding="utf-8-sig")) for i,p in definitions.items()}
api=pathlib.Path(old[1927]["zosApiPath"])
compiler=pathlib.Path(os.environ["WINDIR"])/"Microsoft.NET/Framework64/v4.0.30319/csc.exe"
host=root/"host"
host.mkdir(exist_ok=True)
exe=host/"ZemaxHost.exe"
sources=sorted((repo/"tools/OpticalSystemDesign.ZemaxComparison/ZemaxHost").glob("*.cs"))
libraries=[api/name for name in ("ZOSAPI.dll","ZOSAPI_Interfaces.dll","ZOSAPI_NetHelper.dll")]
assert compiler.is_file() and all(p.is_file() for p in libraries)
build=subprocess.run([str(compiler),"/nologo","/target:exe","/platform:x64","/out:"+str(exe),"/r:System.Web.Extensions.dll",
                      *("/r:"+str(p) for p in libraries),*(str(p) for p in sources)],
                     capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=60)
(host/"build.log").write_bytes(build.stdout+build.stderr)
build.check_returncode()
exe.with_suffix(".exe.config").write_text('<configuration><startup useLegacyV2RuntimeActivationPolicy="true"><supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.8"/></startup></configuration>',encoding="utf-8")
original=native/"sources/Objectives/Tessar lens using vignetting factors.zmx"
copy=root/original.name
shutil.copyfile(original,copy)
assert hashlib.sha256(copy.read_bytes()).digest()==hashlib.sha256(original.read_bytes()).digest()
environment={**os.environ,"PATH":str(api)+os.pathsep+os.environ.get("PATH","")}
for index,density in [(1927,1024),(1934,512),(1927,2048),(1934,1024),(1934,2048)]:
    folder=root/"native"/f"{index}-{density}"
    folder.mkdir(parents=True,exist_ok=False)
    request=dict(old[index])
    request["input"]=str(copy)
    request["pupilSampling"]=density
    if index==1934:
        request["zemaxSettings"]={**request["zemaxSettings"],"SampleSize":f"S_{density}x{density}"}
    request_path=folder/"request.json"
    request_path.write_text(json.dumps(request,ensure_ascii=False,indent=2),encoding="utf-8")
    start=time.monotonic()
    proc=subprocess.run([str(exe),str(request_path),str(folder)],cwd=host,env=environment,capture_output=True,
                         creationflags=subprocess.CREATE_NO_WINDOW,timeout=480)
    (folder/"process.log").write_bytes(proc.stdout+proc.stderr)
    (folder/"execution.json").write_text(json.dumps({"index":index,"sampling":density,"exitCode":proc.returncode,
        "seconds":time.monotonic()-start,"nativeHostSha256":hashlib.sha256(exe.read_bytes()).hexdigest(),
        "sourceSha256":hashlib.sha256(copy.read_bytes()).hexdigest()},indent=2),encoding="utf-8")
    data=folder/"data.json"
    print(index,density,proc.returncode,data.exists(),flush=True)
    if not data.exists() and not (folder/"environment.json").exists():
        raise RuntimeError((index,density,proc.stdout[-600:],proc.stderr[-600:]))

