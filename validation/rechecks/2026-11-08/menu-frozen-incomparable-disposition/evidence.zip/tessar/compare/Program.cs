using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Metrics;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var repo = Path.GetFullPath(args[0]);
var study = Path.GetFullPath(args[1]);
var root = Path.Combine(study, "tessar");
var nativeCorpus = Path.Combine(repo, "artifacts/zemax-sequential-corpus/20261021/full-v1");
var originalLens = Path.Combine(nativeCorpus, "sources/Objectives/Tessar lens using vignetting factors.zmx");
var sampledLens = Path.Combine(root, Path.GetFileName(originalLens));
Require(Hash(originalLens) == Hash(sampledLens), "Native capture source changed");
var policyPath = Path.Combine(nativeCorpus, "comparison-settings.json");
var policy = ComparisonConfiguration.Load(policyPath);
policy.Validate();
var results = new List<object>();
foreach (var index in new[] { 1927, 1934 })
{
    var current = Path.Combine(root, "current-" + index);
    var original = Path.Combine(study, "formal-fixed", index.ToString());
    var job = JsonFiles.Read<WorkbenchJob>(Path.Combine(original, "request.json"));
    var actualJob = JsonFiles.Read<WorkbenchJob>(Path.Combine(current, "request.json"));
    var frozenSettings = new Dictionary<string, string>(job.Request.WorkbenchSettings);
    if (index == 1927) Require(frozenSettings.Remove("FourierSamplingMode", out var frozenMode) && frozenMode == "Fixed", "Expected historical fixed mode");
    var request = job.Request with { WorkbenchSettings = frozenSettings };
    var actualSettings = new Dictionary<string, string>(actualJob.Request.WorkbenchSettings);
    if (index == 1934)
    {
        Require(actualSettings.Remove("FourierSamplingMode", out var mode) && mode == "Adaptive", "Energy requires the checked adaptive result");
        Require(actualSettings.Remove("FourierMaximumSampling") && actualSettings.Remove("FourierRelativeAccuracy"), "Missing energy controls");
    }
    Require((actualJob.Request with { WorkbenchSettings = actualSettings }).Fingerprint == request.Fingerprint
        && Hash(job.SnapshotPath) == Hash(actualJob.SnapshotPath), "Physical request or prescription changed");
    var productPath = Path.Combine(current, "data.json");
    var product = JsonFiles.Read<AnalysisData>(productPath);
    var certificate = (JsonElement)product.Values["FourierSamplingValidation"];
    Require(product.Outcome == AnalysisOutcome.Success && certificate.GetProperty("validated").GetBoolean(), "No converged product result");
    var entry = AnalysisComparisonRegistry.Get(request.CanonicalAnalysisKey);
    var actual = ResultNormalizer.Workbench(productPath, entry, request);
    var gates = policy.Analyses[request.CanonicalAnalysisKey].Quantities;
    var originalNative = Directory.GetDirectories(Path.Combine(nativeCorpus, "analyses"), index + "-*").Single();
    var originalCapture = Read(Path.Combine(originalNative, "native/captured-settings.json"));
    var references = new List<(int Sampling, NumericResult Data, object Proof)>();
    var rejected = new List<object>();
    foreach (var dir in Directory.GetDirectories(Path.Combine(root, "native-live"), index + "-*"))
    {
        var data = Path.Combine(dir, "data.json");
        var sampling = int.Parse(Path.GetFileName(dir).Split('-')[1]);
        if (!File.Exists(data) || !File.Exists(Path.Combine(dir, "result-diagnostics.json")))
        {
            rejected.Add(new { sampling, reason = "No completed native data" });
            continue;
        }
        try
        {
            var captured = Read(Path.Combine(dir, "captured-settings.json"));
            var nativeRequest = captured.GetProperty("request");
            Require(nativeRequest.GetProperty("configuration").GetInt32() == request.Configuration
                && nativeRequest.GetProperty("pupilSampling").GetInt32() == sampling, "Native configuration or sampling differs");
            Require(JsonElement.DeepEquals(originalCapture.GetProperty("selectors"), captured.GetProperty("selectors")),
                "Native field, wave or surface selector changed");
            var oldSettings = originalCapture.GetProperty("properties");
            var newSettings = captured.GetProperty("properties");
            Require(oldSettings.EnumerateObject().Count() == newSettings.EnumerateObject().Count()
                && newSettings.EnumerateObject().All(p => p.Name is "PupilSampleSize" or "SampleSize"
                    ? p.Value.GetString()!.EndsWith($"_{sampling}x{sampling}", StringComparison.Ordinal)
                    : oldSettings.TryGetProperty(p.Name, out var value) && JsonElement.DeepEquals(value, p.Value)),
                "Native setting other than pupil sampling changed");
            var environment = Read(Path.Combine(dir, "environment.json"));
            Require(environment.GetProperty("mode").GetString() == "Server"
                && environment.GetProperty("validLicense").GetBoolean()
                && environment.GetProperty("opticStudioVersion").ToString() == "260127", "Native version or headless identity differs");
            var diagnostics = Read(Path.Combine(dir, "result-diagnostics.json"));
            Require(diagnostics.GetProperty("messages").GetArrayLength() == 0, "Native diagnostics present");
            var normalized = ResultNormalizer.Zemax(data, entry, request with { PupilSampling = sampling }, productPath);
            references.Add((sampling, normalized, new { sampling, path = Path.GetRelativePath(study, dir), dataSha256 = Hash(data),
                settingsSha256 = Hash(Path.Combine(dir, "captured-settings.json")), modelSha256 = Hash(Path.Combine(dir, "model.json")),
                sourceSha256 = Hash(sampledLens), version = "2026 R1 (260127)" }));
        }
        catch (InvalidDataException failure)
        {
            rejected.Add(new { sampling, reason = failure.Message });
        }
    }
    var ordered = references.OrderBy(r => r.Sampling).ToArray();
    if (ordered.Length < 2)
    {
        results.Add(new { index, outcome = "Pending", references = ordered.Select(r => r.Proof), rejected, certificate });
        Console.WriteLine($"{index}: needs two valid native tiers");
        continue;
    }
    var low = ordered[^2]; var high = ordered[^1];
    var nativeConvergence = Compare(low.Data, high.Data, actual, gates);
    var productToFine = Compare(actual, high.Data, actual, gates);
    var productToCoarse = Compare(actual, low.Data, actual, gates);
    var passed = nativeConvergence.Concat(productToFine).All(m => m.Conclusion == Conclusion.Pass && m.Coverage == 1);
    var verdict = passed ? "Pass" : "Open";
    results.Add(new { index, outcome = verdict, requestFingerprint = request.Fingerprint, actualProductSha256 = Hash(productPath),
        productProvenance = Read(Path.Combine(current, "provenance.json")), certificate, references = ordered.Select(r => r.Proof), rejected,
        nativeConvergence, productToCoarse, productToFine, acceptedNativeTiers = new[] { low.Sampling, high.Sampling } });
    Console.WriteLine($"{index}: {verdict}, native pair NRMS {nativeConvergence.Max(m => m.Nrmse):R}, product cross {productToFine.Max(m => m.Nrmse):R}");
}
JsonFiles.Write(Path.Combine(root, "receipt.json"), new { policySha256 = Hash(policyPath), rows = results });

static ComparisonMetric[] Compare(NumericResult left, NumericResult right, NumericResult domain, IReadOnlyDictionary<string,Tolerances> gates)
{
    var result = new List<ComparisonMetric>();
    foreach (var expected in domain.Grids)
    {
        var a = left.Grids.Single(grid => grid.Id == expected.Id);
        var b = right.Grids.Single(grid => grid.Id == expected.Id);
        var aligned = ComparisonMetrics.Align(a, b, []);
        Require(a.X.SequenceEqual(expected.X) && a.Y.SequenceEqual(expected.Y)
            && aligned.Coverage == 1 && aligned.X.Length == 128*128, "Original 128 by 128 grid was not fully compared");
        result.Add(ComparisonMetrics.Calculate(expected.Id, expected.ValueAxis.Unit, aligned, gates[expected.ValueAxis.Quantity]));
    }
    foreach (var expected in domain.Series)
    {
        Require(expected.X.Length == 401 && expected.X[0] == 0 && Math.Abs(expected.X[^1] - 5) < 1e-12, "Original energy axis changed");
        var a = At(left, expected); var b = At(right, expected);
        result.Add(ComparisonMetrics.Calculate(expected.Id, expected.YAxis.Unit, new(expected.X,null,a,b,1), gates[expected.YAxis.Quantity]));
    }
    Require((domain.Grids.Count == 1 && domain.Series.Count == 0 && result.Count == 1)
        || (domain.Grids.Count == 0 && domain.Series.Count == 2 && result.Count == 2), "Missing actual/ideal or grid output");
    return result.ToArray();
}

static double[] At(NumericResult source, Series1DResult target)
{
    var series = PhysicalNormalization.Convert(source.Series.Single(s => s.Id == target.Id), target.XAxis, target.YAxis, []);
    var sorted = PhysicalNormalization.Sort(series.X, series.Y);
    return target.X.Select(x => PhysicalNormalization.Interpolate(sorted.X, sorted.Y, x)).ToArray();
}
static string Hash(string path) { using var input = File.OpenRead(path); return Convert.ToHexStringLower(SHA256.HashData(input)); }
static JsonElement Read(string path) => JsonFiles.Read<JsonElement>(path);
static void Require(bool condition, string message) { if(!condition) throw new InvalidDataException(message); }



