import concurrent.futures,csv,hashlib,json,pathlib,subprocess,time
repo=pathlib.Path.cwd()
root=repo/"artifacts/validation/menu-427-incomparable-20261108"
baseline=repo/"artifacts/validation/focal-fft-domain-20261108/full"
worker=root/"bin-current/OpticalSystemDesign.ZemaxComparison.dll"
frozen=repo/"validation/rechecks/2026-11-08/parallel-focal-fft-applicability/frozen-replay.csv"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def write(path,data): path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def sha(path):
    with path.open("rb") as file: return hashlib.file_digest(file,"sha256").hexdigest()
with frozen.open(encoding="utf-8-sig",newline="") as file:
    scope={int(row["index"]):row for row in csv.DictReader(file) if row["conclusion"]=="Incomparable"}
assert len(scope)==427 and sha(frozen)==read(frozen.parent/"summary.json")["frozenReplaySha256"]
rows=[row for row in read(baseline/"rows.json") if row["index"] in scope]
assert len(rows)==len(scope)
write(root/"cohort.json",rows)
output=root/"formal-fixed"
output.mkdir(exist_ok=True)
jobs=[row for row in rows if row.get("job")]
print("Canonical jobs:",len(jobs),"frozen-only",len(rows)-len(jobs),flush=True)
def run(row):
    index=row["index"]
    origin=pathlib.Path(row["job"])
    dest=output/f"{index:04d}"
    dest.mkdir(exist_ok=True)
    job=dest/"request.json"
    request=read(origin)
    request["outputDirectory"]=str(dest)
    fixed=row["key"] in {"PSF","MTF","FFT PSF Cross Section"}
    if fixed:
        assert "FourierSamplingMode" not in request["request"]["workbenchSettings"]
        request["request"]["workbenchSettings"]["FourierSamplingMode"]="Fixed"
    write(job,request)
    start=time.monotonic()
    result=subprocess.run(["dotnet",str(worker),"--workbench-worker",str(job)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                          text=True,encoding="utf-8",errors="replace",timeout=900)
    write(dest/"execution.json",{"index":index,"exitCode":result.returncode,"seconds":time.monotonic()-start,
          "originalRequestSha256":sha(origin),"workerSha256":sha(worker),"output":result.stdout})
    if result.returncode:
        print(index,row["key"],"worker exit",result.returncode,flush=True)
        return
    provenance=read(dest/"provenance.json")
    if not fixed:
        assert provenance["requestFingerprint"]==scope[index]["requestFingerprint"]
    data=read(dest/"data.json")
    print(index,row["key"],data["outcome"],flush=True)
# Start the longest remaining two optics as early as possible.
jobs.sort(key=lambda row: (row["index"] not in (1927,1934),row["index"]))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for _ in pool.map(run,jobs): pass

