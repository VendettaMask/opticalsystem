import collections
import csv
import hashlib
import json
import pathlib
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-427-incomparable-20261108"
rechecks = repo / "validation/rechecks"
prior = rechecks / "2026-11-08/parallel-focal-fft-applicability"
report = rechecks / "2026-11-08/menu-frozen-incomparable-disposition"
report.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def sha(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

def item(path):
    return {"path": path.relative_to(repo).as_posix(), "sha256": sha(path)}

def csv_read(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))

def csv_write(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)

def indexed(rows, key="index"):
    data = {int(row[key]): row for row in rows}
    assert len(data) == len(rows)
    return data

archive_495 = rechecks / "2026-11-01/example-incomparable-repair/psf-evidence.zip"
archive_497 = rechecks / "2026-11-01/grid-grin-mtf-phase/evidence.zip"
assert sha(archive_495) == "87e0fc48419b7f37b11c152cd4a04b47897b37140dd7266890f94f2f562d8671"
assert sha(archive_497) == read(archive_497.parent / "verification.json")["sha256"]
grin = {}
for index, archive, members in [
    (495, archive_495, ["checks/comparison.json"]),
    (497, archive_497, [
        "artifacts/validation/grid-mtf-final-core-20261101/compare-results.json",
        "artifacts/validation/grid-mtf-final-fine-reference-20261101/compare-results.json"]),
]:
    with ZipFile(archive) as evidence:
        assert evidence.testzip() is None
        cases = [row for member in members for row in json.loads(evidence.read(member))]
    assert all(row["index"] == index and row["conclusion"] == "Pass"
               and all(metric["conclusion"] == "Pass" for metric in row["metrics"]) for row in cases)
    if index == 495:
        scope = archive.parent / "psf-scope.json"
        assert read(scope)["originalGatesUnchanged"] and cases[0]["metrics"][0]["maxAbsolute"] <= 1e-5
    else:
        scope = archive.parent / "scope.json"
        scope_data = read(scope)
        assert not scope_data["gatesChanged"] and all(
            row["workbenchCoreSha256"] == scope_data["coreSha256"] for row in cases)
    grin[index] = {"scope": "HistoricalRefinedGridGrinIntegration", "archive": item(archive),
                   "members": members, "contract": item(scope), "cases": cases}

bounded = rechecks / "2026-11-06/grid-grin-bounded-fft-reference"
product = bounded / "product-comparisons.json"
certificate = bounded / "reference-certificate.json"
profile = read(certificate)["profile"]
assert profile["index"] == 499 and profile["status"] == "Pass" and profile["sampleCount"] == 32769
assert all(profile[key]["verdict"] == "Pass" and profile[key]["pointwise"]
           for key in ("nativeDirectIntegrationStep", "nativeHigherEffectiveSampling"))
controls = {key: data for key, data in read(product).items() if key in {"profile-8192-window317", "profile-16384-window317"}}
assert len(controls) == 2 and all(case["coverage"] == 1 and case["count"] == 32769 and case["verdict"] == "Pass"
    and case["pointwise"] and case["maxAbsolute"] <= data["gate"]["absolute"]
    for data in controls.values() for case in data["comparisons"].values())
with ZipFile(bounded / "native-bounded-fft.zip") as evidence:
    assert evidence.testzip() is None
grin[499] = {"scope": "HistoricalBoundedGridGrinProfile", "archive": item(bounded / "native-bounded-fft.zip"),
             "certificate": item(certificate), "productComparisons": item(product),
             "referenceProfile": item(bounded / "profile-reference.csv"),
             "reference": profile, "product": controls}
write(root / "historical-grid-grin-receipt.json", grin)

prior_summary = read(prior / "summary.json")
assert sha(prior / "frozen-replay.csv") == prior_summary["frozenReplaySha256"]
frozen = indexed([row for row in csv_read(prior / "frozen-replay.csv") if row["conclusion"] == "Incomparable"])
assert len(frozen) == prior_summary["frozen"]["Incomparable"] == 427
ledger = indexed([row for row in csv_read(prior / "independent-coverage.csv") if row["frozenVerdict"] == "Incomparable"])
cohort = indexed(read(root / "cohort.json"))
original = indexed(read(root / "frozen-compare/replay-receipt.json"))
replayed = indexed(read(root / "frozen-compare/results.json"))
assert set(frozen) == set(ledger) == set(cohort) == set(original) == set(replayed)
assert all(row["conclusion"] == "Incomparable" for row in replayed.values())

afocal = indexed(read(root / "afocal-meter/receipt.json")["rows"])
followup = indexed(read(root / "followup/receipt.json")["rows"])
older = indexed(read(root / "followup/older-receipt.json")["rows"])
applicable = indexed(list(read(root / "applicability/receipt.json")["rows"].values()))
opd = indexed(read(root / "opd/raw/dense-results.json")["reports"], "id")
fan_all = indexed(read(root / "fan/explicit-fan-coverage/results.json"))
assert len(fan_all) == 120 and set(opd) < set(fan_all)
fan = {index: row for index, row in fan_all.items() if index not in opd}
tessar = indexed(read(root / "tessar/receipt.json")["rows"])
core = read(root / "frozen-compare/identity.json")["coreSha256"]
assert all(row["state"] == "Verified" for row in afocal.values())
assert all(row["numericVerdict"] == "Pass" for row in followup.values())
assert collections.Counter(row["auditScope"] for row in older.values()) == {
    "ImmutablePriorNativeAndCoreRefinedSampling": 30, "ImmutablePriorFinalCoreRecheck": 8}
assert all(row["evidence"] for row in older.values())
assert all(row["physical"] == "Pass" for row in fan.values())
assert all(row["conclusion"] == row["addedPointwiseConclusion"] == "Pass" for row in opd.values())
assert all(row["outcome"] == "Pass" and row["productProvenance"]["codeFingerprint"].endswith(core)
           for row in tessar.values())
assert set(tessar) == {1927, 1934}
assert all(row["diagnosticDisposition"] in {"OriginalRequestTypedNotApplicable", "ScopeVerifiedByCanonicalAlternative",
           "ScopeVerifiedWithExplicitlyWithheldCardinals"} for row in applicable.values())
groups = [
    ("AfocalMeterAndRayArcs", "afocal-meter/receipt.json", afocal, 134),
    ("ExplicitPupilFans", "fan/explicit-fan-coverage/results.json", fan, 98),
    ("ExactNormalizedPupilOPD", "opd/raw/dense-results.json", opd, 22),
    ("SupplementalPrecision", "followup/receipt.json", followup, 87),
    ("ArchivedRefinedSampling", "followup/older-receipt.json", older, 38),
    ("ArchivedGridGRIN", "historical-grid-grin-receipt.json", grin, 3),
    ("TessarConvergedNative", "tessar/receipt.json", tessar, 2),
    ("PhysicalApplicability", "applicability/receipt.json", applicable, 43),
]
matches = {}
for group, member, data, expected_count in groups:
    assert len(data) == expected_count and not (set(data) & set(matches))
    matches.update({index: (group, member, row) for index, row in data.items()})
assert set(matches) == set(frozen)

by_request = []
for index, (group, member, evidence) in sorted(matches.items()):
    job = cohort[index]
    original_row = original[index]
    assert bool(job["job"]) == original_row["canonicalJob"]
    prior_row = ledger[index]
    independent = "ScopeNotApplicable" if index in applicable else "IndependentNumericalPass"
    if index in tessar:
        assert prior_row["disposition"] == "HistoricalExclusion"
    elif index in applicable:
        assert "NotApplicable" in prior_row["disposition"], (index, prior_row)
    else:
        assert prior_row["disposition"] in {"IndependentNumericalPass", "SupplementalPass", "单色 OPD 原坐标逐点通过", "高档独立收敛对照通过"}, (index, prior_row)
    status = original_row.get("workbenchOutcome")
    if status is None:
        status = "WorkerError" if original_row["canonicalJob"] else "NoCanonicalRequest"
    by_request.append({
        "index": index, "lensIndex": job["lensIndex"], "lens": job["lens"], "configuration": job["configuration"],
        "analysis": job["key"], "frozenVerdict": frozen[index]["conclusion"],
        "currentAgainstFrozenNative": replayed[index]["conclusion"], "currentFixedWorkbenchOutcome": status,
        "priorIndependentDisposition": prior_row["disposition"], "independentDisposition": independent,
        "referenceFamily": group, "scopedEvidence": member, "frozenRequestFingerprint": frozen[index]["requestFingerprint"],
        "scope": evidence.get("scope", evidence.get("auditScope", evidence.get("diagnosticDisposition", group))),
    })
csv_write(report / "by-request.csv", by_request)

models = read(root / "frozen-compare/models.json")
assert len(models) == prior_summary["menuLenses"] == 95
by_lens = []
for model in models:
    rows = [row for row in by_request if row["lensIndex"] == model["index"]]
    counts = collections.Counter(row["independentDisposition"] for row in rows)
    by_lens.append({"lensIndex": model["index"], "lens": model["lens"], "configurations": len(model["snapshots"]),
                    "frozenIncomparable": len(rows), "canonicalRequestsReplayed": sum(
                        row["currentFixedWorkbenchOutcome"] != "NoCanonicalRequest" for row in rows),
                    "independentNumericalPass": counts["IndependentNumericalPass"],
                    "scopeNotApplicable": counts["ScopeNotApplicable"], "open": len(rows) - sum(counts.values())})
csv_write(report / "by-lens.csv", by_lens)
assert sum(row["open"] for row in by_lens) == 0

test = root / "menu-427-focused.trx"
counts = ET.parse(test).getroot().find(".//{*}Counters").attrib
assert counts["passed"] == "167" and counts["failed"] == "0"
files = {member: root / member for _, member, _, _ in groups}
files.update({name: root / name for name in [
    "frozen-compare/identity.json", "frozen-compare/replay-receipt.json", "frozen-compare/summary.json",
    "frozen-compare/results.json", "Compare-Fixed.py", "Run-Fixed.py", "Seal.py", "menu-427-focused.trx",
    "afocal-meter/verified-scopes.zip", "afocal-meter/arc-reference.json",
    "followup/current-point-checks.json", "followup/fresh-current-controls.json", "followup/hash-gap-resolution.json",
    "tessar/Capture-Tessar.py", "tessar/compare/Program.cs", "tessar/compare/CompareTessar.csproj"]})
for folder in sorted((root / "current-applicability").iterdir()):
    for path in folder.glob("*.json"):
        files[path.relative_to(root).as_posix()] = path
for folder in sorted((root / "tessar/native-live").iterdir()):
    for name in ("capture.json", "captured-settings.json", "data.json", "environment.json", "model.json",
                 "native-stage.json", "request.json", "result-diagnostics.json", "settings.CFG"):
        path = folder / name
        assert path.is_file()
        files[path.relative_to(root).as_posix()] = path
for index in tessar:
    folder = root / "tessar" / f"current-{index}"
    for path in folder.glob("*.json"):
        files[path.relative_to(root).as_posix()] = path

evidence_path = report / "evidence.zip"
with ZipFile(evidence_path, "w", compression=ZIP_DEFLATED, compresslevel=6) as evidence:
    for member, path in sorted(files.items()):
        evidence.write(path, member)
    evidence.writestr("manifest.json", json.dumps({member: sha(path) for member, path in sorted(files.items())}, indent=2))
with ZipFile(evidence_path) as evidence:
    assert evidence.testzip() is None
    assert all(hashlib.sha256(evidence.read(member)).hexdigest() == digest
               for member, digest in json.loads(evidence.read("manifest.json")).items())

write(report / "summary.json", {
    "menuLenses": 95, "frozenConfigurations": 115, "frozenRequests": 3024,
    "affectedLenses": sum(row["frozenIncomparable"] > 0 for row in by_lens),
    "frozenMatrix": prior_summary["frozen"], "scopeRequests": 427,
    "frozenReplay": item(prior / "frozen-replay.csv"), "originalNativeArchive": prior_summary["nativeReference"]["archiveSha256"],
    "originalNativePayloadsVerified": sum(len(row["frozenNativeFiles"]) for row in original.values()),
    "currentCoreSha256": core, "policySha256": prior_summary["policySha256"],
    "currentComparisonAgainstFrozenNative": {"Incomparable": 427},
    "currentFixedWorkbenchOutcomes": dict(collections.Counter(row["currentFixedWorkbenchOutcome"] for row in by_request)),
    "currentFixedWorkerErrorIndices": [row["index"] for row in by_request if row["currentFixedWorkbenchOutcome"] == "WorkerError"],
    "independentDisposition": {"IndependentNumericalPass": 384, "ScopeNotApplicable": 43, "Open": 0},
    "evidenceFamilies": {group: {"count": count, "member": member, "sha256": sha(root / member)}
                         for group, member, _, count in groups},
    "tested": {"passed": 167, "failed": 0, "member": test.name, "sha256": sha(test)},
    "applicability": read(root / "applicability/receipt.json")["summary"],
    "originalJobsReplayed": 307, "rowsWithoutCanonicalFrozenJob": 120,
    "priorSupplementalAncillaryFilesWithoutOriginalBytes": read(root / "followup/receipt.json")["ancillaryMissingHashCount"],
    "evidenceArchive": {**item(evidence_path), "entries": len(files) + 1, "contentsHashVerified": True},
    "requestLedger": item(report / "by-request.csv"), "lensLedger": item(report / "by-lens.csv")
})
print("Sealed 427 requests, 95 lenses, 384 numeric, 43 not applicable, 0 open.")



