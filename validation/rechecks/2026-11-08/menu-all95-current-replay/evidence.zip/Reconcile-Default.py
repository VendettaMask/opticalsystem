import hashlib
import json
import pathlib
import subprocess

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-all95-fixed-current-20261108"
known = root / "default-controls.json"
retry = root / "default-controls/1989"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

document = read(known)
original = next(row for row in document["rows"] if row["index"] == 1989)
first_attempt = original.get("firstAttempt", {"exitCode": original["exitCode"], "timeoutSeconds": 240})
assert first_attempt["exitCode"] == 124
done = read(retry / "retry-execution.json")
assert done["exitCode"] == 0 and read(retry / "data.json")["outcome"] == "Success"
actual = sha(retry / "data.json")
original.update(firstAttempt=first_attempt, exitCode=0, outcome="Success", currentDataSha256=actual,
                byteIdentical=actual == original["previousDataSha256"], provenance=read(retry / "provenance.json"),
                isolatedRetry=done)

runner = repo / "artifacts/validation/fft-low-reference-20261108/comparator/bin/Release/net10.0/CompareFftReferenceDrift.dll"
receipt = root / "default-native-recomparison.json"
subprocess.run(["dotnet", str(runner), str(repo), str(root / "default-controls"), str(receipt)], check=True)
comparison = read(receipt)
assert comparison["passed"] == 16 and comparison["failed"] == comparison["pending"] == 0
compared = {row["index"]: row for row in comparison["rows"]}
for row in document["rows"]:
    assert row["outcome"] == "Success" and row["exitCode"] == 0
    if row["index"] in compared:
        proof = compared[row["index"]]
        assert proof["state"] == "Pass" and proof["dataSha256"] == row["currentDataSha256"]
        row["nativeRecomparison"] = {"state": proof["state"], "receiptSha256": sha(receipt),
                                     "comparedOriginalCoordinates": proof["originalDomainCoverage"],
                                     "nativeConvergence": proof["nativeConvergence"],
                                     "versusNativeLow": proof["versusNativeLow"],
                                     "versusNativeHigh": proof["versusNativeHigh"]}
    assert row["byteIdentical"] or row.get("nativeRecomparison", {}).get("state") == "Pass"
known.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Default controls reconciled",sum(row["byteIdentical"] for row in document["rows"]),
      "byte-identical;",comparison["passed"],"recompared against both native tiers")
