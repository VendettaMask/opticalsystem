import hashlib
import json
import pathlib
import subprocess
from zipfile import ZipFile

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-all95-fixed-current-20261108"
authority = repo / "validation/rechecks/2026-11-08/fft-default-phase-recovery"
frozen = repo / "validation/rechecks/2026-11-08/fft-low-close-disposition/summary.json"
worker = root / "bin/OpticalSystemDesign.ZemaxComparison.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

members = read(frozen)["originalTwentyComponents"]
scope = sorted(index for group in members.values() for index in group)
assert len(set(scope)) == len(scope) == 20
archive = authority / "formal-evidence.zip"
with archive.open("rb") as stream:
    archive_hash = hashlib.file_digest(stream, "sha256").hexdigest()
assert archive_hash == read(authority / "summary.json")["reportFileHashes"]["formal-evidence.zip"]
results = []
with ZipFile(archive) as evidence:
    for index in scope:
        relative = f"{index:04d}"
        target = root / "default-controls" / relative
        target.mkdir(parents=True, exist_ok=True)
        product = evidence.read(f"formal/{relative}/data.json")
        request = json.loads(evidence.read(f"formal/{relative}/request.json"))
        current = read(root / "full/analyses" / relative / "request.json")
        assert sha(pathlib.Path(current["snapshotPath"]).read_bytes()) == sha(pathlib.Path(request["snapshotPath"]).read_bytes())
        assert current["request"] == request["request"]
        assert "FourierSamplingMode" not in request["request"]["workbenchSettings"]
        request["snapshotPath"] = current["snapshotPath"]
        request["outputDirectory"] = str(target)
        job = target / "request.json"
        write(job, request)
        try:
            run = subprocess.run(["dotnet", str(worker), "--workbench-worker", str(job)], timeout=240,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
            execution = {"index": index, "exitCode": run.returncode, "log": run.stdout.decode("utf-8", errors="replace")}
        except subprocess.TimeoutExpired:
            execution = {"index": index, "exitCode": 124, "log": "Default control exceeded 240 seconds"}
        write(target / "execution.json", execution)
        row = {"index": index, "exitCode": execution["exitCode"], "previousDataSha256": sha(product)}
        if execution["exitCode"] == 0:
            current_product = (target / "data.json").read_bytes()
            data = json.loads(current_product)
            row.update(outcome=data["outcome"], currentDataSha256=sha(current_product),
                       byteIdentical=current_product == product, provenance=read(target / "provenance.json"))
        results.append(row)
        print(index, row.get("outcome", "WorkerError"), row.get("byteIdentical", False), flush=True)
        write(root / "default-controls.json", {"archiveSha256": archive_hash, "expected": scope, "rows": results})
