import collections
import csv
import hashlib
import json
import pathlib
import shutil
import subprocess

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-all95-fixed-current-20261108"
full = root / "full"
reports = repo / "validation/rechecks/2026-11-08"
previous = reports / "parallel-focal-fft-applicability"
report = reports / "menu-all95-current-replay"
report.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def csv_read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))

def csv_write(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)

def indexed(rows):
    values = {int(row["index"]): row for row in rows}
    assert len(values) == len(rows)
    return values

def proof(path):
    return {"path": path.relative_to(repo).as_posix(), "sha256": digest(path)}

def assert_report_hash(path, summary, key):
    raw = read(summary)[key]
    expected = raw["sha256"] if isinstance(raw, dict) else raw
    assert digest(path) == expected, path

native = read(root / "reference-integrity.json")
assert native["allMatched"] and native["filesVerified"] >= 30700
history = previous / "frozen-replay.csv"
previous_summary = read(previous / "summary.json")
assert digest(history) == previous_summary["frozenReplaySha256"]
frozen = indexed(csv_read(history))
assert len(frozen) == 3024 and collections.Counter(row["conclusion"] for row in frozen.values()) == previous_summary["frozen"]
models = read(full / "models.json")
assert len(models) == 95 and sum(len(model["snapshots"]) for model in models) == 115
assert all(not model["error"] for model in models)
identity = read(full / "identity.json")
core = digest(root / "bin/OpticalSystemDesign.Core.dll")
application = digest(root / "bin/OpticalSystemDesign.Application.dll")
assert identity["coreSha256"] == core
assert core == digest(repo / "artifacts/validation/fft-fixed-window-repair-20261108/bin-final/OpticalSystemDesign.Core.dll")
assert application == digest(repo / "artifacts/validation/fft-fixed-window-repair-20261108/bin-final/OpticalSystemDesign.Application.dll")
prepared = indexed(read(full / "rows.original.json"))
translated = indexed(read(full / "explicit-fixed-mode.json"))
workers = [read(path) for path in (full / "workers").glob("*.json")]
assert len(workers) == len({row["lensIndex"] for row in prepared.values() if row["job"]}) == 90
assert all(row["result"]["exitCode"] == 0 and not row["result"]["timedOut"] for row in workers)
assert len(translated) == 324
assert len(list((full / "analyses").glob("*/execution.json"))) == 2904

controls = indexed(read(root / "default-controls.json")["rows"])
older_controls = read(reports / "fft-low-close-disposition/summary.json")["originalTwentyComponents"]
assert set(controls) == {index for group in older_controls.values() for index in group}
assert set(controls) == {index for index, row in frozen.items() if row["conclusion"] == "Error"}
for row in controls.values():
    if row.get("outcome") == "Success":
        assert row["provenance"]["codeFingerprint"] == f"{application}:{core}"

# Restore the original comparison identities. The explicit fixed worker
# settings and fingerprints are kept separately in every translated folder.
shutil.copyfile(full / "rows.original.json", full / "rows.json")
if not (full / "results.json").exists():
    subprocess.run(["dotnet", str(root / "bin/ExampleAccuracy20261031.dll"), "compare", str(repo), str(full)], check=True)

direct = indexed(read(full / "results.json"))
assert set(direct) == set(frozen) == set(prepared)
assert all(row["coreSha256"] == core for row in direct.values())
diff_dir = reports / "menu-frozen-differences-disposition"
close_dir = reports / "menu-frozen-close-disposition"
inc_dir = reports / "menu-frozen-incomparable-disposition"
assert_report_hash(inc_dir / "by-request.csv", inc_dir / "summary.json", "requestLedger")
tables = {
    "Difference": indexed(csv_read(diff_dir / "by-request.csv")),
    "Close": indexed(csv_read(close_dir / "by-request.csv")),
    "Incomparable": indexed(csv_read(inc_dir / "by-request.csv")),
}
for state, records in tables.items():
    assert set(records) == {index for index, row in frozen.items() if row["conclusion"] == state}
    if state != "Incomparable":
        assert all(row["currentIndependentAcceptance"] == "Pass" for row in records.values())
    else:
        assert collections.Counter(row["independentDisposition"] for row in records.values()) == {
            "IndependentNumericalPass": 384, "ScopeNotApplicable": 43}
fixed_recent = reports / "fft-fixed-physical-window/verification.json"
repaired = indexed(read(fixed_recent)["results"])
assert set(repaired) == {555, 2499}
assert all(row["metrics"]["conclusion"] == "Pass" and row["provenance"]["codeFingerprint"] == f"{application}:{core}"
           for row in repaired.values())

rows = []
for index, historical in sorted(frozen.items()):
    item = prepared[index]
    comparison = direct[index]
    state = historical["conclusion"]
    fixed = "NoCanonicalRequest"
    current_hash = ""
    fixed_provenance = ""
    reason = comparison.get("reason") or ""
    if item["job"]:
        job_path = pathlib.Path(item["job"])
        folder = job_path.parent
        execution = read(folder / "execution.json")
        assert execution["coreSha256"] == core
        if index in translated:
            setting = translated[index]
            assert digest(job_path) == setting["originalRequestSha256"]
            actual = folder / "fixed-execution-request.json"
            assert digest(actual) == setting["fixedExecutionRequestSha256"]
        if execution["exitCode"] == 0:
            data = folder / "data.json"
            current_hash = digest(data)
            fixed = read(data)["outcome"]
            provenance = read(folder / "provenance.json")
            assert provenance["codeFingerprint"] == f"{application}:{core}"
            fixed_provenance = provenance["requestFingerprint"]
            assert provenance["snapshotSha256"] == digest(pathlib.Path(item["snapshot"]))
        else:
            fixed = "WorkerError"
    prior_hash = historical["currentDataSha256"]
    same_fixed = bool(current_hash and current_hash == prior_hash)
    if index in repaired:
        assert fixed == "Success" and current_hash == repaired[index]["workbenchDataSha256"]
    direct_state = comparison["conclusion"]
    if state == "Pass":
        accepted = "DirectPass" if direct_state == "Pass" else "Open"
        evidence = "CurrentFixedDirectComparison"
    elif state == "Error":
        control = controls[index]
        exact = control.get("byteIdentical") is True
        compared = control.get("nativeRecomparison", {}).get("state") == "Pass"
        ok = control.get("outcome") == "Success" and (exact or compared)
        accepted = "IndependentNumericalPass" if ok else "Open"
        evidence = ("CurrentDefaultExactMatchToConvergedReceipt" if exact else
                    "CurrentDefaultRecomparedAgainstConvergedNative" if compared else
                    "CurrentDefaultNeedsIndependentRecomparison")
    elif state in ("Difference", "Close"):
        accepted = "IndependentNumericalPass"
        evidence = "AcceptedScopedReference" + ("WithIdenticalFixedProduct" if same_fixed else "")
    else:
        accepted = tables[state][index]["independentDisposition"]
        evidence = tables[state][index]["referenceFamily"]
        if index in repaired:
            evidence = "CurrentFixedToIndependentConvergedReference"
    rows.append({
        "index": index, "lensIndex": item["lensIndex"], "lens": item["lens"], "configuration": item["configuration"],
        "analysis": item["key"], "frozenVerdict": state, "currentFixedVsFrozenReference": direct_state,
        "currentFixedWorkbenchOutcome": fixed, "acceptedStatus": accepted, "acceptanceEvidence": evidence,
        "workbenchDataSha256": current_hash, "sameFixedDataAsPreviousFullReplay": same_fixed if item["job"] else "",
        "fixedExecutionFingerprint": fixed_provenance, "originalEffectiveFingerprint": historical["requestFingerprint"],
        "currentDirectReason": reason,
    })
csv_write(report / "by-request.csv", rows)
supplement = read(root / "lens-supplement-controls.json")
supplement_direct = {row["name"]: row for row in read(root / "supplemental-native-comparisons.json")}
supplement_by_lens = collections.Counter()
no_canonical_lenses = {model["index"] for model in models} - {row["lensIndex"] for row in prepared.values() if row["job"]}
assert {row["lensIndex"] for row in supplement["rows"]} == no_canonical_lenses == {2, 19, 28, 35, 76}
for row in supplement["rows"]:
    assert row["outcome"] == "Success" and row["provenance"]["codeFingerprint"] == f"{application}:{core}"
    if row["byteIdentical"]:
        row["validation"] = "ByteIdenticalToPreviouslyAcceptedResult"
    else:
        compared = supplement_direct[row["case"]]
        assert compared["conclusion"] == "Pass" and compared["workbenchSha256"] == row["currentDataSha256"]
        row["validation"] = "RecomparedAgainstNativeReference"
        row["comparison"] = compared
    supplement_by_lens[row["lensIndex"]] += 1
write(report / "lens-supplement-controls.json", supplement)

matrix = []
for model in models:
    group = [row for row in rows if row["lensIndex"] == model["index"]]
    direct_counts = collections.Counter(row["currentFixedVsFrozenReference"] for row in group)
    acceptance = collections.Counter(row["acceptedStatus"] for row in group)
    fixed = collections.Counter(row["currentFixedWorkbenchOutcome"] for row in group)
    matrix.append({
        "lensIndex": model["index"], "lens": model["lens"], "configurations": len(model["snapshots"]), "requests": len(group),
        "fixedExecuted": len(group) - fixed["NoCanonicalRequest"], "noCanonicalRequest": fixed["NoCanonicalRequest"],
        "additionalCurrentScopedControls": supplement_by_lens[model["index"]],
        "fixedWorkbenchWorkerError": fixed["WorkerError"], "fixedDirectPass": direct_counts["Pass"],
        "fixedDirectClose": direct_counts["Close"], "fixedDirectDifference": direct_counts["Difference"],
        "fixedDirectIncomparable": direct_counts["Incomparable"], "fixedDirectError": direct_counts["Error"],
        "acceptedDirect": acceptance["DirectPass"], "acceptedIndependently": acceptance["IndependentNumericalPass"],
        "confirmedNotApplicable": acceptance["ScopeNotApplicable"], "open": acceptance["Open"],
    })
csv_write(report / "by-lens.csv", matrix)
changed = [row for row in rows if row["frozenVerdict"] != row["currentFixedVsFrozenReference"]]
csv_write(report / "verdict-changes.csv", changed or [{
    "index": "", "lensIndex": "", "lens": "", "configuration": "", "analysis": "",
    "frozenVerdict": "", "currentFixedVsFrozenReference": "", "currentFixedWorkbenchOutcome": "",
    "acceptedStatus": "", "acceptanceEvidence": "", "workbenchDataSha256": "",
    "sameFixedDataAsPreviousFullReplay": "", "fixedExecutionFingerprint": "", "originalEffectiveFingerprint": "",
    "currentDirectReason": "",
}])
scoped_sources = {
    "previousFrozenMatrix": proof(history), "differenceAcceptance": proof(diff_dir / "by-request.csv"),
    "closeAcceptance": proof(close_dir / "by-request.csv"), "incomparableAcceptance": proof(inc_dir / "by-request.csv"),
    "previousDefaultRecovery": proof(reports / "fft-default-phase-recovery/by-request.csv"),
    "newFixedWindowAcceptance": proof(fixed_recent),
}
summary = {
    "lensesImported": 95, "configurationsImported": 115, "requests": len(rows), "originalFixedRequestsExecuted": 2904,
    "withoutCanonicalRequest": 120, "explicitHistoricalFixedMode": len(translated),
    "applicationSha256": application, "coreSha256": core, "frozenReference": native,
    "originalFrozenClassifications": previous_summary["frozen"],
    "currentFixedDirectComparisons": dict(collections.Counter(row["currentFixedVsFrozenReference"] for row in rows)),
    "fixedWorkbenchOutcomes": dict(collections.Counter(row["currentFixedWorkbenchOutcome"] for row in rows)),
    "currentFixedDirectVerdictChanges": [row["index"] for row in changed],
    "byteIdenticalToPreviousFixedFullReplay": sum(row["sameFixedDataAsPreviousFullReplay"] is True for row in rows),
    "defaultControls": {"run": len(controls), "success": sum(row.get("outcome") == "Success" for row in controls.values()),
                        "byteIdentical": sum(row.get("byteIdentical") is True for row in controls.values()),
                        "recomparedAgainstBothNativeTiers": sum(row.get("nativeRecomparison", {}).get("state") == "Pass" for row in controls.values())},
    "acceptanceWithRecordedScopedReferences": dict(collections.Counter(row["acceptedStatus"] for row in rows)),
    "lensesWithOpenItems": [row["lensIndex"] for row in matrix if row["open"]],
    "additionalCurrentScopedControls": {"lenses": sorted(no_canonical_lenses), "rows": len(supplement["rows"]),
        "byteIdentical": sum(row["byteIdentical"] for row in supplement["rows"]),
        "recomparedAgainstNative": len(supplement_direct), "receipt": proof(report / "lens-supplement-controls.json")},
    "sources": scoped_sources,
    "requestLedger": proof(report / "by-request.csv"), "lensLedger": proof(report / "by-lens.csv"),
    "directComparatorResults": proof(full / "results.json"),
}
write(report / "summary.json", summary)
shutil.copyfile(root / "default-controls.json", report / "default-controls.json")
print(json.dumps({k: v for k, v in summary.items() if k not in {"sources"}}, indent=2))


