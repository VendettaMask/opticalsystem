import hashlib, json, pathlib

root = pathlib.Path("artifacts/validation/menu-all95-fixed-current-20261108")
old = pathlib.Path("artifacts/validation/focal-fft-domain-20261108/full/models.json")
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

receipts = []
for current, previous in zip(read(root / "full/models.json"), read(old), strict=True):
    assert all(current[key] == previous[key] for key in ("index", "lens", "sourceSha256", "sourceSurfaceNumbers"))
    assert digest(pathlib.Path(current["source"])) == current["sourceSha256"]
    for config, (after, before) in enumerate(zip(current["snapshots"], previous["snapshots"], strict=True), 1):
        assert digest(pathlib.Path(after)) == digest(pathlib.Path(before))
        receipts.append({"lensIndex": current["index"], "configuration": config, "snapshotSha256": digest(pathlib.Path(after)),
                         "sourceSha256": current["sourceSha256"]})
assert len(receipts) == 115 and len({row["lensIndex"] for row in receipts}) == 95
(root / "snapshot-integrity.json").write_text(json.dumps(receipts, indent=2) + "\n", encoding="utf-8")
