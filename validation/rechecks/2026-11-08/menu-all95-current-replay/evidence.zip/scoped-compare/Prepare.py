import hashlib, json, pathlib, zipfile
r=pathlib.Path("artifacts/validation/menu-all95-fixed-current-20261108")
prior=pathlib.Path("validation/rechecks")
prism=prior/"2026-10-26/afocal-recompare/evidence.zip"
with prism.open("rb") as f:
 actual=hashlib.file_digest(f,"sha256").hexdigest()
assert actual==json.loads((prism.parent/"archive-integrity.json").read_text(encoding="utf-8-sig"))["archiveSha256"]
base="artifacts/validation/afocal-recompare-20261026"
with zipfile.ZipFile(prism) as z:
 for label,prefix in {
  "prism-ray":base+"/expanded/0114-004-apochromat_prism-c1-primary-f1-w3-single-ray-trace/native",
  "prism-mtf":base+"/baseline-v4/analyses/0121-004-apochromat_prism-c1-primary-f0-w0-mtf/native",
 }.items():
  folder=r/"lens-supplement-controls"/label/"native"
  folder.mkdir(exist_ok=True)
  for file in ("data.json","data.txt","model.json","request.json","captured-settings.json"):
   (folder/file).write_bytes(z.read(f"{prefix}/{file}"))
 (r/"scoped-compare/prism-policy.json").write_bytes(z.read(base+"/baseline-v4/comparison-settings.json"))
with zipfile.ZipFile(prior/"2026-11-07/object-cone/numeric-controls.zip") as z:
 folder=r/"lens-supplement-controls/cone-huygens-psf-512/native"
 folder.mkdir(exist_ok=True)
 for file in ("data.json","captured-settings.json","result-diagnostics.json"):
  (folder/file).write_bytes(z.read("native/menu-huygens-psf-512/"+file))

