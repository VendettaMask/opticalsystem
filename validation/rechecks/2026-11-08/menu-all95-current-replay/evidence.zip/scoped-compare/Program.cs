using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var root = Path.GetFullPath(args[0]);
var repo = Directory.GetCurrentDirectory();
var conePolicy = ComparisonConfiguration.Load(Path.Combine(repo, "artifacts/zemax-sequential-corpus/20261021/full-v1/comparison-settings.json"));
var prismPolicy = ComparisonConfiguration.Load(Path.Combine(root, "scoped-compare/prism-policy.json"));
var prismSource = Path.Combine(repo, "src/OpticalSystemDesign.App/Assets/SequentialExamples/Miscellaneous/Apochromat_prism.zmx");
var receipts = new List<object>();
foreach (var name in new[] { "prism-ray", "prism-mtf", "cone-huygens-psf-512" })
{
    var folder = Path.Combine(root, "lens-supplement-controls", name);
    var wb = Path.Combine(folder, "data.json");
    var native = Path.Combine(folder, "native", "data.json");
    var request = JsonFiles.Read<WorkbenchJob>(Path.Combine(folder, "request.json")).Request;
    var entry = AnalysisComparisonRegistry.Get(request.CanonicalAnalysisKey);
    var run = new AnalysisRun { Key = entry.CanonicalAnalysisKey, Directory = folder, Request = request };
    int[]? sourceSurfaceNumbers = null;
    if (name == "prism-ray")
    {
        var models = JsonFiles.Read<JsonElement>(Path.Combine(root, "full/models.json"));
        sourceSurfaceNumbers = models[27].GetProperty("sourceSurfaceNumbers")[0].Deserialize<int[]>()!;
        var effective = request with { SurfaceCount = sourceSurfaceNumbers.Length };
        ComparisonRunner.Compare(run, entry, prismPolicy.Analyses[entry.CanonicalAnalysisKey],
            ResultNormalizer.Workbench(wb, entry, effective),
            ResultNormalizer.Zemax(native, entry, effective, wb, sourceSurfaceNumbers), folder);
    }
    else if (name.StartsWith("prism-"))
    {
        var original = prismPolicy.Analyses[entry.CanonicalAnalysisKey];
        var decoded = ScopedAfocalNormalizer.Read(wb, native, entry, request, original, new(0, 0, 0, 0, 1), prismSource);
        ComparisonRunner.Compare(run, entry, decoded.Settings, decoded.Actual, decoded.Expected, folder);
    }
    else
    {
        var settings = conePolicy.Analyses[entry.CanonicalAnalysisKey];
        ComparisonRunner.Compare(run, entry, settings, ResultNormalizer.Workbench(wb, entry, request),
            ResultNormalizer.Zemax(native, entry, request, wb), folder);
    }
    receipts.Add(new { name, run.Conclusion, run.Reason, run.Metrics, originalRequestFingerprint = request.Fingerprint,
        originalSurfaceCount = request.SurfaceCount, sourceSurfaceNumbers,
        workbenchSha256 = Hash(wb), nativeSha256 = Hash(native) });
    Console.WriteLine($"{name} {run.Conclusion}: {run.Reason}");
}
JsonFiles.Write(Path.Combine(root, "supplemental-native-comparisons.json"), receipts);

static string Hash(string path) => Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path)));



