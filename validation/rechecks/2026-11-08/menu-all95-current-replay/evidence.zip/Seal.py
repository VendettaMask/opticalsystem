import csv
import hashlib
import json
import pathlib
from zipfile import ZIP_DEFLATED, ZipFile

repo = pathlib.Path.cwd()
run = repo / "artifacts/validation/menu-all95-fixed-current-20261108"
report = repo / "validation/rechecks/2026-11-08/menu-all95-current-replay"

def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

summary = read(report / "summary.json")
with (report / "by-lens.csv").open(encoding="utf-8-sig", newline="") as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == 95 and sum(int(row["configurations"]) for row in rows) == 115
assert sum(int(row["requests"]) for row in rows) == 3024
assert sum(int(row["fixedExecuted"]) for row in rows) == 2904
assert [int(row["lensIndex"]) for row in rows if int(row["open"])] == summary["lensesWithOpenItems"]
columns = ("lensIndex", "lens", "configurations", "requests", "fixedExecuted", "acceptedDirect",
           "acceptedIndependently", "confirmedNotApplicable", "open", "additionalCurrentScopedControls")
headers = ("序号", "镜头", "配置", "请求", "原档执行", "直接通过", "专项数值通过", "不适用", "待处理", "补充复跑")
lines = [
    "# 全部 95 支镜头逐项汇总", "",
    "直接通过采用当前原档对冻结原生参考。专项数值通过依据对应收敛或等效参考，含本轮同版复验及明确标识的已验收档案。",
    "", "[验收范围和计数](README.md) · [3,024 条逐项记录](by-request.csv) · [镜头数据 CSV](by-lens.csv)",
    "", "| " + " | ".join(headers) + " |", "| " + " | ".join(["---:","---"] + ["---:"] * 8) + " |"
]
for row in rows:
    lines.append("| " + " | ".join(row[key].replace("|", r"\|") for key in columns) + " |")
(report / "BY_LENS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

members = {name: run / name for name in [
    "Prepare-Fixed.py", "Replay-Default.py", "Verify-Native.py", "Finish.py", "Seal.py", "reference-integrity.json", "Replay-Supplement.py",
    "Verify-Snapshots.py", "snapshot-integrity.json", "Reconcile-Default.py", "default-native-recomparison.json",
    "scoped-compare/Prepare.py", "scoped-compare/Scoped.csproj", "scoped-compare/Program.cs",
    "full/identity.json", "full/models.json", "full/request-mapping.json", "full/explicit-fixed-mode.json",
    "full/results.json", "full/summary.json", "full/lens-results.json", "full/compute-completed.json",
]}
members.update({name: report / name for name in ["by-request.csv", "by-lens.csv", "default-controls.json", "verdict-changes.csv", "lens-supplement-controls.json"]})
for index in (555, 2499):
    for name in ("request.json", "fixed-execution-request.json", "execution.json", "data.json", "provenance.json", "comparison.json"):
        path = run / "full/analyses" / f"{index:04d}" / name
        assert path.is_file(), path
        members[path.relative_to(run).as_posix()] = path
for control in read(run / "default-controls.json")["rows"]:
    directory = run / "default-controls" / f'{control["index"]:04d}'
    for name in ("request.json", "execution.json", "provenance.json", "initial-execution.json", "retry-execution.json"):
        path = directory / name
        if path.is_file():
            members[path.relative_to(run).as_posix()] = path
for control in read(report / "lens-supplement-controls.json")["rows"]:
    directory = run / "lens-supplement-controls" / control["case"]
    for name in ("request.json", "data.json", "provenance.json"):
        path = directory / name
        members[path.relative_to(run).as_posix()] = path
    if (directory / "native").is_dir():
        for path in (directory / "native").glob("*"):
            if path.is_file():
                members[path.relative_to(run).as_posix()] = path
manifest = {name: sha(path) for name, path in sorted(members.items())}
evidence = report / "evidence.zip"
with ZipFile(evidence, "w", compression=ZIP_DEFLATED) as archive:
    for name, path in sorted(members.items()):
        archive.write(path, name)
    archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with ZipFile(evidence) as archive:
    assert archive.testzip() is None
    for name, expected in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected
summary["evidenceArchive"] = {"sha256": sha(evidence), "entries": len(manifest) + 1, "contentsVerified": True}
(report / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(summary["evidenceArchive"])





