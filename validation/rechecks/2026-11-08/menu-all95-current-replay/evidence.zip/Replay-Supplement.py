import hashlib
import json
import pathlib
import subprocess
from zipfile import ZipFile

repo = pathlib.Path.cwd()
run = repo / "artifacts/validation/menu-all95-fixed-current-20261108"
prior = repo / "artifacts/validation/menu-427-incomparable-20261108"
worker = run / "bin/OpticalSystemDesign.ZemaxComparison.dll"
cone = repo / "validation/rechecks/2026-11-07/object-cone/numeric-controls.zip"
prism = repo / "validation/rechecks/2026-10-27/afocal-reference-focus/evidence.zip"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def replay(lens_index, name, job, prior_data, archived_provenance, authority):
    d = run / "lens-supplement-controls" / name
    d.mkdir(parents=True, exist_ok=True)
    snapshot = run / "full/models" / f"{lens_index:03d}-c1.optic.json"
    old_snapshot = archived_provenance["snapshotSha256"]
    current_snapshot = sha(snapshot.read_bytes())
    job["outputDirectory"] = str(d)
    job["snapshotPath"] = str(snapshot)
    path = d / "request.json"
    write(path, job)
    result = subprocess.run(["dotnet", str(worker), "--workbench-worker", str(path)], timeout=180,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    assert result.returncode == 0, (name, result.stdout.decode("utf-8", errors="replace"))
    actual = (d / "data.json").read_bytes()
    current = json.loads(actual)
    provenance = read(d / "provenance.json")
    assert provenance["requestFingerprint"] == archived_provenance["requestFingerprint"]
    assert provenance["snapshotSha256"] == current_snapshot
    row = {"lensIndex": lens_index, "case": name, "analysis": job["request"]["canonicalAnalysisKey"],
           "outcome": current["outcome"], "priorOutcome": json.loads(prior_data)["outcome"],
           "sameImportedSnapshotAsHistoricalControl": old_snapshot == current_snapshot,
           "priorSnapshotSha256": old_snapshot, "currentDataSha256": sha(actual),
           "previousDataSha256": sha(prior_data), "byteIdentical": actual == prior_data,
           "authority": authority, "provenance": provenance}
    print(name, row["outcome"], row["byteIdentical"], row["sameImportedSnapshotAsHistoricalControl"], flush=True)
    return row

results = []
for lens_index, index in [(2, 31), (19, 647), (76, 2329)]:
    source = prior / "afocal-meter/formal" / f"{index:04d}"
    results.append(replay(lens_index, f"canonical-{index:04d}", read(source / "request.json"),
                          (source / "data.json").read_bytes(), read(source / "provenance.json"),
                          "Authenticated afocal/meter scoped request, previous accepted data"))
with ZipFile(cone) as source:
    for name in ("first-order", "spot", "fft-psf-fixed-256", "huygens-psf-512"):
        folder = f"supplement/{name}"
        results.append(replay(35, f"cone-{name}", json.loads(source.read(f"{folder}/request.json")),
                              source.read(f"{folder}/data.json"), json.loads(source.read(f"{folder}/provenance.json")),
                              "OpticStudio 2026 R1 object cone supplemental archive"))
assert sha(prism.read_bytes()) == read(prism.parent / "archive-integrity.json")["sha256"]
with ZipFile(prism) as source:
    for label, target in [("ray","0114-004-apochromat_prism-"),("mtf","0121-004-apochromat_prism-")]:
        folder, = [path.removesuffix("/request.json") for path in source.namelist()
                   if target in path and path.endswith("/workbench/request.json")]
        results.append(replay(28, f"prism-{label}", json.loads(source.read(f"{folder}/request.json")),
                              source.read(f"{folder}/data.json"), json.loads(source.read(f"{folder}/provenance.json")),
                              "OpticStudio 2026 R1 afocal reference focus archive"))
write(run / "lens-supplement-controls.json", {"coneArchiveSha256": sha(cone.read_bytes()),
      "prismArchiveSha256": sha(prism.read_bytes()), "rows": results})
