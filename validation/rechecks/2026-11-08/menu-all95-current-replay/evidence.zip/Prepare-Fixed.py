import hashlib
import json
import pathlib
import shutil

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-all95-fixed-current-20261108/full"
baseline = repo / "artifacts/validation/focal-fft-domain-20261108/full"

def read(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

original_rows = root / "rows.json"
original_copy = root / "rows.original.json"
assert not original_copy.exists()
rows = read(original_rows)
prior = read(baseline / "rows.json")
models = read(root / "models.json")
assert len(models) == 95 and sum(len(m["snapshots"]) for m in models) == 115
assert len(rows) == len(prior) == 3024 and sum(bool(row["job"]) for row in rows) == 2904

for row, old in zip(rows, prior, strict=True):
    assert all(row[k] == old[k] for k in ("index", "lens", "configuration", "key", "scope", "settings"))
    assert bool(row["job"]) == bool(old["job"])
    if row["job"]:
        job = read(pathlib.Path(row["job"]))
        old_job = read(pathlib.Path(old["job"]))
        assert job["request"] == old_job["request"]
        assert digest(pathlib.Path(job["snapshotPath"])) == digest(pathlib.Path(old_job["snapshotPath"]))

shutil.copyfile(original_rows, original_copy)
fixed = []
for row in rows:
    if not row["job"] or row["key"] not in {"PSF", "MTF", "FFT PSF Cross Section"}:
        continue
    original = pathlib.Path(row["job"])
    translated = original.with_name("fixed-execution-request.json")
    job = read(original)
    settings = job["request"]["workbenchSettings"]
    assert "FourierSamplingMode" not in settings
    settings["FourierSamplingMode"] = "Fixed"
    translated.write_text(json.dumps(job, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    row["job"] = str(translated)
    fixed.append({"index": row["index"], "originalRequestSha256": digest(original),
                  "fixedExecutionRequestSha256": digest(translated)})

original_rows.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
(root / "explicit-fixed-mode.json").write_text(json.dumps(fixed, indent=2) + "\n", encoding="utf-8")
print(f"Verified 95 lenses, 115 configurations, {len(rows)} requests, 2904 executable, {len(fixed)} explicit fixed mode.")
