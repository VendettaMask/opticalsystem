import hashlib
import json
import pathlib
from zipfile import ZipFile

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-all95-fixed-current-20261108"
extracted = repo / "artifacts/zemax-sequential-corpus/20261021/full-v1"
archive = repo / "validation/repairs/2026-10-21/sequential-corpus-full-evidence.zip"
prior = repo / "artifacts/validation/focal-fft-domain-20261108/full/reference-integrity.json"

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

scope = json.loads(prior.read_text(encoding="utf-8-sig"))
archive_hash = digest(archive)
assert archive_hash == scope["archiveSha256"]
with ZipFile(archive) as frozen:
    manifest = {row["path"]: row for row in json.loads(frozen.read("payload-manifest.json"))}
rows = json.loads((root / "full/rows.original.json").read_text(encoding="utf-8-sig"))
comparison_members = {"run/comparison-settings.json", "run/items.json", "run/analysis-results.json"}
for row in rows:
    if not row["job"]:
        continue
    folder = pathlib.Path(row["legacyPath"]) / "native"
    for name in ("batch-result.json", "data.json", "error.json", "captured-settings.json", "result-diagnostics.json"):
        path = folder / name
        if path.is_file():
            comparison_members.add("run/" + path.relative_to(extracted).as_posix())
paths = {item["path"] for item in scope["files"]} | comparison_members
for name in sorted(paths):
    path = extracted / name.removeprefix("run/")
    expected = manifest[name]
    assert path.stat().st_size == expected["bytes"] and digest(path) == expected["sha256"], name
record = {"archiveSha256": archive_hash, "filesVerified": len(paths), "comparisonFilesVerified": len(comparison_members),
          "allMatched": True, "pathScopeSha256": hashlib.sha256("\n".join(sorted(paths)).encode()).hexdigest()}
(root / "reference-integrity.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(record)
