import json, pathlib, shutil, subprocess
repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/focal-fft-default-recovery-20261108"
previous = repo / "artifacts/validation/focal-fft-domain-20261108/full"
rows = json.loads((previous / "rows.json").read_text(encoding="utf-8-sig"))
scope = root / "frozen-native-compare"
(scope / "analyses").mkdir(parents=True, exist_ok=True)
for name in ("identity.json", "models.json"):
    shutil.copyfile(previous / name, scope / name)
selected = []
for row in rows:
    folder = root / "formal" / f'{row["index"]:04d}'
    if not (folder / "execution.json").exists():
        continue
    row["job"] = str(folder / "request.json")
    selected.append(row)
    output = scope / "analyses" / folder.name
    output.mkdir(exist_ok=True)
    for name in ("data.json", "execution.json"):
        shutil.copyfile(folder / name, output / name)
assert len(selected) == 20
(scope / "rows.json").write_text(json.dumps(selected, ensure_ascii=False), encoding="utf-8")
cli = previous.parent / "bin-domain/ExampleAccuracy20261031.dll"
subprocess.run(["dotnet", str(cli), "compare", str(repo), str(scope)], check=True)

