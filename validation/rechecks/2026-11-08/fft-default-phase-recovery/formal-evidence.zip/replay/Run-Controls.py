import hashlib,json,pathlib,subprocess,concurrent.futures
repo=pathlib.Path.cwd()
root=repo/"artifacts/validation/focal-fft-default-recovery-20261108"
previous=repo/"artifacts/validation/focal-fft-domain-20261108/full/analyses"
previous_archive=repo/"artifacts/validation/precision-physical-fourier-20261108/full/analyses"
worker=repo/"tools/OpticalSystemDesign.ZemaxComparison/bin/Release/net10.0/OpticalSystemDesign.ZemaxComparison.dll"
cases=(9,101,103,105,339,361,945,946,949,1365,1367,2205,2547)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def difference(before, after):
    if isinstance(before, dict) and isinstance(after, dict):
        assert before.keys() == after.keys()
        return max((difference(before[k], after[k]) for k in before), default=0)
    if isinstance(before, list) and isinstance(after, list):
        assert len(before) == len(after)
        return max((difference(a, b) for a, b in zip(before, after, strict=True)), default=0)
    if type(before) in (int, float) and type(after) in (int, float):
        return abs(before-after)
    assert before == after, (before, after)
    return 0

def run(index):
    identifier=f"{index:04d}"
    before=previous/identifier/"data.json"
    if not before.exists():
        before=previous_archive/identifier/"data.json"
    source=json.loads((previous/identifier/"request.json").read_text(encoding="utf-8-sig"))
    folder=root/"controls"/identifier
    folder.mkdir(parents=True, exist_ok=True)
    source["outputDirectory"]=str(folder)
    job=folder/"request.json"
    job.write_text(json.dumps(source,ensure_ascii=False),encoding="utf-8")
    subprocess.run(["dotnet",str(worker),"--workbench-worker",str(job)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
    new=folder/"data.json"
    load = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
    prior_data, current_data = load(before), load(new)
    assert "RequestedPupilPhaseSampling" not in current_data["values"]
    error = difference(prior_data,current_data)
    assert error <= 1e-12,(index,error)
    return {"index":index,"analysis":source["request"]["canonicalAnalysisKey"],
            "outcome":current_data["outcome"], "priorSha256":sha(before),"actualSha256":sha(new),
            "byteIdentical":sha(before)==sha(new), "maximumAbsoluteNumericChange":error}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    result=list(pool.map(run,cases))
(root/"controls.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(f"{len(result)} controls, {sum(r['byteIdentical'] for r in result)} byte-identical, max numeric delta {max(r['maximumAbsoluteNumericChange'] for r in result)}")

