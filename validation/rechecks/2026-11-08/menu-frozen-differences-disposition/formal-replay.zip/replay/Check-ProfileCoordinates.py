import hashlib,json,math,pathlib,re
from zipfile import ZipFile
repo=pathlib.Path.cwd()
run=repo/"artifacts/validation/menu-31-differences-20261108"
reports=repo/"validation/rechecks"
policy=json.loads((repo/"artifacts/zemax-sequential-corpus/20261021/full-v1/comparison-settings.json").read_text(encoding="utf-8-sig"))
gate=policy["analyses"]["Huygens PSF Cross Section"]["quantities"]["Irradiance"]
cases=[
 (448,run/"diffraction/current/448-1024/data.json",reports/"2026-11-07/huygens-image-local-pupil/native-controls.zip","native/448-n1024/data.txt"),
 (2162,run/"diffraction/current/2162-1024/data.json",reports/"2026-11-02/huygens-common/evidence.zip","payloads/b06c60f5322307e31c37ea84a06ca20f5bf200f04537b80f84666fef4c274c5e"),
 (500,run/"formal/0500/data.json",reports/"2026-11-06/grid-grin-diffraction-reference/native-controls.zip","refinement/captures/500-step0.00025/data.txt"),
]
records=[]
for i,formal,archive,entry in cases:
 w=json.loads(formal.read_text(encoding="utf-8-sig"))["plotSeries"][0]
 assert w["xUnit"]=="Micrometer"
 with ZipFile(archive) as z:
  raw=z.read(entry)
 enc="utf-16" if raw.startswith((b"\xff\xfe",b"\xfe\xff")) else "gb18030"
 text=raw.decode(enc,errors="replace")
 vals=[(float(a),float(b)) for a,b in re.findall(r"^\s*\d+[ \t]+([-+0-9.Ee]+)[ \t]+([-+0-9.Ee]+)[ \t\r]*$",text,flags=re.MULTILINE)]
 native=dict(vals)
 assert len(native)==len(vals)
 pairs=[(p["x"],p["y"],native[p["x"]]) for p in w["points"]]
 error=[abs(a-b) for _,a,b in pairs]
 pointwise=all(e<=gate["absolute"]+gate["relative"]*abs(b) for e,(_,_,b) in zip(error,pairs))
 rms=math.sqrt(sum(e*e for e in error)/len(error))
 nrmse=rms/max(max(abs(b) for _,_,b in pairs),gate["absolute"])
 assert pointwise or nrmse<=gate["nrmse"]
 extra=[x for x in native if x not in {p["x"] for p in w["points"]}]
 records.append({"index":i,"outcome":"Pass","workbenchPoints":len(pairs),"nativeReportedPoints":len(native),"nativePrintedAdditionalMicrometers":extra,
                 "maxAbsolute":max(error),"nrmse":nrmse,"pointwisePass":pointwise,"nativeMemberSha256":hashlib.sha256(raw).hexdigest(),
                 "archive":str(archive.relative_to(reports)),"entry":entry,"gate":gate})
(run/"profile-physical-coverage.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8")
print(json.dumps(records,indent=2))

