import collections,csv,hashlib,json,pathlib
from zipfile import ZipFile,ZIP_DEFLATED

repo=pathlib.Path.cwd()
root=repo/"artifacts/validation/menu-31-differences-20261108"
reports=repo/"validation/rechecks/2026-11-08"
baseline=reports/"parallel-focal-fft-applicability"
report=reports/"menu-frozen-differences-disposition"
report.mkdir(exist_ok=True)

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def dump(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()

def table(path):
    with path.open(newline="",encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))

def put_table(path,rows):
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def keyed(rows):
    if isinstance(rows,dict):
        rows=list(rows.values())
    return {int(r["index"]):r for r in rows}

historic=load(baseline/"summary.json")
assert sha(baseline/"frozen-replay.csv")==historic["frozenReplaySha256"]
matrix=table(baseline/"frozen-replay.csv")
scope={int(r["index"]):r for r in matrix if r["conclusion"]=="Difference"}
assert len(matrix)==3024 and len(scope)==31
formal=keyed(load(root/"original-replay.json"))
frozen_comparison=keyed(load(root/"frozen-compare/results.json"))
assert set(formal)==set(frozen_comparison)==set(scope)
assert all(r["conclusion"]=="Difference" for r in frozen_comparison.values())
groups={}
for name,filename in (("grin","grid-grin-verification.json"),("definitions","equivalent-definitions-verification.json"),
                      ("diffraction","dense-diffraction-verification.json")):
    path=root/name/"receipt.json"
    groups[name]=keyed(load(path)["rows"])
    (report/filename).write_bytes(path.read_bytes())
grin,defs,diff=(groups[g] for g in ("grin","definitions","diffraction"))
assert [len(group) for group in (grin,defs,diff)]==[15,7,9]
assert (set(grin)|set(defs)|set(diff))==set(scope)
assert all(r["independentOutcome"]=="SupplementalPass" for r in grin.values())
assert all(r["equivalentVerdict"]=="Pass" for r in defs.values())
def success(row):
    for key in ("numericVerdict","independentOutcome","verdict","state","outcome","currentVerdict","conclusion"):
        if key in row:
            return row[key] in ("Pass","SupplementalPass")
    raise ValueError(list(row))
assert all(success(row) for row in diff.values())
assert {i for i,r in grin.items() if r.get("arc")}=={490,507,511,515}
assert all(r["arc"]["byExtrapolation"]["conclusion"]=="Pass" for r in grin.values() if r.get("arc"))
coverage=keyed(load(root/"profile-physical-coverage.json"))
assert set(coverage)=={448,500,2162} and all(r["workbenchPoints"]==32 and r["pointwisePass"] for r in coverage.values())

labels={"grin":("NativeRefinedGridIntegration","grid-grin-verification.json"),
        "definitions":("IndependentEquivalentDefinition","equivalent-definitions-verification.json"),
        "diffraction":("ConvergedPupilSampling","dense-diffraction-verification.json")}
results=[]
assemblies=set()
archive=report/"formal-replay.zip"
with ZipFile(archive,"w",compression=ZIP_DEFLATED,compresslevel=9) as evidence:
    for index,item in sorted(formal.items()):
        historic_row=scope[index]
        assert item["requestFingerprint"]==historic_row["requestFingerprint"]==frozen_comparison[index]["requestFingerprint"]
        assemblies.add(item["codeFingerprint"])
        group=next(g for g,rows in groups.items() if index in rows)
        ref=groups[group][index]
        if group=="grin":
            assert item["dataSha256"]==ref["formalDataSha256"] and item["requestFingerprint"]==ref["requestFingerprint"]
        if group=="definitions":
            assert item["dataSha256"]==ref["formalData"]["sha256"] and item["requestFingerprint"]==ref["formalProvenance"]["requestFingerprint"]
        if group=="diffraction":
            assert item["dataSha256"]==ref["originalReplay"]["coreDataSha256"] and item["requestFingerprint"]==ref["requestFingerprint"]
            assert len(ref["currentReferences"])==2
            for tier in ref["currentReferences"]:
                high_dir=root/"diffraction/current"/f"{index}-{tier['pupilSampling']}"
                assert tier["outcome"]=="Success" and sha(high_dir/"data.json")==tier["dataSha256"]
                assert tier["provenance"]["codeFingerprint"]==item["codeFingerprint"]
                assert tier["snapshotSha256"]==item["snapshotSha256"]
        case=f"{index:04d}"
        folder=root/"formal"/case
        assert sha(folder/"data.json")==item["dataSha256"]
        for name in ("request.json","data.json","provenance.json","execution.json"):
            evidence.write(folder/name,f"formal/{case}/{name}")
        reference,receipt=labels[group]
        if index in {490,507,511,515}:
            reference="NativeRefinedRaysAndIndependentArc"
        if index==950:
            reference="CheckedRadialHuygensAndIndependentNativeIntegral"
        results.append({"index":index,"lensIndex":int(historic_row["lensIndex"]),"lens":item["lens"],"configuration":item["configuration"],
                        "analysis":item["analysis"],"frozenVerdict":"Difference","currentDirectFrozenComparison":"Difference",
                        "currentIndependentAcceptance":"Pass","referenceContract":reference,"receipt":receipt,
                        "requestFingerprint":item["requestFingerprint"],"snapshotSha256":item["snapshotSha256"],
                        "originalWorkbenchDataSha256":item["dataSha256"],"originalWorkbenchByteIdentical":item["workbenchPayloadByteIdentical"],
                        "extraNativePrintedEndpointMicrometers":4 if index in coverage else None})
    for folder in sorted((root/"diffraction/current").iterdir()):
        if not folder.is_dir():
            continue
        for name in ("request.json","data.json","provenance.json","execution.json"):
            file=folder/name
            if file.is_file():
                evidence.write(file,f"diffraction/{folder.name}/{name}")
    for name in ("request.json","data.json","provenance.json"):
        evidence.write(root/"definitions/0950-checked"/name,f"definitions/0950-checked/{name}")
    for name in ("Run-Original.py","Compare-Original.py","Check-ProfileCoordinates.py","seal.py",
                 "grin/Program.cs","grin/CompareGrin.csproj","definitions/Verify-Definitions.py",
                 "diffraction/Run-High.py","diffraction/Prepare-Compare.py","diffraction/compare/Program.cs","diffraction/compare/Compare.csproj"):
        file=root/name
        if file.is_file():
            evidence.write(file,"replay/"+name)
    for name in ("original-replay.json","frozen-compare/results.json"):
        evidence.write(root/name,"frozen/"+pathlib.Path(name).name)
assert len(assemblies)==1
application,core=next(iter(assemblies)).split(":")
assert core==historic["coreSha256"]
put_table(report/"by-request.csv",results)
by_lens=table(baseline/"by-lens.csv")
lens_counts=collections.Counter(r["lensIndex"] for r in results)
assert len(by_lens)==95
for row in by_lens:
    row["differenceScopeReplayed"]=lens_counts[int(row["index"])]
    row["differenceScopeIndependentPass"]=lens_counts[int(row["index"])]
assert sum(int(r["Difference"]) for r in by_lens)==sum(lens_counts.values())==31
put_table(report/"by-lens.csv",by_lens)
(report/"original-replay.json").write_bytes((root/"original-replay.json").read_bytes())
(report/"frozen-comparison.json").write_bytes((root/"frozen-compare/results.json").read_bytes())
(report/"profile-physical-coverage.json").write_bytes((root/"profile-physical-coverage.json").read_bytes())
summary={"menuLenses":95,"menuConfigurations":historic["configurations"],"frozenRequests":len(matrix),
         "frozenCounts":historic["frozen"],"differenceScopeLenses":len(lens_counts),"differenceScopeReplayed":len(results),
         "currentFrozenDirectDifference":31,"independentAcceptance":{"Pass":31,"Close":0,"Difference":0,"Error":0},
         "referenceGroups":{name:len(rows) for name,rows in groups.items()},"originalFrozenNativeFilesVerified":sum(len(r["frozenNativeFiles"]) for r in formal.values()),
         "originalOutputByteIdenticalWithPrior":sum(r["workbenchPayloadByteIdentical"] for r in formal.values()),
         "originalOutputRoundoffIndex":608,"originalOutputMaxRoundoff":1.732238796847696e-10,
         "grinRayTraceArcSeparate":[490,507,511,515],"nativePrintedExtraProfileEndpoint":[448,500,2162],
         "applicationSha256":application,"coreSha256":core,"frozenNativeArchiveSha256":historic["nativeReference"]["archiveSha256"],
         "policySha256":historic["policySha256"],"frozenMatrixSha256":historic["frozenReplaySha256"],
         "reportFileHashes":{file.name:sha(file) for file in sorted(report.iterdir()) if file.is_file() and file.suffix in (".zip",".csv",".json") and file.name!="summary.json"}}
dump(report/"summary.json",summary)
print(json.dumps(summary,indent=2))

