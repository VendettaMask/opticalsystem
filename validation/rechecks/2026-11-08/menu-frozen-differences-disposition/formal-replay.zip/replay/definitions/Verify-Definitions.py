import csv
import hashlib
import json
import math
from pathlib import Path
import re
from zipfile import ZipFile

import numpy as np


repo = Path.cwd()
root = Path(__file__).resolve().parent
base = root.parent
evidence = repo/'validation/rechecks'
corpus = repo/'artifacts/zemax-sequential-corpus/20261021/full-v1'
indices = (125, 608, 698, 847, 950, 2216, 2220)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return {'path': str(path.relative_to(repo)), 'sha256': sha(path.read_bytes())}


def member(archive, path):
    with ZipFile(archive) as z:
        raw = z.read(path)
    return raw, {'archive': str(archive.relative_to(repo)), 'member': path, 'sha256': sha(raw)}


def decoded(raw):
    return raw.decode('utf-16' if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig')


def scalar(val, ref, gate):
    return measures([val], [ref], gate)


def measures(work, native, gate):
    work, native = np.asarray(work, float), np.asarray(native, float)
    assert work.shape == native.shape and work.size
    m = np.isfinite(work)
    assert np.array_equal(m, np.isfinite(native)) and m.any()
    diff = abs(work[m]-native[m])
    denom = max(np.max(abs(native[m])), gate['absolute'])
    nrmse = float(np.sqrt(np.mean(diff*diff))/denom)
    pointwise = bool(np.all(diff <= gate['absolute']+gate['relative']*abs(native[m])))
    pass_nrmse = work.size > 1 and nrmse <= gate['nrmse']
    verdict = 'Pass' if pointwise or pass_nrmse else 'Close' if nrmse <= gate['closeNrmse'] else 'Difference'
    return {'verdict': verdict, 'coverage': 1, 'coordinates': int(work.size), 'finitePairs': int(m.sum()),
            'maxAbsolute': float(diff.max()), 'nrmse': nrmse, 'pointwisePass': pointwise, 'nrmsePass': pass_nrmse}


def curve(series, nx, ny, gate, x_quantity='PupilCoordinate', x_unit='Dimensionless', y_unit='Wave'):
    assert (series['xQuantity'], series['xUnit'], series['yUnit']) == (x_quantity, x_unit, y_unit)
    w = np.array([[v['x'], v['y']] for v in series['points']], float)
    assert w.shape[0] == len(nx) and np.allclose(w[:, 0], nx, rtol=0, atol=1e-12)
    return measures(w[:, 1], ny, gate)


def native_fans(data, native, gate):
    panes = data['plotPanes']
    assert len(panes) == len(native['dataSeries']) == 2 and not native['messages']
    output = {}
    for axis, pane, reference in zip(('tangential', 'sagittal'), panes, native['dataSeries']):
        series, = pane['series']
        assert series['xAxisLabel'] == ('P_y' if axis == 'tangential' else 'P_x')
        assert reference['description'].startswith('子午' if axis == 'tangential' else '弧矢')
        output[axis] = curve(series, reference['x'], [v[0] for v in reference['y']], gate)
    return output


cohort = {row['index']: row for row in read(base/'cohort.json')}
frozen = evidence/'2026-11-08/parallel-focal-fft-applicability/frozen-replay.csv'
assert sha(frozen.read_bytes()) == read(frozen.with_name('summary.json'))['frozenReplaySha256']
with frozen.open(encoding='utf-8-sig', newline='') as f:
    original = {int(row['index']): row for row in csv.DictReader(f) if int(row['index']) in indices}


def setup(index):
    row = cohort[index]
    folder = base/'formal'/f'{index:04}'
    original_path = Path(row['job'])
    request = read(folder/'request.json')
    origin = read(original_path)
    assert dict(request, outputDirectory=origin['outputDirectory']) == origin
    provenance = read(folder/'provenance.json')
    assert provenance['requestFingerprint'] == original[index]['requestFingerprint']
    assert provenance['executorId'] == 'Application.WorkbenchRuntime.BuildAnalysisData/v1'
    assert provenance['snapshotSha256'] == sha(Path(origin['snapshotPath']).read_bytes())
    execution = read(folder/'execution.json')
    assert execution['exitCode'] == 0 and execution['originalRequestSha256'] == sha(original_path.read_bytes())
    result = read(folder/'data.json')
    assert result['outcome'] == 'Success' and original[index]['conclusion'] == 'Difference'
    native, = (corpus/'analyses').glob(f'{index:04}-*')
    source = corpus/'sources'/row['lens']
    receipt = {'index': index, 'lens': row['lens'], 'analysis': row['key'], 'frozenVerdict': 'Difference',
               'configuration': row['configuration'], 'formalOutcome': result['outcome'], 'formalProvenance': provenance,
               'workerSha256': execution['workerSha256'], 'originalRequest': identity(original_path),
               'formalData': identity(folder/'data.json'), 'nativeSource': identity(source),
               'frozenNativeData': identity(native/'native/data.json'),
               'originalPolicy': row['settings']['quantities'], 'references': []}
    return result, request, native/'native', source, receipt


curvature = evidence/'2026-11-07/curvature-image-space-reference/native-controls.zip'
interconnect = evidence/'2026-11-07/optical-interconnect-reference'
axicon = evidence/'2026-11-08/axicon-continuum'
etalon_path = evidence/'2026-11-08/wavefront-directional-f-number/verification.json'
etalon = {row['index']: row for row in read(etalon_path)['etalon']}
assert sha(curvature.read_bytes()) == read(etalon_path)['etalonEvidenceArchiveSha256']
rows = {}


for i in indices:
    data, req, native, source, out = setup(i)
    gates = out['originalPolicy']
    values = data['values']
    rows[str(i)] = out

    if i == 125:
        raw, receipt = member(curvature, 'native/125-ordinary-index/data.json')
        out['references'].append(receipt)
        ref = json.loads(raw)
        raw, receipt = member(curvature, 'native/125-ordinary-index/captured-settings.json')
        out['references'].append(receipt)
        options = json.loads(raw)['request']
        assert options['reference'] == values['FirstOrderReferenceConvention'] == 'CenteredVertexOrdinaryIndexV1'
        assert {k: options[k] for k in req['request']} == dict(req['request'], reference=options['reference'])
        assert ref['firstOrderReference']['surfaces'] == [{'surface': 2, 'originalParaxIgnore': 0, 'actualParaxIgnore': 1}]
        assert not ref['firstOrderReference']['realRayModeChanged'] and not ref['messages']
        assert ref['operands']['EFFL']/ref['operands']['EPDI'] == ref['scalars']['FNumber']
        out['modeSpecificEquivalence'] = 'Ordinary-index centered vertex convention with native paraxial Ignore surface 2 only, real ray mode unchanged'
        out['workbench'] = {key: values[key] for key in gates}
        out['frozenNative'] = read(native/'data.json')['scalars']
        out['frozenNativeMetrics'] = {key: scalar(values[key], out['frozenNative'][key], gate) for key, gate in gates.items()}
        out['equivalentNative'] = ref['scalars']
        out['equivalentMetrics'] = {key: scalar(values[key], ref['scalars'][key], gate) for key, gate in gates.items()}
        assert all(x['verdict'] == 'Pass' for x in out['equivalentMetrics'].values())
    elif i in (608, 698):
        gate = gates['WavefrontError']
        original_source = decoded(source.read_bytes()).splitlines()
        controls = {}
        for mode in (0, 3):
            raw, receipt = member(curvature, f'controls/{i}-mode{mode}.zmx')
            out['references'].append(receipt)
            controlled = decoded(raw).splitlines()
            assert len(controlled) == len(original_source)
            assert [(a.strip(), b.strip()) for a, b in zip(original_source, controlled) if a != b] == [
                ('PARM 2 1', f'PARM 2 {mode}')]
            raw, receipt = member(curvature, f'native/{i}-mode{mode}/captured-settings.json')
            out['references'].append(receipt)
            settings = json.loads(raw)
            assert req['request'] == {k: settings['request'][k] for k in req['request']}
            assert settings['selectors'] == {'Field': 3, 'Surface': 0, 'Wavelength': 3}
            raw, receipt = member(curvature, f'native/{i}-mode{mode}/data.json')
            out['references'].append(receipt)
            controls[str(mode)] = json.loads(raw)
        assert controls['0']['dataSeries'] == controls['3']['dataSeries']
        prior_dir = evidence/'2026-11-04/offaxis-opd-sampling'
        control_identity = prior_dir/'equivalent-source-controls.json'
        original_sha = out['nativeSource']['sha256']
        geometry_checks = [ref for ref in read(control_identity) if ref['originalSourceSha256'] == original_sha]
        assert geometry_checks and all(ref['maximumPositionDirectionDifference'] == 0 and ref['positionDirectionOperands'] == 540
                                       and ref['onlyPhaseAlgorithmFlagChanged'] for ref in geometry_checks)
        out['references'].extend([identity(control_identity), identity(prior_dir/'plane-controls.json')])
        out['priorIndependentPlaneGeometryControls'] = geometry_checks
        out['modeSpecificEquivalence'] = 'PerfectCollimationPhaseReference/v1 for this exact conjugate. Only the first PARAXIAL surface phase algorithm changes in the independent native controls.'
        out['frozenNativeMetrics'] = native_fans(data, read(native/'data.json'), gate)
        out['equivalentMetrics'] = {k: native_fans(data, control, gate) for k, control in controls.items()}
        assert all(x['verdict'] == 'Pass' for result in out['equivalentMetrics'].values() for x in result.values())
    elif i == 847:
        archived = read(interconnect/'first-order.json')
        out['references'].append(identity(interconnect/'first-order.json'))
        references = {}
        for tier, summary in archived['originalNearAxisControls'].items():
            raw, receipt = member(interconnect/'native-controls.zip', f'native-first-order/original-rays-{tier}/model-controls.json')
            out['references'].append(receipt)
            points = {(r['input']['code'], r['input']['int1'], r['input']['data2']):r['value'] for r in json.loads(raw)['rows']}
            pair = []
            for p in summary['points']:
                h, v = points['REAY', 2, p['hy']], points['REAB', 6, p['hy']]
                assert h == p['entranceHeightMm'] and v == p['outputDirectionCosine'] and h/v == p['focalLengthMm']
                pair.append((h*h, h/v))
            (a, y_a), (b, y_b) = pair[:2]
            reference = (b*y_a-a*y_b)/(b-a)
            assert abs(reference-summary['extrapolatedFocalLengthMm']) < 1e-13
            references[tier] = reference
        raw, receipt = member(interconnect/'native-controls.zip', 'native-first-order/collimated-0.002/model-controls.json')
        out['references'].append(receipt)
        rows2 = json.loads(raw)['rows']
        def collimated(code, surface):
            value, = [r['value'] for r in rows2 if r['input']['code'] == code and r['input']['int1'] == surface
                      and r['input']['data1'] == r['input']['data2'] == r['input']['data3'] == 0 and r['input']['data4'] == .001]
            return value
        independent = archived['collimatedControls']['0.002']['independentFocalLengthMmByNormalizedPupil']['0.001']
        assert abs(abs(collimated('REAY', 2)/collimated('REAB', 6))-independent) < 1e-12
        references['collimatedSmallestProbe'] = independent
        prescription = decoded(source.read_bytes())
        numerical_aperture = float(re.search(r'(?m)^OBNA\s+(\S+)', prescription)[1])
        distance = float(re.search(r'(?ms)^SURF 0\s*$.*?^\s*DISZ\s+(\S+)', prescription)[1])
        diameter = 2*distance*numerical_aperture/math.sqrt(1-numerical_aperture**2)
        raw_native = read(native/'data.json')
        assert abs(diameter-raw_native['operands']['EPDI']) < 1e-8 and abs(diameter-values['EffectiveFocalLength']/values['FNumber']) < 1e-8
        out['modeSpecificEquivalence'] = 'Two original-prescription near-axis real-ray focal length limits; F-number is that limit divided by the entrance-pupil diameter derived from original object aperture. Collimated net-zero-air removal is an additional altered-prescription control.'
        out['independentEntrancePupilDiameterMm'] = diameter
        out['frozenNative'] = raw_native['scalars']
        out['frozenNativeMetrics'] = {key: scalar(values[key], raw_native['scalars'][key], gate) for key, gate in gates.items()}
        out['workbench'] = {key: values[key] for key in gates}
        out['equivalentMetrics'] = {name: {'referenceEflMm': v, 'referenceFNumber': v/diameter,
            'EffectiveFocalLength': scalar(values['EffectiveFocalLength'], v, gates['EffectiveFocalLength']),
            'FNumber': scalar(values['FNumber'], v/diameter, gates['FNumber'])} for name, v in references.items()}
        assert all(m[key]['verdict'] == 'Pass' for m in out['equivalentMetrics'].values() for key in gates)
    elif i == 950:
        gate = gates['Irradiance']
        native_path = axicon/'native-results.json'
        verification = read(axicon/'verification.json')
        assert verification['continuumChecksPass']
        out['references'].extend([identity(native_path), identity(axicon/'verification.json'), identity(axicon/'identity.json')])
        identity_axicon = read(axicon/'identity.json')
        assert identity_axicon['snapshotSha256'] == out['formalProvenance']['snapshotSha256']
        assert identity_axicon['sourceLensSha256'] == out['nativeSource']['sha256']
        capsule = identity(repo/identity_axicon['nativeRayPhaseLocalPath'])
        assert capsule['sha256'] == identity_axicon['nativeRayPhaseSha256']
        out['references'].append(capsule)
        native_tiers = [next(p['line'] for p in j['results'] if p['focus'] == 0) for j in read(native_path)]
        nx = verification['sectionXMicrometers']
        assert nx == [v/4 for v in range(-16, 16)]
        adjusted = root/'0950-checked'
        refined = read(adjusted/'request.json')
        options = refined['request']['workbenchSettings'].copy()
        assert options.pop('UseCheckedFocusedPupil') == 'True'
        assert dict(refined['request'], workbenchSettings=options) == req['request']
        assert refined['snapshotPath'] == req['snapshotPath']
        result = read(adjusted/'data.json')
        provenance = read(adjusted/'provenance.json')
        assert provenance['codeFingerprint'] == out['formalProvenance']['codeFingerprint']
        assert result['outcome'] == 'Success' and result['values']['SamplingStatus'] == 'SamplingStable'
        assert result['values']['PropagationModel'] == 'Checked radial planar Huygens'
        sampling = result['values']['FocusedHuygensSampling']
        assert sampling['coarseNodes'] < sampling['fineNodes'] and sampling['maximumPhaseStepWaves'] < .5
        series, = result['plotSeries']
        fixed, = data['plotSeries']
        def line(series, ordinate):
            return curve(series, nx, ordinate, gate, 'ImageHeight', 'Micrometer', 'Dimensionless')
        out['modeSpecificEquivalence'] = 'Same original window, pitch, scalar propagation scope and ideal normalization. Validated continuum mode is an explicit opt-in and distinct from the original fixed 32-node rule.'
        out['checkedFormalData'] = identity(adjusted/'data.json')
        out['checkedRequest'] = identity(adjusted/'request.json')
        out['checkedProvenance'] = provenance
        out['checkedSampling'] = sampling
        out['fixedVersusContinuum'] = line(fixed, native_tiers[-1])
        out['equivalentMetrics'] = {'checkedVersusIndependentContinuum': line(series, native_tiers[-1]),
                                    'independentContinuumTiers': measures(native_tiers[0], native_tiers[1], gate)}
        out['relativeToIndependentPeakMaxDifference'] = out['equivalentMetrics']['checkedVersusIndependentContinuum']['maxAbsolute']/max(native_tiers[-1])
        out['originalNativeText'] = identity(native/'data.txt')
        text = decoded((native/'data.txt').read_bytes())
        reference_points = re.findall(r'(?m)^\s*([0-9]+)\t\s*([-0-9.]+)\t\s*([-0-9.]+)\s*$', text)
        assert [int(k) for k, _, _ in reference_points] == list(range(33))
        assert [float(x) for _, x, _ in reference_points] == [*nx, 4]
        measured = line(fixed, [float(y) for _, _, y in reference_points[:-1]])
        measured['coverage'] = (nx[-1]-nx[0])/(4-nx[0])
        assert measured['coverage'] >= gate['minimumCoverage'] and measured['verdict'] == 'Difference'
        out['frozenNativeMetrics'] = measured
        out['frozenNativeTextCoordinates'] = 33
        assert out['fixedVersusContinuum']['verdict'] == 'Difference' and all(m['verdict'] == 'Pass' for m in out['equivalentMetrics'].values())
    else:
        gate = gates['WavefrontError']
        ref = etalon[i]
        assert ref['request'] == out['formalProvenance']['requestFingerprint'] and ref['passesEveryTestedSurrogate']
        out['references'].append(identity(etalon_path))
        ray_controls = []
        for control_name in (f'{i}-absolute-rays', f'{i}-rays'):
            raw, receipt = member(curvature, f'native/{control_name}/point-reference.json')
            out['references'].append(receipt)
            ray_controls.append(json.loads(raw))
        absolute, focal = ray_controls
        raw, receipt = member(curvature, 'controls/etalon-absolute.zmx')
        out['references'].append(receipt)
        assert absolute['inputSha256'] == sha(raw) and focal['inputSha256'] == out['nativeSource']['sha256']
        assert [(a.strip(), b.strip()) for a, b in zip(decoded(source.read_bytes()).splitlines(), decoded(raw).splitlines()) if a != b] == [('ROPD 2', 'ROPD 0')]
        assert absolute['inputs'] == focal['inputs'] and len(focal['inputs']) == 82
        assert absolute['opdMode'] == focal['opdMode'] == 'CurrentAndChief'
        assert absolute['wavelength'] == focal['wavelength'] == req['request']['wavelength']
        abs_rays, focal_rays = absolute['surfaces'][-1]['rays'], focal['surfaces'][-1]['rays']
        chief_idx = next(k for k, p in enumerate(focal['inputs']) if p['px'] == p['py'] == 0)
        chief_ray = focal_rays[chief_idx]
        reconstructed = []
        for coords, ray, abs_ray, stored in zip(focal['inputs'], focal_rays, abs_rays, ref['nodes']):
            assert all(ray[k] == abs_ray[k] for k in 'xyzlmn')
            assert all(ray[k] == chief_ray[k] for k in 'lmn')
            assert ray['error'] == ray['vignette'] == abs_ray['error'] == abs_ray['vignette'] == 0
            assert ray['intensity'] > 0 and abs_ray['intensity'] > 0
            offset = [ray[k]-chief_ray[k] for k in 'xyz']
            along = sum(x*ray[k] for x, k in zip(offset, 'lmn'))
            transverse = max(0, sum(x*x for x in offset)-along*along)
            stable = abs_ray['opdWaves']+along/ref['wave']
            assert abs(stable-stored['planeWaves']) < 1e-12 and abs(transverse-stored['transverseSquared']) < 1e-12
            assert coords['px'] == stored['px'] and coords['py'] == stored['py']
            assert ray['opdWaves'] == stored['nativeReportedWaves']
            reconstructed.append(dict(stored, planeWaves=stable, transverseSquared=transverse))
        assert values['ReferenceOpdMode'] == 'ExitPupil' and not values['ImageSpaceAfocal']
        out['modeSpecificEquivalence'] = 'Original focal request, same native Absolute and ExitPupil rays. Stable plane and all sign/radius surrogate controls for the collapsed zero-radius sphere; frozen numerics include ULP quantization.'
        out['frozenNativeMetrics'] = native_fans(data, read(native/'data.json'), gate)
        output = {}
        for radius in (None, ref['minSurrogateRadius'], ref['roundingScale'], 2*ref['minSurrogateRadius']):
            for sign in ((0,) if radius is None else (-1, 1)):
                tests = {}
                for axis, pane, offset in zip(('tangential', 'sagittal'), data['plotPanes'], (41, 0)):
                    series, = pane['series']
                    assert series['xAxisLabel'] == ('P_y' if axis == 'tangential' else 'P_x')
                    nodes = reconstructed[offset:offset+41]
                    nx = [n['py' if axis == 'tangential' else 'px'] for n in nodes]
                    ny = [n['planeWaves'] + (0 if radius is None else sign*n['transverseSquared'] /
                          ((math.sqrt(radius**2-n['transverseSquared'])+radius)*ref['wave'])) for n in nodes]
                    tests[axis] = curve(series, nx, ny, gate)
                output[f'{radius or "plane"}:{sign}'] = tests
        out['equivalentMetrics'] = output
        assert all(m['verdict'] == 'Pass' for result in output.values() for m in result.values())

    out['equivalentVerdict'] = 'Pass'


(root/'receipt.json').write_text(json.dumps({'frozenReplay': identity(frozen), 'rows': rows}, indent=2)+'\n', encoding='utf-8')
for i, result in rows.items():
    print(i, result['frozenVerdict'], result['equivalentVerdict'])
