using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Metrics;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var plans = JsonFiles.Read<Plan[]>(args[0]);
var results = new List<object>();
foreach (var plan in plans)
{
    var job = JsonFiles.Read<WorkbenchJob>(plan.Request);
    var entry = AnalysisComparisonRegistry.Get(job.Request.CanonicalAnalysisKey);
    var log = new List<string>();
    var metrics = new List<ComparisonMetric>();
    var gateBranches = new List<object>();
    var status = Conclusion.Error;
    string? error = null;
    try
    {
        var left = Read(plan.Left);
        var right = Read(plan.Right);
        if (left.Scalars.Count != 0 || right.Scalars.Count != 0)
            throw new InvalidDataException("Unexpected scalar in this diffraction cohort");
        foreach (var curve in right.Series)
        {
            var a = left.Series.Single(value => value.Id == curve.Id);
            var aligned = ComparisonMetrics.Align(a, curve, log);
            AddMetric(curve.Id, curve.YAxis.Unit, aligned, plan.Settings.Quantities[curve.YAxis.Quantity]);
        }
        foreach (var grid in right.Grids)
        {
            var a = left.Grids.Single(value => value.Id == grid.Id);
            var aligned = ComparisonMetrics.Align(a, grid, log);
            AddMetric(grid.Id, grid.ValueAxis.Unit, aligned, plan.Settings.Quantities[grid.ValueAxis.Quantity]);
        }
        status = metrics.Count == 0 || metrics.Any(x => x.Conclusion == Conclusion.Incomparable) ? Conclusion.Incomparable
            : metrics.Any(x => x.Conclusion == Conclusion.Difference) ? Conclusion.Difference
            : metrics.Any(x => x.Conclusion == Conclusion.Close) ? Conclusion.Close : Conclusion.Pass;
    }
    catch (Exception ex)
    {
        error = ex.ToString();
    }
    results.Add(new { plan.Index, plan.Id, plan.Left, plan.Right, plan.Request, job.Request.Fingerprint,
        plan.Settings.Quantities, Status = status.ToString(), Metrics = metrics, GateBranches = gateBranches,
        Normalizations = log, Error = error });
    Console.WriteLine($"{plan.Index} {plan.Id} {status} {error?.Split('\n')[0]}");

    NumericResult Read(Side side) => side.Kind switch
    {
        "core" => ResultNormalizer.Workbench(side.Path, entry, JsonFiles.Read<WorkbenchJob>(side.Request!).Request),
        "native" => ResultNormalizer.Zemax(side.Path, entry, job.Request, plan.WorkbenchBasis),
        _ => throw new ArgumentOutOfRangeException(nameof(side))
    };

    void AddMetric(string id, string unit, MatchedValues matched, Tolerances gate)
    {
        var metric = ComparisonMetrics.Calculate(id, unit, matched, gate);
        var pointwise = matched.Workbench.Zip(matched.Zemax, (a, b) => Math.Abs(a-b) <= gate.Absolute + gate.Relative*Math.Abs(b)).All(pass => pass);
        metrics.Add(metric);
        gateBranches.Add(new { id, PointwisePass = pointwise, NrmsePass = metric.Nrmse <= gate.Nrmse, CoveragePass = metric.Coverage >= gate.MinimumCoverage });
    }
}
JsonFiles.Write(args[1], results);

sealed record Side(string Kind, string Path, string? Request);
sealed record Plan(int Index, string Id, string Request, string WorkbenchBasis, AnalysisConfiguration Settings, Side Left, Side Right);
