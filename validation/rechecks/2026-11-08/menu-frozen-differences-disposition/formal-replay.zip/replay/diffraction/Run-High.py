import hashlib
import json
from pathlib import Path
import subprocess
import time


repo = Path.cwd()
root = repo/'artifacts/validation/menu-31-differences-20261108'
out = root/'diffraction'
worker = repo/'tools/OpticalSystemDesign.ZemaxComparison/bin/Release/net10.0/OpticalSystemDesign.ZemaxComparison.dll'
core = worker.with_name('OpticalSystemDesign.Core.dll')
tiers = {369: (128, 256), 444: (512, 1024), 446: (512, 1024), 448: (512, 1024),
         2158: (512, 1024), 2162: (512, 1024), 2278: (256, 512), 2165: (512, 1024), 451: (1024, 2048)}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


for index, sizes in tiers.items():
    original = root/'formal'/f'{index:04d}'/'request.json'
    for size in sizes:
        dest = out/'current'/f'{index}-{size}'
        dest.mkdir(parents=True, exist_ok=True)
        request = read(original)
        snapshot = Path(request['snapshotPath'])
        request['outputDirectory'] = str(dest)
        selected = request['request']
        original_size = selected['pupilSampling']
        selected['pupilSampling'] = size
        for alias in ('PupilSampling', 'Sampling'):
            settings = selected['workbenchSettings']
            if settings.get(alias) == str(original_size):
                settings[alias] = str(size)
        job = dest/'request.json'
        write(job, request)
        started = time.monotonic()
        receipt = {'index': index, 'pupilSampling': size, 'coreSha256': sha(core), 'workerSha256': sha(worker),
                   'snapshotSha256': sha(snapshot), 'frozenRequestSha256': sha(original), 'requestSha256': sha(job)}
        print('START', index, size, flush=True)
        try:
            run = subprocess.run(['dotnet', str(worker), '--workbench-worker', str(job)], stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', timeout=480)
            receipt['exitCode'] = run.returncode
            receipt['output'] = run.stdout
        except subprocess.TimeoutExpired:
            receipt['exitCode'] = 'Timeout'
        receipt['seconds'] = time.monotonic()-started
        if (dest/'data.json').exists():
            receipt['dataSha256'] = sha(dest/'data.json')
            data = read(dest/'data.json')
            receipt['outcome'], receipt['reason'] = data['outcome'], data['outcomeReason']
        write(dest/'execution.json', receipt)
        print('END', index, size, receipt.get('outcome', receipt['exitCode']), receipt.get('reason'),
              round(receipt['seconds'], 3), flush=True)
