import hashlib
import json
from pathlib import Path
from zipfile import ZipFile


repo = Path.cwd()
root = repo/'artifacts/validation/menu-31-differences-20261108'
out = root/'diffraction'
checks = repo/'validation/rechecks'
folded = checks/'2026-11-07/huygens-image-local-pupil'
dual = checks/'2026-11-07/residual-reference-followup'
twyman = checks/'2026-11-02/huygens-common'
tiers = {369: ((128, 256), (128, 256)), 444: ((512, 1024), (512, 1024)),
         446: ((512, 1024), (512, 1024)), 448: ((512, 1024), (512, 1024)),
         451: ((1024, 2048), (1024, 2048)), 2158: ((512, 1024), (512, 1024)),
         2162: ((512, 1024), (512, 1024)), 2165: ((512, 1024), (512, 1024)),
         2278: ((256, 512), (256, 512, 1024))}


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def digest(data):
    return hashlib.sha256(data).hexdigest()


catalog = {entry['logicalPath']: entry for entry in read(twyman/'archive-index.json')}
cohort = {row['index']: row for row in read(root/'cohort.json')}


def payload(index, tier, name):
    if index == 369:
        path = dual/'native'/f'{index}-{tier}'/name
        return path.read_bytes(), {'path': str(path.relative_to(repo))}
    if index in (2158, 2162, 2165):
        group = 'convergence-first' if index == 2165 else 'psf-convergence-corrected'
        record = catalog[f'{group}/{index}/{tier}/native/{name}']
        if 'retainedFile' in record:
            path = twyman/record['retainedFile']
            data = path.read_bytes()
            locator = {'path': str(path.relative_to(repo))}
        else:
            path = twyman/record['archive']
            with ZipFile(path) as archive:
                data = archive.read(record['entry'])
            locator = {'archive': str(path.relative_to(repo)), 'member': record['entry']}
        assert len(data) == record['length'] and digest(data) == record['sha256']
        return data, locator
    if index == 2278:
        case = f'{index}-selected-s{tier}'
    elif index == 444:
        case = f'{index}-n{tier}-d0.25'
    else:
        case = f'{index}-n{tier}'
    path = folded/'native-controls.zip'
    member = f'native/{case}/{name}'
    with ZipFile(path) as archive:
        data = archive.read(member)
    return data, {'archive': str(path.relative_to(repo)), 'member': member}


def stage(index, tier, original):
    path = out/'native'/f'{index}-{tier}'
    path.mkdir(parents=True, exist_ok=True)
    identities = {}
    names = ('data.json', 'captured-settings.json') if index == 369 else ('data.json', 'data.txt', 'captured-settings.json')
    for name in names:
        data, identity = payload(index, tier, name)
        (path/name).write_bytes(data)
        identities[name] = {**identity, 'sha256': digest(data), 'bytes': len(data)}
    settings = read(path/'captured-settings.json')
    request = settings['request']
    for key in ('canonicalAnalysisKey', 'configuration', 'field', 'wavelength', 'polarization', 'reference'):
        assert original[key] == request[key], (index, tier, key, original[key], request[key])
    physical = settings['properties']
    sampling = physical.get('PupilSampleSize', physical.get('SampleSize'))
    assert sampling == f'S_{tier}x{tier}' and request['pupilSampling'] == tier, (index, tier, physical, request)
    if index == 2278:
        assert physical['RadiusMaximum'] == 5 and physical['ReferTo'] == 'Centroid' and physical['ShowDiffractionLimit']
    else:
        assert request['imageSampling'] == original['imageSampling'] and request['imageDeltaMicrometers'] == original['imageDeltaMicrometers']
    if index in (369, 451, 2165):
        assert physical['Frequency'] == original['maximumFrequency'] and physical['NumberOfSteps'] == 5
    identity = {'tier': tier, 'files': identities, 'capturedProperties': physical,
                'capturedSelectors': settings['selectors']}
    return {'kind': 'native', 'path': str(path/'data.json')}, identity


def core(index, tier):
    path = out/'current'/f'{index}-{tier}'
    if (path/'execution.json').exists() and read(path/'execution.json').get('outcome') == 'Success':
        return {'kind': 'core', 'path': str(path/'data.json'), 'request': str(path/'request.json')}


plans = []
native_receipts = []
for index, (core_tiers, native_tiers) in tiers.items():
    original = read(root/'formal'/f'{index:04d}'/'request.json')['request']
    natives = {}
    for tier in native_tiers:
        natives[tier], native_receipt = stage(index, tier, original)
        native_receipts.append({'index': index, **native_receipt})
    cores = {tier: core(index, tier) for tier in core_tiers}
    basis = next((cores[t] for t in reversed(core_tiers) if cores[t] is not None), None)
    if basis is None:
        continue

    def add(label, left, right):
        if left is None or right is None:
            return
        plans.append({'index': index, 'id': label, 'request': basis['request'], 'workbenchBasis': basis['path'],
                      'settings': cohort[index]['settings'], 'left': left, 'right': right})

    for a, b in zip(native_tiers[:-1], native_tiers[1:]):
        add(f'native-{a}-vs-native-{b}', natives[a], natives[b])
    lo, hi = core_tiers
    add(f'current-{lo}-vs-current-{hi}', cores[lo], cores[hi])
    for tier in core_tiers:
        add(f'current-{tier}-vs-native-{tier}', cores[tier], natives.get(tier))
    add(f'current-{lo}-vs-native-{native_tiers[-1]}', cores[lo], natives[native_tiers[-1]])
    if hi != native_tiers[-1]:
        add(f'current-{hi}-vs-native-{native_tiers[-1]}', cores[hi], natives[native_tiers[-1]])
    formal = root/'formal'/f'{index:04d}'
    if (formal/'execution.json').exists() and read(formal/'data.json')['outcome'] == 'Success':
        frozen_native = Path(cohort[index]['legacyPath'])/'native'/'data.json'
        if frozen_native.exists():
            plans.append({'index': index, 'id': 'current-original-vs-frozen-native',
                          'request': str(formal/'request.json'), 'workbenchBasis': str(formal/'data.json'),
                          'settings': cohort[index]['settings'],
                          'left': {'kind': 'core', 'path': str(formal/'data.json'), 'request': str(formal/'request.json')},
                          'right': {'kind': 'native', 'path': str(frozen_native)}})

write(out/'native-references.json', native_receipts)
write(out/'plans.json', plans)
