using System.Globalization;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Metrics;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

if (args.Length != 3) throw new ArgumentException("CompareGrin <repo> <formal-root> <output-directory>");
var repo = Path.GetFullPath(args[0]);
var formal = Path.GetFullPath(args[1]);
var output = Path.GetFullPath(args[2]);
var cohort = JsonFiles.Read<JsonElement[]>(Path.Combine(Path.GetDirectoryName(formal)!, "cohort.json"));
var history = Path.Combine(repo, "validation/rechecks/2026-11-06");
using var frozen = new VerifiedArchive(Path.Combine(repo, "validation/repairs/2026-10-21/sequential-corpus-full-evidence.zip"),
    expected: "1dc562461d4e39ac9bf54f3c2309a0bb81fdeccfb092554cd8e9c14aa80760ad");
using var refined = new VerifiedArchive(Path.Combine(history, "grid-grin-refined-reference/native-grid-grin-controls.zip"));
using var diffraction = new VerifiedArchive(Path.Combine(history, "grid-grin-diffraction-reference/native-controls.zip"));
using var arcs = new VerifiedArchive(Path.Combine(history, "grid-grin-focal-arc-fft/native-controls.zip"));
var policyBytes = frozen.Read("run/comparison-settings.json");
var policyHash = JsonFiles.Hash(policyBytes);
Require(policyHash == "30c27e7976710867d0edc6dd4099edac54ca9e070245dea679b3afdd88fd28f5", "Original policy identity changed");
var policy = JsonSerializer.Deserialize<ComparisonConfiguration>(policyBytes, JsonFiles.Options)!;
const string lens = "GRINs/Grid GRIN.ZMX";
var source = frozen.Read("run/sources/" + lens);
var sourceHash = JsonFiles.Hash(source);
Require(sourceHash == "66d151a1b114b865ceab7d78e2fcfccdb869005cb67420db1d8cf422ad20dddb"
    && sourceHash == VerifiedArchive.FileHash(Path.Combine(repo, "src/OpticalSystemDesign.App/Assets/SequentialExamples", lens)), "Original menu prescription changed");
var grid = VerifiedArchive.FileHash(Path.Combine(repo, "src/OpticalSystemDesign.Core/Materials/Data/sample-grid-gradient.ggd"));
Require(grid == refined.Manifest.GetProperty("gridDataSha256").GetString(), "Sample.GGD identity changed");
var originalLines = LensLines(source);
Require(originalLines[89].Trim() == "PARM 1 1" && originalLines[90].Trim() == "DISZ 3.80E+00", "Grid GRIN source layout changed");
var axisIntegrals = RecomputeArcs(arcs, originalLines);
var cases = new (int Id, string Coarse, string Fine, bool Diffraction)[]
{
    (489, "0.0005", "0.00025", false), (490, "0.001", "0.0005", false),
    (493, "0.005", "0.001", false), (494, "0.005", "0.001", false),
    (496, "0.0005", "0.00025", true), (500, "0.0005", "0.00025", true),
    (501, "0.005", "0.001", true), (503, "0.001", "0.0005", true), (506, "0.005", "0.001", false),
    (507, "0.001", "0.0005", false), (510, "0.005", "0.001", false), (511, "0.001", "0.0005", false),
    (514, "0.005", "0.001", false), (515, "0.001", "0.0005", false), (518, "0.005", "0.001", false)
};
var rows = new List<object>();
foreach (var item in cases)
{
    var id = item.Id;
    var label = id.ToString("D4");
    var spec = cohort.Single(row => row.GetProperty("index").GetInt32() == id);
    var folder = Path.Combine(formal, label);
    var jobPath = Path.Combine(folder, "request.json");
    var dataPath = Path.Combine(folder, "data.json");
    var job = JsonFiles.Read<WorkbenchJob>(jobPath);
    var request = job.Request;
    var key = request.CanonicalAnalysisKey;
    var original = JsonFiles.Read<WorkbenchJob>(Text(spec, "job"));
    Require(request.Fingerprint == original.Request.Fingerprint && Text(spec, "lens") == lens, "Formal request differs from original");
    var execution = JsonFiles.Read<JsonElement>(Path.Combine(folder, "execution.json"));
    var provenance = JsonFiles.Read<JsonElement>(Path.Combine(folder, "provenance.json"));
    Require(execution.GetProperty("exitCode").GetInt32() == 0 && Text(provenance, "requestFingerprint") == request.Fingerprint
        && Text(provenance, "snapshotSha256") == VerifiedArchive.FileHash(job.SnapshotPath)
        && VerifiedArchive.FileHash(job.SnapshotPath) == VerifiedArchive.FileHash(original.SnapshotPath), "Formal execution provenance differs");
    var entry = AnalysisComparisonRegistry.Get(key);
    var config = spec.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
    Require(JsonElement.DeepEquals(JsonSerializer.SerializeToElement(config.Quantities, JsonFiles.Options),
        JsonSerializer.SerializeToElement(policy.Analyses[key].Quantities, JsonFiles.Options)), "Effective comparison gates differ from frozen policy");
    var prefix = frozen.Entries.Single(name => name.StartsWith($"run/analyses/{label}-", StringComparison.Ordinal)
        && name.EndsWith("/native/data.json", StringComparison.Ordinal))[..^"/data.json".Length];
    var captured = frozen.Json(prefix + "/captured-settings.json");
    var selected = item.Diffraction ? diffraction : refined;
    var old = Materialize(frozen, prefix, Path.Combine(output, "inputs", label, "frozen"));
    var coarse = Tier(item.Coarse);
    var fine = Tier(item.Fine);
    var workbench = ResultNormalizer.Workbench(dataPath, entry, request);
    var nativeOld = ResultNormalizer.Zemax(old, entry, request, dataPath);
    var nativeCoarse = ResultNormalizer.Zemax(coarse.Path, entry, request, dataPath);
    var nativeFine = ResultNormalizer.Zemax(fine.Path, entry, request, dataPath);
    var coarseFine = Compare("coarse-vs-fine", nativeCoarse, nativeFine);
    var oldFine = Compare("old-vs-fine", nativeOld, nativeFine);
    var workbenchFine = Compare("workbench-vs-fine", workbench, nativeFine);
    Require(coarseFine.Metrics.All(m => m.Conclusion == Conclusion.Pass) && workbenchFine.Metrics.All(m => m.Conclusion == Conclusion.Pass),
        $"{label} has a real difference on the converged reference");
    object? arc = null;
    if (key == "Single Ray Trace")
    {
        Require(nativeFine.UnreportedNativeRayPathSurfaces?.SequenceEqual([2]) == true
            && nativeCoarse.UnreportedNativeRayPathSurfaces?.SequenceEqual([2]) == true
            && workbenchFine.Conclusion == Conclusion.Incomparable && coarseFine.Conclusion == Conclusion.Incomparable,
            "Ray’s native missing path segment changed");
        var reported = workbenchFine.Metrics.Single(m => m.Id == "path-length");
        Require(reported.Count == 3 && reported.Conclusion == Conclusion.Pass, "Reported ray segments differ");
        var ray = JsonFiles.Read<JsonElement>(dataPath).GetProperty("values").GetProperty("RealRayData").EnumerateArray()
            .Single(row => row[0].GetDouble() == 2);
        var length = ray[11].GetDouble();
        var low = axisIntegrals[("0.001", request.Wavelength)];
        var high = axisIntegrals[("0.0005", request.Wavelength)];
        var gate = config.Quantities["Coordinate"];
        ComparisonMetric ArcMetric(double estimate, double expected) => ComparisonMetrics.Calculate("unreported-surface-2-arc", "Millimeter",
            new([2], null, [estimate], [expected], 1), gate);
        var byExtrapolation = ArcMetric(length, high.Extrapolated);
        var byChord = ArcMetric(length, high.Chords[64]);
        var referenceConvergence = ArcMetric(low.Extrapolated, high.Extrapolated);
        Require(new[] { byExtrapolation, byChord, referenceConvergence }.All(x => x.Conclusion == Conclusion.Pass), "Independent arc exceeds original coordinate tolerance");
        arc = new { request.Wavelength, normalizedField = new[] { 0d, 0d }, normalizedPupil = new[] { 0d, .8 },
            missingBuiltInSurface = 2, workbenchLengthMm = length, low, high, byExtrapolation, byChord, referenceConvergence };
    }
    else Require(coarseFine.Conclusion == Conclusion.Pass && workbenchFine.Conclusion == Conclusion.Pass, "Convergence or refined comparison failed");
    object? endpointCoverage = null;
    if (id == 500)
    {
        var productAxis = workbench.Series.Single().X;
        var nativeAxis = nativeFine.Series.Single().X;
        Require(productAxis.Length == 32 && nativeAxis.Length == 33 && productAxis.SequenceEqual(nativeAxis[..32]),
            "Huygens profile original image coordinates changed");
        endpointCoverage = new { productNodes = productAxis.Length, nativeNodes = nativeAxis.Length, sharedNodes = productAxis.Length,
            productMinimumMicrometers = productAxis[0], productMaximumMicrometers = productAxis[^1],
            extraNativeEndpointMicrometers = nativeAxis[^1], originalGateMinimumCoverage = config.Quantities["Irradiance"].MinimumCoverage };
    }
    rows.Add(new { index = id, key, sourceSha256 = sourceHash, requestFingerprint = request.Fingerprint,
        formalDataSha256 = VerifiedArchive.FileHash(dataPath), formalRequestSha256 = VerifiedArchive.FileHash(jobPath), provenance,
        originalSettings = new { request.Configuration, request.Field, request.Wavelength, request.Surface,
            request.PupilSampling, request.ImageSampling, request.ImageDeltaMicrometers, request.Reference, request.UseRayAiming },
        capturePropertyAndSelectorReadbacksEqualToFrozen = true,
        frozenVerdict = "Difference", independentOutcome = "SupplementalPass", coarse = coarse.Receipt, fine = fine.Receipt,
        oldFine = Summarize(oldFine), coarseFine = Summarize(coarseFine), workbenchFine = Summarize(workbenchFine), arc, endpointCoverage });
    Console.WriteLine($"{label} {key}: {workbenchFine.Conclusion}; all measured quantities and any arc pass");

    (string Path, object Receipt) Tier(string step)
    {
        var level = double.Parse(step, CultureInfo.InvariantCulture) < .001 ? "refinement" : "native";
        var dir = $"{level}{(item.Diffraction ? "/captures" : "")}/{id}-step{step}";
        var modelPath = item.Diffraction ? $"sources/grid-{step}.ZMX" : $"{level}/sources/grid-{step}.ZMX";
        var model = selected.Read(modelPath);
        Require(LensLines(model).SequenceEqual(AdjustedSource(originalLines, step)), "Native prescription changed beyond the GRIN maximum step");
        var readback = selected.Json(dir + "/captured-settings.json");
        Require(Text(readback, "origin") == "CapturedSettings" && JsonElement.DeepEquals(readback.GetProperty("properties"), captured.GetProperty("properties"))
            && JsonElement.DeepEquals(readback.GetProperty("selectors"), captured.GetProperty("selectors")), "Native readback differs from original settings");
        var nativeRequest = readback.GetProperty("request");
        Require(nativeRequest.Deserialize<CanonicalAnalysisRequest>(JsonFiles.Options)!.Fingerprint == request.Fingerprint
            && Text(nativeRequest, "inputSha256") == JsonFiles.Hash(model), "Native refined request or model identity differs");
        var path = Materialize(selected, dir, Path.Combine(output, "inputs", label, step));
        return (path, new { stepMillimeters = step, selected.ArchivePath, selected.ArchiveHash, member = dir,
            dataSha256 = VerifiedArchive.FileHash(path), settingsSha256 = JsonFiles.Hash(selected.Read(dir + "/captured-settings.json")),
            sourceMember = modelPath, sourceSha256 = JsonFiles.Hash(model) });
    }

    AnalysisRun Compare(string scope, NumericResult left, NumericResult right)
    {
        var run = new AnalysisRun { Key = key, Directory = $"{label}-{scope}", Request = request };
        run.Normalizations.AddRange(left.Transformations.Concat(right.Transformations));
        ComparisonRunner.Compare(run, entry, config, left, right, output);
        return run;
    }
}
JsonFiles.Write(Path.Combine(output, "receipt.json"), new { passed = rows.Count, frozenArchiveSha256 = frozen.ArchiveHash,
    policySha256 = policyHash, gridSha256 = grid, arcArchiveSha256 = arcs.ArchiveHash, rows });

static object Summarize(AnalysisRun run) => new
{
    run.Conclusion, run.Reason,
    metrics = run.Metrics.Select(m => new { m.Id, m.Unit, m.Count, m.MaxAbsolute, m.Nrmse, m.Coverage, m.Conclusion,
        scalars = m.Count == 1 ? m.Extra : null })
};

static Dictionary<(string, int), Arc> RecomputeArcs(VerifiedArchive source, string[] originalLines)
{
    var result = new Dictionary<(string, int), Arc>();
    var stations = source.Json("transport/stations.json").EnumerateArray().GroupBy(row => row.GetProperty("step").GetDouble());
    foreach (var group in stations)
    {
        var step = group.Key == .001 ? "0.001" : "0.0005";
        Require(group.Key is .001 or .0005, "Unexpected transport step");
        var samples = group.OrderBy(row => row.GetProperty("station").GetInt32()).ToArray();
        Require(samples.Length == 65, "Missing native depth stations");
        var points = new List<(double X, double Y, double Z)>[] { [], [], [] };
        for (var k = 0; k < samples.Length; k++)
        {
            var station = samples[k];
            var z = station.GetProperty("z").GetDouble();
            var name = Text(station, "id");
            Require(station.GetProperty("station").GetInt32() == k && Math.Abs(z - k * 3.8 / 64) < 1e-14, "Native arc station moved");
            var model = source.Read($"transport/sources/{name}.ZMX");
            var expected = AdjustedSource(originalLines, step);
            var actual = LensLines(model);
            if (k != 0)
            {
                var length = double.Parse(actual[90].Trim()[5..], CultureInfo.InvariantCulture);
                Require(actual[90].Trim().StartsWith("DISZ ") && Math.Abs(length - z) < 1e-14, "Native arc plane is not at declared depth");
                expected[90] = actual[90];
            }
            Require(actual.SequenceEqual(expected), "Native arc changed another part of the lens");
            Require(Text(source.Json($"transport/requests/{name}.json"), "inputSha256") == JsonFiles.Hash(model), "Native arc capture input mismatch");
            var data = source.Json($"transport/capture/{name}/model-controls.json");
            Require(Text(data, "contract") == "NativeSurfaceModelOperandsV1" && !data.GetProperty("savedInput").GetBoolean(), "Unexpected native arc operation");
            var operands = data.GetProperty("rows").EnumerateArray().ToDictionary(row =>
            {
                var input = row.GetProperty("input");
                Require(input.GetProperty("int1").GetInt32() == (k == 0 ? 1 : 2) && input.GetProperty("data1").GetDouble() == 0
                    && input.GetProperty("data2").GetDouble() == 0 && input.GetProperty("data3").GetDouble() == 0
                    && input.GetProperty("data4").GetDouble() == .8, "Native arc ray coordinates changed");
                return (Text(input, "code"), input.GetProperty("int2").GetInt32());
            }, row => row.GetProperty("value").GetDouble());
            for (var w = 1; w <= 3; w++)
            {
                Require(Math.Abs(operands[("REAZ", w)]) < 1e-10, "Native ray misses the requested station plane");
                points[w-1].Add((operands[("REAX", w)], operands[("REAY", w)], z));
            }
        }
        for (var w = 1; w <= 3; w++)
        {
            var ray = points[w-1];
            var chords = new Dictionary<int, double>();
            foreach (var count in new[] { 8, 16, 32, 64 })
            {
                var stride = 64/count;
                chords[count] = Enumerable.Range(0, count).Sum(i =>
                {
                    var a = ray[i * stride]; var b = ray[(i + 1) * stride];
                    return Math.Sqrt(Math.Pow(a.X-b.X, 2)+Math.Pow(a.Y-b.Y, 2)+Math.Pow(a.Z-b.Z, 2));
                });
            }
            result[(step, w)] = new(chords, (4*chords[64]-chords[32])/3, ray.Count);
        }
    }
    Require(result.Count == 6, "Native arc controls incomplete");
    return result;
}

static string Materialize(VerifiedArchive archive, string prefix, string directory)
{
    Directory.CreateDirectory(directory);
    foreach (var name in new[] { "data.json", "data.txt", "captured-settings.json", "model.json", "result-diagnostics.json" })
        if (archive.Entries.Contains(prefix + "/" + name)) File.WriteAllBytes(Path.Combine(directory, name), archive.Read(prefix + "/" + name));
    return Path.Combine(directory, "data.json");
}

static string[] AdjustedSource(string[] original, string step)
{
    var copy = (string[])original.Clone();
    copy[89] = "  PARM 1 " + step;
    return copy;
}
static string[] LensLines(byte[] data) => Encoding.Unicode.GetString(data).TrimStart('\uFEFF').Replace("\r\n", "\n").Split('\n');
static string Text(JsonElement value, string key) => value.GetProperty(key).GetString()!;
static void Require(bool condition, string reason) { if (!condition) throw new InvalidDataException(reason); }

sealed record Arc(Dictionary<int, double> Chords, double Extrapolated, int Stations);

sealed class VerifiedArchive : IDisposable
{
    private readonly ZipArchive archive;
    private readonly Dictionary<string, string> hashes;
    public string ArchivePath { get; }
    public string ArchiveHash { get; }
    public HashSet<string> Entries { get; }
    public JsonElement Manifest { get; }
    public VerifiedArchive(string path, string? expected = null)
    {
        ArchivePath = path;
        ArchiveHash = FileHash(path);
        hashes = [];
        if (expected is null)
        {
            Manifest = JsonFiles.Read<JsonElement>(Path.ChangeExtension(path, ".json"));
            expected = Manifest.GetProperty("archiveSha256").GetString();
            var records = Manifest.TryGetProperty("members", out var members) ? members : Manifest.GetProperty("rawPayloads");
            hashes = records.EnumerateArray().ToDictionary(row =>
                (row.TryGetProperty("path", out var member) ? member : row.GetProperty("archivePath")).GetString()!,
                row => row.GetProperty("sha256").GetString()!);
        }
        if (ArchiveHash != expected) throw new InvalidDataException("Evidence archive changed: " + path);
        archive = ZipFile.OpenRead(path);
        Entries = archive.Entries.Select(entry => entry.FullName).ToHashSet();
    }
    public byte[] Read(string member)
    {
        using var input = (archive.GetEntry(member) ?? throw new FileNotFoundException(member)).Open();
        using var buffer = new MemoryStream();
        input.CopyTo(buffer);
        var data = buffer.ToArray();
        if (hashes.Count != 0 && hashes.GetValueOrDefault(member) != JsonFiles.Hash(data)) throw new InvalidDataException("Evidence member changed: " + member);
        return data;
    }
    public JsonElement Json(string member) => JsonSerializer.Deserialize<JsonElement>(Read(member), JsonFiles.Options);
    public void Dispose() => archive.Dispose();
    public static string FileHash(string path)
    {
        using var stream = File.OpenRead(path);
        return Convert.ToHexStringLower(SHA256.HashData(stream));
    }
}
