using System.Diagnostics;
using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Services;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Workbench;
using OpticalSystemDesign.ZemaxComparison.Zemax;

var mode = args[0];
var current = Path.GetFullPath(args[1]);
var previous = Path.GetFullPath(args[2]);
var assembly = typeof(Optic).Assembly.Location;
var core = Hash(assembly);
var identity = JsonFiles.Read<JsonElement>(Path.Combine(current, "identity.json"));
if (identity.GetProperty("coreSha256").GetString() != core) throw new InvalidDataException("Core hash changed");
var rows = JsonFiles.Read<Row[]>(Path.Combine(current, "rows.json"));
if (mode is "compute")
{
    var driver = typeof(Row).Assembly.Location;
    var binary = Path.GetDirectoryName(driver)!;
    var lenses = rows.Where(r => r.Job != null).GroupBy(r => r.LensIndex).ToArray();
    var done = 0;
    await Parallel.ForEachAsync(lenses, new ParallelOptions { MaxDegreeOfParallelism = 2 }, async (group, token) =>
    {
        var lens = group.Key.ToString(CultureInfo.InvariantCulture);
        var run = await ProcessIsolation.Run("dotnet", [
            "exec", "--runtimeconfig", Path.Combine(binary, "ExampleAccuracy20261031.runtimeconfig.json"),
            "--depsfile", Path.Combine(binary, "ExampleAccuracy20261031.deps.json"), driver, "worker", current, previous, lens],
            identity.GetProperty("repository").GetString()!, group.Count() * 900 + 30, token);
        JsonFiles.Write(Path.Combine(current, "workers", lens + ".json"), run);
        Console.WriteLine($"LENS {Interlocked.Increment(ref done)}/{lenses.Length} {lens}: {run.ExitCode}");
        if (run.ExitCode != 0) throw new InvalidDataException("Worker failed: " + lens);
    });
    return;
}
var selected = args[3].Split(',').Select(x => int.Parse(x, CultureInfo.InvariantCulture)).ToHashSet();
var jobs = rows.Where(r => r.Job != null && (mode == "worker" ? selected.Contains(r.LensIndex) : selected.Contains(r.Index)));
var staging = Path.Combine(current, "staging", mode + "-" + args[3]);
Directory.CreateDirectory(staging);
foreach (var row in jobs)
{
    var job = JsonFiles.Read<WorkbenchJob>(row.Job!);
    var folder = Path.GetDirectoryName(row.Job!)!;
    var priorFolder = Path.Combine(previous, "analyses", $"{row.Index:D4}");
    var priorJob = JsonFiles.Read<WorkbenchJob>(Path.Combine(priorFolder, "request.json"));
    var snapshot = Hash(job.SnapshotPath);
    var oldSnapshot = Hash(priorJob.SnapshotPath);
    if (job.Request.Fingerprint != priorJob.Request.Fingerprint || snapshot != oldSnapshot)
        throw new InvalidDataException("Original request or snapshot changed: " + row.Index);
    var completion = Path.Combine(folder, "execution.json");
    if (File.Exists(completion)) throw new IOException("Existing execution: " + row.Index);
    var priorExit = JsonFiles.Read<JsonElement>(Path.Combine(priorFolder, "execution.json")).GetProperty("exitCode").GetInt32();
    var watch = Stopwatch.StartNew();
    string? error = null;
    try
    {
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(900));
        using var scope = ComputationCancellation.Push(deadline.Token);
        WorkbenchExecutor.Execute(job with { OutputDirectory = staging });
    }
    catch (Exception failure) { error = failure.ToString(); }

    var exitCode = error is null ? 0 : 3;
    var file = Path.Combine(staging, "data.json");
    var digest = exitCode == 0 ? Hash(file) : null;
    var previousDigest = priorExit == 0 ? Hash(Path.Combine(priorFolder, "data.json")) : null;
    var unchanged = exitCode == 0 && priorExit == 0 && digest == previousDigest;
    foreach (var name in new[] { "data.json", "data.txt", "preflight.json", "provenance.json" })
    {
        var source = Path.Combine(staging, name);
        if (!File.Exists(source)) continue;
        if (!unchanged || name == "provenance.json") File.Move(source, Path.Combine(folder, name));
        else File.Delete(source);
    }
    JsonFiles.Write(completion, new { row.Index, exitCode, error, seconds = watch.Elapsed.TotalSeconds, coreSha256 = core,
        previousExitCode = priorExit, currentDataSha256 = digest, previousDataSha256 = previousDigest,
        snapshotSha256 = snapshot, requestFingerprint = job.Request.Fingerprint, unchanged });
    Console.WriteLine($"ROW {row.Index}: {exitCode}; same={unchanged}; {watch.Elapsed.TotalSeconds:F2}s");
}
static string Hash(string path)
{
    using var file = File.OpenRead(path);
    return Convert.ToHexStringLower(SHA256.HashData(file));
}
internal sealed record Row(int Index, int LensIndex, string? Job);

