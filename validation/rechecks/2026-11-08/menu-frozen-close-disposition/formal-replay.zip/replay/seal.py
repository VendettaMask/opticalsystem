import collections,csv,hashlib,json,pathlib
from zipfile import ZipFile,ZIP_DEFLATED

repo=pathlib.Path.cwd()
root=repo/"artifacts/validation/menu-19-close-20261108"
reports=repo/"validation/rechecks/2026-11-08"
baseline=reports/"parallel-focal-fft-applicability"
report=reports/"menu-frozen-close-disposition"
report.mkdir(exist_ok=True)

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def dump(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()

def table(path):
    with path.open(newline="",encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))

def put_table(path,rows):
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def keyed(rows):
    if isinstance(rows,dict):
        rows=list(rows.values())
    return {int(r["index"]):r for r in rows}

historic=load(baseline/"summary.json")
assert sha(baseline/"frozen-replay.csv")==historic["frozenReplaySha256"]
matrix=table(baseline/"frozen-replay.csv")
scope={int(r["index"]):r for r in matrix if r["conclusion"]=="Close"}
assert len(matrix)==3024 and len(scope)==19
formal=keyed(load(root/"original-replay.json"))
direct=keyed(load(root/"frozen-compare/results.json"))
assert set(formal)==set(direct)==set(scope)
assert all(r["conclusion"]=="Close" for r in direct.values())
assert all(r["workbenchPayloadByteIdentical"] for r in formal.values())
maps=keyed(load(repo/"artifacts/validation/focal-fft-domain-20261108/full/request-mapping.json"))
assert all(maps[i]["effectiveFingerprint"]==scope[i]["requestFingerprint"] for i in scope)
bridges=[maps[i] for i in scope if maps[i]["originalFingerprint"]!=maps[i]["effectiveFingerprint"]]
assert [(r["index"],r["explicitSurface"]) for r in bridges]==[(2728,-1)]
tilted=next(r for r in load(root/"cohort.json") if r["index"]==2728)
image_model=load(pathlib.Path(tilted["legacyPath"])/"native/model.json")
image_job=load(root/"formal/2728/request.json")
image_snapshot=load(pathlib.Path(image_job["snapshotPath"]))
assert image_model["surfaces"][-1]["IsImage"] is True
assert image_job["request"]["surface"]==-1 and image_job["request"]["workbenchSettings"]["SurfaceNumber"]=="-1"
assert len(image_snapshot["surfaces"])==bridges[0]["effectiveSurfaceCount"]
bridges[0].update({"frozenNativeModelSurfaceCount":len(image_model["surfaces"]),"frozenNativeLastSurfaceIsImage":True,
                   "workbenchSnapshotLastSurfaceNumber":image_snapshot["surfaces"][-1]["number"]})

groups={}
labels={"energy":("ConvergedDiffractionEnergy","energy-verification.json"),
        "dense":("ConvergedDiffractionOrFineGridIntegration","dense-and-grid-verification.json"),
        "definitions":("IndependentEquivalentDefinition","equivalent-definitions-verification.json")}
for name,(_,filename) in labels.items():
    path=root/name/"receipt.json"
    groups[name]=keyed(load(path)["rows"])
    (report/filename).write_bytes(path.read_bytes())
energy,dense,defs=(groups[g] for g in ("energy","dense","definitions"))
assert [len(energy),len(dense),len(defs)]==[8,4,7]
assert set(energy)|set(dense)|set(defs)==set(scope)
def success(row):
    for key in ("numericVerdict","independentOutcome","equivalentVerdict","verdict","state","outcome","currentVerdict","conclusion","status"):
        if key in row:
            return row[key] in ("Pass","SupplementalPass")
    raise ValueError(list(row))
assert all(success(row) for group in groups.values() for row in group.values())

results=[]
assemblies=set()
archive=report/"formal-replay.zip"
with ZipFile(archive,"w",compression=ZIP_DEFLATED,compresslevel=9) as evidence:
    for index,item in sorted(formal.items()):
        row=scope[index]
        assert item["requestFingerprint"]==row["requestFingerprint"]==direct[index]["requestFingerprint"]
        assemblies.add(item["codeFingerprint"])
        group=next(g for g,rows in groups.items() if index in rows)
        ref=groups[group][index]
        if "requestFingerprint" in ref:
            assert item["requestFingerprint"]==ref["requestFingerprint"]
        if "originalEffectiveRequestFingerprint" in ref:
            assert item["requestFingerprint"]==ref["originalEffectiveRequestFingerprint"]
        if "formalProvenance" in ref:
            assert item["requestFingerprint"]==ref["formalProvenance"]["requestFingerprint"]
        if "formalData" in ref:
            assert item["dataSha256"]==ref["formalData"]["sha256"]
        name=f"{index:04d}"
        folder=root/"formal"/name
        assert sha(folder/"data.json")==item["dataSha256"]
        for file in ("request.json","data.json","provenance.json","execution.json"):
            evidence.write(folder/file,f"formal/{name}/{file}")
        contract,receipt=labels[group]
        if index in (498,505):
            contract="NativeRefinedGridIntegration"
        if index==825:
            contract="NativeParaxialRayDerivativeAndAnalyticControl"
        if index==953:
            contract="CheckedRadialHuygensAndIndependentNativeIntegral"
        if index==954:
            contract="SinglePhysicalFieldNativeRelativeIllumination"
        results.append({"index":index,"lensIndex":int(row["lensIndex"]),"lens":item["lens"],"configuration":item["configuration"],
                        "analysis":item["analysis"],"frozenVerdict":"Close","currentDirectFrozenComparison":"Close",
                        "currentIndependentAcceptance":"Pass","referenceContract":contract,"receipt":receipt,
                        "originalRequestFingerprint":maps[index]["originalFingerprint"],"effectiveRequestFingerprint":item["requestFingerprint"],
                        "snapshotSha256":item["snapshotSha256"],"originalWorkbenchDataSha256":item["dataSha256"],
                        "originalWorkbenchByteIdentical":item["workbenchPayloadByteIdentical"]})
    for group in groups:
        for provenance in sorted((root/group).rglob("provenance.json")):
            identity=load(provenance)
            if "codeFingerprint" not in identity:
                continue
            folder=provenance.parent
            if not (folder/"data.json").is_file() or not (folder/"request.json").is_file():
                continue
            assert identity["codeFingerprint"] in assemblies
            for file in ("request.json","data.json","provenance.json","execution.json"):
                target=folder/file
                if target.is_file():
                    evidence.write(target,target.relative_to(root).as_posix())
    for name in ("Run-Original.py","Compare-Original.py","seal.py"):
        evidence.write(root/name,"replay/"+name)
    for group in groups:
        for file in sorted((root/group).glob("*")):
            if file.suffix in (".cs",".csproj",".py",".ps1"):
                evidence.write(file,"replay/"+file.relative_to(root).as_posix())
    for name in ("dense/compare/Program.cs","dense/compare/Compare.csproj"):
        source=root/name
        if source.is_file():
            evidence.write(source,"replay/"+name)
    for name in ("original-replay.json","frozen-compare/results.json"):
        evidence.write(root/name,"frozen/"+pathlib.Path(name).name)

assert len(assemblies)==1
application,core=next(iter(assemblies)).split(":")
assert core==historic["coreSha256"]
put_table(report/"by-request.csv",results)
by_lens=table(baseline/"by-lens.csv")
lens_counts=collections.Counter(r["lensIndex"] for r in results)
assert len(by_lens)==95
for row in by_lens:
    row["closeScopeReplayed"]=lens_counts[int(row["index"])]
    row["closeScopeIndependentPass"]=lens_counts[int(row["index"])]
assert sum(int(r["Close"]) for r in by_lens)==sum(lens_counts.values())==19
put_table(report/"by-lens.csv",by_lens)
for source,name in (("original-replay.json","original-replay.json"),("frozen-compare/results.json","frozen-comparison.json")):
    (report/name).write_bytes((root/source).read_bytes())
dump(report/"request-mapping-controls.json",bridges)
summary={"menuLenses":95,"menuConfigurations":historic["configurations"],"frozenRequests":len(matrix),
         "frozenCounts":historic["frozen"],"closeScopeLenses":len(lens_counts),"closeScopeReplayed":len(results),
         "currentFrozenDirectClose":19,"independentAcceptance":{"Pass":19,"Close":0,"Difference":0,"Error":0},
         "referenceGroups":{name:len(rows) for name,rows in groups.items()},"originalFrozenNativeFilesVerified":sum(len(r["frozenNativeFiles"]) for r in formal.values()),
         "originalOutputByteIdenticalWithPrior":len(formal),"effectiveSurfaceFingerprintBridge":[2728],
         "applicationSha256":application,"coreSha256":core,"frozenNativeArchiveSha256":historic["nativeReference"]["archiveSha256"],
         "policySha256":historic["policySha256"],"frozenMatrixSha256":historic["frozenReplaySha256"],
         "reportFileHashes":{file.name:sha(file) for file in sorted(report.iterdir()) if file.is_file() and file.suffix in (".zip",".csv",".json") and file.name!="summary.json"}}
dump(report/"summary.json",summary)
print(json.dumps(summary,indent=2))

