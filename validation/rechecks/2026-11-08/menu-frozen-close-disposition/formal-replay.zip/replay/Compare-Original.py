import hashlib, json, pathlib, shutil, subprocess, time
from zipfile import ZipFile

repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-19-close-20261108"
baseline = repo / "artifacts/validation/focal-fft-domain-20261108/full"
archive = repo / "validation/repairs/2026-10-21/sequential-corpus-full-evidence.zip"
native_root = repo / "artifacts/zemax-sequential-corpus/20261021/full-v1"
prior = repo / "artifacts/validation/precision-physical-fourier-20261108/full"
report = repo / "validation/rechecks/2026-11-08/parallel-focal-fft-applicability"
scope = root / "frozen-compare"
scope.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def sha(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

rows = read(root / "cohort.json")
assert len(rows) == 19
stop = time.monotonic() + 300
while sum((root / "formal" / f'{r["index"]:04d}' / "provenance.json").exists() for r in rows) < len(rows):
    if time.monotonic() > stop:
        raise TimeoutError("Original Workbench execution did not finish")
    time.sleep(2)
expected = read(report / "summary.json")
assert sha(archive) == expected["nativeReference"]["archiveSha256"]
with ZipFile(archive) as z:
    manifest = {r["path"]: r for r in json.loads(z.read("payload-manifest.json"))}

receipts = []
for row in rows:
    index = row["index"]
    relative = f"{index:04d}"
    source = root / "formal" / relative
    baseline_folder = baseline / "analyses" / relative
    provenance = read(source / "provenance.json")
    job = read(source / "request.json")
    assert sha(pathlib.Path(job["snapshotPath"])) == provenance["snapshotSha256"]
    prior_job = read(baseline_folder / "request.json")
    assert prior_job["request"] == job["request"]
    assert sha(pathlib.Path(prior_job["snapshotPath"])) == provenance["snapshotSha256"]
    native = pathlib.Path(row["legacyPath"]) / "native"
    verified = {}
    for path in sorted(native.iterdir()):
        if not path.is_file() or path.suffix in {".png", ".svg", ".jpg", ".jpeg", ".pdf"}:
            continue
        name = "run/" + path.relative_to(native_root).as_posix()
        record = manifest[name]
        assert record["sha256"] == sha(path) and record["bytes"] == path.stat().st_size
        verified[name] = record["sha256"]
    assert any(name.endswith("/data.json") for name in verified)
    assert any(name.endswith("/captured-settings.json") for name in verified)
    original = baseline_folder / "data.json"
    if not original.is_file():
        original = prior / "analyses" / relative / "data.json"
    current = sha(source / "data.json")
    receipts.append({"index": index, "lens": row["lens"], "configuration": row["configuration"],
                     "analysis": row["key"], "requestFingerprint": provenance["requestFingerprint"],
                     "snapshotSha256": provenance["snapshotSha256"], "codeFingerprint": provenance["codeFingerprint"],
                     "dataSha256": current, "previousOriginalDataSha256": sha(original),
                     "workbenchPayloadByteIdentical": current == sha(original), "frozenNativeFiles": verified})
    row["job"] = str(source / "request.json")
    destination = scope / "analyses" / relative
    destination.mkdir(parents=True, exist_ok=True)
    for file in ("execution.json", "data.json"):
        shutil.copyfile(source / file, destination / file)

write(root / "original-replay.json", receipts)
write(scope / "rows.json", rows)
for name in ("identity.json", "models.json"):
    shutil.copyfile(baseline / name, scope / name)
subprocess.run(["dotnet", str(baseline.parent / "bin-domain/ExampleAccuracy20261031.dll"),
                "compare", str(repo), str(scope)], check=True)
print("verified native files", sum(len(r["frozenNativeFiles"]) for r in receipts))
print("byte-identical Workbench payloads", sum(r["workbenchPayloadByteIdentical"] for r in receipts))

