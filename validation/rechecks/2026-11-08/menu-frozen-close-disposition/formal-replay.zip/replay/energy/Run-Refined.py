"""Replay accepted 256/512 energy settings on current Workbench, headlessly."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from hashlib import file_digest, sha256
from pathlib import Path
from subprocess import run, STDOUT, PIPE
from time import monotonic
from zipfile import ZipFile
import json


repo = Path.cwd()
root = repo/'artifacts/validation/menu-19-close-20261108'
work = root/'energy'
history = repo/'validation/rechecks/2026-11-07/parallel-refinement'
archive_path = history/'energy-evidence.zip'
worker = repo/'tools/OpticalSystemDesign.ZemaxComparison/bin/Release/net10.0/OpticalSystemDesign.ZemaxComparison.dll'
indices = (108, 368, 712, 742, 860, 2142, 2728, 2750)


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf8')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


worker_hash = digest(worker)
assert digest(archive_path) == read(history/'energy-refinement.json')['archiveSha256']


def job_for(index, size, archive):
    original = read(root/'formal'/f'{index:04d}'/'request.json')
    candidate = deepcopy(original)
    request = candidate['request']
    request['pupilSampling'] = size
    request['imageSampling'] = 2*size
    settings = request['workbenchSettings']
    settings.update(PupilSampling=str(size), Sampling=str(size), ImageSampling=str(2*size))
    if index == 860:
        # Archived EnergyProbe uses the legacy alias NumRays for this row.
        settings['NumRays'] = str(size)
    else:
        request['gridSize'] = 2*size
        request['zemaxSettings']['SampleSize'] = f'S_{size}x{size}'
        member = f'{index}-{size}/wreq.json'
        raw = archive.read(member)
        assert sha256(raw).hexdigest() == manifest[member]
        assert request == json.loads(raw)['request'], (index, size)
    directory = work/'formal'/f'{index:04d}'/str(size)
    candidate['outputDirectory'] = str(directory)
    return index, size, candidate, directory


def execute(item):
    index, size, job, directory = item
    directory.mkdir(parents=True, exist_ok=True)
    path = directory/'request.json'
    write(path, job)
    started = monotonic()
    execution = run(['dotnet', str(worker), '--workbench-worker', str(path)],
                    stdout=PIPE, stderr=STDOUT, timeout=240, text=True, encoding='utf8', errors='replace')
    write(directory/'execution.json', {'index': index, 'sampling': size, 'exitCode': execution.returncode,
          'seconds': monotonic()-started, 'workerSha256': worker_hash, 'requestSha256': digest(path),
          'output': execution.stdout})
    assert not execution.returncode, (index, size, execution.stdout)
    provenance = read(directory/'provenance.json')
    original_provenance = read(root/'formal'/f'{index:04d}'/'provenance.json')
    assert provenance['codeFingerprint'] == original_provenance['codeFingerprint']
    assert provenance['snapshotSha256'] == original_provenance['snapshotSha256']
    data = read(directory/'data.json')
    assert data['outcome'] == 'Success', (index, size, data['outcomeReason'])
    print(index, size, data['outcome'], flush=True)


with ZipFile(archive_path) as archive:
    manifest = {item['path']: item['sha256'] for item in json.loads(archive.read('manifest.json'))['files']}
    jobs = [job_for(index, size, archive) for index in indices for size in (256, 512)]
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(execute, jobs))
