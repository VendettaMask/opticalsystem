"""Audit the eight original energy windows and reproduce their old comparison gates."""
from contextlib import ExitStack
from hashlib import file_digest, sha256
from pathlib import Path
from zipfile import ZipFile
import json

import numpy as np


repo = Path.cwd()
root = repo/'artifacts/validation/menu-19-close-20261108'
work = root/'energy'
prior = repo/'validation/rechecks/2026-11-07'
frozen_path = repo/'validation/repairs/2026-10-21/sequential-corpus-full-evidence.zip'
parallel_path = prior/'parallel-refinement/energy-evidence.zip'
interconnect_path = prior/'optical-interconnect-reference/native-controls.zip'
mapping_path = repo/'artifacts/validation/focal-fft-domain-20261108/full/request-mapping.json'
indices = (108, 368, 712, 742, 860, 2142, 2728, 2750)
radii = np.arange(401)*5/400
names = ('DiffractionLimit', 'Actual')


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def sha_bytes(raw):
    return sha256(raw).hexdigest()


def checked(zipfile, member, manifest):
    raw = zipfile.read(member)
    assert sha_bytes(raw) == manifest[member], member
    return raw


def native_curves(raw):
    data = json.loads(raw)
    assert not data['messages']
    series = data['dataSeries']
    assert len(series) == 2 and [s['index'] for s in series] == [0, 1]
    assert series[0]['description'] == '衍射极限'
    result = []
    for s in series:
        axis, values = np.asarray(s['x']), np.asarray(s['y'])
        assert values.shape == (401, 1)
        result.append(check_curve(axis, values[:, 0]))
    return result


def workbench_curves(path, sampling):
    data = read(path)
    assert data['outcome'] == 'Success' and data['values']['PupilSampling'] == sampling
    assert data['values']['EffectiveImageSampling'] == 2*sampling
    series = data['plotSeries']
    assert len(series) == 2 and series[0]['name'] == '衍射极限' and series[1]['name'] != series[0]['name']
    result = []
    for s in series:
        assert (s['xQuantity'], s['xUnit'], s['yQuantity'], s['yUnit']) == (
            'Radius', 'Micrometer', 'EnergyFraction', 'Dimensionless')
        axis, values = np.asarray([(point['x'], point['y']) for point in s['points']]).T
        result.append(check_curve(axis, values))
    return result


def check_curve(axis, values):
    assert len(axis) == len(values) == 401
    assert np.max(abs(axis-radii)) < 1e-12 and axis[0] == 0 and axis[-1] == 5
    assert np.all(np.diff(axis) > 0) and np.all(np.isfinite(values))
    assert values[0] == 0 and np.all(np.diff(values) >= -1e-13) and values[-1] <= 1+1e-13
    return axis, values


def metric(candidate, reference, gate):
    error = abs(candidate-reference)
    nrmse = float(np.sqrt(np.mean(error**2))/max(abs(reference).max(), gate['absolute']))
    pointwise = bool(np.all(error <= gate['absolute']+gate['relative']*abs(reference)))
    conclusion = 'Pass' if pointwise or nrmse <= gate['nrmse'] else 'Close' if nrmse <= gate['closeNrmse'] else 'Difference'
    return {'count': len(error), 'coverage': 1, 'maximumAbsolute': float(error.max()),
            'nrmse': nrmse, 'pointwisePass': pointwise, 'conclusion': conclusion}


def compare(candidate, reference, gate):
    comparisons = []
    for name, left, right in zip(names, candidate, reference):
        # Match the comparison registry's physical-knot union. Report the
        # exact 401-point original product domain separately from roundoff-
        # distinct union coordinates. All curves share the same endpoints.
        union = np.union1d(left[0], right[0])
        a, b = np.interp(union, *left), np.interp(union, *right)
        union_metric = metric(a, b, gate)
        physical_metric = metric(np.interp(radii, *left), np.interp(radii, *right), gate)
        comparisons.append({'component': name, 'comparisonRegistryMetric': union_metric,
                            'originalRadiusMetric': physical_metric})
    return comparisons


def passed(records):
    return all(row[key]['conclusion'] == 'Pass' for row in records
               for key in ('comparisonRegistryMetric', 'originalRadiusMetric'))


with ExitStack() as close:
    histories = read(prior/'parallel-refinement/energy-refinement.json')
    refs = {case['index']: case for case in histories['requests']}
    interconnect = read(prior/'optical-interconnect-reference/native-controls.json')
    archive_hashes = {str(path.relative_to(repo)): sha(path) for path in (frozen_path, parallel_path, interconnect_path)}
    frozen, parallel, inter = (close.enter_context(ZipFile(path)) for path in (frozen_path, parallel_path, interconnect_path))
    manifest = json.loads(parallel.read('manifest.json'))
    assert sha(frozen_path) == manifest['frozenArchiveSha256']
    assert sha(parallel_path) == histories['archiveSha256'] and sha(interconnect_path) == interconnect['archiveSha256']
    manifests = {parallel: {item['path']: item['sha256'] for item in manifest['files']},
                 inter: json.loads(inter.read('manifest.json'))}
    policy = frozen.read('run/comparison-settings.json')
    policy_sha = sha_bytes(policy)
    assert policy_sha == '30c27e7976710867d0edc6dd4099edac54ca9e070245dea679b3afdd88fd28f5'
    gate = dict(json.loads(policy)['analyses']['Diffraction Encircled Energy']['quantities']['EnergyFraction'], minimumCoverage=.95)
    assert gate['nrmse'] == .003
    frozen_rows = {item['index']: item for item in read(root/'original-replay.json')}
    bridges = {item['index']: item for item in read(mapping_path)}
    cases = []
    for index in indices:
        index_label = f'{index:04d}'
        replay = frozen_rows[index]
        lens = replay['lens']
        source = frozen.read('run/sources/'+lens)
        source_hash = sha_bytes(source)
        assert sha(repo/'src/OpticalSystemDesign.App/Assets/SequentialExamples'/lens) == source_hash
        original = root/'formal'/index_label
        original_job = read(original/'request.json')
        original_request = original_job['request']
        assert original_request['canonicalAnalysisKey'] == 'Diffraction Encircled Energy'
        assert original_request['reference'] == 'Centroid' and original_request['surface'] == -1
        assert original_request['wavelength'] > 0 and original_request['wavelengthScope'] == 'Selected'
        assert original_request['workbenchSettings']['MaximumDistanceMicrometers'] == '5'
        assert original_request['workbenchSettings']['NumPoints'] == '401'
        bridge = None
        prefix = next(item.rsplit('/native/data.json', 1)[0] for item in frozen.namelist()
                      if item.startswith(f'run/analyses/{index_label}-') and item.endswith('/native/data.json'))
        original_native = frozen.read(prefix+'/native/data.json')
        original_native_settings = frozen.read(prefix+'/native/captured-settings.json')
        original_native_model = frozen.read(prefix+'/native/model.json')
        raw_original_request = json.loads(frozen.read(prefix+'/workbench/request.json'))['request']
        if index == 2728:
            bridge = bridges[index]
            assert bridge['originalFingerprint'] == '5ae9d7c5297efb7a4c81d26ae05d0bdca950ed5de2319f7806bbc2609723e1a1'
            assert bridge['effectiveFingerprint'] == replay['requestFingerprint']
            assert (bridge['originalSurfaceCount'], bridge['effectiveSurfaceCount'], bridge['explicitSurface']) == (4, 5, -1)
            assert raw_original_request == {**original_request, 'surfaceCount': 4}
        else:
            assert raw_original_request == original_request
        assert sha(original/'data.json') == replay['dataSha256']
        assert sha_bytes(original_native) == replay['frozenNativeFiles'][prefix+'/native/data.json']
        assert sha_bytes(original_native_settings) == replay['frozenNativeFiles'][prefix+'/native/captured-settings.json']
        original_settings = json.loads(original_native_settings)
        old_pair = compare(workbench_curves(original/'data.json', 32), native_curves(original_native), gate)
        assert any(row['comparisonRegistryMetric']['conclusion'] == 'Close' for row in old_pair)
        assert all(row['comparisonRegistryMetric']['conclusion'] != 'Difference' for row in old_pair)

        if index == 860:
            native_archive, archive_path = inter, interconnect_path
            fine_member = 'native-energy/inputs/a491e9f1c3f8540576ffa6ded0072053d8c3f4bb1470c56823374767ad783a29.ZMX'
            original_member = f'native-energy/inputs/{source_hash}.ZMX'
            assert checked(inter, original_member, manifests[inter]) == source
            fine_source = checked(inter, fine_member, manifests[inter])
            base_lines = source.decode('utf16').splitlines()
            fine_lines = fine_source.decode('utf16').splitlines()
            assert len(base_lines) == len(fine_lines)
            edits = [(a.strip(), b.strip()) for a, b in zip(base_lines, fine_lines) if a != b]
            assert edits == [('PARM 1 1.00E-01', 'PARM 1 0.001')]*2
            source_control = {'originalStepMm': .1, 'fineStepMm': .001, 'changedStepLines': 2,
                              'originalSourceMember': original_member, 'fineSourceMember': fine_member,
                              'fineSourceSha256': sha_bytes(fine_source)}
        else:
            native_archive, archive_path = parallel, parallel_path
            member = f'{index}-64/native/model.json'
            observed_model = json.loads(checked(parallel, member, manifests[parallel]))
            observed_model.pop('advanced')
            assert observed_model == json.loads(original_native_model)
            source_control = {'nativeModelControlMember': member, 'frozenNativeModelSha256': sha_bytes(original_native_model)}
        tier_records = []
        product_curves, native_levels, fine_levels = [], [], []
        for n in (256, 512):
            directory = work/'formal'/index_label/str(n)
            candidate = read(directory/'request.json')['request']
            adjusted = dict(original_request, pupilSampling=n, imageSampling=2*n)
            settings = dict(original_request['workbenchSettings'], Sampling=str(n), PupilSampling=str(n), ImageSampling=str(2*n))
            adjusted['workbenchSettings'] = settings
            if index == 860:
                settings['NumRays'] = str(n)
                native_prefix = f'native-energy/frozen-{n}'
                native_job_member = f'native-energy/requests/frozen-{n}.json'
            else:
                adjusted['gridSize'] = 2*n
                adjusted['zemaxSettings'] = dict(original_request['zemaxSettings'], SampleSize=f'S_{n}x{n}')
                native_prefix = f'{index}-{n}/native'
                native_job_member = f'{index}-{n}/nreq.json'
                archived_job = json.loads(checked(parallel, f'{index}-{n}/wreq.json', manifests[parallel]))
                assert archived_job['request'] == candidate
            assert candidate == adjusted
            provenance = read(directory/'provenance.json')
            assert provenance['snapshotSha256'] == replay['snapshotSha256'] and provenance['codeFingerprint'] == replay['codeFingerprint']
            assert read(directory/'execution.json')['exitCode'] == 0
            source_readback = json.loads(checked(native_archive, native_job_member, manifests[native_archive]))
            settings_bytes = checked(native_archive, native_prefix+'/captured-settings.json', manifests[native_archive])
            native_readback = json.loads(settings_bytes)
            assert native_readback['origin'] == 'CapturedSettings'
            assert native_readback['properties'] == dict(original_settings['properties'], SampleSize=f'S_{n}x{n}')
            assert native_readback['selectors'] == original_settings['selectors']
            assert native_readback['request'] == source_readback
            if index == 860:
                assert source_readback['inputSha256'] == source_hash
            else:
                assert source_readback['input'].replace('\\', '/').endswith('/full-v1/sources/'+lens)
                entry = next(row for row in refs[index]['readbacks'] if row['sampling'] == n)
                assert entry['nativeRequestSource'] == source_hash and entry['frozenNativeModel'] == sha_bytes(original_native_model)
                assert entry['requestFingerprint'] == provenance['requestFingerprint']
            native_bytes = checked(native_archive, native_prefix+'/data.json', manifests[native_archive])
            a, b = workbench_curves(directory/'data.json', n), native_curves(native_bytes)
            cross = compare(a, b, gate)
            assert passed(cross), (index, n, cross)
            product_curves.append(a)
            native_levels.append(b)
            tier_record = {'sampling': n, 'imageSampling': 2*n, 'provenance': provenance,
                           'formalDataSha256': sha(directory/'data.json'), 'formalRequestSha256': sha(directory/'request.json'),
                           'nativeDataMember': native_prefix+'/data.json', 'nativeDataSha256': sha_bytes(native_bytes),
                           'nativeSettingsMember': native_prefix+'/captured-settings.json', 'nativeSettingsSha256': sha_bytes(settings_bytes),
                           'nativeRequestMember': native_job_member, 'settingsReadbackEqualsOriginalExceptSampling': True,
                           'crossComparison': cross}
            if index == 860:
                fine_prefix = f'native-energy/fine-{n}'
                fine_data = checked(inter, fine_prefix+'/data.json', manifests[inter])
                fine_settings = json.loads(checked(inter, fine_prefix+'/captured-settings.json', manifests[inter]))
                assert fine_settings['properties'] == native_readback['properties'] and fine_settings['selectors'] == native_readback['selectors']
                assert fine_settings['request']['inputSha256'] == sha_bytes(fine_source)
                f = native_curves(fine_data)
                same_sampling_step = compare(b, f, gate)
                refined_step_cross = compare(a, f, gate)
                assert passed(same_sampling_step) and passed(refined_step_cross)
                fine_levels.append(f)
                tier_record['fineStepControl'] = {'nativeDataMember': fine_prefix+'/data.json', 'dataSha256': sha_bytes(fine_data),
                                                 'stepConvergence': same_sampling_step, 'crossComparison': refined_step_cross}
            tier_records.append(tier_record)
        product_convergence = compare(*product_curves, gate)
        native_convergence = compare(*native_levels, gate)
        assert passed(product_convergence) and passed(native_convergence), index
        fine_convergence = compare(*fine_levels, gate) if fine_levels else None
        assert fine_convergence is None or passed(fine_convergence)
        cases.append({'index': index, 'lens': lens, 'analysis': original_request['canonicalAnalysisKey'],
                      'frozenVerdict': 'Close', 'independentOutcome': 'SupplementalPass',
                      'originalEffectiveRequestFingerprint': replay['requestFingerprint'],
                      'originalRequestBridge': bridge, 'sourceSha256': source_hash, 'sourceControl': source_control,
                      'nativeArchive': str(archive_path.relative_to(repo)).replace('\\', '/'),
                      'nativeArchiveSha256': sha(archive_path), 'originalSettings': {
                          'configuration': original_request['configuration'], 'field': original_request['field'],
                          'wavelength': original_request['wavelength'], 'surface': original_request['surface'],
                          'reference': original_request['reference'], 'maximumRadiusMicrometers': 5, 'originalRadiusNodes': 401},
                      'originalWorkbenchVersusOriginalNative': old_pair, 'tiers': tier_records,
                      'workbenchConvergence': product_convergence, 'nativeConvergence': native_convergence,
                      'nativeFineStepSamplingConvergence': fine_convergence})
        print(index, 'Pass', max(r['comparisonRegistryMetric']['nrmse'] for r in tier_records[-1]['crossComparison']))

receipt = {'passed': len(cases), 'policySha256': policy_sha, 'originalGate': gate, 'archiveSha256': archive_hashes, 'rows': cases}
(work/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf8')
