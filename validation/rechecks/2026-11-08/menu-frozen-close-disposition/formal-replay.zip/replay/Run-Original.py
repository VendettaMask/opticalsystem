import concurrent.futures, csv, hashlib, json, pathlib, subprocess, time
repo = pathlib.Path.cwd()
root = repo / "artifacts/validation/menu-19-close-20261108"
baseline = repo / "artifacts/validation/focal-fft-domain-20261108/full"
worker = repo / "tools/OpticalSystemDesign.ZemaxComparison/bin/Release/net10.0/OpticalSystemDesign.ZemaxComparison.dll"
frozen = repo / "validation/rechecks/2026-11-08/parallel-focal-fft-applicability/frozen-replay.csv"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def sha(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

with frozen.open(encoding="utf-8-sig", newline="") as file:
    scope = {int(row["index"]): row for row in csv.DictReader(file) if row["conclusion"] == "Close"}
assert len(scope) == 19
assert sha(frozen) == read(frozen.parent / "summary.json")["frozenReplaySha256"]
rows = [row for row in read(baseline / "rows.json") if row["index"] in scope]
assert len(rows) == len(scope)
write(root / "cohort.json", rows)

def run(row):
    index = row["index"]
    origin = pathlib.Path(row["job"])
    destination = root / "formal" / f"{index:04d}"
    if (destination / "execution.json").is_file() and (destination / "data.json").is_file():
        assert read(destination / "execution.json")["exitCode"] == 0
        assert read(destination / "provenance.json")["requestFingerprint"] == scope[index]["requestFingerprint"]
        return
    destination.mkdir(exist_ok=True)
    request = read(origin)
    request["outputDirectory"] = str(destination)
    job = destination / "request.json"
    write(job, request)
    start = time.monotonic()
    result = subprocess.run(["dotnet", str(worker), "--workbench-worker", str(job)],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                            errors="replace", timeout=900)
    write(destination / "execution.json", {"index": index, "exitCode": result.returncode,
        "seconds": time.monotonic() - start, "originalRequestSha256": sha(origin),
        "workerSha256": sha(worker), "output": result.stdout})
    if result.returncode:
        raise RuntimeError((index, row["key"], result.stdout))
    provenance = read(destination / "provenance.json")
    assert provenance["requestFingerprint"] == scope[index]["requestFingerprint"]
    data = read(destination / "data.json")
    print(index, row["key"], data["outcome"], flush=True)

(root / "formal").mkdir(exist_ok=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for _ in pool.map(run, rows):
        pass

