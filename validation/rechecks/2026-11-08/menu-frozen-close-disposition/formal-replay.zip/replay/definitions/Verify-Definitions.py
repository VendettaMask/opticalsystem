import csv
import hashlib
import json
import math
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from scipy.interpolate import CubicSpline


repo = Path.cwd()
root = Path(__file__).resolve().parent
base = root.parent
evidence = repo/'validation/rechecks'
corpus = repo/'artifacts/zemax-sequential-corpus/20261021/full-v1'
indices = (600, 604, 690, 694, 825, 953, 954)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return {'path': str(path.relative_to(repo)), 'sha256': sha(path.read_bytes())}


def decoded(raw):
    return raw.decode('utf-16' if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig')


def measures(work, ref, gate):
    work, ref = np.asarray(work, float), np.asarray(ref, float)
    assert work.shape == ref.shape and work.size
    finite = np.isfinite(work)
    assert np.array_equal(finite, np.isfinite(ref)) and finite.any()
    diff = abs(work[finite]-ref[finite])
    nrmse = float(np.sqrt(np.mean(diff*diff))/max(np.max(abs(ref[finite])), gate['absolute']))
    pointwise = bool(np.all(diff <= gate['absolute']+gate['relative']*abs(ref[finite])))
    pass_nrmse = work.size > 1 and nrmse <= gate['nrmse']
    verdict = 'Pass' if pointwise or pass_nrmse else 'Close' if nrmse <= gate['closeNrmse'] else 'Difference'
    return {'verdict': verdict, 'coverage': 1, 'coordinates': int(work.size), 'finitePairs': int(finite.sum()),
            'maxAbsolute': float(diff.max()), 'nrmse': nrmse, 'pointwisePass': pointwise, 'nrmsePass': pass_nrmse}


def curve(series, x, y, gate, units):
    assert tuple(series[k] for k in ('xQuantity', 'xUnit', 'yQuantity', 'yUnit')) == units
    work = np.array([[p['x'], p['y']] for p in series['points']], float)
    assert work.shape[0] == len(x) and np.allclose(work[:, 0], x, rtol=0, atol=1e-12)
    return measures(work[:, 1], y, gate)


def fans(work, native, gate):
    assert not native['messages'] and len(work['plotPanes']) == len(native['dataSeries']) == 2
    output = {}
    for axis, pane, ref in zip(('tangential','sagittal'), work['plotPanes'], native['dataSeries']):
        series, = pane['series']
        assert series['xAxisLabel'] == ('P_y' if axis == 'tangential' else 'P_x')
        assert ref['description'].startswith('子午' if axis == 'tangential' else '弧矢')
        output[axis] = curve(series, ref['x'], [r[0] for r in ref['y']], gate,
                             ('PupilCoordinate','Dimensionless','WavefrontError','Wave'))
    return output


def pass_metrics(items):
    if 'verdict' in items:
        return items['verdict'] == 'Pass'
    return all(pass_metrics(v) for v in items.values())


cohort = {row['index']: row for row in read(base/'cohort.json')}
frozen = evidence/'2026-11-08/parallel-focal-fft-applicability/frozen-replay.csv'
assert sha(frozen.read_bytes()) == read(frozen.with_name('summary.json'))['frozenReplaySha256']
with frozen.open(encoding='utf-8-sig', newline='') as f:
    original = {int(row['index']): row for row in csv.DictReader(f) if int(row['index']) in indices}
formal_comparison = base/'frozen-compare/results.json'
replay_receipt = base/'original-replay.json'
formal_rows = {row['index']: row for row in read(formal_comparison)}
replayed = {row['index']: row for row in read(replay_receipt)}


offaxis = evidence/'2026-11-04/offaxis-opd-sampling'
archive_index = {e['logicalPath']: e for e in read(offaxis/'archive-index.json')}
grin = evidence/'2026-11-08/grin-first-order-reference'
axicon = evidence/'2026-11-08/axicon-continuum'
illumination = evidence/'2026-11-07/residual-reference-followup/axicon-axis'
policy_path = repo/'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'
rows = {}


for i in indices:
    row = cohort[i]
    folder = base/'formal'/f'{i:04}'
    request = read(folder/'request.json')
    original_path = Path(row['job'])
    previous = read(original_path)
    assert dict(request, outputDirectory=previous['outputDirectory']) == previous
    req = request['request']
    provenance = read(folder/'provenance.json')
    assert provenance['executorId'] == 'Application.WorkbenchRuntime.BuildAnalysisData/v1'
    assert provenance['requestFingerprint'] == original[i]['requestFingerprint'] and original[i]['conclusion'] == 'Close'
    assert provenance['snapshotSha256'] == sha(Path(request['snapshotPath']).read_bytes())
    execution = read(folder/'execution.json')
    assert execution['exitCode'] == 0 and execution['originalRequestSha256'] == sha(original_path.read_bytes())
    data = read(folder/'data.json')
    assert data['outcome'] == 'Success'
    native_case, = (corpus/'analyses').glob(f'{i:04}-*')
    native_path = native_case/'native/data.json'
    native = read(native_path)
    assert not native['messages']
    source = corpus/'sources'/row['lens']
    gates = row['settings']['quantities']
    values = data['values']
    out = {'index': i, 'lens': row['lens'], 'analysis': row['key'], 'configuration': row['configuration'],
           'frozenVerdict': 'Close', 'formalOutcome': data['outcome'], 'formalProvenance': provenance,
           'workerSha256': execution['workerSha256'], 'originalRequest': identity(original_path),
           'formalData': identity(folder/'data.json'), 'nativeSource': identity(source),
           'frozenNativeData': identity(native_path), 'originalPolicy': gates, 'references': []}
    official = formal_rows[i]
    replay = replayed[i]
    assert official['conclusion'] == 'Close' and official['requestFingerprint'] == provenance['requestFingerprint']
    assert official['coreSha256'] == provenance['codeFingerprint'].split(':')[-1]
    assert replay['dataSha256'] == out['formalData']['sha256'] and replay['codeFingerprint'] == provenance['codeFingerprint']
    manifest_member = 'run/'+native_path.relative_to(corpus).as_posix()
    assert replay['frozenNativeFiles'][manifest_member] == out['frozenNativeData']['sha256']
    out['officialOriginalComparison'] = {'verdict': official['conclusion'], 'metrics': official['metrics'],
                                         'workbenchPayloadByteIdentical': replay['workbenchPayloadByteIdentical']}
    rows[str(i)] = out

    if i < 800:
        geometry = [r for r in read(offaxis/'equivalent-source-controls.json') if r['originalSourceSha256'] == out['nativeSource']['sha256']]
        assert geometry and all(r['positionDirectionOperands'] == 540 and r['maximumPositionDirectionDifference'] == 0
                                and r['onlyPhaseAlgorithmFlagChanged'] for r in geometry)
        out['references'].extend([identity(offaxis/f) for f in ('archive-index.json','equivalent-source-controls.json','plane-controls.json')])
        out['priorGeometryChecks'] = geometry
        controlled_modes = {}
        for record in geometry:
            mode = record['mode']
            prefix = f'runs/offaxis-opd-native-mode{mode}{"-example5" if i >= 690 else ""}-20261104/'
            result_paths = [prefix+f'paraxial-mode{mode}.zmx', prefix+f'plot-{i}/captured-settings.json', prefix+f'plot-{i}/data.json']
            payloads = []
            for logical in result_paths:
                ref = archive_index[logical]
                archive = (offaxis/ref['archive']).resolve()
                with ZipFile(archive) as z:
                    raw = z.read(ref['entry'])
                assert sha(raw) == ref['sha256'] and len(raw) == ref['length']
                out['references'].append({'archive': str(archive.relative_to(repo)), 'member': ref['entry'], 'sha256': ref['sha256'], 'logicalPath': logical})
                payloads.append(raw)
            prescription, settings, control = payloads
            assert sha(prescription) == record['controlledSourceSha256']
            source_lines, changed = decoded(source.read_bytes()).splitlines(), decoded(prescription).splitlines()
            assert len(source_lines) == len(changed)
            assert [(a.strip(), b.strip()) for a,b in zip(source_lines,changed) if a != b] == [('PARM 2 1',f'PARM 2 {mode}')]
            captured = json.loads(settings)
            assert req == {k: captured['request'][k] for k in req}
            assert captured['selectors'] == {'Field': 3, 'Surface': 0, 'Wavelength': req['wavelength']}
            controlled_modes[str(mode)] = json.loads(control)
        if len(controlled_modes) == 2:
            assert controlled_modes['0']['dataSeries'] == controlled_modes['3']['dataSeries']
        gate = gates['WavefrontError']
        out['frozenNativeDirectLatticeDiagnostic'] = fans(data, native, gate)
        out['equivalentMetrics'] = {mode: fans(data, ref, gate) for mode, ref in controlled_modes.items()}
        out['modeSpecificEquivalence'] = 'PerfectCollimationPhaseReference/v1 on the exact original conjugate; the independent native copy changes only PARAXIAL phase mode while positions and directions stay identical.'
        out['archivedNativeModesCompared'] = list(controlled_modes)
    elif i == 825:
        verification = read(grin/'verification.json')
        raw_path = grin/'direct-grin.json'
        raw = read(raw_path)
        assert sha(raw_path.read_bytes()) == verification['nativeRayCaptureSha256']
        assert out['nativeSource']['sha256'] == verification['sourceSha256'] == verification['frozenSourceSha256']
        assert provenance['snapshotSha256'] == verification['snapshotSha256']
        assert provenance['requestFingerprint'] == verification['canonicalRequestFingerprint']
        assert out['frozenNativeData']['sha256'] == verification['frozenNativeReportSha256']
        assert sha(policy_path.read_bytes()) == verification['policySha256']
        assert req['configuration'] == verification['configuration'] == 1 and req['wavelength'] == raw['wavelength'] == 1
        assert verification['originalTolerances'] == gates
        out['references'].extend([identity(grin/f) for f in ('verification.json','model.json','direct-grin.json','capture-receipt.json')])
        distances = []
        for record, archived in zip(raw['records'], verification['records']):
            front, rear = [s['rays'] for s in record['surfaces']]
            assert len(front) == len(rear) == len(raw['launch'])
            assert all(a['number'] == b['number'] and a['error'] == a['vignette'] == b['error'] == b['vignette'] == 0
                       for a,b in zip(front,rear))
            heights, slopes = [], []
            for k in range(0,12,2):
                h = front[k+1]['y']
                assert front[k]['y'] == -h and front[k]['m'] == front[k+1]['m'] == 0
                heights.append(h)
                slopes.append((rear[k+1]['m']/rear[k+1]['n']-rear[k]['m']/rear[k]['n'])/(2*h))
            assert all(h == 2*l for h,l in zip(heights, heights[1:]))
            pupil = front[-1]['y']-front[-2]['y']
            direct = -3/(4*slopes[-1]-slopes[-2])
            previous_height = -3/(4*slopes[-2]-slopes[-3])
            assert abs(direct-archived['directRayEfl']) < 1e-13 and pupil == archived['directRayEpdi']
            distances.append((direct, previous_height, pupil))
        assert len(distances) == 4
        efl, height, pupil = distances[-1]
        n, g = raw['surface1BaseIndex'], math.sqrt(-2*raw['surface1RadialQuadratic']/raw['surface1BaseIndex'])
        analytic = 1/(n*g*math.sin(raw['rodLength']*g))
        assert abs(efl-analytic) < 1e-12
        def pair(a, b):
            return {key: measures([a[k]], [b[k]], gates[key]) for k,key in enumerate(('EffectiveFocalLength','FNumber'))}
        work = tuple(values[key] for key in ('EffectiveFocalLength','FNumber'))
        model = (efl,efl/pupil)
        old = tuple(native['scalars'][key] for key in ('EffectiveFocalLength','FNumber'))
        builtin_efl = raw['records'][-1]['effl']
        builtin = (builtin_efl,builtin_efl/raw['records'][-1]['entrancePupilDiameter'])
        out['frozenNativeDirectLatticeDiagnostic'] = pair(work,old)
        out['finestNativeBuiltInOperandMetrics'] = pair(work,builtin)
        assert all(x['verdict'] == 'Close' for x in out['frozenNativeDirectLatticeDiagnostic'].values())
        assert all(x['verdict'] == 'Close' for x in out['finestNativeBuiltInOperandMetrics'].values())
        out['equivalentMetrics'] = {'directRays': pair(work,model), 'analyticGradient1': pair(work,(analytic,analytic/pupil)),
                                    'independentStepConvergence': pair((distances[-2][0],distances[-2][0]/distances[-2][2]),model),
                                    'independentHeightConvergence': pair((height,height/pupil),model)}
        out['values'] = {'workbench': work, 'nativeDirectRay': model, 'nativeBuiltInOperand': builtin, 'analyticEflMm': analytic, 'independentEpdiMm': pupil}
        out['modeSpecificEquivalence'] = 'Original prescription and aperture. Native direct-ray symmetric height derivatives and the analytic Gradient 1 on-axis limit; the original and refined native built-in EFFL operands remain Close.'
    elif i == 953:
        gate = gates['Modulation']
        proof = read(axicon/'verification.json')
        axicon_id = read(axicon/'identity.json')
        assert proof['continuumChecksPass'] and axicon_id['sourceLensSha256'] == out['nativeSource']['sha256']
        assert axicon_id['snapshotSha256'] == provenance['snapshotSha256']
        capsule = identity(repo/axicon_id['nativeRayPhaseLocalPath'])
        assert capsule['sha256'] == axicon_id['nativeRayPhaseSha256']
        out['references'].extend([identity(axicon/f) for f in ('verification.json','identity.json','native-results.json')]+[capsule])
        checked_folder = root/'0953-checked'
        checked_req = read(checked_folder/'request.json')
        settings = checked_req['request']['workbenchSettings'].copy()
        assert settings.pop('UseCheckedFocusedPupil') == 'True'
        assert dict(checked_req['request'], workbenchSettings=settings) == req and checked_req['snapshotPath'] == request['snapshotPath']
        result = read(checked_folder/'data.json')
        checked_prov = read(checked_folder/'provenance.json')
        assert checked_prov['codeFingerprint'] == provenance['codeFingerprint'] and checked_prov['snapshotSha256'] == provenance['snapshotSha256']
        assert result['outcome'] == 'Success'
        checked_values = result['values']
        assert checked_values['Method'] == 'Huygens' and checked_values['SpatialFrequency'] == 50
        assert checked_values['ImageDeltaMicrometers'] == .25 and checked_values['ImageSampling'] == 32 and checked_values['DeltaFocus'] == .01
        assert checked_values['NumberOfSteps'] == 5 and checked_values['HuygensFrequencySampling'] == 'NaturalCubicEndpointSpan'
        stages = checked_values['FocusedHuygensSampling']
        assert len(stages) == 5 and all(s['coarseNodes'] < s['fineNodes'] and 0 < s['maximumPhaseStepWaves'] < .5 for s in stages)
        x = np.linspace(-.01,.01,101)
        focus = proof['focusMillimeters']
        raw_tiers = read(axicon/'native-results.json')
        assert [t['nodeCount'] for t in raw_tiers] == [98292,131072]
        tier = []
        for stage in raw_tiers:
            assert [r['focus'] for r in stage['results']] == focus
            tier.append([CubicSpline(focus,[r[key] for r in stage['results']],bc_type='natural')(x) for key in ('mtfT','mtfS')])
        units = ('Defocus','Millimeter','Modulation','Dimensionless')
        modes = ('tangential','sagittal')
        native_curve, = native['dataSeries']
        assert np.allclose(native_curve['x'],x,rtol=0,atol=1e-12)
        out['frozenNativeDirectLatticeDiagnostic'] = {name: curve(data['plotSeries'][k],x,[y[k] for y in native_curve['y']],gate,units) for k,name in enumerate(modes)}
        out['equivalentMetrics'] = {'currentCheckedAgainstIndependent': {name: curve(result['plotSeries'][k],x,tier[-1][k],gate,units) for k,name in enumerate(modes)},
                                    'independentNativeConvergence': {name: measures(tier[0][k],tier[1][k],gate) for k,name in enumerate(modes)}}
        out['fixedVersusIndependentContinuum'] = {name: curve(data['plotSeries'][k],x,tier[-1][k],gate,units) for k,name in enumerate(modes)}
        out['checkedSampling'] = stages
        out['checkedRequest'] = identity(checked_folder/'request.json')
        out['checkedFormalData'] = identity(checked_folder/'data.json')
        out['checkedProvenance'] = checked_prov
        out['modeSpecificEquivalence'] = 'Explicit checked radial planar Huygens continuum, retaining the original image grid, 50 cycles/mm, five focus knots, and both complete 101-coordinate output curves.'
    else:
        gate = gates['Irradiance']
        proof = read(illumination/'verification.json')
        ops_path = illumination/'operands.json'
        assert proof['sourceSha256'] == out['nativeSource']['sha256'] and proof['nativeOperandsSha256'] == sha(ops_path.read_bytes())
        assert req['field'] == req['wavelength'] == 1 and req['definedFields'] == [[0,0]]
        assert values['MaxFieldDegrees'] == 0 and values['RayDensity'] == values['EffectiveRayDensity'] == 20
        series, = data['plotSeries']
        assert (series['xQuantity'],series['xUnit'],series['yQuantity'],series['yUnit']) == ('FieldAngle','Degree','Irradiance','Dimensionless')
        assert len(series['points']) == int(req['workbenchSettings']['FieldDensity']) == 21
        assert {p['x'] for p in series['points']} == {0} and len({p['y'] for p in series['points']}) == 1
        assert min(values['RawProjectedCosineArea']) > 0 and min(values['EffectiveFNumbers']) > 0
        native_curve, = native['dataSeries']
        assert len(native_curve['x']) == 21 and native_curve['x'][0] == 0 and native_curve['x'][-1] == 1e-6
        assert all(a < b for a,b in zip(native_curve['x'], native_curve['x'][1:]))
        frozen_origin = native_curve['y'][0][0]
        work = series['points'][0]['y']
        ops = read(ops_path)
        assert all(o['field'] == o['wave'] == 1 and o['polarization'] == 0 for o in ops)
        efno, = [o['value'] for o in ops if o['code'] == 'EFNO' and o['density'] == values['RayDensity']]
        reli, = [o['value'] for o in ops if o['code'] == 'RELI' and o['density'] == values['RayDensity']]
        assert {o['value'] for o in ops if o['code']=='RELI'} == {1}
        out['references'].extend([identity(illumination/f) for f in ('verification.json','model.json','operands.json')])
        out['frozenAxisOnlyNonEquivalentMetric'] = measures([work],[frozen_origin],gate)
        out['frozenNativeNormalizationDomainDegrees'] = [0,1e-6]
        out['workbenchUniquePhysicalCoordinatesDegrees'] = [0]
        out['plotCopiesOfSingleField'] = len(series['points'])
        out['equivalentMetrics'] = {'uniqueAxialFieldNativeRELI': measures([work],[reli],gate)}
        out['supplementalEfnoControl'] = {'native': efno, 'workbench': values['EffectiveFNumbers'][0],
                                          'relativeDifference': abs(values['EffectiveFNumbers'][0]-efno)/efno}
        assert out['supplementalEfnoControl']['relativeDifference'] < 5e-5
        out['modeSpecificEquivalence'] = 'Unique physical axial field, original density 20. Native RELI at that one field matches exactly. The frozen graph normalizes over an appended 0–1e-6 degree interval and has a different physical domain.'

    assert pass_metrics(out['equivalentMetrics'])
    out['equivalentVerdict'] = 'Pass'


(root/'receipt.json').write_text(json.dumps({'frozenReplay': identity(frozen),
    'officialCurrentOriginalComparison': identity(formal_comparison), 'officialOriginalReplayReceipt': identity(replay_receipt),
    'rows': rows}, indent=2)+'\n',encoding='utf-8')
for i,row in rows.items():
    print(i,row['frozenVerdict'],row['equivalentVerdict'])
