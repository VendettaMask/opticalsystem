import hashlib
import json
from pathlib import Path
import subprocess
import time


repo = Path.cwd()
root = repo/'artifacts/validation/menu-19-close-20261108'
out = root/'dense'
worker = repo/'tools/OpticalSystemDesign.ZemaxComparison/bin/Release/net10.0/OpticalSystemDesign.ZemaxComparison.dll'
core = worker.with_name('OpticalSystemDesign.Core.dll')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


for index, tiers in {347: (128, 256), 2160: (512, 1024)}.items():
    original = root/'formal'/f'{index:04d}'/'request.json'
    for size in tiers:
        dest = out/'current'/f'{index}-{size}'
        dest.mkdir(parents=True, exist_ok=True)
        request = read(original)
        request['outputDirectory'] = str(dest)
        selected = request['request']
        original_size = selected['pupilSampling']
        selected['pupilSampling'] = size
        for alias in ('PupilSampling', 'Sampling'):
            if selected['workbenchSettings'].get(alias) == str(original_size):
                selected['workbenchSettings'][alias] = str(size)
        job = dest/'request.json'
        write(job, request)
        start = time.monotonic()
        result = subprocess.run(['dotnet', str(worker), '--workbench-worker', str(job)], stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', timeout=240)
        data = read(dest/'data.json') if result.returncode == 0 else {}
        write(dest/'execution.json', {'index': index, 'pupilSampling': size, 'coreSha256': sha(core), 'workerSha256': sha(worker),
            'snapshotSha256': sha(Path(request['snapshotPath'])), 'originalJobSha256': sha(original), 'jobSha256': sha(job),
            'exitCode': result.returncode, 'seconds': time.monotonic()-start, 'outcome': data.get('outcome'),
            'reason': data.get('outcomeReason'), 'dataSha256': sha(dest/'data.json') if data else None, 'output': result.stdout})
        assert result.returncode == 0 and data['outcome'] == 'Success', result.stdout
        print(index, size, data['outcome'], flush=True)
