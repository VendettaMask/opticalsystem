import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile


repo = Path.cwd()
root = repo/'artifacts/validation/menu-19-close-20261108'
out = root/'dense'
frozen = repo/'validation/rechecks/2026-11-08/parallel-focal-fft-applicability/frozen-replay.csv'
grid = repo/'validation/rechecks/2026-11-06/grid-grin-diffraction-reference'
compare = repo/'artifacts/validation/menu-31-differences-20261108/diffraction/compare/bin/Release/net10.0/Compare.dll'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stats(row):
    metrics = row['metrics']
    return {'comparison': row['id'], 'verdict': row['status'], 'nrmse': max(m['nrmse'] for m in metrics),
            'maxAbs': max(m['maxAbsolute'] for m in metrics), 'coverage': min(m['coverage'] for m in metrics),
            'points': [m['count'] for m in metrics], 'gateBranches': row['gateBranches']}


def execution(directory, expected_sampling=None, original=None):
    job = read(directory/'request.json')
    result = read(directory/'data.json')
    record = read(directory/'execution.json')
    provenance = read(directory/'provenance.json')
    assert provenance['executorId'] == 'Application.WorkbenchRuntime.BuildAnalysisData/v1'
    assert result['outcome'] == 'Success' and record['exitCode'] == 0
    assert provenance['snapshotSha256'] == sha(Path(job['snapshotPath']))
    if expected_sampling is not None:
        assert sha(directory/'request.json') == record['jobSha256'] and sha(directory/'data.json') == record['dataSha256']
        a, b = original.copy(), job['request'].copy()
        assert b.pop('pupilSampling') == expected_sampling
        previous = a.pop('pupilSampling')
        changed_settings = b.pop('workbenchSettings')
        settings = a.pop('workbenchSettings')
        assert a == b and changed_settings == {key: str(expected_sampling) if key in ('PupilSampling', 'Sampling') and value == str(previous) else value for key, value in settings.items()}
    return {'request': str((directory/'request.json').relative_to(repo)), 'requestSha256': sha(directory/'request.json'),
            'dataSha256': sha(directory/'data.json'), 'provenance': provenance, 'seconds': record['seconds'],
            'pupilSampling': job['request']['pupilSampling']}


def reference_control():
    archive = grid/'native-controls.zip'
    index = {row['path']: row for row in read(grid/'native-controls.json')['members']}
    base = 'refinement/captures/505-centroid-step0.001'
    source = {}
    blobs = {}
    with ZipFile(archive) as z:
        for name in ('captured-settings.json', 'data.json', 'data.txt'):
            member = f'{base}/{name}'
            raw = z.read(member)
            digest = hashlib.sha256(raw).hexdigest()
            assert digest == index[member]['sha256']
            source[name] = {'archive': str(archive.relative_to(repo)), 'member': member, 'sha256': digest}
            blobs[name] = raw
    assert json.loads(blobs['captured-settings.json'])['properties']['ReferTo'] == 'Centroid'
    report = blobs['data.txt'].decode('utf-16')
    assert '参考: 主光线.' in report
    series = json.loads(blobs['data.json'])['dataSeries'][0]
    assert series['x'][0] == 0
    return {'apiEnum': 'Centroid', 'physicalReportReference': 'ChiefRay',
            'onAxisMicrometers': series['y'][0][0], 'files': source}


with frozen.open(encoding='utf-8-sig', newline='') as f:
    fixed = {int(row['index']): row for row in csv.DictReader(f) if row['conclusion'] == 'Close'}
assert len(fixed) == 19
cohort = {row['index']: row for row in read(root/'cohort.json')}
comparisons = read(out/'comparisons.json')
assert len(comparisons) == 22
native = read(out/'native-references.json')
rows = []
for index, tiers in {347: (128, 256), 498: (), 505: (), 2160: (512, 1024)}.items():
    model = cohort[index]
    formal = root/'formal'/f'{index:04d}'
    original = execution(formal)
    assert original['provenance']['requestFingerprint'] == fixed[index]['requestFingerprint']
    runs = [r for r in comparisons if r['index'] == index]
    original_comparison, *checks = runs
    assert original_comparison['id'] == 'current-original-vs-frozen-native' and original_comparison['status'] == 'Close'
    assert all(r['status'] == 'Pass' and stats(r)['coverage'] == 1 for r in checks)
    fine_steps = ['0.005', '0.001'] if index == 498 else ['0.005', '0.001', '0.0005'] if index == 505 else []
    if tiers:
        lo, hi = tiers
        compare_key = f'current-{hi}-vs-native-{hi}'
        current_key = f'current-{lo}-vs-current-{hi}'
        current_receipts = [execution(out/'current'/f'{index}-{tier}', tier, read(formal/'request.json')['request']) for tier in tiers]
        current_convergence = stats(next(r for r in checks if r['id'] == current_key))
    else:
        compare_key = f'current-original-vs-native-{fine_steps[-1]}'
        current_receipts = [original]
        current_convergence = None
    assert all(r['provenance']['codeFingerprint'] == original['provenance']['codeFingerprint'] for r in current_receipts)
    strongest = next(r for r in checks if r['id'] == compare_key)
    domain = None
    if index == 505:
        m = strongest['metrics'][0]
        assert m['count'] == 1 and m['worstX'] == 0 and m['unit'] == 'Micrometer' and strongest['gateBranches'][0]['pointwisePass']
        assert read(formal/'request.json')['request']['definedFields'] == [[0, 0]]
        domain = {'type': 'physical single-field scalar', 'field': [0, 0], 'coverage': 1,
                  'reference': 'Centroid', 'selectedWavelengthIndex': 2, 'wavelengthMicrometers': .55,
                  'workbenchMicrometers': m['extra']['workbench'], 'nativeMicrometers': m['extra']['zemax'],
                  'nativeEnumReported': 'ChiefRay', 'enumInversionControl': reference_control(),
                  'pointDomainNormalizations': strongest['normalizations']}
    rows.append({'index': index, 'lens': model['lens'], 'analysis': model['key'], 'frozenVerdict': 'Close',
                 'requestFingerprint': fixed[index]['requestFingerprint'], 'originalReplay': stats(original_comparison),
                 'originalReplayIdentity': original, 'numericVerdict': 'Pass', 'status': 'ConfirmedRefinedPassFrozenClose',
                 'coverage': stats(strongest)['coverage'], 'highestCrossComparison': stats(strongest),
                 'currentConvergence': current_convergence, 'nativeConvergence': [stats(r) for r in checks if r['id'].startswith('native-')],
                 'allRefinedComparisons': [stats(r) for r in checks], 'currentPupilSampling': list(tiers) or [original['pupilSampling']],
                 'nativePupilSampling': list(tiers) or ([32] if index == 498 else None), 'nativeStepsMm': list(map(float, fine_steps)),
                 'domain': domain, 'originalGates': model['settings']['quantities'],
                 'currentReferences': current_receipts, 'nativeReferences': [r for r in native if r['index'] == index]})

fingerprints = {r['originalReplayIdentity']['provenance']['codeFingerprint'] for r in rows}
assert len(fingerprints) == 1
payload = {'rows': rows, 'scope': 'Four frozen Close requests of the 95-menu matrix', 'refinedPasses': len(rows),
           'frozenCloseReproduced': len(rows), 'comparisonCount': len(comparisons), 'codeFingerprint': next(iter(fingerprints)),
           'frozenMatrixSha256': sha(frozen), 'comparisonResultsSha256': sha(out/'comparisons.json'),
           'comparatorSha256': sha(compare), 'freshNativeCapture': False}
(out/'receipt.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print('Sealed', len(rows), 'cases', sha(out/'receipt.json'))
