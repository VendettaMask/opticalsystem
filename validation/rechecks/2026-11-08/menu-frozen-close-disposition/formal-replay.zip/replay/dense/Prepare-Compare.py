import hashlib
import json
from pathlib import Path
from zipfile import ZipFile


repo = Path.cwd()
root = repo/'artifacts/validation/menu-19-close-20261108'
out = root/'dense'
rechecks = repo/'validation/rechecks'
dual = rechecks/'2026-11-07/residual-reference-followup'
twyman = rechecks/'2026-11-02/huygens-common'
grid = rechecks/'2026-11-06/grid-grin-diffraction-reference'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def digest(data):
    return hashlib.sha256(data).hexdigest()


archive_index = {r['logicalPath']: r for r in read(twyman/'archive-index.json')}
grid_index = read(grid/'native-controls.json')
grid_members = {r['path']: r for r in grid_index['members']}
grid_captures = {r['id']: r for r in grid_index['captures']}
cohort = {r['index']: r for r in read(root/'cohort.json')}
archive = grid/'native-controls.zip'
assert digest(archive.read_bytes()) == grid_index['archiveSha256']


def zipped(path, name, sha, size):
    with ZipFile(path) as z:
        data = z.read(name)
    assert len(data) == size and digest(data) == sha
    return data, {'archive': str(path.relative_to(repo)), 'member': name}


def grid_member(name):
    entry = grid_members[name]
    return zipped(archive, name, entry['sha256'], entry['bytes'])


def payload(index, tier, name):
    if index == 347:
        path = dual/'native'/f'{index}-{tier}'/name
        return path.read_bytes(), {'path': str(path.relative_to(repo))}
    if index == 2160:
        r = archive_index[f'psf-convergence-corrected/{index}/{tier}/native/{name}']
        return zipped(twyman/r['archive'], r['entry'], r['sha256'], r['length'])
    case = f'{index}-step{tier}'
    capture = grid_captures[case]
    return grid_member(f'{capture["stage"]}/captures/{case}/{name}')


def step_receipt(index, step, original_native):
    case = f'{index}-step{step}'
    capture = grid_captures[case]
    assert capture['captureStatus']['exitCode'] == 0 and capture['nativeSettingsEqualToOriginal']
    model, origin = grid_member(f'sources/grid-{step}.ZMX')
    frozen_path = Path(read(original_native/'request.json')['input'])
    frozen = frozen_path.read_bytes()
    assert digest(model) == capture['inputSha256']
    a, b = frozen.decode('utf-16').splitlines(), model.decode('utf-16').splitlines()
    assert len(a) == len(b)
    changes = [(i+1, x, y) for i, (x, y) in enumerate(zip(a, b)) if x != y]
    assert len(changes) == 1 and changes[0][1].strip() == 'PARM 1 1' and changes[0][2].strip() == f'PARM 1 {step}'
    line = changes[0][0]
    assert 'TYPE GRINSU11' in '\n'.join(a[line-20:line])
    return {'stepMm': float(step), 'sourceSha256': digest(model), 'originalSourceSha256': digest(frozen),
            'source': origin, 'onlyLensLineChange': changes[0], 'nativeCapture': capture}


def stage(index, tier, original, original_native):
    directory = out/'native'/f'{index}-{tier}'
    directory.mkdir(parents=True, exist_ok=True)
    files = {}
    names = ('data.json', 'captured-settings.json') if index == 347 else ('data.json', 'data.txt', 'captured-settings.json')
    for name in names:
        data, origin = payload(index, tier, name)
        (directory/name).write_bytes(data)
        files[name] = {**origin, 'sha256': digest(data), 'bytes': len(data)}
    captured = read(directory/'captured-settings.json')
    request = captured['request']
    for key in ('canonicalAnalysisKey', 'configuration', 'field', 'wavelength', 'reference', 'maximumFieldRadius', 'definedFields'):
        assert original[key] == request[key], (index, tier, key, original[key], request[key])
    physical = captured['properties']
    proof = {'index': index, 'tier': tier, 'files': files, 'capturedProperties': physical, 'capturedSelectors': captured['selectors']}
    if index in (347, 2160):
        assert physical['PupilSampleSize'] == f'S_{tier}x{tier}' and request['pupilSampling'] == tier
        assert physical['ImageSampleSize'] == 'S_32x32' and physical['ImageDelta'] == .25
    else:
        base = read(original_native/'captured-settings.json')
        assert physical == base['properties'] and captured['selectors'] == base['selectors']
        proof.update(step_receipt(index, tier, original_native))
        assert files['data.json']['sha256'] == proof['nativeCapture']['nativeDataSha256']
        if index == 505:
            report = (directory/'data.txt').read_bytes().decode('utf-16')
            assert '参考: 质心.' in report and request['definedFields'] == [[0, 0]] and request['maximumFieldRadius'] == 0
            proof['physicalReferenceFromReport'] = 'Centroid'
    return {'kind': 'native', 'path': str(directory/'data.json')}, proof


def core(directory):
    assert read(directory/'data.json')['outcome'] == 'Success'
    return {'kind': 'core', 'path': str(directory/'data.json'), 'request': str(directory/'request.json')}


plans = []
references = []
for index, tiers in {347: (128, 256), 498: ('0.005', '0.001'), 505: ('0.005', '0.001', '0.0005'), 2160: (512, 1024)}.items():
    formal = root/'formal'/f'{index:04d}'
    original_native = Path(cohort[index]['legacyPath'])/'native'
    original = read(formal/'request.json')['request']
    original_core = core(formal)
    natives = {}
    for tier in tiers:
        natives[tier], proof = stage(index, tier, original, original_native)
        references.append(proof)

    def add(name, left, right, basis):
        plans.append({'index': index, 'id': name, 'request': basis['request'], 'workbenchBasis': basis['path'],
                      'settings': cohort[index]['settings'], 'left': left, 'right': right})

    add('current-original-vs-frozen-native', original_core, {'kind': 'native', 'path': str(original_native/'data.json')}, original_core)
    cores = {tier: core(out/'current'/f'{index}-{tier}') for tier in tiers} if index in (347, 2160) else {}
    basis = cores[tiers[-1]] if cores else original_core
    for a, b in zip(tiers[:-1], tiers[1:]):
        add(f'native-{a}-vs-native-{b}', natives[a], natives[b], basis)
    if cores:
        lo, hi = tiers
        add(f'current-{lo}-vs-current-{hi}', cores[lo], cores[hi], basis)
        for tier in tiers:
            add(f'current-{tier}-vs-native-{tier}', cores[tier], natives[tier], basis)
        add(f'current-{lo}-vs-native-{hi}', cores[lo], natives[hi], basis)
    else:
        for tier in tiers:
            add(f'current-original-vs-native-{tier}', original_core, natives[tier], basis)

write(out/'native-references.json', references)
write(out/'plans.json', plans)
