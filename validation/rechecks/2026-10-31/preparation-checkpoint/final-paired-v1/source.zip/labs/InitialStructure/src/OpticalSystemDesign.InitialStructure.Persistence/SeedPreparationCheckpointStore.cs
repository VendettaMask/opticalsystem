using System.Text.Json;
using System.Text.Json.Serialization;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.InitialStructure.Contracts;
using OpticalSystemDesign.InitialStructure.Engine;

namespace OpticalSystemDesign.InitialStructure.Persistence;

/// <summary>Preparation-only atomic revisioned files. A cancelled computation must finish durable saving.</summary>
public sealed class SeedPreparationCheckpointStore
{
    private static readonly JsonSerializerOptions Json = new()
    {
        PropertyNamingPolicy=JsonNamingPolicy.CamelCase,NumberHandling=JsonNumberHandling.AllowNamedFloatingPointLiterals,
        Converters={new JsonStringEnumConverter(JsonNamingPolicy.CamelCase)}
    };

    public async ValueTask SaveAsync(SeedPreparationCheckpoint state,string path,long expectedRevision,CancellationToken token=default)
    {
        SeedPreparationSearch.Validate(state);
        RunDirectoryStore.EnsureSafeIdentifier(state.RunId,nameof(state));
        if(state.Revision!=expectedRevision+1)throw new InvalidDataException("Preparation revision must advance exactly once.");
        path=Path.GetFullPath(path);Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await using var lease=new FileStream(path+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
        var checksum=ContentFingerprint.Compute(state);
        if(File.Exists(path))
        {
            var previous=await LoadAsync(path,token);
            if(previous.RunId!=state.RunId||previous.PlanFingerprint!=state.PlanFingerprint||previous.ProtocolFingerprint!=state.ProtocolFingerprint)
                throw new InvalidDataException("Cannot replace another preparation or alter its original task.");
            if(previous.Revision==state.Revision&&ContentFingerprint.Compute(previous)==checksum)return;
            if(previous.Revision!=expectedRevision)throw new InvalidDataException("Stale preparation checkpoint writer.");
            var a=previous.Consumed;var b=state.Consumed;
            if(b.FunctionEvaluations<a.FunctionEvaluations||b.GradientEvaluations<a.GradientEvaluations||b.ValidationEvaluations<a.ValidationEvaluations
                ||b.MatrixEvaluations<a.MatrixEvaluations||b.GeometryProbes<a.GeometryProbes||b.TracedRays<a.TracedRays||b.Elapsed<a.Elapsed
                ||state.Candidates.Length<previous.Candidates.Length||state.Phases.Length<previous.Phases.Length
                ||ContentFingerprint.Compute(state.Candidates.Take(previous.Candidates.Length).ToArray())!=ContentFingerprint.Compute(previous.Candidates.ToArray())
                ||ContentFingerprint.Compute(state.Phases.Take(previous.Phases.Length).ToArray())!=ContentFingerprint.Compute(previous.Phases.ToArray())
                ||state.LostReservations<previous.LostReservations
                ||state.Stage==previous.Stage&&state.Cursor<previous.Cursor
                ||previous.Stage=="Finished"&&ContentFingerprint.Compute(state)!=ContentFingerprint.Compute(previous))
                throw new InvalidDataException("Preparation history and consumed budgets cannot be rolled back or rewritten.");
        }
        else if(expectedRevision!=0)throw new InvalidDataException("Missing previous preparation checkpoint revision.");
        await BoundedFile.WriteAtomicAsync(path,InitialStructureLimits.MaximumManifestBytes,"seed preparation checkpoint",
            (stream,ct)=>JsonSerializer.SerializeAsync(stream,new Envelope(state,checksum),Json,ct),token);
    }

    public async Task<SeedPreparationCheckpoint> LoadAsync(string path,CancellationToken token=default)
    {
        var bytes=await BoundedFile.ReadAllBytesAsync(path,InitialStructureLimits.MaximumManifestBytes,"seed preparation checkpoint",token);
        Envelope saved;
        try{saved=JsonSerializer.Deserialize<Envelope>(bytes,Json)??throw new InvalidDataException("Empty preparation checkpoint.");}
        catch(JsonException error){throw new InvalidDataException("Invalid preparation checkpoint JSON.",error);}
        if(saved.Checkpoint is null||saved.Sha256!=ContentFingerprint.Compute(saved.Checkpoint))throw new InvalidDataException("Preparation checkpoint checksum mismatch.");
        SeedPreparationSearch.Validate(saved.Checkpoint);RunDirectoryStore.EnsureSafeIdentifier(saved.Checkpoint.RunId,nameof(path));return saved.Checkpoint;
    }
    private sealed record Envelope(SeedPreparationCheckpoint Checkpoint,string Sha256);
}
