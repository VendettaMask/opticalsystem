# Binocular Fourier convergence study

This C# diagnostic investigates the original binocular C1/C2 high-frequency MTF field curves. Every optical trace and OPD comes from shared Core or separately captured native ZOS-API data. Experimental quadratures are independent diagnostic controls, never product evaluators.

Build in Release. Commands take `mode repository study-root`. The study uses the frozen original inputs under `artifacts/validation/afocal-mtf-field-20261031` and writes to its own fresh root.

- `prepare`: nine bounded native controls (individual colors, 64/128 sampling, frequency order/repetition, ordinary FFT MTF). Execute generated `native/jobs.json` with `FftProfileNative20261029`; screenshots must remain disabled.
- `probe`: shared Core monochromatic complex OTF sampling study.
- `prepare-points`, `compare-points`: 704 explicit shifted-pupil rays and OPD comparison.
- `endpoints`: bounded shared Core zero-defocus MTF, both configurations and 32–512 sampling; persists completed results after each case.
- `curves`: only 3.2 cycles/mrad, ten calculated field positions, Core 32/128. Reads available native references without replacing them.
- `assess`: reads frozen results and the explicit `single-frequency-native/c{config}-n{sampling}` captures. Checks physical settings/readbacks and uses unchanged comparison-policy tolerances for original-32, reference convergence, Core convergence and final comparisons. It performs no optical calculation and never upgrades the original-32 verdicts.

`NativeFourierOperandCapture` supplies a separate, bounded `fourier-operands` host adapter. Requests explicitly declare sampling, wavelength, field, frequency, grid and data types; it captures native schemas and actual MTFT/MTFS values without saving the source system. The endpoint equivalence to the original field curve was independently verified at 32 sampling.

`rules`, `gauss`, `paraxial`, `clm`, `clm-paraxial`, `clm-inset`, `pupils`, and `prepare-flat` are recorded hypothesis/capability experiments. They did not determine a product correction and must not be used to fit lens-specific runtime constants. Failed and timed-out controls remain in the evidence archive.

Portable regression inputs are in `validation/zemax/2026-r1/binocular-fourier-converged-2026-10-31/reference.zip`. Numerical results, the explicit user decision to use converged native references, and remaining scope are documented in [the report](../../../docs/BINOCULAR_FOURIER_CONVERGENCE_2026-10-31.md).
