using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Analysis;

internal sealed record HuygensPsfSynthesisResult(PsfResult Psf, double IdealPeakWeight);

/// <summary>
/// Incoherent spectral synthesis of the formal monochromatic Huygens PSFs.
/// All colors are evaluated at the same physical image coordinates. The
/// monochromatic grids use 100 for their ideal peak; IdealPeakWeight supplies
/// the corresponding ideal polychromatic normalization, exactly once.
/// </summary>
internal static class HuygensPsfSynthesis
{
    internal static HuygensPsfSynthesisResult Compute(
        Optic optic,
        (double Hx, double Hy) field,
        IReadOnlyList<Wavelength> wavelengths,
        int pupilSampling,
        int imageSize,
        double pixelPitchMillimeters,
        bool usePolarization = false,
        Wavelength? referenceWavelength = null,
        (double X, double Y)? imageCenterOffset = null,
        double defocus = 0,
        bool useParaxialPupilDefocus = false,
        AfocalHuygensIntegration afocalIntegration = AfocalHuygensIntegration.NativeFiniteCell,
        long maximumSamplingOperations = AnalysisResourceLimits.MaximumDirectPsfOperations)
    {
        ArgumentNullException.ThrowIfNull(optic);
        ArgumentNullException.ThrowIfNull(wavelengths);
        if (wavelengths.Count == 0)
            throw new ArgumentException("Huygens synthesis requires a wavelength.", nameof(wavelengths));
        AnalysisResourceLimits.ValidateDirectPsfWork(pupilSampling, imageSize);
        referenceWavelength ??= wavelengths.FirstOrDefault(w => w.IsPrimary) ?? wavelengths[0];
        var weightScale = wavelengths.Max(w => w.Weight);
        var contributors = weightScale > 0
            ? wavelengths.Where(wavelength => wavelength.Weight > 0).ToArray()
            : wavelengths.ToArray();
        var shortest = contributors.Min(w => w.Nanometers);
        var values = new double[imageSize, imageSize];
        var idealPeakWeight = 0.0;
        var workingFNumber = 0.0;
        HuygensPolarizationMode? polarizationMode = null;
        var finiteCellHuygensUsed = true;
        var quadratureNodes = 0;
        var geometricChiefReferenceUsed = false;
        var samplingChecks = new List<HuygensSamplingDiagnostics>();
        var remainingSamplingOperations = maximumSamplingOperations;
        foreach (var wavelength in contributors)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            // A common spectral scale cancels from all normalized observables.
            // Divide it out before summation to avoid overflow. Preserve the
            // analysis-level legacy equal-weight fallback; strict merit-metric
            // selection rejects an all-zero mixture before reaching this layer.
            var spectralWeight = weightScale > 0 ? wavelength.Weight / weightScale : 1;
            var weight = spectralWeight * Math.Pow(shortest / wavelength.Nanometers, 2);
            if (afocalIntegration == AfocalHuygensIntegration.CheckedGaussianPupil && usePolarization)
                throw new NotSupportedException("Checked afocal pupil integration supports scalar, non-polarized wavelets only.");
            PsfResult psf;
            try { psf = afocalIntegration == AfocalHuygensIntegration.CheckedGaussianPupil
                ? DiffractionEngine.ComputeCheckedAfocalHuygensPsf(optic, field, wavelength,
                    pupilSampling, imageSize, pixelPitchMillimeters,
                    new HuygensRefinementOptions(MaximumOperations: remainingSamplingOperations),
                    aimAtStop: optic.RayAimingEnabled, referenceWavelength: referenceWavelength,
                    imageCenterOffset: imageCenterOffset, defocus: defocus, useParaxialPupilDefocus: useParaxialPupilDefocus)
                : DiffractionEngine.ComputeHuygensPsf(optic, field, wavelength,
                pupilSampling, imageSize, pixelPitchMillimeters, afocalIntegration, usePolarization,
                aimAtStop: optic.RayAimingEnabled, referenceWavelength: referenceWavelength,
                imageCenterOffset: imageCenterOffset, defocus: optic.ImageSpaceAfocal ? defocus : 0,
                useParaxialPupilDefocus: useParaxialPupilDefocus); }
            catch (AnalysisDataUnavailableException error) when (error.Data[HuygensSamplingDiagnostics.ExceptionKey] is HuygensSamplingDiagnostics)
            {
                error.Data[HuygensSamplingDiagnostics.PreviousChecksKey] = samplingChecks.ToArray();
                throw;
            }
            if (psf.HuygensSamplingChecks is { } checks)
            {
                samplingChecks.AddRange(checks);
                remainingSamplingOperations -= checks.Sum(check => check.CumulativeOperations);
            }
            if (polarizationMode is { } previous && previous != psf.HuygensPolarization)
                throw new AnalysisDataUnavailableException("Huygens PSF", "spectral components use different polarization models");
            polarizationMode = psf.HuygensPolarization;
            finiteCellHuygensUsed &= psf.FiniteCellHuygensUsed;
            quadratureNodes = Math.Max(quadratureNodes, psf.PupilQuadratureNodeCount);
            geometricChiefReferenceUsed |= psf.GeometricChiefReferenceUsed;
            workingFNumber += psf.WorkingFNumber / contributors.Length;
            idealPeakWeight += weight;
            for (var row = 0; row < imageSize; row++)
            {
                ComputationCancellation.ThrowIfCancellationRequested();
                for (var column = 0; column < imageSize; column++)
                    values[row, column] += weight * psf.Values[row, column];
            }
        }
        if (!double.IsFinite(idealPeakWeight) || idealPeakWeight <= 0)
            throw new AnalysisDataUnavailableException("Huygens PSF", "no finite positive spectral weight");
        return new(new PsfResult(values, pupilSampling, imageSize, workingFNumber,
            optic.ImageSpaceAfocal ? pixelPitchMillimeters : pixelPitchMillimeters * 1000,
            SampleSpacingUnit: optic.ImageSpaceAfocal
                ? AnalysisAxisUnit.Milliradian : AnalysisAxisUnit.Micrometer)
        {
            UseRayAiming = optic.RayAimingEnabled,
            HuygensPolarization = polarizationMode ?? HuygensPolarizationMode.None,
            FiniteCellHuygensUsed = finiteCellHuygensUsed,
            AfocalIntegration = optic.ImageSpaceAfocal ? afocalIntegration : null,
            PupilQuadratureNodeCount = quadratureNodes,
            GeometricChiefReferenceUsed = geometricChiefReferenceUsed,
            HuygensSamplingChecks = samplingChecks.Count > 0 ? samplingChecks.ToArray() : null
        }, idealPeakWeight);
    }
}
