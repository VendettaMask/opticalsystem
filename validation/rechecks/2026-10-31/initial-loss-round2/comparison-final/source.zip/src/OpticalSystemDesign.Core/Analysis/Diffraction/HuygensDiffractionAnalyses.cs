using OpticalSystemDesign.Core.Apertures;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Raytrace;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Analysis;

public sealed class MmdftPsfAnalysis : BaseAnalysis
{
    private readonly int _numRays;
    private readonly int _imageSize;
    private readonly double? _pixelPitchMicrometers;

    public MmdftPsfAnalysis(
        Optic optic,
        int numRays = 16,
        int imageSize = 32,
        double? pixelPitchMicrometers = null) : base(optic)
    {
        _numRays = Math.Max(2, numRays);
        _imageSize = Math.Max(1, imageSize);
        _pixelPitchMicrometers = pixelPitchMicrometers;
    }

    public override string Name => "MMDFT PSF";

    public override AnalysisData GenerateData()
    {
        var wavelength = Optic.Wavelengths.FirstOrDefault(item => item.IsPrimary)
            ?? Optic.Wavelengths.FirstOrDefault();
        if (wavelength is null)
        {
            return AnalysisData.Unavailable(Name, "No wavelengths");
        }

        var field = SpotAnalysisEngine.DefinedFields(Optic).LastOrDefault();
        var psf = DiffractionEngine.ComputeMmdftPsf(
            Optic,
            field,
            wavelength,
            _numRays,
            _imageSize,
            _pixelPitchMicrometers);
        return DiffractionAnalysisPresentation.CreatePsfData(
            Name,
            "MMDFT",
            "MMDFT PSF",
            psf,
            field,
            wavelength,
            psf.PeakStrehlRatio);
    }
}

public sealed class HuygensPsfAnalysis : BaseAnalysis
{
    private readonly int _numRays;
    private readonly int _imageSize;
    private readonly double _pixelPitchMillimeters;
    private readonly int _wavelengthNumber;
    private readonly int _fieldNumber;
    private readonly double _rotationDegrees;
    private readonly string _type;
    private readonly string _displayAs;
    private readonly bool _usePolarization;
    private readonly bool _normalize;
    private readonly bool _useCentroid;

    public HuygensPsfAnalysis(
        Optic optic,
        int numRays = 9,
        int imageSize = 32,
        double pixelPitchMillimeters = 0.005,
        int wavelengthNumber = -1,
        int fieldNumber = 0,
        double rotationDegrees = 0,
        string type = "线性",
        string displayAs = "伪彩色",
        bool usePolarization = false,
        bool normalize = false,
        bool useCentroid = false) : base(optic)
    {
        _numRays = Math.Max(2, numRays);
        _imageSize = Math.Max(1, imageSize);
        _pixelPitchMillimeters = Math.Max(0, pixelPitchMillimeters);
        _wavelengthNumber = Math.Max(-1, wavelengthNumber);
        _fieldNumber = Math.Max(0, fieldNumber);
        _rotationDegrees = rotationDegrees;
        _type = type;
        _displayAs = displayAs;
        _usePolarization = usePolarization;
        _normalize = normalize;
        _useCentroid = useCentroid;
    }

    public override string Name => "Huygens PSF";

    public AfocalHuygensIntegration AfocalIntegration { get; init; } = AfocalHuygensIntegration.NativeFiniteCell;

    public override AnalysisData GenerateData()
    {
        try { return GenerateDataCore(); }
        catch (AnalysisDataUnavailableException error) when (error.Data[HuygensSamplingDiagnostics.ExceptionKey] is HuygensSamplingDiagnostics)
        { return HuygensSamplingDiagnostics.Unavailable(Name, error)!; }
    }

    private AnalysisData GenerateDataCore()
    {
        var allWavelengths = Optic.Wavelengths.ToArray();
        if (allWavelengths.Length == 0)
        {
            return AnalysisData.Unavailable(Name, "No wavelengths");
        }

        var wavelengths = _wavelengthNumber switch
        {
            < 0 => new[]
            {
                allWavelengths.FirstOrDefault(item => item.IsPrimary) ?? allWavelengths[0]
            },
            0 => allWavelengths,
            _ => new[]
            {
                allWavelengths[Math.Clamp(_wavelengthNumber - 1, 0, allWavelengths.Length - 1)]
            }
        };
        var allFields = SpotAnalysisEngine.DefinedFields(Optic);
        var field = allFields.Count == 0
            ? (Hx: 0.0, Hy: 0.0)
            : _fieldNumber <= 0
                ? allFields[^1]
                : allFields[Math.Clamp(_fieldNumber - 1, 0, allFields.Count - 1)];
        var imageDeltaWavelength = wavelengths.MaxBy(item => item.Micrometers) ?? wavelengths[0];
        var pixelPitchMillimeters = _pixelPitchMillimeters > 0
            ? _pixelPitchMillimeters
            : DiffractionEngine.DefaultHuygensImageDeltaMillimeters(
                Optic,
                field,
                imageDeltaWavelength,
                _numRays);
        var afocalImageSpace = Optic.ImageSpaceAfocal;
        var referenceWavelength = wavelengths.FirstOrDefault(item => item.IsPrimary) ?? wavelengths[0];
        var geometricCenter = _useCentroid
            ? DiffractionEngine.HuygensGeometricCenterOffset(Optic, field, wavelengths,
                referenceWavelength, _numRays, Optic.RayAimingEnabled, AfocalIntegration)
            : (X: 0.0, Y: 0.0);
        var synthesis = HuygensPsfSynthesis.Compute(Optic, field, wavelengths, _numRays,
            _imageSize, pixelPitchMillimeters, _usePolarization, referenceWavelength,
            imageCenterOffset: _useCentroid ? geometricCenter : null, afocalIntegration: AfocalIntegration);
        var values = new double[_imageSize, _imageSize];
        for (var row = 0; row < _imageSize; row++)
        {
            for (var column = 0; column < _imageSize; column++)
            {
                values[row, column] = synthesis.Psf.Values[row, column]
                    / (100 * synthesis.IdealPeakWeight);
            }
        }

        var rawPeak = values.Cast<double>().DefaultIfEmpty(0).Max();
        var rawCenter = values[_imageSize / 2, _imageSize / 2];
        if (_normalize && rawPeak > 0)
        {
            for (var row = 0; row < _imageSize; row++)
            {
                for (var column = 0; column < _imageSize; column++)
                {
                    values[row, column] /= rawPeak;
                }
            }
        }

        var centerColumn = _imageSize / 2;
        var centerRow = _imageSize / 2;
        var intensityCentroid = IntensityCentroid(values);
        var centroidOffsetX = (intensityCentroid.X - centerColumn) * pixelPitchMillimeters;
        var centroidOffsetY = (intensityCentroid.Y - centerRow) * pixelPitchMillimeters;
        var logarithmic = _type.Contains("对数", StringComparison.Ordinal)
            || _type.Contains("log", StringComparison.OrdinalIgnoreCase);
        var sampleSpacing = afocalImageSpace ? pixelPitchMillimeters : pixelPitchMillimeters * 1000;
        var imageUnitLabel = afocalImageSpace
            ? ImageSpaceAnalysisSupport.MilliradianLabel
            : "µm";
        var imageAxisUnit = afocalImageSpace
            ? AnalysisAxisUnit.Milliradian
            : AnalysisAxisUnit.Micrometer;
        var imageQuantity = afocalImageSpace
            ? AnalysisAxisQuantity.IncidentAngle
            : AnalysisAxisQuantity.ImageHeight;
        var points = new List<AnalysisPoint>(_imageSize * _imageSize);
        for (var row = 0; row < _imageSize; row++)
        {
            var y = (row - centerRow) * sampleSpacing;
            for (var column = 0; column < _imageSize; column++)
            {
                var value = values[row, column];
                points.Add(new AnalysisPoint(
                    (column - centerColumn) * sampleSpacing,
                    y,
                    Value: logarithmic ? 10 * Math.Log10(Math.Max(1e-12, value)) : value));
            }
        }

        var extent = _imageSize * sampleSpacing;
        var series = new AnalysisSeries(
            $"X ({imageUnitLabel})",
            $"Y ({imageUnitLabel})",
            points,
            AnalysisSeriesKind.Heatmap,
            ValueLabel: logarithmic ? "Relative Intensity (dB)" : "Relative Intensity",
            XQuantity: imageQuantity,
            XUnit: imageAxisUnit,
            YQuantity: imageQuantity,
            YUnit: imageAxisUnit,
            ValueQuantity: AnalysisAxisQuantity.Irradiance,
            ValueUnit: logarithmic ? AnalysisAxisUnit.Decibel : AnalysisAxisUnit.Dimensionless);
        var polarizationMode = synthesis.Psf.HuygensPolarization;
        var title = polarizationMode == HuygensPolarizationMode.CoherentXyz
            ? "Coherent XYZ Jones Huygens PSF（受限透明介质）"
            : polarizationMode == HuygensPolarizationMode.UnpolarizedMeanPower
                ? "Polarization-weighted scalar Huygens PSF（非偏振平均功率）"
            : _usePolarization
            ? wavelengths.Length > 1
                ? "复色光 Polarization-weighted scalar Huygens PSF（Experimental）"
                : "Polarization-weighted scalar Huygens PSF（Experimental）"
            : wavelengths.Length > 1 ? "复色光惠更斯PSF" : "惠更斯PSF";
        return new AnalysisData(Name, new Dictionary<string, object>
        {
            ["Method"] = "Huygens-Fresnel",
            ["PropagationModel"] = Optic.ImageSpaceAfocal ? "Afocal scalar plane waves"
                : synthesis.Psf.FiniteCellHuygensUsed ? "Finite-cell Auto planar/spherical Huygens"
                    : "Lens-datum scalar Huygens weight (compatibility approximation)",
            ["FiniteCellHuygensUsed"] = synthesis.Psf.FiniteCellHuygensUsed,
            ["AfocalIntegration"] = synthesis.Psf.AfocalIntegration?.ToString() ?? "NotApplicable",
            ["PupilQuadratureNodeCount"] = synthesis.Psf.PupilQuadratureNodeCount,
            ["GeometricChiefReferenceUsed"] = synthesis.Psf.GeometricChiefReferenceUsed,
            ["SamplingStatus"] = synthesis.Psf.HuygensSamplingChecks is { Count: > 0 } ? "SamplingStable" : "NotAssessed",
            ["SamplingChecks"] = synthesis.Psf.HuygensSamplingChecks ?? Array.Empty<HuygensSamplingDiagnostics>(),
            ["ImagePlane"] = "Chief ray tangent plane",
            ["PupilSampling"] = _numRays,
            ["ImageSize"] = _imageSize,
            ["GridSize"] = _imageSize,
            ["ImageDeltaMicrometers"] = afocalImageSpace ? 0 : sampleSpacing,
            ["PixelPitchMicrometers"] = afocalImageSpace ? 0 : sampleSpacing,
            ["ImageExtentMicrometers"] = afocalImageSpace ? 0 : extent,
            ["ImageDeltaMilliradians"] = afocalImageSpace ? sampleSpacing : 0,
            ["PixelPitchMilliradians"] = afocalImageSpace ? sampleSpacing : 0,
            ["ImageExtentMilliradians"] = afocalImageSpace ? extent : 0,
            ["ImageSpaceAfocal"] = afocalImageSpace,
            ["ImageCoordinateUnit"] = imageUnitLabel,
            ["WorkingFNumber"] = synthesis.Psf.WorkingFNumber,
            ["SpectralWeighting"] = "Configured flux weights times squared shortest/selected wavelength ratio",
            ["ReferenceWavelengthNanometers"] = referenceWavelength.Nanometers,
            ["StrehlRatio"] = rawCenter,
            ["PeakStrehlRatio"] = rawPeak,
            ["WavelengthNumber"] = _wavelengthNumber,
            ["WavelengthRange"] = $"{wavelengths.Min(item => item.Micrometers):0.0000}–{wavelengths.Max(item => item.Micrometers):0.0000} µm",
            ["FieldNumber"] = _fieldNumber,
            ["FieldHx"] = field.Hx,
            ["FieldHy"] = field.Hy,
            ["RotationDegrees"] = _rotationDegrees,
            ["Type"] = _type,
            ["DisplayAs"] = _displayAs,
            ["UsePolarization"] = _usePolarization,
            ["PolarizationModel"] = polarizationMode switch
            {
                HuygensPolarizationMode.UnpolarizedMeanPower => "Unpolarized mean-power scalar Huygens",
                HuygensPolarizationMode.CoherentXyz => "Coherent XYZ Jones Huygens",
                HuygensPolarizationMode.LegacyScalarApproximation => "Polarization-weighted scalar approximation",
                _ => "Scalar"
            },
            ["PolarizationMode"] = polarizationMode.ToString(),
            ["PolarizationLimit"] = polarizationMode switch
            {
                HuygensPolarizationMode.UnpolarizedMeanPower => "Orthogonal input powers are averaged before scalar diffraction; this is not the incoherent sum of two vector PSFs. Bare homogeneous complex-index interface power is supported; coherent multilayers retain their existing exterior-medium limits. General absorbing XYZ electric fields and longitudinal vector propagation are not modeled.",
                HuygensPolarizationMode.CoherentXyz => "XYZ fields and interface phases are propagated separately in supported transparent isotropic homogeneous media. Absorbing-interface electric fields and GRIN are explicitly unsupported; native coherent Jones/phase certification remains pending.",
                HuygensPolarizationMode.LegacyScalarApproximation => "Legacy Jones powers collapse before scalar diffraction; coherent and longitudinal fields are not certified in this fallback.",
                _ => string.Empty
            },
            ["Normalized"] = _normalize,
            ["UseCentroid"] = _useCentroid,
            ["CenterReference"] = _useCentroid ? "Geometric centroid" : "Chief ray",
            ["GeometricCenterOffsetXMicrometers"] = afocalImageSpace ? 0 : geometricCenter.X * 1000,
            ["GeometricCenterOffsetYMicrometers"] = afocalImageSpace ? 0 : geometricCenter.Y * 1000,
            ["GeometricCenterOffsetXMilliradians"] = afocalImageSpace ? geometricCenter.X : 0,
            ["GeometricCenterOffsetYMilliradians"] = afocalImageSpace ? geometricCenter.Y : 0,
            ["PsfCentroidOffsetXMicrometers"] = afocalImageSpace ? 0 : centroidOffsetX * 1000,
            ["PsfCentroidOffsetYMicrometers"] = afocalImageSpace ? 0 : centroidOffsetY * 1000,
            ["PsfCentroidOffsetXMilliradians"] = afocalImageSpace ? centroidOffsetX : 0,
            ["PsfCentroidOffsetYMilliradians"] = afocalImageSpace ? centroidOffsetY : 0,
            ["CentroidXMicrometers"] = afocalImageSpace ? 0 : (geometricCenter.X + centroidOffsetX) * 1000,
            ["CentroidYMicrometers"] = afocalImageSpace ? 0 : (geometricCenter.Y + centroidOffsetY) * 1000,
            ["CentroidXMilliradians"] = afocalImageSpace ? geometricCenter.X + centroidOffsetX : 0,
            ["CentroidYMilliradians"] = afocalImageSpace ? geometricCenter.Y + centroidOffsetY : 0
        }, series, new[] { series }, new AnalysisPlotOptions(
            Title: title,
            EqualAspect: true,
            XMinimum: -extent / 2,
            XMaximum: extent / 2,
            YMinimum: -extent / 2,
            YMaximum: extent / 2));
    }

    private static (double X, double Y) IntensityCentroid(double[,] values)
    {
        var rows = values.GetLength(0);
        var columns = values.GetLength(1);
        var total = 0.0;
        var weightedX = 0.0;
        var weightedY = 0.0;
        for (var row = 0; row < rows; row++)
        {
            for (var column = 0; column < columns; column++)
            {
                var value = Math.Max(0, values[row, column]);
                total += value;
                weightedX += column * value;
                weightedY += row * value;
            }
        }

        return total > 0
            ? (weightedX / total, weightedY / total)
            : (columns / 2, rows / 2);
    }
}

public sealed class HuygensMtfAnalysis : BaseAnalysis
{
    private readonly int _numRays;
    private readonly int _imageSize;
    private readonly double _pixelPitchMillimeters;
    private readonly IReadOnlyList<(double Hx, double Hy)>? _fields;
    private readonly double? _maximumFrequency;
    private readonly int _wavelengthNumber;
    private readonly int _fieldNumber;
    private readonly bool _zemaxCompatible;

    public HuygensMtfAnalysis(
        Optic optic,
        int numRays = 9,
        int imageSize = 32,
        double pixelPitchMillimeters = 0.005,
        IReadOnlyList<(double Hx, double Hy)>? fields = null,
        double? maximumFrequency = null,
        int wavelengthNumber = -1,
        int fieldNumber = 0,
        bool zemaxCompatible = false) : base(optic)
    {
        _numRays = Math.Max(2, numRays);
        _imageSize = Math.Max(1, imageSize);
        _pixelPitchMillimeters = Math.Max(0, pixelPitchMillimeters);
        _fields = fields;
        _maximumFrequency = maximumFrequency is > 0 && double.IsFinite(maximumFrequency.Value)
            ? maximumFrequency
            : null;
        _wavelengthNumber = wavelengthNumber;
        _fieldNumber = Math.Max(0, fieldNumber);
        _zemaxCompatible = zemaxCompatible;
    }

    public override string Name => "Huygens MTF";

    public AfocalHuygensIntegration AfocalIntegration { get; init; } = AfocalHuygensIntegration.NativeFiniteCell;

    public override AnalysisData GenerateData()
    {
        try { return GenerateDataCore(); }
        catch (AnalysisDataUnavailableException error) when (error.Data[HuygensSamplingDiagnostics.ExceptionKey] is HuygensSamplingDiagnostics)
        { return HuygensSamplingDiagnostics.Unavailable(Name, error)!; }
    }

    private AnalysisData GenerateDataCore()
    {
        var wavelengths = MtfMethodEvaluator.SelectWavelengths(Optic, _wavelengthNumber);
        if (wavelengths.Count == 0)
        {
            return AnalysisData.Unavailable(Name, "No wavelengths");
        }

        var allFields = _fields ?? SpotAnalysisEngine.DefinedFields(Optic);
        var fieldIndices = _fieldNumber <= 0
            ? Enumerable.Range(0, allFields.Count).ToArray()
            : new[] { Math.Clamp(_fieldNumber - 1, 0, Math.Max(0, allFields.Count - 1)) };
        var fields = fieldIndices.Select(index => allFields[index]).ToArray();
        if (fields.Length == 0)
        {
            return AnalysisData.Unavailable(Name, "No fields");
        }

        var sharedPixelPitchMillimeters = _pixelPitchMillimeters > 0
            ? _pixelPitchMillimeters
            : MtfMethodEvaluator.ResolveHuygensImageDeltaMillimeters(
                Optic,
                fields[0],
                wavelengths,
                new MtfComputationSettings(PupilSampling: _numRays, PixelPitchMillimeters: 0));
        var series = new List<AnalysisSeries>();
        var samplingChecks = new List<HuygensSamplingDiagnostics>();
        var remainingSamplingOperations = AnalysisResourceLimits.MaximumDirectPsfOperations;
        var maximumFrequency = 0.0;
        var frequencyLabel = ImageSpaceAnalysisSupport.SpatialFrequencyLabel(Optic);
        var frequencyUnit = ImageSpaceAnalysisSupport.SpatialFrequencyUnit(Optic);
        var frequencyUnitLabel = ImageSpaceAnalysisSupport.SpatialFrequencyUnitLabel(Optic);
        for (var fieldIndex = 0; fieldIndex < fields.Length; fieldIndex++)
        {
            var field = fields[fieldIndex];
            MtfResult fullMtf;
            if (_zemaxCompatible && AfocalIntegration == AfocalHuygensIntegration.NativeFiniteCell)
            {
                var supportedMaximum = (_imageSize - 1.0)
                    / ((2 * _imageSize - 1.0) * sharedPixelPitchMillimeters);
                var requestedMaximum = _maximumFrequency.HasValue
                    ? Math.Min(_maximumFrequency.Value, supportedMaximum)
                    : supportedMaximum;
                var frequencies = Enumerable.Range(0, 300)
                    .Select(index => requestedMaximum * index / 299.0)
                    .ToArray();
                var values = MtfMethodEvaluator.EvaluatePolychromaticFrequencies(
                    Optic,
                    MtfComputationMethod.Huygens,
                    field,
                    wavelengths,
                    frequencies,
                    new MtfComputationSettings(
                        PupilSampling: _numRays,
                        ImageSize: _imageSize,
                        PixelPitchMillimeters: sharedPixelPitchMillimeters,
                        ZemaxCompatible: true,
                        UseZemaxHuygensSemantics: true));
                fullMtf = new MtfResult(
                    frequencies,
                    values.Select(item => item.Tangential).ToArray(),
                    values.Select(item => item.Sagittal).ToArray(),
                    supportedMaximum);
            }
            else
            {
                // First sum incoherent intensities on one physical grid, then
                // transform the sum. Combining already-modulated color curves
                // loses OTF phase and lateral color (and lacks complex OTFs).
                PsfResult psf;
                try { psf = HuygensPsfSynthesis.Compute(Optic, field, wavelengths,
                    _numRays, _imageSize, sharedPixelPitchMillimeters, afocalIntegration: AfocalIntegration,
                    maximumSamplingOperations: remainingSamplingOperations).Psf; }
                catch (AnalysisDataUnavailableException error) when (error.Data[HuygensSamplingDiagnostics.ExceptionKey] is HuygensSamplingDiagnostics)
                {
                    var componentChecks = error.Data[HuygensSamplingDiagnostics.PreviousChecksKey] as IReadOnlyList<HuygensSamplingDiagnostics>
                        ?? Array.Empty<HuygensSamplingDiagnostics>();
                    error.Data[HuygensSamplingDiagnostics.PreviousChecksKey] = samplingChecks.Concat(componentChecks).ToArray();
                    throw;
                }
                if (psf.HuygensSamplingChecks is { } checks)
                {
                    samplingChecks.AddRange(checks);
                    remainingSamplingOperations -= checks.Sum(check => check.CumulativeOperations);
                }
                fullMtf = DiffractionEngine.ComputePsfMtf(psf);
            }

            var mtf = DiffractionEngine.LimitFrequency(fullMtf, _maximumFrequency);
            maximumFrequency = Math.Max(maximumFrequency, fullMtf.Frequency.DefaultIfEmpty(0).Max());
            series.Add(new AnalysisSeries(
                frequencyLabel,
                "Modulation",
                mtf.Frequency.Select((frequency, index) => new AnalysisPoint(frequency, mtf.Tangential[index])).ToArray(),
                Name: MtfPresentation.SeriesName(Optic, field, "Tangential"),
                ColorIndex: fieldIndices[fieldIndex],
                XQuantity: AnalysisAxisQuantity.SpatialFrequency,
                XUnit: frequencyUnit,
                YQuantity: AnalysisAxisQuantity.Modulation,
                YUnit: AnalysisAxisUnit.Dimensionless));
            series.Add(new AnalysisSeries(
                frequencyLabel,
                "Modulation",
                mtf.Frequency.Select((frequency, index) => new AnalysisPoint(frequency, mtf.Sagittal[index])).ToArray(),
                Name: MtfPresentation.SeriesName(Optic, field, "Sagittal"),
                LineStyle: AnalysisLineStyle.Dashed,
                ColorIndex: fieldIndices[fieldIndex],
                XQuantity: AnalysisAxisQuantity.SpatialFrequency,
                XUnit: frequencyUnit,
                YQuantity: AnalysisAxisQuantity.Modulation,
                YUnit: AnalysisAxisUnit.Dimensionless));
        }

        var plottedMaximum = _maximumFrequency.HasValue
            ? Math.Min(_maximumFrequency.Value, maximumFrequency)
            : maximumFrequency;
        return new AnalysisData(Name, new Dictionary<string, object>
        {
            ["Method"] = "Huygens-Fresnel",
            ["PropagationModel"] = Optic.ImageSpaceAfocal ? "Afocal scalar plane waves"
                : "Lens-datum scalar Huygens weight (compatibility approximation)",
            ["ImagePlane"] = "Chief ray tangent plane",
            ["NumRays"] = _numRays,
            ["ImageSize"] = _imageSize,
            ["PixelPitchMillimeters"] = sharedPixelPitchMillimeters,
            ["MtfTransformSize"] = _imageSize * (_zemaxCompatible && AfocalIntegration == AfocalHuygensIntegration.NativeFiniteCell ? 2 : 1),
            ["FrequencySampling"] = _zemaxCompatible && AfocalIntegration == AfocalHuygensIntegration.NativeFiniteCell ? "NaturalCubicEndpointSpan" : "LinearDftPeriod",
            ["AfocalIntegration"] = Optic.ImageSpaceAfocal ? AfocalIntegration.ToString() : "NotApplicable",
            ["SamplingStatus"] = samplingChecks.Count > 0 ? "SamplingStable" : "NotAssessed",
            ["SamplingChecks"] = samplingChecks.ToArray(),
            ["ImageDeltaMicrometers"] = Optic.ImageSpaceAfocal ? 0 : sharedPixelPitchMillimeters * 1000,
            ["ImageDeltaMilliradians"] = Optic.ImageSpaceAfocal ? sharedPixelPitchMillimeters : 0,
            ["MaximumFrequency"] = plottedMaximum,
            ["CutoffFrequency"] = maximumFrequency,
            ["FrequencyUnit"] = frequencyUnitLabel,
            ["ImageSpaceAfocal"] = Optic.ImageSpaceAfocal,
            ["WavelengthNumber"] = _wavelengthNumber,
            ["WavelengthsMicrometers"] = wavelengths.Select(item => item.Micrometers).ToArray(),
            ["FieldNumber"] = _fieldNumber,
            ["FieldCount"] = fields.Length,
            ["ZemaxCompatible"] = _zemaxCompatible && AfocalIntegration == AfocalHuygensIntegration.NativeFiniteCell
        }, series.FirstOrDefault(), series, new AnalysisPlotOptions(
            Title: "Huygens MTF",
            XMinimum: 0,
            XMaximum: plottedMaximum,
            YMinimum: 0,
            YMaximum: 1,
            ShowLegend: true,
            GridOpacity: 0.25));
    }
}

internal static class DiffractionAnalysisPresentation
{
    public static AnalysisData CreatePsfData(
        string name,
        string method,
        string title,
        PsfResult psf,
        (double Hx, double Hy) field,
        Wavelength wavelength,
        double strehlRatio)
    {
        var extent = psf.GridSize * psf.SampleSpacingMicrometers;
        var afocalImageSpace = psf.SampleSpacingUnit == AnalysisAxisUnit.Milliradian;
        var imageUnitLabel = afocalImageSpace
            ? ImageSpaceAnalysisSupport.MilliradianLabel
            : "µm";
        var imageQuantity = afocalImageSpace
            ? AnalysisAxisQuantity.IncidentAngle
            : AnalysisAxisQuantity.ImageHeight;
        var points = new List<AnalysisPoint>(psf.GridSize * psf.GridSize);
        for (var row = 0; row < psf.GridSize; row++)
        {
            var y = -extent / 2 + ((row + 0.5) * psf.SampleSpacingMicrometers);
            for (var column = 0; column < psf.GridSize; column++)
            {
                var x = -extent / 2 + ((column + 0.5) * psf.SampleSpacingMicrometers);
                points.Add(new AnalysisPoint(x, y, Value: psf.Values[row, column]));
            }
        }

        var series = new AnalysisSeries(
            $"X ({imageUnitLabel})",
            $"Y ({imageUnitLabel})",
            points,
            AnalysisSeriesKind.Heatmap,
            ValueLabel: "Relative Intensity (%)",
            XQuantity: imageQuantity,
            XUnit: psf.SampleSpacingUnit,
            YQuantity: imageQuantity,
            YUnit: psf.SampleSpacingUnit,
            ValueQuantity: AnalysisAxisQuantity.Irradiance,
            ValueUnit: AnalysisAxisUnit.Percent);
        return new AnalysisData(name, new Dictionary<string, object>
        {
            ["Method"] = method,
            ["PupilSampling"] = psf.PupilSampling,
            ["ImageSize"] = psf.GridSize,
            ["GridSize"] = psf.GridSize,
            ["PixelPitchMicrometers"] = afocalImageSpace ? 0 : psf.SampleSpacingMicrometers,
            ["PixelPitchMilliradians"] = afocalImageSpace ? psf.SampleSpacingMicrometers : 0,
            ["ImageSpaceAfocal"] = afocalImageSpace,
            ["ImageCoordinateUnit"] = imageUnitLabel,
            ["WorkingFNumber"] = psf.WorkingFNumber,
            ["StrehlRatio"] = strehlRatio,
            ["PeakStrehlRatio"] = psf.PeakStrehlRatio,
            ["WavelengthMicrometers"] = wavelength.Micrometers,
            ["FieldHx"] = field.Hx,
            ["FieldHy"] = field.Hy
        }, series, new[] { series }, new AnalysisPlotOptions(
            Title: title,
            EqualAspect: true,
            XMinimum: -extent / 2,
            XMaximum: extent / 2,
            YMinimum: -extent / 2,
            YMaximum: extent / 2));
    }
}
