using OpticalSystemDesign.InitialStructure.Contracts;
using OpticalSystemDesign.InitialStructure.Engine;
using OpticalSystemDesign.InitialStructure.Persistence;

namespace OpticalSystemDesign.App.Laboratories.InitialStructure;

/// <summary>In-process desktop lifetime. Loading is read-only; only RunAsync dispatches optical work.</summary>
internal sealed class AutonomousDesktopSession(string directory)
{
    private readonly AutonomousSearchCheckpointStore _store = new();
    private AutonomousSearchCheckpoint? _checkpoint;
    private CancellationTokenSource? _cancellation;
    private int _busy;
    public AutonomousSearchCheckpoint? Checkpoint => Volatile.Read(ref _checkpoint);
    public bool IsBusy => Volatile.Read(ref _busy) != 0;
    public string? RecordPath { get; private set; }
    public ParaxialSeedSearchResult? PreparationResult { get; private set; }
    public string? PreparationReportPath { get; private set; }
    public Task Pending { get; private set; } = Task.CompletedTask;

    public void Reset()
    {
        EnsureIdle();
        _checkpoint = null; RecordPath = null; PreparationResult = null; PreparationReportPath = null;
    }

    public async Task LoadAsync(string path, Action<AutonomousSearchPlan>? validate = null)
    {
        EnsureIdle();
        var loaded = await _store.LoadAsync(path);
        validate?.Invoke(loaded.Plan);
        _checkpoint = loaded;
        PreparationResult = null; PreparationReportPath = null;
        RecordPath = Path.GetFullPath(path);
    }

    public Task RunAsync(AutonomousSearchPlan plan, bool resume, Action<AutonomousSearchCheckpoint> publish,
        Action<AutonomousSearchPending, FixedTopologyStep>? progress = null,
        Action<AutonomousSearchPending, ParaxialRecoveryStep>? recoveryProgress = null,
        Action<int, int>? preparationProgress = null)
    {
        if (AutonomousSearchService.IsHistoricalReadOnlyPlan(plan))
            throw new NotSupportedException("Historical transmission prototype plans are read-only; create a fresh versioned plan.");
        if (Interlocked.CompareExchange(ref _busy, 1, 0) != 0) throw new InvalidOperationException("An autonomous desktop operation is already active.");
        _cancellation = new();
        Pending = ExecuteAsync();
        return Pending;

        async Task ExecuteAsync()
        {
            try
            {
                if (!resume)
                {
                    var id = "autonomous-" + Guid.NewGuid().ToString("N");
                    PreparationResult = null; PreparationReportPath = null;
                    if (plan.Options.SeedPreparation is { ColdStart: not null } preparation)
                    {
                        // Validate before any new run file. Cold failure never falls back to an old seed/checkpoint.
                        _ = AutonomousSearchService.Create("automatic-cold-preflight", plan);
                        _checkpoint = null; RecordPath = null; PreparationResult = null; PreparationReportPath = null;
                        var result = await Task.Run(() => ParaxialSeedSearch.Run(plan, preparation, _cancellation.Token, preparationProgress));
                        PreparationResult = result;
                        var reports = Path.Combine(directory, "preparations");
                        Directory.CreateDirectory(reports);
                        PreparationReportPath = Path.Combine(reports, id + ".seed-search.json");
                        // Cancellation stops computation; persistence retains the attempted fresh run and its actual costs.
                        await ParaxialSeedSearchFiles.SaveAsync(result, PreparationReportPath);
                        if (result.Seeds.IsEmpty || _cancellation.IsCancellationRequested) return;
                        plan = plan with { Seeds = result.Seeds };
                        await AutonomousDesignFiles.SavePlanAsync(plan, Path.Combine(reports, id + ".topology-plan.json"));
                    }
                    var created = AutonomousSearchService.Create(id, plan) with { Revision = 1 };
                    Directory.CreateDirectory(directory);
                    var path = Path.Combine(directory, id + ".autonomous.json");
                    await _store.SaveAsync(created, path, 0, _cancellation.Token);
                    _checkpoint = created; RecordPath = path;
                    publish(created);
                }
                var source = Checkpoint ?? throw new InvalidOperationException("No autonomous checkpoint has been loaded.");
                if (source.PlanFingerprint != ContentFingerprint.Compute(plan)) throw new InvalidDataException("Cannot resume a changed autonomous task.");
                var revision = source.Revision;
                await Task.Run(() =>
                {
                    var endpoint = AutonomousSearchService.Run(source, Save, _cancellation.Token, progress, recoveryProgress);
                    _checkpoint = endpoint;
                    publish(endpoint);

                    void Save(AutonomousSearchCheckpoint next)
                    {
                        // Persistence finishes before the engine may dispatch its reserved phase.
                        _store.SaveAsync(next, RecordPath!, revision).AsTask().GetAwaiter().GetResult();
                        revision = next.Revision;
                        Volatile.Write(ref _checkpoint, next);
                        publish(next);
                    }
                });
            }
            finally
            {
                _cancellation.Dispose(); _cancellation = null;
                Volatile.Write(ref _busy, 0);
            }
        }
    }

    public void Cancel() => _cancellation?.Cancel();

    private void EnsureIdle()
    {
        if (IsBusy) throw new InvalidOperationException("Stop and save the active autonomous task before loading another.");
    }
}
