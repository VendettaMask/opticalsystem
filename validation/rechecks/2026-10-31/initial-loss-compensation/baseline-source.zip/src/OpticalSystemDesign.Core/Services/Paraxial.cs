using OpticalSystemDesign.Core.Apertures;
using OpticalSystemDesign.Core.Capabilities;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Geometries;
using OpticalSystemDesign.Core.Interactions;
using OpticalSystemDesign.Core.Materials;

namespace OpticalSystemDesign.Core.Services;

public sealed record ParaxialTrace(
    IReadOnlyList<IReadOnlyList<double>> Heights,
    IReadOnlyList<IReadOnlyList<double>> Slopes);

public sealed record CardinalPointEstimate(
    double EffectiveFocalLength,
    double FrontFocalPosition,
    double BackFocalPosition,
    double FrontPrincipalPlanePosition,
    double BackPrincipalPlanePosition,
    double FrontNodalPlanePosition,
    double BackNodalPlanePosition,
    double FirstReferencePosition,
    double LastReferencePosition);

public sealed partial class Paraxial
{
    private readonly Optic _optic;

    public Paraxial(Optic optic)
    {
        _optic = optic;
    }

    public double EstimateEffectiveFocalLength()
    {
        EnsureComputable();
        var matrix = TraceMatrix(0, _optic.SurfaceGroup.Items.Count,
            PrimaryWavelengthNanometers(), out var determinant);
        return FocalLength(matrix, determinant);
    }

    /// <summary>Reciprocal effective focal length from matrix C, finite at an exact plane system.</summary>
    public double EstimateOpticalPower()
    {
        EnsureComputable();
        var matrix = TraceMatrix(0, _optic.SurfaceGroup.Items.Count,
            PrimaryWavelengthNanometers(), out var determinant);
        return -Math.CopySign(1, determinant) * matrix.C;
    }

    internal double ParaxialImageHeightObjectSlope(double imageHeight)
    {
        EnsureComputable();
        if (_optic.SurfaceGroup.Items.Count < 2)
            throw new InvalidOperationException("Paraxial image-height fields require an optical surface.");
        // At the primary paraxial focal plane, h = -det(M) * u / C.
        // Start after the object plane: its material is the incident medium,
        // not another refracting interface from an assumed unit index.
        var matrix = TraceMatrix(1, _optic.SurfaceGroup.Items.Count,
            PrimaryWavelengthNanometers(), out var determinant);
        if (!double.IsFinite(matrix.C) || Math.Abs(matrix.C) <= 1e-15
            || !double.IsFinite(determinant) || determinant == 0)
            throw new InvalidOperationException("Paraxial image-height fields require finite optical power and conjugate mapping.");
        return imageHeight * -matrix.C / determinant;
    }

    public double EstimateEffectiveFocalLengthBetweenSurfaces(int startSurface, int endSurface)
    {
        EnsureComputable();
        var surfaces = _optic.SurfaceGroup.Items;
        if (surfaces.Count == 0)
        {
            throw new InvalidOperationException("The optical system has no surfaces.");
        }

        var startIndex = startSurface <= 0
            ? 0
            : surfaces.ToList().FindIndex(surface => surface.Number == startSurface);
        if (startIndex < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(startSurface), startSurface, "Start surface was not found.");
        }

        var endIndex = endSurface <= 0
            ? surfaces.Count - 1
            : surfaces.ToList().FindIndex(surface => surface.Number == endSurface);
        if (endIndex < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(endSurface), endSurface, "End surface was not found.");
        }

        if (endIndex < startIndex)
        {
            throw new ArgumentOutOfRangeException(nameof(endSurface), endSurface, "End surface must be at or after start surface.");
        }

        var matrix = TraceMatrix(startIndex, endIndex + 1,
            PrimaryWavelengthNanometers(), out var determinant);
        return FocalLength(matrix, determinant);
    }

    public double EstimateFNumber()
    {
        EnsureComputable();
        var focalLength = Math.Abs(EstimateEffectiveFocalLength());
        var apertureDiameter = EstimateEntrancePupilDiameter();
        return apertureDiameter <= 0 || focalLength <= 0 ? 0 : focalLength / apertureDiameter;
    }

    public double EstimateEntrancePupilDiameter()
    {
        EnsureComputable();
        var fallbackDiameter = _optic.SurfaceGroup.ApertureRadius() * 2.0;
        return _optic.Aperture.Kind switch
        {
            ApertureKind.FNumber => Math.Abs(EstimateEffectiveFocalLength()) / Math.Max(1e-12, _optic.Aperture.Value),
            ApertureKind.NumericalAperture => EntrancePupilDiameterFromObjectNumericalAperture(),
            ApertureKind.FloatByStopSize => EntrancePupilDiameterFromStop(fallbackDiameter),
            _ => _optic.Aperture.Diameter(fallbackDiameter)
        };
    }

    private double EntrancePupilDiameterFromStop(double stopDiameter)
    {
        var stopIndex = _optic.SurfaceGroup.Items.ToList().FindIndex(surface => surface.IsStop);
        if (stopIndex < 0)
        {
            throw new InvalidOperationException("Float by stop size requires an aperture stop.");
        }

        // y(stop) = A*y(object) + B*u(object). At the entrance pupil B/A
        // from the object, the transverse magnification to the stop is A.
        var magnification = TraceMatrix(0, stopIndex, PrimaryWavelengthNanometers()).A;
        if (!double.IsFinite(magnification) || Math.Abs(magnification) <= 1e-15)
        {
            throw new InvalidOperationException("The aperture stop has no finite entrance pupil diameter.");
        }

        return stopDiameter / Math.Abs(magnification);
    }

    private double EntrancePupilDiameterFromObjectNumericalAperture()
    {
        var objectSurface = _optic.SurfaceGroup.Items.FirstOrDefault();
        if (objectSurface is null || ObjectConjugate.IsInfinite(objectSurface))
        {
            throw new InvalidOperationException("Object numerical aperture requires a finite object surface.");
        }

        var wavelength = PrimaryWavelengthNanometers();
        var objectIndex = objectSurface.MaterialAfter.RefractiveIndex(wavelength);
        var sine = _optic.Aperture.Value / objectIndex;
        if (!double.IsFinite(sine) || sine <= 0 || sine > 1)
        {
            throw new InvalidOperationException("Object numerical aperture divided by object-space index must be in (0, 1].");
        }

        var objectPosition = objectSurface.CoordinateSystem.Origin.Z;
        var distance = EstimateEntrancePupilLocation() - objectPosition;
        return 2 * distance * Math.Tan(Math.Asin(sine));
    }

    public double EstimateEntrancePupilLocation()
    {
        return EstimateEntrancePupilLocation(PrimaryWavelengthNanometers() / 1000.0);
    }

    public double EstimateEntrancePupilLocation(double wavelengthMicrometers)
    {
        EnsureComputable();
        if (!double.IsFinite(wavelengthMicrometers) || wavelengthMicrometers <= 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(wavelengthMicrometers),
                wavelengthMicrometers,
                "Wavelength must be finite and positive.");
        }

        var wavelengthNanometers = wavelengthMicrometers * 1000.0;
        var objectSurface = _optic.SurfaceGroup.Items.FirstOrDefault();
        var stopIndex = _optic.SurfaceGroup.Items.ToList().FindIndex(surface => surface.IsStop);
        var endSurfaceExclusive = stopIndex < 0 ? _optic.SurfaceGroup.Items.Count : stopIndex;
        var matrix = TraceMatrix(0, endSurfaceExclusive, wavelengthNanometers);

        if (Math.Abs(matrix.A) < 1e-12)
        {
            return 0;
        }

        // TraceMatrix(0, ...) includes the virtual Object row's unit-index
        // incident convention. The pupil position is measured inside the actual
        // object medium: undo its 1/n angular factor before converting B/A into
        // a physical distance. Unit-index paths keep their exact old value.
        var objectIndex = objectSurface?.MaterialAfter.RefractiveIndex(wavelengthNanometers) ?? 1;
        var relativeLocation = objectIndex * (matrix.B / matrix.A);
        return ObjectConjugate.IsInfinite(objectSurface)
            ? relativeLocation
            : (objectSurface?.CoordinateSystem.Origin.Z ?? 0) + relativeLocation;
    }

    public CardinalPointEstimate EstimateCardinalPoints()
    {
        EnsureComputable();
        var positions = SurfacePositions();
        if (positions.Count == 0)
        {
            return new CardinalPointEstimate(0, 0, 0, 0, 0, 0, 0, 0, 0);
        }

        var matrix = TraceMatrix(0, _optic.SurfaceGroup.Items.Count,
            PrimaryWavelengthNanometers(), out var determinant);
        var effectiveFocalLength = FocalLength(matrix, determinant);
        var axialFocalLength = Math.Abs(matrix.C) < 1e-12 ? 0 : -1.0 / matrix.C;
        var matrixStart = positions[0];
        var matrixEnd = matrixStart + _optic.SurfaceGroup.TotalTrack;
        var firstReference = positions.Count > 1 ? positions[1] : positions[0];
        var lastReference = positions[^1];
        var frontFocalPosition = Math.Abs(matrix.C) < 1e-12
            ? firstReference
            : matrixStart + (matrix.D / matrix.C);
        var backFocalPosition = Math.Abs(matrix.C) < 1e-12
            ? lastReference
            : matrixEnd - (matrix.A / matrix.C);
        // Positions remain in the original axial frame; focal length is signed
        // along outgoing propagation. The determinant also retains n/object:n/image.
        var frontPrincipalPlane = frontFocalPosition + determinant * axialFocalLength;
        var backPrincipalPlane = backFocalPosition - axialFocalLength;
        var frontNodalPlane = frontFocalPosition + effectiveFocalLength;
        var backNodalPlane = backFocalPosition - Math.Abs(determinant) * axialFocalLength;
        return new CardinalPointEstimate(
            effectiveFocalLength,
            frontFocalPosition,
            backFocalPosition,
            frontPrincipalPlane,
            backPrincipalPlane,
            frontNodalPlane,
            backNodalPlane,
            firstReference,
            lastReference);
    }

    public double EstimateExitPupilLocation()
    {
        EnsureComputable();
        return EstimateExitPupilLocation(PrimaryWavelengthNanometers() / 1000.0);
    }

    public double EstimateExitPupilLocation(double wavelengthMicrometers)
    {
        EnsureComputable();
        var stopIndex = _optic.SurfaceGroup.Items.ToList().FindIndex(surface => surface.IsStop);
        if (stopIndex < 0 || stopIndex >= _optic.SurfaceGroup.Items.Count - 1)
        {
            return 0;
        }

        var positions = SurfacePositions();
        var trace = TraceGeneric(
            new[] { 0.0 },
            new[] { 0.1 },
            positions[stopIndex],
            wavelengthMicrometers,
            stopIndex + 1);
        var finalHeight = trace.Heights[^1][0];
        var finalSlope = trace.Slopes[^1][0];
        return Math.Abs(finalSlope) <= 1e-12 ? 0 : -finalHeight / finalSlope;
    }

    public double EstimateExitPupilDiameter()
    {
        EnsureComputable();
        return EstimateExitPupilDiameter(PrimaryWavelengthNanometers() / 1000.0);
    }

    public double EstimateExitPupilDiameter(double wavelengthMicrometers)
    {
        EnsureComputable();
        var marginal = MarginalRay(wavelengthMicrometers);
        var imageHeight = marginal.Heights[^1][0];
        var imageSlope = marginal.Slopes[^1][0];
        return 2 * (imageHeight + (imageSlope * EstimateExitPupilLocation(wavelengthMicrometers)));
    }

    public ParaxialTrace TraceNormalizedPupil(
        double normalizedFieldY,
        IReadOnlyList<double> normalizedPupilY,
        double wavelengthMicrometers)
    {
        EnsureComputable();
        var positions = SurfacePositions();
        var firstSurfacePosition = positions.Count > 1 ? positions[1] : 0;
        var entrancePupilLocation = EstimateEntrancePupilLocation(wavelengthMicrometers);
        var entrancePupilRadius = EstimateEntrancePupilDiameter() / 2;
        var fieldY = normalizedFieldY * FieldCoordinates.MaximumRadius(_optic.Fields);
        var pupilHeights = normalizedPupilY.Select(pupil => pupil * entrancePupilRadius).ToArray();
        var objectSurface = _optic.SurfaceGroup.Items.FirstOrDefault();
        var objectAtInfinity = ObjectConjugate.IsInfinite(objectSurface);
        double objectHeight;
        double objectPosition;
        double? infiniteFieldSlope = null;

        switch (_optic.FieldDefinition)
        {
            case FieldDefinitionKind.ObjectHeight:
                if (objectAtInfinity)
                {
                    throw new InvalidOperationException("Object-height fields require a finite object surface.");
                }

                objectHeight = -fieldY;
                objectPosition = objectSurface?.CoordinateSystem.Origin.Z ?? 0;
                break;
            case FieldDefinitionKind.ParaxialImageHeight:
            case FieldDefinitionKind.RealImageHeight:
                // A paraxial report uses the specified image height in its linear
                // conjugate mapping; real-ray aiming includes higher-order distortion.
                (objectHeight, objectPosition, var imageFieldSlope) = ParaxialImageObjectPosition(
                    fieldY,
                    entrancePupilLocation,
                    firstSurfacePosition,
                    objectSurface,
                    objectAtInfinity);
                infiniteFieldSlope = imageFieldSlope;
                break;
            default:
                var angleSlope = Math.Tan(fieldY * Math.PI / 180.0);
                objectPosition = objectAtInfinity
                    ? firstSurfacePosition
                    : objectSurface?.CoordinateSystem.Origin.Z ?? 0;
                objectHeight = -angleSlope * (entrancePupilLocation - objectPosition);
                infiniteFieldSlope = angleSlope;
                break;
        }

        var heights = pupilHeights.Select(pupilHeight => objectAtInfinity
            ? pupilHeight + objectHeight
            : objectHeight).ToArray();
        var slopes = pupilHeights.Select((pupilHeight, index) =>
        {
            if (objectAtInfinity && infiniteFieldSlope is { } fieldSlope)
                return fieldSlope;
            var denominator = entrancePupilLocation - objectPosition;
            return Math.Abs(denominator) <= 1e-15
                ? 0
                : (pupilHeight - heights[index]) / denominator;
        }).ToArray();
        return TraceGeneric(heights, slopes, objectPosition, wavelengthMicrometers);
    }

    public ParaxialTrace MarginalRay(double wavelengthMicrometers)
    {
        EnsureComputable();
        var positions = SurfacePositions();
        var firstSurfacePosition = positions.Count > 1 ? positions[1] : 0;
        var objectSurface = _optic.SurfaceGroup.Items.FirstOrDefault();
        if (ObjectConjugate.IsInfinite(objectSurface))
        {
            return TraceGeneric(
                new[] { EstimateEntrancePupilDiameter() / 2 },
                new[] { 0.0 },
                firstSurfacePosition - 10,
                wavelengthMicrometers);
        }

        var objectPosition = objectSurface?.CoordinateSystem.Origin.Z ?? 0;
        var pupilDistance = EstimateEntrancePupilLocation(wavelengthMicrometers) - objectPosition;
        var slope = Math.Abs(pupilDistance) <= 1e-15
            ? 0
            : EstimateEntrancePupilDiameter() / (2 * pupilDistance);
        return TraceGeneric(new[] { 0.0 }, new[] { slope }, objectPosition, wavelengthMicrometers);
    }

    public ParaxialTrace ChiefRay(double wavelengthMicrometers)
    {
        EnsureComputable();
        var maximumRadius = FieldCoordinates.MaximumRadius(_optic.Fields);
        var maximumField = _optic.Fields
            .OrderByDescending(field => (field.X * field.X) + (field.Y * field.Y))
            .FirstOrDefault();
        // Scalar paraxial rays describe the meridional plane of the radial field.
        var sign = maximumField is null ? 1 : Math.Sign(maximumField.Y != 0 ? maximumField.Y : maximumField.X);
        var normalizedY = maximumRadius <= 1e-15 ? 0 : sign;
        return TraceNormalizedPupil(normalizedY, new[] { 0.0 }, wavelengthMicrometers);
    }

    private (double Height, double Position, double Slope) ParaxialImageObjectPosition(
        double imageHeight,
        double entrancePupilLocation,
        double firstSurfacePosition,
        OpticalSurface? objectSurface,
        bool objectAtInfinity)
    {
        var objectPosition = objectAtInfinity ? firstSurfacePosition : objectSurface?.CoordinateSystem.Origin.Z ?? 0;
        var objectHeightUnit = -(entrancePupilLocation - objectPosition);
        if (objectAtInfinity && _optic.FieldDefinition == FieldDefinitionKind.ParaxialImageHeight)
        {
            var slope = ParaxialImageHeightObjectSlope(imageHeight);
            return (objectHeightUnit * slope, firstSurfacePosition, slope);
        }
        var trace = TraceGeneric(new[] { objectHeightUnit }, new[] { 1.0 }, objectPosition,
            PrimaryWavelengthNanometers() / 1000.0);
        var imageHeightUnit = trace.Heights[^1][0];
        if (Math.Abs(imageHeightUnit) <= 1e-15)
        {
            throw new InvalidOperationException("The paraxial image height cannot be resolved for this optical system.");
        }

        if (objectAtInfinity)
        {
            return (objectHeightUnit * imageHeight / imageHeightUnit, firstSurfacePosition, imageHeight / imageHeightUnit);
        }

        return (
            objectHeightUnit * imageHeight / imageHeightUnit,
            objectSurface?.CoordinateSystem.Origin.Z ?? 0,
            imageHeight / imageHeightUnit);
    }

    public ParaxialTrace TraceGeneric(
        IReadOnlyList<double> initialHeights,
        IReadOnlyList<double> initialSlopes,
        double initialZ,
        double wavelengthMicrometers,
        int startSurfaceIndex = 0)
    {
        EnsureComputable();
        return TraceGenericCore(
            initialHeights,
            initialSlopes,
            initialZ,
            wavelengthMicrometers,
            startSurfaceIndex,
            reverse: false);
    }

    public ParaxialTrace TraceGenericReverse(
        IReadOnlyList<double> initialHeights,
        IReadOnlyList<double> initialSlopes,
        double initialZ,
        double wavelengthMicrometers,
        int skipSurfaceCount = 0)
    {
        EnsureComputable();
        return TraceGenericCore(
            initialHeights,
            initialSlopes,
            initialZ,
            wavelengthMicrometers,
            skipSurfaceCount,
            reverse: true);
    }

    private ParaxialTrace TraceGenericCore(
        IReadOnlyList<double> initialHeights,
        IReadOnlyList<double> initialSlopes,
        double initialZ,
        double wavelengthMicrometers,
        int skipSurfaceCount,
        bool reverse)
    {
        if (HasGradientIndex)
            return TraceGradientGeneric(initialHeights, initialSlopes, initialZ, wavelengthMicrometers, skipSurfaceCount, reverse);
        if (initialHeights.Count != initialSlopes.Count)
        {
            throw new ArgumentException("Paraxial height and slope arrays must have equal length.");
        }

        var wavelengthNanometers = wavelengthMicrometers * 1000;
        var surfaces = _optic.SurfaceGroup.Items.ToArray();
        var positions = SurfacePositions().ToArray();
        var radii = surfaces
            .Select(ParaxialRadius)
            .ToArray();
        var indices = surfaces
            .Select(surface => surface.MaterialAfter.RefractiveIndex(wavelengthNanometers))
            .ToArray();
        if (reverse)
        {
            var imagePosition = positions[^1];
            surfaces = surfaces.Reverse().ToArray();
            positions = positions.Reverse().Select(position => imagePosition - position).ToArray();
            radii = radii.Reverse().Select(radius => -radius).ToArray();
            indices = indices
                .Select((_, index) => indices[(index + indices.Length - 1) % indices.Length])
                .Reverse()
                .ToArray();
        }

        var y = initialHeights.ToArray();
        var u = initialSlopes.ToArray();
        var z = initialZ;
        var heights = new List<IReadOnlyList<double>>(surfaces.Length);
        var slopes = new List<IReadOnlyList<double>>(surfaces.Length);

        for (var surfaceIndex = Math.Clamp(skipSurfaceCount, 0, surfaces.Length); surfaceIndex < surfaces.Length; surfaceIndex++)
        {
            var surface = surfaces[surfaceIndex];
            if (ReferenceEquals(surface, _optic.SurfaceGroup.Items[0]))
            {
                heights.Add(y.ToArray());
                slopes.Add(u.ToArray());
                continue;
            }

            var distance = positions[surfaceIndex] - z;
            for (var rayIndex = 0; rayIndex < y.Length; rayIndex++)
            {
                y[rayIndex] += distance * u[rayIndex];
            }

            z = positions[surfaceIndex];
            var indexBefore = indices[(surfaceIndex + indices.Length - 1) % indices.Length];
            var indexAfter = indices[surfaceIndex];
            var power = double.IsInfinity(radii[surfaceIndex])
                ? 0
                : (indexAfter - indexBefore) / radii[surfaceIndex];
            var reflective = surface.IsReflective
                || surface.InteractionModel is RefractiveReflectiveInteractionModel { IsReflective: true }
                || surface.InteractionModel is ThinLensInteractionModel { IsReflective: true };
            for (var rayIndex = 0; rayIndex < u.Length; rayIndex++)
            {
                u[rayIndex] = surface.InteractionModel switch
                {
                    ThinLensInteractionModel thinLens when reflective =>
                        -u[rayIndex] + (y[rayIndex] / (indexBefore * thinLens.FocalLength)),
                    ThinLensInteractionModel thinLens =>
                        ((indexBefore * u[rayIndex]) - (y[rayIndex] / thinLens.FocalLength)) / indexAfter,
                    _ when reflective => -u[rayIndex] - (2 * y[rayIndex] / radii[surfaceIndex]),
                    _ => ((indexBefore * u[rayIndex]) - (y[rayIndex] * power)) / indexAfter
                };
            }

            heights.Add(y.ToArray());
            slopes.Add(u.ToArray());
        }

        return new ParaxialTrace(heights, slopes);
    }

    private IReadOnlyList<double> SurfacePositions()
    {
        return _optic.SurfaceGroup.Items
            .Select(surface => surface.CoordinateSystem.Origin.Z)
            .ToArray();
    }

    private static double FocalLength(RayMatrix matrix, double determinant)
    {
        // Matrix slopes use the original +Z axis. Each reflection reverses
        // propagation, so -1/C alone reports the wrong sign after an odd count.
        return Math.Abs(matrix.C) < 1e-12 ? 0 : -Math.CopySign(1, determinant) / matrix.C;
    }

    private static double ParaxialRadius(OpticalSurface surface)
    {
        var radius = surface.IsPlane ? double.PositiveInfinity : surface.Radius;
        if (surface.Geometry is not EvenAsphereGeometry asphere
            || asphere.Coefficients.Count == 0 || asphere.Coefficients[0] == 0)
            return radius;
        // z = c*r²/2 + A2*r² + O(r⁴). A plane base can still have
        // paraxial power; the higher asphere terms do not change that power.
        var curvature = (double.IsInfinity(radius) ? 0 : 1 / radius) + 2 * asphere.Coefficients[0];
        return curvature == 0 ? double.PositiveInfinity : 1 / curvature;
    }

    private RayMatrix TraceMatrix(
        int startSurfaceInclusive,
        int endSurfaceExclusive,
        double wavelengthNanometers,
        bool includeTrailingTranslation = true)
        => TraceMatrix(startSurfaceInclusive, endSurfaceExclusive, wavelengthNanometers,
            out _, includeTrailingTranslation);

    private RayMatrix TraceMatrix(
        int startSurfaceInclusive,
        int endSurfaceExclusive,
        double wavelengthNanometers,
        out double determinant,
        bool includeTrailingTranslation = true)
    {
        if (HasGradientIndex)
            return TraceGradientMatrix(startSurfaceInclusive, endSurfaceExclusive, wavelengthNanometers,
                includeTrailingTranslation, out determinant);
        var matrix = RayMatrix.Identity;
        var currentIndex = startSurfaceInclusive <= 0
            ? 1.0
            : _optic.SurfaceGroup.Items[startSurfaceInclusive - 1]
                .MaterialAfter
                .RefractiveIndex(wavelengthNanometers);
        var initialIndex = currentIndex;
        var orientation = 1;

        for (var index = startSurfaceInclusive; index < endSurfaceExclusive; index++)
        {
            var surface = _optic.SurfaceGroup.Items[index];
            var radius = ParaxialRadius(surface);
            var nextIndex = surface.MaterialAfter.RefractiveIndex(wavelengthNanometers);
            var reflective = surface.IsReflective
                || surface.InteractionModel is RefractiveReflectiveInteractionModel { IsReflective: true }
                || surface.InteractionModel is ThinLensInteractionModel { IsReflective: true }
                || surface.InteractionModel is DiffractiveInteractionModel { IsReflective: true }
                || surface.InteractionModel is PhaseInteractionModel { IsReflective: true };
            matrix = surface.InteractionModel switch
            {
                ThinLensInteractionModel thinLens => ThinLens(
                    matrix,
                    thinLens.FocalLength,
                    currentIndex,
                    nextIndex,
                    reflective),
                _ when reflective => Reflect(matrix, radius),
                _ => Refract(matrix, radius, currentIndex, nextIndex)
            };
            if ((index != 0 || !ObjectConjugate.IsInfinite(surface))
                && (includeTrailingTranslation || index + 1 < endSurfaceExclusive))
            {
                matrix = Translate(matrix, surface.Thickness);
            }
            if (!reflective)
            {
                currentIndex = nextIndex;
            }
            else
            {
                orientation = -orientation;
            }
        }

        // Use the index ratio rather than A*D-B*C, which loses precision at
        // large defocus. Unit-index, even-reflection paths retain exactly 1.
        determinant = orientation * initialIndex / currentIndex;
        return matrix;
    }

    private double PrimaryWavelengthNanometers()
    {
        return (_optic.Wavelengths.FirstOrDefault(item => item.IsPrimary) ?? _optic.Wavelengths.FirstOrDefault())?.Nanometers
            ?? 587.6;
    }

    private void EnsureComputable()
    {
        OpticCapabilityPreflight.EnsureSupported(
            _optic,
            OpticCapabilityOperation.Analysis,
            "Paraxial / First Order");
        if (HasGradientIndex) ValidateGradientIndexSystem();
    }

    private static RayMatrix Refract(RayMatrix matrix, double radius, double indexBefore, double indexAfter)
    {
        if (Math.Abs(radius) < 1e-12 || double.IsInfinity(radius))
        {
            return matrix with
            {
                C = (indexBefore / indexAfter) * matrix.C,
                D = (indexBefore / indexAfter) * matrix.D
            };
        }

        var c = -(indexAfter - indexBefore) / (indexAfter * radius);
        var d = indexBefore / indexAfter;
        return new RayMatrix(
            matrix.A,
            matrix.B,
            (c * matrix.A) + (d * matrix.C),
            (c * matrix.B) + (d * matrix.D));
    }

    private static RayMatrix Reflect(RayMatrix matrix, double radius)
    {
        var c = Math.Abs(radius) < 1e-12 || double.IsInfinity(radius) ? 0 : -2 / radius;
        const double d = -1;
        return new RayMatrix(
            matrix.A,
            matrix.B,
            (c * matrix.A) + (d * matrix.C),
            (c * matrix.B) + (d * matrix.D));
    }

    private static RayMatrix ThinLens(
        RayMatrix matrix,
        double focalLength,
        double indexBefore,
        double indexAfter,
        bool reflective)
    {
        if (!double.IsFinite(focalLength) || Math.Abs(focalLength) < 1e-12)
        {
            throw new InvalidOperationException("Thin-lens focal length must be finite and non-zero.");
        }

        var c = reflective ? 1 / (indexBefore * focalLength) : -1 / (indexAfter * focalLength);
        var d = reflective ? -1 : indexBefore / indexAfter;
        return new RayMatrix(
            matrix.A,
            matrix.B,
            (c * matrix.A) + (d * matrix.C),
            (c * matrix.B) + (d * matrix.D));
    }

    private static RayMatrix Translate(RayMatrix matrix, double distance)
    {
        return new RayMatrix(
            matrix.A + (distance * matrix.C),
            matrix.B + (distance * matrix.D),
            matrix.C,
            matrix.D);
    }

    private sealed record RayMatrix(double A, double B, double C, double D)
    {
        public static RayMatrix Identity { get; } = new(1, 0, 0, 1);
    }
}
