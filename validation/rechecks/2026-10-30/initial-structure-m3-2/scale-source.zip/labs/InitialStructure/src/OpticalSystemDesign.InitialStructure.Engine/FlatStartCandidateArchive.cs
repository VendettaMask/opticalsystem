using OpticalSystemDesign.InitialStructure.Contracts;

namespace OpticalSystemDesign.InitialStructure.Engine;

internal static class FlatStartCandidateArchive
{
    public static IReadOnlyList<CandidateSnapshot> Select(InitialStructureSpecification specification,
        FlatStartSearchOptions options, IEnumerable<FamilyTrial> trials)
    {
        var ranked = trials.Where(trial => trial.Candidate is not null).Select(trial => trial.Candidate!)
            .OrderBy(candidate => Rank(candidate.Status)).ThenBy(candidate => Score(specification, candidate))
            .ThenBy(candidate => candidate.CandidateId, StringComparer.Ordinal)
            .DistinctBy(candidate => candidate.OpticFingerprint).ToArray();
        var selected = new List<CandidateSnapshot>();
        // Choose genuinely different glass/stop/element families before additional members of a family.
        foreach (var category in ranked.GroupBy(candidate => Rank(candidate.Status)).OrderBy(group => group.Key))
        {
            var seenFamilies = selected.Select(FamilyKey).ToHashSet(StringComparer.Ordinal);
            foreach (var candidate in category)
                if (seenFamilies.Add(FamilyKey(candidate)) && selected.Count < options.MaximumDisplayedCandidates) selected.Add(candidate);
            foreach (var candidate in category)
                if (selected.Count < options.MaximumDisplayedCandidates && !selected.Contains(candidate)
                    && selected.Where(other => FamilyKey(other) == FamilyKey(candidate))
                        .All(other => Distance(specification, candidate, other) >= options.MinimumStructuralDistance)) selected.Add(candidate);
        }
        return selected;
    }

    public static int Rank(CandidateStatus status) => status switch
    { CandidateStatus.LabAccepted => 0, CandidateStatus.TraceValid => 1, _ => 2 };

    public static double Score(InitialStructureSpecification specification, CandidateSnapshot candidate)
    {
        var evaluation = candidate.Evaluation;
        if (evaluation.FlatStartObjective is { } objective)
            return objective.SamplingPolicy == specification.FlatStart?.SamplingPolicy
                && objective.UsePhysicalStop == specification.FlatStart.UsePhysicalStop
                && (!objective.UsePhysicalStop || candidate.Optic.RayAimingEnabled)
                && (objective.SamplingPolicy == FlatStartSamplingPolicy.LegacyEqualRings || objective.IndependentValidation)
                ? Score(objective) : double.PositiveInfinity;
        // Read-only compatibility for historical results. New searches publish
        // the full dense objective and never compare it with this legacy score.
        if (specification.FlatStart?.UsePhysicalStop == true) return double.PositiveInfinity;
        return (evaluation.RmsSpotRadiusMillimeters ?? 1e6) / specification.MaximumRmsSpotRadiusMillimeters
            + (evaluation.MaximumSpotRadiusMillimeters ?? 1e6) / specification.MaximumSpotRadiusMillimeters
            + 100 * (1 - evaluation.ValidRayFraction)
            + (evaluation.EffectiveFocalLengthMillimeters is { } focal ? Math.Abs(focal / specification.EffectiveFocalLengthMillimeters - 1) : 1e6);
    }

    public static double Score(FlatStartObjectiveValue? objective) =>
        objective is { DenseSampling: true, HasContinuousResiduals: true }
        && Enum.IsDefined(objective.SamplingPolicy)
        && objective.Kind == (objective.SamplingPolicy == FlatStartSamplingPolicy.LegacyEqualRings
            ? FlatStartObjectiveKind.RealRaySumSquaresV1 : FlatStartObjectiveKind.ConstrainedRealRaySumSquaresV2)
        && objective.Stage == FlatStartDesignProblem.FullStage && double.IsFinite(objective.SumSquares) && objective.SumSquares >= 0
            ? objective.SumSquares : double.PositiveInfinity;

    internal static string FamilyKey(CandidateSnapshot candidate) => string.Join("|",
        candidate.Optic.Surfaces.Count,
        candidate.Optic.Surfaces.FindIndex(surface => surface.IsStop),
        candidate.Lineage.InitialForm ?? "",
        string.Join(",", candidate.Optic.Surfaces.Skip(1).Where((_, index) => index % 2 == 0)
            .Take(candidate.Lineage.ElementCount).Select(surface => surface.Material.ToUpperInvariant())));

    private static double Distance(InitialStructureSpecification specification, CandidateSnapshot a, CandidateSnapshot b)
    {
        var sum = 0.0;
        for (var index = 1; index < a.Optic.Surfaces.Count - 1; index++)
        {
            var left = a.Optic.Surfaces[index];
            var right = b.Optic.Surfaces[index];
            var curvature = (left.Radius == 0 ? 0 : specification.EffectiveFocalLengthMillimeters / left.Radius)
                - (right.Radius == 0 ? 0 : specification.EffectiveFocalLengthMillimeters / right.Radius);
            var thickness = (left.Thickness - right.Thickness) / specification.MaximumTrackLengthMillimeters;
            sum += curvature * curvature + thickness * thickness;
            if (specification.FlatStart?.OptimizationMethod == FlatStartOptimizationMethod.AutoLensManagedV1)
            {
                var profile = Core.Differentiation.OpticalDesignParameters.NormalizedProfileDifference(left, right);
                // An unavailable shape comparison cannot establish structural identity.
                if (profile is null) return double.PositiveInfinity;
                sum += profile.Value;
            }
        }
        return Math.Sqrt(sum / (2 * (a.Optic.Surfaces.Count - 2)));
    }
}
