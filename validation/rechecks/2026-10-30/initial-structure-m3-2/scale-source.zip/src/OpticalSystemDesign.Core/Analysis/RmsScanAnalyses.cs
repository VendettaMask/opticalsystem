using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.Raytrace;

namespace OpticalSystemDesign.Core.Analysis;

public sealed class RmsVsWavelengthAnalysis : BaseAnalysis
{
    public int GaussianAzimuthalSamples { get; init; } = 6;

    private readonly int _waveDensity;
    private readonly int _numRings;
    private readonly string _distribution;
    private readonly int _fieldNumber;
    private readonly string _reference;
    private readonly string _method;
    private readonly string _data;
    private readonly bool _showDiffractionLimit;
    private readonly bool _usePolarization;
    private readonly bool _removeVignetting;

    public RmsVsWavelengthAnalysis(
        Optic optic,
        int waveDensity = 21,
        int numRings = 6,
        string distribution = "hexapolar",
        int fieldNumber = 0,
        string reference = "centroid",
        string method = "GQ",
        string data = "spot",
        bool showDiffractionLimit = false,
        bool usePolarization = false,
        bool removeVignetting = true) : base(optic)
    {
        _waveDensity = Math.Clamp(waveDensity, 2, 100);
        _numRings = RmsScanSupport.ValidateRayDensity(numRings, method);
        _distribution = distribution;
        _fieldNumber = Math.Max(0, fieldNumber);
        _reference = RmsScanSupport.NormalizeReference(reference);
        _method = RmsScanSupport.NormalizeMethod(method);
        _data = RmsScanSupport.NormalizeData(data);
        _showDiffractionLimit = showDiffractionLimit;
        _usePolarization = usePolarization;
        _removeVignetting = removeVignetting;
    }

    public override string Name => "RMS vs Wavelength";

    public override AnalysisData GenerateData()
    {
        var definedWavelengths = Optic.Wavelengths.ToArray();
        var fields = RmsScanSupport.SelectedFields(Optic, _fieldNumber);
        if (definedWavelengths.Length == 0 || fields.Count == 0)
        {
            return RmsScanSupport.Empty(Name);
        }

        RmsScanSupport.ValidateSamplingWork(Optic, _numRings, _method, GaussianAzimuthalSamples,
            fields.Count * _waveDensity, 1);

        var minimum = definedWavelengths.Min(wavelength => wavelength.Micrometers);
        var maximum = definedWavelengths.Max(wavelength => wavelength.Micrometers);
        var wavelengths = Enumerable.Range(0, _waveDensity)
            .Select(index => new Wavelength
            {
                Label = $"W{index + 1}",
                Micrometers = minimum + ((maximum - minimum) * index / (_waveDensity - 1.0)),
                Weight = 1,
                IsPrimary = true
            })
            .ToArray();
        var effectiveDistribution = RmsScanSupport.EffectiveDistribution(_method, _distribution);
        var yAxisLabel = RmsScanSupport.AxisLabel(Optic, _data);
        var series = fields.Select((field, fieldIndex) => new AnalysisSeries(
            "Wavelength (\u00B5m)",
            yAxisLabel,
            wavelengths.Select(wavelength => new AnalysisPoint(
                wavelength.Micrometers,
                RmsScanSupport.Metric(
                    Optic,
                    (field.Hx, field.Hy),
                    new[] { wavelength },
                    _numRings,
                    effectiveDistribution,
                    _data,
                    _reference,
                    usePolarization: _usePolarization,
                    removeVignetting: _removeVignetting, gaussianAzimuthalSamples: GaussianAzimuthalSamples))).ToArray(),
            Name: field.Label,
            ColorIndex: fieldIndex,
            XQuantity: AnalysisAxisQuantity.Wavelength,
            XUnit: AnalysisAxisUnit.Micrometer,
            YQuantity: RmsScanSupport.MetricQuantity(_data),
            YUnit: RmsScanSupport.MetricUnit(Optic, _data))).ToList();
        var diffractionLimit = RmsScanSupport.DiffractionLimitValue(Optic, wavelengths, _data);
        if (_showDiffractionLimit && diffractionLimit > 0)
        {
            series.Add(new AnalysisSeries(
                "Wavelength (\u00B5m)",
                yAxisLabel,
                wavelengths.Select(wavelength => new AnalysisPoint(
                    wavelength.Micrometers,
                    RmsScanSupport.DiffractionLimitValue(Optic, new[] { wavelength }, _data))).ToArray(),
                Name: "Diffraction Limit",
                LineStyle: AnalysisLineStyle.Dashed,
                ColorIndex: series.Count,
                XQuantity: AnalysisAxisQuantity.Wavelength,
                XUnit: AnalysisAxisUnit.Micrometer,
                YQuantity: RmsScanSupport.MetricQuantity(_data),
                YUnit: RmsScanSupport.MetricUnit(Optic, _data)));
        }

        return new AnalysisData(
            Name,
            new Dictionary<string, object>
            {
                ["WaveDensity"] = _waveDensity,
                ["RayDensity"] = _numRings,
                ["GaussianAzimuthalSamples"] = Math.Clamp(GaussianAzimuthalSamples, 1, 72),
                ["Method"] = _method,
                ["Data"] = _data,
                ["Distribution"] = effectiveDistribution,
                ["FieldNumber"] = _fieldNumber,
                ["Reference"] = _reference,
                ["ShowDiffractionLimit"] = _showDiffractionLimit,
                ["ImageSpaceAfocal"] = Optic.ImageSpaceAfocal && RmsScanSupport.NormalizeData(_data) == "spot",
                ["MetricUnit"] = RmsScanSupport.MetricUnitLabel(Optic, _data),
                ["DiffractionLimitMillimeters"] = _data == "spot" && !Optic.ImageSpaceAfocal ? diffractionLimit : 0,
                ["DiffractionLimitMilliradians"] = _data == "spot" && Optic.ImageSpaceAfocal ? diffractionLimit : 0,
                ["DiffractionLimitValue"] = diffractionLimit,
                ["DiffractionLimitUnit"] = RmsScanSupport.DiffractionLimitUnit(Optic, _data),
                ["UsePolarization"] = _usePolarization,
                ["RemoveVignetting"] = _removeVignetting,
                ["MinimumWavelengthMicrometers"] = minimum,
                ["MaximumWavelengthMicrometers"] = maximum
            },
            series.FirstOrDefault(),
            series,
            new AnalysisPlotOptions(
                Title: "RMS vs. Wavelength",
                XMinimum: minimum,
                XMaximum: maximum,
                YMinimum: 0,
                ShowLegend: true,
                HideTopAndRightAxes: true,
                GridOpacity: 0.25,
                LegendBelow: true));
    }
}

public sealed class RmsVsFocusAnalysis : BaseAnalysis
{
    public int GaussianAzimuthalSamples { get; init; } = 6;

    private readonly int _focusDensity;
    private readonly double _minimumFocus;
    private readonly double _maximumFocus;
    private readonly int _numRings;
    private readonly string _distribution;
    private readonly int _wavelengthNumber;
    private readonly string _reference;
    private readonly string _method;
    private readonly string _data;
    private readonly bool _showDiffractionLimit;
    private readonly bool _usePolarization;
    private readonly bool _removeVignetting;

    public RmsVsFocusAnalysis(
        Optic optic,
        int focusDensity = 21,
        double minimumFocus = -1,
        double maximumFocus = 1,
        int numRings = 6,
        string distribution = "hexapolar",
        int wavelengthNumber = 0,
        string reference = "centroid",
        string method = "GQ",
        string data = "spot",
        bool showDiffractionLimit = false,
        bool usePolarization = false,
        bool removeVignetting = true) : base(optic)
    {
        _focusDensity = Math.Clamp(focusDensity, 2, 100);
        _minimumFocus = Math.Min(minimumFocus, maximumFocus);
        _maximumFocus = Math.Max(minimumFocus, maximumFocus);
        _numRings = RmsScanSupport.ValidateRayDensity(numRings, method);
        _distribution = distribution;
        _wavelengthNumber = Math.Max(0, wavelengthNumber);
        _reference = RmsScanSupport.NormalizeReference(reference);
        _method = RmsScanSupport.NormalizeMethod(method);
        _data = RmsScanSupport.NormalizeData(data);
        _showDiffractionLimit = showDiffractionLimit;
        _usePolarization = usePolarization;
        _removeVignetting = removeVignetting;
    }

    public override string Name => "RMS vs Focus";

    public override AnalysisData GenerateData()
    {
        var fields = AnalysisTrace.DefinedFieldSamples(Optic);
        IReadOnlyList<Wavelength> wavelengths = AnalysisTrace.SelectWavelengths(Optic, _wavelengthNumber);
        if (fields.Count == 0 || wavelengths.Count == 0)
        {
            return RmsScanSupport.Empty(Name);
        }

        var focusValues = Enumerable.Range(0, _focusDensity)
            .Select(index => _minimumFocus
                + ((_maximumFocus - _minimumFocus) * index / (_focusDensity - 1.0)))
            .ToArray();
        RmsScanSupport.ValidateSamplingWork(Optic, _numRings, _method, GaussianAzimuthalSamples,
            fields.Count * _focusDensity, wavelengths.Count);
        var effectiveDistribution = RmsScanSupport.EffectiveDistribution(_method, _distribution);
        var yAxisLabel = RmsScanSupport.AxisLabel(Optic, _data);
        var series = fields.Select((field, fieldIndex) => new AnalysisSeries(
            ImageSpaceAnalysisSupport.DefocusLabel(Optic),
            yAxisLabel,
            focusValues.Select(focus => new AnalysisPoint(
                focus,
                RmsScanSupport.Metric(
                    Optic,
                    (field.Hx, field.Hy),
                    wavelengths,
                    _numRings,
                    effectiveDistribution,
                    _data,
                    _reference,
                    focus,
                    _usePolarization,
                    _removeVignetting, GaussianAzimuthalSamples))).ToArray(),
            Name: field.Label,
            ColorIndex: fieldIndex,
            XQuantity: AnalysisAxisQuantity.Defocus,
            XUnit: ImageSpaceAnalysisSupport.DefocusUnit(Optic),
            YQuantity: RmsScanSupport.MetricQuantity(_data),
            YUnit: RmsScanSupport.MetricUnit(Optic, _data))).ToList();
        var diffractionLimit = RmsScanSupport.DiffractionLimitValue(Optic, wavelengths, _data);
        if (_showDiffractionLimit && diffractionLimit > 0)
        {
            series.Add(new AnalysisSeries(
                ImageSpaceAnalysisSupport.DefocusLabel(Optic),
                yAxisLabel,
                focusValues.Select(focus => new AnalysisPoint(focus, diffractionLimit)).ToArray(),
                Name: "Diffraction Limit",
                LineStyle: AnalysisLineStyle.Dashed,
                ColorIndex: series.Count,
                XQuantity: AnalysisAxisQuantity.Defocus,
                XUnit: ImageSpaceAnalysisSupport.DefocusUnit(Optic),
                YQuantity: RmsScanSupport.MetricQuantity(_data),
                YUnit: RmsScanSupport.MetricUnit(Optic, _data)));
        }

        return new AnalysisData(
            Name,
            new Dictionary<string, object>
            {
                ["FocusDensity"] = _focusDensity,
                ["MinimumFocus"] = _minimumFocus,
                ["MaximumFocus"] = _maximumFocus,
                ["RayDensity"] = _numRings,
                ["GaussianAzimuthalSamples"] = Math.Clamp(GaussianAzimuthalSamples, 1, 72),
                ["Method"] = _method,
                ["Data"] = _data,
                ["Distribution"] = effectiveDistribution,
                ["WavelengthNumber"] = _wavelengthNumber,
                ["Reference"] = _reference,
                ["ShowDiffractionLimit"] = _showDiffractionLimit,
                ["ImageSpaceAfocal"] = Optic.ImageSpaceAfocal && RmsScanSupport.NormalizeData(_data) == "spot",
                ["DefocusUnit"] = ImageSpaceAnalysisSupport.DefocusUnitLabel(Optic),
                ["MetricUnit"] = RmsScanSupport.MetricUnitLabel(Optic, _data),
                ["DiffractionLimitMillimeters"] = _data == "spot" && !Optic.ImageSpaceAfocal ? diffractionLimit : 0,
                ["DiffractionLimitMilliradians"] = _data == "spot" && Optic.ImageSpaceAfocal ? diffractionLimit : 0,
                ["DiffractionLimitValue"] = diffractionLimit,
                ["DiffractionLimitUnit"] = RmsScanSupport.DiffractionLimitUnit(Optic, _data),
                ["UsePolarization"] = _usePolarization,
                ["RemoveVignetting"] = _removeVignetting
            },
            series.FirstOrDefault(),
            series,
            new AnalysisPlotOptions(
                Title: "RMS vs. Focus",
                XMinimum: _minimumFocus,
                XMaximum: _maximumFocus,
                YMinimum: 0,
                ShowLegend: true,
                HideTopAndRightAxes: true,
                GridOpacity: 0.25,
                LegendBelow: true));
    }
}

public sealed class RmsFieldMapAnalysis : BaseAnalysis
{
    public int GaussianAzimuthalSamples { get; init; } = 6;

    private readonly int _xFieldSamples;
    private readonly int _yFieldSamples;
    private readonly double _xFieldWidth;
    private readonly double _yFieldWidth;
    private readonly int _numRings;
    private readonly string _distribution;
    private readonly int _wavelengthNumber;
    private readonly string _reference;
    private readonly string _method;
    private readonly string _data;
    private readonly bool _usePolarization;
    private readonly bool _removeVignetting;

    public RmsFieldMapAnalysis(
        Optic optic,
        int xFieldSamples = 11,
        int yFieldSamples = 11,
        double xFieldWidth = 0,
        double yFieldWidth = 0,
        int numRings = 6,
        string distribution = "hexapolar",
        int wavelengthNumber = 0,
        string reference = "centroid",
        string method = "GQ",
        string data = "spot",
        bool usePolarization = false,
        bool removeVignetting = true) : base(optic)
    {
        var defaultWidth = Math.Max(1e-9, AnalysisTrace.MaxFieldValue(optic));
        _xFieldSamples = Math.Clamp(xFieldSamples, 3, 101);
        _yFieldSamples = Math.Clamp(yFieldSamples, 3, 101);
        _xFieldWidth = xFieldWidth > 0 ? xFieldWidth : defaultWidth;
        _yFieldWidth = yFieldWidth > 0 ? yFieldWidth : defaultWidth;
        _numRings = RmsScanSupport.ValidateRayDensity(numRings, method);
        _distribution = distribution;
        _wavelengthNumber = Math.Max(0, wavelengthNumber);
        _reference = RmsScanSupport.NormalizeReference(reference);
        _method = RmsScanSupport.NormalizeMethod(method);
        _data = RmsScanSupport.NormalizeData(data);
        _usePolarization = usePolarization;
        _removeVignetting = removeVignetting;
    }

    public override string Name => "RMS Field Map";

    public override AnalysisData GenerateData()
    {
        IReadOnlyList<Wavelength> wavelengths = AnalysisTrace.SelectWavelengths(Optic, _wavelengthNumber);
        var maximumField = Math.Max(1e-12, AnalysisTrace.MaxFieldValue(Optic));
        if (wavelengths.Count == 0)
        {
            return RmsScanSupport.Empty(Name);
        }

        var points = new List<AnalysisPoint>(_xFieldSamples * _yFieldSamples);
        RmsScanSupport.ValidateSamplingWork(Optic, _numRings, _method, GaussianAzimuthalSamples,
            _xFieldSamples * _yFieldSamples, wavelengths.Count);
        var effectiveDistribution = RmsScanSupport.EffectiveDistribution(_method, _distribution);
        for (var row = 0; row < _yFieldSamples; row++)
        {
            var y = -_yFieldWidth + (2 * _yFieldWidth * row / (_yFieldSamples - 1.0));
            for (var column = 0; column < _xFieldSamples; column++)
            {
                var x = -_xFieldWidth + (2 * _xFieldWidth * column / (_xFieldSamples - 1.0));
                var rms = RmsScanSupport.Metric(
                    Optic,
                    (x / maximumField, y / maximumField),
                    wavelengths,
                    _numRings,
                    effectiveDistribution,
                    _data,
                    _reference,
                    usePolarization: _usePolarization,
                    removeVignetting: _removeVignetting, gaussianAzimuthalSamples: GaussianAzimuthalSamples);
                points.Add(new AnalysisPoint(x, y, Value: rms));
            }
        }

        var values = points.Select(point => point.Value ?? 0).ToArray();
        var minimum = values.Min();
        var maximum = values.Max();
        var series = new AnalysisSeries(
            RmsScanSupport.FieldXAxisLabel(Optic),
            RmsScanSupport.FieldYAxisLabel(Optic),
            points,
            AnalysisSeriesKind.Heatmap,
            Name: RmsScanSupport.SeriesName(_data),
            ValueLabel: RmsScanSupport.AxisLabel(Optic, _data),
            ValueMinimum: minimum,
            ValueMaximum: maximum,
            XQuantity: AnalysisTrace.FieldAxisQuantity(Optic),
            XUnit: AnalysisTrace.FieldAxisUnit(Optic),
            YQuantity: AnalysisTrace.FieldAxisQuantity(Optic),
            YUnit: AnalysisTrace.FieldAxisUnit(Optic),
            ValueQuantity: RmsScanSupport.MetricQuantity(_data),
            ValueUnit: RmsScanSupport.MetricUnit(Optic, _data));
        return new AnalysisData(
            Name,
            new Dictionary<string, object>
            {
                ["XFieldSamples"] = _xFieldSamples,
                ["YFieldSamples"] = _yFieldSamples,
                ["XFieldWidth"] = _xFieldWidth,
                ["YFieldWidth"] = _yFieldWidth,
                ["RayDensity"] = _numRings,
                ["GaussianAzimuthalSamples"] = Math.Clamp(GaussianAzimuthalSamples, 1, 72),
                ["Method"] = _method,
                ["Data"] = _data,
                ["Distribution"] = effectiveDistribution,
                ["WavelengthNumber"] = _wavelengthNumber,
                ["Reference"] = _reference,
                ["ImageSpaceAfocal"] = Optic.ImageSpaceAfocal && RmsScanSupport.NormalizeData(_data) == "spot",
                ["MetricUnit"] = RmsScanSupport.MetricUnitLabel(Optic, _data),
                ["DiffractionLimitMillimeters"] = Optic.ImageSpaceAfocal
                    ? 0
                    : RmsScanSupport.DiffractionLimitMillimeters(Optic, wavelengths),
                ["DiffractionLimitMilliradians"] = Optic.ImageSpaceAfocal
                    ? RmsScanSupport.DiffractionLimitValue(Optic, wavelengths, _data)
                    : 0,
                ["UsePolarization"] = _usePolarization,
                ["RemoveVignetting"] = _removeVignetting,
                ["MinimumMetricValue"] = minimum,
                ["MaximumMetricValue"] = maximum,
                [RmsScanSupport.MinimumValueKey(_data)] = minimum,
                [RmsScanSupport.MaximumValueKey(_data)] = maximum
            },
            series,
            new[] { series },
            new AnalysisPlotOptions(
                Title: "RMS Field Map",
                EqualAspect: true,
                XMinimum: -_xFieldWidth,
                XMaximum: _xFieldWidth,
                YMinimum: -_yFieldWidth,
                YMaximum: _yFieldWidth,
                HideTopAndRightAxes: true));
    }
}

internal static class RmsScanSupport
{
    public static AnalysisData Empty(string name)
    {
        throw new AnalysisDataUnavailableException(name, "the optical system has no selected fields or wavelengths");
    }

    public static IReadOnlyList<AnalysisFieldSample> SelectedFields(Optic optic, int fieldNumber)
    {
        var fields = AnalysisTrace.DefinedFieldSamples(optic);
        return fieldNumber > 0
            ? fields.Skip(fieldNumber - 1).Take(1).ToArray()
            : fields;
    }

    public static string NormalizeMethod(string method)
    {
        if (string.Equals(method, "RA", StringComparison.OrdinalIgnoreCase)
            || string.Equals(method, "Rectangular Array", StringComparison.OrdinalIgnoreCase))
        {
            return "RA";
        }

        return "GQ";
    }

    public static int ValidateRayDensity(int density, string method)
    {
        var normalized = NormalizeMethod(method);
        var maximum = normalized == "RA" ? AnalysisResourceLimits.MaximumAnalysisGridDimension : 32;
        if (density < 1 || density > maximum)
            throw new ArgumentOutOfRangeException(nameof(density),
                $"{normalized} ray density must be between 1 and {maximum}; it is never silently reduced.");
        return density;
    }

    public static void ValidateSamplingWork(Optic optic, int density, string method, int azimuthalSamples,
        int evaluationCount, int wavelengthCount, int tracePasses = 1)
    {
        ValidateRayDensity(density, method);
        var rectangular = NormalizeMethod(method) == "RA";
        if (!rectangular && azimuthalSamples is < 1 or > 72)
            throw new ArgumentOutOfRangeException(nameof(azimuthalSamples), "GQ angular samples must be between 1 and 72.");
        var upperRayCount = rectangular ? (long)density * density : (long)density * azimuthalSamples;
        var work = checked((upperRayCount + 1) * evaluationCount * wavelengthCount
            * Math.Max(1, optic.SurfaceGroup.Items.Count) * tracePasses);
        if (work > AnalysisResourceLimits.MaximumAnalysisRayWork)
            throw new ArgumentOutOfRangeException(nameof(density),
                "RMS sampling exceeds the ray-work safety budget. Reduce ray density, scan points or wavelengths.");
    }

    public static string NormalizeData(string data)
    {
        if (string.Equals(data, "wavefront", StringComparison.OrdinalIgnoreCase)
            || string.Equals(data, "Wavefront", StringComparison.OrdinalIgnoreCase)
            || string.Equals(data, "波前", StringComparison.Ordinal))
        {
            return "wavefront";
        }

        return "spot";
    }

    public static string NormalizeReference(string reference)
    {
        if (string.Equals(reference, "chief", StringComparison.OrdinalIgnoreCase)
            || string.Equals(reference, "chief ray", StringComparison.OrdinalIgnoreCase)
            || string.Equals(reference, "主光线", StringComparison.Ordinal))
        {
            return "chief";
        }

        return "centroid";
    }

    public static string EffectiveDistribution(string method, string distribution)
    {
        return NormalizeMethod(method) == "RA"
            ? "uniform"
            : "gaussian";
    }

    public static string AxisLabel(string data)
    {
        return NormalizeData(data) == "wavefront"
            ? "RMS Wavefront Error (waves)"
            : "RMS Spot Radius (mm)";
    }

    public static string AxisLabel(Optic optic, string data)
    {
        if (NormalizeData(data) == "wavefront")
        {
            return "RMS Wavefront Error (waves)";
        }

        return optic.ImageSpaceAfocal
            ? $"RMS Spot Radius ({ImageSpaceAnalysisSupport.MilliradianLabel})"
            : "RMS Spot Radius (mm)";
    }

    public static string SeriesName(string data)
    {
        return NormalizeData(data) == "wavefront"
            ? "RMS Wavefront Error"
            : "RMS Spot Radius";
    }

    public static string MaximumValueKey(string data)
    {
        return NormalizeData(data) == "wavefront"
            ? "MaximumRmsWavefrontError"
            : "MaximumRmsSpotRadius";
    }

    public static string MinimumValueKey(string data)
    {
        return NormalizeData(data) == "wavefront"
            ? "MinimumRmsWavefrontError"
            : "MinimumRmsSpotRadius";
    }

    public static double Metric(
        Optic optic,
        (double Hx, double Hy) field,
        IReadOnlyList<Wavelength> wavelengths,
        int numRings,
        string distribution,
        string data,
        string reference,
        double imagePlaneOffset = 0,
        bool usePolarization = false,
        bool removeVignetting = true,
        int gaussianAzimuthalSamples = 6)
    {
        var workingOptic = AnalysisTrace.PrepareVignettingFactors(optic, removeVignetting);
        return NormalizeData(data) == "wavefront"
            ? WavefrontRms(
                workingOptic,
                field,
                wavelengths,
                numRings,
                distribution,
                reference,
                imagePlaneOffset,
                usePolarization, gaussianAzimuthalSamples)
            : SpotRadius(
                workingOptic,
                field,
                wavelengths,
                numRings,
                distribution,
                reference,
                imagePlaneOffset,
                usePolarization, gaussianAzimuthalSamples);
    }

    public static double SpotRadius(
        Optic optic,
        (double Hx, double Hy) field,
        IReadOnlyList<Wavelength> wavelengths,
        int numRings,
        string distribution,
        string reference,
        double imagePlaneOffset = 0,
        bool usePolarization = false,
        int gaussianAzimuthalSamples = 6)
    {
        var result = SpotAnalysisEngine.Generate(
            optic,
            new[] { field },
            wavelengths,
            numRings,
            distribution,
            imagePlaneOffset,
            reference: reference,
            usePolarization: usePolarization,
            aimAtStop: optic.RayAimingEnabled,
            includeSurfaceTransmission: usePolarization,
            gaussianAzimuthalSamples: gaussianAzimuthalSamples,
            explicitPupilSamples: string.Equals(distribution, "uniform", StringComparison.OrdinalIgnoreCase)
                ? ApertureSampler.GenerateRectangularArray(numRings) : null,
            gaussianPupilIntegral: !usePolarization && string.Equals(distribution, "gaussian", StringComparison.OrdinalIgnoreCase));
        var rays = result.Fields.FirstOrDefault()?.WeightedRays
            .ToArray() ?? Array.Empty<SpotRayData>();
        if (rays.Length == 0)
        {
            throw new AnalysisDataUnavailableException(
                "RMS spot",
                "no valid rays reached the selected surface");
        }

        return SpotAnalysisEngine.RmsRadius(rays);
    }

    public static double WavefrontRms(
        Optic optic,
        (double Hx, double Hy) field,
        IReadOnlyList<Wavelength> wavelengths,
        int numRings,
        string distribution,
        string reference,
        double imagePlaneOffset = 0,
        bool usePolarization = false,
        int gaussianAzimuthalSamples = 6)
    {
        if (wavelengths.Count == 0)
        {
            throw new AnalysisDataUnavailableException("RMS wavefront", "no wavelengths");
        }

        var pupil = string.Equals(distribution, "uniform", StringComparison.OrdinalIgnoreCase)
            ? ApertureSampler.Generate(numRings * numRings, PupilSampling.UniformGrid)
            : ApertureSampler.GenerateGaussianQuadrature(numRings, gaussianAzimuthalSamples);
        var coordinates = pupil.Select(sample => (sample.X, sample.Y)).ToArray();
        var wavefronts = DiffractionEngine.GenerateDefocusedPolychromaticWavefronts(
            optic,
            field,
            wavelengths,
            coordinates,
            imagePlaneOffset,
            usePolarization);
        var weightedMeanSquare = 0.0;
        var totalWavelengthWeight = 0.0;
        for (var wavelengthIndex = 0; wavelengthIndex < wavelengths.Count; wavelengthIndex++)
        {
            var wavelength = wavelengths[wavelengthIndex];
            var wavefront = wavefronts[wavelengthIndex];
            var samples = wavefront.Samples.Select((sample, index) => (
                    Sample: sample,
                    Weight: Math.Max(0, pupil[index].Weight) * (usePolarization ? sample.Intensity : 1)))
                .Where(item => item.Weight > 0
                    && double.IsFinite(item.Sample.OpdWaves)
                    && item.Sample.Intensity > 0)
                .ToArray();
            if (samples.Length == 0)
            {
                continue;
            }

            var rms = WeightedWavefrontRms(wavefront.Samples, pupil, reference, usePolarization);
            var meanSquare = rms * rms;
            var wavelengthWeight = Math.Max(0, wavelength.Weight) * (usePolarization ? samples.Sum(item => item.Weight) : 1);
            weightedMeanSquare += wavelengthWeight * meanSquare;
            totalWavelengthWeight += wavelengthWeight;
        }

        if (totalWavelengthWeight <= 1e-30)
        {
            throw new AnalysisDataUnavailableException(
                "RMS wavefront",
                "no valid weighted wavefront samples");
        }

        return Math.Sqrt(Math.Max(0, weightedMeanSquare / totalWavelengthWeight));
    }

    public static double WeightedWavefrontRms(
        IReadOnlyList<WavefrontSample> wavefront,
        IReadOnlyList<PupilSample> pupil,
        string reference,
        bool usePolarization = false)
    {
        return WavefrontStatistics.Measure(wavefront, pupil,
            NormalizeReference(reference) == "centroid" ? WavefrontReferenceKind.Centroid : WavefrontReferenceKind.ChiefRay,
            useIntensityWeights: usePolarization).Rms;
    }

    public static double DiffractionLimitMillimeters(
        Optic optic,
        IReadOnlyList<Wavelength> wavelengths)
    {
        var wavelength = wavelengths.Count == 0
            ? optic.Wavelengths.FirstOrDefault(item => item.IsPrimary) ?? optic.Wavelengths.FirstOrDefault()
            : wavelengths.FirstOrDefault(item => item.IsPrimary) ?? wavelengths[0];
        if (wavelength is null)
        {
            return 0;
        }

        var fNumber = Math.Abs(optic.Paraxial.EstimateFNumber());
        return fNumber <= 1e-30 ? 0 : 1.22 * wavelength.Micrometers * 1e-3 * fNumber;
    }

    public static double DiffractionLimitValue(
        Optic optic,
        IReadOnlyList<Wavelength> wavelengths,
        string data)
    {
        if (string.Equals(data, "strehl", StringComparison.OrdinalIgnoreCase))
        {
            return 0.8;
        }

        if (NormalizeData(data) == "wavefront")
        {
            return 0.072;
        }

        var wavelength = wavelengths.Count == 0
            ? optic.Wavelengths.FirstOrDefault(item => item.IsPrimary) ?? optic.Wavelengths.FirstOrDefault()
            : wavelengths.FirstOrDefault(item => item.IsPrimary) ?? wavelengths[0];
        if (wavelength is null)
        {
            return 0;
        }

        return optic.ImageSpaceAfocal
            ? ImageSpaceAnalysisSupport.AfocalAiryRadiusMilliradians(optic, wavelength)
            : DiffractionLimitMillimeters(optic, wavelengths);
    }

    public static string DiffractionLimitUnit(string data)
    {
        if (string.Equals(data, "strehl", StringComparison.OrdinalIgnoreCase))
        {
            return "ratio";
        }

        return NormalizeData(data) == "wavefront" ? "waves" : "mm";
    }

    public static string DiffractionLimitUnit(Optic optic, string data)
    {
        if (string.Equals(data, "strehl", StringComparison.OrdinalIgnoreCase))
        {
            return "ratio";
        }

        if (NormalizeData(data) == "wavefront")
        {
            return "waves";
        }

        return optic.ImageSpaceAfocal
            ? ImageSpaceAnalysisSupport.MilliradianLabel
            : "mm";
    }

    public static AnalysisAxisQuantity MetricQuantity(string data)
    {
        return NormalizeData(data) == "wavefront"
            ? AnalysisAxisQuantity.WavefrontError
            : AnalysisAxisQuantity.Radius;
    }

    public static AnalysisAxisUnit MetricUnit(string data)
    {
        if (string.Equals(data, "strehl", StringComparison.OrdinalIgnoreCase))
        {
            return AnalysisAxisUnit.Dimensionless;
        }

        return NormalizeData(data) == "wavefront"
            ? AnalysisAxisUnit.Wave
            : AnalysisAxisUnit.Millimeter;
    }

    public static AnalysisAxisUnit MetricUnit(Optic optic, string data)
    {
        if (string.Equals(data, "strehl", StringComparison.OrdinalIgnoreCase))
        {
            return AnalysisAxisUnit.Dimensionless;
        }

        if (NormalizeData(data) == "wavefront")
        {
            return AnalysisAxisUnit.Wave;
        }

        return optic.ImageSpaceAfocal
            ? AnalysisAxisUnit.Milliradian
            : AnalysisAxisUnit.Millimeter;
    }

    public static string MetricUnitLabel(Optic optic, string data)
    {
        return MetricUnit(optic, data) switch
        {
            AnalysisAxisUnit.Wave => "waves",
            AnalysisAxisUnit.Milliradian => ImageSpaceAnalysisSupport.MilliradianLabel,
            AnalysisAxisUnit.Millimeter => "mm",
            AnalysisAxisUnit.Dimensionless => "ratio",
            _ => string.Empty
        };
    }

    public static string FieldXAxisLabel(Optic optic)
    {
        return optic.FieldDefinition == FieldDefinitionKind.Angle
            ? "X Field (degrees)"
            : "X Field (mm)";
    }

    public static string FieldYAxisLabel(Optic optic)
    {
        return optic.FieldDefinition == FieldDefinitionKind.Angle
            ? "Y Field (degrees)"
            : "Y Field (mm)";
    }
}
