using System.Globalization;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.InitialStructure.Contracts;
using OpticalSystemDesign.Modules;

namespace OpticalSystemDesign.App.Laboratories.InitialStructure;

internal sealed class CandidateRow(int number, FamilyTrial trial, bool inherited = false)
{
    public FamilyTrial Trial { get; } = trial;
    public CandidateSnapshot Candidate => Trial.Candidate!;
    public string Name => inherited ? "来源方案" : $"方案 {number}";
    public string Status => IncompleteAreaEvaluation ? "光线不完整" : Candidate.Status == CandidateStatus.LabAccepted ? "已达标" : "有差距";
    public int Elements => Candidate.Lineage.ElementCount;
    public string InitialForm => Trial.AutoLensState?.SchemaVersion == 2 ? "随机起点" : Trial.Family.BinaryStart?.Signs ?? "历史方案";
    public string FocalLength => Format(Candidate.Evaluation.EffectiveFocalLengthMillimeters);
    public string Rms => IncompleteAreaEvaluation ? "光线不完整" : Format(Candidate.Evaluation.RmsSpotRadiusMillimeters);
    private bool AreaSampling => Candidate.Evaluation.FlatStartObjective?.SamplingPolicy == FlatStartSamplingPolicy.UniformAreaGaussianV1;
    private bool IncompleteAreaEvaluation => AreaSampling && Trial.FinalValidation?.HasContinuousSearchResiduals != true;
    public string Transmission => Trial.FinalValidation is { Fields.Count: > 0 } result
        ? result.Fields.SelectMany(sample => sample.Wavelengths.Select(wave => wave.AttemptedRays > 0 ? (double)wave.ValidRays / wave.AttemptedRays : 0)
            .Append(sample.AttemptedRays > 0 ? (double)sample.ValidRays / sample.AttemptedRays : 0)
            .Append(sample.CheckAttemptedRays > 0 ? (double)sample.CheckValidRays / sample.CheckAttemptedRays : 1)).Min().ToString("P2", CultureInfo.CurrentCulture) : "—";

    public IReadOnlyList<TargetRow> Targets(InitialStructureSpecification specification)
    {
        var violations = Candidate.Violations;
        string State(Func<ConstraintViolation, bool> predicate) => violations.Any(predicate) ? "未满足" : "满足";
        string ImageQualityState(Func<ConstraintViolation, bool> predicate) => IncompleteAreaEvaluation ? "无法判定" : State(predicate);
        var totalTrack = InitialStructurePresentation.TotalTrack(Candidate);
        return
        [
            new("焦距 mm", $"{Format(specification.EffectiveFocalLengthMillimeters)} ± {specification.FlatStart!.EffectiveFocalLengthRelativeTolerance:P1}", FocalLength, State(item => item.Code == "target.focal-length")),
            new("F/#", $"{Format(specification.FNumber)} ± {specification.FlatStart.FNumberRelativeTolerance:P1}", Format(Candidate.Evaluation.FNumber), State(item => item.Code == "target.f-number")),
            new(AreaSampling ? "最差面积 RMS mm" : "历史离散 RMS mm", "≤ " + Format(specification.MaximumRmsSpotRadiusMillimeters), Rms, ImageQualityState(item => item.Code.EndsWith(".rms", StringComparison.Ordinal))),
            new("最大光斑半径 mm", "≤ " + Format(specification.MaximumSpotRadiusMillimeters), IncompleteAreaEvaluation ? "光线不完整" : Format(Candidate.Evaluation.MaximumSpotRadiusMillimeters), ImageQualityState(item => item.Code.EndsWith(".maximum-radius", StringComparison.Ordinal))),
            new("逐视场／波长通光", "≥ " + specification.FlatStart.MinimumValidRayFraction.ToString("P1", CultureInfo.CurrentCulture)
                + (AreaSampling ? "；边缘检查 100%" : ""), Transmission,
                State(item => item.Code.EndsWith(".lost-fraction", StringComparison.Ordinal) || item.Code.EndsWith(".check-lost-rays", StringComparison.Ordinal))),
            new("总长 mm", "≤ " + Format(specification.MaximumTrackLengthMillimeters), Format(totalTrack),
                totalTrack <= specification.MaximumTrackLengthMillimeters + 1e-9 ? "满足" : "未满足"),
            new("后焦 mm", specification.FlatStart.FixedBackFocusMillimeters is { } back ? Format(back) + "（固定）" : "≥ " + Format(specification.MinimumBackFocusMillimeters),
                Format(InitialStructurePresentation.BackFocus(Candidate)), State(item => item.Code.Contains("back-focus", StringComparison.Ordinal))),
            new("完整目标验收", "全部条件满足", Status, Candidate.Status == CandidateStatus.LabAccepted ? "通过" : "未通过")
        ];
    }

    public IEnumerable<PrescriptionRow> Prescription() => InitialStructurePresentation.Prescription(Candidate).Select((surface, index) => new PrescriptionRow(
        surface.IsStop ? $"{index} 光阑" : index.ToString(CultureInfo.InvariantCulture),
        (surface.Radius == 0 ? "∞" : Format(surface.Radius)) + (surface.RadiusVariable ? " V" : ""),
        Format(surface.Thickness) + (surface.ThicknessVariable ? " V" : ""), surface.Material,
        Format(surface.SemiDiameter), Format(surface.MechanicalSemiDiameter)));

    public IEnumerable<FieldRow> Fields() => (Trial.FinalValidation?.Fields ?? []).Select(field => new FieldRow(
        Format(field.HalfFieldAngleDegrees), DiagnosticSpot(field.RmsRadiusMillimeters), DiagnosticSpot(field.MaximumRadiusMillimeters),
        field.AttemptedRays > 0 ? ((double)field.ValidRays / field.AttemptedRays).ToString("P2", CultureInfo.CurrentCulture) : "—",
        string.Join("；", field.Wavelengths.Select(wave => $"{wave.Nanometers:0.###} nm：{wave.ValidRays}/{wave.AttemptedRays}"))
            + (field.CheckAttemptedRays > 0 ? $"；边缘检查 {field.CheckValidRays}/{field.CheckAttemptedRays}" : "")));

    public string Details(FlatStartSearchCheckpoint checkpoint)
    {
        var measuredTraces = int.TryParse(checkpoint.Algorithm.Version, NumberStyles.None, CultureInfo.InvariantCulture, out var version) && version >= 18;
        var lines = new List<string>
        {
            $"{Name} · {Status} · {Elements} 片",
            checkpoint.Specification.FlatStart?.OptimizationMethod switch
            {
                FlatStartOptimizationMethod.AutoLensCpuExperimentV1 => "算法：AutoLens 启发式 C# CPU 试验 v1；数值梯度 Adam + 原生完整目标细化，非原版可微/GPU。",
                FlatStartOptimizationMethod.AutoLensManagedV1 when Trial.AutoLensState?.SchemaVersion == 2 => "算法：AutoLens e58 原版规则；共享 Core、固定输入光线、两阶段直接 Adam、允许玻璃匹配；实际设备见下方记录。",
                FlatStartOptimizationMethod.AutoLensManagedV1 => "算法：历史 AutoLens C# 自动求导；保留原求解与精修记录。",
                _ => "算法：原生信赖域（默认）。"
            },
            AreaSampling ? "像质：均匀照明圆瞳面积 RMS；独立加密验收，边缘光线另行检查。"
                : "像质：历史等圈离散 RMS；保留原采样含义，与面积积分结果不能直接比较。",
            Trial.AutoLensState?.SchemaVersion == 2 ? "随机弱曲率起点；最终光学性能以正式 Core 验证结果为准。" : $"起始形式：{InitialForm}；这是初始曲率方向，最终光学性能以正式 Core 验证结果为准。",
            "玻璃：" + string.Join(" / ", InitialStructurePresentation.Prescription(Candidate).Skip(1).Where(surface => !string.IsNullOrWhiteSpace(surface.Material) && !surface.Material.Equals("Air", StringComparison.OrdinalIgnoreCase)).Select(surface => surface.Material)),
            Trial.AutoLensState?.SchemaVersion == 2 ? "独立前置光阑 · 训练物距 20000 mm。" : $"光阑：面 {Trial.Family.StopSurfaceIndex}；从零曲率平板起步，当前为第 {Candidate.Lineage.Generation} 代。",
            Candidate.Evaluation.FlatStartObjective?.UsePhysicalStop == true
                ? Trial.AutoLensState?.SchemaVersion == 2 ? "实体光阑：课程按原版改变口径，精修保持；独立验收使用正式 Core 瞄准。"
                    : "实体光阑：净口径按系统入瞳标定并瞄准；镜片机械半径单独计算。" : "历史口径模式：按近轴入瞳发射，光阑面随镜片口径更新。",
            $"本次已计入 {checkpoint.ChargedEvaluations}/{checkpoint.Specification.Budget.MaximumEvaluations} 次评价；已记录 {checkpoint.TracedRealRayCount:N0} "
                + (measuredTraces ? "次真实光线追迹计算（含瞄准与诊断）。" : "个分析光线采样（历史计数，不含全部瞄准开销）。")
        };
        if (IncompleteAreaEvaluation) lines.Add("完整口径追迹失败；逐视场光斑值仅供诊断，不代表完整口径像质。RMS 与最大半径目标无法判定。");
        if (Trial.AutoLensState?.LastComputeExecution is { } execution)
            lines.Add(UiLocalization.Text("计算设备") + "：" + (execution.GpuBatches > 0 ? "GPU · " + execution.DeviceName : "CPU")
                + (execution.FallbackReason is { } reason ? " · " + reason : ""));
        if (Trial.AutoLensState?.PropagationExecution is { Batches: > 0 } propagation)
            lines.Add("GPU · " + propagation.DeviceName + " · " + UiLocalization.Text("GPU 瞄准光线") + " " + propagation.AimRays
                + " · " + UiLocalization.Text("GPU 追迹光线") + " " + propagation.PropagatedRays
                + " · " + UiLocalization.Text("CPU 恢复光线") + " " + propagation.CpuRecoveryRays);
        if (Trial.AutoLensState?.PropagationExecution is { CpuAimingRays: > 0 } cpuAim)
            lines.Add("有限物距方向瞄准：Core CPU · " + cpuAim.CpuAimingRays + " 条光线。");
        if (checkpoint.Origin is { } origin) lines.Add($"本次是追加细化；来源运行已用 {origin.ChargedEvaluations} 次评价，未计入本次新预算。来源记录：{origin.RunId}");
        lines.Add("差距与约束：");
        lines.AddRange(Candidate.Violations.Count == 0 ? ["完整规格的最终验收通过。"] : Candidate.Violations.Select(violation =>
            $"{violation.Code}：{violation.Message}"));
        lines.Add("记录编号：" + Candidate.CandidateId);
        return string.Join(Environment.NewLine, lines);
    }

    private string DiagnosticSpot(double? value) => Format(value) + (IncompleteAreaEvaluation && value.HasValue ? "（诊断）" : "");

    private static string Format(double? value) => value switch
    {
        null => "—",
        double.PositiveInfinity => "∞",
        double.NegativeInfinity => "−∞",
        _ => value.Value.ToString("0.######", CultureInfo.CurrentCulture)
    };
}

internal sealed record TargetRow(string Name, string Target, string Actual, string State);
internal sealed record PrescriptionRow(string Surface, string Radius, string Thickness, string Material, string SemiDiameter, string Mechanical);
internal sealed record FieldRow(string Field, string Rms, string Maximum, string Transmission, string Wavelengths);
