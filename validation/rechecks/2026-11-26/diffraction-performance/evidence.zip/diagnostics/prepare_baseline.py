from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[2]
folder = root / '.tmp/diffraction-performance/original-source'
folder.mkdir(exist_ok=True)
path = root / 'src/OpticalSystemDesign.Core/Analysis/DiffractionEngine.cs'
engine = path.read_bytes().decode('utf-8')
nl = '\r\n' if '\r\n' in engine else '\n'
def lines(text): return text.replace('\n', nl)
engine = engine.replace('        var (tangentialOtf, sagittalOtf) = ComputePsfOtfAxes(psf);', lines('''        var shifted = ComputeCenteredPsfTransform(psf);
        var center = psf.GridSize / 2;
        var dc = shifted[center, center];
        var normalization = dc.Magnitude <= 1e-30 ? Complex.One : dc;
        var tangentialOtf = Enumerable.Range(center, psf.GridSize - center)
            .Select(row => shifted[row, center] / normalization)
            .ToArray();
        var sagittalOtf = Enumerable.Range(center, psf.GridSize - center)
            .Select(column => shifted[center, column] / normalization)
            .ToArray();'''))
start = engine.index('        // Each image pixel owns')
end = engine.index('        void EvaluateRow(int row)', start) + len('        void EvaluateRow(int row)')
engine = engine[:start] + '        for (var row = 0; row < imageSize; row++)' + engine[end:]
(folder / 'DiffractionEngine.cs').write_bytes(engine.encode('utf-8'))
path = root / 'src/OpticalSystemDesign.Core/Analysis/Radiometry/EncircledEnergyVariants.cs'
energy = path.read_bytes().decode('utf-8')
nl = '\r\n' if '\r\n' in energy else '\n'
start = energy.index('        var samples = new EnergySample[checked(size * size)];')
end = energy.index('        if (samples.All', start)
energy = energy[:start] + lines('''        var samples = Enumerable.Range(0, size).SelectMany(row => Enumerable.Range(0, size).Select(column =>
            new EnergySample((column - size / 2d + 1) * pitch, (row - size / 2d + 1) * pitch,
                results.Select((r, i) => weights[i] * r.Result.Values[(row + 1) % size, (column + 1) % size]).Sum() / totalWeight))).ToArray();
''') + energy[end:]
(folder / 'EncircledEnergyVariants.cs').write_bytes(energy.encode('utf-8'))
before = json.loads((root / '.tmp/diffraction-performance/source-before.json').read_text(encoding='utf-8-sig'))
for item in before:
    file = folder / Path(item['Path']).name
    if file.exists():
        actual = hashlib.sha256(file.read_bytes()).hexdigest().upper()
        assert actual == item['Hash'], (str(file), actual, item['Hash'])
        print('Restored exact original source:', file.name, actual)
