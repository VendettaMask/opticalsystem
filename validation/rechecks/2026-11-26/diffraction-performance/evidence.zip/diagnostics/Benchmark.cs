using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
using OpticalSystemDesign.Application.Runtime;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;

internal static class PerformanceBenchmark
{
    private static readonly JsonSerializerOptions Json = new() { WriteIndented = true, NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals };
    internal static async Task Run(string label)
    {
        var cases = new (string Key, Dictionary<string,string> Settings)[]
        {
            ("Huygens PSF",new(){["PupilSampling"]="64 x 64",["ImageSampling"]="128 x 128"}),
            ("PSF",new(){["Sampling"]="256 x 256",["Display"]="512 x 512"}),
            ("MTF",new(){["Sampling"]="256"}),
            ("Diffraction Encircled Energy",new(){["PupilSampling"]="256 x 256",["FourierSamplingMode"]="固定采样"})
        };
        var results = new List<object>();
        foreach(var (key,overrides) in cases)
        {
            var runtime = new WorkbenchRuntime(Optic.CreateCookeTriplet());
            var settings = runtime.GetAnalysisParameters(key).ToDictionary(p=>p.Key,p=>p.DefaultValue);
            foreach(var item in overrides) settings[item.Key]=item.Value;
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(55));
            await Task.Run(()=>runtime.BuildAnalysisData(key,settings,timeout.Token));
            var rounds = new List<object>();
            var milliseconds = new List<double>();
            AnalysisData? data = null;
            for(int repeat=0;repeat<3;repeat++)
            {
                var cpu=Process.GetCurrentProcess().TotalProcessorTime;
                var allocated=GC.GetTotalAllocatedBytes(true);
                var timer=Stopwatch.StartNew();
                data=await Task.Run(()=>runtime.BuildAnalysisData(key,settings,timeout.Token));
                timer.Stop();
                milliseconds.Add(timer.Elapsed.TotalMilliseconds);
                rounds.Add(new { Milliseconds=timer.Elapsed.TotalMilliseconds, CpuMs=(Process.GetCurrentProcess().TotalProcessorTime-cpu).TotalMilliseconds, AllocatedBytes=GC.GetTotalAllocatedBytes(true)-allocated });
            }
            if(data!.Outcome!=AnalysisOutcome.Success) throw new Exception(key+": "+data.OutcomeReason);
            var payload=JsonSerializer.SerializeToUtf8Bytes(data,Json);
            var filename=key.Replace(" ","-").ToLowerInvariant()+".json";
            var folder=".tmp/diffraction-performance/"+label;
            Directory.CreateDirectory(folder);
            File.WriteAllBytes(Path.Combine(folder,filename),payload);
            var result=new { Analysis=key, Settings=settings, MedianMs=milliseconds.Order().ElementAt(1), Rounds=rounds, ResultFile=filename, ResultSha256=Convert.ToHexString(SHA256.HashData(payload)) };
            results.Add(result); Console.WriteLine(JsonSerializer.Serialize(result,Json));
        }
        File.WriteAllText(".tmp/diffraction-performance/"+label+"/timings.json",JsonSerializer.Serialize(new { Framework=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription, Processors=Environment.ProcessorCount, Results=results },Json));
    }
}
