using System.Diagnostics;
using System.Numerics;
using System.Reflection;
using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Services;
using OpticalSystemDesign.Application.Runtime;

if(args.Contains("bench")) { await PerformanceBenchmark.Run(args[^1]); return; }
if(args.Contains("focus")) { await RunFocused(); return; }
var results = new List<object>();
var fft = typeof(DiffractionEngine).GetMethod("Fft", BindingFlags.Static | BindingFlags.NonPublic)!.CreateDelegate<Action<Complex[]>>();
var fft2 = typeof(DiffractionEngine).GetMethod("Fft2D", BindingFlags.Static | BindingFlags.NonPublic)!.CreateDelegate<Action<Complex[,]>>();
Console.WriteLine($"runtime={System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription}, processors={Environment.ProcessorCount}");
foreach (var n in new[] { 256, 512, 1024 })
{
    var source = new Complex[n,n];
    for (int y=0;y<n;y++) for(int x=0;x<n;x++) source[y,x]=new(Math.Sin(x*.17+y*.013), Math.Cos(x*.03-y*.11));
    var candidate = new PrototypePlan(n);
    for(int warm=0;warm<2;warm++) { fft2((Complex[,])source.Clone()); Candidate2((Complex[,])source.Clone(),candidate); }
    var a=(Complex[,])source.Clone(); var b=(Complex[,])source.Clone(); fft2(a); Candidate2(b,candidate);
    var max=0d; long bits=0;
    for(int y=0;y<n;y++) for(int x=0;x<n;x++) { max=Math.Max(max,(a[y,x]-b[y,x]).Magnitude); if(a[y,x]!=b[y,x]) bits++; }
    var oldTimes=new List<double>(); var newTimes=new List<double>();
    for(int repeat=0;repeat<5;repeat++)
    {
        a=(Complex[,])source.Clone(); b=(Complex[,])source.Clone();
        if(repeat%2==0){ oldTimes.Add(Measure(()=>fft2(a))); newTimes.Add(Measure(()=>Candidate2(b,candidate))); }
        else { newTimes.Add(Measure(()=>Candidate2(b,candidate))); oldTimes.Add(Measure(()=>fft2(a))); }
    }
    var item=new {Kind="FFT2D prototype", Size=n, BaselineMs=oldTimes.Order().ElementAt(2), CandidateMs=newTimes.Order().ElementAt(2), MaximumDelta=max, DifferentComplexValues=bits, BaselineRounds=oldTimes, CandidateRounds=newTimes}; results.Add(item); Console.WriteLine(JsonSerializer.Serialize(item));
}
var runtime=new WorkbenchRuntime(Optic.CreateCookeTriplet());
foreach(var key in new[]{"PSF","MTF","Diffraction Encircled Energy","Huygens PSF"})
{
    var settings=runtime.GetAnalysisParameters(key).ToDictionary(p=>p.Key,p=>p.DefaultValue);
    using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(15));
    var timer=Stopwatch.StartNew(); var allocated=GC.GetTotalAllocatedBytes(true);
    try
    {
        var data=runtime.BuildAnalysisData(key, settings, timeout.Token); timer.Stop();
        var selected=data.Values.Where(p=>p.Key.Contains("Sampling")||p.Key.Contains("Validation")||p.Key.Contains("Grid")||p.Key.Contains("Unavailable")).ToDictionary(p=>p.Key,p=>p.Value);
        var item=new { Kind="Default analysis cold", Analysis=key, Milliseconds=timer.Elapsed.TotalMilliseconds, AllocatedBytes=GC.GetTotalAllocatedBytes(true)-allocated, Settings=settings, Details=selected }; results.Add(item); Console.WriteLine(JsonSerializer.Serialize(item,new JsonSerializerOptions{NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals}));
    }
    catch(Exception error) { var item=new {Kind="Default analysis cold", Analysis=key, Milliseconds=timer.Elapsed.TotalMilliseconds, Error=error.GetType().Name+": "+error.Message}; results.Add(item); Console.WriteLine(JsonSerializer.Serialize(item)); }
}
File.WriteAllText(".tmp/diffraction-performance/baseline.json",JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true,NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals}));
static double Measure(Action action){var timer=Stopwatch.StartNew();action();return timer.Elapsed.TotalMilliseconds;}
static void Candidate2(Complex[,] data, PrototypePlan plan)
{
    ComputationCancellation.ThrowIfCancellationRequested(); var n=data.GetLength(0);var buffer=new Complex[n];
    for(int y=0;y<n;y++){ComputationCancellation.ThrowIfCancellationRequested();for(int x=0;x<n;x++)buffer[x]=data[y,x];plan.Transform(buffer);for(int x=0;x<n;x++)data[y,x]=buffer[x];}
    for(int x=0;x<n;x++){ComputationCancellation.ThrowIfCancellationRequested();for(int y=0;y<n;y++)buffer[y]=data[y,x];plan.Transform(buffer);for(int y=0;y<n;y++)data[y,x]=buffer[y];}
}
static async Task RunFocused()
{
    var results=new List<object>();
    var cases=new (string Key, Dictionary<string,string> Overrides)[]
    {
        ("Diffraction Encircled Energy", new(){["FourierSamplingMode"]="固定采样"}),
        ("Diffraction Encircled Energy", new(){["FourierSamplingMode"]="固定采样",["PupilSampling"]="128 x 128"}),
        ("Diffraction Encircled Energy", new(){["FourierSamplingMode"]="固定采样",["PupilSampling"]="256 x 256"}),
        ("Diffraction Encircled Energy", new(){["FourierMaximumSampling"]="256"}),
        ("Diffraction Encircled Energy", new(){["FieldNumber"]="1",["WavelengthNumber"]="1"}),
        ("Diffraction Encircled Energy", new(){["FieldNumber"]="1"}),
        ("Huygens PSF", new(){["PupilSampling"]="64 x 64",["ImageSampling"]="128 x 128"}),
        ("PSF",new(){["Sampling"]="256 x 256",["Display"]="512 x 512"}),
        ("MTF",new(){["Sampling"]="256"})
    };
    foreach(var (key,overrides) in cases)
    {
        var runtime=new WorkbenchRuntime(Optic.CreateCookeTriplet());
        var settings=runtime.GetAnalysisParameters(key).ToDictionary(p=>p.Key,p=>p.DefaultValue);
        foreach(var p in overrides)settings[p.Key]=p.Value;
        using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(8));
        var timer=Stopwatch.StartNew();var cpu=Process.GetCurrentProcess().TotalProcessorTime;var alloc=GC.GetTotalAllocatedBytes(true);
        try
        {
            var data=await Task.Run(()=>runtime.BuildAnalysisData(key,settings,timeout.Token)); timer.Stop();
            var details=data.Values.Where(p=>p.Key.Contains("Sampling")||p.Key.Contains("Validation")||p.Key.Contains("Grid")).ToDictionary(p=>p.Key,p=>p.Value);
            var item=new { Analysis=key, Overrides=overrides, Milliseconds=timer.Elapsed.TotalMilliseconds, CpuMs=(Process.GetCurrentProcess().TotalProcessorTime-cpu).TotalMilliseconds, AllocatedBytes=GC.GetTotalAllocatedBytes(true)-alloc, Outcome=data.Outcome.ToString(), data.OutcomeReason, Details=details };results.Add(item);Console.WriteLine(JsonSerializer.Serialize(item,new JsonSerializerOptions{NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals}));
        }
        catch(Exception error){var item=new {Analysis=key,Overrides=overrides,Milliseconds=timer.Elapsed.TotalMilliseconds,CpuMs=(Process.GetCurrentProcess().TotalProcessorTime-cpu).TotalMilliseconds,AllocatedBytes=GC.GetTotalAllocatedBytes(true)-alloc,Error=error.GetType().Name+": "+error.Message};results.Add(item);Console.WriteLine(JsonSerializer.Serialize(item));}
    }
    File.WriteAllText(".tmp/diffraction-performance/focused.json",JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true,NumberHandling=System.Text.Json.Serialization.JsonNumberHandling.AllowNamedFloatingPointLiterals}));
}
sealed class PrototypePlan
{
    readonly (int,int)[] swaps; readonly Complex[] factors;
    public PrototypePlan(int n)
    {
        var list=new List<(int,int)>();
        for(int i=1,j=0;i<n;i++){var bit=n>>1;for(;(j&bit)!=0;bit>>=1)j^=bit;j^=bit;if(i<j)list.Add((i,j));}
        swaps=list.ToArray();factors=new Complex[n-1];
        for(int length=2;length<=n;length<<=1){var root=Complex.FromPolarCoordinates(1,-2*Math.PI/length);var f=Complex.One;for(int k=0;k<length/2;k++){factors[length/2-1+k]=f;f*=root;}}
    }
    public void Transform(Complex[] values)
    {
        ComputationCancellation.ThrowIfCancellationRequested();foreach(var (i,j) in swaps)(values[i],values[j])=(values[j],values[i]);
        for(int length=2;length<=values.Length;length<<=1){ComputationCancellation.ThrowIfCancellationRequested();var half=length/2;for(int start=0;start<values.Length;start+=length)for(int k=0;k<half;k++){var even=values[start+k];var odd=values[start+k+half]*factors[half-1+k];values[start+k]=even+odd;values[start+k+half]=even-odd;}}
    }
}
