import json
import math
from pathlib import Path

root = Path(__file__).parent
before = json.loads((root / 'before/timings.json').read_text())
after_dir = 'after-quiet' if (root / 'after-quiet/timings.json').exists() else 'after'
after = json.loads((root / after_dir / 'timings.json').read_text())
summary = []
for b, a in zip(before['Results'], after['Results']):
    numeric = []
    structural = []
    def compare(left, right, path=''):
        if isinstance(left, dict) and isinstance(right, dict):
            if left.keys() != right.keys():
                structural.append(path + ': keys')
            for key in left.keys() & right.keys():
                compare(left[key], right[key], path + '/' + key)
        elif isinstance(left, list) and isinstance(right, list):
            if len(left) != len(right):
                structural.append(path + ': length')
            for index, (l, r) in enumerate(zip(left, right)):
                compare(l, r, path + '/' + str(index))
        elif left != right:
            if isinstance(left, (int, float)) and isinstance(right, (int, float)):
                numeric.append((abs(left - right), path, left, right))
            else:
                structural.append(path + ': value')
    compare(json.loads((root / 'before' / b['ResultFile']).read_text()),
            json.loads((root / after_dir / a['ResultFile']).read_text()))
    n = sorted(numeric, reverse=True)
    summary.append(dict(Analysis=b['Analysis'], BeforeMs=b['MedianMs'], AfterMs=a['MedianMs'],
        SpeedRatio=b['MedianMs']/a['MedianMs'],
        BeforeMedianAllocatedBytes=sorted(r['AllocatedBytes'] for r in b['Rounds'])[1],
        AfterMedianAllocatedBytes=sorted(r['AllocatedBytes'] for r in a['Rounds'])[1],
        DifferentNumericValues=len(n), MaximumAbsoluteDifference=n[0][0] if n else 0,
        LargestDifferences=n[:5], StructuralDifferences=structural[:20],
        BeforeSha256=b['ResultSha256'], AfterSha256=a['ResultSha256']))
result = dict(Framework=before['Framework'], Processors=before['Processors'], AfterRun=after_dir, Results=summary)
(root / 'comparison.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
