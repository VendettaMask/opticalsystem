using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
var root=Path.GetFullPath(".");
var testPath=Path.Combine(root,"tests/OpticalSystemDesign.Tests/bin/Release/net10.0");
AppContext.SetData("APP_CONTEXT_BASE_DIRECTORY",testPath+Path.DirectorySeparatorChar);
AssemblyLoadContext.Default.Resolving+=(context,name)=>
{
    var path=Path.Combine(testPath,name.Name+".dll");
    return File.Exists(path)?context.LoadFromAssemblyPath(path):null;
};
AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(root,args[0]));
var assembly=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(testPath,"OpticalSystemDesign.Tests.dll"));
var energyType=assembly.GetType("OpticalSystemDesign.Tests.PolychromaticCumulativeEnergyTests")!;
var energy=Activator.CreateInstance(energyType);
var method=energyType.GetMethod("ReferenceConeAndExplicitIntervalCloseTheCapturedPolychromaticCurves")!;
var results=new List<object>();
foreach(var id in new[]{"apo-poly64","0014-all-waves","0308-all-waves","isolate-w8"})
    foreach(var series in new[]{0,1}) Invoke(method,energy,[id,series],id+"/"+series);
var statusType=assembly.GetType("OpticalSystemDesign.Tests.OpticalNumericalConsistencyTests")!;
var outcomeType=assembly.GetReferencedAssemblies().First(a=>a.Name=="OpticalSystemDesign.Core");
var core=Assembly.Load(outcomeType);
var unavailable=Enum.Parse(core.GetType("OpticalSystemDesign.Core.Analysis.AnalysisOutcome")!,"Unavailable");
Invoke(statusType.GetMethod("StatusPagesKeepTypedOutcomeAcrossRuntimeAndDto")!,Activator.CreateInstance(statusType),["Incoherent Irradiance",unavailable],"Incoherent Irradiance status");
File.WriteAllText(args[1],JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true}));
void Invoke(MethodInfo m,object? instance,object?[] inputs,string name)
{
    try { m.Invoke(instance,inputs);results.Add(new {Case=name,Passed=true,Error=""}); }
    catch(TargetInvocationException error)
    {
        var inner=error.InnerException!;
        results.Add(new {Case=name,Passed=false,Error=inner.GetType().Name+": "+inner.Message});
        Console.WriteLine(name+": "+inner.Message);
    }
}
