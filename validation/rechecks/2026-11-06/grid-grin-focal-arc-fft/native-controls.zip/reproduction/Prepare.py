import sys, hashlib, json, re
from pathlib import Path
from itertools import product

root, previous, fine = map(Path, sys.argv[1:])
batch = root / 'transport'
sources = batch / 'sources'
requests = batch / 'requests'
for d in (sources,requests):
    d.mkdir(parents=True, exist_ok=True)
job_list = []
def load(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,value): Path(p).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
def operands(code, surface, wave=1, py=0, hy=0):
    return dict(code=code,int1=surface,int2=wave,data1=0,data2=hy,data3=0,data4=py,data5=0,data6=0)
def add(name, source, req, queries):
    req = dict(req, adapter='surface-model-controls', input=str(source), inputSha256=hashlib.sha256(source.read_bytes()).hexdigest(),
               modelOperands=queries)
    target = requests / (name+'.json')
    write(target, req)
    job_list.append(dict(id=name,request=str(target),output=str(batch / name)))

old_synthetic = previous / 'native'
model_request = load(old_synthetic / 'requests/y-affine.json')
template = (old_synthetic / 'sources/y-affine.ZMX').read_text(encoding='utf-8-sig')
grid_length = 3.8
definitions = []
def case(name, slope=2, g=.02, q=0, n0=1.5, length=3.8, mesh=.1, step=.001, extra=0):
    definitions.append(dict(name=name,slope=slope,g=g,q=q,n0=n0,length=length,mesh=mesh,step=step,extra=extra))
for g in (-.04, -.02, -.01, .005, .01, .02, .04, .08):
    case(f'g{g:+.3f}',g=g)
for slope in (-2, -.5, .5, 1, 4, 8, 10, 12):
    case(f'z{slope:+g}',slope=slope,n0=10 if slope<0 else 1.5)
case('offset-n3',n0=3)
case('offset-n6',n0=6)
case('fine-mesh',mesh=.05)
case('short',length=1.9)
case('short-fine-step',length=1.9,step=.00025)
case('quadratic',g=0,q=-.02,mesh=.05)
case('mixed-quadratic',q=-.02,mesh=.05)
case('curved-axial',slope=.7,extra=.7)
case('curved-axial-reversed',slope=3.5,extra=-.42)
case('linear-fine-step',step=.00025)
for item in definitions:
    name,slope,g,q,n0,length,h,step,extra = (item[k] for k in ('name','slope','g','q','n0','length','mesh','step','extra'))
    nn = round(1/h)+1
    zz = [k*grid_length/20 for k in range(21)]
    xx = [k*h-.5 for k in range(nn)]
    grid = sources/(name+'.ggd')
    grid.write_text(f'schott {nn} {nn} 21 {h:.17g} {h:.17g} .19\n'+''.join(
        f'{x:.17g} {y:.17g} {z:.17g} {n0+slope*z+extra*z*z+g*y+q*y*y:.17g}'+' 0'*10+'\n'
        for x,y,z in product(xx,xx,zz)),encoding='ascii')
    source = sources/(name+'.ZMX')
    lens = re.sub(r'TYPE GRINSU11 .*',f'TYPE GRINSU11 {grid.as_posix()}',template)
    lens = re.sub(r'PARM 1 [^\n]+',f'PARM 1 {step:.9g}',lens)
    lens = re.sub(r'DISZ 3\.8\b',f'DISZ {length:.9g}',lens)
    source.write_text(lens,encoding='ascii')
    add(name,source,model_request,[operands('EFFL',0)]+[operands(code,3,py=py) for code,py in product(('PARY','PATY','REAY','REAB'),(-.1,0,.1))])
write(batch/'synthetics.json',definitions)

arc_request = load(fine/'native/requests/490-step0.001.json')
arc_model = fine/'native/grid-0.001.ZMX'
base = arc_model.read_text(encoding='utf-16')
assert base.count('DISZ 3.80E+00')==1
arc_stations=[]
for n in (0,1):
    for k in range(65):
        z = k*3.8/64
        # A second integration step on the same set of stations distinguishes integration error from chord discretization.
        step = (.001,.0005)[n]
        label=f'arc-{n}-{k:02d}'
        source=sources/(label+'.ZMX')
        lens=base.replace('PARM 1 0.001',f'PARM 1 {step}')
        if k:
            lens=lens.replace('DISZ 3.80E+00',f'DISZ {z:.17g}')
        source.write_text(lens,encoding='utf-16')
        add(label,source,arc_request,[operands(code,2 if k else 1,wave,py=.8) for code,wave in product(('REAX','REAY','REAZ'),(1,2,3))])
        arc_stations.append(dict(id=label,z=z,station=k,step=step))
write(batch/'stations.json',arc_stations)
write(batch/'native-jobs.json',job_list)
print(len(job_list))

