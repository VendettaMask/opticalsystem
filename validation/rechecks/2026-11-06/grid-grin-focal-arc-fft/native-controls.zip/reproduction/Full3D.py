import sys,numpy as np
from scipy.interpolate import make_interp_spline,NdBSpline
from scipy.integrate import solve_ivp
a=np.loadtxt(sys.argv[1],skiprows=1,encoding='utf-16').reshape(21,21,21,14)
axis=[a[:,0,0,0],a[0,:,0,1],a[0,0,:,2]]
c=a[:,:,:,3]
knots=[]
for k,x in enumerate(axis):
    s=make_interp_spline(x,c,k=3,axis=k,bc_type='natural')
    c=np.moveaxis(s.c,0,k)
    knots.append(s.t)
n=NdBSpline(tuple(knots),c,(3,3,3))
def trace(initial):
    def f(z,state):
        x,y,u,v=state.reshape(-1,4).T
        points=np.stack((x,y,np.full_like(x,z)),axis=1)
        factor=(1+u*u+v*v)/n(points)
        gz=n(points,nu=(0,0,1))
        return np.stack((u,v,(n(points,nu=(1,0,0))-u*gz)*factor,(n(points,nu=(0,1,0))-v*gz)*factor),axis=1).ravel()
    # All finite differences share the same solver steps to preserve small differences.
    return solve_ivp(f,(0,3.8),np.asarray(initial).ravel(),rtol=3e-14,atol=1e-16,max_step=.005,method='DOP853').y[:,-1].reshape(-1,4)
nn=n(np.array([[0,0,3.8]]))[0]
expected=10893.5332489438
for x,u,d in [(0,0,.002),(0,.002,.002),(.002,0,.002),(.002,.002,.002),(-.002,0,.002),(0,-.002,.002),(0,0,.001),(0,0,.0001),(0,0,.01)]:
    out=trace([[x,d,u,.002],[x,-d,u,.002]])
    matrix=(out[0]-out[1])/(2*d)
    efl=-1/(matrix[3]*nn)
    print(x,u,d,efl,efl-expected,matrix[1],out.mean(axis=0),flush=True)

