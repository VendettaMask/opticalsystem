import json,math,sys
from pathlib import Path
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
root,study=map(Path,sys.argv[1:])
batch=root/'transport'
lengths={}
for step in (.001,.0005):
    stations=[]
    for s in read(batch/'stations.json'):
        if s['step']!=step:continue
        path=batch/s['id']/'model-controls.json'
        if not path.exists(): break
        v={(r['input']['code'],r['input']['int2']):r['value'] for r in read(path)['rows']}
        assert all(abs(v['REAZ',w])<1e-10 for w in (1,2,3))
        stations.append((s['z'],v))
    if len(stations)!=65: continue
    lengths[str(step)]={}
    for wave in (1,2,3):
        coords=[(v['REAX',wave],v['REAY',wave],z) for z,v in stations]
        def arc(stride): return sum(math.dist(a,b) for a,b in zip(coords[::stride],coords[stride::stride]))
        counts={str(64//stride):arc(stride) for stride in (8,4,2,1)}
        extrapolated=(4*counts['64']-counts['32'])/3
        lengths[str(step)][wave]=dict(samples=counts,richardson=extrapolated,entrance=coords[0],exit=coords[-1])
out={'nativeArcIntegralsMm':lengths,'targetRequests':{}}
for index,wave in ((490,2),(507,1),(511,2),(515,3)):
    values=read(study/'analyses'/f'{index:04}'/'data.json')['values']
    core=next(row for row in values['RealRayData'] if row[0]==2)[11]
    coarse,fine=(lengths[step][wave] for step in ('0.001','0.0005'))
    direct=fine['samples']['64']
    reference=fine['richardson']
    gate=1e-6+1e-6*abs(reference)
    assert abs(coarse['richardson']-reference)<=gate and abs(core-reference)<=gate and abs(core-direct)<=gate
    out['targetRequests'][index]=dict(wave=wave,normalizedHx=0,normalizedHy=0,normalizedPx=0,normalizedPy=.8,
        coreArcMm=core,nativeExtrapolatedArcMm=reference,native64ChordArcMm=direct,
        absoluteErrorMm=abs(core-reference),absoluteErrorAgainstChordsMm=abs(core-direct),
        integrationStepDifferenceMm=abs(coarse['richardson']-reference),coordinateToleranceMm=gate,
        independentArcConclusion='Pass',builtInReportStillMissing=True)
print(json.dumps(out,indent=2))
(root/'arcs.json').write_text(json.dumps(out,indent=2)+'\n')

