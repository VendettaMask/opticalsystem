import json, math, sys
from pathlib import Path
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp

def solve(nz, g, q, length, epsilon, order=2):
    def deriv(z,v):
        y, u, a, c, b, e = v
        ax, dz = nz(z)
        n = ax + g*y + q*y*y
        dy = g+2*q*y
        numerator = dy-u*dz
        factor = 1+u*u if order == 2 else 1
        k = factor * (2*q/n-numerator*dy/(n*n))
        l = -factor*dz/n + (2*u*numerator/n if order == 2 else 0)
        return u, factor*numerator/n, c, k*a+l*c, e, k*b+l*e
    out = solve_ivp(deriv, (0,length), (0,epsilon,1,0,0,1), rtol=2e-12, atol=2e-15).y[:,-1]
    return out, (-1/(out[3]*nz(length)[0]) if abs(out[3])>1e-18 else None)

def fit_epsilon(nz, g, q, length, native):
    from scipy.optimize import root_scalar
    def f(epsilon):
        v = solve(nz,g,q,length,epsilon)[0]
        return v[3]*nz(length)[0]+1/native
    return root_scalar(f, x0=.002,x1=.0021,xtol=1e-14).root
def load(f): return json.loads(f.read_text(encoding='utf-8-sig'))
root, previous = map(Path,sys.argv[1:])
result = []
for spec in load(root / 'transport' / 'synthetics.json'):
    name = spec['name']
    path = root / 'transport' / name / 'model-controls.json'
    if not path.is_file(): continue
    data = load(path)['rows']
    v = data[0]['value']
    n = lambda z:(spec['n0']+spec['slope']*z+spec['extra']*z*z,spec['slope']+2*spec['extra']*z)
    if spec['extra']:
        cubic = CubicSpline([i*.19 for i in range(21)],[n(i*.19)[0] for i in range(21)],bc_type='natural')
        n = lambda z:(float(cubic(z)),float(cubic(z,1)))
    out,f = solve(n,spec['g'],spec['q'],spec['length'],.002)
    result.append((name,v,f,f/v-1 if f else None,fit_epsilon(n,spec['g'],spec['q'],spec['length'],v)))
for spec in load(previous / 'models.json'):
    name = spec['name']
    if 'sample-axis-y-affine' not in name and name not in ['y-affine','y-affine-negative','y-affine-double','y-affine-quadratic']: continue
    d=spec['item']['definition']
    cubic = CubicSpline([j['z'] for j in spec['indices']],[j['index'] for j in spec['indices']],bc_type='natural')
    n = lambda z:(float(cubic(z)),float(cubic(z,1)))
    v=spec['native']
    out,f=solve(n,d['linear'],d['q'],d['length'],.002)
    result.append((name,v,f,f/v-1,fit_epsilon(n,d['linear'],d['q'],d['length'],v)))
for name,v,f,err,fit in result: print(name,v,f,err,fit)
(root/'variational.json').write_text(json.dumps(result,indent=2))

