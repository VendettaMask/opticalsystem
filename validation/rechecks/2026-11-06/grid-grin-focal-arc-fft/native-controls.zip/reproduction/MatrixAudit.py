import math,json,sys,numpy as np
from pathlib import Path
from scipy.interpolate import make_interp_spline,NdBSpline
from scipy.integrate import solve_ivp
root=Path(sys.argv[1])
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
out=[]
for spec in read(root/'transport/synthetics.json'):
    name=spec['name']
    file=root/'followup'/f'{name}-matrix'/'model-controls.json'
    if not file.exists():continue
    h=spec['mesh']; nn=round(1/h)+1
    raw=np.loadtxt(root/'transport/sources'/f'{name}.ggd',skiprows=1).reshape(nn,nn,21,14)[nn//2]
    ys,zs=raw[:,0,1],raw[0,:,2]
    y=make_interp_spline(ys,raw[:,:,3],axis=0,bc_type='natural')
    z=make_interp_spline(zs,y.c,axis=1,bc_type='natural')
    n=NdBSpline((y.t,z.t),z.c.T,(3,3))
    length=spec['length']
    incoming,exit=n([[0,0],[0,length]])
    def f(z,v):
        y,u=v.reshape(-1,2).T
        pts=np.stack((y,np.full_like(y,z)),axis=1)
        return np.stack((u,(1+u*u)*(n(pts,nu=(1,0))-u*n(pts,nu=(0,1)))/n(pts)),axis=1).ravel()
    rays=[(.002,.002),(-.002,.002),(0,.002),(0,-.002),(.002,-.002),(.002,0),(.002,.004),(0,0),(0,.004)]
    yout,uout=solve_ivp(f,(0,length),np.asarray(rays).ravel(),rtol=3e-14,atol=1e-16,max_step=.005,method='DOP853').y[:,-1].reshape(-1,2).T
    s={(r['input']['int1'],r['input']['code'],r['input']['data2'],r['input']['data4']):r['value'] for r in read(file)['rows']}
    def col(surface,code,use_hy):
        return (s[surface,code,.1,0]-s[surface,code,-.1,0] if use_hy else s[surface,code,0,.1]-s[surface,code,0,-.1])/.2
    def coords(surface):
        return [[col(surface,'PARY',False),col(surface,'PARY',True)],[col(surface,'PATY',False),col(surface,'PATY',True)]]
    m=np.array(coords(3))@np.linalg.inv(np.array(coords(2)))
    # input column uses the direction after planar entrance refraction, output is in air.
    a=(yout[0]-yout[1])/.004;c=(uout[0]-uout[1])*exit/.004
    dirs={}
    for label,i,j in (('0,+/-.002',2,3),('.002,+/-.002',0,4),('.002,0/.004',6,5),('0,0/.004',8,7),('.002,0/.002',0,5),('0,0/.002',2,7)):
        t=rays[i][1]-rays[j][1]
        dirs[label]=[(yout[i]-yout[j])/t,(uout[i]-uout[j])*exit/t]
    candidate=[(yout[0]+yout[1])/.004,(uout[0]+uout[1])*exit/.004]; r=dict(name=name,matrix=m.tolist(),heightProbe=[a,c],sumProbe=candidate,errors=(m-np.array([[a,candidate[0]],[c,candidate[1]]])).tolist())
    print(name,'native',m.tolist(),'height',a,c,'closest',min(dirs,key=lambda k: np.linalg.norm(m[:,1]-dirs[k])))
    print("sums",candidate,"errors",r["errors"])
    out.append(r)
(root/'matrix-audit.json').write_text(json.dumps(out,indent=2))

