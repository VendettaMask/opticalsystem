import hashlib,json,re,sys
from pathlib import Path
from itertools import product
root, prior, controls, repo = map(Path,sys.argv[1:])
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v): p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
batch=root/'followup'
(batch/'sources').mkdir(parents=True,exist_ok=True)
(batch/'requests').mkdir(exist_ok=True)
jobs=[]
def add(name,source,req):
    req.update(input=str(source),inputSha256=hashlib.sha256(source.read_bytes()).hexdigest(),captureScreenshots=False)
    path=batch/'requests'/f'{name}.json'
    write(path,req)
    jobs.append(dict(id=name,request=str(path),output=str(batch/name)))

angle_cases=['g+0.020','g-0.020','z-2','z+4','quadratic','mixed-quadratic','fine-mesh','curved-axial','curved-axial-reversed']
for name in angle_cases:
    req=read(root/'transport/requests'/f'{name}.json')
    lens=(root/'transport/sources'/f'{name}.ZMX').read_text(encoding='ascii')
    lens=lens.replace('FTYP 0 0 1 1 0 0 0','FTYP 0 0 2 1 0 0 0').replace('XFLN 0\nYFLN 0','XFLN 0 0\nYFLN 0 0.5')
    lens=re.sub(r'PARM 1 [^\n]+','PARM 1 0.00025',lens)
    source=batch/'sources'/f'{name}-matrix.ZMX'
    source.write_text(lens,encoding='ascii')
    req.update(fieldCount=2,maximumFieldRadius=.5,definedFields=[[0,0],[0,.5]])
    req['modelOperands']=[dict(code=code,int1=s,int2=1,data1=0,data2=hy,data3=0,data4=py,data5=0,data6=0)
        for s,code,(hy,py) in product((2,3),('PARY','PATY'),((0,0),(0,.1),(.1,0),(-.1,0),(0,-.1),(.1,.1)))]
    add(name+'-matrix',source,req)
# Match the historical convergence windows and use compact text output where the API has an empty buffer.
target_495=read(controls/'fft-check/requests/495-step0.001.json')
target_495['zemaxSettings']['SampleSize']='PsfS_2048x2048'
target_495['pupilSampling']=2048
add('495-psf-2048',prior/'native/grid-0.001.ZMX',target_495)
profile_plan=read(repo/'artifacts/validation/incomparable-profile-native-step-confirmed-20261101/convergence-jobs.json')[0]
profile_dir=Path(profile_plan['nativeB'])
profile_req=read(profile_dir.parent/(profile_dir.name+'.request.json'))
# First-order and ray work is already done before the high-memory lanes.
add('499-profile-8192',prior/'native/grid-0.001.ZMX',dict(profile_req))
wide=dict(profile_req,zemaxSettings=dict(profile_req['zemaxSettings']))
wide['zemaxSettings']['SampleSize']='S_16384x16384'
wide['pupilSampling']=16384
add('499-profile-16384',prior/'native/grid-0.005.ZMX',wide)
energy_req=read(controls/'fft-check/requests/502-step0.001.json')
energy_req['zemaxSettings']['SampleSize']='S_8192x8192'
energy_req['pupilSampling']=8192
add('502-energy-8192',prior/'native/grid-0.001.ZMX',energy_req)
write(batch/'native-jobs.json',jobs)
print([(j['id'],j['request']) for j in jobs[-4:]])

