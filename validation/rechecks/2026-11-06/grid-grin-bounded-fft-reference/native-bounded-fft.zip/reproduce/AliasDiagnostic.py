from pathlib import Path
import sys,json
import numpy as np
from BoundedReadout import Grid, energy, curve_metrics
p=Path(sys.argv[1]); h=p/'historical'
small=Grid.load(h/'grid-495-1024-step.005')
small_fine=Grid.load(h/'grid-495-1024-step.001')
large=Grid.load(h/'grid-495-2048-step.005')
# Diagnostic only: folding intensity cannot restore missing coherent field.
# It isolates the centroid sensitivity of a too-small complete FFT period.
nx,ny=small.values.shape[1],small.values.shape[0]
sx=round((small.min_x-large.min_x)/large.dx)
sy=round((small.min_y-large.min_y)/large.dy)
fold=np.roll(large.values,(-sy,-sx),axis=(0,1)).reshape(2,ny,2,nx).sum(axis=(0,2))
alias=Grid(fold,small.dx,small.dy,small.min_x,small.min_y,'incoherent-fold')
gates=(1e-5,.002,.003,.01)
ref=large.whole()
res=dict(coarse=small.whole(),fine=small_fine.whole(),wide=ref,folded=alias.whole(),
         energyOutsideCoarseWindow=float(1-large.values[sy:sy+ny,sx:sx+nx].sum()/large.values.sum()))
def energy_curve(g, fix):
    m=g.whole()
    if fix:
        m.update(cx=ref['cx'],cy=ref['cy'])
    return energy(g,m,5,8,512,2000)[1]
res['fixedWideCentroidStepComparison']=curve_metrics(energy_curve(small,True),energy_curve(small_fine,True),*gates)
res['fixedWideCentroidCoarseVsWide']=curve_metrics(energy_curve(small,True),energy_curve(large,False),*gates)
res['fixedWideCentroidFineVsWide']=curve_metrics(energy_curve(small_fine,True),energy_curve(large,False),*gates)
res['eachGridOwnCentroidFineVsWide']=curve_metrics(energy_curve(small_fine,False),energy_curve(large,False),*gates)
print(json.dumps(res,indent=2))
(p/'readout'/'alias-diagnostics.json').write_text(json.dumps(res,indent=2)+'\n')
