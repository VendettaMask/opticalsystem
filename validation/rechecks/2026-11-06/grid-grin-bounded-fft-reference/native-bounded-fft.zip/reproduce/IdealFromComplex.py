from pathlib import Path
import json,sys
import numpy as np
from scipy.fft import fft2, ifft2
from BoundedReadout import Grid,energy,curve_metrics,read

root=Path(sys.argv[1])
complex_path=root/'complex-native'
results={}
curves={}
gate=(1e-5,.002,.003,.01)
for kind,linear_name in [('control','control-full-256'),('grid','grid-full-512')]:
    lpath=root/'native-full'/linear_name
    rpath=complex_path/(kind+'-real')
    ipath=complex_path/(kind+'-imaginary')
    if not all((folder/'psf-grid.json').is_file() for folder in (lpath,rpath,ipath)):continue
    linear,re,im=map(Grid.load,(lpath,rpath,ipath))
    for g in (re,im):
        if (g.dx,g.dy,g.min_x,g.min_y,g.values.shape)!=(linear.dx,linear.dy,linear.min_x,linear.min_y,linear.values.shape):
            raise ValueError('Complex FFT outputs must share the linear PSF grid.')
    complex_image=re.values+1j*im.values
    derived=abs(complex_image)**2
    abs_err=float(np.max(abs(derived-linear.values)))
    relative_rms=float(np.sqrt(np.mean((derived-linear.values)**2))/linear.values.max())
    if not np.allclose(derived,linear.values,rtol=2e-11,atol=1e-13):raise ValueError((kind,abs_err,relative_rms))
    # The inverse transform of the signed native focal field contains the
    # original complex pupil. Dropping only its phase retains illumination,
    # projected aperture, and total power.
    pupil=abs(ifft2(complex_image))
    origin=(round(-linear.min_y/linear.dy),round(-linear.min_x/linear.dx))
    ideal_values=np.roll(abs(fft2(pupil))**2,origin,axis=(0,1))
    energy_rel=abs(ideal_values.sum()/derived.sum()-1)
    if energy_rel>2e-12:raise ValueError('Parseval power changed in the zero-phase transform.')
    ideal=Grid(ideal_values,linear.dx,linear.dy,linear.min_x,linear.min_y,kind+'-zero-phase')
    whole=ideal.whole()
    r0,e0=energy(ideal,whole,5,8,512,1000)
    r,e1=energy(ideal,whole,5,16,1024,2000)
    result=dict(linearComplexMaxAbs=abs_err,linearComplexNrmse=relative_rms,zeroPhaseFluxRelError=float(energy_rel),
        pupilPeak=float(pupil.max()),pupilSignificantNodes=int(np.count_nonzero(pupil>pupil.max()*1e-8)),
        centroid=[whole['cx'],whole['cy']],zeroPhaseAt5=float(e1[-1]),
        quadrature=curve_metrics(e0,np.interp(r0,r,e1),*gate))
    # Re-evaluate the same physical pupil on two independently decimated
    # parity grids. The doubled pupil step and halved transform length
    # preserve image spacing; both grids retain the aperture footprint.
    parity_comparisons={}
    for parity in (0,1):
        decimated=pupil[parity::2,parity::2]
        ny,nx=decimated.shape
        kx,ky=nx//2-1,ny//2-1
        f=Grid(np.roll(abs(fft2(decimated))**2,(ky,kx),axis=(0,1)),linear.dx,linear.dy,
            -kx*linear.dx,-ky*linear.dy,'zero-phase-coarse')
        ee=energy(f,f.whole(),5,8,512,2000)[1]
        parity_comparisons[str(parity)]=curve_metrics(ee,e1,*gate)
    result['pupilDecimation']=parity_comparisons
    curves[kind]=e1
    if kind=='control':
        for n in (1024,2048):
            reference=read(root/'native-full'/f'control-native-energy-{n}'/'data.json')['dataSeries'][0]
            result['idealVsNative'+str(n)]=curve_metrics(np.interp(reference['x'],r,e1),np.array(reference['y']).reshape(-1),*gate)
    results[kind]=result
    print(kind,result,flush=True)
out=root/'readout'
(out/'ideal-comparisons.json').write_text(json.dumps(results,indent=2)+'\n')
if curves:np.savez_compressed(out/'ideal-curves.npz',radius=r,**curves)


