import sys,json,itertools
from pathlib import Path
import numpy as np
from scipy.fft import ifft2,fftshift
from scipy.ndimage import map_coordinates
from BoundedReadout import Grid,read

p=Path(sys.argv[1]); c=p/'complex-native'
re,im=[Grid.load(c/'grid-real'),Grid.load(c/'grid-imaginary')]
origin=(round(-re.min_y/re.dy),round(-re.min_x/re.dx))
pupil=fftshift(ifft2(np.roll(re.values+1j*im.values,(-origin[0],-origin[1]),axis=(0,1))))
amp=abs(pupil)
mask=amp>amp.max()*1e-8
yy,xx=np.nonzero(mask)
print('pupil support',xx.min(),xx.max(),yy.min(),yy.max(),origin)
g=read(p/'phase-controls/wavefront-0.005/data.json')['dataGrids'][0]
w=np.asarray(g['values'],dtype=float)
target=np.asarray(g['values'],dtype=float)
n=w.shape[0]
cases=[]
for xzero,yzero in itertools.product((31,31.5,32),repeat=2):
  for dx,dy in [(255,255),((xx.max()-xx.min())/2,(yy.max()-yy.min())/2)]:
    for sx,sy,psign in itertools.product((-1,1),repeat=3):
      y,x=np.indices(w.shape)
      iy=512+dy*(y-yzero)/31*sy
      ix=512+dx*(x-xzero)/31*sx
      q=map_coordinates(pupil.real,(iy,ix),order=1)+1j*map_coordinates(pupil.imag,(iy,ix),order=1)
      valid=np.isfinite(w) & (abs(q)>amp.max()*.7)
      phase=np.exp(-2j*np.pi*psign*w[valid])*q[valid]/abs(q[valid])
      coherence=abs(phase.mean())
      cases.append((coherence,int(valid.sum()),xzero,yzero,dx,dy,sx,sy,psign))
for row in sorted(cases,reverse=True)[:8]: print(row)
