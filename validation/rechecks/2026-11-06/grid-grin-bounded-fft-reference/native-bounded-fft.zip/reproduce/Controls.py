import json,hashlib,sys
from pathlib import Path
p=Path(sys.argv[1]); root=p/'controls'; old=p/'native-full'; (root/'requests').mkdir(parents=True,exist_ok=True)
def read(x):return json.loads(x.read_text(encoding='utf-8-sig'))
def write(x,v):x.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
source=root/'defocused.ZMX'
source.write_text((p/'native/focal-control.ZMX').read_text().replace('DISZ 50\n','DISZ 50.4\n'),encoding='ascii')
jobs=[]
def add(name,q,src):
    q.update(input=str(src),inputSha256=hashlib.sha256(src.read_bytes()).hexdigest())
    req=root/'requests'/f'{name}.json';write(req,q);jobs.append(dict(id=name,request=str(req),output=str(root/name)))
for n in (256,512):
    add(f'defocus-full-{n}',read(old/'requests'/f'control-full-{n}.json'),source)
for n in (1024,2048):
    add(f'defocus-energy-{n}',read(old/'requests'/f'control-native-energy-{n}.json'),source)
q=read(old/'requests/control-full-256.json')
q.update(adapter='inspect-settings',analysisTypes=['PartiallyCoherentImageAnalysis'],captureInspectionResults=False)
add('inspect-partial-coherence',q,source)
write(root/'native-jobs.json',jobs)
