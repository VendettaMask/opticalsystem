from pathlib import Path
import argparse, hashlib, json

def main():
    p=argparse.ArgumentParser()
    p.add_argument('stage',type=Path,help='Unpacked capture stage in the evidence bundle')
    p.add_argument('destination',type=Path,help='Fresh directory for replay')
    p.add_argument('zosapi',type=Path,help='Licensed OpticStudio 2026 R1 installation directory')
    p.add_argument('--jobs',nargs='*',default=[])
    o=p.parse_args()
    if o.destination.exists():
        raise FileExistsError('Choose a fresh replay directory')
    if not (o.zosapi/'ZOSAPI_Interfaces.dll').is_file():
        raise FileNotFoundError('The ZOS-API interface assembly was not found')
    out=o.destination.resolve()
    (out/'requests').mkdir(parents=True)
    requests=sorted((o.stage/'requests').glob('*.json'))
    jobs=[]
    for f in requests:
        if o.jobs and f.stem not in o.jobs:continue
        q=json.loads(f.read_text(encoding='utf-8-sig'))
        lens=(o.stage/'sources'/Path(q['input']).name).resolve()
        if hashlib.sha256(lens.read_bytes()).hexdigest()!=q['inputSha256']:
            raise ValueError(f'Input hash differs {lens}')
        q.update(input=str(lens),zosApiPath=str(o.zosapi.resolve()))
        target=out/'requests'/f.name
        target.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        jobs.append(dict(id=f.stem,request=str(target),output=str(out/f.stem)))
    if not jobs or (o.jobs and {j['id'] for j in jobs}!=set(o.jobs)):
        raise ValueError('One or more requested recipes are absent')
    (out/'native-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':main()
