import json,sys
from pathlib import Path
p=Path(sys.argv[1]); old=p/'native'; run=p/'native-full'; (run/'requests').mkdir(parents=True,exist_ok=True)
def read(x):return json.loads(x.read_text(encoding='utf-8-sig'))
def write(x,v):x.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
jobs=[]
def add(name,q):
    req=run/'requests'/(name+'.json');write(req,q);jobs.append(dict(id=name,request=str(req),output=str(run/name)))
for name,n in [('control-full-256',256),('control-full-512',512),('grid-full-512',512),('grid-full-1024',1024),('grid-full-512-step0.001',512)]:
    q=read(old/'requests'/f'{name}.json')
    q.update(pupilSampling=n,imageSampling=2*n,gridSize=2*n,imageDeltaMicrometers=-1)
    add(name,q)
    if name=='control-full-256':
        q=dict(q, imageDeltaMicrometers=0, zemaxSettings=dict(q['zemaxSettings'],ImageDelta=0))
        add('control-default-256',q)
    if name=='control-full-512':
        for n in (1024,2048):
            q=read(old/'requests/control-native-energy.json')
            q.update(pupilSampling=n)
            q['zemaxSettings']['SampleSize']=f'S_{n}x{n}'
            add(f'control-native-energy-{n}',q)
write(run/'native-jobs.json',jobs)
