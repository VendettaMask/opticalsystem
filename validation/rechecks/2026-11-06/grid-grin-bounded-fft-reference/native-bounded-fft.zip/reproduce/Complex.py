from pathlib import Path
import json,sys
p=Path(sys.argv[1]); old=p/'native-full'
r=p/'complex-native'; (r/'requests').mkdir(parents=True,exist_ok=True)
def read(x):return json.loads(x.read_text(encoding='utf-8-sig'))
def write(x,v):x.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
jobs=[]
for prefix,readname in [('control','control-full-256'),('grid','grid-full-512')]:
    for part in ('Real','Imaginary'):
        q=read(old/'requests'/f'{readname}.json')
        q.update(adapter='contract',nativePsfComponent=part)
        q['zemaxSettings']['Type']=part
        name=f'{prefix}-{part.lower()}'
        req=r/'requests'/f'{name}.json'
        write(req,q)
        jobs.append(dict(id=name,request=str(req),output=str(r/name)))
write(r/'native-jobs.json',jobs)
