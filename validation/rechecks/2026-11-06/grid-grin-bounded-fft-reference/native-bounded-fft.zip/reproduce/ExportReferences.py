from pathlib import Path
import json,sys
import numpy as np
from BoundedReadout import read,profile_file,curve_metrics
root,out,repo=map(Path,sys.argv[1:])
out.mkdir(parents=True,exist_ok=True)
r=root/'readout'
curves=np.load(r/'curves.npz')
ideal=np.load(r/'ideal-curves.npz')
native=read(r/'comparisons.json')
product=read(root/'product-comparisons.json')
history=repo/'artifacts/validation/incomparable-grid-pending-native-refinement-20261101'
def profile(name):
    return profile_file(history/('job-'+name)/name/'data.txt')
coarse,fine=map(profile,('profile-8192-window317-step.005','profile-8192-step.001'))
assert np.max(abs(coarse[:,0]-fine[:,0]))<1e-8
gates=(1e-5,.002,.003,.01)
step_profile=curve_metrics(coarse[:,1],fine[:,1],*gates)
x=curves['profile_axis_grid']
assert len(x)==len(fine) and np.max(abs(x-fine[:,0]))<8e-6
profile_ref=curves['profile-grid-495-2048-step.005']
pkey='grid-495-2048-step.005~native-cross-8192'
pstatus=(step_profile['verdict']=='Pass' and native['profileComparisons'][pkey]['verdict']=='Pass'
    and all(product[k]['comparisons']['profile-grid-495-2048-step.005']['verdict']=='Pass' for k in
            ('profile-8192-window317','profile-16384-window317')))
np.savetxt(out/'profile-reference.csv',np.column_stack((x,profile_ref,fine[:,1])),delimiter=',',fmt='%.15g',
           header='position_um,bounded_native_psf_irradiance,direct_native_8192_irradiance',comments='')
actual_case=next(name for name in ('grid-full-512-step0.001','grid-full-512-step0.0025','grid-full-512') if 'energy-'+name in curves)
e=curves['energy-'+actual_case]
radius=curves['radius']
assert np.allclose(radius,ideal['radius'],rtol=0,atol=1e-12)
edata=np.column_stack((radius[::5],e[::5],ideal['grid'][::5]))
np.savetxt(out/'energy-reference.csv',edata,delimiter=',',fmt='%.15g',
           header='radius_um,actual_encircled_fraction,zero_phase_encircled_fraction',comments='')
earlier_step=native['energyComparisons'].get('grid-full-512~grid-full-512-step0.0025')
actual_step=native['energyComparisons'].get('grid-full-512-step0.0025~grid-full-512-step0.001')
higher_sampling_at_other_step=native['energyComparisons'].get('grid-full-512-step0.001~grid-495-2048-step.005')
actual_sampling=native['energyComparisons']['grid-full-512~grid-495-2048-step.005']
ideal_checks=read(r/'ideal-comparisons.json')['grid']
estatus=(actual_step is not None and actual_step['verdict']=='Pass' and actual_sampling['verdict']=='Pass' and
    higher_sampling_at_other_step is not None and higher_sampling_at_other_step['verdict']=='Pass' and
    ideal_checks['quadrature']['verdict']=='Pass' and
    all(v['verdict']=='Pass' for v in ideal_checks['pupilDecimation'].values()) and
    all(product[k]['comparisons'][q]['verdict']=='Pass' for k in ('energy-65536','energy-131072')
        for q in ('energy-'+actual_case,'energy-zero-phase-grid')))
data=dict(profile=dict(index=499,status='Pass' if pstatus else 'Open',scope='bounded independent native FFT PSF readout',
    nativeDirectIntegrationStep=step_profile,nativeHigherEffectiveSampling=native['profileComparisons'][pkey],
    minPositionUm=float(x[0]),maxPositionUm=float(x[-1]),sampleCount=len(x)),
    energy=dict(index=502,status='Pass' if estatus else 'Open',scope='bounded independent native full PSF integration',
        actualCase=actual_case,actualStep=actual_step,earlierStep=earlier_step,actualSampling=actual_sampling,
        finerVsDenserNative=higher_sampling_at_other_step,idealChecks=ideal_checks,
        actualAt5=float(e[-1]),idealAt5=float(ideal['grid'][-1])),
    coreSha256=read(root/'study/identity.json')['coreSha256'], originalMatrixModified=False)
(out/'reference-certificate.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2))
