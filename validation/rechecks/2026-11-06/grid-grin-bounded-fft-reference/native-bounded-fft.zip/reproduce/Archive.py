from pathlib import Path
import hashlib,json,sys,zipfile

root,out,repo=map(Path,sys.argv[1:])
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
manifest=[]
cases=[]
seen=set()
out.mkdir(parents=True,exist_ok=True)
bundle=out/'native-bounded-fft.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def include(source,name):
        if name in seen or not source.is_file():return
        data=source.read_bytes()
        z.writestr(name,data)
        manifest.append(dict(path=name,sha256=sha(data),bytes=len(data)))
        seen.add(name)
    for stage in ('native','native-full','auto-native','controls','complex-native','refinement','refinement-fine','phase-controls','phase-controls-128'):
        directory=root/stage
        if not (directory/'native-jobs.json').is_file():continue
        include(directory/'native-jobs.json',stage+'/native-jobs.json')
        include(directory/'native.log',stage+'/native.log')
        for host in ('host','host-v2'):
            for item in ('source-identities.json','NativeBinaryPsf.cs'):
                include(directory/host/item,stage+'/'+host+'/'+item)
        for job in read(directory/'native-jobs.json'):
            capture=Path(job['output'])
            req=Path(job['request'])
            receipt=capture/'batch-result.json'
            if not receipt.is_file():continue
            v=read(req)
            lens=Path(v['input'])
            if sha(lens.read_bytes())!=v['inputSha256']:raise ValueError('Native lens hash changed')
            include(req,stage+'/requests/'+req.name)
            include(lens,stage+'/sources/'+lens.name)
            for name in ('batch-result.json','model.json','environment.json','captured-settings.json','settings.CFG',
                         'psf-grid.json','grid-f64le.bin','data.json','data.txt','error.json','result-diagnostics.json'):
                # Native shape-limited control receipts are tiny. The full native PSFs use only binary.
                include(capture/name,stage+'/capture/'+job['id']+'/'+name)
            cases.append(dict(stage=stage,job=job['id'],inputSha256=v['inputSha256'],receipt=read(receipt)))
    for script in ('NativeBinaryPsf.cs','Run-BinaryNative.ps1','Prepare.py','Corrected.py','Controls.py','Complex.py','Refine.py',
                   'ReadNativePsf.py','BoundedReadout.py','IdealFromComplex.py','CompareProduct.py','AliasDiagnostic.py',
                   'ExportReferences.py','PhaseCheck.py','PhaseAlignment.py','PropagatePhaseDiagnostic.py','CheckReadoutMath.py','RebaseRequests.py','Run-BinaryNative-Portable.ps1','Archive.py'):
        include(root/script,'reproduce/'+script)
    include(root/'rebase-test/exact-match.json','reproduce/portable-replay.json')
    include(root/'readout/math-self-check.json','reproduce/math-self-check.json')
    profile_base=repo/'artifacts/validation/incomparable-grid-pending-native-refinement-20261101'
    for label in ('profile-8192-window317-step.005','profile-8192-step.001'):
        directory=profile_base/('job-'+label)/label
        for name in ('data.txt','data.json','captured-settings.json','environment.json','result-diagnostics.json'):
            include(directory/name,'historical/'+label+'/'+name)
    for label in ('profile-8192-window317','profile-16384-window317','energy-65536','energy-131072'):
        directory=root/'product'/label
        include(root/'product'/(label+'.json'),'product/requests/'+label+'.json')
        for name in ('data.json','provenance.json','execution.json'):
            include(directory/name,'product/capture/'+label+'/'+name)
    for name in ('grid-495-1024-step.005','grid-495-1024-step.001','grid-495-2048-step.005'):
        include(root/'historical'/name/'psf-grid.json','historical/'+name+'/psf-grid.json')
with zipfile.ZipFile(bundle) as z:
    if z.testzip() is not None:raise ValueError('ZIP CRC failure')
    for f in manifest:
        data=z.read(f['path'])
        if sha(data)!=f['sha256'] or len(data)!=f['bytes']:raise ValueError(f)
meta=dict(cases=cases,members=manifest,zipSha256=sha(bundle.read_bytes()),zipBytes=bundle.stat().st_size,
    canceledControls=['first attempt at 512 used historical canonical fields; stopped after readback exposed mismatch',
                      'un-stretched 1024 native full-grid duplicate stopped in favor of exact 512-only step refinement'],
    externalHistoricalFullPsfText=[read(root/'historical'/name/'psf-grid.json') for name in
       ('grid-495-1024-step.005','grid-495-1024-step.001','grid-495-2048-step.005')])
(out/'native-inputs.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(len(cases),'native receipts,',len(manifest),'verified files,',meta['zipBytes'],'archive bytes')

