import json,sys,itertools
from pathlib import Path
import numpy as np
p=Path(sys.argv[1])
source=p/'phase-controls'
pairs={}
for a,b in itertools.combinations(('0.005','0.0025','0.001','0.0005'),2):
    fa,fb=[source/('wavefront-'+s)/'data.json' for s in (a,b)]
    if not fa.is_file() or not fb.is_file():continue
    z=[json.loads(f.read_text(encoding='utf-8-sig')) for f in (fa,fb)]
    g=[d['dataGrids'][0] for d in z]
    for k in ('nx','ny','dx','dy','minX','minY'):
        if g[0][k]!=g[1][k]:raise ValueError('Physical wavefront sampling coordinates differ')
    v=[np.array(d['values'],dtype=float) for d in g]
    x,y=np.meshgrid(g[0]['minX']+np.arange(g[0]['nx'])*g[0]['dx'],g[0]['minY']+np.arange(g[0]['ny'])*g[0]['dy'])
    physical=(x*x+y*y)<=1
    ok=physical & np.isfinite(v[0]) & np.isfinite(v[1]) & (abs(v[0])<1e9) & (abs(v[1])<1e9)
    err=v[0][ok]-v[1][ok]
    hi=max(abs(v[1][ok]))
    pairs[a+'~'+b]=dict(validCount=len(err),maxAbsoluteWaves=float(max(abs(err))),rmsWaves=float(np.sqrt(np.mean(err**2))),
        nrmse=float(np.sqrt(np.mean(err**2))/hi),stdWithoutPistonWaves=float(np.std(err)),peakReferenceWaves=float(hi))
print(json.dumps(pairs,indent=2))
(p/'phase-comparisons.json').write_text(json.dumps(pairs,indent=2)+'\n')
