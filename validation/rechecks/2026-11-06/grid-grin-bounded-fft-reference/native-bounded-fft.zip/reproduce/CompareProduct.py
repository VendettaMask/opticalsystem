import sys,json
from pathlib import Path
import numpy as np
from BoundedReadout import curve_metrics,read
root=Path(sys.argv[1]); curves=np.load(root/'readout/curves.npz'); out={}
settings=read(root/'study/rows.json')
for name in ('profile-8192-window317','profile-16384-window317','energy-65536','energy-131072'):
    p=root/'product'/name/'data.json'
    if not p.is_file():continue
    a=read(p)
    index=499 if name.startswith('profile') else 502
    gate=next(iter(settings[index-1]['settings']['quantities'].values()))
    thresholds=[gate[k] for k in ('absolute','relative','nrmse','closeNrmse')]
    values={}
    for s in a['plotSeries']:
        if s['name']=='衍射极限':
            i=root/'readout/ideal-curves.npz'
            if i.is_file():
                ideal=np.load(i)
                if 'grid' in ideal:
                    x=np.array([pt['x'] for pt in s['points']])
                    y=np.array([pt['y'] for pt in s['points']])
                    radii=ideal['radius']
                    values['energy-zero-phase-grid']=curve_metrics(np.interp(radii,x,y),ideal['grid'],*thresholds)
            continue
        x=np.array([pt['x'] for pt in s['points']])
        y=np.array([pt['y'] for pt in s['points']])
        is_profile=index==499
        ref_axis=curves['profile_axis_grid' if is_profile else 'radius']
        refs=[k for k in curves.files if k.startswith('profile-grid' if is_profile else 'energy-grid')]
        for k in refs:
            if ref_axis[0]<x[0]-1e-8 or ref_axis[-1]>x[-1]+1e-8: raise ValueError(f'{name} lacks full native domain')
            values[k]=curve_metrics(np.interp(ref_axis,x,y),curves[k],*thresholds)
    out[name]=dict(gate=gate,comparisons=values,core=read(root/'product'/name/'execution.json'))
for low,high,index in (('profile-8192-window317','profile-16384-window317',499),('energy-65536','energy-131072',502)):
    first=root/'product'/low/'data.json'
    last=root/'product'/high/'data.json'
    if not first.is_file() or not last.is_file():continue
    a=read(first)['plotSeries']
    b=read(last)['plotSeries']
    gate=next(iter(settings[index-1]['settings']['quantities'].values()))
    thresholds=[gate[k] for k in ('absolute','relative','nrmse','closeNrmse')]
    curves={}
    for x,y in zip(a,b,strict=True):
        if x['name']!=y['name']:raise ValueError('Compared series identities differ')
        xx=np.array([pt['x'] for pt in x['points']])
        yy=np.array([pt['y'] for pt in x['points']])
        fx=np.array([pt['x'] for pt in y['points']])
        fy=np.array([pt['y'] for pt in y['points']])
        if abs(xx[0]-fx[0])>1e-8 or abs(xx[-1]-fx[-1])>1e-8:raise ValueError('Core sampling changed physical extent')
        curves[x['name']]=curve_metrics(np.interp(fx,xx,yy),fy,*thresholds)
    out[low+'~'+high]=dict(comparisons=curves,gate=gate)
print(json.dumps(out,indent=2))
(root/'product-comparisons.json').write_text(json.dumps(out,indent=2)+'\n')

