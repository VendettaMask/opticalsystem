import json,sys
from pathlib import Path
import numpy as np
from scipy.special import j1
from BoundedReadout import Grid,energy

n=64
period=16.
pitch=period/n
axis=(np.arange(n)-(n-1)/2)*pitch
intensity=lambda x,y: 1+.2*np.cos(2*np.pi*x/period)+.15*np.cos(4*np.pi*y/period)
grid=Grid(intensity(axis[None,:],axis[:,None]),pitch,pitch,axis[0],axis[0],'analytic')
x=np.linspace(-2.3,2.3,129)
y=np.linspace(-2.7,2.7,151)
fine=grid.window(x,y,rows_per_block=7)
direct=intensity(x[None,:],y[:,None])
xy_error=float(np.max(abs(fine-direct)))
block_error=float(np.max(abs(fine-grid.window(x,y,rows_per_block=32))))
full=grid.whole()
r,computed=energy(grid,full,3,8,512,2000)
q=2*np.pi*r/period
def kernel(x):
    return np.divide(2*j1(x),x,out=np.ones_like(x),where=x!=0)
expected=np.pi*r*r*(1+.2*kernel(q)+.15*kernel(2*q))/(period*period)
enclosed_error=float(np.max(abs(computed-expected)))
centroid_max=max(abs(full['cx']),abs(full['cy']))
assert xy_error<1e-10 and block_error<1e-10 and enclosed_error<1e-8 and centroid_max<1e-10
result=dict(maxWindowError=xy_error,maxBlockSizeDifference=block_error,maxDiskIntegralError=enclosed_error,
    maxCentroidError=centroid_max,fullPower=full['total'],analyticFullPower=period*period)
(Path(sys.argv[1])/'readout/math-self-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
