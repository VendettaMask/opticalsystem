import sys,json
from pathlib import Path
import numpy as np
from scipy.fft import ifft2,ifftshift,fft2,fftshift
from scipy.ndimage import map_coordinates
from BoundedReadout import Grid,read,energy,curve_metrics
p=Path(sys.argv[1]); c=p/'complex-native'
size=int(sys.argv[2]) if len(sys.argv)>2 else 64
phase_directory='phase-controls' if size==64 else f'phase-controls-{size}'
re,im=[Grid.load(c/'grid-real'),Grid.load(c/'grid-imaginary')]
origin=(round(-re.min_y/re.dy),round(-re.min_x/re.dx))
pupil=fftshift(ifft2(np.roll(re.values+1j*im.values,(-origin[0],-origin[1]),axis=(0,1))))
amp=abs(pupil);mask=amp>amp.max()*1e-8
yy,xx=np.indices(pupil.shape)
def wavefront(step):
    g=read(p/phase_directory/('wavefront-'+step)/'data.json')['dataGrids'][0]
    return np.asarray(g['values'],dtype=float)
base=wavefront('0.005')
records={}
curves={}
for step in ('0.0025','0.001','0.0005'):
    if not (p/phase_directory/('wavefront-'+step)/'data.json').is_file():continue
    delta=wavefront(step)-base
    finite=np.isfinite(delta)
    n=len(delta)
    iy=n//2-(yy-512)*(n//2-1)/255
    ix=n//2-(xx-512)*(n//2-1)/255
    v=map_coordinates(np.where(finite,delta,0),(iy,ix),order=1,prefilter=False)
    weight=map_coordinates(finite.astype(float),(iy,ix),order=1,prefilter=False)
    accepted=weight>1-1e-10
    phase=np.where(accepted,v,0)
    upd=pupil*np.exp(2j*np.pi*phase)
    new=abs(np.roll(fft2(ifftshift(upd)),origin,axis=(0,1)))**2
    case={'0.0025':'refinement','0.001':'refinement-fine'}.get(step)
    metrics={}
    obs_path=(p/case/('grid-full-512-step'+step)) if case else None
    obs=Grid.load(obs_path) if obs_path and (obs_path/'psf-grid.json').exists() else None
    g=Grid(new,obs.dx if obs else re.dx,obs.dy if obs else re.dy,obs.min_x if obs else re.min_x,obs.min_y if obs else re.min_y,'phase-diagnostic')
    full=g.whole()
    r,e=energy(g,full,5,8,512,2000)
    rec=dict(coverage=float((accepted&mask).sum()/mask.sum()),projectedEnergyAt5=float(e[-1]),cx=full['cx'],cy=full['cy'])
    if obs:
        er=energy(obs,obs.whole(),5,8,512,2000)[1]
        rec['againstDirectNative']=curve_metrics(e,er,1e-5,.002,.003,.01)
        rec['nativeAt5']=float(er[-1])
    print(step,rec)
    records[step]=rec
(p/f'readout/phase-propagation-diagnostic-{size}.json').write_text(json.dumps(records,indent=2)+'\n')
