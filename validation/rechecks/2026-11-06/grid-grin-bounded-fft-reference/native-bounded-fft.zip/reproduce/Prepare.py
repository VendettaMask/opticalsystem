from pathlib import Path
import sys,json,hashlib
root, fine, latest, previous = map(Path,sys.argv[1:])
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
r=root/'native'
(r/'requests').mkdir(parents=True,exist_ok=True)
psf=read(latest/'fft-psf/requests/495-psf-1024.json')
profile=read(latest/'followup/requests/499-profile-8192.json')
energy=read(latest/'fft-bounds/requests/502-energy-8192.json')
synthetic=r/'focal-control.ZMX'
synthetic.write_text("""VERS 200426 262 0
MODE SEQ
UNIT MM X W X CM MR CPMM
ENPD 10
FTYP 0 0 1 1 0 0 0
XFLN 0
YFLN 0
WAVM 1 .55 1
PWAV 1
SURF 0
 TYPE STANDARD
 CURV 0
 DISZ INFINITY
SURF 1
 STOP
 TYPE PARAXIAL
 CURV 0
 PARM 1 50
 DISZ 50
 DIAM 5.01 1 0 0 1 ""
SURF 2
 TYPE STANDARD
 CURV 0
 DIAM 6 1 0 0 1 ""
""",encoding='ascii')
jobs=[]
def add(name,base,source,settings, compact=False,control=False):
    q=dict(base,zemaxSettings=dict(base['zemaxSettings'],**settings),input=str(source),inputSha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        captureScreenshots=False,nativeAsyncApplyPolling=False)
    if compact:q['nativeBinaryPsf']=True
    if control:
        q.update(wavelength=1,wavelengthCount=1,surfaceCount=3)
        q['zemaxSettings']['Wavelength']=1
    req=r/'requests'/f'{name}.json'
    write(req,q)
    jobs.append(dict(id=name,request=str(req),output=str(r/name)))
def pupil(name,sample,source,control=False):
    add(name,psf,source,dict(SampleSize=f'PsfS_{sample}x{sample}',OutputSize=f'PsfS_{2*sample}x{2*sample}',ImageDelta=-1),True,control)
pupil('control-full-256',256,synthetic,True)
pupil('control-full-512',512,synthetic,True)
add('control-native-profile',profile,synthetic,dict(SampleSize='S_256x256',PlotScale=20),False,True)
add('control-native-energy',energy,synthetic,dict(SampleSize='S_512x512'),False,True)
source=fine/'native/grid-0.005.ZMX'
pupil('grid-full-512',512,source)
pupil('grid-full-1024',1024,source)
pupil('grid-full-512-step0.001',512,fine/'native/grid-0.001.ZMX')
write(r/'native-jobs.json',jobs)
auto=root/'auto-native'
(auto/'requests').mkdir(parents=True,exist_ok=True)
jobs=[]
r=auto
add('energy-native-auto-4096',energy,source,dict(SampleSize='S_4096x4096',RadiusMaximum=0))
add('energy-native-auto-8192',energy,source,dict(SampleSize='S_8192x8192',RadiusMaximum=0))
write(r/'native-jobs.json',jobs)
