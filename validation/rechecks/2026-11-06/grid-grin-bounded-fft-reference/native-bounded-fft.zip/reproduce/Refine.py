import json,hashlib,sys
from pathlib import Path
p,coarse=map(Path,sys.argv[1:]); run=p/'refinement'; (run/'requests').mkdir(parents=True,exist_ok=True)
old=coarse.read_bytes().decode('utf-16')
assert old.count('PARM 1 0.005')==1
new=old.replace('PARM 1 0.005','PARM 1 0.0025')
source=run/'grid-0.0025.ZMX'
source.write_bytes(new.encode('utf-16'))
q=json.loads((p/'native-full/requests/grid-full-512.json').read_text(encoding='utf-8-sig'))
q.update(input=str(source),inputSha256=hashlib.sha256(source.read_bytes()).hexdigest())
name='grid-full-512-step0.0025'
f=run/'requests'/(name+'.json');f.write_text(json.dumps(q,indent=2)+'\n')
(run/'native-jobs.json').write_text(json.dumps([dict(id=name,request=str(f),output=str(run/name))],indent=2)+'\n')
