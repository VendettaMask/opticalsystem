using System;
using System.IO;
using System.Linq;
using ZOSAPI.Analysis;

internal static class NativeBinaryPsf
{
    internal static int Capture(IAR_ result, string output)
    {
        var messages = Enumerable.Range(0, result.NumberOfMessages).Select(i =>
        {
            var m = result.GetMessageAt(i);
            return Host.Object("errorCode", m.ErrorCode.ToString(), "text", m.Text);
        }).ToArray();
        Host.Write("result-diagnostics.json", Host.Object("messages", messages, "gridCount", result.NumberOfDataGrids));
        if (messages.Length != 0 || result.NumberOfDataGrids != 1)
        {
            result.GetTextFile(Path.Combine(output, "data.txt"));
            throw new CaptureFailure("NativeInvalidResult", "Native PSF did not return one warning-free grid.");
        }
        var g = result.GetDataGrid(0);
        if (g == null) throw new CaptureFailure("NativeInvalidResult", "Native PSF buffer unavailable.");
        var v = g.Values;
        if (v == null || g.Nx < 1 || g.Nx > 4096 || g.Ny < 1 || g.Ny > 4096
            || v.GetLength(0) != g.Ny || v.GetLength(1) != g.Nx)
            throw new CaptureFailure("NativeInvalidResult", "Native PSF grid dimensions unavailable or exceed bound.");
        if (g.Dx <= 0 || g.Dy <= 0 || double.IsNaN(g.Dx) || double.IsNaN(g.Dy))
            throw new CaptureFailure("NativeInvalidResult", "Native PSF physical axis unavailable.");
        var path = Path.Combine(output, "grid-f64le.bin");
        var max = 0d; var total = 0d;
        using (var file = new FileStream(path + ".partial", FileMode.CreateNew, FileAccess.Write, FileShare.None, 131072))
        {
            var row = new byte[checked(g.Nx * sizeof(double))];
            for (int y = 0; y < g.Ny; ++y)
            {
                Buffer.BlockCopy(v, y * row.Length, row, 0, row.Length);
                file.Write(row, 0, row.Length);
                for (int x = 0; x < g.Nx; ++x)
                {
                    var n = v[y, x];
                    if (double.IsInfinity(n) || double.IsNaN(n) || n < 0)
                        throw new CaptureFailure("NativeInvalidResult", "Invalid native PSF intensity.");
                    total += n; max = Math.Max(max, n);
                }
            }
        }
        if (!(total > 0) || double.IsInfinity(total))
            throw new CaptureFailure("NativeInvalidResult", "Native PSF has no finite positive flux.");
        File.Move(path + ".partial", path);
        Host.Write("psf-grid.json", Host.Object("nx", g.Nx, "ny", g.Ny, "dx", g.Dx, "dy", g.Dy,
            "minX", g.MinX, "minY", g.MinY, "description", g.Description, "xLabel", g.XLabel, "yLabel", g.YLabel,
            "valueLabel", g.ValueLabel, "peak", max, "intensitySum", total, "header", result.HeaderData.Lines,
            "layout", "float64 little-endian, row major, no re-normalization or crop"));
        return 0;
    }
}
