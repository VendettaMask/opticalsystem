using System.Text.Json;
using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Materials;
using OpticalSystemDesign.Core.Propagation;
using OpticalSystemDesign.ZemaxComparison;

var directory = args[0];
var items = JsonFiles.Read<JsonElement[]>(Path.Combine(directory, "synthetic-inputs.json"));
var result = new List<object>();
foreach (var item in items)
{
    var name = item.GetProperty("id").GetString()!;
    var optic = await new ZemaxZmxImporter().ImportFileAsync(item.GetProperty("source").GetString()!);
    var entrance = optic.SurfaceGroup.Items.Single(surface => surface.MaterialAfter is GradientIndexMaterial);
    var material = (GradientIndexMaterial)entrance.MaterialAfter;
    var grid = (GridGradientIndexProfile)material.Profile;
    var matrix = GradientIndexParaxialTransport.Between(material, 0, entrance.Thickness, 550);
    var nOut = grid.InterfaceRefractiveIndex(new(0,0,entrance.Thickness),550);
    var efl = Math.Abs(matrix.C) < 1e-13 ? (double?)null : -1 / (matrix.C * nOut);
    var native = JsonFiles.Read<JsonElement>(Path.Combine(directory,name,"data.json"))
        .GetProperty("scalars").GetProperty("EffectiveFocalLength").GetDouble();
    var nativePower = Math.Abs(native) == 1e10 ? 0 : 1 / native;
    var indices = Enumerable.Range(0,grid.Nz).Select(k => new { z = grid.Origin.Z + k*grid.Spacing.Z,
        index = grid.RefractiveIndex(new(0,0,grid.Origin.Z+k*grid.Spacing.Z),550) }).ToArray();
    result.Add(new { name, item, native, nativePower, coreEfl = efl, corePower = -matrix.C*nOut,
        matrix, grid.Origin, grid.Spacing, indices, inputSha256 = grid.SourceSha256 });
    Console.WriteLine($"{name,-27} core={efl,16:G12} native={native,16:G12} ratio={efl/native:G9}");
}
JsonFiles.Write(args[1], result);
