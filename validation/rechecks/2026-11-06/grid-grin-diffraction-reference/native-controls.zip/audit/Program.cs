using System.Text.Json;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.ZemaxComparison;
using OpticalSystemDesign.ZemaxComparison.Configuration;
using OpticalSystemDesign.ZemaxComparison.Normalization;
using OpticalSystemDesign.ZemaxComparison.Workbench;

var study = args[0]; var root = args[1]; var output = args[2];
var rows = JsonFiles.Read<JsonElement[]>(Path.Combine(study, "rows.json"));
var records = new List<object>();
foreach (int id in new[] {496,498,500,501,503,505})
{
    var row = rows[id-1];
    var key = row.GetProperty("key").GetString()!;
    var entry = AnalysisComparisonRegistry.Get(key);
    var job = JsonFiles.Read<WorkbenchJob>(row.GetProperty("job").GetString()!);
    var settings = row.GetProperty("settings").Deserialize<AnalysisConfiguration>(JsonFiles.Options)!;
    var workbench = Path.Combine(study, "analyses", $"{id:D4}", "data.json");
    var native = Path.Combine(row.GetProperty("legacyPath").GetString()!, "native", "data.json");
    string Native(string batch, string step) => Path.Combine(root, batch, $"{id}-step{step}", "data.json");
    NumericResult Reference(string path) => ResultNormalizer.Zemax(path, entry, job.Request, workbench);
    var actual = ResultNormalizer.Workbench(workbench, entry, job.Request);
    if (!File.Exists(Native("native","0.001")) || !File.Exists(Native("native","0.005"))) continue;
    var original = Reference(native); var coarse = Reference(Native("native","0.005")); var fine = Reference(Native("native","0.001"));
    Run("native-original-vs-0.001", original, fine);
    Run("native-0.005-vs-0.001", coarse, fine);
    Run("core-vs-0.001", actual, fine);
    if (File.Exists(Native("refinement","0.0005")))
    {
        var finer = Reference(Native("refinement","0.0005"));
        Run("native-0.001-vs-0.0005", fine, finer);
        Run("core-vs-0.0005", actual, finer);
        if (File.Exists(Native("refinement","0.00025")))
        {
            var finest = Reference(Native("refinement","0.00025"));
            Run("native-0.0005-vs-0.00025", finer, finest);
            Run("core-vs-0.00025", actual, finest);
        }
    }
    void Run(string scope, NumericResult first, NumericResult second)
    {
        var run = new AnalysisRun { Key = key, Directory = $"{id}-{scope}", Request = job.Request };
        run.Normalizations.AddRange(first.Transformations.Concat(second.Transformations));
        ComparisonRunner.Compare(run, entry, settings, first, second, output);
        records.Add(new { id, scope, key, run.Conclusion, run.Reason, run.Metrics, run.Normalizations,
            allMeasuredQuantitiesPass = run.Metrics.Count > 0 && run.Metrics.All(m => m.Conclusion == Conclusion.Pass),
            unreportedPathSurfaces = second.UnreportedNativeRayPathSurfaces, requestFingerprint = job.Request.Fingerprint });
        Console.WriteLine($"{id} {scope} {run.Conclusion} reported={run.Metrics.All(m => m.Conclusion == Conclusion.Pass)} {string.Join(" ", run.Metrics.Select(m => $"{m.Id}={m.MaxAbsolute:G5}/{m.Nrmse:G5}"))}");
    }
}
JsonFiles.Write(Path.Combine(output,"results.json"), new { coreSha256 = JsonFiles.Hash(File.ReadAllBytes(typeof(Optic).Assembly.Location)),
    comparisonSha256 = JsonFiles.Hash(File.ReadAllBytes(typeof(ComparisonRunner).Assembly.Location)), results = records });

