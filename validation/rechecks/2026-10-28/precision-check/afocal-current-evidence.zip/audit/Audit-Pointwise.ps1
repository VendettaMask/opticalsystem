$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$rows = @(Get-Content "$root/original-150/summary.json" -Raw | ConvertFrom-Json)
$audit = @(foreach ($row in $rows) {
    if (!$row.metrics.Count) { continue }
    $caseRoot = "$root/original-150/comparison/$($row.id)"
    $run = Get-Content "$caseRoot/comparison.json" -Raw | ConvertFrom-Json
    $gates = @($run.tolerances.PSObject.Properties)
    if ($gates.Count -ne 1) { continue }
    $gate = $gates[0].Value
    foreach ($metric in $row.metrics) {
        $stem = ($metric.id.ToLowerInvariant() -split '[\s:/\\_()]+' | Where-Object { $_ }) -join '-'
        $csvPath = "$caseRoot/comparisons/$($row.id)/$stem-values.csv"
        if (!(Test-Path -LiteralPath $csvPath)) { throw "Missing matched values: $csvPath" }
        $samples = @(Import-Csv -LiteralPath $csvPath)
        $failureCount = 0
        $worstExcess = 0.0
        foreach ($sample in $samples) {
            $nativeValue = [double]::Parse($sample.zemax, [Globalization.CultureInfo]::InvariantCulture)
            $sampleError = [double]::Parse($sample.absoluteError, [Globalization.CultureInfo]::InvariantCulture)
            $pointLimit = $gate.absolute + $gate.relative * [Math]::Abs($nativeValue)
            if ($sampleError -gt $pointLimit) {
                $failureCount++
                $worstExcess = [Math]::Max($worstExcess, $sampleError - $pointLimit)
            }
        }
        if ($samples.Count -ne $metric.count) { throw 'Matched-value count changed' }
        [ordered]@{id=$row.id; lens=$row.lens; configuration=$row.configuration; key=$row.key;
            metric=$metric.id; unit=$metric.unit; quantity=$gates[0].Name; gate=$gate; points=$samples.Count;
            pointsOutsideAbsoluteRelativeGate=$failureCount; maximumGateExcess=$worstExcess;
            originalConclusion=$metric.conclusion; requestConclusion=$row.conclusion;
            acceptedOnlyByNrmse=($metric.conclusion -eq 'Pass' -and $failureCount -gt 0 -and $samples.Count -gt 1);
            csvSha256=(Get-FileHash -LiteralPath $csvPath).Hash.ToLowerInvariant()}
    }
})
$audit | ConvertTo-Json -Depth 7 | Set-Content "$root/pointwise-audit.json" -Encoding utf8
$audit = @(Get-Content "$root/pointwise-audit.json" -Raw | ConvertFrom-Json)
$only = @($audit | Where-Object acceptedOnlyByNrmse)
[pscustomobject]@{auditedMetricSeries=$audit.Count; nrmseOnlySeries=$only.Count;
    nrmseOnlyCases=@($only.id | Sort-Object -Unique).Count;
    nrmseOnlyPassingRequests=@($only | Where-Object requestConclusion -eq Pass | Select-Object -ExpandProperty id -Unique).Count;
    scope='Single effective quantity gate only; original conclusions and tolerance policy unchanged.'} | ConvertTo-Json
$only | Group-Object key | ForEach-Object {
    [pscustomobject]@{key=$_.Name; series=$_.Count; requests=@($_.Group.id | Sort-Object -Unique).Count;
        points=($_.Group | Measure-Object pointsOutsideAbsoluteRelativeGate -Sum).Sum}
} | ConvertTo-Json
