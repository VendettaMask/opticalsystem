$ErrorActionPreference = 'Stop'
$work = $PSScriptRoot
$repository = (Resolve-Path (Join-Path $work '../../..')).Path
$output = Join-Path $repository 'validation/rechecks/2026-10-28/precision-check'
function ReadJson([string]$Path) { Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json }
function Hash([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Require($Condition, [string]$Message) { if (!$Condition) { throw $Message } }
function Counts($Rows) {
    [pscustomobject]@{total=@($Rows).Count; pass=@($Rows | Where-Object conclusion -eq Pass).Count;
        close=@($Rows | Where-Object conclusion -eq Close).Count;
        difference=@($Rows | Where-Object conclusion -eq Difference).Count;
        incomparable=@($Rows | Where-Object conclusion -eq Incomparable).Count;
        errors=@($Rows | Where-Object conclusion -eq Error).Count}
}
$sets = @(
    @{name='original-150'; prior='artifacts/validation/afocal-fft-energy-20261027/final-150-v2'; count=150},
    @{name='fixed-20'; prior='artifacts/validation/afocal-fft-energy-20261027/final-fixed-v2'; count=20}
)
$core = Hash (Join-Path $work 'runner/OpticalSystemDesign.Core.dll')
Require ((Hash (Join-Path $work 'pupil-runner/OpticalSystemDesign.Core.dll')) -ceq $core) 'Mixed pupil Core'
Require ((Hash (Join-Path $repository 'artifacts/validation/precision-check-20261028/dedup-fresh-bin/OpticalSystemDesign.Core.dll')) -ceq $core) 'Mixed test Core'
$policy = Hash (Join-Path $repository 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json')
Require ($policy -ceq '30c27e7976710867d0edc6dd4099edac54ca9e070245dea679b3afdd88fd28f5') 'Original policy changed'
Add-Type -AssemblyName System.IO.Compression
$priorArchivePath = 'validation/rechecks/2026-10-27/afocal-fft-energy/evidence-current.zip'
$priorArchiveHash = Hash (Join-Path $repository $priorArchivePath)
Require ($priorArchiveHash -ceq '235f113b4633fce7341e837da03850ac3c8cff14a48c32f4b4731e7250d7f4b1') 'Prior archive changed'
$priorArchive = [IO.Compression.ZipFile]::OpenRead((Join-Path $repository $priorArchivePath))
$payload = [Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)
$storage = [Collections.Generic.List[object]]::new()
$allCases = [Collections.Generic.List[object]]::new()
$runResults = [Collections.Generic.List[object]]::new()
$metricChanges = [Collections.Generic.List[object]]::new()
function Add-Payload([string]$Name, [string]$Path) {
    Require (!$payload.ContainsKey($Name)) ('Repeated archive member: ' + $Name)
    $payload.Add($Name, [IO.Path]::GetFullPath($Path))
}
function Store-Result([string]$SetName, [string]$CurrentFile, [string]$PriorFile, [string]$Kind) {
    $relative = [IO.Path]::GetRelativePath((Join-Path $work $SetName), $CurrentFile).Replace('\','/')
    $checksum = Hash $CurrentFile
    $reuse = $null
    if ((Test-Path -LiteralPath $PriorFile) -and (Hash $PriorFile) -ceq $checksum) {
        $member = [IO.Path]::GetRelativePath($repository, $PriorFile).Replace('\','/')
        $entry = $priorArchive.GetEntry($member)
        if ($entry) {
            $stream = $entry.Open()
            try { $archiveChecksum = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() }
            finally { $stream.Dispose() }
            Require ($archiveChecksum -ceq $checksum) 'Existing member differs from recomputed bytes'
            $reuse = [ordered]@{kind='existing-archive'; archive=$priorArchivePath; archiveSha256=$priorArchiveHash; member=$member}
        }
    }
    if (!$reuse) {
        $member = 'results/' + $SetName + '/' + $relative
        Add-Payload $member $CurrentFile
        $reuse = [ordered]@{kind='current-archive'; archive='afocal-current-evidence.zip'; member=$member}
    }
    $storage.Add([pscustomobject]@{set=$SetName; path=$relative; dataKind=$Kind;
        bytes=(Get-Item -LiteralPath $CurrentFile).Length; sha256=$checksum; storage=$reuse})
}
try {
    foreach ($set in $sets) {
        $currentRoot = Join-Path $work $set.name
        $priorRoot = Join-Path $repository $set.prior
        $items = @(ReadJson (Join-Path $currentRoot 'items.json'))
        $previousItems = @(ReadJson (Join-Path $priorRoot 'items.json'))
        $rows = @(ReadJson (Join-Path $currentRoot 'summary.json'))
        $previousRows = @(ReadJson (Join-Path $priorRoot 'summary.json'))
        $inputIdentity = ReadJson (Join-Path $currentRoot 'input-identity.json')
        $jobs = @(ReadJson (Join-Path $currentRoot 'workbench-results.json'))
        Require ($rows.Count -eq $set.count -and $items.Count -eq $set.count -and $jobs.Count -eq $set.count) 'Incomplete matrix'
        Require (@($rows.id | Sort-Object -Unique).Count -eq $set.count) 'Repeated matrix ID'
        Require (@($jobs | Where-Object timedOut).Count -eq 0) 'Timed out worker'
        Require ((Hash $inputIdentity.source) -ceq $inputIdentity.sourceSha256) 'Original request list changed'
        $oldItems = @{}; foreach ($row in $previousItems) { $oldItems[$row.id] = $row }
        $oldRows = @{}; foreach ($row in $previousRows) { $oldRows[$row.id] = $row }
        $fingerprints = @{}; foreach ($row in $inputIdentity.inputs) { $fingerprints[$row.id] = $row.requestFingerprint }
        $changedConclusions = 0
        $regressions = 0
        foreach ($row in $items) {
            Require (($row.request | ConvertTo-Json -Depth 70 -Compress) -ceq
                ($oldItems[$row.id].request | ConvertTo-Json -Depth 70 -Compress)) 'Canonical request object changed'
        }
        foreach ($row in $inputIdentity.inputs) {
            Require ((Hash $row.snapshot) -ceq $row.snapshotSha256) 'Snapshot changed during recheck'
            foreach ($file in $row.files) { Require ((Hash $file.path) -ceq $file.sha256) 'Native input changed during recheck' }
        }
        foreach ($row in $rows) {
            $priorRow = $oldRows[$row.id]
            if ($row.conclusion -cne $priorRow.conclusion) { $changedConclusions++ }
            if ($priorRow.conclusion -eq 'Pass' -and $row.conclusion -ne 'Pass') { $regressions++ }
            foreach ($metric in $row.metrics) {
                $oldMetric = @($priorRow.metrics | Where-Object id -eq $metric.id)
                if ($oldMetric.Count -eq 1) {
                    $metricChanges.Add([pscustomobject]@{set=$set.name; id=$row.id; metric=$metric.id;
                        unit=$metric.unit; maxAbsoluteMetricChange=[Math]::Abs($metric.maxAbsolute-$oldMetric[0].maxAbsolute);
                        nrmseMetricChange=[Math]::Abs($metric.nrmse-$oldMetric[0].nrmse)})
                }
            }
            $run = ReadJson (Join-Path $currentRoot ('comparison/' + $row.id + '/comparison.json'))
            $allCases.Add([pscustomobject]@{set=$set.name; id=$row.id; lens=$row.lens; configuration=$row.configuration;
                analysis=$row.key; previousConclusion=$priorRow.conclusion; conclusion=$row.conclusion;
                reason=$row.reason; requestFingerprint=$fingerprints[$row.id]; effectiveTolerances=$run.tolerances;
                metrics=$row.metrics; normalizations=$run.normalizations})
            $data = Join-Path $currentRoot ($row.id + '/workbench/data.json')
            if (Test-Path -LiteralPath $data) { Store-Result $set.name $data (Join-Path $priorRoot ($row.id + '/workbench/data.json')) 'core-data' }
        }
        foreach ($csv in Get-ChildItem -LiteralPath (Join-Path $currentRoot 'comparison') -Recurse -File -Filter '*-values.csv') {
            $relative = [IO.Path]::GetRelativePath($currentRoot, $csv.FullName)
            Store-Result $set.name $csv.FullName (Join-Path $priorRoot $relative) 'matched-values'
        }
        $identity = ReadJson (Join-Path $currentRoot 'identity.json')
        Require ($identity.coreSha256 -ceq $core) 'Mixed matrix Core'
        $priorIdentityPath = Join-Path $priorRoot 'identity.json'
        $priorIdentity = if (Test-Path -LiteralPath $priorIdentityPath) { ReadJson $priorIdentityPath } else { $null }
        $runResults.Add([pscustomobject]@{set=$set.name; counts=(Counts $rows); previousCounts=(Counts $previousRows);
            changedConclusions=$changedConclusions; previousPassRegressions=$regressions;
            requestObjectsUnchanged=$true; snapshotsAndNativeFilesUnchanged=$true;
            workers=@($jobs | Sort-Object id); priorIdentity=$priorIdentity;
            priorIdentityFileAvailable=(Test-Path -LiteralPath $priorIdentityPath)})
        Add-Payload ('inputs/' + $set.name + '.json') (Join-Path $currentRoot 'input-identity.json')
    }
} finally { $priorArchive.Dispose() }
$main = @($allCases | Where-Object set -eq 'original-150')
$byModel = @($main | Group-Object lens,configuration | ForEach-Object {
    [pscustomobject]@{lens=$_.Group[0].lens; configuration=$_.Group[0].configuration; counts=(Counts $_.Group)}
})
$byAnalysis = @($main | Group-Object analysis | ForEach-Object {
    [pscustomobject]@{analysis=$_.Name; counts=(Counts $_.Group); metricsByUnit=@($_.Group.metrics | Group-Object unit | ForEach-Object {
        [pscustomobject]@{unit=$_.Name; maximumAbsolute=($_.Group | Measure-Object maxAbsolute -Maximum).Maximum;
            maximumNrmse=($_.Group | Measure-Object nrmse -Maximum).Maximum}
    })}
})
$tests = @(foreach ($spec in @(@{file='additional-controls.trx';count=18}, @{file='formal-psf.trx';count=20})) {
    $path = Join-Path $work ('tests/' + $spec.file)
    [xml]$trx = Get-Content -LiteralPath $path -Raw
    $c = $trx.TestRun.ResultSummary.Counters
    Require ([int]$c.passed -eq $spec.count -and [int]$c.failed -eq 0 -and [int]$c.total -eq $spec.count) 'Incomplete controls'
    Add-Payload ('tests/' + $spec.file) $path
    [pscustomobject]@{file=$spec.file; passed=[int]$c.passed; failed=[int]$c.failed; started=$trx.TestRun.Times.start; finished=$trx.TestRun.Times.finish}
})
$pointwise = @(ReadJson (Join-Path $work 'pointwise-audit.json'))
$onlyNrmse = @($pointwise | Where-Object acceptedOnlyByNrmse)
$passingNrmseOnly = @($onlyNrmse | Where-Object requestConclusion -eq Pass | Select-Object -ExpandProperty id -Unique)
$sourcePaths = @('tools/diagnostics/AfocalReferenceFocus20261027/Program.cs',
    'tools/diagnostics/AfocalReferenceFocus20261027/ScopedAfocalNormalizer.cs',
    'tools/diagnostics/AfocalFftEnergy20261027/BinocularAudit.cs',
    'tools/OpticalSystemDesign.ZemaxComparison/Metrics/ComparisonMetrics.cs')
$sourceHashes = @($sourcePaths | ForEach-Object { [pscustomobject]@{path=$_; sha256=(Hash (Join-Path $repository $_))} })
foreach ($file in @('build.log','pupil-build.log','original-150-workbench.log','fixed-20-workbench.log',
    'additional-controls.log','formal-psf.log','pointwise-audit.log','pointwise-first-attempt.json',
    'pointwise-audit.json','Audit-Pointwise.ps1','Collect-Current.ps1')) {
    Add-Payload ('audit/' + $file) (Join-Path $work $file)
}
Add-Payload 'diagnostics/binocular-nodes.json' (Join-Path $work 'binocular-nodes-current/summary.json')
Add-Payload 'diagnostics/core-unification.json' (Join-Path $work 'core-unification.json')
Add-Payload 'diagnostics/grid-spacing.json' (Join-Path $work 'grid-diagnostics.json')
foreach ($job in $runResults[0].workers | Where-Object exitCode -ne 0) {
    Require ($job.id -match 'relative-illumination' -and !$job.timedOut -and $job.exitCode -eq 3) 'Unexpected unavailable worker'
    Add-Payload ('unavailable/' + $job.id + '.log') (Join-Path $work ('original-150/' + $job.id + '/workbench/process.log'))
}
$archivePath = Join-Path $output 'afocal-current-evidence.zip'
Require (!(Test-Path -LiteralPath $archivePath)) 'Fresh current-evidence archive required'
$zip = [IO.Compression.ZipFile]::Open($archivePath, [IO.Compression.ZipArchiveMode]::Create)
$members = @(try {
    foreach ($name in @($payload.Keys | Sort-Object)) {
        $path = $payload[$name]
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $path, $name, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
        [pscustomobject]@{member=$name; bytes=(Get-Item -LiteralPath $path).Length; sha256=(Hash $path)}
    }
} finally { $zip.Dispose() })
$zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    foreach ($member in $members) {
        $entry = $zip.GetEntry($member.member); $stream = $entry.Open()
        try { $checksum = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant() }
        finally { $stream.Dispose() }
        Require ($entry.Length -eq $member.bytes -and $checksum -ceq $member.sha256) 'New archive readback failed'
    }
} finally { $zip.Dispose() }
$report = [ordered]@{checkedAtUtc=[DateTime]::UtcNow.ToString('o'); sourceCommit=(& git -C $repository rev-parse HEAD).Trim();
    currentCoreSha256=$core; comparisonPolicySha256=$policy;
    scope='Validated main-branch Core pinned when this recheck began re-executed the exact original 150 requests and independent 20 fixed-angle controls against existing OpticStudio 2026 R1 captures. Original snapshots, native files and canonical requests unchanged. Concurrent unaccepted Core edits excluded. No native recapture or policy changes.';
    sourceIdentities=$sourceHashes; runs=$runResults.ToArray(); byModel=$byModel; byAnalysis=$byAnalysis;
    cases=$allCases.ToArray(); gridSpacingDiagnostics=(ReadJson (Join-Path $work 'grid-diagnostics.json'));
    binocularPupilDiagnostics=(ReadJson (Join-Path $work 'binocular-nodes-current/summary.json'));
    binaryUnification=(ReadJson (Join-Path $work 'core-unification.json'));
    supplementaryTests=$tests;
    supplementaryScope=@{opdGroups=13;opdPoints=169;angularCentroidGroups=3;angularCentroidFields=13;
        originalNativeCentroidRays=10361;curvatureOperandConfigurations=2;
        formalPsfTests=20;formalPsfTestsIncludeExpectedIncomparable=6;
        countsNotAddedToOriginal150=$true};
    pointwiseAudit=@{scope='Only aligned metric series from cases with one effective quantity gate. Additional diagnostic; original policy and conclusions unchanged.';
        auditedSeries=$pointwise.Count;metricSeriesPassingOnlyByNrmse=$onlyNrmse.Count;
        originalPassRequestsWithPointwiseFailures=$passingNrmseOnly.Count;requestIds=$passingNrmseOnly;
        byAnalysis=@($onlyNrmse | Where-Object requestConclusion -eq Pass | Group-Object key | ForEach-Object {
            [pscustomobject]@{analysis=$_.Name;requests=@($_.Group.id | Sort-Object -Unique).Count}
        }); rule='Pass permits pointwise absolute+relative success OR multi-sample NRMSE success, after coverage checks.'};
    previousMetricChanges=@($metricChanges | Sort-Object nrmseMetricChange -Descending | Select-Object -First 10);
    resultStorage=$storage.ToArray();
    storageSummary=@{recomputedDataFiles=@($storage | Where-Object dataKind -eq 'core-data').Count;
        recomputedDataReusingIdenticalExistingBytes=@($storage | Where-Object {$_.dataKind -eq 'core-data' -and $_.storage.kind -eq 'existing-archive'}).Count;
        newlyStoredDataFiles=@($storage | Where-Object {$_.dataKind -eq 'core-data' -and $_.storage.kind -eq 'current-archive'}).Count;
        matchedValuesStoredOrReferenced=@($storage | Where-Object dataKind -eq 'matched-values').Count;
        semantics='Every worker executed anew; identical result bytes are referenced in the previous sealed archive only after hash and member verification. Native reference arrays are not copied.'};
    archive=@{file='afocal-current-evidence.zip';bytes=(Get-Item -LiteralPath $archivePath).Length;sha256=(Hash $archivePath);
        members=$members;readbackVerified=$true};
    limitations=@('The existing 150-request matrix covers 18 analysis families across four files/five configurations, not every catalog entry, arbitrary setting, polarization or all 95 files.',
        'Three built-in centroid Difference results, six automatic-grid Incomparables, five missing illumination references and two inapplicable mixed-NSC first-order results remain.',
        'Formal PSF tests assert the six known Incomparable outcomes; passing tests do not relabel these optical comparisons.',
        'The initial pointwise summary attempt and one inline parse retry failed; both are excluded. Final pointwise analysis reads the unchanged completed comparison CSV files.',
        'The first node audit used a concurrently built Core and is excluded. Final node diagnostics use exactly the main matrix/test Core; unaccepted concurrent Core edits are not certified.',
        'No DeepSeek tools were available in this session; no external code transmission occurred.')}
$report | ConvertTo-Json -Depth 35 | Set-Content -LiteralPath (Join-Path $output 'afocal-comparison.json') -Encoding utf8
[pscustomobject]@{original=$runResults[0].counts;fixed=$runResults[1].counts;
    changedConclusions=$runResults[0].changedConclusions;passRegressions=$runResults[0].previousPassRegressions;
    nrmseOnlyPassingRequests=$passingNrmseOnly.Count;storage=$report.storageSummary;archiveBytes=$report.archive.bytes} | ConvertTo-Json -Depth 5
