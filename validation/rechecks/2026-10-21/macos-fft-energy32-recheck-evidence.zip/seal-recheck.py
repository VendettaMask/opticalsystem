import collections
import datetime
import hashlib
import json
import platform
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from zoneinfo import ZoneInfo

repo = Path.cwd()
evidence = repo / 'artifacts/validation/local-fft-energy32-recheck-20261021'
baseline = 'ecf35b1f5ca1365e426ad0b3ac2e8695fb836965'
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

native_filter = '|'.join('FullyQualifiedName~' + name for name in [
    'ObjectivesEnergy32RepairTests', 'ObjectivesResidualPrecisionTests', 'PetzvalNativeRepairTests'])
core_filter = '|'.join('FullyQualifiedName~' + name for name in [
    'StandardIntersectionPrecisionTests', 'GeometryIntersectionResultTests',
    'StopAimingIntersectionTests', 'FftCumulativeEnergyTests', 'FftEnergyGridIntegrityTests',
    'PreparedPupilProvenanceTests', 'FiniteFftAimingEnergyTests', 'FftAimingStopBranchTests'])
failure_filter = '|'.join('FullyQualifiedName~FftSamplingReferenceRepairTests.' + name for name in [
    'VertexPlotMatchesImageLocalReferenceUsedByEnergyOperand',
    'PolychromaticEnergyPlotAndOperandShareTheSameSampling'])
runs = [
    ('release-native', 'Release', 'ZemaxComparison', native_filter, 0),
    ('release-core', 'Release', 'Core', core_filter, 0),
    ('debug-native', 'Debug', 'ZemaxComparison', native_filter, 0),
    ('release-sampling', 'Release', 'Core', 'FullyQualifiedName~FftSamplingReferenceRepairTests', 1),
    ('debug-sampling-failures', 'Debug', 'Core', failure_filter, 1),
    ('baseline-sampling-failures', 'Release', 'Pre-sync Core diagnostic', failure_filter, 1),
]
tests = []
for name, configuration, scope, selected_filter, exit_code in runs:
    root = ET.parse(evidence / (name + '.trx')).getroot()
    counters = {k: int(v) for k, v in root.find('t:ResultSummary/t:Counters', ns).attrib.items()}
    classes = collections.Counter()
    for test in root.findall('t:TestDefinitions/t:UnitTest', ns):
        classes[test.find('t:TestMethod', ns).get('className').split('.')[-1]] += 1
    results = root.findall('t:Results/t:UnitTestResult', ns)
    assert len(results) == counters['total'] == counters['executed']
    assert counters['notExecuted'] == counters['aborted'] == counters['error'] == 0
    failures = []
    for result in results:
        if result.get('outcome') != 'Passed':
            failures.append({'test': result.get('testName'), 'outcome': result.get('outcome'),
                             'message': result.findtext('t:Output/t:ErrorInfo/t:Message', namespaces=ns)})
    assert counters['failed'] == len(failures)
    tests.append({'id': name, 'configuration': configuration, 'scope': scope,
                  'sourceRevision': baseline if name.startswith('baseline-') else revision,
                  'filter': selected_filter, 'exitCode': exit_code, 'counters': counters,
                  'classes': dict(sorted(classes.items())), 'failures': failures,
                  'times': root.find('t:Times', ns).attrib,
                  'trx': name + '.trx', 'log': 'test-' + name + '.log'})

builds = []
for configuration in ['Debug', 'Release']:
    filename = 'build-' + configuration.lower() + '.log'
    log = (evidence / filename).read_text()
    projects = sorted(set(re.findall(r'^  (\S+) -> ', log, re.MULTILINE)))
    assert len(projects) == 19 and '0 个警告' in log and '0 个错误' in log and '已成功生成' in log
    assemblies = []
    app_output = repo / 'src/OpticalSystemDesign.App/bin' / configuration / 'net10.0'
    for filename_dll in ['OpticalSystemDesign.App.dll', 'OpticalSystemDesign.Core.dll',
                         'OpticalSystemDesign.Application.dll', 'OpticalSystemDesign.InitialStructure.Engine.dll',
                         'OpticalSystemDesign.CoatingDesign.Engine.dll']:
        path = app_output / filename_dll
        assemblies.append({'path': str(path.relative_to(repo)), 'bytes': path.stat().st_size, 'sha256': sha(path)})
    core_hash = sha(repo / 'src/OpticalSystemDesign.Core/bin' / configuration / 'net10.0/OpticalSystemDesign.Core.dll')
    for folder in ['src/OpticalSystemDesign.App', 'tests/OpticalSystemDesign.Tests', 'tests/OpticalSystemDesign.ZemaxComparison.Tests']:
        assert sha(repo / folder / 'bin' / configuration / 'net10.0/OpticalSystemDesign.Core.dll') == core_hash
    builds.append({'configuration': configuration, 'command': f'dotnet build OpticalSystemDesign.slnx -c {configuration} --no-restore /m:1 /nr:false',
                   'exitCode': 0, 'projects': projects, 'projectCount': len(projects), 'warnings': 0, 'errors': 0,
                   'log': filename, 'defaultOutputAssemblies': assemblies, 'coreOutputMatchesAppAndBothTestHosts': True})

# Compare every exported baseline source byte with its committed Git blob.
raw = subprocess.check_output(['git', 'ls-tree', '-rz', baseline, '--',
    'src/OpticalSystemDesign.Core', 'Directory.Build.props', 'Directory.Build.targets', 'ProductVersion.props', 'global.json'])
baseline_files = []
for entry in raw.split(b'\0'):
    if not entry:
        continue
    metadata, path_bytes = entry.split(b'\t', 1)
    _, kind, oid = metadata.decode().split()
    assert kind == 'blob'
    path = path_bytes.decode()
    data = (evidence / 'baseline-src' / path).read_bytes()
    actual_oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert actual_oid == oid
    baseline_files.append({'path': path, 'gitBlob': oid, 'sha256': hashlib.sha256(data).hexdigest()})
source = repo / 'tests/OpticalSystemDesign.Tests/FftSamplingReferenceRepairTests.cs'
copied_source = evidence / 'baseline-tests/FftSamplingReferenceRepairTests.cs'
assert sha(source) == sha(copied_source)
assert subprocess.check_output(['git', 'show', baseline + ':' + str(source.relative_to(repo))]) == source.read_bytes()
write(evidence / 'baseline-source-integrity.json', {'revision': baseline, 'matched': len(baseline_files),
    'files': baseline_files, 'testSourceSha256': sha(source), 'testSourceIdenticalToCurrentAndBaseline': True})

latest_failures = next(t for t in tests if t['id'] == 'release-sampling')['failures']
old_failures = next(t for t in tests if t['id'] == 'baseline-sampling-failures')['failures']
debug_failures = next(t for t in tests if t['id'] == 'debug-sampling-failures')['failures']
assert {t['test'] for t in latest_failures} == {t['test'] for t in old_failures} == {t['test'] for t in debug_failures}

policy = repo / 'tools/OpticalSystemDesign.ZemaxComparison/comparison-settings.json'
assert sha(policy) == '30c27e7976710867d0edc6dd4099edac54ca9e070245dea679b3afdd88fd28f5'
receipt = {
    'schemaVersion': 1, 'date': '2026-10-21', 'recordedAt': datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
    'sourceRevision': revision, 'status': 'builds-and-original32-guards-pass-two-pre-existing-sampling-contract-failures',
    'environment': {'os': platform.platform(), 'architecture': platform.machine(), 'sdk': '10.0.300', 'runtime': '10.0.8',
                    'details': 'dotnet-info.txt'},
    'restore': {'command': 'dotnet restore OpticalSystemDesign.slnx --locked-mode --verbosity minimal', 'exitCode': 0,
                'log': 'restore-retry.log', 'initialSandboxAttempt': {'status': 'canceled-incomplete', 'log': 'restore.log',
                'reason': 'No progress in restricted execution. Confirmed exact restore PID before termination; retry outside sandbox succeeded.'}},
    'builds': builds, 'tests': tests,
    'conclusions': {
        'original32FormalCasesPassedPerConfiguration': 10, 'original32RepairAndIntegrityGuardsPassedPerConfiguration': 12,
        'nativeGuardGroupPassedPerConfiguration': 20, 'releaseCoreGuardGroupPassed': 117,
        'additionalSamplingClass': {'passed': 11, 'failed': 2, 'skipped': 0},
        'twoFailuresReproducedWithDebugAndPreSyncCore': True,
        'baselineDiagnostic': 'Unchanged complete sampling test source and matching test packages; only two failing methods executed against independently exported pre-sync Core. It is a failure-origin control, not product-build verification.',
        'original32CasesRemainPassed': True, 'allRelatedTestsPassed': False,
        'scopeNote': 'Counts overlap across configurations and the two-method diagnostic; do not add them into a unique test baseline.'},
    'policySha256': sha(policy), 'sourceOrTestsChanged': False, 'tolerancesChanged': False, 'nativeReferencesChanged': False,
    'fullTestSuiteRun': False, 'full638MatrixRun': False, 'newZemaxCaptureRun': False, 'nativeCertificationClaimed': False,
    'productLaunched': False, 'installerRepublished': False, 'committedOrPushed': False,
    'evidenceRoot': str(evidence.relative_to(repo)),
    'relatedRepairLedger': 'docs/validation/OBJECTIVES_ENERGY32_REPAIR_2026-10-21.json'
}
write(evidence / 'run-receipt.json', receipt)
payloads = sorted([p for p in evidence.iterdir() if p.is_file() and p.suffix in ['.log', '.trx', '.txt', '.json', '.py']])
payloads += [copied_source, evidence / 'baseline-tests/BaselineSampling.Tests.csproj']
manifest = [{'path': str(p.relative_to(evidence)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in payloads]
write(evidence / 'evidence-manifest.json', {'files': manifest})
payloads.append(evidence / 'evidence-manifest.json')
archive = repo / 'validation/rechecks/2026-10-21/macos-fft-energy32-recheck-evidence.zip'
archive.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for path in payloads:
        z.write(path, path.relative_to(evidence))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:
        content = z.read(item['path'])
        assert len(content) == item['bytes'] and hashlib.sha256(content).hexdigest() == item['sha256']
receipt['archive'] = {'path': str(archive.relative_to(repo)), 'bytes': archive.stat().st_size, 'sha256': sha(archive),
                      'files': len(payloads), 'readBackVerified': True, 'includesOriginalFailedRuns': True}
ledger = repo / 'docs/validation/LOCAL_FFT_ENERGY32_RECHECK_2026-10-21.json'
write(ledger, receipt)
print(json.dumps({'ledger': str(ledger.relative_to(repo)), 'archive': receipt['archive'],
                  'baselineSourceFilesMatched': len(baseline_files),
                  'tests': [{'id': t['id'], 'passed': t['counters']['passed'], 'failed': t['counters']['failed']} for t in tests]}, indent=2))
