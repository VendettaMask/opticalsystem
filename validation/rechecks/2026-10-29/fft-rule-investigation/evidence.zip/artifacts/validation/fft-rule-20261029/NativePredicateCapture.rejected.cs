// Independent geometric control; never supplies product rays or acceptance masks.
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ZOSAPI;
using ZOSAPI.Tools.RayTrace;

internal static class NativePredicateCapture
{
    internal static string Run(IOpticalSystem source, IZOSAPI_Application app)
    {
        int facet = Host.Int("diagnosticFacetIndex");
        if (facet != 10 && facet != 11) throw new InvalidOperationException("Only the declared seam pair is supported");
        source.NCE.SetActiveSurface(6);
        var original = source.NCE.GetObjectAt(1);
        string originalName = original.Comment;
        if (originalName != "PORRO_PRISM-LH.POB" && originalName != "PORRO_PRISM-RH.POB") throw new InvalidOperationException("Unexpected polygon identity");
        string directory = Path.GetFullPath(Path.Combine(app.ObjectsDir, "Polygon Objects"));
        string name = "codex_afocal_" + Guid.NewGuid().ToString("N").Substring(0, 12) + ".POB";
        string path = Path.GetFullPath(Path.Combine(directory, name));
        if (Path.GetDirectoryName(path) != directory) throw new InvalidOperationException("Owned file escaped directory");
        var vertices = new List<string>();
        var triangles = new List<string[]>();
        foreach (string line in File.ReadAllLines(Path.Combine(directory, originalName)))
        {
            string[] t = line.Split('!')[0].Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            if (t.Length == 0) continue;
            if (t[0] == "V") vertices.Add(line);
            if (t[0] == "T") triangles.Add(new[] { t[1], t[2], t[3] });
            if (t[0] == "R") { triangles.Add(new[] { t[1], t[2], t[3] }); triangles.Add(new[] { t[1], t[3], t[4] }); }
        }
        var bytes = System.Text.Encoding.ASCII.GetBytes(string.Join("\r\n", vertices.ToArray()) + "\r\nT " + string.Join(" ", triangles[facet]) + " -1 0\r\n");
        using (var file = new FileStream(path, FileMode.CreateNew, FileAccess.Write)) file.Write(bytes, 0, bytes.Length);
        try
        {
            File.WriteAllBytes(Path.Combine(Host.Output, "single-facet.POB"), bytes);
            var system = app.CreateNewSystem(SystemType.NonSequential);
            system.SystemData.Units.LensUnits = source.SystemData.Units.LensUnits;
            system.SystemData.Wavelengths.GetWavelength(1).Wavelength = source.SystemData.Wavelengths.GetWavelength(2).Wavelength;
            system.SystemData.NonSequentialData.GlueDistanceInLensUnits = 1e-12;
            if (system.NCE.CopyObjectsFrom(source.NCE, 1, 1, 1) != 1) throw new InvalidOperationException("Cannot copy polygon pose");
            var obj = system.NCE.GetObjectAt(1);
            obj.Comment = name;
            ((ZOSAPI.Editors.NCE.IObjectPolygon)obj.ObjectData).IsVolume = false;
            obj.Material = "";
            system.NCE.ReloadObject(1);
            Host.Write("predicate-control.json", Host.Object("facet", facet, "originalName", originalName,
                "actualName", obj.Comment, "originalObject", Host.Properties(original), "object", Host.Properties(obj),
                "glueDistance", system.SystemData.NonSequentialData.GlueDistanceInLensUnits,
                "status", system.GetCurrentStatus(), "originalFullSystemRequest", false, "savedInput", false));
            if (obj.Comment != name) throw new InvalidOperationException("Native filename truncated");
            var inputs = ((IEnumerable)Host.Request["geometricInputs"]).Cast<Dictionary<string, object>>().ToArray();
            if (inputs.Length < 3 || inputs.Length > 128) throw new InvalidOperationException("Bounded geometric probes required");
            var tool = system.Tools.OpenBatchRayTrace();
            try
            {
                var data = tool.CreateNSC(inputs.Length, 16, 0);
                foreach (var p in inputs)
                    if (!data.AddRay(1, 1, NSCTraceOptions.None, N(p,"x"),N(p,"y"),N(p,"z"),N(p,"l"),N(p,"m"),N(p,"n"),0,0,0,0,0,0,0))
                        throw new InvalidOperationException("Geometric ray rejected");
                tool.RunAndWaitForCompletion();
                if (!data.StartReadingResults()) throw new InvalidOperationException("No geometric results");
                int number, error, wave, count;
                var rays = new List<object>();
                bool physicalHit = false;
                bool errors = false;
                while (data.ReadNextResult(out number,out error,out wave,out count))
                {
                    if (error != 0) errors = true;
                    var segments = new List<object>();
                    int level,parent,hit,inside;
                    double x,y,z,l,m,n,exr,exi,eyr,eyi,ezr,ezi,intensity,length;
                    while (data.ReadNextSegment(out level,out parent,out hit,out inside,out x,out y,out z,out l,out m,out n,
                        out exr,out exi,out eyr,out eyi,out ezr,out ezi,out intensity,out length))
                    {
                        if (level > 0 && hit == 1 && length > 0) physicalHit = true;
                        segments.Add(Host.Object("level",level,"hitObject",hit,"x",x,"y",y,"z",z,"l",l,"m",m,"n",n,"pathLength",length));
                    }
                    rays.Add(Host.Object("number",number,"error",error,"segmentCount",count,"segments",segments));
                }
                Host.Write("predicate-rays.json", Host.Object("inputs",inputs,"rays",rays));
                if (rays.Count != inputs.Length) throw new InvalidOperationException("Incomplete geometric results");
                if (!physicalHit) throw new InvalidOperationException("No physical single-facet hit; control is invalid");
                if (errors) throw new InvalidOperationException("Native single-facet control returned ray errors");
            }
            finally { tool.Close(); }
            return path;
        }
        catch { NativePolygonControl.RemoveOwned(path); throw; }
    }
    private static double N(Dictionary<string, object> p,string key) { return Convert.ToDouble(p[key]); }
}
