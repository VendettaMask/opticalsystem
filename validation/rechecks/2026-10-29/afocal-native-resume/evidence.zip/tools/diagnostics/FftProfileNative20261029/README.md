# Background afocal native investigation (2026-10-29)

This independent C# diagnostic resumes the frozen binocular FFT cross-section
investigation. It is not a product dependency or an optical acceptance override.
Use only a licensed Windows OpticStudio 2026 R1 installation. All live workers use
the existing `ProcessIsolation` hidden-process/job-object implementation, with a
120-second limit per capture and at most 16 captures per manifest. Existing
interactive applications are neither attached nor terminated. Screenshots are
explicitly forbidden by this runner.

Prepare exact frozen inputs with the existing offline-only
[`Capture-Remaining.py`](../AfocalPsfContract20261028/Capture-Remaining.py).
Select the desired jobs into a new `jobs.json`; their request files and source
hashes must accompany it. This preparation script has no product runtime role.
The runner compiles the repository Framework host against the installed API
assemblies, never copying proprietary DLLs:

```powershell
dotnet run --project tools/diagnostics/FftProfileNative20261029 -c Release -- REPOSITORY PREPARED_DIRECTORY INSTALLED_API_ROOT
```

Each job requires an unused destination and unchanged input SHA-256. Execution
receipts are saved incrementally. Source ZMX/POB files and existing references are
never overwritten. A valid native process exit is a capture success, not an
optical pass. The preparation-time `existing-evidence.json` retains its original
`nativeExecuted=false`; actual executed subsets are exclusively in `execution.json`.

`nsc-facet-paths` is a deliberately restricted native adapter for surface 6 of the
frozen binocular prescription. It obtains launches at surface 5, shifts their
local Z by that standard surface's thickness, and records actual NSC batch
segments. The two surfaces share orientation in this specific frozen input.
Typed API surface enums are used in every UI language. The records expose object
IDs and directions, **not internal triangle IDs**. Reflection normals can be
inferred independently; a nearest normal match must not be labelled an API facet
ID. The optional diagnostic glue control changes only the disposable in-memory
system, records both values, and never substitutes for the original request.

Two offline modes use the original frozen archive and the current shared Core:

```powershell
dotnet run --project tools/diagnostics/FftProfileNative20261029 -c Release -- --compare REPOSITORY CAPTURE_DIRECTORY NEW_OUTPUT_DIRECTORY
dotnet run --project tools/diagnostics/FftProfileNative20261029 -c Release -- --assess REPOSITORY ARTIFACT_VALIDATION_ROOT OUTPUT_JSON
```

`--compare` keeps the original five request fingerprints and tolerance ledgers.
The four outside-[-1,1] native pupil probes per configuration are explicitly
unavailable through Core's normalized-pupil API; they are never clamped or counted
as matching. Its exit code reports successful diagnostic execution; `violations`
in the summary determines pointwise success. `--assess` verifies the 20 completed
captures, reference selectors, frozen FFT channels and final pointwise results.
Its report deliberately retains `allProfilePointsPassed=false`.

The investigation found a real native/Core seam-plane difference, but the tested
normalized-edge/file-order hypothesis improved configuration 2 while regressing
configuration 1 and did not close the FFT residual. That product change was
reverted. The current deliverable changes only diagnostic tooling and status
documentation. See the [native report](../../../docs/AFOCAL_NATIVE_RESUME_2026-10-29.md).
