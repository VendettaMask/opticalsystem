using OpticalSystemDesign.Core.Backend;
using OpticalSystemDesign.Core.Capabilities;
using OpticalSystemDesign.Core.Materials;
using OpticalSystemDesign.Core.Rays;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Raytrace;

internal readonly record struct LocalImageRay(Vector3D Position, Vector3D Direction, double Intensity);

public sealed partial class SequentialRayTracer
{
    // Evaluate a small geometric pencil without adding a large frame origin to
    // every intercept and subtracting it again at the next surface. Propagation,
    // apertures, materials and interactions still use the formal surface kernel.
    internal LocalImageRay?[] TraceImageLocalPencil(RealRayBundle bundle)
    {
        if (bundle.Rays.Count is < 1 or > 8) throw new ArgumentOutOfRangeException(nameof(bundle));
        OpticCapabilityPreflight.EnsureSupported(_optic, OpticCapabilityOperation.RayTrace);
        var surfaces = _optic.SurfaceGroup.Items.Select(surface => surface.Clone()).ToArray();
        if (surfaces.Length < 2 || surfaces.Any(surface => surface.MaterialBefore is GradientIndexMaterial
            || surface.MaterialAfter is GradientIndexMaterial))
            throw new NotSupportedException("Local image pencils require homogeneous sequential media.");
        SequentialTraceMeasurement.Record(bundle.Rays.Count);
        var result = new LocalImageRay?[bundle.Rays.Count];
        for (var index = 0; index < bundle.Rays.Count; index++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var ray = RayState.FromRealRay(bundle.Rays[index].Normalize());
            var origin = Vector3D.Zero;
            var material = ResolveMaterial("Air");
            double path = 0, opticalPath = 0;
            for (var surfaceIndex = 0; surfaceIndex < surfaces.Length; surfaceIndex++)
            {
                var surface = surfaces[surfaceIndex];
                var frame = surface.CoordinateSystem;
                ray = ray with { Origin = (origin - frame.Origin) + ray.Origin };
                origin = frame.Origin;
                var shifted = surface.Clone();
                shifted.CoordinateSystem = frame with { Origin = Vector3D.Zero };
                var traced = TraceSequentialSurface(shifted, surfaceIndex, ray, material, path, opticalPath,
                    allowVirtualIntersection: AllowsReferenceBacktrack(surfaces, surfaceIndex));
                if (traced.StopTracing || traced.Sample.Vignetted || traced.Sample.Intensity <= 0) break;
                ray = traced.Ray;
                material = traced.OutgoingMaterial;
                path = traced.CumulativePathLength;
                opticalPath = traced.CumulativeOpticalPathLength;
                if (surfaceIndex == surfaces.Length - 1)
                    result[index] = new(frame.ToLocalDirection(ray.Origin), frame.ToLocalDirection(ray.Direction), ray.Intensity);
            }
        }
        return result;
    }
}
