using System.Collections.Concurrent;
using OpticalSystemDesign.Core.Services;

namespace OpticalSystemDesign.Core.Raytrace;

public enum PupilSampling
{
    UniformGrid,
    Hexapolar,
    Random,
    Sobol,
    LineX,
    LineY,
    Ring
}

public sealed record PupilSample(double X, double Y, double Weight);

public static class ApertureSampler
{
    public const int MaximumPupilSampleCount = 1_000_000;
    public const int MaximumHexapolarRings = 576;

    /// <summary>Area-stratified disk samples with a stable explicit seed, independent of global random state.</summary>
    public static IReadOnlyList<PupilSample> GenerateSeededUniformDisk(int count, ulong seed)
    {
        if (count is < 1 or > MaximumPupilSampleCount) throw new ArgumentOutOfRangeException(nameof(count));
        var samples = new PupilSample[count];
        var state = seed;
        for (var index = 0; index < count; index++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var radius = Math.Sqrt((index + Unit()) / count);
            var angle = 2 * Math.PI * Unit();
            samples[index] = new(radius * Math.Cos(angle), radius * Math.Sin(angle), 1.0 / count);
        }
        return Array.AsReadOnly(samples);

        double Unit()
        {
            state = unchecked(state + 0x9e3779b97f4a7c15UL);
            var value = state;
            value = unchecked((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9UL);
            value = unchecked((value ^ (value >> 27)) * 0x94d049bb133111ebUL);
            value ^= value >> 31;
            return (value >> 11) * (1.0 / (1UL << 53));
        }
    }

    private const int MaximumCachedSamplingPlans = 128;
    private const int MaximumCacheableSampleCount = 4_096;
    private static readonly ConcurrentDictionary<GaussianSamplingKey, IReadOnlyList<PupilSample>>
        GaussianCache = new();
    private static readonly ConcurrentDictionary<int, IReadOnlyList<PupilSample>> HexapolarRingCache = new();
    private static readonly ConcurrentDictionary<int, IReadOnlyList<PupilSample>> RectangularArrayCache = new();
    private static readonly ConcurrentDictionary<SamplingKey, IReadOnlyList<PupilSample>> SamplingCache = new();

    /// <summary>Equal-area cell centers in a square grid, restricted to the circular pupil.</summary>
    public static IReadOnlyList<PupilSample> GenerateRectangularArray(int axisSamples)
    {
        if (axisSamples is < 1 or > 1024)
            throw new ArgumentOutOfRangeException(nameof(axisSamples));
        if (axisSamples > 64) return BuildRectangularArray(axisSamples);
        TrimSamplingCachesIfNeeded();
        return RectangularArrayCache.GetOrAdd(axisSamples, BuildRectangularArray);
    }

    private static IReadOnlyList<PupilSample> BuildRectangularArray(int axisSamples)
    {
        var samples = new List<PupilSample>();
        for (var row = 0; row < axisSamples; row++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var y = (2 * row + 1d) / axisSamples - 1;
            for (var column = 0; column < axisSamples; column++)
            {
                var x = (2 * column + 1d) / axisSamples - 1;
                if (x * x + y * y <= 1) samples.Add(new PupilSample(x, y, 1));
            }
        }
        return Array.AsReadOnly(samples.ToArray());
    }

    public static IReadOnlyList<PupilSample> GenerateGaussianQuadrature(
        int radialSamples,
        int azimuthalSamples = 6,
        double obscuration = 0)
    {
        radialSamples = Math.Clamp(radialSamples, 1, 32);
        azimuthalSamples = Math.Clamp(azimuthalSamples, 1, 72);
        obscuration = Math.Clamp(obscuration, 0, 0.999999);

        TrimSamplingCachesIfNeeded();
        return GaussianCache.GetOrAdd(
            new GaussianSamplingKey(radialSamples, azimuthalSamples, obscuration),
            static key => BuildGaussianQuadrature(
                key.RadialSamples,
                key.AzimuthalSamples,
                key.Obscuration));
    }

    private static IReadOnlyList<PupilSample> BuildGaussianQuadrature(
        int radialSamples,
        int azimuthalSamples,
        double obscuration)
    {

        var lower = obscuration * obscuration;
        var span = 1 - lower;
        var radial = new (double Radius, double Weight)[radialSamples];
        var rootsToFind = (radialSamples + 1) / 2;
        for (var rootIndex = 0; rootIndex < rootsToFind; rootIndex++)
        {
            var root = Math.Cos(Math.PI * (rootIndex + 0.75) / (radialSamples + 0.5));
            double derivative = 0;
            for (var iteration = 0; iteration < 32; iteration++)
            {
                var previous = 1.0;
                var current = root;
                for (var order = 2; order <= radialSamples; order++)
                {
                    var next = (((2 * order) - 1) * root * current - ((order - 1) * previous)) / order;
                    previous = current;
                    current = next;
                }

                derivative = radialSamples * ((root * current) - previous) / ((root * root) - 1);
                var nextRoot = root - (current / derivative);
                if (Math.Abs(nextRoot - root) <= 1e-15)
                {
                    root = nextRoot;
                    break;
                }

                root = nextRoot;
            }

            var p0 = 1.0;
            var p1 = root;
            for (var order = 2; order <= radialSamples; order++)
            {
                var next = (((2 * order) - 1) * root * p1 - ((order - 1) * p0)) / order;
                p0 = p1;
                p1 = next;
            }

            derivative = radialSamples * ((root * p1) - p0) / ((root * root) - 1);
            var legendreWeight = 2 / ((1 - (root * root)) * derivative * derivative);
            SetRadialSample(rootIndex, -root, legendreWeight);
            SetRadialSample(radialSamples - rootIndex - 1, root, legendreWeight);
        }

        var samples = new List<PupilSample>(radialSamples * azimuthalSamples);
        foreach (var radialSample in radial)
        {
            for (var azimuth = 0; azimuth < azimuthalSamples; azimuth++)
            {
                var angle = 2 * Math.PI * azimuth / azimuthalSamples;
                samples.Add(new PupilSample(
                    radialSample.Radius * Math.Cos(angle),
                    radialSample.Radius * Math.Sin(angle),
                    radialSample.Weight / azimuthalSamples));
            }
        }

        return Array.AsReadOnly(samples.ToArray());

        void SetRadialSample(int index, double node, double legendreWeight)
        {
            var normalizedRadiusSquared = (node + 1) / 2;
            radial[index] = (
                Math.Sqrt(lower + (span * normalizedRadiusSquared)),
                span * legendreWeight / 2);
        }
    }

    public static IReadOnlyList<PupilSample> GenerateHexapolarRings(int numRings)
    {
        var sampleCount = CountHexapolarRingSamples(numRings);

        if (sampleCount > MaximumCacheableSampleCount)
        {
            return BuildHexapolarRings(numRings);
        }

        TrimSamplingCachesIfNeeded();
        return HexapolarRingCache.GetOrAdd(numRings, static rings => BuildHexapolarRings(rings));
    }

    public static int CountHexapolarRingSamples(int numRings)
    {
        if (numRings is < 0 or > MaximumHexapolarRings)
        {
            throw new ArgumentOutOfRangeException(
                nameof(numRings),
                $"Hexapolar ring count must be between 0 and {MaximumHexapolarRings}.");
        }

        var sampleCount = checked(1L + (3L * numRings * (numRings + 1L)));
        if (sampleCount > MaximumPupilSampleCount)
        {
            throw new ArgumentOutOfRangeException(
                nameof(numRings),
                $"Hexapolar sampling cannot exceed {MaximumPupilSampleCount:N0} pupil samples.");
        }

        return checked((int)sampleCount);
    }

    private static IReadOnlyList<PupilSample> BuildHexapolarRings(int numRings)
    {
        var samples = new List<PupilSample> { new(0, 0, 1) };
        for (var ring = 1; ring <= numRings; ring++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var radius = ring / (double)numRings;
            var points = ring * 6;
            for (var index = 0; index < points; index++)
            {
                ComputationCancellation.ThrowIfCancellationRequested();
                var angle = 2 * Math.PI * index / points;
                samples.Add(new PupilSample(radius * Math.Cos(angle), radius * Math.Sin(angle), 1));
            }
        }

        return Array.AsReadOnly(samples.ToArray());
    }

    public static IReadOnlyList<PupilSample> Generate(int sampleCount, PupilSampling sampling, int seed = 1234)
    {
        if (sampleCount is < 1 or > MaximumPupilSampleCount)
        {
            throw new ArgumentOutOfRangeException(
                nameof(sampleCount),
                $"Pupil sample count must be between 1 and {MaximumPupilSampleCount:N0}.");
        }

        if (!Enum.IsDefined(sampling))
        {
            throw new ArgumentOutOfRangeException(nameof(sampling));
        }

        if (sampleCount > MaximumCacheableSampleCount)
        {
            return Build(sampleCount, sampling, seed);
        }

        TrimSamplingCachesIfNeeded();
        return SamplingCache.GetOrAdd(
            new SamplingKey(sampleCount, sampling, seed),
            static key => Build(key.SampleCount, key.Sampling, key.Seed));
    }

    private static IReadOnlyList<PupilSample> Build(
        int sampleCount,
        PupilSampling sampling,
        int seed)
    {
        var samples = sampling switch
        {
            PupilSampling.Hexapolar => Hexapolar(sampleCount),
            PupilSampling.Random => Random(sampleCount, seed),
            PupilSampling.Sobol => SobolLike(sampleCount),
            PupilSampling.LineX => LineX(sampleCount),
            PupilSampling.LineY => LineY(sampleCount),
            PupilSampling.Ring => Ring(sampleCount),
            PupilSampling.UniformGrid => UniformGrid(sampleCount),
            _ => throw new ArgumentOutOfRangeException(nameof(sampling))
        };
        return samples is PupilSample[] array
            ? Array.AsReadOnly(array)
            : samples;
    }

    private static void TrimSamplingCachesIfNeeded()
    {
        if (GaussianCache.Count + HexapolarRingCache.Count + RectangularArrayCache.Count + SamplingCache.Count
            <= MaximumCachedSamplingPlans)
        {
            return;
        }

        GaussianCache.Clear();
        HexapolarRingCache.Clear();
        RectangularArrayCache.Clear();
        SamplingCache.Clear();
    }

    private static IReadOnlyList<PupilSample> UniformGrid(int sampleCount)
    {
        var side = (int)Math.Ceiling(Math.Sqrt(sampleCount));
        var samples = new List<PupilSample>();
        for (var iy = 0; iy < side; iy++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            for (var ix = 0; ix < side; ix++)
            {
                var x = side == 1 ? 0 : -1 + (2.0 * ix / (side - 1));
                var y = side == 1 ? 0 : -1 + (2.0 * iy / (side - 1));
                if ((x * x) + (y * y) <= 1.0)
                {
                    samples.Add(new PupilSample(x, y, 1));
                }
            }
        }

        return samples.Take(sampleCount).ToArray();
    }

    private static IReadOnlyList<PupilSample> Hexapolar(int sampleCount)
    {
        var rings = Math.Max(1, (int)Math.Ceiling(Math.Sqrt(sampleCount / 6.0)));
        return GenerateHexapolarRings(rings).Take(sampleCount).ToArray();
    }

    private static IReadOnlyList<PupilSample> Random(int sampleCount, int seed)
    {
        var random = new Random(seed);
        var samples = new PupilSample[sampleCount];
        for (var index = 0; index < samples.Length; index++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var radius = Math.Sqrt(random.NextDouble());
            var angle = random.NextDouble() * 2 * Math.PI;
            samples[index] = new PupilSample(radius * Math.Cos(angle), radius * Math.Sin(angle), 1);
        }

        return samples;
    }

    private static IReadOnlyList<PupilSample> SobolLike(int sampleCount)
    {
        var samples = new PupilSample[sampleCount];
        for (var index = 0; index < samples.Length; index++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var u = VanDerCorput(index + 1, 2);
            var v = VanDerCorput(index + 1, 3);
            var radius = Math.Sqrt(u);
            var angle = 2 * Math.PI * v;
            samples[index] = new PupilSample(radius * Math.Cos(angle), radius * Math.Sin(angle), 1);
        }

        return samples;
    }

    private static IReadOnlyList<PupilSample> LineX(int sampleCount)
    {
        if (sampleCount == 1)
        {
            return new[] { new PupilSample(0, 0, 1) };
        }

        var samples = new PupilSample[sampleCount];
        for (var index = 0; index < samples.Length; index++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            samples[index] = new PupilSample(-1 + (2.0 * index / (sampleCount - 1)), 0, 1);
        }

        return samples;
    }

    private static IReadOnlyList<PupilSample> LineY(int sampleCount)
    {
        if (sampleCount == 1)
        {
            return new[] { new PupilSample(0, 0, 1) };
        }

        var samples = new PupilSample[sampleCount];
        for (var index = 0; index < samples.Length; index++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            samples[index] = new PupilSample(0, -1 + (2.0 * index / (sampleCount - 1)), 1);
        }

        return samples;
    }

    private static IReadOnlyList<PupilSample> Ring(int sampleCount)
    {
        var samples = new PupilSample[sampleCount];
        for (var index = 0; index < samples.Length; index++)
        {
            ComputationCancellation.ThrowIfCancellationRequested();
            var angle = 2 * Math.PI * index / sampleCount;
            samples[index] = new PupilSample(Math.Cos(angle), Math.Sin(angle), 1);
        }

        return samples;
    }

    private static double VanDerCorput(int n, int basis)
    {
        var denominator = 1.0;
        var result = 0.0;
        while (n > 0)
        {
            denominator *= basis;
            result += (n % basis) / denominator;
            n /= basis;
        }

        return result;
    }

    private readonly record struct GaussianSamplingKey(
        int RadialSamples,
        int AzimuthalSamples,
        double Obscuration);

    private readonly record struct SamplingKey(
        int SampleCount,
        PupilSampling Sampling,
        int Seed);
}
