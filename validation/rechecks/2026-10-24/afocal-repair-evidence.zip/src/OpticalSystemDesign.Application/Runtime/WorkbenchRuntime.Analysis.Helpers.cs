using System.Collections.ObjectModel;
using System.Globalization;
using OpticalSystemDesign.Application.Formatting;
using OpticalSystemDesign.Core;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.Apodization;
using OpticalSystemDesign.Core.Apertures;
using OpticalSystemDesign.Core.Coatings;
using OpticalSystemDesign.Core.Domain;
using OpticalSystemDesign.Core.FileIO;
using OpticalSystemDesign.Core.Geometries;
using OpticalSystemDesign.Core.Interactions;
using OpticalSystemDesign.Core.Multiconfig;
using OpticalSystemDesign.Core.Optimization;
using OpticalSystemDesign.Core.Phase;
using OpticalSystemDesign.Core.Serialization;
using OpticalSystemDesign.Core.Services;
using OpticalSystemDesign.Core.Tolerancing;
using ContractMeritFunctionPreset = OpticalSystemDesign.Application.Contracts.MeritFunctionPreset;

namespace OpticalSystemDesign.Application.Runtime;

public partial class WorkbenchRuntime
{
    private static string FormatAnalysisData(AnalysisData data)
    {
        var lines = new List<string> { $"分析：{DisplayAnalysisName(data.Name)}" };
        lines.AddRange(data.Values.Where(item => item.Value is not IReadOnlyList<AnalysisSeries>)
            .Select(item => $"{DisplayAnalysisKey(item.Key)}：{FormatAnalysisValue(item.Value)}"));
        if (data.Table is not null)
        {
            lines.Add(string.Empty);
            lines.Add(string.Join('\t', data.Table.Columns));
            lines.AddRange(data.Table.Rows.Select(row => string.Join('\t', row)));
        }

        return string.Join(Environment.NewLine, lines);
    }

    private static AnalysisParameterDescriptor IntParameter(
        string key,
        string displayName,
        string defaultValue,
        double minimum,
        double maximum)
    {
        return new AnalysisParameterDescriptor(
            key,
            displayName,
            AnalysisParameterKind.Integer,
            defaultValue,
            minimum,
            maximum,
            1);
    }

    private static AnalysisParameterDescriptor DoubleParameter(
        string key,
        string displayName,
        string defaultValue,
        double minimum,
        double maximum,
        double increment)
    {
        return new AnalysisParameterDescriptor(
            key,
            displayName,
            AnalysisParameterKind.Double,
            defaultValue,
            minimum,
            maximum,
            increment);
    }

    private static AnalysisParameterDescriptor ChoiceParameter(
        string key,
        string displayName,
        string defaultValue,
        IReadOnlyList<string> choices)
    {
        return new AnalysisParameterDescriptor(
            key,
            displayName,
            AnalysisParameterKind.Choice,
            defaultValue,
            Choices: choices);
    }

    private static AnalysisParameterDescriptor FileParameter(
        string key,
        string displayName,
        string defaultValue = "")
    {
        return new AnalysisParameterDescriptor(
            key,
            displayName,
            AnalysisParameterKind.File,
            defaultValue);
    }

    private static AnalysisParameterDescriptor BoolParameter(
        string key,
        string displayName,
        string defaultValue)
    {
        return new AnalysisParameterDescriptor(
            key,
            displayName,
            AnalysisParameterKind.Boolean,
            defaultValue);
    }

    private AnalysisParameterDescriptor[] FieldCurvatureAndDistortionParameters(bool angularField)
    {
        var parameters = new List<AnalysisParameterDescriptor>
        {
            DoubleParameter("MaximumCurvature", "最大场曲（0=自动）", "0", 0, 1_000_000, 0.1),
            DoubleParameter("MaximumDistortion", "最大畸变（0=自动）", "0", 0, 1_000_000, 0.1),
            ChoiceParameter(
                "WavelengthNumber",
                "波长（0=所有）",
                "0",
                new[] { "0" }.Concat(Enumerable.Range(1, Math.Max(1, CurrentOptic.Wavelengths.Count))
                    .Select(index => index.ToString(CultureInfo.InvariantCulture))).ToArray()),
            ChoiceParameter("DisplayMode", "畸变显示为", "百分比", new[] { "百分比", "绝对值" }),
            ChoiceParameter("ScanDirection", "扫描方向", "+y", new[] { "+y", "+x", "-y", "-x" }),
            ChoiceParameter(
                "ReferenceFieldNumber",
                "参考视场",
                "1",
                Enumerable.Range(1, Math.Max(1, CurrentOptic.Fields.Count))
                    .Select(index => index.ToString(CultureInfo.InvariantCulture)).ToArray()),
            DoubleParameter("ParabasalDelta", "傍轴光瞳间隔", CurrentOptic.ImageSpaceAfocal ? "0.0001" : "0.001", 1e-8, 0.1, 0.00001),
            BoolParameter("ChiefRayParabasal", "以主光线为傍轴参考", CurrentOptic.ImageSpaceAfocal ? "false" : "true"),
            BoolParameter("IgnoreVignettingFactors", "忽略渐晕因数", "true")
        };
        if (angularField)
        {
            parameters.Insert(3, ChoiceParameter(
                "DistortionType",
                "畸变模型",
                "F-Tan(Theta)",
                DistortionModelChoices()));
        }

        return parameters.ToArray();
    }

    private static string[] DistortionModelChoices()
    {
        return new[]
        {
            "F-Tan(Theta)",
            "F-Theta",
            "Calibrated F-Theta",
            "Calibrated F-Tan(Theta)",
            "SMIA-TV"
        };
    }

    private AnalysisParameterDescriptor[] GridDistortionParameters()
    {
        return new[]
        {
            ChoiceParameter("DisplayMode", "显示", "截面", new[] { "截面", "向量" }),
            IntParameter("NumPoints", "网格尺寸", "12", 2, 128),
            DoubleParameter("Scale", "缩放", "1", 0, 1_000_000, 0.1),
            BoolParameter("SymmetricMagnification", "对称放大", "false"),
            ChoiceParameter(
                "WavelengthNumber",
                "波长",
                "1",
                Enumerable.Range(1, Math.Max(1, CurrentOptic.Wavelengths.Count)).Select(index => index.ToString(CultureInfo.InvariantCulture)).ToArray()),
            ChoiceParameter(
                "ReferenceFieldNumber",
                "参考视场",
                "1",
                Enumerable.Range(1, Math.Max(1, CurrentOptic.Fields.Count)).Select(index => index.ToString(CultureInfo.InvariantCulture)).ToArray()),
            DoubleParameter("HeightWidthAspect", "H/W 纵横比", "1", 0.000001, 1_000_000, 0.1),
            DoubleParameter("FieldWidth", "视场宽度（0=自动）", "0", 0, 1_000_000, 0.1)
        };
    }

    private bool UsesAngularDistortionModel()
    {
        if (CurrentOptic.FieldDefinition == FieldDefinitionKind.Angle)
        {
            return true;
        }

        if (CurrentOptic.FieldDefinition != FieldDefinitionKind.RealImageHeight)
        {
            return false;
        }

        return ObjectConjugate.IsInfinite(CurrentOptic.SurfaceGroup.Items.FirstOrDefault());
    }

    private static int TryReadInt(IReadOnlyDictionary<string, string> settings, string key, int fallback)
    {
        return settings.TryGetValue(key, out var value)
            && int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var number)
            ? number
            : fallback;
    }

    private static double TryReadDouble(IReadOnlyDictionary<string, string> settings, string key, double fallback)
    {
        return settings.TryGetValue(key, out var value)
            && double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var number)
            ? number
            : fallback;
    }

    private static bool TryReadBool(IReadOnlyDictionary<string, string> settings, string key, bool fallback)
    {
        return settings.TryGetValue(key, out var value) && bool.TryParse(value, out var flag)
            ? flag
            : fallback;
    }

    private static string FormatAnalysisValue(object value)
    {
        return value switch
        {
            double number => NumericDisplayFormatter.Format(number),
            float number => NumericDisplayFormatter.Format(number),
            string text when text == "linear-height" => "线性高度",
            _ => value.ToString() ?? string.Empty
        };
    }

}
