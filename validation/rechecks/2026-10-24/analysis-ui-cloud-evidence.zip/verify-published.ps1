[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$SourceCommit,
    [Parameter(Mandatory)][long]$WindowsRun,
    [Parameter(Mandatory)][string]$ReleaseJson,
    [string]$WindowsSnapshot,
    [Parameter(Mandatory)][string]$Output
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$release = Get-Content -LiteralPath $ReleaseJson -Raw | ConvertFrom-Json
$expectedNames = @('OpticalSystemDesign-1.0.4-win-x64-UnsignedTest-Setup.exe', 'OpticalSystemDesign-1.0.4-osx-arm64-AdHocTest.dmg')
if ($release.tag_name -cne 'v1.0.4-test.20261019' -or $release.draft -or -not $release.prerelease -or
    (@($release.assets.name | Sort-Object) -join ',') -cne (@($expectedNames | Sort-Object) -join ',')) {
    throw 'Unexpected release state or attachments.'
}
$markerPattern = '(?s)<!-- optical-system-design-ota-v1\s+([A-Za-z0-9+/=]+)\.([A-Za-z0-9+/=]+)\s+-->'
$markers = [regex]::Matches($release.body, $markerPattern)
if ($markers.Count -ne 1) { throw 'Expected one Windows OTA envelope.' }
$bytes = [Convert]::FromBase64String($markers[0].Groups[1].Value)
$signature = [Convert]::FromBase64String($markers[0].Groups[2].Value)
$rsa = [Security.Cryptography.RSA]::Create()
try {
    $rsa.ImportFromPem((Get-Content src/OpticalSystemDesign.App/Assets/Updates/ota-public-key.pem -Raw))
    if (-not $rsa.VerifyData($bytes, $signature, [Security.Cryptography.HashAlgorithmName]::SHA256,
        [Security.Cryptography.RSASignaturePadding]::Pss)) { throw 'OTA signature verification failed.' }
} finally { $rsa.Dispose() }
$ota = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
$windows = @($release.assets | Where-Object name -CEQ $expectedNames[0])[0]
if ($ota.Format -ne 2 -or $ota.Repository -cne 'VendettaMask/opticalsystem' -or
    $ota.ProductAppId -cne 'OpticalSystemDesign-8D387EA8-F349-447F-B5D3-B58E27F46D4A' -or
    $ota.Version -cne '1.0.4' -or $ota.Runtime -cne 'win-x64' -or $ota.Tag -cne $release.tag_name -or
    $ota.Name -cne $windows.name -or $ota.Size -ne $windows.size -or
    "sha256:$($ota.Sha256)" -cne $windows.digest -or $ota.SourceCommit -cne $SourceCommit -or
    $ota.BuildSequence -ne $WindowsRun) { throw 'Signed identity differs from the cloud build or public asset.' }
$records = @($release.assets | ForEach-Object {
    $asset = $_
    $line = @($release.body -split "`n" | Where-Object { $_.StartsWith("- $($asset.name) |", [StringComparison]::Ordinal) })
    if ($line.Count -ne 1 -or -not $line[0].EndsWith("源码: $SourceCommit", [StringComparison]::Ordinal) -or
        -not $line[0].Contains("SHA-256: $($asset.digest -replace '^sha256:', '')")) { throw 'Asset provenance is missing or inconsistent.' }
    $identity = [regex]::Match($line[0], '发布 ID:\s*([^|]+)\s*\|').Groups[1].Value.Trim()
    if ($asset.name -eq $windows.name -and $identity -cne $ota.ReleaseId) { throw 'Signed release ID differs from the public source record.' }
    [ordered]@{ id = $asset.id; name = $asset.name; size = $asset.size; digest = $asset.digest; releaseId = $identity; sourceCommit = $SourceCommit; url = $asset.browser_download_url }
})
$preserved = $null
if ($WindowsSnapshot) {
    $old = Get-Content -LiteralPath $WindowsSnapshot -Raw | ConvertFrom-Json
    $oldMarker = [regex]::Matches($old.body, $markerPattern)
    $oldWindows = @($old.assets | Where-Object name -CEQ $windows.name)[0]
    $preserved = $oldMarker.Count -eq 1 -and $oldMarker[0].Value -ceq $markers[0].Value -and
        $oldWindows.id -eq $windows.id -and $oldWindows.size -eq $windows.size -and $oldWindows.digest -ceq $windows.digest
    if (-not $preserved) { throw 'Mac publication changed the untouched Windows asset or OTA envelope.' }
}
$summary = [ordered]@{ sourceCommit = $SourceCommit; releaseTag = $release.tag_name; releaseUrl = $release.html_url;
    prerelease = $release.prerelease; windowsBuildSequence = $ota.BuildSequence; pinnedRsaPssSignatureVerified = $true;
    signedIdentityMatchesPublicAsset = $true; windowsPreservedByMacPublication = $preserved; assets = $records;
    fullInstallerDownloadedLocally = $false; localInstallationModified = $false }
$summary | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $Output -Encoding utf8
$summary | ConvertTo-Json -Depth 8
