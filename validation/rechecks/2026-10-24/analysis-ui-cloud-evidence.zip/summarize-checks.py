import collections
import json
import pathlib
import sys
import xml.etree.ElementTree as ET

base = pathlib.Path(__file__).parent
ns = {"t": "http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}
platforms = {}
for platform in ["windows", "mac"]:
    folder = base / platform
    groups = []
    cases = {}
    for path in sorted(folder.rglob("*.trx")):
        root = ET.parse(path).getroot()
        counts = collections.Counter()
        for result in root.findall("t:Results/t:UnitTestResult", ns):
            outcome = result.attrib["outcome"]
            case = result.attrib["testId"]
            counts[outcome] += 1
            if case in cases and cases[case]["outcome"] != outcome:
                raise RuntimeError(f"Conflicting final outcomes: {platform} {case}")
            cases[case] = {"outcome": outcome, "name": result.attrib["testName"]}
        groups.append({"trx": path.name, "outcomes": dict(counts)})
    distinct = collections.Counter(case["outcome"] for case in cases.values())
    summaries = {}
    for name in ["summary.json", "native-product.json", "dmg-summary.json", "dmg-native-product.json", "frozen.json", "documentation.json"]:
        paths = list(folder.rglob(name))
        if len(paths) == 1:
            summaries[name] = json.loads(paths[0].read_text(encoding="utf-8-sig"))
    platforms[platform] = {
        "groups": groups,
        "distinct": dict(distinct),
        "executions": sum(sum(item["outcomes"].values()) for item in groups),
        "nonPassingNames": [case["name"] for case in cases.values() if case["outcome"] != "Passed"],
        "summaries": summaries,
    }
output = base / "checks-summary.json"
output.write_text(json.dumps(platforms, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({name: {"groups": value["groups"], "distinct": value["distinct"], "executions": value["executions"],
    "nonPassingNames": value["nonPassingNames"], "summaryFiles": list(value["summaries"])} for name, value in platforms.items()}, ensure_ascii=False))
