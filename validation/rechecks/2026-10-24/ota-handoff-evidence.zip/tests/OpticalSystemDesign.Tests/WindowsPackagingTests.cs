using System.Diagnostics;
using System.Xml.Linq;

namespace OpticalSystemDesign.Tests;

public sealed class WindowsPackagingTests
{
    [Fact]
    public void PackagingVersionResolverUsesAuthorityAndAllowsExplicitTestOverrides()
    {
        if (!OperatingSystem.IsWindows()) return;
        var current = RunScriptFile("get-product-version.ps1");
        Assert.Equal(0, current.ExitCode);
        Assert.Equal(global::OpticalSystemDesign.App.Services.ProductVersionInfo.Current, current.Output.Trim());
        var specific = RunScriptFile("get-product-version.ps1", "-AppVersion", "2.3.4");
        Assert.Equal(0, specific.ExitCode);
        Assert.Equal("2.3.4", specific.Output.Trim());
        foreach (var bad in new[] { "01.0.4", "1.0.4.0", "1.0.4-rc.1", "1.0.65535", "-1.0.4" })
        {
            Assert.NotEqual(0, RunScriptFile("get-product-version.ps1", "-AppVersion", bad).ExitCode);
        }
    }

    [Fact]
    public void PackagingUsesPortableUntrimmedOutputWithoutOverwritingTrackedLocks()
    {
        var root = RepositoryRoot();
        var script = File.ReadAllText(Path.Combine(root, "scripts", "publish-windows.ps1"));
        Assert.Contains("--self-contained true", script);
        Assert.Contains("-p:PublishSingleFile=false", script);
        Assert.Contains("-p:PublishTrimmed=false", script);
        Assert.Contains("NuGetLockFilePath=obj/packages.$Runtime.lock.json", script);
        Assert.Contains("[System.IO.Directory]::Move($stagingDirectory, $packageDirectory)", script);
        Assert.DoesNotContain("Remove-Item", script);
        Assert.Contains("LensLibrary\\StockCatalogs", script);
        var project = XDocument.Load(Path.Combine(root, "src", "OpticalSystemDesign.App", "OpticalSystemDesign.App.csproj"));
        Assert.Contains(project.Descendants("OutputType"), property =>
            property.Value == "WinExe" && (string?)property.Attribute("Condition") == "'$(WindowsPackage)' == 'true'");
        Assert.Contains("%BUILD_EXIT_CODE%", File.ReadAllText(Path.Combine(root, "Build-Exe.cmd")));
    }

    [Fact]
    public void WindowsPackagingDryRunAcceptsSpacesAndDoesNotCreateOutput()
    {
        if (!OperatingSystem.IsWindows())
        {
            return;
        }
        var destination = Path.Combine(Path.GetTempPath(), $"optical package dry run {Guid.NewGuid():N}");
        var result = RunScript("-WhatIf", "-OutputRoot", destination);
        Assert.True(result.ExitCode == 0, result.Output);
        Assert.Contains(destination, result.Output);
        Assert.False(Directory.Exists(destination));
    }

    [Fact]
    public void WindowsPackagingRejectsUnsupportedRuntimeBeforePublishing()
    {
        if (!OperatingSystem.IsWindows())
        {
            return;
        }
        var result = RunScript("-Runtime", "linux-x64");
        Assert.NotEqual(0, result.ExitCode);
        Assert.Contains("linux-x64", result.Output);
    }

    [Fact]
    public void InstallerUsesChineseWizardAndLoggedUninstallWithoutDeletingUserData()
    {
        var root = RepositoryRoot();
        var installer = File.ReadAllText(Path.Combine(root, "packaging", "windows", "OpticalSystemDesign.iss"));
        Assert.Contains("WizardStyle=modern", installer);
        Assert.Contains("DisableWelcomePage=no", installer);
        Assert.Contains("DisableDirPage=no", installer);
        Assert.Contains("UsePreviousGroup=yes", installer);
        Assert.Contains("ChineseSimplified.isl", installer);
        Assert.Contains("PrivilegesRequired=lowest", installer);
        Assert.Contains("CloseApplications=no", installer);
        Assert.Contains("AppMutex={#ApplicationMutex}", installer);
        Assert.Contains("SetupMutex={#ApplicationMutex}-Setup", installer);
        Assert.Contains("Compression=none", installer);
        Assert.Contains("Uninstallable=yes", installer);
        Assert.Contains("recursesubdirs createallsubdirs", installer);
        Assert.Contains("postinstall skipifsilent unchecked", installer);
        Assert.DoesNotContain("[UninstallDelete]", installer);
        Assert.DoesNotContain("[InstallDelete]", installer);
        Assert.DoesNotContain("filesandordirs", installer);
        Assert.Contains("build-installer.ps1", File.ReadAllText(Path.Combine(root, "Build-Exe.cmd")));
        Assert.True(File.Exists(Path.Combine(root, "Build-Installer.cmd")));
        var builder = File.ReadAllText(Path.Combine(root, "scripts", "build-installer.ps1"));
        Assert.Contains("-PassThru -CompactName", builder);
        Assert.Contains("Get-FileHash -LiteralPath $setupPath -Algorithm SHA256", builder);
        Assert.Contains("[IO.Directory]::Move($stagingDirectory, $buildDirectory)", builder);
    }

    [Fact]
    public void InstallerLocksRegisteredLocationAndShortcutsAndClassifiesRepairBeforeCopying()
    {
        var root = RepositoryRoot();
        var installer = File.ReadAllText(Path.Combine(root, "packaging", "windows", "OpticalSystemDesign.iss"));
        var policy = File.ReadAllText(Path.Combine(root, "packaging", "windows", "InstallationPolicy.iss"));
        Assert.Contains("#include \"InstallationPolicy.iss\"", installer);
        Assert.Contains("RegKeyExists(HKCU, Key)", policy);
        Assert.Contains("RegKeyExists(HKLM32, Key)", policy);
        Assert.Contains("RegKeyExists(HKLM64, Key)", policy);
        Assert.Contains("WizardForm.DirEdit.Text := RegisteredDirectory", policy);
        Assert.Contains("WizardForm.GroupEdit.Text := RegisteredGroup", policy);
        Assert.Contains("WizardForm.NoIconsCheck.Checked := RegisteredNoIcons", policy);
        Assert.Contains("WizardSelectTasks('!desktopicon')", policy);
        Assert.Contains("PageID = wpSelectDir", policy);
        Assert.Contains("PageID = wpSelectProgramGroup", policy);
        Assert.Contains("PageID = wpSelectTasks", policy);
        Assert.Contains("StrToVersion(RegisteredVersion", policy);
        Assert.Contains("StrToVersion(StateVersion", policy);
        Assert.Contains("InstallationMode := 'Repair'", policy);
        Assert.Contains("InstallationMode := 'Upgrade'", policy);
        Assert.Contains("Downgrade refused", policy);
        Assert.Contains("function UpdateReadyMemo", policy);
        Assert.DoesNotContain("RegDelete", policy);
        Assert.DoesNotContain("DelTree", policy);
        Assert.DoesNotContain("Exec(", policy);
        var prepare = installer[installer.IndexOf("function PrepareToInstall", StringComparison.Ordinal)..];
        Assert.True(prepare.IndexOf("EnforceInstallationIdentity;", StringComparison.Ordinal) < prepare.IndexOf("AcquireInstallationFileGate;", StringComparison.Ordinal));
        Assert.True(prepare.IndexOf("RecoverInterruptedTransaction;", StringComparison.Ordinal) < prepare.IndexOf("ValidateInstallationPolicy;", StringComparison.Ordinal));
        Assert.True(prepare.IndexOf("ValidateInstallationPolicy;", StringComparison.Ordinal) < prepare.IndexOf("CaptureDurableJournal;", StringComparison.Ordinal));
        Assert.Contains("InstallationPolicyScriptSha256", File.ReadAllText(Path.Combine(root, "scripts", "build-installer.ps1")));
    }

    [Fact]
    public void NativeInstallationPolicyRegressionUsesOnlyFreshIsolatedIdentityAndCrossDirectoryAttempts()
    {
        var script = File.ReadAllText(Path.Combine(RepositoryRoot(), "scripts", "verify-windows-installation-policy.ps1"));
        Assert.Contains("OpticalSystemDesign-UpgradeValidation-", script);
        Assert.Contains("[Guid]::NewGuid()", script);
        Assert.Contains("Assert-OwnedPath", script);
        Assert.Contains("-WindowStyle Hidden", script);
        Assert.Contains("alternate-directory-not-created", script);
        Assert.Contains("flat-downgrade-blocked", script);
        Assert.Contains("same-version-repacked-update", script);
        Assert.Contains("noicons-maintenance-preserved", script);
        Assert.Contains("user-data-byte-preserved", script);
    }

    [Fact]
    public void InstallerRejectsOverlongProductIdentityBeforeCreatingAnyOutput()
    {
        if (!OperatingSystem.IsWindows()) return;
        var destination = Path.Combine(Path.GetTempPath(), $"optical invalid identity {Guid.NewGuid():N}");
        var result = RunScriptFile("build-installer.ps1", "-WhatIf", "-OutputRoot", destination,
            "-ProductAppId", new string('A', 57));
        Assert.NotEqual(0, result.ExitCode);
        Assert.False(Directory.Exists(destination));
    }

    [Fact]
    public void InstallerUsesVerifiedSideBySidePayloadAndRestoresActivationOnFailure()
    {
        var installer = File.ReadAllText(Path.Combine(RepositoryRoot(), "packaging", "windows", "OpticalSystemDesign.iss"));
        Assert.Contains("#define PayloadDir \"versions\\\" + ReleaseId", installer);
        Assert.Contains("AfterInstall: VerifyPayload", installer);
        Assert.Contains("GetSHA256OfFile", installer);
        Assert.Contains("procedure DeinitializeSetup", installer);
        Assert.Contains("PreviousState", installer);
        Assert.Contains("PreviousDisplayVersion", installer);
        Assert.Contains("CompareVersions", installer);
        Assert.Contains("CheckNoReparsePath", installer);
        Assert.Contains("function GetCustomSetupExitCode", installer);
        Assert.Contains("if Failed then Result := 70", installer);
        Assert.Contains("Committed := not Failed", installer);
        Assert.Contains("procedure UpdateOwnedAssociation", installer);
        Assert.DoesNotContain("taskkill", installer, StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain("DelTree", installer);
    }

    [Fact]
    public void SigningRequiresExplicitPublisherAndTimestampAndSignsUninstall()
    {
        var script = File.ReadAllText(Path.Combine(RepositoryRoot(), "scripts", "windows-signing.ps1"));
        Assert.Contains("/sha1", script);
        Assert.Contains("SHA256", script);
        Assert.Contains("/tr", script);
        Assert.Contains("/pa", script);
        Assert.Contains("TimeStamperCertificate", script);
        Assert.DoesNotContain("/f MyCert", script);
        var installer = File.ReadAllText(Path.Combine(RepositoryRoot(), "packaging", "windows", "OpticalSystemDesign.iss"));
        Assert.Contains("SignedUninstaller=yes", installer);
        Assert.Contains("SignTool=OpticalPublisher", installer);
    }

    [Fact]
    public void CompilerBootstrapChecksPinnedHashAndUsesProjectLocalPortableMode()
    {
        var script = File.ReadAllText(Path.Combine(RepositoryRoot(), "scripts", "get-inno-setup.ps1"));
        Assert.Contains("https://github.com/jrsoftware/issrc/releases/download/is-6_7_3/", script);
        Assert.Contains("9c73c3bae7ed48d44112a0f48e66742c00090bdb5bef71d9d3c056c66e97b732", script);
        Assert.Contains("Get-FileHash -LiteralPath $download -Algorithm SHA256", script);
        Assert.Contains("/PORTABLE=1", script);
        Assert.Contains("/CURRENTUSER", script);
        Assert.Contains("-WindowStyle Hidden", script);
        Assert.DoesNotContain("Remove-Item", script);
        Assert.True(script.IndexOf("Get-FileHash", StringComparison.Ordinal)
            < script.IndexOf("Start-Process", StringComparison.Ordinal));
    }

    [Fact]
    public void InstallerDryRunDoesNotDownloadToolsOrPublishAndSupportsSpaces()
    {
        if (!OperatingSystem.IsWindows()) { return; }
        var destination = Path.Combine(Path.GetTempPath(), $"optical installer dry run {Guid.NewGuid():N}");
        var result = RunScriptFile("build-installer.ps1", "-WhatIf", "-OutputRoot", destination,
            "-InnoSetupCompiler", "deliberately missing compiler.exe");
        Assert.True(result.ExitCode == 0, result.Output);
        Assert.Contains(destination, result.Output);
        Assert.False(Directory.Exists(destination));
    }

    [Fact]
    public void MissingExplicitInstallerCompilerFailsBeforeCreatingRelease()
    {
        if (!OperatingSystem.IsWindows()) { return; }
        var destination = Path.Combine(Path.GetTempPath(), $"optical installer missing compiler {Guid.NewGuid():N}");
        var result = RunScriptFile("build-installer.ps1", "-OutputRoot", destination,
            "-InnoSetupCompiler", "deliberately missing compiler.exe");
        Assert.NotEqual(0, result.ExitCode);
        Assert.Contains("Inno Setup compiler not found", result.Output);
        Assert.False(Directory.Exists(destination));
    }

    private static (int ExitCode, string Output) RunScript(params string[] arguments) =>
        RunScriptFile("publish-windows.ps1", arguments);

    private static (int ExitCode, string Output) RunScriptFile(string fileName, params string[] arguments)
    {
        var start = new ProcessStartInfo("powershell.exe")
        {
            WorkingDirectory = Path.GetTempPath(),
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        foreach (var argument in new[] { "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
                     Path.Combine(RepositoryRoot(), "scripts", fileName) }.Concat(arguments))
        {
            start.ArgumentList.Add(argument);
        }
        using var process = Process.Start(start)!;
        var output = process.StandardOutput.ReadToEndAsync();
        var error = process.StandardError.ReadToEndAsync();
        if (!process.WaitForExit(30_000))
        {
            process.Kill(entireProcessTree: true);
            throw new TimeoutException("Packaging script validation did not finish in 30 seconds.");
        }
        return (process.ExitCode, output.GetAwaiter().GetResult() + error.GetAwaiter().GetResult());
    }

    private static string RepositoryRoot()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null && !File.Exists(Path.Combine(directory.FullName, "OpticalSystemDesign.slnx")))
        {
            directory = directory.Parent;
        }
        return directory?.FullName ?? throw new DirectoryNotFoundException("Repository root not found.");
    }
}
