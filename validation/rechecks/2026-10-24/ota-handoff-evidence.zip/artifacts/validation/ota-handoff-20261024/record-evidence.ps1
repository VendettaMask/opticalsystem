$ErrorActionPreference = 'Stop'
$root = (Get-Location).Path
$raw = Join-Path $root 'artifacts/validation/ota-handoff-20261024'
$reportPath = Join-Path $root 'docs/validation/OTA_HANDOFF_REPAIR_2026-10-24.json'
$archivePath = Join-Path $root 'validation/rechecks/2026-10-24/ota-handoff-evidence.zip'
$packagePath = Join-Path $root 'artifacts/ota-handoff-package-final/installer-win-x64-77be407c'
function Hash([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Relative([string]$Path) { [IO.Path]::GetRelativePath($root, $Path).Replace('\','/') }
$sources = @('src/OpticalSystemDesign.App/Services/Updates/WindowsOtaHandoff.cs',
    'src/OpticalSystemDesign.App/Services/Updates/OtaHelperRuntime.cs',
    'src/OpticalSystemDesign.App/Panels/SoftwareUpdatePanel.cs',
    'src/OpticalSystemDesign.App/Services/UiLocalization.cs',
    'packaging/windows/InstallationPolicy.iss', 'packaging/windows/OpticalSystemDesign.iss',
    'scripts/verify-windows-installation-policy.ps1',
    'tests/OpticalSystemDesign.Tests/OtaHelperRuntimeTests.cs',
    'tests/OpticalSystemDesign.Tests/OtaClientTests.cs',
    'tests/OpticalSystemDesign.Tests/OtaUpdatePanelTests.cs',
    'tests/OpticalSystemDesign.Tests/WindowsPackagingTests.cs')
$sourceRecords = @($sources | ForEach-Object { @{ Path = $_; Sha256 = Hash (Join-Path $root $_) } })
[xml]$trx = Get-Content -Raw -LiteralPath (Join-Path $raw 'tests/ota-final-v3.trx')
$counters = $trx.TestRun.ResultSummary.Counters
if ([int]$counters.passed -ne 149 -or [int]$counters.total -ne 149 -or [int]$counters.failed -ne 0) { throw 'Unexpected focused test result.' }
$native = Get-Content -Raw -LiteralPath (Join-Path $raw 'native-policy-final/summary.json') | ConvertFrom-Json
if ($native.Passed -ne 49 -or $native.Failed -ne 0) { throw 'Unexpected native installer result.' }
$package = Get-Content -Raw -LiteralPath (Join-Path $packagePath 'release.json') | ConvertFrom-Json
$installer = Join-Path $packagePath 'OpticalSystemDesign-1.0.4-win-x64-UnsignedTest-Setup.exe'
Copy-Item -LiteralPath (Join-Path $packagePath 'release.json') -Destination (Join-Path $raw 'final-package.json')
Copy-Item -LiteralPath ($installer + '.sha256') -Destination (Join-Path $raw 'final-package.sha256')
git diff --binary HEAD -- docs packaging scripts src tests | Set-Content -LiteralPath (Join-Path $raw 'tracked-changes.diff') -Encoding utf8
if ($LASTEXITCODE -ne 0) { throw 'Cannot capture tracked changes.' }

# Keep all validation stages and exact sources. Large release/test binaries stay
# in the local package; their hashes identify them without bloating the archive.
$files = @(Get-ChildItem -LiteralPath $raw -Recurse -File | Where-Object { $_.Extension -notin @('.exe','.dll','.pdb','.tmp','.zip') })
$files += @($sources | ForEach-Object { Get-Item -LiteralPath (Join-Path $root $_) })
$files = @($files | Sort-Object FullName -Unique)
if (Test-Path -LiteralPath $archivePath) { throw 'Refusing to overwrite frozen evidence.' }
New-Item -ItemType Directory -Path (Split-Path -Parent $archivePath) -Force | Out-Null
$manifest = @($files | ForEach-Object { @{ Path = Relative $_.FullName; Bytes = $_.Length; Sha256 = Hash $_.FullName } })
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [IO.Compression.ZipFile]::Open($archivePath, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files) { [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, (Relative $file.FullName), [IO.Compression.CompressionLevel]::Optimal) | Out-Null }
} finally { $zip.Dispose() }
$zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($zip.Entries.Count -ne $manifest.Count) { throw 'Archive file count mismatch.' }
    foreach ($row in $manifest) {
        $entry = $zip.GetEntry($row.Path)
        if ($null -eq $entry -or $entry.Length -ne $row.Bytes) { throw 'Archive length mismatch.' }
        $stream = $entry.Open(); $sha = [Security.Cryptography.SHA256]::Create()
        try { $actual = [Convert]::ToHexString($sha.ComputeHash($stream)).ToLowerInvariant() }
        finally { $sha.Dispose(); $stream.Dispose() }
        if ($actual -ne $row.Sha256) { throw 'Archive hash mismatch.' }
    }
} finally { $zip.Dispose() }
$report = [ordered]@{
    Date = '2026-10-24'; BaseCommit = (git rev-parse HEAD).Trim(); SourceDirty = $true
    Problem = 'Installed EXE also ran the waiting OTA helper; the native exclusive old-EXE guard rejected Setup with exit 7.'
    Repairs = @('Cache runtime copy with bounded traversal and per-file SHA-256 verification',
        'Original registered installation and active release bound to ticket; parent verified against original EXE',
        'Normal parent exit and actual old-image handle release before Setup',
        'Wait for final installer mutex and file-gate release before restart',
        'Recovery always addresses original installation',
        'Same-version different payload labelled Update; same payload labelled Repair',
        'Unsigned Windows publisher state explained separately from OTA verification')
    FocusedTests = @{ Passed = 149; Total = 149; Failed = 0; Skipped = 0; NewCases = 8;
        Trx = 'artifacts/validation/ota-handoff-20261024/tests/ota-final-v3.trx'; Sha256 = Hash (Join-Path $raw 'tests/ota-final-v3.trx') }
    NativeInstaller = @{ Passed = 49; Failed = 0; TestFixtureOnly = $true; Date = $native.Date; ProductAppId = $native.ProductAppId;
        Summary = 'artifacts/validation/ota-handoff-20261024/native-policy-final/summary.json'; Sha256 = Hash (Join-Path $raw 'native-policy-final/summary.json') }
    RuntimeProof = @{ RealProductChild = $true; FullSelfContainedPayload = $true; GlobalRuntimeRootDisabled = $true;
        OriginalExeExclusivelyAvailable = $true; CachedExeRemainedInUse = $true; GuiVerified = $false }
    Interface = @{ Languages = @('zh-CN','en-US','ja-JP'); FontSizes = @(13,18); HeadlessSkiaScreenshots = $true; NativeHighDpiAccepted = $false }
    Build = @{ DefaultDebug = 'passed'; DefaultRelease = 'passed, 0 warnings, 0 errors'; SelfContainedX64 = 'passed' }
    Package = @{ Path = Relative $installer; Sha256 = Hash $installer; Bytes = (Get-Item -LiteralPath $installer).Length;
        ReleaseId = $package.ReleaseId; Version = $package.Version; OtaBuildSequence = $package.OtaBuildSequence;
        SourceCommit = $package.SourceCommit; SourceDirty = $package.SourceDirty; WindowsPublisherSigned = $false;
        ProductionInstalled = $false; GitHubPublished = $false; MetadataSha256 = Hash (Join-Path $packagePath 'release.json') }
    PreservedFailures = @('Original setup exit 7 and handoff error logs',
        'First isolated matrix stopped at fresh-noicons-install due to final uninstaller mutex release race',
        'Intermediate 148-case stage and Windows-only test annotation warnings; not added to final totals')
    Limits = @('Existing installed or downloaded clients are unchanged and need one manual bootstrap install after normal exit',
        'No real cloud-signed end-to-end OTA install/restart acceptance', 'No Windows publisher certificate supplied',
        'No ARM64 hardware acceptance', 'No full repository suite', 'No optical calculation changes')
    Sources = $sourceRecords
    Evidence = @{ Archive = Relative $archivePath; Sha256 = Hash $archivePath; Files = $manifest.Count; ReadbackVerified = $true }
}
$report | ConvertTo-Json -Depth 9 | Set-Content -LiteralPath $reportPath -Encoding utf8
@{ ArchiveSha256 = Hash $archivePath; Files = $manifest } | ConvertTo-Json -Depth 6 |
    Set-Content -LiteralPath ($archivePath + '.manifest.json') -Encoding utf8
Write-Output "Recorded 149 focused tests, 49 isolated installer checks; $($manifest.Count) archive payloads verified."
