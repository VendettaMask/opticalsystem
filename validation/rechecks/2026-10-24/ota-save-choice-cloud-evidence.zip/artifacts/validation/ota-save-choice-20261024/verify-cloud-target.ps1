$ErrorActionPreference = 'Stop'
$evidence = $PSScriptRoot
$repositoryRoot = (Resolve-Path -LiteralPath (Join-Path $evidence '..\..\..')).Path
$release = gh api repos/VendettaMask/opticalsystem/releases/tags/v1.0.4-test.20261019 | ConvertFrom-Json
if ($LASTEXITCODE -ne 0) { throw 'Cannot read public release.' }
$release | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $evidence 'release-after-cloud.json') -Encoding utf8
$matches = [regex]::Matches($release.body.Replace("`r`n", "`n"), '<!-- optical-system-design-ota-v1\n([A-Za-z0-9+/=]+\.[A-Za-z0-9+/=]+)\n-->')
if ($matches.Count -ne 1) { throw 'Unexpected OTA envelope count.' }
$parts = $matches[0].Groups[1].Value.Split('.')
$bytes = [Convert]::FromBase64String($parts[0])
$signature = [Convert]::FromBase64String($parts[1])
$rsa = [Security.Cryptography.RSA]::Create()
try {
    $rsa.ImportFromPem([IO.File]::ReadAllText((Join-Path $repositoryRoot 'src\OpticalSystemDesign.App\Assets\Updates\ota-public-key.pem')))
    if ($rsa.KeySize -ne 4096 -or $signature.Length -ne 512 -or -not $rsa.VerifyData($bytes, $signature, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pss)) {
        throw 'Published signature rejected.'
    }
} finally { $rsa.Dispose() }
$payload = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
if ($payload.SourceCommit -ne '1bb09acf1cb5684c9a5cfb1a66edc2462296c7c3' -or $payload.BuildSequence -ne 40073865616 -or $payload.Runtime -ne 'win-x64' -or $payload.Version -ne '1.0.4') {
    throw 'The published package is not this repair build.'
}
$asset = @($release.assets | Where-Object name -eq $payload.Name)
if ($asset.Count -ne 1 -or $asset[0].size -ne $payload.Size -or $asset[0].digest -ne ('sha256:' + $payload.Sha256)) { throw 'Published asset differs from signed payload.' }
$previous = Get-Content -LiteralPath (Join-Path $evidence 'release-before-cloud.json') -Raw | ConvertFrom-Json
$oldMac = @($previous.assets | Where-Object name -like '*.dmg')[0]
$newMac = @($release.assets | Where-Object name -like '*.dmg')[0]
if ($oldMac.id -ne $newMac.id -or $oldMac.size -ne $newMac.size -or $oldMac.digest -ne $newMac.digest) { throw 'Mac asset changed.' }
$tag = gh api repos/VendettaMask/opticalsystem/git/ref/tags/v1.0.4-test.20261019 | ConvertFrom-Json
if ($LASTEXITCODE -ne 0 -or $tag.object.sha -ne '9242b31abf38b4d97f23d19e4b00f8df47abfabb') { throw 'Release tag changed.' }
$payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $evidence 'signed-cloud-target.json') -Encoding utf8
[ordered]@{
    Date = '2026-10-24'
    RunId = 40073865616
    SourceCommit = $payload.SourceCommit
    BuildSequence = $payload.BuildSequence
    ReleaseId = $payload.ReleaseId
    Bytes = $payload.Size
    Sha256 = $payload.Sha256
    AssetId = $asset[0].id
    SignatureVerifiedAgainstPinnedKey = $true
    SignedIdentityMatchesAsset = $true
    TagUnchanged = $true
    MacAssetPreserved = $true
    MacAssetId = $newMac.id
    MacDigest = $newMac.digest
    Prerelease = $release.prerelease
    NewDiscardBranchNativeOtaVerified = $false
    UserInstallationReplaced = $false
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $evidence 'cloud-target-verification.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $evidence 'cloud-target-verification.json')
