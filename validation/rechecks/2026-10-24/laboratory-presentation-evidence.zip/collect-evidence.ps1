$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$repository = [IO.Path]::GetFullPath((Join-Path $taskRoot '../..'))
Set-Location -LiteralPath $repository
$runNames = @('alignment-camera-debug.trx', 'coating-desktop-debug.trx', 'laboratory-layout-debug.trx', 'coating-layout-final-debug.trx', 'alignment-camera-layout-final-debug.trx')
$results = @()
$runs = foreach ($name in $runNames) {
    [xml]$trx = Get-Content -LiteralPath (Join-Path $taskRoot "tests/$name") -Raw
    $cases = @($trx.SelectNodes('//*[local-name()="UnitTestResult"]') | ForEach-Object {
        [pscustomobject]@{ TestId=$_.testId; Name=$_.testName; Outcome=$_.outcome }
    })
    $results += $cases
    [pscustomobject]@{ Trx="tests/$name"; Total=$cases.Count; Passed=@($cases | Where-Object Outcome -eq 'Passed').Count; Failed=@($cases | Where-Object Outcome -eq 'Failed').Count; Other=@($cases | Where-Object Outcome -notin @('Passed','Failed')).Count }
}
$distinct = @($results | Group-Object Name | ForEach-Object { $_.Group[-1] })
if ($distinct.Count -ne 35 -or @($results | Where-Object Outcome -ne 'Passed').Count) { throw 'Unexpected scoped test results.' }
$sources = @(
    'src/OpticalSystemDesign.App/Laboratories/LaboratoryPresentation.cs',
    'src/OpticalSystemDesign.App/Laboratories/OpticalAssemblyWindow.cs',
    'src/OpticalSystemDesign.App/Laboratories/OpticalAssemblyWindow.Presentation.cs',
    'src/OpticalSystemDesign.App/Laboratories/CameraImagingWindow.cs',
    'src/OpticalSystemDesign.App/Laboratories/CoatingDesign/MainWindow.cs',
    'src/OpticalSystemDesign.App/Laboratories/CoatingDesign/MaterialEditorWindow.cs',
    'src/OpticalSystemDesign.App/Services/UiLocalization.cs',
    'tests/OpticalSystemDesign.Tests/LaboratoryPresentationTests.cs'
)
$sourceHashes = foreach ($path in $sources) {
    $target = Join-Path $taskRoot "source/$path"
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath $path -Destination $target -Force
    [pscustomobject]@{ Path=$path; Sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$binaries = foreach ($configuration in @('Debug','Release')) {
    foreach ($assembly in @('OpticalSystemDesign.App','OpticalSystemDesign.Application','OpticalSystemDesign.Core')) {
        $path = "src/OpticalSystemDesign.App/bin/$configuration/net10.0/$assembly.dll"
        [pscustomobject]@{ Configuration=$configuration; Path=$path; Sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
    }
}
$builds = foreach ($configuration in @('Debug','Release')) {
    $log = "build-$($configuration.ToLowerInvariant())-final.log"
    $content = Get-Content -LiteralPath (Join-Path $taskRoot $log) -Raw
    if ($content -notmatch '0 个警告' -or $content -notmatch '0 个错误') { throw "Unconfirmed build: $log" }
    [pscustomobject]@{ Configuration=$configuration; Log=$log; ExitCode=0; Warnings=0; Errors=0; DefaultOutput=$true }
}
$report = [ordered]@{
    SchemaVersion=1; Date='2026-10-24'; BaseCommit=(git rev-parse HEAD).Trim(); WorkingTreeDirty=$true
    Scope=@('Coating Design presentation and material editor', 'Optical Assembly presentation', 'Camera Imaging presentation')
    AutoLensChangedByThisTask=$false; CoreOpticalFormulasChangedByThisTask=$false; DefaultsChangedByThisTask=$false
    SamplingChangedByThisTask=$false; TolerancesChangedByThisTask=$false; PersistenceChangedByThisTask=$false
    OtherWorkspaceChangesPreserved=$true; FullSuiteRun=$false; NativeDesktopAcceptance=$false; ZemaxCertification=$false
    CommittedOrPushed=$false; InstallerPackagedOrReplaced=$false; InstalledApplicationReplaced=$false
    Rendering='Avalonia Headless with Skia; actual UI and related calculations, not native desktop acceptance'
    SourceSnapshots=$sourceHashes; BuildResults=$builds; BinaryEvidence=$binaries; TestRuns=$runs
    TestExecutions=$results.Count; DistinctCases=$distinct.Count; DistinctPassed=@($distinct | Where-Object Outcome -eq 'Passed').Count
    DistinctFailed=0; Skipped=0; NewLayoutCases=9; DistinctCaseResults=$distinct
    IncompleteRuns=@([ordered]@{ Log='tests-coating-layout-final-debug.compile-incomplete.log'; Reason='Transient CS0103 in independently edited ZemaxZmxReader.PolygonGroup.cs; no tests started; same focused filter passed after shared file updated.' })
    Screenshots=@(Get-ChildItem -LiteralPath $taskRoot -Filter '*.png' -Recurse -File | ForEach-Object { [IO.Path]::GetRelativePath($taskRoot,$_.FullName).Replace('\','/') })
    VisualReview=@('coating-final/ar-1200-900.png','camera-final/Light-stages.png','assembly-final/cooke-initial.png','coating/material-editor.png','layout/camera-ja-JP-Light-760-overview.png','layout/coating-ja-JP-Light-820-overview.png','layout/assembly-en-US-Dark-1100-overview.png')
    DocumentationAudit='documentation-audit.json'
    EvidenceArchive='validation/rechecks/2026-10-24/laboratory-presentation-evidence.zip'
    Limitations=@('Focused UI validation only; no full optical regression or tolerance change', 'Existing camera service and unrelated shared workspace changes are outside this presentation task', 'Existing untranslated text may remain; checks cover layout and preserving data during language switches', 'Only local source and default build output updated')
}
$report | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath docs/validation/LABORATORY_PRESENTATION_2026-10-24.json -Encoding utf8
$docs = @('docs/LABORATORY_PRESENTATION_2026-10-24.md','docs/UI_DESIGN_SPEC.md','docs/USER_GUIDE.md','docs/GUI_QUICKSTART_REFACTOR.md','docs/OPTICAL_ASSEMBLY_LAB.md','docs/CAMERA_IMAGING_LAB.md','labs/CoatingDesign/README.md','docs/CURRENT_STATUS.md','docs/README.md')
foreach ($path in $docs) {
    $target = Join-Path $taskRoot "documentation/$path"
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath $path -Destination $target -Force
}
$manifest = @(Get-ChildItem -LiteralPath $taskRoot -Recurse -File | Where-Object Name -ne 'manifest.json' | ForEach-Object {
    [pscustomobject]@{ Path=[IO.Path]::GetRelativePath($taskRoot,$_.FullName).Replace('\','/'); Bytes=$_.Length; Sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
})
$manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'manifest.json') -Encoding utf8
$zip = Join-Path $repository $report.EvidenceArchive
if (Test-Path -LiteralPath $zip) { throw 'Evidence archive already exists; use explicit update after review.' }
[IO.Compression.ZipFile]::CreateFromDirectory($taskRoot, $zip, [IO.Compression.CompressionLevel]::Optimal, $false)
Write-Output "Distinct tests: $($distinct.Count), executions: $($results.Count), all passed. Archive: $zip"
