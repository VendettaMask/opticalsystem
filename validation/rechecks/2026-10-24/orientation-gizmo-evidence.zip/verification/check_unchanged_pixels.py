import hashlib
import json
from pathlib import Path
import numpy as np
from PIL import Image

scope = Path(__file__).parent.parent
previous = scope / 'verification/baseline'
current = scope / 'captures'
results = []
for mode in ['SolidModel', 'OpticalLayout']:
    for theme, language in [('Light', 'zh-CN'), ('Dark', 'en-US')]:
        name = f'viewer3d-{mode}-{theme}-{language}.png'
        old = previous / name
        new = current / name
        a = np.array(Image.open(old).convert('RGBA'))
        b = np.array(Image.open(new).convert('RGBA'))
        assert a.shape == b.shape
        changed = np.any(a != b, axis=2)
        allowed = np.zeros(changed.shape, dtype=bool)
        if mode == 'SolidModel':
            allowed[-180:, :115] = True
            allowed[-180:, -100:] = True
        outside = int(np.count_nonzero(changed & ~allowed))
        assert outside == 0, (name, outside)
        results.append(dict(file=name, previousSha256=hashlib.sha256(old.read_bytes()).hexdigest(),
            currentSha256=hashlib.sha256(new.read_bytes()).hexdigest(),
            changedPixels=int(np.count_nonzero(changed)), changedOutsideGizmoRegions=outside))
output = Path(__file__).parent / 'unchanged-pixels.json'
output.write_text(json.dumps(dict(results=results,
    scope='Exact RGBA image comparison against the immediately preceding ray-display stage; no optical accuracy comparison.'), indent=2) + '\n')
print(json.dumps(results, indent=2))
