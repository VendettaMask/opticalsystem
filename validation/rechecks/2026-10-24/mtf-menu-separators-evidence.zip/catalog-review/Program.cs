using System.Text.Encodings.Web;
using System.Text.Json;
using OpticalSystemDesign.Application.Services;

var menu = WorkbenchAnalysisCatalog.RibbonMenus.Single(menu => menu.Label == "MTF 曲线");
var commands = WorkbenchAnalysisCatalog.AllRibbonCommands.ToDictionary(command => command.Id);
var unresolved = WorkbenchAnalysisCatalog.RibbonMenus.SelectMany(menu => menu.CommandIds)
    .Where(id => id != "-" && !commands.ContainsKey(id)).ToArray();
Console.WriteLine(JsonSerializer.Serialize(new
{
    menu.Label,
    Entries = menu.CommandIds.Select(id => id == "-" ? "---" : commands[id].Label),
    SeparatorPositions = menu.CommandIds.Select((id, index) => (id, index)).Where(item => item.id == "-").Select(item => item.index),
    CommandCount = menu.CommandIds.Count(id => id != "-"),
    UnresolvedCommands = unresolved,
    Scope = "Compiles the actual menu catalog only; does not build or validate the full desktop app."
}, new JsonSerializerOptions { WriteIndented = true, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping }));
