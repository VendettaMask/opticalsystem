using System.Reflection;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Presenters;
using Avalonia.Headless;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using Avalonia.VisualTree;
using Dock.Avalonia.Controls;
using OpticalSystemDesign.App;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Panels;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.App.Theming;
using OpticalSystemDesign.Application.Formatting;
using OpticalSystemDesign.Application.Services;

using System.Text.Json;
using SkiaSharp;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        var output = Path.GetFullPath(args[0]); Directory.CreateDirectory(output);
        AppBuilder.Configure<global::OpticalSystemDesign.App.App>().UseSkia()
            .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false }).UseHarfBuzz().SetupWithoutStarting();
        var theme = "Light"; double width = 1280, fontSize = 13;
            ThemeApplicationService.Apply(Avalonia.Application.Current!, theme);
            var settings = new AppSettings { FontSize = fontSize, Theme = theme, LeftPaneWidth = 256 };
            DisplayTypography.Configure(settings);
            using var application = WorkbenchApplication.Create();
            Populate(application);
            using var panels = new PanelManager(application, settings,
                new WorkspaceSessionStore(Path.Combine(Path.GetTempPath(), "reference-workbench", Guid.NewGuid().ToString("N"))));
            var snapshot = application.Documents.GetSnapshot();
            var commands = new[]
            {
                Button("file-plus", "新建"), Button("folder-open", "打开"), Button("save", "保存"),
                Button("download", "导入", true), Button("upload", "导出", true), Button("aperture", "示例", true),
                Button("undo", "撤销"), Button("redo", "重做")
            };
            MainWindow.UpdateHistoryButtons(commands[6], commands[7], snapshot.CanUndo, snapshot.CanRedo);
            var groups = new[]
            {
                Group("文件", true, commands[..3]), Group("交换与示例", true, commands[3..6]), Group("编辑", false, commands[6..])
            };
            var page = (Control)Invoke("BuildRibbonPage", new object[] { groups });
            var names = new[] { "文件", "设置", "视图", "分析", "优化", "公差", "加工与图纸", "数据库", "实验室", "窗口", "帮助" };
            var tabs = new TabControl
            {
                SelectedIndex = 0,
                ItemsSource = names.Select(name => (TabItem)Invoke("RibbonTab", name, name == "文件" ? page : new Border())).ToArray()
            };
            var ribbon = MainWindow.BuildRibbonFrame(tabs);
            var status = MainWindow.BuildStatusBarFrame(
                new TextBlock { Text = snapshot.Status },
                new TextBlock { Text = $"EFFL: {Invoke("FormatMetric", snapshot.EffectiveFocalLength)}" },
                new TextBlock { Text = $"F/#: {Invoke("FormatMetric", snapshot.FNumber)}" },
                new TextBlock { Text = $"APER: {NumericDisplayFormatter.Format(snapshot.ApertureValue)}" },
                new TextBlock { Text = $"TOTR: {Invoke("FormatMetric", snapshot.TotalTrack)}" });
            var shell = MainWindow.BuildShellLayout(new ContentControl { Content = ribbon }, panels.WorkspaceControl, status);
            var actions = new ActionManager();
            actions.Register("show-lens-editor", "镜头数据", "设置", () => panels.Show(WorkspacePanelId.LensEditor));
            var window = new Window { Title = snapshot.Name + " - 顺序模式 - Optical System Design", Width = width, Height = 820 };
            window.Content = MainWindowTitleBar.Wrap(window, shell, new CommandSearchControl(actions));
            DisplayTypography.Apply(window);
            window.Show();
                Tick(window);
                panels.ApplyLayout(new WorkspaceLayoutState(256));
                Tick(window);

        var production = args.Contains("--production");
        var baseline = Path.Combine(output, production ? "dock-production-12.png" : "dock-current.png"); Capture(window, baseline);
        if (production)
        {
            foreach (var dock in window.GetVisualDescendants().Where(v => v is ToolDockControl or DocumentDockControl))
            {
                if (dock.Clip is not RectangleGeometry { RadiusX: 12, RadiusY: 12 } clip || clip.Rect != new Rect(dock.Bounds.Size))
                    throw new InvalidOperationException("Product Dock clipping did not follow live bounds.");
            }
            File.WriteAllText(Path.Combine(output, "production-receipt.json"), JsonSerializer.Serialize(new
            {
                RealAvaloniaControls = true, RuntimeCornerOverridesApplied = false, Styles = "Current product stylesheet",
                RadiusDip = 12, UserSettingsWritten = false, SamplePrescription = "In-memory UI specimen"
            }, new JsonSerializerOptions { WriteIndented = true }));
            window.Close(); Console.WriteLine("Rendered product 12 DIP Dock styles without preview overrides."); return;
        }
        foreach (var radius in new[] { 8d, 12d })
        {
            Round(window, radius); Tick(window);
            Capture(window, Path.Combine(output, $"dock-rounded-{radius:0}.png"));
        }
        using (var sheet = new SKBitmap(1800, 440))
        using (var canvas = new SKCanvas(sheet))
        using (var paint = new SKPaint { IsAntialias = true, Color = SKColor.Parse("#22354D") })
        using (var font = new SKFont(SKTypeface.FromFamilyName("Arial"), 23))
        {
            canvas.Clear(SKColors.White);
            var files = new[] { "dock-current.png", "dock-rounded-8.png", "dock-rounded-12.png" };
            var labels = new[] { "Current", "8 DIP", "12 DIP" };
            for (var i = 0; i < 3; i++)
            {
                canvas.DrawText(labels[i], i * 600 + 20, 32, font, paint);
                using var bitmap = SKBitmap.Decode(Path.Combine(output, files[i]));
                canvas.DrawBitmap(bitmap, new SKRect(0, 236, 1200, 756), new SKRect(i * 600, 48, (i + 1) * 600, 308));
                canvas.DrawBitmap(bitmap, new SKRect(0, 1480, 1200, 1620), new SKRect(i * 600, 358, (i + 1) * 600, 428));
            }
            using var data = sheet.Encode(SKEncodedImageFormat.Png, 100);
            using var stream = File.Create(Path.Combine(output, "dock-corner-comparison.png")); data.SaveTo(stream);
        }
        File.WriteAllText(Path.Combine(output, "preview-receipt.json"), JsonSerializer.Serialize(new
        {
            RealAvaloniaControls = true, Theme = "Light", FontSizeDip = 13, PreviewRadiiDip = new[] { 8, 12 },
            ProductionStylesChanged = false, UserSettingsWritten = false,
            SamplePrescription = "In-memory UI specimen; no optical accuracy claim", TabSelectionEdge = "Original blue right edge retained"
        }, new JsonSerializerOptions { WriteIndented = true }));
        window.Close();
        Console.WriteLine("Rendered current, 8 DIP and 12 DIP dock previews.");
    }
    private static void Populate(WorkbenchApplication app)
    {
        for (var i = 0; i < 6; i++) app.Prescription.AddSurface();
        var rows = app.Prescription.GetSurfaces().ToArray();
        app.Prescription.UpdateSurface(rows[0] with { Thickness = double.PositiveInfinity, SemiDiameter = 8 });
        double[] radii = [32, -32, 48, -48, 60, -60]; double[] thickness = [5, 12, 4, 14, 5, 35];
        for (var i = 0; i < 6; i++) app.Prescription.UpdateSurface(rows[i + 1] with
        { Label = $"S{i + 1}", Radius = radii[i], Thickness = thickness[i], Material = i % 2 == 0 ? "N-BK7" : "Air", SemiDiameter = 8, IsStop = i == 0 });
        app.Prescription.UpdateSurface(rows[^1] with { Label = "Image", Thickness = 0, SemiDiameter = 12 });
    }
    private static void Round(Window window, double radius)
    {
        foreach (var dock in window.GetVisualDescendants().Where(v => v is ToolDockControl or DocumentDockControl))
            dock.Clip = new RectangleGeometry(new Rect(dock.Bounds.Size), radius, radius);
        foreach (var doc in window.GetVisualDescendants().OfType<DocumentControl>())
        {
            var frame = doc.GetVisualDescendants().OfType<Border>().Single(b => b.TemplatedParent == doc && b.Name == "PART_Border");
            frame.CornerRadius = new CornerRadius(radius); frame.ClipToBounds = true;
            frame.Clip = new RectangleGeometry(new Rect(frame.Bounds.Size), radius, radius);
        }
        foreach (var chrome in window.GetVisualDescendants().OfType<ToolChromeControl>())
        {
            var header = chrome.GetVisualDescendants().OfType<Border>().Single(b => b.TemplatedParent == chrome && b.Name == "PART_Border");
            header.CornerRadius = new CornerRadius(radius, radius, 0, 0); header.ClipToBounds = true;
        }
    }
    private static void Capture(Window window, string path)
    {
        Tick(window);
        using var bitmap = new RenderTargetBitmap(new PixelSize((int)window.Width * 2, (int)window.Height * 2), new Vector(192, 192));
        bitmap.Render(window); bitmap.Save(path, PngBitmapEncoderOptions.Default);
    }
    private static Button Button(string icon, string label, bool dropdown = false)
    {
        var button = dropdown ? new DropDownButton() : new Button();
        button.Content = Invoke(dropdown ? "RibbonDropDownCommandContent" : "RibbonCommandContent", icon, label);
        button.HorizontalContentAlignment = HorizontalAlignment.Center;
        button.VerticalContentAlignment = VerticalAlignment.Center;
        button.Classes.Add("ribbon-command");
        if (dropdown) button.Classes.Add("ribbon-dropdown");
        Invoke("BindRibbonCommandLayout", button);
        Invoke("BindRibbonCommandChrome", button);
        Invoke("AttachRibbonCommandHover", button, button.Content);
        return button;
    }

    private static Control Group(string title, bool divider, Button[] buttons) =>
        (Control)Invoke("RibbonGroup", title, divider, buttons.Cast<Control>().ToArray());

    private static object Invoke(string name, params object?[] arguments) =>
        typeof(MainWindow).GetMethods(BindingFlags.Static | BindingFlags.NonPublic)
            .Single(method => method.Name == name && method.GetParameters().Length == arguments.Length)
            .Invoke(null, arguments)!;

    private static void Tick(Window window)
    {
        Dispatcher.UIThread.RunJobs(); window.UpdateLayout(); AvaloniaHeadlessPlatform.ForceRenderTimerTick();
    }

}
