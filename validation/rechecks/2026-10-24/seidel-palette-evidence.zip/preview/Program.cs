using System.Globalization;
using System.Reflection;
using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using OpticalSystemDesign.App.Controls;
using OpticalSystemDesign.App.Services;
using OpticalSystemDesign.Application.Contracts;
using OpticalSystemDesign.Core.Analysis;
using OpticalSystemDesign.Core.FileIO;

AppBuilder.Configure<OpticalSystemDesign.App.App>().UseSkia()
    .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false })
    .UseHarfBuzz().SetupWithoutStarting();
var output = Path.GetFullPath(args[0]);
Directory.CreateDirectory(output);
var source = Path.GetFullPath("artifacts/zemax/123456-zemax-2026-r1-baseline/source/123456.ZMX");
var optic = OpticalFormatCatalog.Import(File.ReadAllText(source), ".zmx");
var data = new SeidelDiagramAnalysis(optic, wavelengthNumber: 2).GenerateData();
var table = new AnalysisTableDto(data.Table!.Columns, data.Table.Rows);
File.WriteAllText(Path.Combine(output, "table.json"), JsonSerializer.Serialize(table));
var applyTheme = typeof(OpticalSystemDesign.App.App).Assembly.GetType(
    "OpticalSystemDesign.App.Theming.ThemeApplicationService")!.GetMethod("Apply")!;
var manifest = new List<object>();
foreach (var theme in new[] { "Light", "Dark", "Isekai", "Pixel", "Lumen" })
{
    applyTheme.Invoke(null, [Avalonia.Application.Current!, theme]);
    DisplayTypography.Configure(new AppSettings { Theme = theme, FontSize = 13 });
    // Product calculation for the preview; a separate signed probe exercises all seven bar colors.
    Capture(theme, "sample", table, 0.1);
    var probe = new AnalysisTableDto(table.Columns,
        [new[] { "+", "0.45", "0.45", "0.45", "0.45", "0.45", "0.45", "0.45" },
         new[] { "−", "-0.45", "-0.45", "-0.45", "-0.45", "-0.45", "-0.45", "-0.45" }]);
    Capture(theme, "signed-probe", probe, 0.6);
}
File.WriteAllText(Path.Combine(output, "renders.json"), JsonSerializer.Serialize(manifest,
    new JsonSerializerOptions { WriteIndented = true }));

void Capture(string theme, string label, AnalysisTableDto values, double maximum)
{
    var chart = new SeidelDiagramControl { Table = values, MaximumAberration = maximum, GridInterval = 0.1 };
    var window = new Window { Width = 960, Height = 560, Content = chart };
    try
    {
        window.Show();
        Dispatcher.UIThread.RunJobs(); window.UpdateLayout();
        AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        Dispatcher.UIThread.RunJobs(); window.UpdateLayout();
        var resourceFound = chart.TryFindResource(ThemeResourceBindings.PlotBackground, chart.ActualThemeVariant, out var value);
        if (!resourceFound || value is not ISolidColorBrush background) throw new InvalidOperationException("No theme background");
        using var bitmap = new RenderTargetBitmap(new PixelSize(960, 560), new Vector(96, 96));
        bitmap.Render(window);
        var file = $"seidel-{theme}-{label}.png";
        bitmap.Save(Path.Combine(output, file), PngBitmapEncoderOptions.Default);
        manifest.Add(new { file, theme, themeBackground = background.Color.ToString(), width = chart.Bounds.Width,
            height = chart.Bounds.Height, rows = values.Rows.Count, maximum, dpi = 96 });
    }
    finally { window.Close(); }
}
