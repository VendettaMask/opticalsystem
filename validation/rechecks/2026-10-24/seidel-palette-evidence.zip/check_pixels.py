import hashlib
import io
import json
from pathlib import Path
from PIL import Image, ImageCms

root = Path(__file__).parent
reference = Path('/var/folders/cb/v0mdrb6x27n0gn3trpqhw9nr0000gn/T/codex-clipboard-80f23f0f-7901-4044-a44e-b0e06878da77.png')
hexes = ['#1F77B4', '#2CA02C', '#D62728', '#17BECF', '#9467BD', '#BCBD22', '#FF7F0E']
palette = [tuple(bytes.fromhex(value[1:])) for value in hexes]
im = Image.open(reference)
profile = ImageCms.ImageCmsProfile(io.BytesIO(im.info['icc_profile']))
srgb = ImageCms.profileToProfile(im, profile, ImageCms.createProfile('sRGB'), outputMode='RGB')
samples = [(246,55), (501,55), (754,55), (246,87), (501,87), (754,87), (246,118)]
reference_results = []
for xy, expected in zip(samples, palette):
    actual = srgb.getpixel(xy)
    delta = max(abs(a-b) for a,b in zip(actual, expected))
    assert delta <= 2, (xy, actual, expected)
    reference_results.append(dict(point=xy, srgb=actual, selected=expected, maxChannelDifference=delta))

checks = []
for item in json.loads((root / 'renders/renders.json').read_text()):
    im = Image.open(root / 'renders' / item['file']).convert('RGB')
    def check(x, y, expected, kind, coefficient=None):
        actual = im.getpixel((round(x), round(y)))
        assert actual == expected, (item['file'], kind, coefficient, actual, expected)
        checks.append(dict(file=item['file'], kind=kind, coefficient=coefficient,
                           point=[round(x), round(y)], actual=actual, expected=expected))
    color = item['themeBackground']
    background = (255,255,255) if color == 'White' else tuple(bytes.fromhex(color[-6:]))
    check(2, 2, background, 'theme-background')
    for i, expected in enumerate(palette):
        check(24 + (i + 0.5) * 912/7, 512, expected, 'legend', i)
        if 'signed-probe' in item['file']:
            for row, y in [(0, 184), (1, 352)]:
                check(24 + row*456 + 456*0.14 + (i+0.5)*456*0.72/7,
                      y, expected, 'positive-bar' if row == 0 else 'negative-bar', i)

report = dict(referenceSha256=hashlib.sha256(reference.read_bytes()).hexdigest(),
              referenceProfile=ImageCms.getProfileDescription(profile).strip(),
              referenceComparison='ICC-converted sRGB; <=2/255 per-channel screenshot quantization allowance',
              palette=hexes, referenceSamples=reference_results, renderSamples=checks,
              renderChecksPassed=len(checks), themes=5, images=10, dpi=96,
              scope='Rendered controls only; no new optical accuracy certification or native GUI/HiDPI acceptance')
(root / 'pixel-checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(f'{len(checks)} rendered pixel checks passed; 7 reference colors match within 2/255 after ICC conversion.')
