$ErrorActionPreference = 'Stop'
$runId = 40064177748L
$sourceCommit = 'e6631b79f1b8ebf2b26fb5d4ca462dd90215ed90'
$directory = $PSScriptRoot
$repo = 'VendettaMask/opticalsystem'
$tag = 'v1.0.4-test.20261019'
$name = 'OpticalSystemDesign-1.0.4-win-x64-UnsignedTest-Setup.exe'
gh run view $runId --json status,conclusion,headSha,jobs,url > (Join-Path $directory 'run-final.json')
if ($LASTEXITCODE) { throw 'Cannot read workflow result.' }
$run = Get-Content -Raw (Join-Path $directory 'run-final.json') | ConvertFrom-Json
if ($run.status -ne 'completed' -or $run.conclusion -ne 'success' -or $run.headSha -ne $sourceCommit) { throw 'Workflow did not complete successfully from the expected source.' }
gh api "repos/$repo/releases/tags/$tag" > (Join-Path $directory 'release-after.json')
if ($LASTEXITCODE) { throw 'Cannot read release.' }
gh api "repos/$repo/git/ref/tags/$tag" > (Join-Path $directory 'tag-after.json')
if ($LASTEXITCODE) { throw 'Cannot read tag.' }
$release = Get-Content -Raw (Join-Path $directory 'release-after.json') | ConvertFrom-Json
$before = Get-Content -Raw (Join-Path $directory 'release-before.json') | ConvertFrom-Json
$oldTag = Get-Content -Raw (Join-Path $directory 'tag-before.json') | ConvertFrom-Json
$newTag = Get-Content -Raw (Join-Path $directory 'tag-after.json') | ConvertFrom-Json
if ($oldTag.object.sha -ne $newTag.object.sha) { throw 'Release tag moved.' }
if (-not $release.prerelease -or $release.draft -or $release.assets.Count -ne 2) { throw 'Release/attachment shape changed unexpectedly.' }
$asset = @($release.assets | Where-Object name -CEQ $name)
if ($asset.Count -ne 1) { throw 'Expected exactly one Windows installer.' }
$asset = $asset[0]
$macName = 'OpticalSystemDesign-1.0.4-osx-arm64-AdHocTest.dmg'
$oldMac = @($before.assets | Where-Object name -CEQ $macName)
$newMac = @($release.assets | Where-Object name -CEQ $macName)
if ($oldMac.Count -ne 1 -or $newMac.Count -ne 1 -or $oldMac[0].id -ne $newMac[0].id -or
    $oldMac[0].digest -cne $newMac[0].digest -or $oldMac[0].size -ne $newMac[0].size) { throw 'Untouched Mac asset changed.' }
$matches = [regex]::Matches($release.body,'(?s)<!-- optical-system-design-ota-v1\s+([A-Za-z0-9+/=]+)\.([A-Za-z0-9+/=]+)\s+-->')
if ($matches.Count -ne 1) { throw 'Unexpected OTA envelope count.' }
$bytes = [Convert]::FromBase64String($matches[0].Groups[1].Value)
$signature = [Convert]::FromBase64String($matches[0].Groups[2].Value)
$payload = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
$rsa = [Security.Cryptography.RSA]::Create()
try {
    $rsa.ImportFromPem([IO.File]::ReadAllText((Join-Path (Get-Location) 'src/OpticalSystemDesign.App/Assets/Updates/ota-public-key.pem')))
    if ($rsa.KeySize -ne 4096 -or -not $rsa.VerifyData($bytes,$signature,[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pss)) { throw 'Pinned-key OTA signature failed.' }
} finally { $rsa.Dispose() }
if ($payload.Format -ne 2 -or $payload.BuildSequence -ne $runId -or $payload.SourceCommit -cne $sourceCommit -or
    $payload.Repository -cne $repo -or $payload.Tag -cne $tag -or $payload.Version -cne '1.0.4' -or $payload.Runtime -cne 'win-x64' -or
    $payload.ProductAppId -cne 'OpticalSystemDesign-8D387EA8-F349-447F-B5D3-B58E27F46D4A' -or
    $payload.Name -cne $name -or $payload.Size -ne $asset.size -or $asset.digest -cne "sha256:$($payload.Sha256)" -or
    $payload.ReleaseId -cnotmatch '^1\.0\.4-win-x64-[0-9a-f]{12}$') { throw 'Signed identity does not match the source or asset.' }
$downloadDirectory = Join-Path $directory 'public-download'
gh release download $tag --repo $repo --pattern $name --dir $downloadDirectory
if ($LASTEXITCODE) { throw 'Cannot download the public installer.' }
$file = Get-Item -LiteralPath (Join-Path $downloadDirectory $name)
$hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
if ($file.Length -ne $payload.Size -or $hash -cne $payload.Sha256) { throw 'Full public download hash differs from the signed payload.' }
$verification = [ordered]@{
    Date = '2026-10-24'; RunId = $runId; Workflow = $run.url; SourceCommit = $sourceCommit
    ReleaseUrl = $release.html_url; ReleaseId = $payload.ReleaseId; BuildSequence = $payload.BuildSequence
    Version = $payload.Version; Runtime = $payload.Runtime; AssetId = $asset.id; Name = $name
    Sha256 = $hash; Bytes = $file.Length; PinnedRsaPssSignatureVerified = $true; SignedIdentityVerified = $true
    FullPublicDownloadVerified = $true; MacAssetPreserved = $true; PreservedMac = $newMac[0]
    TagUnchanged = $true; TagCommit = $newTag.object.sha; Prerelease = $true
    WindowsPublisherSigned = $false; ProductionInstalled = $false; FullRealOtaAccepted = $false
}
$verification | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $directory 'public-verification.json') -Encoding utf8
$verification | Select-Object SourceCommit,BuildSequence,ReleaseId,Sha256,Bytes,MacAssetPreserved,TagUnchanged | ConvertTo-Json
