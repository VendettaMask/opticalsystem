$ErrorActionPreference = 'Stop'
$root = (Get-Location).Path
$raw = $PSScriptRoot
function Hash([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Relative([string]$Path) { [IO.Path]::GetRelativePath($root,$Path).Replace('\','/') }
$public = Get-Content -Raw (Join-Path $raw 'public-verification.json') | ConvertFrom-Json
if (-not $public.FullPublicDownloadVerified -or -not $public.PinnedRsaPssSignatureVerified -or -not $public.MacAssetPreserved) { throw 'Public verification is incomplete.' }
$tally = Get-Content -Raw (Join-Path $raw 'test-tally.json') | ConvertFrom-Json
if ($tally.UniquePassed -ne 304 -or $tally.UniqueFailed -ne 0 -or $tally.UniqueSkipped -ne 1) { throw 'Unexpected cloud tests.' }
$package = Get-Content -Raw (Join-Path $raw 'cloud-checks/cloud-package-verification/summary.json') | ConvertFrom-Json
$native = Get-Content -Raw (Join-Path $raw 'cloud-checks/cloud-package-verification/native-product.json') | ConvertFrom-Json
$frozen = Get-Content -Raw (Join-Path $raw 'cloud-checks/cloud-verification/frozen.json') | ConvertFrom-Json
$docs = Get-Content -Raw (Join-Path $raw 'cloud-checks/cloud-verification/documentation.json') | ConvertFrom-Json
if ($package.Passed -ne 14 -or $package.Failed -ne 0 -or -not $native.Success -or -not $frozen.unchanged -or
    $frozen.matched -ne 2668 -or $docs.SourceDirty -or $docs.BrokenLinks.Count -ne 0) { throw 'Cloud acceptance records failed.' }
$sources = @('.github/workflows/release.yml','packaging/windows/RELEASE_NOTES.md',
    'scripts/publish-github-exe.ps1','scripts/build-installer.ps1',
    'src/OpticalSystemDesign.App/Services/Updates/WindowsOtaHandoff.cs',
    'src/OpticalSystemDesign.App/Services/Updates/OtaHelperRuntime.cs',
    'src/OpticalSystemDesign.App/Assets/Updates/ota-public-key.pem',
    'tests/OpticalSystemDesign.Tests/CloudReleaseTests.cs','tests/OpticalSystemDesign.Tests/OtaHelperRuntimeTests.cs')
$archivePath = Join-Path $root 'validation/rechecks/2026-10-24/ota-cloud-release-evidence.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Frozen cloud evidence already exists.' }
$files = @(Get-ChildItem -LiteralPath $raw -Recurse -File | Where-Object { $_.Extension -notin @('.exe','.dll','.pdb','.zip') })
$files += @($sources | ForEach-Object { Get-Item -LiteralPath (Join-Path $root $_) })
$files = @($files | Sort-Object FullName -Unique)
$manifest = @($files | ForEach-Object { @{ Path = Relative $_.FullName; Bytes = $_.Length; Sha256 = Hash $_.FullName } })
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try { foreach ($file in $files) { [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$file.FullName,(Relative $file.FullName),[IO.Compression.CompressionLevel]::Optimal) | Out-Null } }
finally { $zip.Dispose() }
$zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    if ($zip.Entries.Count -ne $manifest.Count) { throw 'Cloud evidence count differs.' }
    foreach ($row in $manifest) {
        $entry = $zip.GetEntry($row.Path)
        if ($null -eq $entry -or $entry.Length -ne $row.Bytes) { throw 'Cloud evidence length differs.' }
        $stream = $entry.Open(); $sha = [Security.Cryptography.SHA256]::Create()
        try { $actual = [Convert]::ToHexString($sha.ComputeHash($stream)).ToLowerInvariant() }
        finally { $stream.Dispose(); $sha.Dispose() }
        if ($actual -cne $row.Sha256) { throw 'Cloud evidence readback differs.' }
    }
} finally { $zip.Dispose() }
$archiveHash = Hash $archivePath
@{ ArchiveSha256 = $archiveHash; Files = $manifest } | ConvertTo-Json -Depth 6 |
    Set-Content -LiteralPath ($archivePath + '.manifest.json') -Encoding utf8
$report = [ordered]@{
    Date = '2026-10-24'; SourceCommit = $public.SourceCommit; SourceDirty = $docs.SourceDirty
    WorkflowRun = $public.RunId; WorkflowUrl = $public.Workflow; WorkflowConclusion = 'success'
    CloudHostedBuild = $true; Scope = 'Windows x64 OTA handoff repair and all committed product code through e6631b79; Mac package preserved.'
    Build = @{ CompleteReleaseSolution = 'passed, 0 warnings, 0 errors'; Runtime = $native.Framework; Architecture = $native.Architecture }
    LocalReleaseRules = @{ Passed = 26; Failed = 0; TrxSha256 = Hash (Join-Path $raw 'tests/cloud-gates.trx') }
    CloudTests = $tally
    PackageVerification = $package
    Modules = @{ InProcess = $native.ModulesInProcess; Modules = $native.Modules; Libraries = $native.ModuleLibraries; UserDataWritten = $native.UserDataWritten }
    FrozenEvidence = @{ Matched = $frozen.matched; Count = $frozen.count; Unchanged = $frozen.unchanged; AggregateSha256 = $frozen.actualAggregateSha256 }
    Documentation = @{ Documents = $docs.Documents; BrokenLinks = $docs.BrokenLinks.Count; SourceCommit = $docs.SourceCommit; SourceDirty = $docs.SourceDirty }
    Published = $public
    LocalRepairStage = 'docs/validation/OTA_HANDOFF_REPAIR_2026-10-24.json'
    OldAttachmentBackup = @{ ActionsArtifact = 'cloud-release-receipt'; Metadata = 'artifacts/validation/ota-cloud-release-20261024/artifacts-final.json'; RetentionDays = 30; DownloadedLocally = $false }
    Sources = @($sources | ForEach-Object { @{ Path = $_; Sha256 = Hash (Join-Path $root $_) } })
    Evidence = @{ Archive = Relative $archivePath; Sha256 = $archiveHash; Files = $manifest.Count; ReadbackVerified = $true; PublicInstallerIncluded = $false }
    Boundaries = @('No production installation modified', 'Existing broken clients need a one-time normal-exit/manual bootstrap install',
        'No Windows Authenticode publisher certificate', 'No real end-to-end signed OTA installation/restart acceptance',
        'No ARM64 or Mac rebuild in this run', 'No full repository test suite or renewed optical certification')
}
$report | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath (Join-Path $root 'docs/validation/OTA_CLOUD_RELEASE_2026-10-24.json') -Encoding utf8
Write-Output "Cloud report recorded: $($tally.UniquePassed) unique passes, 1 skipped, $($manifest.Count) verified archive files."
