---
title: Group Delay / GDD
description: Spectral phase and its derivatives for chirped mirrors and ultrafast coatings.
ribbonIcon: gd-gdd
---

The GD/GDD window computes the spectral phase of a coating and its derivatives
with respect to angular frequency: group delay (GD), group-delay dispersion
(GDD), and third-order dispersion (TOD). These quantities describe how a
coating delays different parts of an optical pulse. The same group-delay
dispersion is also available against wavelength, as the chromatic dispersion
coefficient (CDC) used in telecommunications.

The phase comes from the complex reflection or transmission coefficient:

```
φ(ω) = arg(r)  or  arg(t)
GD  = -dφ/dω       [fs]
GDD = -d²φ/dω²     [fs²]
TOD = -d³φ/dω³     [fs³]
CDC = GDD·2πc/λ²     [fs/nm]
```

CDC carries no information GDD does not: it is the same number per nm of
wavelength rather than per rad/fs. Fibre data sheets quote the equivalent per
kilometre of fibre, in ps/(nm·km); a coating has no length, so the unit here
is fs/nm.

## Settings

**Quantity**: phase φ, GD, GDD, CDC, or TOD.

**Reflection / Transmission**: take the phase from the reflected or transmitted
complex amplitude.

**Polarization**: the average of s and p, s, or p. The average uses the same
per-polarization arithmetic mean as the matching merit operand.

**Side**: evaluate the **front** coating or the **back** coating.

**Wavelength range**: the span plotted and exported, in nm. TFStudio chooses the
sampling automatically and adds local samples around pronounced reflection or
transmission minima. There is no derivative or sampling step to tune.

**AOI**: angle of incidence in degrees, measured in the incident medium.

**Reference wavelength**: shifts the displayed phase to zero at the selected
wavelength. This constant offset does not change GD, GDD, CDC, or TOD.

**Targets**: shows enabled GD, GDD, or TOD merit-function targets that match
the selected reflection or transmission response, polarization, and AOI.
Point operands appear as X markers. Flatness operands show their target level
and wavelength band. Phase targets are not overlaid because the displayed
phase may have an arbitrary reference offset, and CDC has no operand of its
own, since the same requirement is written as a GDD target. Current
phase-dispersion merit operands evaluate the front coating normally and the
back coating for a back-only design, so their overlays appear only on the side
they score.

**Edit**: build targets on the plot instead of typing them into the
[Merit Function Editor](/design/merit-function-editor/). Click to add a target
at one wavelength; drag across a band to add a flatness target at the level you
release on. Drag a target line or either of its ends to move it, or switch to
the delete tool and click a line to remove it. A drawn target takes the
quantity, response, polarization and angle the window is showing, so there is
nothing else to choose. Endpoints snap to a wavelength grid, to a level grid
taken from the visible range and shown beside the wavelength step, and to the
ends of existing targets. Phase has no editor, for the same reason it has no
overlay, and the button is disabled on the side the merit function does not
score.

## How the values are calculated

GD, GDD, and TOD are evaluated point by point through third-order Taylor
arithmetic in the characteristic matrix, and CDC is converted from GDD at the
same wavelength. The derivatives come from the complex
logarithmic derivative of `r` or `t`; phase unwrapping is used only to draw the
phase curve. TFStudio uses `n + ik` with an `exp(-iωt)` time factor, then applies
the conjugate-Macleod convention once so a material transit time is positive,
with the same sign as the Material Dispersion window.

Formula materials are differentiated exactly. A tabulated material gives the
exact derivative of its shape-preserving PCHIP curve, or of the straight line
between two points when the material carries the linear rule that Essential
Macleod and TFCalc read tables with. PCHIP is C1: GD is continuous, while higher
derivatives can show finite steps at table knots and TOD is especially sensitive
to how sparse data is represented. A linear table is C0, so GD steps there as
well. For coating reflection and transmission, both tabulated `n` and `k`
contribute to this continuity limit.

Exactly on a knot two pieces of the table meet, and a derivative that steps there
has no single value. The window reports the mean of the two sides. That is the
limit of the symmetric difference quotient, and it is the number Essential
Macleod gives at the same wavelength. Every knot inside the plotted range gets a
sample of its own, and the curve is drawn through both of its one-sided values,
so a jump appears as the step it is rather than a gap. The curve is never cut at
a knot; a gap means the opposite, that the wavelength has no value at all.
Fitting a smooth dispersion model to a material removes its knots, and a saved
fit replaces the table only inside its stated validity range and is named in the
model list. Where a table is fine enough that its knots crowd the plotted
samples, they are left out and the curve is drawn from those samples alone.

Outside a material's data range the curve is still drawn, over a shaded band
naming the material and the range it does cover. A table holds the value in its
last row out there, so its index has no slope and that material adds no
dispersion in the band: what is left of the curve is the geometry of the stack.
A formula is extrapolated past the band it was fitted over and keeps dispersing.
The results table marks those rows with the material, so an exported number is
never silently an extrapolation, and the notice offers to narrow the plotted
range to the span every material covers.

## How to read it

For a chirped mirror, GD should follow the target ramp across the band and GDD
should hold the intended value used for pulse compensation. A narrow positive
or negative GD feature beside a reflection zero is expected phase behavior.
Read it with the coefficient magnitude: little reflected energy occupies a
deep reflectance minimum, although the same feature can matter when the coating
is used in transmission.

The data table lists phase and all three derivatives against wavelength for
export. A knot wavelength is written as two rows, λ− and λ+, carrying the value
on each side of it, so a number taken from the table is never a midpoint without
saying so.

## References

- H. A. Macleod, *Thin-Film Optical Filters*, 5th ed., Ch. 11, Eq. 11.17.
- J. Birge and F. X. Kärtner, "Efficient analytic computation of higher-order dispersion from optical interferometers," *Applied Optics* **45**, 1478-1483 (2006), [doi:10.1364/AO.45.001478](https://doi.org/10.1364/AO.45.001478).
- S. Diddams and J.-C. Diels, *Journal of the Optical Society of America B* **13**, 1120 (1996).
