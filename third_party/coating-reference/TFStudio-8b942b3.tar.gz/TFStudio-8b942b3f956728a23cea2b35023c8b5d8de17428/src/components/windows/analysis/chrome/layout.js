/**
 * The frame an analysis window is assembled in.
 *
 * The plot is what the window is for, so it gets the height. Everything else
 * fits in two thin bands: one control row above the plot, and the collapsed
 * Results strip below it. Two of these windows docked side by side on a laptop
 * screen still show plots worth looking at.
 *
 * What goes where:
 *
 *   control row  the switches that change which curve is drawn — T/R/A, the
 *                quantity, the polarization — plus the notice badge and the
 *                Setup button at the right-hand end.
 *   Setup panel  everything else: ranges, steps, angle of incidence, side,
 *                reference wavelength. See `chrome/popover.js`.
 *   editor strip the per-interface and per-material tables the tolerance
 *                windows are built around. A popover cannot hold a hundred
 *                rows, so these get a strip of their own above the results,
 *                the full width of the window. See `EditorBody` below.
 *   Results      the numbers behind the plot, collapsed by default, with the
 *                export control on its right.
 *
 * There is no status footer. The design's name, layer count and media are the
 * same in every analysis window and are already in the Design Editor; repeating
 * them in each window cost more height than they were worth.
 */

const { createElement: h } = React;

const FONT = 'system-ui, -apple-system, sans-serif';

/** Outermost element of a window: fills the dock and never scrolls itself. */
export function AnalysisWindow({ c, row = false, children }) {
    return h('div', {
        style: {
            display: 'flex', flexDirection: row ? 'row' : 'column',
            width: '100%', height: '100%', overflow: 'hidden',
            backgroundColor: c.bg, color: c.text,
            fontFamily: FONT, fontSize: 12,
        },
    }, children);
}

/**
 * The window's one row of controls. Wraps rather than clips when the window is
 * narrow, and holds its height when the plot is squeezed.
 *
 * Put the curve switches in `children`; pass the notice badge and Setup button
 * as `trailing`, which is pushed to the right-hand end.
 *
 * `footer` puts the same row under the plot instead of over it, for a window
 * whose controls drive a position in the plot rather than what it draws.
 */
export function ControlRow({ c, children, trailing, footer = false, ...rest }) {
    return h('div', {
        ...rest,
        style: {
            display: 'flex', flexWrap: 'wrap', alignItems: 'center',
            gap: 8, rowGap: 5, padding: '5px 10px',
            backgroundColor: c.panel, flexShrink: 0,
            [footer ? 'borderTop' : 'borderBottom']: `1px solid ${c.border}`,
        },
    },
        children,
        trailing && h('div', {
            style: {
                marginLeft: 'auto', display: 'flex', alignItems: 'center',
                gap: 6, flexShrink: 0,
            },
        }, trailing),
    );
}

/**
 * A second row that belongs to a mode rather than to the window, such as the
 * target editor. Only ever rendered while that mode is on.
 */
export function ModeRow({ c, children, ...rest }) {
    return h('div', {
        ...rest,
        style: {
            display: 'flex', flexWrap: 'wrap', alignItems: 'center',
            gap: 8, rowGap: 6, padding: '5px 10px',
            borderBottom: `1px solid ${c.border}`,
            backgroundColor: c.bg, flexShrink: 0,
        },
    }, children);
}

/**
 * Progress of a run that takes seconds to minutes: a hairline under the control
 * row while it is going, and nothing at all once it is done.
 *
 *   progress  { i, total }
 */
export function ProgressHairline({ c, progress }) {
    return h('div', { style: { height: 3, background: c.border, flexShrink: 0 } },
        h('div', {
            style: {
                height: '100%', background: c.accent,
                width: progress.total ? `${100 * progress.i / progress.total}%` : '0%',
                transition: 'width 100ms linear',
            },
        }),
    );
}

/** The plot itself: takes the space left over and clips rather than scrolls. */
export function PlotArea({ children, relative = false }) {
    return h('div', {
        style: {
            flex: 1, minHeight: 0, minWidth: 0, overflow: 'hidden',
            display: 'flex', flexDirection: 'column',
            position: relative ? 'relative' : undefined,
        },
    }, children);
}

/** Stands in for the plot when there is nothing to draw. */
export function CenteredMessage({ c, message }) {
    return h('div', {
        style: {
            flex: 1, minHeight: 0, display: 'flex',
            alignItems: 'center', justifyContent: 'center',
            color: c.textDim, fontSize: 13, fontFamily: FONT,
            padding: 16, textAlign: 'center',
        },
    }, message);
}

/**
 * Body of an editor strip: the per-interface and per-material tables the
 * tolerance windows are built around.
 *
 * These are data entry, not settings, and there is one row per interface — a
 * hundred-layer stack means a hundred rows. They get the window's full width
 * and grow to `maxHeight` before scrolling, so a two-interface design costs
 * almost nothing and a hundred-interface one still leaves the plot on screen.
 */
export function EditorBody({ c, maxHeight = 240, children }) {
    return h('div', {
        style: {
            maxHeight, overflowY: 'auto', overflowX: 'hidden',
            padding: '4px 12px 10px', backgroundColor: c.bg, flexShrink: 0,
            fontFamily: FONT, fontSize: 12,
        },
    }, children);
}

/**
 * Scalar fields laid across the width available rather than down one column.
 * A strip is as wide as the window, so four fields fit on one line where a
 * popover would have stacked them four deep.
 */
export function FieldGrid({ minWidth = 250, children }) {
    return h('div', {
        style: {
            display: 'grid', columnGap: 18,
            gridTemplateColumns: `repeat(auto-fill, minmax(${minWidth}px, 1fr))`,
        },
    }, children);
}

/** Heading over a group inside an editor strip. */
export function EditorGroupTitle({ c, children }) {
    return h('div', {
        style: {
            fontSize: 10, fontWeight: 700, color: c.textDim,
            textTransform: 'uppercase', letterSpacing: '0.06em',
            userSelect: 'none', padding: '8px 0 2px',
        },
    }, children);
}

/** Persistent column of settings beside the plot. */
export function SidePanel({ c, width = 260, children }) {
    return h('div', {
        style: {
            width, flexShrink: 0, borderRight: `1px solid ${c.border}`,
            backgroundColor: c.panel, overflowY: 'auto',
            display: 'flex', flexDirection: 'column',
            fontFamily: FONT,
        },
    }, children);
}

/** Heading over a group of controls inside a `SidePanel`. */
export function SectionTitle({ c, children }) {
    return h('div', {
        style: {
            fontSize: 10, fontWeight: 700, color: c.textDim,
            textTransform: 'uppercase', letterSpacing: '0.06em',
            userSelect: 'none', padding: '10px 10px 4px',
        },
    }, children);
}

/** Explanatory text at the foot of a `SidePanel`. */
export function SidePanelNote({ c, children }) {
    return h('div', {
        style: {
            padding: '8px 10px', marginTop: 'auto', fontSize: 10,
            color: c.textDim, lineHeight: 1.5,
            borderTop: `1px solid ${c.border}`,
        },
    }, children);
}
