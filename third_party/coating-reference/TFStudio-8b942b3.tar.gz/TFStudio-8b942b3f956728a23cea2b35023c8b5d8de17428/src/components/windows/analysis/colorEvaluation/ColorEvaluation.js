/**
 * Color Evaluation — CIE color of the coating's reflectance / transmittance.
 *
 * The chromaticity diagram carries the window; the sample and reference-white
 * swatches sit on it, and the colorimetric coordinates are in the results strip.
 * The colorimetry itself is in colorModel.js.
 */

import { useDesign } from '../../../../state/DesignContext.js';
import { COLOR_RANGE_NM, xyzToSRGB } from '../../../../utils/physics/colorimetry.js';
import { makeConeSpec, coneIsActive } from '../../../../utils/physics/optimizer.js';
import { useMaterialRangeNotice } from '../../../materials/MaterialRangeNotice.js';
import { ConeBadge, EvalModeBadge } from '../../../SurfaceModeBar.js';
import { ExportMenu, useCsvExport } from '../../../ui/ExportMenu.js';
import { csvFromRows, ResultsGrid, ResultsSection } from '../../../ui/ResultsSection.js';
import { AnalysisWindow, CenteredMessage, PlotArea } from '../chrome/layout.js';
import { ChromaticityChart } from './chartFigure.js';
import { ColorControls } from './ColorControls.js';
import {
    computeColorReport, formatValue, readoutColumns, readoutTableRows,
} from './colorModel.js';
import { colorEvaluationSession } from './sessionState.js';
import { useWindowSession } from '../../windowSession.js';
import { useAnalysisEvaluation } from '../useAnalysisEvaluation.js';

const { createElement: h, useState, useEffect, useMemo } = React;

function Swatch({ color, label, sub, c }) {
    return h('div', {
        style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 },
    },
        h('div', {
            style: {
                width: 44, height: 44, borderRadius: 5, background: color,
                border: `1px solid ${c.border}`,
                boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.06)',
            },
        }),
        h('div', { style: { fontSize: 9, color: c.text, fontWeight: 600 } }, label),
        sub && h('div', { style: { fontSize: 8, color: c.textDim } }, sub),
    );
}

/** The colour readout sits in the diagram's naturally empty upper-right region. */
function Swatches({ report, sampleRgb, state, ce, c }) {
    const exposureNote = state.exposure === 'fit' ? ce.expFit : `×${state.exposure}`;
    return h('div', {
        style: {
            position: 'absolute', right: 12, top: 72, zIndex: 2,
            display: 'flex', gap: 8, padding: 6,
            background: c.panel + 'dd', border: `1px solid ${c.border}`, borderRadius: 5,
            pointerEvents: 'none',
        },
    },
        h(Swatch, {
            c, color: sampleRgb,
            label: state.characteristic === 'T' ? ce.swatchT : ce.swatchR,
            sub: state.exposure === '1'
                ? `Y = ${formatValue(report.XYZ.Y, 2)}`
                : `Y = ${formatValue(report.XYZ.Y, 2)} · ${exposureNote}`,
        }),
        h(Swatch, { c, color: 'rgb(255,255,255)', label: ce.refWhite, sub: state.illuminant }),
    );
}

function useColorState(design) {
    const [session, setField] = useWindowSession(colorEvaluationSession, design);
    return {
        ...session,
        setCharacteristic: value => setField('characteristic', value),
        setPol: value => setField('pol', value),
        setTheta: value => setField('theta', value),
        setObserver: value => setField('observer', value),
        setIllum: value => setField('illuminant', value),
        setStep: value => setField('step', value),
        setExposure: value => setField('exposure', value),
        setShowTable: value => setField('showTable', value),
    };
}

export function ColorEvaluation({ c, theme, t }) {
    const { design, evalMode } = useDesign();
    const ce = t.colorEval;
    const dt = t.dataTable;
    const state = useColorState(design);
    const [error, setError] = useState(null);

    useEffect(() => { setError(null); }, [evalMode]);

    const coneActive = coneIsActive(makeConeSpec(design?.cone || {}));
    const workerOptions = useMemo(() => ({
        evalMode,
        characteristic: state.characteristic, pol: state.pol, theta: state.theta,
        observer: state.observer, illuminant: state.illuminant, step: state.step,
    }), [evalMode, state.characteristic, state.pol, state.theta,
        state.observer, state.illuminant, state.step]);
    const workerPayload = useMemo(
        () => ({ design, options: workerOptions }),
        [design, workerOptions],
    );
    const workerResult = useAnalysisEvaluation(coneActive, 'colorReport', workerPayload);
    const directReport = useMemo(
        () => coneActive ? null : computeColorReport({
            design, evalMode, setError,
            characteristic: state.characteristic, pol: state.pol, theta: state.theta,
            observer: state.observer, illuminant: state.illuminant, step: state.step,
        }),
        [coneActive, design, evalMode, state.characteristic, state.pol, state.theta,
         state.observer, state.illuminant, state.step]);
    const report = coneActive ? workerResult.data : directReport;

    const columns = readoutColumns(ce);
    const rows = readoutTableRows(report, ce);
    const rangeNotice = useMaterialRangeNotice(design, COLOR_RANGE_NM[0], COLOR_RANGE_NM[1], t);
    const csv = useCsvExport(
        () => csvFromRows(columns, rows),
        () => `${(design?.name || 'design').replace(/[^\w.-]+/g, '_')}_color.csv`,
    );

    // Exposure only rescales the on-screen swatch; the colorimetric report and
    // its readout are unchanged. '1' reuses the report's reference-white swatch.
    const sampleRgb = report && (state.exposure === '1'
        ? report.rgb
        : xyzToSRGB(report.XYZ, report.white,
            state.exposure === 'fit' ? { fit: true } : { gain: Number(state.exposure) }));

    const notices = [
        (coneActive ? workerResult.error : error) && {
            label: coneActive ? t.analysisEvaluation.failed : error,
            tone: 'error',
        },
        rangeNotice,
    ].filter(Boolean);

    return h(AnalysisWindow, { c },
        h(ColorControls, { c, t, ce, state, notices }),
        h(PlotArea, { relative: true },
            coneActive && workerResult.busy
                ? h(CenteredMessage, { c, message: t.analysisEvaluation.computing })
                : report
                ? h(React.Fragment, null,
                    h(ChromaticityChart, { report, observer: state.observer, c, theme, tr: ce }),
                    h(Swatches, { report, sampleRgb, state, ce, c }))
                : h(CenteredMessage, { c, message: ce.noData }),
        ),
        h(ResultsSection, {
            c, label: dt.results, count: rows.length, countLabel: dt.rowCount,
            open: state.showTable, setOpen: state.setShowTable,
            actions: h('div', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
                h(EvalModeBadge, { design, c, t }),
                h(ConeBadge, { design, c, t }),
                h(ExportMenu, {
                    c, enabled: rows.length > 0, ...csv,
                    labels: {
                        export: dt.export, copyCsv: dt.copyCsv, saveCsv: dt.saveCsv,
                        copied: dt.csvCopied, saved: dt.csvSaved,
                    },
                }),
            ),
        }, h(ResultsGrid, { columns, rows, c })),
    );
}
