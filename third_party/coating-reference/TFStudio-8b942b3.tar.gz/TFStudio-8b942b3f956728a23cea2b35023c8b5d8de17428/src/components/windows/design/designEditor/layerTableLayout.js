/**
 * Shared column geometry for the Design Editor header and layer rows. `tr` and
 * `tipTr` key into t.layerThicknesses, which already names these four columns
 * for the Layer Thicknesses window. OT, QW and FW are the standard thin-film
 * abbreviations and stay as written.
 */
export const LAYER_THICKNESS_COLUMNS = Object.freeze([
    { unit: 'nm', tr: 'colPhysical', tipTr: 'unitNmTip', primary: true },
    { unit: 'OT', label: 'OT', tipTr: 'unitOtTip' },
    { unit: 'QWOT', label: 'QW', tipTr: 'unitQwotTip' },
    { unit: 'FWOT', label: 'FW', tipTr: 'unitFwotTip' },
]);

/** Header text and tooltip for a thickness column. `lt` is t.layerThicknesses. */
export const thicknessColumnText = (column, lt) =>
    ({ label: column.label || lt[column.tr], title: lt[column.tipTr] });

export const LAYER_TABLE = Object.freeze({
    gap: 2,
    scrollInset: 4,
    numberWidth: 32, // compact drag handle plus a three-digit layer index
    materialMinWidth: 92,
    materialTextInset: 22, // picker padding + color swatch + spacing
    numericTextInset: 4,
    // Sized from the primary d (nm) column, which renders at 12 px semibold while
    // OT/QW/FW render at 11 px regular: eight characters need 50 px of text there,
    // plus the inset either side and the cell border. That shows any thickness up
    // to 99999.99 nm, and any QW/FW value up to 1000.0255, in full. Above that the
    // cell falls back to its ellipsis and tooltip rather than widening the table
    // for values the 1 mm entry guard exists to prevent.
    thicknessWidth: 60,
    lockWidth: 22,
    moveWidth: 36, // up and down arrows side by side, 18 px each
    actionsWidth: 24,
});

const TRACK_COUNT = 9; // number, material, four thicknesses, lock, move, delete
const ROW_INSET = 10; // 4 px row padding and a 2 px selection border

export const LAYER_TABLE_MIN_WIDTH = ROW_INSET
    + LAYER_TABLE.numberWidth
    + LAYER_TABLE.materialMinWidth
    + LAYER_THICKNESS_COLUMNS.length * LAYER_TABLE.thicknessWidth
    + LAYER_TABLE.lockWidth
    + LAYER_TABLE.moveWidth
    + LAYER_TABLE.actionsWidth
    + (TRACK_COUNT - 1) * LAYER_TABLE.gap;

export function fixedLayerTrack(width, extra = {}) {
    return { width, flexShrink: 0, ...extra };
}

export function materialLayerTrack(extra = {}) {
    return {
        flex: `1 0 ${LAYER_TABLE.materialMinWidth}px`,
        minWidth: LAYER_TABLE.materialMinWidth,
        overflow: 'hidden',
        ...extra,
    };
}

export function shiftedThicknessUnit(unit, delta) {
    const index = Math.max(0, LAYER_THICKNESS_COLUMNS.findIndex(column => column.unit === unit));
    const next = Math.max(0, Math.min(LAYER_THICKNESS_COLUMNS.length - 1, index + delta));
    return LAYER_THICKNESS_COLUMNS[next].unit;
}

/** Excel-style destination after committing a thickness cell. */
export function nextThicknessCell(rows, rowId, unit, direction) {
    const rowIndex = rows.findIndex(row => row.id === rowId);
    const unitIndex = LAYER_THICKNESS_COLUMNS.findIndex(column => column.unit === unit);
    if (rowIndex < 0 || unitIndex < 0) return null;

    let nextRow = rowIndex;
    let nextUnit = unitIndex;
    if (direction === 'up') nextRow--;
    else if (direction === 'down') nextRow++;
    else if (direction === 'left') {
        nextUnit--;
        if (nextUnit < 0) { nextUnit = LAYER_THICKNESS_COLUMNS.length - 1; nextRow--; }
    } else if (direction === 'right') {
        nextUnit++;
        if (nextUnit >= LAYER_THICKNESS_COLUMNS.length) { nextUnit = 0; nextRow++; }
    }

    if (nextRow < 0 || nextRow >= rows.length) return null;
    return { rowId: rows[nextRow].id, unit: LAYER_THICKNESS_COLUMNS[nextUnit].unit };
}
