/**
 * Warning shown when an analysis window evaluates outside the declared data
 * range of a material the design uses.
 *
 * Deliberately non-blocking, unlike MissingMaterialsNotice: an out-of-range
 * wavelength still produces a result, it just produces one from a clamped or
 * extrapolated optical constant. Gating the window would hide a spectrum the
 * user may well want to see; the banner says what part of it to distrust.
 */
import {
    clampLambdaToCovered, clampToCovered, designRangeCoverage, materialsRangeCoverage,
} from '../../utils/materials/materialRange.js';
import { operandWavelengthSpan } from '../../utils/physics/optimizer.js';

const { createElement: h, useMemo } = React;

const format = (value) => (Math.round(value * 10) / 10).toString();

/**
 * One line per material that falls short, naming the range it does cover and,
 * where the material is tabulated, that it is held flat outside it.
 *
 * The two kinds of outside behave differently and only one of them is a real
 * extrapolation. A table held at its end value has no slope from the first
 * wavelength past its last row, so it contributes nothing to a group delay or a
 * dispersion out there; a formula carries on smoothly past the band it was
 * fitted over. Which one a reader is looking at decides what the curve in the
 * shaded band means.
 */
function offenderLines(offenders, t) {
    return offenders.map(({ id, name, rangeNm, heldFlat }) => {
        const line = heldFlat ? t.materialRange.materialLineHeld : t.materialRange.materialLine;
        return line(name || id, format(rangeNm[0]), format(rangeNm[1]));
    });
}

function OffenderList({ offenders, c, t }) {
    const lines = offenderLines(offenders, t);
    return h('div', {
        style: {
            color: c.textDim, fontSize: 11, lineHeight: 1.4,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        },
        title: lines.join('\n'),
    }, lines.join('   '));
}

export function MaterialRangeBanner({ offenders, evaluated, c, t }) {
    if (!offenders?.length) return null;
    const accent = c.warning || c.error;
    return h('div', {
        role: 'alert',
        'data-material-range': 'warning',
        style: {
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '6px 10px', flexShrink: 0,
            borderBottom: `1px solid ${accent}`,
            backgroundColor: accent + '14', color: c.text,
            fontFamily: 'system-ui, -apple-system, sans-serif',
        },
    },
        h('span', { style: { color: accent, fontSize: 15, flexShrink: 0 } }, '⚠'),
        h('div', { style: { flex: 1, minWidth: 0 } },
            h('div', { style: { fontSize: 12, fontWeight: 600 } },
                t.materialRange.banner(offenders.length,
                    format(evaluated[0]), format(evaluated[1]))),
            h(OffenderList, { offenders, c, t })),
    );
}

/**
 * The banner for one window, wired to the design. Renders nothing when every
 * material covers the range, or when no material declares one.
 *
 * @param {number} fromNm start of the evaluated range, in nm
 * @param {number} toNm   end of the evaluated range, in nm
 */
export function MaterialRangeWarning({ design, fromNm, toNm, c, t }) {
    const { offenders } = useMemo(
        () => designRangeCoverage(design, [fromNm, toNm]),
        [design, fromNm, toNm],
    );
    return h(MaterialRangeBanner, { offenders, evaluated: [fromNm, toNm], c, t });
}

function offenderDetail(offenders, t) {
    return offenderLines(offenders, t).join('\n');
}

/**
 * The same warning as one entry for an analysis window's notice badge, for
 * windows that give their height to the plot and carry no banner. Null when
 * every material covers the evaluated range.
 *
 * `onFix`, when given, receives a `[fromNm, toNm]` range every material covers
 * and puts the notice's fix button on the badge. Windows whose evaluated range
 * the user can edit pass their range setter; the button disappears with the
 * warning once the range is applied.
 *
 * @returns {{ label: string, detail: string,
 *             action?: { label: string, onClick: () => void } } | null}
 */
export function useMaterialRangeNotice(design, fromNm, toNm, t, onFix) {
    const coverage = useMemo(
        () => designRangeCoverage(design, [fromNm, toNm]),
        [design, fromNm, toNm],
    );
    return useCoverageNotice(coverage, fromNm, toNm, t, onFix);
}

/**
 * The same notice for a window that computes with a stack other than the
 * design's own. `materials` is `[{ id, material }]`, every material the window
 * evaluates, memoized by the caller.
 */
export function useMaterialsRangeNotice(materials, fromNm, toNm, t, onFix) {
    const coverage = useMemo(
        () => materialsRangeCoverage(materials, [fromNm, toNm]),
        [materials, fromNm, toNm],
    );
    return useCoverageNotice(coverage, fromNm, toNm, t, onFix);
}

function useCoverageNotice({ offenders, covered }, fromNm, toNm, t, onFix) {
    return useMemo(() => {
        if (!offenders.length) return null;
        const fixed = onFix ? clampToCovered(covered, [fromNm, toNm]) : null;
        return {
            label: t.materialRange.banner(offenders.length, format(fromNm), format(toNm)),
            detail: offenderDetail(offenders, t),
            ...(fixed ? {
                action: {
                    label: t.materialRange.fixAction(format(fixed[0]), format(fixed[1])),
                    onClick: () => onFix(fixed),
                },
            } : {}),
        };
    }, [offenders, covered, fromNm, toNm, t, onFix]);
}

/**
 * The same warning for an optimizer window. There is no plot axis to check, so
 * the evaluated range is the span of every wavelength the enabled merit
 * operands sample, which is what a run scores the design on. Null when the
 * merit function holds no spectral operand, or when every material covers that
 * span.
 *
 * No fix action: the span is not a setting of the window but the targets
 * themselves, and narrowing those is a design decision.
 *
 * @returns {{ label: string, detail: string } | null}
 */
export function useMeritRangeNotice(design, t) {
    const operands = design?.meritOperands;
    const span = useMemo(() => operandWavelengthSpan(operands || []), [operands]);
    const { offenders } = useMemo(() => designRangeCoverage(design, span), [design, span]);
    return useMemo(() => {
        if (!span || !offenders.length) return null;
        return {
            label: t.materialRange.targets(offenders.length, format(span[0]), format(span[1])),
            detail: offenderDetail(offenders, t),
        };
    }, [span, offenders, t]);
}

/**
 * The same warning for a window that evaluates at a single wavelength.
 *
 * There is no range to pull in, so `onFix` is offered a wavelength every
 * material has data for instead: the nearest covered one to where the window is
 * now. Windows whose wavelength the user can set pass their setter.
 *
 * @returns {{ label: string, detail: string,
 *             action?: { label: string, onClick: () => void } } | null}
 */
export function useMaterialLambdaNotice(design, lambdaNm, t, onFix) {
    const { offenders, covered } = useMemo(
        () => designRangeCoverage(design, [lambdaNm, lambdaNm]),
        [design, lambdaNm],
    );
    return useMemo(() => {
        if (!offenders.length) return null;
        const fixed = onFix ? clampLambdaToCovered(covered, lambdaNm) : null;
        return {
            label: t.materialRange.banner(offenders.length, format(lambdaNm), format(lambdaNm)),
            detail: offenderDetail(offenders, t),
            ...(fixed != null ? {
                action: {
                    label: t.materialRange.fixLambda(format(fixed)),
                    onClick: () => onFix(fixed),
                },
            } : {}),
        };
    }, [offenders, covered, lambdaNm, t, onFix]);
}
