/**
 * Group filter tabs for PickerDropdown: the full-list button, then one scrolling
 * row of groups.
 *
 * The row scrolls sideways rather than wrapping. A wrapped strip takes its height
 * out of the result list below it, and a machine with a dozen catalogs grew it to
 * six rows, leaving the list a few entries tall in a 320 px overlay. Sideways
 * scrolling is not discoverable by itself and cannot be reached at all without a
 * wheel, so the arrows appear whenever the row is wider than the space it has.
 */

const { createElement: h, useState, useRef, useEffect, useCallback } = React;

import { attachTabWheelScroll } from '../docking/tabWheel.js';
import { observeResize } from './observeResize.js';

// Fraction of the visible width one arrow click aims to move, leaving a tab or so
// of overlap so nothing is stepped over between one click and the next.
const PAGE = 0.8;

// Width of the soft edge where the row continues past the boundary.
const FADE = 14;

// `current` marks the group the picker's value belongs to while the list is
// unfiltered: an underline, so it is not mistaken for the active filter.
function tabStyle(active, c, current = false) {
    return {
        padding: '1px 7px', fontSize: 11, flexShrink: 0, whiteSpace: 'nowrap',
        border: `1px solid ${active ? c.accent : c.border}`,
        borderRadius: 3,
        backgroundColor: active ? c.accent + '33' : 'transparent',
        color: active || current ? c.accent : c.textDim,
        boxShadow: current && !active ? `inset 0 -2px 0 0 ${c.accent}` : 'none',
        cursor: 'pointer', outline: 'none',
        fontFamily: 'system-ui, -apple-system, sans-serif'
    };
}

// Tabs and arrows are buttons, and a button takes focus when clicked, which
// would end typing in the search box above them. Changing the filter must not.
export function keepSearchFocus(event) {
    event.preventDefault();
}

/** Whether the row overflows, and whether it is scrolled to either end. */
export function stripEdges(strip) {
    const travel = strip.scrollWidth - strip.clientWidth;
    return {
        overflowing: travel > 1,
        atStart: strip.scrollLeft <= 0,
        atEnd: strip.scrollLeft >= travel - 1,
    };
}

// The span of the row that is not under a soft edge. A tab sitting inside the
// fade is faded itself, which reads as a cut-off name rather than as the tab the
// picker is pointing at.
function clearSpan(strip) {
    const travel = strip.scrollWidth - strip.clientWidth;
    return {
        from: strip.scrollLeft + (strip.scrollLeft > 0 ? FADE : 0),
        to: strip.scrollLeft + strip.clientWidth - (strip.scrollLeft < travel - 1 ? FADE : 0),
    };
}

/**
 * Bring a tab into view, centred. The picker marks the group holding the
 * current value, and that group's tab can sit anywhere along the row: off the
 * end, or under one of the fades, where it reads as clipped. Centring puts it
 * where it is read first and shows the groups on either side of it.
 *
 * A tab already clear of both fades is left alone: the strip must not jump
 * under the pointer when a click on a visible tab changes the filter.
 */
export function scrollTabIntoView(strip, tab) {
    if (!strip || !tab) return;
    const travel = strip.scrollWidth - strip.clientWidth;
    if (travel <= 0) return;
    const { from, to } = clearSpan(strip);
    if (tab.offsetLeft >= from && tab.offsetLeft + tab.offsetWidth <= to) return;
    const centred = tab.offsetLeft - (strip.clientWidth - tab.offsetWidth) / 2;
    strip.scrollLeft = Math.max(0, Math.min(centred, travel));
}

/**
 * Where an arrow click leaves the row: about a screenful along, rounded to a tab
 * boundary. The row rests only on boundaries, because a name sliced down the
 * middle by the edge of the strip reads as a truncated catalog name rather than
 * as a row that continues.
 *
 * @param {number[]} starts    left edge of every tab
 * @param {number}   from      current scroll offset
 * @param {number}   viewport  visible width of the row
 * @param {number}   direction -1 back, +1 forward
 */
export function pagedOffset(starts, from, viewport, direction) {
    const target = from + direction * viewport * PAGE;
    const ahead = starts.filter(start => (direction > 0 ? start > from + 1 : start < from - 1));
    if (ahead.length === 0) return from;
    return ahead.reduce((best, start) => Math.abs(start - target) < Math.abs(best - target) ? start : best);
}

// Soft edge wherever the row continues, so the tab the boundary cuts reads as
// more to come. No fade at an end there is nothing beyond.
export function fadeMask({ overflowing, atStart, atEnd }) {
    if (!overflowing) return undefined;
    const stops = [
        atStart ? 'black 0' : `transparent 0, black ${FADE}px`,
        atEnd ? 'black 100%' : `black calc(100% - ${FADE}px), transparent 100%`,
    ];
    return `linear-gradient(to right, ${stops.join(', ')})`;
}

function arrowEl(glyph, disabled, onClick, c) {
    return h('button', {
        onClick: disabled ? undefined : onClick,
        onMouseDown: keepSearchFocus,
        style: {
            flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            width: 14, height: 17, padding: 0, fontSize: 10, lineHeight: 1,
            border: 'none', background: 'transparent',
            color: c.textDim, opacity: disabled ? 0.3 : 1,
            cursor: disabled ? 'default' : 'pointer', outline: 'none',
        }
    }, glyph);
}

export function PickerTabs({ groups, catFilter, setCatFilter, currentGroup = null, allLabel, c }) {
    // The tab brought into view: the filter, or the current group while the
    // list is unfiltered, so an open picker says where its value comes from.
    const markedGroup = catFilter === 'all' ? currentGroup : catFilter;
    const stripRef     = useRef(null);
    const activeTabRef = useRef(null);
    const [edges, setEdges] = useState({ overflowing: false, atStart: true, atEnd: true });

    const measure = useCallback(() => {
        if (stripRef.current) setEdges(stripEdges(stripRef.current));
    }, []);

    // React delegates wheel events through a passive listener, which cannot stop
    // the page scrolling instead. tabWheel attaches a native one.
    useEffect(() => (stripRef.current ? attachTabWheelScroll(stripRef.current) : undefined), []);

    useEffect(() => {
        const strip = stripRef.current;
        if (!strip) return undefined;
        measure();
        const observer = observeResize(strip, measure);
        return () => { if (observer) observer.disconnect(); };
    }, [groups.length, measure]);

    useEffect(() => {
        scrollTabIntoView(stripRef.current, activeTabRef.current);
        measure();
    }, [markedGroup, measure]);

    const page = (direction) => {
        const strip = stripRef.current;
        if (!strip) return;
        const starts = [...strip.children].map(tab => tab.offsetLeft);
        strip.scrollLeft = pagedOffset(starts, strip.scrollLeft, strip.clientWidth, direction);
        measure();
    };

    if (groups.length <= 1) return null;
    return h('div', {
        style: {
            display: 'flex', alignItems: 'center', gap: 2, padding: '3px 6px',
            borderBottom: `1px solid ${c.border}`
        }
    },
        // The full list stays out of the scrolling part. It is the way out of a
        // filtered view, and the picker opens filtered to the current selection.
        h('button', {
            onClick: () => setCatFilter('all'),
            onMouseDown: keepSearchFocus,
            style: tabStyle(catFilter === 'all', c)
        }, allLabel),
        edges.overflowing && arrowEl('◂', edges.atStart, () => page(-1), c),
        h('div', {
            ref: stripRef, className: 'tabstrip-noscrollbar', onScroll: measure,
            style: {
                display: 'flex', gap: 2, flex: 1, minWidth: 0,
                overflowX: 'auto', overflowY: 'hidden', position: 'relative',
                // No scroll snapping: the strip is placed deliberately, by the
                // arrows and by scrollTabIntoView, and neither lands on a tab
                // boundary. Mandatory snapping would pull the marked tab back
                // off the centre it has just been brought to.
                maskImage: fadeMask(edges), WebkitMaskImage: fadeMask(edges),
            }
        },
            groups.map(g => h('button', {
                key: g.id,
                ref: g.id === markedGroup ? activeTabRef : undefined,
                onClick: () => setCatFilter(g.id),
                onMouseDown: keepSearchFocus,
                style: tabStyle(catFilter === g.id, c, g.id === currentGroup)
            }, g.label))
        ),
        edges.overflowing && arrowEl('▸', edges.atEnd, () => page(1), c)
    );
}
