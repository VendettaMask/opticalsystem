using System.Text.Json;
using System.Text.Json.Serialization;
using OptilandWorkbench.Core;
using OptilandWorkbench.Core.Serialization;
using OptilandWorkbench.InitialStructure.Contracts;
using OptilandWorkbench.InitialStructure.Engine;
using OptilandWorkbench.InitialStructure.Engine.Optimization;

var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../../../.."));
var options = new JsonSerializerOptions { NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals, PropertyNameCaseInsensitive = true, WriteIndented = true, Converters = { new JsonStringEnumConverter() } };
// Quality fixtures serialize numeric enums.
var quality = JsonSerializer.Deserialize<QualityInput[]>(File.ReadAllText(Path.Combine(root, "labs/InitialStructure/benchmarks/quality-audit-20260926/inputs.json")), options)!;
var reports = new List<object>();
if (args.FirstOrDefault() == "generic")
{
    var result = BoundedTrustRegionLeastSquares.Solve([0.0, 0.0], [-10, -10], [10, 10],
        (point, _) => new([point[0] - 3, 100 * (point[1] - 2)]),
        new() { InitialRadius = 2.5, MaximumEvaluations = 60, StepMethod = LeastSquaresStepMethod.Regularized });
    Console.WriteLine(JsonSerializer.Serialize(result, options));
    return;
}
foreach (var index in new[] { 6, 9 })
{
    var input = quality[index];
    var spec = input.Specification with { FlatStart = input.Specification.FlatStart! with { SamplingPolicy = FlatStartSamplingPolicy.UniformAreaGaussianV1 } };
    var problem = new FlatStartDesignProblem(spec, input.Family.ElementCount, input.Initial, input.Family);
    var initial = problem.Vector(input.Initial);
    var best = Evaluate(initial);
    var accepted = new List<object>();
    var statistics = new List<object>();
    var result = FlatStartLocalSolver.Solve(problem.SolverCoordinates, initial, best, 600, Evaluate, true, () => false, default,
        (point, evaluation, phase) => { accepted.Add(new { phase, Point = point, Evaluation = Summary(evaluation) }); if (Rank(evaluation) < Rank(best) || Rank(evaluation) == Rank(best) && evaluation.Merit < best.Merit) best = evaluation; },
        (phase, stats) => statistics.Add(new { phase, stats }));
    var fresh = problem.Evaluate(Optic.FromSnapshot(best.EvaluatedOptic!), FlatStartDesignProblem.FullStage, true, default, true);
    reports.Add(new { Index = index, input.Id, spec, Result = new { result.Evaluations, result.Termination }, Best = Summary(best), Fresh = Summary(fresh), Accepted = accepted, Statistics = statistics });
    Console.WriteLine($"quality {index}: {result.Termination} {result.Evaluations}, best RMS {best.Fields.Max(f => f.RmsRadiusMillimeters)}, fresh {fresh.Fields.Max(f => f.RmsRadiusMillimeters)}, meets {fresh.MeetsTargets}");
    DesignEvaluation Evaluate(double[] vector) => problem.Evaluate(problem.CreateOptic(vector, FlatStartDesignProblem.FullStage), FlatStartDesignProblem.FullStage, true, default);
}
var fixture = JsonSerializer.Deserialize<Fixture>(File.ReadAllText(Path.Combine(root, "labs/InitialStructure/benchmarks/field-continuation-20260927/restart-inputs.json")), options)!;
foreach (var input in fixture.Cases.Where(c => c.TrialId is "trial-0056" or "trial-0078"))
{
    var result = new FlatStartDesignService().Continue(input.Specification, input.Family, input.RootProof, input.Start, input.ParentCandidateId);
    reports.Add(new { input.TrialId, input.Specification, result.State, result.EvaluationCount, Final = Summary(result.FinalValidation!), Steps = result.Steps.Select(s => new { s.EvaluationNumber, s.Operation, Evaluation = Summary(s.Evaluation) }), result.Diagnostics });
    Console.WriteLine($"restart {input.TrialId}: {result.EvaluationCount}, RMS {result.FinalValidation!.Fields.Max(f => f.RmsRadiusMillimeters)}, feasible {result.FinalValidation.IsFeasible}");
}
File.WriteAllText(Path.Combine(root, "artifacts/validation/problem-fix-20261014/" + (args.FirstOrDefault() ?? "diagnostic-before") + ".json"), JsonSerializer.Serialize(reports, options));
static int Rank(DesignEvaluation e) => e.MeetsTargets ? 0 : e.IsFeasible ? 1 : 2;
static object Summary(DesignEvaluation e) => new { e.Merit, e.MeetsTargets, e.GeometryFeasible, e.IsFeasible, e.HasContinuousSearchResiduals, Rms = e.Fields.Max(f => f.RmsRadiusMillimeters), Maximum = e.Fields.Max(f => f.MaximumRadiusMillimeters), e.EffectiveFocalLengthMillimeters, e.Violations, Fingerprint = ContentFingerprint.Compute(e.EvaluatedOptic!), e.EvaluatedOptic };
record QualityInput(string Id, InitialStructureSpecification Specification, FlatStartFamily Family, OpticSnapshot Initial);
record Fixture(Input[] Cases);
record Input(string TrialId, InitialStructureSpecification Specification, FlatStartFamily Family, OpticSnapshot Start, FlatStartBootstrapResult RootProof, string ParentCandidateId);
