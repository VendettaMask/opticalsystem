# Zemax / Workbench 数值比较

结论仅适用于 manifest 记录的镜头哈希、CapturedSettings、软件版本和容差配置。图像是数值重绘，原生截图状态单列；截图不计数值通过。

Enumerated: 177; Workbench captured: 2; Zemax captured: 2; Pass: 0; Close: 1; Difference: 1; Incomparable: 0; Skipped: 175; Error: 0

| Analysis | Zemax | Workbench | Comparison | Worst NRMSE | Reason |
|---|---|---|---|---:|---|
| [Single Ray Trace](comparisons/single-ray-trace-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Non-Sequential Ray Trace](comparisons/non-sequential-ray-trace-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Non-Sequential Detector Viewer](comparisons/non-sequential-detector-viewer-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [First Order](comparisons/first-order-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Seidel Coefficients](comparisons/seidel-coefficients-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Seidel Diagram](comparisons/seidel-diagram-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Spot Diagram](comparisons/spot-diagram-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Full Field Spot Diagram](comparisons/full-field-spot-diagram-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Matrix Spot Diagram](comparisons/matrix-spot-diagram-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Configuration Matrix Spot Diagram](comparisons/configuration-matrix-spot-diagram-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Ray Fan](comparisons/ray-fan-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Footprint Diagram](comparisons/footprint-diagram-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Field Curvature and Distortion](comparisons/field-curvature-and-distortion-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Grid Distortion](comparisons/grid-distortion-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Field Curvature](comparisons/field-curvature-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Color Focus Shift](comparisons/color-focus-shift-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Lateral Color](comparisons/lateral-color-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Axial Aberration](comparisons/axial-aberration-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Full Field Aberration](comparisons/full-field-aberration-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Encircled Energy](comparisons/encircled-energy-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Diffraction Encircled Energy](comparisons/diffraction-encircled-energy-c1/comparison.json) | Captured | Captured | Difference | 0.0121515 |  |
| [Geometric Line Edge Spread](comparisons/geometric-line-edge-spread-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Extended Source Encircled Energy](comparisons/extended-source-encircled-energy-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Pupil Aberration](comparisons/pupil-aberration-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [RMS vs Field](comparisons/rms-vs-field-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [RMS vs Wavelength](comparisons/rms-vs-wavelength-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [RMS vs Focus](comparisons/rms-vs-focus-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [RMS Field Map](comparisons/rms-field-map-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [RMS Wavefront vs Field](comparisons/rms-wavefront-vs-field-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Through Focus](comparisons/through-focus-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Through Focus MTF](comparisons/through-focus-mtf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Fourier Through Focus MTF](comparisons/fourier-through-focus-mtf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Huygens Through Focus MTF](comparisons/huygens-through-focus-mtf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Geometric Through Focus MTF](comparisons/geometric-through-focus-mtf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Fourier MTF vs Field](comparisons/fourier-mtf-vs-field-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Huygens MTF vs Field](comparisons/huygens-mtf-vs-field-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Geometric MTF vs Field](comparisons/geometric-mtf-vs-field-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Angle vs Image Height](comparisons/angle-vs-image-height-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Angle vs Image Height - Through Pupil](comparisons/angle-vs-image-height---through-pupil-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Angle vs Image Height - Through Field](comparisons/angle-vs-image-height---through-field-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Cardinal Points Data](comparisons/cardinal-points-data-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Vignetting Diagram](comparisons/vignetting-diagram-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Relative Illumination](comparisons/relative-illumination-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Incoherent Irradiance](comparisons/incoherent-irradiance-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Radiant Intensity](comparisons/radiant-intensity-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Y-Ybar](comparisons/y-ybar-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [PSF](comparisons/psf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [FFT PSF Cross Section](comparisons/fft-psf-cross-section-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [FFT Line Edge Spread](comparisons/fft-line-edge-spread-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Huygens PSF](comparisons/huygens-psf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Huygens PSF Cross Section](comparisons/huygens-psf-cross-section-c1/comparison.json) | Captured | Captured | Close | 0.00372567 |  |
| [MTF](comparisons/mtf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Huygens MTF](comparisons/huygens-mtf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Geometric MTF](comparisons/geometric-mtf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Sampled MTF](comparisons/sampled-mtf-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Contrast Loss Map](comparisons/contrast-loss-map-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Optical Path Difference](comparisons/optical-path-difference-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Foucault Analysis](comparisons/foucault-analysis-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Wavefront](comparisons/wavefront-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Centroid Sphere Wavefront](comparisons/centroid-sphere-wavefront-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Best Fit Sphere Wavefront](comparisons/best-fit-sphere-wavefront-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Zernike](comparisons/zernike-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Image Simulation](comparisons/image-simulation-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Geometric Image Analysis](comparisons/geometric-image-analysis-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Geometric Bitmap Image Analysis](comparisons/geometric-bitmap-image-analysis-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Light Source Analysis](comparisons/light-source-analysis-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Partially Coherent Image Analysis](comparisons/partially-coherent-image-analysis-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Extended Diffraction Image Analysis](comparisons/extended-diffraction-image-analysis-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Jones Pupil](comparisons/jones-pupil-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Prescription Report](comparisons/prescription-report-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [System Data Report](comparisons/system-data-report-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Classified Data Report](comparisons/classified-data-report-c1/comparison.json) | Skipped | Skipped | Skipped | — | Not selected by --analysis |
| [Zemax:ZernikeAnnularCoefficients](comparisons/zemax-zernikeannularcoefficients/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ZernikeCoefficientsVsField](comparisons/zemax-zernikecoefficientsvsfield/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ZernikeStandardCoefficients](comparisons/zemax-zernikestandardcoefficients/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:FftMtfMap](comparisons/zemax-fftmtfmap/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:GeometricMtfMap](comparisons/zemax-geometricmtfmap/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:FftSurfaceMtf](comparisons/zemax-fftsurfacemtf/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:HuygensSurfaceMtf](comparisons/zemax-huygenssurfacemtf/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfaceCurvatureCross](comparisons/zemax-surfacecurvaturecross/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfacePhaseCross](comparisons/zemax-surfacephasecross/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfaceSagCross](comparisons/zemax-surfacesagcross/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfaceCurvature](comparisons/zemax-surfacecurvature/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfacePhase](comparisons/zemax-surfacephase/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfaceSag](comparisons/zemax-surfacesag/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:Interferogram](comparisons/zemax-interferogram/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:Draw2D](comparisons/zemax-draw2d/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:Draw3D](comparisons/zemax-draw3d/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:IMABIMFileViewer](comparisons/zemax-imabimfileviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:BitmapFileViewer](comparisons/zemax-bitmapfileviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:BiocularFieldOfViewAnalysis](comparisons/zemax-biocularfieldofviewanalysis/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:BiocularDipvergenceConvergence](comparisons/zemax-bioculardipvergenceconvergence/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PowerFieldMapSettings](comparisons/zemax-powerfieldmapsettings/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PowerPupilMapSettings](comparisons/zemax-powerpupilmapsettings/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:FiberCouplingSettings](comparisons/zemax-fibercouplingsettings/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:YNIContributions](comparisons/zemax-ynicontributions/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SagTable](comparisons/zemax-sagtable/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:DispersionDiagram](comparisons/zemax-dispersiondiagram/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:GlassMap](comparisons/zemax-glassmap/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:AthermalGlassMap](comparisons/zemax-athermalglassmap/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:InternalTransmissionvsWavelength](comparisons/zemax-internaltransmissionvswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:DispersionvsWavelength](comparisons/zemax-dispersionvswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:GrinProfile](comparisons/zemax-grinprofile/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:GradiumProfile](comparisons/zemax-gradiumprofile/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:UniversalPlot1D](comparisons/zemax-universalplot1d/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:UniversalPlot2D](comparisons/zemax-universalplot2d/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PolarizationRayTrace](comparisons/zemax-polarizationraytrace/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:Transmission](comparisons/zemax-transmission/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PhaseAberration](comparisons/zemax-phaseaberration/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:TransmissionFan](comparisons/zemax-transmissionfan/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ParaxialGaussianBeam](comparisons/zemax-paraxialgaussianbeam/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SkewGaussianBeam](comparisons/zemax-skewgaussianbeam/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PhysicalOpticsPropagation](comparisons/zemax-physicalopticspropagation/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:BeamFileViewer](comparisons/zemax-beamfileviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ReflectionvsAngle](comparisons/zemax-reflectionvsangle/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:TransmissionvsAngle](comparisons/zemax-transmissionvsangle/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:AbsorptionvsAngle](comparisons/zemax-absorptionvsangle/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:DiattenuationvsAngle](comparisons/zemax-diattenuationvsangle/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PhasevsAngle](comparisons/zemax-phasevsangle/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:RetardancevsAngle](comparisons/zemax-retardancevsangle/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ReflectionvsWavelength](comparisons/zemax-reflectionvswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:TransmissionvsWavelength](comparisons/zemax-transmissionvswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:AbsorptionvsWavelength](comparisons/zemax-absorptionvswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:DiattenuationvsWavelength](comparisons/zemax-diattenuationvswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PhasevsWavelength](comparisons/zemax-phasevswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:RetardancevsWavelength](comparisons/zemax-retardancevswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:DirectivityPlot](comparisons/zemax-directivityplot/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SourcePolarViewer](comparisons/zemax-sourcepolarviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PhotoluminscenceViewer](comparisons/zemax-photoluminscenceviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SourceSpectrumViewer](comparisons/zemax-sourcespectrumviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:RadiantSourceModelViewerSettings](comparisons/zemax-radiantsourcemodelviewersettings/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfaceDataSettings](comparisons/zemax-surfacedatasettings/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:FileComparatorSettings](comparisons/zemax-filecomparatorsettings/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PartViewer](comparisons/zemax-partviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ReverseRadianceAnalysis](comparisons/zemax-reverseradianceanalysis/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PathAnalysis](comparisons/zemax-pathanalysis/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:FluxvsWavelength](comparisons/zemax-fluxvswavelength/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:RoadwayLighting](comparisons/zemax-roadwaylighting/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SourceIlluminationMap](comparisons/zemax-sourceilluminationmap/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ScatterFunctionViewer](comparisons/zemax-scatterfunctionviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ScatterPolarPlotSettings](comparisons/zemax-scatterpolarplotsettings/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ZemaxElementDrawing](comparisons/zemax-zemaxelementdrawing/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ShadedModel](comparisons/zemax-shadedmodel/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:NSCShadedModel](comparisons/zemax-nscshadedmodel/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:NSC3DLayout](comparisons/zemax-nsc3dlayout/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:NSCObjectViewer](comparisons/zemax-nscobjectviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:RayDatabaseViewer](comparisons/zemax-raydatabaseviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ISOElementDrawing](comparisons/zemax-isoelementdrawing/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:TestPlateList](comparisons/zemax-testplatelist/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SourceColorChart1931](comparisons/zemax-sourcecolorchart1931/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SourceColorChart1976](comparisons/zemax-sourcecolorchart1976/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:PrescriptionGraphic](comparisons/zemax-prescriptiongraphic/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:CriticalRayTracer](comparisons/zemax-criticalraytracer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:CoatingListing](comparisons/zemax-coatinglisting/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfaceSlope](comparisons/zemax-surfaceslope/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfaceSlopeCross](comparisons/zemax-surfaceslopecross/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:QuickYield](comparisons/zemax-quickyield/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SystemCheck](comparisons/zemax-systemcheck/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ToleranceYield](comparisons/zemax-toleranceyield/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:ToleranceHistogram](comparisons/zemax-tolerancehistogram/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:DiffEfficiency2D](comparisons/zemax-diffefficiency2d/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:DiffEfficiencyAngular](comparisons/zemax-diffefficiencyangular/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:DiffEfficiencyChromatic](comparisons/zemax-diffefficiencychromatic/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:NSCSurfaceSag](comparisons/zemax-nscsurfacesag/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:NSCGeometricMtf](comparisons/zemax-nscgeometricmtf/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfacePhaseSlope](comparisons/zemax-surfacephaseslope/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:SurfacePhaseSlopeCross](comparisons/zemax-surfacephaseslopecross/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:STARAlignCheck](comparisons/zemax-staraligncheck/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:STARSysViewer](comparisons/zemax-starsysviewer/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:STAR2DDefPlot](comparisons/zemax-star2ddefplot/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:STARPerfChange](comparisons/zemax-starperfchange/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:STARIndexVsTemp](comparisons/zemax-starindexvstemp/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:STARInspectFEA](comparisons/zemax-starinspectfea/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:UserDefinedCOM](comparisons/zemax-userdefinedcom/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:NEST](comparisons/zemax-nest/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:NSCSpotStandardNative](comparisons/zemax-nscspotstandardnative/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |
| [Zemax:XXXTemplateXXX](comparisons/zemax-xxxtemplatexxx/comparison.json) | Skipped | Skipped | Skipped | — | Enumerated native AnalysisIDM; no corresponding public Workbench canonical analysis or explicit adapter. Not executed. |

## 环境与输入

```json
{
  "inputPath": "D:\\Projects\\opticalsystem\\validation\\zemax\\2026-r1\\ms-l7-analysis-expansion-2026-09-06\\source.ZMX",
  "fileName": "source.ZMX",
  "fileLength": 26250,
  "sourceSha256": "8bcc937c2c2e02ba175f38875fd0def40db547f7eedab509cbfd1fed4353e0e8",
  "inputLastWriteUtc": "2026-09-06T04:48:32.0100618Z",
  "startedUtc": "2026-10-08T13:33:39.4274704+00:00",
  "configurationSha256": "a780df3c21edc1bdef1d41e6f4c4fd3a70cac530692c4feaf315b41e6e90695e",
  "configurationVersion": "1.0.0-captured-settings",
  "dotnetVersion": ".NET 10.0.8",
  "operatingSystem": "Microsoft Windows 10.0.26200",
  "toolVersion": "1.0.0",
  "expectedZemaxVersion": "2026 R1",
  "toolAssemblySha256": "4f4665f77b1be32e74af28d22855d5c458bec4cbd3adbadf0301ad53bedf2fe7",
  "settingsOrigin": "CapturedSettings",
  "originalFileUnchanged": true,
  "gitSha": "b4533d8a03ef760c079e164b7e75f26ba547afb9",
  "gitWorkingTreeDirty": true,
  "zmxHeaderRecords": [
    "VERS 181119 161 101059 L101059",
    "MODE SEQ",
    "UNIT MM X W X CM MR CPMM",
    "GCAT SCHOTT",
    "RAIM 0 1 1 1 0 0 0 0 0 0",
    "FTYP 1 0 3 3 0 0 0 3"
  ],
  "zmxFileVersion": "VERS 181119 161 101059 L101059",
  "configurationCount": 1,
  "workbenchParsing": [
    {
      "configuration": 1,
      "surfaceCount": 17,
      "fields": [
        {
          "label": "On axis",
          "x": 0,
          "y": 0,
          "xAngleDegrees": 0,
          "yAngleDegrees": 0,
          "weight": 1,
          "vignetteFactorX": 0,
          "vignetteFactorY": 0,
          "vignetteDecenterX": 0,
          "vignetteDecenterY": 0,
          "vignetteAngleDegrees": 0
        },
        {
          "label": "Field 2",
          "x": 0,
          "y": -10.6,
          "xAngleDegrees": 0,
          "yAngleDegrees": -10.6,
          "weight": 1,
          "vignetteFactorX": 0,
          "vignetteFactorY": 0,
          "vignetteDecenterX": 0,
          "vignetteDecenterY": 0,
          "vignetteAngleDegrees": 0
        },
        {
          "label": "Field 3",
          "x": 0,
          "y": -15,
          "xAngleDegrees": 0,
          "yAngleDegrees": -15,
          "weight": 1,
          "vignetteFactorX": 0,
          "vignetteFactorY": 0,
          "vignetteDecenterX": 0,
          "vignetteDecenterY": 0,
          "vignetteAngleDegrees": 0
        }
      ],
      "wavelengths": [
        {
          "label": "W1",
          "nanometers": 486.1327,
          "micrometers": 0.4861327,
          "weight": 1,
          "isPrimary": false
        },
        {
          "label": "W2",
          "nanometers": 587.5618000000001,
          "micrometers": 0.5875618,
          "weight": 1,
          "isPrimary": true
        },
        {
          "label": "W3",
          "nanometers": 656.2725,
          "micrometers": 0.6562725,
          "weight": 1,
          "isPrimary": false
        }
      ],
      "fieldDefinition": "ObjectHeight",
      "aperture": {
        "kind": "EntrancePupilDiameter",
        "value": 16.4798,
        "objectSpaceTelecentric": false
      },
      "imageSpaceAfocal": false,
      "rayAimingEnabled": true,
      "glassCatalogs": [
        "SCHOTT"
      ],
      "apodization": {
        "kind": "zemax_pupil",
        "numbers": {
          "type": 0,
          "factor": 0
        },
        "text": {},
        "children": null
      },
      "preflightIssues": [],
      "coordinateBreaks": [],
      "parserWarnings": "Importer exposes capability issues; unsupported preserved records are available in input snapshot. No additional warning stream is exposed."
    }
  ],
  "zosApiPath": "D:\\Program Files\\ANSYS Inc\\v261\\Zemax OpticStudio",
  "zemaxEnvironment": {
    "major": 26,
    "minor": 1,
    "servicePack": 0,
    "opticStudioVersion": 260127,
    "licenseStatus": "EnterpriseEdition",
    "validLicense": true,
    "initializationErrors": "",
    "analysisIds": [
      "RayFan",
      "OpticalPathFan",
      "PupilAberrationFan",
      "FieldCurvatureAndDistortion",
      "FocalShiftDiagram",
      "GridDistortion",
      "LateralColor",
      "LongitudinalAberration",
      "RayTrace",
      "SeidelCoefficients",
      "SeidelDiagram",
      "ZernikeAnnularCoefficients",
      "ZernikeCoefficientsVsField",
      "ZernikeFringeCoefficients",
      "ZernikeStandardCoefficients",
      "FftMtf",
      "FftThroughFocusMtf",
      "GeometricThroughFocusMtf",
      "GeometricMtf",
      "FftMtfMap",
      "GeometricMtfMap",
      "FftSurfaceMtf",
      "FftMtfvsField",
      "GeometricMtfvsField",
      "HuygensMtfvsField",
      "HuygensMtf",
      "HuygensSurfaceMtf",
      "HuygensThroughFocusMtf",
      "FftPsf",
      "FftPsfCrossSection",
      "FftPsfLineEdgeSpread",
      "HuygensPsfCrossSection",
      "HuygensPsf",
      "DiffractionEncircledEnergy",
      "GeometricEncircledEnergy",
      "GeometricLineEdgeSpread",
      "ExtendedSourceEncircledEnergy",
      "SurfaceCurvatureCross",
      "SurfacePhaseCross",
      "SurfaceSagCross",
      "SurfaceCurvature",
      "SurfacePhase",
      "SurfaceSag",
      "StandardSpot",
      "ThroughFocusSpot",
      "FullFieldSpot",
      "MatrixSpot",
      "ConfigurationMatrixSpot",
      "RMSField",
      "RMSFieldMap",
      "RMSLambdaDiagram",
      "RMSFocus",
      "Foucault",
      "Interferogram",
      "WavefrontMap",
      "DetectorViewer",
      "Draw2D",
      "Draw3D",
      "ImageSimulation",
      "GeometricImageAnalysis",
      "IMABIMFileViewer",
      "GeometricBitmapImageAnalysis",
      "BitmapFileViewer",
      "LightSourceAnalysis",
      "PartiallyCoherentImageAnalysis",
      "ExtendedDiffractionImageAnalysis",
      "BiocularFieldOfViewAnalysis",
      "BiocularDipvergenceConvergence",
      "RelativeIllumination",
      "VignettingDiagramSettings",
      "FootprintSettings",
      "YYbarDiagram",
      "PowerFieldMapSettings",
      "PowerPupilMapSettings",
      "IncidentAnglevsImageHeight",
      "FiberCouplingSettings",
      "YNIContributions",
      "SagTable",
      "CardinalPoints",
      "DispersionDiagram",
      "GlassMap",
      "AthermalGlassMap",
      "InternalTransmissionvsWavelength",
      "DispersionvsWavelength",
      "GrinProfile",
      "GradiumProfile",
      "UniversalPlot1D",
      "UniversalPlot2D",
      "PolarizationRayTrace",
      "PolarizationPupilMap",
      "Transmission",
      "PhaseAberration",
      "TransmissionFan",
      "ParaxialGaussianBeam",
      "SkewGaussianBeam",
      "PhysicalOpticsPropagation",
      "BeamFileViewer",
      "ReflectionvsAngle",
      "TransmissionvsAngle",
      "AbsorptionvsAngle",
      "DiattenuationvsAngle",
      "PhasevsAngle",
      "RetardancevsAngle",
      "ReflectionvsWavelength",
      "TransmissionvsWavelength",
      "AbsorptionvsWavelength",
      "DiattenuationvsWavelength",
      "PhasevsWavelength",
      "RetardancevsWavelength",
      "DirectivityPlot",
      "SourcePolarViewer",
      "PhotoluminscenceViewer",
      "SourceSpectrumViewer",
      "RadiantSourceModelViewerSettings",
      "SurfaceDataSettings",
      "PrescriptionDataSettings",
      "FileComparatorSettings",
      "PartViewer",
      "ReverseRadianceAnalysis",
      "PathAnalysis",
      "FluxvsWavelength",
      "RoadwayLighting",
      "SourceIlluminationMap",
      "ScatterFunctionViewer",
      "ScatterPolarPlotSettings",
      "ZemaxElementDrawing",
      "ShadedModel",
      "NSCShadedModel",
      "NSC3DLayout",
      "NSCObjectViewer",
      "RayDatabaseViewer",
      "ISOElementDrawing",
      "SystemData",
      "TestPlateList",
      "SourceColorChart1931",
      "SourceColorChart1976",
      "PrescriptionGraphic",
      "CriticalRayTracer",
      "ContrastLoss",
      "CoatingListing",
      "FullFieldAberration",
      "SurfaceSlope",
      "SurfaceSlopeCross",
      "QuickYield",
      "SystemCheck",
      "ToleranceYield",
      "ToleranceHistogram",
      "DiffEfficiency2D",
      "DiffEfficiencyAngular",
      "DiffEfficiencyChromatic",
      "NSCSurfaceSag",
      "NSCSingleRayTrace",
      "NSCGeometricMtf",
      "SurfacePhaseSlope",
      "SurfacePhaseSlopeCross",
      "STARAlignCheck",
      "STARSysViewer",
      "STAR2DDefPlot",
      "STARPerfChange",
      "STARIndexVsTemp",
      "STARInspectFEA",
      "UserDefinedCOM",
      "NEST",
      "NSCSpotStandardNative",
      "XXXTemplateXXX"
    ]
  },
  "zemaxParsing": {
    "mode": "Sequential",
    "surfaceCount": 17,
    "configurationCount": 1,
    "fields": [
      {
        "number": 1,
        "data": {
          "IsActive": true,
          "FieldNumber": 1,
          "X": 0,
          "Y": 0,
          "Weight": 1,
          "VDX": 0,
          "VDY": 0,
          "VCX": 0,
          "VCY": 0,
          "VAN": 0,
          "TAN": 0,
          "Comment": "",
          "XSolve": "Fixed",
          "YSolve": "Fixed",
          "Ignore": false
        }
      },
      {
        "number": 2,
        "data": {
          "IsActive": true,
          "FieldNumber": 2,
          "X": 0,
          "Y": -10.6,
          "Weight": 1,
          "VDX": 0,
          "VDY": 0,
          "VCX": 0,
          "VCY": 0,
          "VAN": 0,
          "TAN": 0,
          "Comment": "",
          "XSolve": "Fixed",
          "YSolve": "Fixed",
          "Ignore": false
        }
      },
      {
        "number": 3,
        "data": {
          "IsActive": true,
          "FieldNumber": 3,
          "X": 0,
          "Y": -15,
          "Weight": 1,
          "VDX": 0,
          "VDY": 0,
          "VCX": 0,
          "VCY": 0,
          "VAN": 0,
          "TAN": 0,
          "Comment": "",
          "XSolve": "Fixed",
          "YSolve": "Fixed",
          "Ignore": false
        }
      }
    ],
    "wavelengths": [
      {
        "number": 1,
        "data": {
          "WavelengthNumber": 1,
          "IsActive": true,
          "IsPrimary": false,
          "Wavelength": 0.4861327,
          "Weight": 1
        }
      },
      {
        "number": 2,
        "data": {
          "WavelengthNumber": 2,
          "IsActive": true,
          "IsPrimary": true,
          "Wavelength": 0.5875618,
          "Weight": 1
        }
      },
      {
        "number": 3,
        "data": {
          "WavelengthNumber": 3,
          "IsActive": true,
          "IsPrimary": false,
          "Wavelength": 0.6562725,
          "Weight": 1
        }
      }
    ],
    "aperture": {
      "ApertureType": "EntrancePupilDiameter",
      "ApertureValue": 16.4798,
      "ApodizationType": "Uniform",
      "ApodizationFactor": 0,
      "ApodizationFactorIsUsed": false,
      "SemiDiameterMargin": 0,
      "SemiDiameterMarginPct": 0,
      "TelecentricObjectSpace": false,
      "AFocalImageSpace": false,
      "IterateSolvesWhenUpdating": false,
      "FastSemiDiameters": true,
      "CheckGRINApertures": false
    },
    "units": {
      "LensUnits": "Millimeters",
      "SourceUnitPrefix": "None",
      "SourceUnits": "Watts",
      "AnalysisUnitPrefix": "None",
      "AnalysisUnits": "WattsPerCMSq",
      "AfocalModeUnits": "Milliradians",
      "MTFUnits": "CyclesPerMillimeter",
      "UseLensUnitsForCAD": true,
      "CADUnits": "Millimeters"
    },
    "rayAiming": {
      "RayAiming": "Paraxial",
      "Method": "Heuristic",
      "UseRayAimingCache": true,
      "UseRobustRayAiming": false,
      "ScalePupilShiftFactorsByField": false,
      "AutomaticallyCalculatePupilShiftsIsChecked": false,
      "UseEnhancedRayAiming": false,
      "UseAdvancedConvergence": false,
      "UseFallBackSearchDuringCacheSetup": false,
      "PupilShiftX": 0,
      "PupilShiftY": 0,
      "PupilShiftZ": 0,
      "PupilCompressX": 0,
      "PupilCompressY": 0,
      "NumStepsCacheSetup": 10
    },
    "environment": {
      "AdjustIndexToEnvironment": false,
      "Temperature": 20,
      "Pressure": 1
    },
    "surfaces": [
      {
        "IsValidRow": true,
        "RowIndex": 0,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 0,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": true,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": null,
        "Thickness": 157.1356942003,
        "Material": "",
        "Coating": "",
        "SemiDiameter": 15,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 15,
        "Conic": 0,
        "TCE": 0,
        "MaterialCatalog": "555CHINESES.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 1,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 1,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": 24.673943044566371,
        "Thickness": 3.217100554962,
        "Material": "N-SK18",
        "Coating": "",
        "SemiDiameter": 8.85,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 8.85,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 2,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 2,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": -68.365417070546783,
        "Thickness": 2.364257385265,
        "Material": "",
        "Coating": "",
        "SemiDiameter": 8.85,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 8.85,
        "Conic": 0,
        "TCE": 0,
        "MaterialCatalog": "555CHINESES.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 3,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 3,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": 9.9026304697766321,
        "Thickness": 4.876277107398,
        "Material": "N-FK56",
        "Coating": "",
        "SemiDiameter": 6.6,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 6.6,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 4,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 4,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": -16.791605597794703,
        "Thickness": 0.9999302400626,
        "Material": "KZFS7A",
        "Coating": "",
        "SemiDiameter": 6.6,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 6.6,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 5,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 5,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": 8.19086009582147,
        "Thickness": 2.744093192587,
        "Material": "",
        "Coating": "",
        "SemiDiameter": 4.335,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 6.6,
        "Conic": 0,
        "TCE": 0,
        "MaterialCatalog": "555CHINESES.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 6,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 6,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": -7.3893622904934047,
        "Thickness": 1.692465802937,
        "Material": "N-BK10",
        "Coating": "",
        "SemiDiameter": 4.321,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 6.6,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 7,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 7,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": true,
        "Comment": "",
        "Radius": 22.489076866146391,
        "Thickness": 4.609979598357,
        "Material": "N-FK56",
        "Coating": "",
        "SemiDiameter": 6.6,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 6.6,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 8,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 8,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": -9.6229921419036888,
        "Thickness": 0.07583120527623,
        "Material": "",
        "Coating": "",
        "SemiDiameter": 6.6,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 6.6,
        "Conic": 0,
        "TCE": 0,
        "MaterialCatalog": "555CHINESES.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 9,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 9,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": 17.350913350385568,
        "Thickness": 4.354699448351,
        "Material": "N-BK7",
        "Coating": "",
        "SemiDiameter": 7.8,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 7.8,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 10,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 10,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": -23.716682822305113,
        "Thickness": 0.144042322567,
        "Material": "",
        "Coating": "",
        "SemiDiameter": 7.8,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 7.8,
        "Conic": 0,
        "TCE": 0,
        "MaterialCatalog": "555CHINESES.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 11,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 11,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": 16.488762830242809,
        "Thickness": 2.9644562471,
        "Material": "N-FK56",
        "Coating": "",
        "SemiDiameter": 7,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 7,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 12,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 12,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": -62.248207753596674,
        "Thickness": 0.0761455868453,
        "Material": "",
        "Coating": "",
        "SemiDiameter": 7,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 7,
        "Conic": 0,
        "TCE": 0,
        "MaterialCatalog": "555CHINESES.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 13,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 13,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": 8.29077585455045,
        "Thickness": 4.207225651125,
        "Material": "N-FK56",
        "Coating": "",
        "SemiDiameter": 5.6,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 5.6,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 14,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 14,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": -15.727338683754182,
        "Thickness": 2.065237946714,
        "Material": "N-LAK7",
        "Coating": "",
        "SemiDiameter": 5.6,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 5.6,
        "Conic": 0,
        "TCE": null,
        "MaterialCatalog": "SCHOTT.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 15,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 15,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": false,
        "IsStop": false,
        "Comment": "",
        "Radius": 6.6023947652659318,
        "Thickness": 3.472571294588,
        "Material": "",
        "Coating": "",
        "SemiDiameter": 2.4147215680071716,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 5.6,
        "Conic": 0,
        "TCE": 0,
        "MaterialCatalog": "555CHINESES.AGF"
      },
      {
        "IsValidRow": true,
        "RowIndex": 16,
        "RowTypeName": "\u6807\u51C6\u9762",
        "Bookmark": "",
        "IsActive": true,
        "SurfaceNumber": 16,
        "TypeName": "\u6807\u51C6\u9762",
        "Type": "Standard",
        "IsObject": false,
        "IsImage": true,
        "IsStop": false,
        "Comment": "",
        "Radius": null,
        "Thickness": null,
        "Material": "",
        "Coating": "",
        "SemiDiameter": 1.4947297864968714,
        "ChipZone": 0,
        "MechanicalSemiDiameter": 1.4947297864968714,
        "Conic": 0,
        "TCE": 0,
        "MaterialCatalog": "555CHINESES.AGF"
      }
    ],
    "warnings": ""
  },
  "completedUtc": "2026-10-08T13:34:22.1880964+00:00",
  "snapshotInputUnchanged": true,
  "fatalError": null
}
```

## 最差差异

- Diffraction Encircled Energy: Difference, NRMSE 0.0121515
- Huygens PSF Cross Section: Close, NRMSE 0.00372567

## Diffraction Encircled Energy

Difference: 

Native screenshot: NotRequested

Settings origin: CapturedSettings; request SHA-256: `6104a0313173c083c6ceeca19abfd4a5616c76acb4f46e1fe6bbc757b5242a09`

```json
{
  "canonicalAnalysisKey": "Diffraction Encircled Energy",
  "configuration": 1,
  "field": 1,
  "wavelength": 1,
  "surface": -1,
  "pupilSampling": 64,
  "imageSampling": 128,
  "rayCount": 20,
  "gridSize": 128,
  "imageDeltaMicrometers": 0.25,
  "maximumFrequency": 50,
  "focusMinimum": -0.1,
  "focusMaximum": 0.1,
  "reference": "Centroid",
  "polarization": false,
  "apodization": "{\r\n  \u0022kind\u0022: \u0022zemax_pupil\u0022,\r\n  \u0022numbers\u0022: {\r\n    \u0022type\u0022: 0,\r\n    \u0022factor\u0022: 0\r\n  },\r\n  \u0022text\u0022: {},\r\n  \u0022children\u0022: null\r\n}",
  "deleteVignetted": true,
  "useRayAiming": true,
  "normalization": "NativePhysical",
  "coordinateConvention": "LocalSurfaceXY; row=y ascending; column=x ascending",
  "outputUnits": "TypedAxes",
  "settingsOrigin": "CapturedSettings",
  "workbenchSettings": {
    "PupilSampling": "64",
    "ImageSampling": "128",
    "NumPoints": "401",
    "WavelengthNumber": "1",
    "FieldNumber": "1",
    "Type": "encircled",
    "Reference": "centroid",
    "MaximumDistanceMicrometers": "5",
    "SurfaceNumber": "-1",
    "UsePolarization": "False",
    "UseRayAiming": "True",
    "Sampling": "64",
    "ZernikeTerms": "37",
    "NumRays": "64",
    "Distribution": "uniform",
    "MaximumRadiusMicrometers": "5",
    "MultiplyByDiffractionLimit": "False"
  },
  "zemaxSettings": {
    "Wavelength": 1,
    "Field": 1,
    "Surface": -1,
    "SampleSize": "S_64x64",
    "UsePolarization": false,
    "RadiusMaximum": 5,
    "Type": "Encircled",
    "ReferTo": "Centroid",
    "ScatterRays": false,
    "ShowDiffractionLimit": true,
    "UseDashes": false,
    "UseHuygensPSF": false,
    "HuygensSample": "S_128x128",
    "HuygensDelta": 0
  },
  "zemaxCfgSettings": {},
  "wavelengthScope": "Selected",
  "wavelengthCount": 3,
  "fieldDefinition": "ObjectHeight",
  "maximumFieldRadius": 15,
  "surfaceCount": 17,
  "fieldCount": 3,
  "definedFields": [
    [
      0,
      0
    ],
    [
      0,
      -10.6
    ],
    [
      0,
      -15
    ]
  ],
  "fieldScanDirection": "\u002By",
  "primaryWavelengthMicrometers": 0.5875618,
  "zemaxSettingsMode": "TypedProperties",
  "sourceImagePath": null,
  "sourceImageSha256": null
}
```

Per-quantity tolerances (configuration SHA-256 in manifest):

```json
{
  "EnergyFraction": {
    "absolute": 1E-05,
    "relative": 0.002,
    "nrmse": 0.003,
    "closeNrmse": 0.01,
    "minimumCoverage": 0.95
  }
}
```

- curve:0: sorted coordinates; linear interpolation on union of 786 physical knots in [0, 5]; no extrapolation
- curve:1: sorted coordinates; linear interpolation on union of 786 physical knots in [0, 5]; no extrapolation

```json
[
  {
    "id": "curve:0",
    "unit": "Dimensionless",
    "count": 786,
    "maxAbsolute": 0.016451146568228325,
    "meanAbsolute": 0.010920604470691687,
    "rmse": 0.012043224981717945,
    "nrmse": 0.012151517736480101,
    "maxRelative": 0.6744319681589591,
    "p50": 0.013534853600582153,
    "p90": 0.015517563353101393,
    "p95": 0.015604569256077588,
    "pearson": 0.9994972551262057,
    "worstX": 0.8749999999999989,
    "worstY": null,
    "coverage": 1,
    "conclusion": "Difference",
    "extra": {}
  },
  {
    "id": "curve:1",
    "unit": "Dimensionless",
    "count": 786,
    "maxAbsolute": 0.016180104576864807,
    "meanAbsolute": 0.008626231032553631,
    "rmse": 0.009999021862625846,
    "nrmse": 0.01009576564140292,
    "maxRelative": 0.6645168619407663,
    "p50": 0.009387868035045571,
    "p90": 0.015098764520668273,
    "p95": 0.0157998354489248,
    "pearson": 0.9998464100867436,
    "worstX": 2.975,
    "worstY": null,
    "coverage": 1,
    "conclusion": "Difference",
    "extra": {}
  }
]
```

![curve-0-difference](comparisons/diffraction-encircled-energy-c1/curve-0-difference.png)

![curve-0-overlay](comparisons/diffraction-encircled-energy-c1/curve-0-overlay.png)

![curve-1-difference](comparisons/diffraction-encircled-energy-c1/curve-1-difference.png)

![curve-1-overlay](comparisons/diffraction-encircled-energy-c1/curve-1-overlay.png)


## Huygens PSF Cross Section

Close: 

Native screenshot: NotRequested

Settings origin: CapturedSettings; request SHA-256: `2e3dffb011fd90408919884ebab8e09b287131400b2784e9ef772616cdf00213`

```json
{
  "canonicalAnalysisKey": "Huygens PSF Cross Section",
  "configuration": 1,
  "field": 1,
  "wavelength": 1,
  "surface": -1,
  "pupilSampling": 32,
  "imageSampling": 32,
  "rayCount": 20,
  "gridSize": 32,
  "imageDeltaMicrometers": 0.25,
  "maximumFrequency": 50,
  "focusMinimum": -0.1,
  "focusMaximum": 0.1,
  "reference": "ChiefRay",
  "polarization": false,
  "apodization": "{\r\n  \u0022kind\u0022: \u0022zemax_pupil\u0022,\r\n  \u0022numbers\u0022: {\r\n    \u0022type\u0022: 0,\r\n    \u0022factor\u0022: 0\r\n  },\r\n  \u0022text\u0022: {},\r\n  \u0022children\u0022: null\r\n}",
  "deleteVignetted": true,
  "useRayAiming": true,
  "normalization": "NativePhysical",
  "coordinateConvention": "LocalSurfaceXY; row=y ascending; column=x ascending",
  "outputUnits": "TypedAxes",
  "settingsOrigin": "CapturedSettings",
  "workbenchSettings": {
    "PupilSampling": "32",
    "ImageSampling": "32",
    "ImageDeltaMicrometers": "0.25",
    "WavelengthNumber": "1",
    "FieldNumber": "1",
    "ProfileType": "X",
    "UsePolarization": "False",
    "UseCentroid": "False",
    "SurfaceNumber": "-1",
    "UseRayAiming": "True",
    "Sampling": "32",
    "Normalized": "False",
    "Frequency": "50",
    "SpatialFrequency": "50",
    "MaximumFrequency": "50",
    "DeltaFocus": "0.01",
    "NumberOfSteps": "5",
    "Steps": "5",
    "UseDashes": "False",
    "FieldDensity": "10",
    "FieldPointCount": "10",
    "ScanType": "\u002By",
    "RemoveVignettingFactors": "True",
    "Frequency1": "10",
    "Frequency2": "20",
    "Frequency3": "30",
    "Frequency4": "40",
    "Frequency5": "50",
    "Frequency6": "60",
    "NumRays": "32",
    "Distribution": "uniform",
    "ScaleByDiffractionLimit": "False",
    "PlotPointCount": "128",
    "Type": "X-\u7EBF\u6027",
    "Row": "\u4E2D\u5FC3",
    "GraphScaleMicrometers": "0",
    "Spread": "\u7EBF",
    "UseCoherentPsf": "False"
  },
  "zemaxSettings": {
    "Wavelength": 1,
    "UsePolarization": false,
    "Field": 1,
    "PupilSampleSize": "S_32x32",
    "ImageSampleSize": "S_32x32",
    "Configuration": 1,
    "ImageDelta": 0.25,
    "Type": "X_Linear",
    "Normalize": false,
    "RowCol": 0,
    "UseCentroid": false
  },
  "zemaxCfgSettings": {},
  "wavelengthScope": "Selected",
  "wavelengthCount": 3,
  "fieldDefinition": "ObjectHeight",
  "maximumFieldRadius": 15,
  "surfaceCount": 17,
  "fieldCount": 3,
  "definedFields": [
    [
      0,
      0
    ],
    [
      0,
      -10.6
    ],
    [
      0,
      -15
    ]
  ],
  "fieldScanDirection": "\u002By",
  "primaryWavelengthMicrometers": 0.5875618,
  "zemaxSettingsMode": "TypedProperties",
  "sourceImagePath": null,
  "sourceImageSha256": null
}
```

Per-quantity tolerances (configuration SHA-256 in manifest):

```json
{
  "Irradiance": {
    "absolute": 1E-05,
    "relative": 0.002,
    "nrmse": 0.003,
    "closeNrmse": 0.01,
    "minimumCoverage": 0.95
  }
}
```

- curve:0: sorted coordinates; linear interpolation on union of 32 physical knots in [-4, 3.75]; no extrapolation

```json
[
  {
    "id": "curve:0",
    "unit": "Dimensionless",
    "count": 32,
    "maxAbsolute": 0.005391581588203756,
    "meanAbsolute": 0.0010785397662390847,
    "rmse": 0.0017391041264783924,
    "nrmse": 0.0037256670590166724,
    "maxRelative": 5.114861400745076,
    "p50": 0.0004388153406521551,
    "p90": 0.0024980921855840142,
    "p95": 0.0038097536917699425,
    "pearson": 0.9998526585367635,
    "worstX": 0.75,
    "worstY": null,
    "coverage": 0.96875,
    "conclusion": "Close",
    "extra": {}
  }
]
```

![curve-0-difference](comparisons/huygens-psf-cross-section-c1/curve-0-difference.png)

![curve-0-overlay](comparisons/huygens-psf-cross-section-c1/curve-0-overlay.png)


## 适用边界

未实现适配器、非等价参考球、模型预检、API/许可证失败和数值差异均单独记录。捕获设置不是通用 Zemax 默认值。本工具不拟合缩放、不搜索对齐方式，也不通过重新归一化改善分数。--fail-on none/error 返回 0 不代表数值一致，必须查看数量、完整状态矩阵和每项原因。
